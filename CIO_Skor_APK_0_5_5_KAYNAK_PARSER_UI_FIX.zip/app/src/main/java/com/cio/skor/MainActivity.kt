package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Result(val name: String, val code: Int, val matches: List<String>, val error: String? = null)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button
    private lateinit var statusText: TextView

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/all-games/all-stakes/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    private val scorePattern = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        // Uygulama açılır açılmaz gerçek taramayı başlat.
        window.statusBarColor = Color.rgb(7, 11, 16)
        window.navigationBarColor = Color.rgb(7, 11, 16)
        window.decorView.postDelayed({ scanAll() }, 500)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 11, 16))
            setPadding(18, 48, 18, 14)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 17f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 12)
        }
        root.addView(sub)

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 17f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(Color.rgb(55, 65, 75), 12)
            setPadding(12, 0, 12, 0)
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 58))

        statusText = TextView(this).apply {
            text = "Hazır • 16 kaynak taranacak"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 8)
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInitialRows()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        sources.forEachIndexed { index, s ->
            resultBox.addView(row("${index + 1}. ${s.name}", "⏳ Bekliyor..."))
        }
    }

    private fun scanAll() {
        scanButton.isEnabled = false
        scanButton.text = "⏳  16 KAYNAK TARANIYOR..."
        scanButton.background = rounded(Color.rgb(40, 48, 56), 12)
        statusText.text = "🌐 16 kaynak paralel taranıyor..."
        resultBox.removeAllViews()

        val rows = HashMap<String, TextView>()
        sources.forEachIndexed { index, source ->
            val r = row("${index + 1}. ${source.name}", "⏳ Bağlanıyor...")
            rows[source.name] = r.getChildAt(1) as TextView
            resultBox.addView(r)
        }

        val done = AtomicInteger(0)
        val successful = java.util.Collections.synchronizedList(mutableListOf<Result>())
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                if (result.matches.isNotEmpty()) successful.add(result)
                runOnUiThread {
                    // Tarama sırasında yalnızca ilerlemeyi göster; hata veren siteleri
                    // kullanıcıya sonuç ekranında göstermiyoruz.
                    rows[source.name]?.let { detail ->
                        detail.text = if (result.matches.isNotEmpty()) {
                            "✅ ${result.matches.size} temiz skor bulundu"
                        } else {
                            "⏳ işlendi"
                        }
                        detail.setTextColor(when {
                            result.matches.isNotEmpty() -> Color.rgb(75, 225, 135)
                            else -> Color.GRAY
                        })
                    }
                    val n = done.incrementAndGet()
                    statusText.text = "📊 Tarama: $n/${sources.size} tamamlandı"
                    if (n == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                        scanButton.background = rounded(Color.rgb(40, 115, 65), 12)
                        renderCleanResults(successful.toList())
                    }
                }
            }
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(24, 31, 39))
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 5, 0, 0)
        }
        box.addView(t)
        box.addView(d)
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 3, 0, 3) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 18000
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code • erişilemedi")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "HTTP $code • boş HTML")
            val matches = extractMatches(source, html)
            Result(source.name, code, matches)
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), "${e.javaClass.simpleName} • ${e.message ?: "bağlantı hatası"}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun extractMatches(source: Source, html: String): List<String> {
        val doc = Jsoup.parse(html)
        val found = LinkedHashSet<String>()

        val selector = when (source.name) {
            "FP.com" -> "article, li, tr, [class*=match], [class*=game], [class*=prediction]"
            "FootballPredictions.net" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "Forebet" -> "tr, article, li, [class*=rcs], [class*=match], [class*=prediction]"
            "PredictZ" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "WinDrawWin" -> "article, li, tr, [class*=match], [class*=fixture], [class*=prediction]"
            "BettingTipsToday" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "SoccerSeer" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "MightyTips" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "FootyStats" -> "article, li, tr, [class*=match], [class*=prediction], [class*=fixture]"
            "GoalVertex" -> "article, li, tr, [class*=match], [class*=prediction], [class*=fixture], [class*=score]"
            "NerdyTips" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "Vitibet" -> "article, li, tr, table, [class*=match], [class*=prediction]"
            "HuhSports" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "FootballAnt" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "DailySports" -> "article, li, tr, [class*=match], [class*=prediction], [class*=game]"
            "Statarea" -> "article, li, tr, table, [class*=match], [class*=prediction], [class*=game]"
            else -> "article, li, tr, [class*=match], [class*=game], [class*=prediction]"
        }

        for (el in doc.select(selector)) {
            val raw = buildString {
                append(el.text())
                listOf("title", "aria-label", "data-match", "data-event", "data-teams").forEach { key ->
                    val v = el.attr(key).trim()
                    if (v.isNotEmpty()) append(" | ").append(v)
                }
            }.replace(Regex("\\s+"), " ").trim()

            if (raw.length !in 8..700) continue
            val parsed = parseSourceMatch(source.name, raw) ?: continue
            if (looksLikeNoise(parsed.first) || looksLikeNoise(parsed.second)) continue
            found.add("${parsed.first} - ${parsed.second} → ${parsed.third}")
            if (found.size >= 12) break
        }

        return found.toList()
    }

    private fun parseSourceMatch(sourceName: String, raw: String): Triple<String, String, String>? {
        val text = normalizeSourceText(sourceName, raw)
        val score = findPredictionScore(text, sourceName) ?: return null
        val teams = extractTeams(text, score) ?: return null
        return Triple(teams.first, teams.second, score)
    }

    private fun normalizeSourceText(sourceName: String, raw: String): String {
        var t = raw.replace(Regex("\\s+"), " ").trim()

        // Ortak gürültü: tarih, saat, yüzde, oran ve tipik açıklama etiketleri.
        t = t.replace(Regex("\\b(?:19|20)\\d{2}[-/.]\\d{1,2}[-/.]\\d{1,2}\\b"), " ")
        t = t.replace(Regex("\\b\\d{1,2}[-/.]\\d{1,2}[-/.]\\d{2,4}\\b"), " ")
        t = t.replace(Regex("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b"), " ")
        t = t.replace(Regex("\\b\\d+(?:\\.\\d+)?%\\b"), " ")
        t = t.replace(Regex("\\b(?:Odds?|Avg\\.?\\s*Goals?|Over|Under)\\s*[:=]?\\s*\\d*(?:\\.\\d+)?\\b.*?(?=\\b(?:Predicted|Prediction|Correct Score|Scoreline)\\b|$)", RegexOption.IGNORE_CASE), " ")

        when (sourceName) {
            "FootyStats" -> {
                t = t.replace(Regex("\\b(?:Predictions|Prediction)\\b", RegexOption.IGNORE_CASE), " ")
                t = stripCompetitionPrefix(t)
            }
            "Statarea" -> {
                // Statarea kartlarında başta zaman/maç no gibi "2 0:0" parçaları görülebiliyor.
                t = t.replace(Regex("^\\s*\\d{1,3}\\s+\\d{1,2}:\\d{2}\\s+"), "")
                t = t.replace(Regex("\\b(?:Tips?|Prediction)\\b.*?(?=\\d\\s*[-:]\\s*\\d|$)", RegexOption.IGNORE_CASE), " ")
            }
            "FootballPredictions.net" -> {
                t = t.replace(Regex("\\b(?:Preview|Prediction|Predictions)\\b.*?(?=\\d\\s*[-:]\\s*\\d|$)", RegexOption.IGNORE_CASE), " ")
                t = stripCompetitionPrefix(t)
            }
            else -> {
                t = t.replace(Regex("\\b(?:Preview|Analysis|Prediction|Predictions|Predicted Score|Correct Score|Scoreline)\\b", RegexOption.IGNORE_CASE), " ")
            }
        }

        return t.replace(Regex("\\s+"), " ").trim(' ', '|', '→', '»', ':')
    }

    private fun stripCompetitionPrefix(text: String): String {
        var t = text.trim()
        val prefixes = listOf(
            "Premier Division", "First Division", "USL Championship", "England: Premier League",
            "England: Championship", "Bulgaria: First League", "Spain La Liga", "Spain: La Liga",
            "Spain Segunda Division", "Italy Serie A", "Portugal Primeira Liga", "Turkey: Super Lig",
            "Turkey: 1. Lig", "Turkey: 2. Lig", "Ireland Premier Division", "Ireland First Division"
        )
        var changed = true
        while (changed) {
            changed = false
            for (prefix in prefixes) {
                val re = Regex("^" + Regex.escape(prefix) + "\\s+", RegexOption.IGNORE_CASE)
                val next = t.replaceFirst(re, "")
                if (next != t) {
                    t = next.trim()
                    changed = true
                }
            }
        }
        return t
    }

    private fun findPredictionScore(raw: String, sourceName: String): String? {
        val normalized = raw.replace(Regex("\\s+"), " ").trim()
        val keywords = when (sourceName) {
            "FP.com" -> listOf("correct score", "score tip", "prediction")
            "FootballPredictions.net" -> listOf("correct score", "prediction", "predicted", "why this")
            "Forebet" -> listOf("correct score", "prediction", "pred")
            "PredictZ" -> listOf("correct score", "correct score odds", "prediction")
            "WinDrawWin" -> listOf("prediction", "correct score", "tips")
            "BettingTipsToday" -> listOf("correct score", "prediction", "predicted")
            "SoccerSeer" -> listOf("correct score", "prediction", "predicted")
            "MightyTips" -> listOf("score", "correct score", "prediction")
            "FootyStats" -> listOf("predicted scoreline", "predicted score", "prediction", "likely correct scoreline")
            "GoalVertex" -> listOf("correct score", "predicted score", "prediction")
            "NerdyTips" -> listOf("correct score", "prediction", "predicted")
            "Vitibet" -> listOf("score", "prediction", "tip")
            "HuhSports" -> listOf("prediction", "score", "predicted")
            "FootballAnt" -> listOf("correct score", "prediction", "predicted")
            "DailySports" -> listOf("correct score", "prediction", "predicted")
            "Statarea" -> listOf("prediction", "score", "tip")
            else -> listOf("correct score", "predicted score", "scoreline", "prediction")
        }

        // Önce etiketin hemen çevresindeki skoru ara. Böylece kart içindeki
        // eski sonuçları ve oranları yanlışlıkla tahmin diye seçmeyiz.
        for (keyword in keywords) {
            var from = 0
            while (from < normalized.length) {
                val idx = normalized.indexOf(keyword, from, ignoreCase = true)
                if (idx < 0) break
                val left = maxOf(0, idx - 70)
                val right = minOf(normalized.length, idx + keyword.length + 110)
                val window = normalized.substring(left, right)
                val m = scorePattern.matcher(window)
                var candidate: String? = null
                while (m.find()) candidate = "${m.group(1)}-${m.group(2)}"
                if (candidate != null) return candidate
                from = idx + keyword.length
            }
        }

        // Etiket yoksa, kartta en fazla iki skor varsa sonuncuyu aday al.
        // Tek skor bulunan kartlarda doğrudan kabul et.
        val all = ArrayList<String>()
        val m = scorePattern.matcher(normalized)
        while (m.find() && all.size < 8) all.add("${m.group(1)}-${m.group(2)}")
        if (all.size == 1) return all[0]
        if (all.size == 2) return all[1]

        // Takım ayırıcı + skor birlikte varsa, takım bilgisinden sonraki son skoru kullan.
        if (all.isNotEmpty() && Regex("(?i)(?:\\s+-\\s+|\\s+–\\s+|\\s+—\\s+|\\s+vs?\\.?\\s+)").containsMatchIn(normalized)) {
            return all.last()
        }
        return null
    }

    private fun extractTeams(raw: String, score: String): Pair<String, String>? {
        // Tahmin skorunun bulunduğu noktaya kadar olan bölüm, takım adlarının
        // bulunduğu en güvenilir alandır. Skordan sonraki "Why this", odds,
        // açıklama vb. metinleri takım adına dahil etmiyoruz.
        val scoreRegex = Regex("(?<!\\d)" + Regex.escape(score.replace("-", "[-:]")) + "(?!\\d)")
        var before = raw
        val m = scorePattern.matcher(raw)
        var lastStart = -1
        while (m.find()) {
            val found = "${m.group(1)}-${m.group(2)}"
            if (found == score) lastStart = m.start()
        }
        if (lastStart >= 0) before = raw.substring(0, lastStart)

        var t = before
            .replace(Regex("\\s+"), " ")
            .trim(' ', '|', '→', '»', ':', '?')

        // Tahmin/yorum etiketlerini ve parantez içi kısa açıklamaları çıkar.
        t = t.replace(Regex("(?i)\\b(?:why this|preview|analysis|prediction|predictions|predicted score|correct score|scoreline|tips?)\\b.*$"), "")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim()

        // Statarea gibi sayfalarda takım adlarından önce eski skor/maç no
        // bulunabiliyor: "3 1 5 - 2 De Mayo - Club Guarani".
        // Başlangıçtaki skor benzeri parçayı at, takım çiftini bırak.
        val leadingScoreNoise = Regex("^\\s*\\d{1,3}\\s+(?:[0-5]\\s*[-:]\\s*[0-5]\\s+)+")
        t = t.replaceFirst(leadingScoreNoise, "")
        t = t.replace(Regex("^\\s*\\d{1,3}\\s+(?=[A-Za-zÀ-ÿ])"), "")

        // Kaynakların lig/yarışma öneklerini takım adına dahil etme.
        t = stripCompetitionPrefix(t)

        // "ShelbournePredictions" gibi yapışmış etiketleri ayır.
        t = t.replace(Regex("(?i)([A-Za-zÀ-ÿ)])(?:Predictions|Prediction)$"), "$1")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', '–', '—', ':', ',', ';', '.')

        // Önce normal takım ayırıcılarını dene. Son tireli parça en güvenilir
        // ayrımdır; başlıkta ekstra tire varsa ilk makul çifti kullanıyoruz.
        val separators = listOf(
            Regex("\\s+(?:vs?\\.?|versus|v\\.)\\s+", RegexOption.IGNORE_CASE),
            Regex("\\s+[–—-]\\s+"),
            Regex("\\s+@\\s+"),
            Regex("\\s*↔\\s*")
        )
        var parts: List<String>? = null
        for (sep in separators) {
            val candidate = t.split(sep, limit = 2)
            if (candidate.size == 2 && candidate[0].trim().length >= 2 && candidate[1].trim().length >= 2) {
                parts = candidate
                break
            }
        }
        if (parts == null) return null

        val a = cleanTeam(parts!![0])
        val b = cleanTeam(parts!![1])
        if (a.length < 2 || b.length < 2) return null
        if (a.length > 55 || b.length > 55) return null
        if (looksLikeNoise(a) || looksLikeNoise(b)) return null
        if (a.equals(b, ignoreCase = true)) return null
        return Pair(a, b)
    }

    private fun cleanTeam(value: String): String {
        return value
            .replace(Regex("(?i)\\b(?:why this|today|tomorrow|preview|analysis|prediction|predicted|correct score|scoreline|odds|tips?)\\b.*$"), "")
            .replace(Regex("(?i)(predictions|prediction)$"), "")
            .replace(Regex("\\([^)]*\\)"), " ")
            .replace(Regex("^[\\s\\d:.-]+"), "")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', ',', ';', '.')
    }

    private fun looksLikeNoise(text: String): Boolean {
        val lower = text.lowercase()
        if (text.length < 4) return true
        val bad = listOf(
            "http", "www.", "sslhandshake", "trust anchor", "avg goals", "likely correct",
            "other likely", "second likely", "best leagues", "prediction odds", "correct score odds",
            "preview", "analysis", "over ", "under ", "model", "%", "predictions", "prediction"
        )
        return bad.any { lower.contains(it) }
    }

    private fun renderCleanResults(results: List<Result>) {
        resultBox.removeAllViews()
        val ordered = results.sortedByDescending { it.matches.size }

        if (ordered.isEmpty()) {
            statusText.text = "⚠️ Bu taramada kullanılabilir skor bulunamadı"
            resultBox.addView(row("Sonuç", "Bu taramada gösterilecek temiz skor bulunamadı."))
            return
        }

        val total = ordered.sumOf { it.matches.size }
        statusText.text = "✅ $total temiz skor • ${ordered.size} kaynak"

        val header = TextView(this).apply {
            text = "🎯 TEMİZ SKORLAR"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(4, 12, 4, 10)
        }
        resultBox.addView(header)

        ordered.forEachIndexed { index, result ->
            val sourceTitle = TextView(this).apply {
                text = "${index + 1}. ${result.name}"
                textSize = 17f
                setTextColor(Color.rgb(120, 240, 155))
                typeface = Typeface.DEFAULT_BOLD
                setPadding(4, 10, 4, 4)
            }
            resultBox.addView(sourceTitle)

            result.matches.forEach { match ->
                val tv = TextView(this).apply {
                    text = "⚽ $match"
                    textSize = 15f
                    setTextColor(Color.WHITE)
                    setPadding(8, 5, 8, 5)
                }
                resultBox.addView(tv)
            }
        }
    }

    private fun formatResult(r: Result): String {
        // Eski hata/HTTP görünümünü artık sonuç ekranında kullanmıyoruz.
        return r.matches.joinToString("\n")
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
