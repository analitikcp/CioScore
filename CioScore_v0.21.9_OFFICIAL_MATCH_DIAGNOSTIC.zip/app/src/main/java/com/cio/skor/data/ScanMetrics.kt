package com.cio.skor.data

import java.util.UUID

data class DropReason(
    val stage: PipelineStage,
    val reasonCode: String,
    val count: Int,
    val details: List<String> = emptyList()
)

enum class PipelineStage {
    HTTP, PARSER, NORMALIZATION, IDENTITY, CONFIDENCE, MERGE, IDDAA_ENRICHMENT, UI
}

data class ParserHealthReport(
    val sourceName: String,
    val httpCode: Int,
    val rawHtmlBytes: Int,
    val parsedCount: Int,
    val durationMs: Long,
    val status: ParserStatus,
    val errorMessage: String? = null
)

enum class ParserStatus { HEALTHY, DEGRADED, FAILED, DOM_CHANGED }

data class ScanTrace(
    val scanId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val timestamp: Long = System.currentTimeMillis(),
    val parserReports: List<ParserHealthReport>,
    val stageMetrics: Map<PipelineStage, Int>,
    val dropReasons: List<DropReason>,
    val totalDurationMs: Long
)
