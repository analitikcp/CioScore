package com.cio.skor.ui

import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.R
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

/** One polished card per unified match; data/filter logic is unchanged. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(initialList: List<MatchGroup> = emptyList()) : RecyclerView.Adapter<ScoreAdapter.VH>() {
    class VH(val card: CardView) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)
        displayedList = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        val card = CardView(context).apply {
            radius = dp(context, 16f)
            cardElevation = dp(context, 2f)
            setCardBackgroundColor(Color.WHITE)
            useCompatPadding = true
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, dp(context, 5f), 0, dp(context, 7f)) }
        }

        card.addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 16f), dp(context, 14f), dp(context, 16f), dp(context, 14f))
            tag = "content"
        })
        return VH(card)
    }

    override fun getItemCount() = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = displayedList[position]
        val content = holder.card.findViewWithTag<LinearLayout>("content")
        content.removeAllViews()
        val context = holder.card.context

        val teams = TextView(context).apply {
            text = "${match.homeTeam}\n${match.awayTeam}"
            setTextColor(context.getColor(R.color.cio_text))
            textSize = 18f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(0, 0, 0, dp(context, 10f))
        }
        content.addView(teams)

        val scoreCounts = match.predictions.groupingBy { it.predictedScore }.eachCount()
            .entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
        val consensus = scoreCounts.firstOrNull()

        if (consensus != null && match.predictions.size > 1) {
            val consensusBox = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp(context, 12f), dp(context, 8f), dp(context, 12f), dp(context, 8f))
                background = context.getDrawable(R.drawable.bg_consensus)
            }
            val label = TextView(context).apply {
                text = "🔥 KONSENSÜS"
                setTextColor(context.getColor(R.color.cio_fire))
                textSize = 12f
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            }
            val score = TextView(context).apply {
                text = "${consensus.key}  ${consensus.value}/${match.predictions.size}"
                setTextColor(context.getColor(R.color.cio_text))
                textSize = 20f
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = android.view.Gravity.CENTER
            }
            consensusBox.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            consensusBox.addView(score)
            content.addView(consensusBox)
            addSpace(content, context, 10)
        }

        val sourceTitle = TextView(context).apply {
            text = "KAYNAK TAHMİNLERİ"
            setTextColor(context.getColor(R.color.cio_muted))
            textSize = 11f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            letterSpacing = 0.08f
        }
        content.addView(sourceTitle)
        addSpace(content, context, 4)

        for ((index, prediction) in match.predictions.withIndex()) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, dp(context, 6f), 0, dp(context, 6f))
            }
            val source = TextView(context).apply {
                text = prediction.source
                setTextColor(context.getColor(R.color.cio_muted))
                textSize = 14f
            }
            val predicted = TextView(context).apply {
                text = prediction.predictedScore
                setTextColor(context.getColor(R.color.cio_text))
                textSize = 15f
                setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                gravity = android.view.Gravity.END
            }
            row.addView(source, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(predicted, LinearLayout.LayoutParams(dp(context, 55f), ViewGroup.LayoutParams.WRAP_CONTENT))
            content.addView(row)
            if (index < match.predictions.lastIndex) {
                val line = View(context).apply { setBackgroundColor(context.getColor(R.color.cio_line)) }
                content.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 1f)))
            }
        }
    }

    private fun addSpace(parent: LinearLayout, context: android.content.Context, dp: Int) {
        parent.addView(View(context), LinearLayout.LayoutParams(1, dp(context, dp.toFloat())))
    }

    private fun dp(context: android.content.Context, value: Float): Int =
        (value * context.resources.displayMetrics.density + 0.5f).toInt()
}
