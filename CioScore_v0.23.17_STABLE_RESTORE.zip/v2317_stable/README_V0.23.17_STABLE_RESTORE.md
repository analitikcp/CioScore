# CioScore v0.23.17 — STABLE RESTORE

Emergency stabilization after the v0.23.16 parser-isolation refactor caused the scan UI to remain stuck.

- Base application core restored from the known-working v0.23.7 source tree.
- v0.23.15 Iddaa/HTFT market parsing repair ported without changing the main scan pipeline.
- Artificial parser truncation limits removed: FP.com 50, PredictZ 50, WinDrawWin 50, SoccerSeer 100, DailySports 300.
- No generic DOM-wide fallback engine is introduced in this stabilization build.
- No MainActivity/SofaScore/HTTP architecture rewrite is introduced.

Goal: restore reliable scanning first, then add source-specific fallbacks one parser at a time with diagnostics.
