package com.cio.skor

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.cio.skor.data.IddaaMarketService
import com.cio.skor.data.MatchMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HtFtOpenedMatchesActivity : Activity() {
    companion object {
        const val EXTRA_HOME_TEAM = "extra_home_team"
        const val EXTRA_AWAY_TEAM = "extra_away_team"
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = IddaaMarketService()
    private lateinit var content: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var titleText: TextView
    private var matches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF6F8FB.toInt())
            setPadding(dp(14), dp(8), dp(14), 0)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top + dp(8), view.paddingRight, view.paddingBottom)
            insets
        }

        // Tek başlık: maç sayısı doğrudan başlığın yanında.
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }
        titleText = TextView(this).apply {
            text = "⚡ HT/FT Açılan Maçlar (0)"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        titleRow.addView(titleText)
        titleRow.addView(Button(this).apply {
            text = "KAPAT"
            setOnClickListener { finish() }
        })
        root.addView(titleRow)

        progress = ProgressBar(this).apply { visibility = View.VISIBLE }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(28)))
        status = TextView(this).apply {
            text = "İddaa resmi oranları taranıyor…"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFF475569.toInt())
            setPadding(0, 0, 0, dp(4))
        }
        root.addView(status)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply {
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        load()
    }

    private fun load() {
        scope.launch {
            val result = withContext(Dispatchers.IO) { service.fetchOpenedMarkets() }
            progress.visibility = View.GONE
            val opened = result.matches.filter { it.hasHtFt }
            val targetHome = intent.getStringExtra(EXTRA_HOME_TEAM)
            val targetAway = intent.getStringExtra(EXTRA_AWAY_TEAM)
            matches = if (!targetHome.isNullOrBlank() && !targetAway.isNullOrBlank()) {
                opened.filter {
                    MatchMerger.isSameTeam(it.homeTeam, targetHome) &&
                        MatchMerger.isSameTeam(it.awayTeam, targetAway)
                }
            } else {
                opened
            }

            status.text = if (matches.isEmpty()) {
                result.error ?: "Bugün İddaa resmi oranlarında HT/FT marketi açık maç bulunamadı."
            } else {
                "Kaynak=İddaa resmi"
            }
            titleText.text = if (matches.isEmpty()) {
                "⚡ HT/FT Açılan Maçlar"
            } else {
                "⚡ HT/FT Açılan Maçlar (${matches.size})"
            }
            renderList()
        }
    }

    private fun renderList() {
        content.removeAllViews()

        if (matches.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Bugün HT/FT oranı açık maç bulunamadı."
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(0xFF64748B.toInt())
                setPadding(0, dp(30), 0, dp(30))
            })
            return
        }

        matches.sortedWith(
            compareBy<IddaaMarketService.OpenedMarketMatch> {
                if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE
            }.thenBy { MatchMerger.normalizeTeamName(it.homeTeam) }
        ).forEach { addMatchRow(it) }
    }

    private fun addMatchRow(match: IddaaMarketService.OpenedMarketMatch) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
            elevation = dp(2).toFloat()
        }

        row.addView(TextView(this).apply {
            text = if (match.matchTime != "--:--") "🕐 ${match.matchTime}" else "🕐 --:--"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            setPadding(0, 0, 0, dp(4))
        })

        row.addView(TextView(this).apply {
            text = "${match.homeTeam}  VS  ${match.awayTeam}"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF0F172A.toInt())
        })

        row.addView(TextView(this).apply {
            text = "MS  1: ${match.ms1 ?: "-"}   •   X: ${match.msX ?: "-"}   •   2: ${match.ms2 ?: "-"}"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF334155.toInt())
            setPadding(0, dp(7), 0, 0)
        })

        val ordered = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
        val available = ordered.mapNotNull { key -> match.htFtOdds[key]?.let { key to it } }
        if (available.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = available.chunked(3).joinToString("\n") { line ->
                    line.joinToString("     ") { "${it.first}: ${it.second}" }
                }
                textSize = 11f
                setTextColor(0xFF00796B.toInt())
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(8), 0, 0)
            })
        }

        // İki seçenek kartın içinde DAİMA görünür. Kullanıcının karta tekrar
        // dokunmasına gerek yok; bu özellikle görünürlük sorununu ortadan kaldırır.
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }

        val cioButton = Button(this).apply {
            text = "CioScore"
            textSize = 14f
            isAllCaps = false
            setOnClickListener { openScoreAnalysis(match) }
        }

        val iddaaButton = Button(this).apply {
            text = "İddaa"
            textSize = 14f
            isAllCaps = false
            setOnClickListener { openIddaa(match) }
        }

        actions.addView(cioButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            marginEnd = dp(5)
        })
        actions.addView(iddaaButton, LinearLayout.LayoutParams(0, dp(50), 1f).apply {
            marginStart = dp(5)
        })
        row.addView(actions, LinearLayout.LayoutParams(-1, -2))

        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(7)
        })
    }

    private fun openScoreAnalysis(match: IddaaMarketService.OpenedMarketMatch) {
        // Return the selected fixture to the existing MainActivity instance.
        // MainActivity already knows how to focus the exact match in the analysis list.
        setResult(RESULT_OK, Intent().apply {
            putExtra(MainActivity.TARGET_MATCH_QUERY, match.homeTeam)
            putExtra(MainActivity.EXTRA_TARGET_HOME, match.homeTeam)
            putExtra(MainActivity.EXTRA_TARGET_AWAY, match.awayTeam)
            putExtra(MainActivity.EXTRA_TARGET_TIMESTAMP, match.matchTimestamp)
        })
        finish()
    }

    private fun openIddaa(match: IddaaMarketService.OpenedMarketMatch) {
        // The official feed exposes the event id, but iddaa does not document a
        // stable public per-match deep-link format. We therefore send the official
        // program URL with today's exact date and event id as context. Android will
        // hand the https URL to the installed iddaa app when it has an App Link;
        // otherwise the browser opens iddaa.com.
        val date = match.matchDate.takeIf { it.matches(Regex("\\d{2}\\.\\d{2}\\.\\d{4}")) }
            ?: java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale("tr", "TR"))
                .format(java.util.Date())
        val url = "https://www.iddaa.com/program/futbol?date=${Uri.encode(date)}&eventId=${Uri.encode(match.matchId)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            startActivity(intent)
        } catch (_: Exception) {
            // Extremely defensive fallback: open the official app package if it is installed.
            val appIntent = packageManager.getLaunchIntentForPackage("com.iddaa.app")
            if (appIntent != null) {
                startActivity(appIntent)
            } else {
                Toast.makeText(this, "İddaa.com açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
