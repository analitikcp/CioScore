package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Official Iddaa sportsbook feed.
 *
 * Source: official Iddaa backend used by https://www.iddaa.com/program/futbol?msg=68
 * The official events feed returns event-level markets in JSON; market-config
 * maps (t, st) to official market metadata. HT/FT is identified from the
 * 9 official outcome labels and normalized to 1/1..2/2. No third-party odds
 * source is used.
 */
class IddaaMarketService {
    data class OpenedMarketMatch(
        val matchId: String,
        val homeTeam: String,
        val awayTeam: String,
        val matchTime: String,
        val ms1: String? = null,
        val msX: String? = null,
        val ms2: String? = null,
        val hasHtFt: Boolean = false,
        val hasCorrectScore: Boolean = false,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
        val correctScoreOdds: LinkedHashMap<String, String> = linkedMapOf()
    ) {
        val hasMatchResult: Boolean get() = ms1 != null || msX != null || ms2 != null
    }

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val marketMatches: Int,
        val httpEvents: Int,
        val httpMarketConfig: Int,
        val error: String? = null
    )

    private data class MarketConfig(val name: String)

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private companion object {
        const val BASE = "https://sportsbookv2.iddaa.com/sportsbook"
        const val EVENTS = "$BASE/events?st=1&type=0&version=0" // official iddaa.com backend
        const val CONFIG = "$BASE/get_market_config"
        val REQUIRED_HTFT = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
    }

    /** Same official feed used by both the main screen and Opened Markets. */
    suspend fun fetchOpenedMarkets(): Result = fetchToday()

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(30_000L) {
            try {
                val eventsResponse = get(EVENTS)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, -1, 0, "İddaa events HTTP hatası")
                val configResponse = get(CONFIG)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, eventsResponse.code, -1, "İddaa market config HTTP hatası")

                val configs = parseMarketConfig(configResponse)
                val parsed = parseEvents(eventsResponse, configs)
                val today = LocalDate.now(ZoneId.systemDefault())
                val todayMatches = parsed.filter {
                    runCatching {
                        Instant.ofEpochSecond(it.first)
                            .atZone(ZoneId.systemDefault()).toLocalDate() == today
                    }.getOrDefault(true)
                }.map { it.second }

                val marketMatches = todayMatches.count { it.hasHtFt || it.hasCorrectScore }
                Result(
                    matches = todayMatches,
                    scanned = todayMatches.size,
                    marketMatches = marketMatches,
                    httpEvents = eventsResponse.code,
                    httpMarketConfig = configResponse.code
                )
            } catch (e: Exception) {
                Result(emptyList(), 0, 0, -1, -1, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, 0, -1, -1, "İddaa resmi veri taraması zaman aşımına uğradı")
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun get(url: String): HttpResult? = runCatching {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json, text/plain, */*")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Origin", "https://www.iddaa.com")
            .header("Referer", "https://www.iddaa.com/")
            .build()
        client.newCall(request).execute().use { response ->
            HttpResult(response.code, response.body?.string().orEmpty())
        }
    }.getOrNull()

    private fun parseMarketConfig(response: HttpResult): Map<String, MarketConfig> {
        val root = JSONObject(response.body)
        val data = root.optJSONObject("data") ?: return emptyMap()
        val markets = data.optJSONObject("m") ?: return emptyMap()
        val out = HashMap<String, MarketConfig>()
        val keys = markets.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = markets.optJSONObject(key) ?: continue
            out[key] = MarketConfig(item.optString("n", "Unknown Market"))
        }
        return out
    }

    private fun parseEvents(
        response: HttpResult,
        configs: Map<String, MarketConfig>
    ): List<Pair<Long, OpenedMarketMatch>> {
        val root = JSONObject(response.body)
        val events = root.optJSONObject("data")?.optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Pair<Long, OpenedMarketMatch>>(events.length())

        for (index in 0 until events.length()) {
            val event = events.optJSONObject(index) ?: continue
            val id = event.optString("i", "")
            val home = event.optString("hn", "").trim()
            val away = event.optString("an", "").trim()
            if (id.isBlank() || home.isBlank() || away.isBlank()) continue

            val timestamp = event.optLong("d", 0L)
            val matchTime = if (timestamp > 0) {
                Instant.ofEpochSecond(timestamp).atZone(ZoneId.systemDefault()).toLocalTime().toString().take(5)
            } else "--:--"

            var ms1: String? = null
            var msX: String? = null
            var ms2: String? = null
            val htFt = linkedMapOf<String, String>()
            val correctScore = linkedMapOf<String, String>()
            val markets = event.optJSONArray("m") ?: continue

            for (mIndex in 0 until markets.length()) {
                val market = markets.optJSONObject(mIndex) ?: continue
                val t = market.optInt("t", -1)
                val st = market.optInt("st", -1)
                val configName = normalize(configs["${t}_${st}"]?.name.orEmpty())
                val outcomes = readOutcomes(market.opt("o"))
                if (outcomes.isEmpty()) continue

                // IMPORTANT: do not depend on the market-config name. The official
                // feed's outcome labels are the most stable source of truth.
                val htCandidate = linkedMapOf<String, String>()
                val scoreCandidate = linkedMapOf<String, String>()
                var one = false
                var draw = false
                var two = false

                for (outcome in outcomes) {
                    val rawLabel = outcome.first
                    val odd = outcome.second ?: continue
                    if (odd <= 1.0) continue

                    normalizeHtFt(rawLabel)?.let { htCandidate[it] = formatOdd(odd) }
                    normalizeScore(rawLabel)?.let { scoreCandidate[it] = formatOdd(odd) }

                    when (normalizeOutcome(rawLabel)) {
                        "1" -> one = true
                        "x" -> draw = true
                        "2" -> two = true
                    }
                }

                // A full 9-cell 1/1..2/2 grid is unambiguous HT/FT.
                if (REQUIRED_HTFT.all { htCandidate.containsKey(it) }) {
                    REQUIRED_HTFT.forEach { htFt[it] = htCandidate.getValue(it) }
                    continue
                }

                // Also accept a clearly-labelled HT/FT market when the provider
                // temporarily omits one or more cells. The filter will still show
                // the available official cells rather than dropping the match.
                if (isHtFt(configName) || htCandidate.isNotEmpty()) {
                    htCandidate.forEach { (k, v) -> htFt[k] = v }
                    if (htFt.isNotEmpty()) continue
                }

                if (isCorrectScore(configName) || scoreCandidate.isNotEmpty()) {
                    scoreCandidate.forEach { (k, v) -> correctScore[k] = v }
                    continue
                }

                // MS is identified only by the exact 1/X/2 outcome signature or
                // by the official market-config name. This avoids confusing other
                // 3-way markets with Match Result.
                if (isMatchResult(configName) || (one && draw && two)) {
                    for (outcome in outcomes) {
                        val odd = outcome.second ?: continue
                        if (odd <= 1.0) continue
                        when (normalizeOutcome(outcome.first)) {
                            "1" -> ms1 = formatOdd(odd)
                            "x" -> msX = formatOdd(odd)
                            "2" -> ms2 = formatOdd(odd)
                        }
                    }
                }
            }

            if (ms1 != null || msX != null || ms2 != null || htFt.isNotEmpty() || correctScore.isNotEmpty()) {
                out += timestamp to OpenedMarketMatch(
                    matchId = id,
                    homeTeam = home,
                    awayTeam = away,
                    matchTime = matchTime,
                    ms1 = ms1,
                    msX = msX,
                    ms2 = ms2,
                    hasHtFt = htFt.isNotEmpty(),
                    hasCorrectScore = correctScore.isNotEmpty(),
                    htFtOdds = htFt,
                    correctScoreOdds = correctScore
                )
            }
        }
        return out
    }

    private fun readOutcomes(raw: Any?): List<Pair<String, Double?>> {
        val result = ArrayList<Pair<String, Double?>>()
        when (raw) {
            is org.json.JSONArray -> {
                for (i in 0 until raw.length()) {
                    val o = raw.optJSONObject(i) ?: continue
                    result += o.optString("n", "") to readOdd(o.opt("odd"))
                }
            }
            is org.json.JSONObject -> {
                val keys = raw.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = raw.opt(key)
                    if (value is org.json.JSONObject) {
                        result += (value.optString("n", key)) to readOdd(value.opt("odd"))
                    } else {
                        result += key to readOdd(value)
                    }
                }
            }
        }
        return result
    }

    private fun readOdd(raw: Any?): Double? = when (raw) {
        is Number -> raw.toDouble()
        is String -> raw.replace(',', '.').toDoubleOrNull()
        else -> null
    }

    private fun isMatchResult(name: String): Boolean =
        name == "mac sonucu" || name == "match result"

    private fun isHtFt(name: String): Boolean =
        name.contains("ilk yari / mac sonucu") ||
            name.contains("ilk yari/mac sonucu") ||
            name.contains("ilk yari mac sonucu") ||
            name.contains("first half / match result") ||
            name.contains("half time / full time")

    private fun isCorrectScore(name: String): Boolean =
        name.contains("dogru skor") || name.contains("correct score") || name.contains("mac skoru")

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('&', ' ')
        v = Normalizer.normalize(v, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        v = v.replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ç', 'c').replace('ö', 'o').replace('ü', 'u')
        return v.replace(Regex("\\s+"), " ").trim()
    }

    private fun normalizeOutcome(value: String): String =
        value.trim().lowercase(Locale.ROOT)
            .replace("0", "x")
            .replace("beraberlik", "x")
            .replace("draw", "x")

    private fun normalizeHtFt(value: String): String? {
        val v = value.trim().uppercase(Locale.ROOT)
            .replace("0", "X")
            .replace('-', '/')
            .replace(" ", "")
        return if (v.matches(Regex("^[1X2]/[1X2]$"))) v else null
    }

    private fun normalizeScore(value: String): String? {
        val v = value.trim().replace(':', '-').replace(" ", "")
        return if (v.matches(Regex("^\\d{1,2}-\\d{1,2}$"))) v else null
    }

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    fun findForTeamPair(
        matches: List<OpenedMarketMatch>,
        homeTeam: String,
        awayTeam: String
    ): OpenedMarketMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) && MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
