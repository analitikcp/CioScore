package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchSessionStore
import com.cio.skor.data.ScoreModel
import com.cio.skor.ui.ScoreAdapter

/**
 * Dedicated MS X candidate screen.
 *
 * A fixture is an X candidate when at least one currently renderable prediction
 * has equal home/away goals (e.g. 0-0, 1-1, 2-2). The main fixture grouping and
 * official İddaa enrichment are reused; this screen is only a filtered view.
 */
class XCandidateActivity : Activity() {
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val back = Button(this).apply {
            text = "‹ Geri"
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(92), dp(44)))

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        titleBox.addView(TextView(this).apply {
            text = "MS X ADAYLARI"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF101828.toInt())
        })
        titleBox.addView(TextView(this).apply {
            text = "Beraberlik skoru üreten maçlar"
            textSize = 12f
            setTextColor(0xFF475569.toInt())
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(header)

        val xGroups = MatchSessionStore.latestGroups
            .filter { match ->
                match.predictions.any { prediction -> isXPrediction(prediction.predictedScore) }
            }
            .sortedBy { it.matchTimestamp.takeIf { ts -> ts > 0L } ?: Long.MAX_VALUE }

        root.addView(TextView(this).apply {
            text = "${xGroups.size} X adayı maç"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        })

        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@XCandidateActivity)
            setHasFixedSize(false)
            itemAnimator = null
            setItemViewCacheSize(4)
        }

        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { _, _ -> },
            onHtFtClick = { _, _ -> },
            onExternalOddsRequest = { _, _ -> },
            onOddsClick = { }
        )
        recycler.adapter = adapter
        adapter.submitList(xGroups)
        root.addView(recycler, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        if (xGroups.isEmpty()) {
            recycler.visibility = View.GONE
            root.addView(TextView(this).apply {
                text = "Bu taramada MS X adayı bulunamadı.\n\nÖrnek X skorları: 0-0, 1-1, 2-2."
                textSize = 15f
                setTextColor(0xFF475569.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(32), dp(24), dp(32))
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            ))
        }

        setContentView(root)
    }

    private fun isXPrediction(score: String): Boolean {
        if (!ScoreModel.hasRenderablePrediction(score)) return false
        val parts = score.trim().replace(':', '-').split('-')
        if (parts.size != 2) return false
        return parts[0].trim().toIntOrNull() == parts[1].trim().toIntOrNull()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
