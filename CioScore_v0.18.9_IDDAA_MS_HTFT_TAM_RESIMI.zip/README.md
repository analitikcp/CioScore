# CioScore v0.18.5

## HT/FT-only architecture
- Ana ekranda yalnızca **⚡ HT/FT AÇILAN MAÇLAR** butonu bulunur.
- Eski Açılan Marketler / Doğru Skor filtreleri kaldırılmıştır.
- HT/FT oranlarının tek bahis oranı kaynağı resmi **İddaa** veri akışıdır.
- HT/FT 9'lu grid: `1/1, 1/X, 1/2, X/1, X/X, X/2, 2/1, 2/X, 2/2`.
- `1-0`, `1/0`, `0/1` gibi sonuç etiketleri `1/X`, `X/1` vb. standarda normalize edilir.
- HT/FT marketi açık olmayan maçlar HT/FT ekranında gösterilmez.
