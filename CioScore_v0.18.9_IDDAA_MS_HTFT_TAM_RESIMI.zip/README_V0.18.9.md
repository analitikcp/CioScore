# CioScore v0.18.9

- MS1 / MSX / MS2 oranları artık MatchGroup içinde doğrudan resmi İddaa alanları olarak tutulur.
- Ana kartta oranlar SofaScore odds nesnesinden değil, `IddaaMarketService` içindeki resmi İddaa 1X2 verisinden beslenir.
- HT/FT oranları ve MS1/MSX/MS2 aynı first-party İddaa program beslemesinden alınır.
- Harici oran sağlayıcısı/fallback yoktur.
- Resmi program referansı `https://www.iddaa.com/program/futbol` olarak sabitlenmiştir.
- CioScore 0-100 puanı ve doğru skor arayüzü kullanılmaz.
- Ana kartta yalnızca `TAHMİN: MS 1 / MS X / MS 2` gösterilir.
- HT/FT açılan maçlar ekranı resmi İddaa HT/FT marketlerinden beslenir ve saate göre sıralanır.
