package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * AiScore schedule reader. It consumes the public server-rendered schedule
 * page only; it does not try to bypass JS challenges or access controls.
 */
class AiScoreRepository {
    private val http = HttpClient()

    suspend fun fetchToday(officialFixtures: List<OfficialFixtureLite> = emptyList()): List<AiScoreMatch> =
        withContext(Dispatchers.IO) {
            val urls = listOf(
                "https://www.aiscore.com/today-matches/football",
                "https://www.aiscore.com/en/today-matches/football",
                "https://m.aiscore.com/en/"
            )
            var lastCode = -1
            for (url in urls) {
                val (code, body) = http.getSource(url, "https://www.aiscore.com/")
                lastCode = code
                if (code !in 200..299 || body.isNullOrBlank()) continue
                val parsed = parse(body, officialFixtures)
                if (parsed.isNotEmpty()) return@withContext parsed
            }
            Log.d(TAG, "AiScore schedule unavailable code=$lastCode")
            emptyList()
        }

    data class OfficialFixtureLite(val homeTeam: String, val awayTeam: String)

    private fun parse(html: String, official: List<OfficialFixtureLite>): List<AiScoreMatch> {
        val doc = Jsoup.parse(html)
        val links = doc.select("a[href*='/live/football-']")
        val out = LinkedHashMap<String, AiScoreMatch>()

        for (link in links) {
            val href = link.absUrl("href").ifBlank { link.attr("href") }
            val pair = parseSlugPair(href) ?: continue
            val container = nearestMatchContainer(link)
            val text = container?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
            val linkText = link.text().replace(Regex("\\s+"), " ").trim()
            val teamNames = extractTeamNames(container, pair.first, pair.second, linkText)
            val home = teamNames.first
            val away = teamNames.second
            if (home.isBlank() || away.isBlank()) continue

            val time = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b").find(text)?.value ?: "--:--"
            val status = when {
                Regex("\\bFT\\b|Finished", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "FINISHED"
                Regex("\\bVS\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "SCHEDULED"
                else -> "SCHEDULED"
            }
            val score = Regex("\\b(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b").find(text)
            val hs = score?.groupValues?.getOrNull(1)?.toIntOrNull()
            val ascore = score?.groupValues?.getOrNull(2)?.toIntOrNull()
            val league = inferLeague(link, container)
            val id = href.substringAfterLast('/').substringBefore('?').ifBlank { "${TeamAliasCanonicalizer.canonical(home)}|${TeamAliasCanonicalizer.canonical(away)}|$time" }
            val odds = extractOneXTwoOdds(text, home, away)
            val matched = official.any {
                TeamAliasCanonicalizer.canonical(it.homeTeam) == TeamAliasCanonicalizer.canonical(home) &&
                    TeamAliasCanonicalizer.canonical(it.awayTeam) == TeamAliasCanonicalizer.canonical(away)
            }
            out[id] = AiScoreMatch(
                matchId = id,
                leagueName = league,
                homeTeam = home,
                awayTeam = away,
                matchTime = time,
                status = status,
                homeScore = hs,
                awayScore = ascore,
                matchUrl = href,
                iddaaMatched = matched,
                aiScoreMs1 = odds?.getOrNull(0),
                aiScoreMsX = odds?.getOrNull(1),
                aiScoreMs2 = odds?.getOrNull(2)
            )
        }

        return out.values.sortedWith(compareBy<AiScoreMatch> { leagueSortKey(it.leagueName) }.thenBy { timeSortKey(it.matchTime) })
    }

    private fun nearestMatchContainer(element: org.jsoup.nodes.Element): org.jsoup.nodes.Element? {
        var current: org.jsoup.nodes.Element? = element
        repeat(6) {
            val c = current ?: return null
            val cls = c.className().lowercase(Locale.ROOT)
            if (cls.contains("match") || cls.contains("event") || cls.contains("game")) return c
            current = c.parent()
        }
        return element.parent()
    }

    private fun extractTeamNames(container: org.jsoup.nodes.Element?, slugHome: String, slugAway: String, linkText: String): Pair<String, String> {
        val candidates = container?.select("a,span,div,p")?.map { it.text().trim() }
            ?.filter { it.length in 2..80 }
            ?.distinct()
            .orEmpty()
        val useful = candidates.filterNot {
            it.matches(Regex("[01]?\\d:[0-5]\\d")) ||
                it.matches(Regex("\\d+\\s*[-:]\\s*\\d+")) ||
                it.equals("H2H", true) || it.equals("Live", true) || it.equals("VS", true)
        }
        if (useful.size >= 2) return useful.takeLast(2).let { it[0] to it[1] }
        val linkParts = linkText.split(Regex("\\s+vs\\s+|\\s+VS\\s+"), limit = 2)
        if (linkParts.size == 2) return linkParts[0].trim() to linkParts[1].trim()
        return prettySlug(slugHome) to prettySlug(slugAway)
    }

    private fun extractOneXTwoOdds(text: String, home: String, away: String): List<String>? {
        if (home.isBlank() || away.isBlank()) return null
        // AiScore's scheduled-match cards expose the 1X2 prices beside the
        // fixture. Restrict extraction to decimal odds so scores/times are not
        // mistaken for prices, then use the final complete triple in the card.
        val numbers = Regex("\\b([1-9][0-9]?\\.[0-9]{1,2})\\b")
            .findAll(text)
            .map { it.groupValues[1] }
            .filter { value ->
                val n = value.toDoubleOrNull() ?: return@filter false
                n > 1.0 && n <= 50.0
            }
            .toList()
        return if (numbers.size >= 3) numbers.takeLast(3) else null
    }

    private fun inferLeague(link: org.jsoup.nodes.Element, container: org.jsoup.nodes.Element?): String {
        var current = container?.previousElementSibling()
        repeat(8) {
            val text = current?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
            if (text.contains(":") && text.length <= 100 && !text.contains("http", true)) return text
            current = current?.previousElementSibling()
        }
        return "AiScore"
    }

    private fun parseSlugPair(href: String): Pair<String, String>? {
        val slug = href.substringAfter("/live/football-", "").substringBefore('?').trim('/')
        if (slug.isBlank()) return null
        val marker = "-vs-"
        val index = slug.indexOf(marker)
        if (index <= 0) return null
        val h = slug.substring(0, index)
        val a = slug.substring(index + marker.length)
        if (h.isBlank() || a.isBlank()) return null
        return h to a
    }

    private fun prettySlug(slug: String): String = slug.replace('-', ' ').split(' ').joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }

    private fun leagueSortKey(value: String): String = value.lowercase(Locale.ROOT)
    private fun timeSortKey(value: String): Int = value.split(':').let { if (it.size == 2) (it[0].toIntOrNull() ?: 99) * 60 + (it[1].toIntOrNull() ?: 99) else Int.MAX_VALUE }

    companion object { private const val TAG = "CioScoreAiScoreList" }
}
