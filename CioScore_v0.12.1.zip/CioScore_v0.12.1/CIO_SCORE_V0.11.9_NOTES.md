# CioScore v0.11.9

- Added explainable CioScore 0-100 rating using the five prediction sources and Mackolik 1X2 odds.
- Added confidence label and strongest outcome on every match card.
- Added positive Value indicator when the source-derived outcome probability implies positive expected value against Mackolik odds.
- Added `🔥 EN GÜÇLÜ MAÇLAR` filter; shows matches with CioScore >= 65 sorted highest first.
- Existing Mackolik parser and working odds integration are unchanged.
- Existing CP/CioScore launcher logo is unchanged.
- Version code: 119.
