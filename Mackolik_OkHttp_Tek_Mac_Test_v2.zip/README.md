Mackolik OkHttp Test v2

Sadece Android + OkHttp ile Maçkolik program sayfasına erişimi test eder.
CioScore projesinden bağımsızdır.
