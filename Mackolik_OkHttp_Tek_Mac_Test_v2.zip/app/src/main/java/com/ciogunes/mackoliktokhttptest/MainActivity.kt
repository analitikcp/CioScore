package com.ciogunes.mackoliktokhttptest

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        Thread { testMackolik() }.start()
    }

    private fun testMackolik() {
        val client = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .build()

        try {
            val request = Request.Builder()
                .url("https://arsiv.mackolik.com/Program/Program.aspx")
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val cagliari = body.contains("Cagliari", true)
                val lecce = body.contains("Lecce", true)
                val odds = Regex("""\b\d+\.\d{2}\b""").findAll(body).count()

                val message = buildString {
                    appendLine("HTTP: ${response.code}")
                    appendLine("Body: ${body.length} karakter")
                    appendLine("Cagliari: ${if (cagliari) "VAR" else "YOK"}")
                    appendLine("Lecce: ${if (lecce) "VAR" else "YOK"}")
                    appendLine("Oran biçimi bulunan sayı: $odds")
                    appendLine()
                    appendLine(if (response.isSuccessful && body.isNotBlank())
                        "SONUÇ: Android OkHttp cevap aldı."
                    else "SONUÇ: Android OkHttp veri alamadı.")
                    appendLine()
                    appendLine("İlk 2000 karakter:")
                    append(body.take(2000))
                }

                runOnUiThread {
                    status.text = "TEST TAMAMLANDI"
                    result.text = message
                }
            }
        } catch (e: Exception) {
            runOnUiThread {
                status.text = "TEST HATASI"
                result.text = "${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }
}
