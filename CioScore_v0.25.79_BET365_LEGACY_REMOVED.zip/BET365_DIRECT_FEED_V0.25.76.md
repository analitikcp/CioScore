# CioScore v0.25.76 — Bet365 Direct Feed

- Added an isolated `Bet365DirectFeedService` backed by OddsPapi.
- Resolves soccer fixtures once for the bulletin window, then requests only `bookmakerOdds.bet365`.
- Uses soccer Full Time Result market `101` and outcomes `101/102/103` for 1/X/2.
- A quote is accepted only when the real `bet365` bookmaker node contains a complete active 1X2 triple.
- Direct Feed is independent of bwin and the legacy Bet365 Motor v2.
- Existing Bet365 Motor v2 remains a fallback; its result cannot overwrite a validated Direct Feed hit.
- RecyclerView/onBind does not start odds requests.
- Added separate OddsPapi API-key storage and diagnostics.

## Configuration

Open the existing API settings and enter an OddsPapi API key for the Direct Feed. The key is stored locally in Android SharedPreferences. No key is embedded in source.

OddsPapi documentation: https://oddspapi.io/en/docs
