# CioScore v0.25.77 — Bet365 Direct Feed operational fix

- Bet365 Direct Feed now uses the existing Odds Data API token and the direct Bet365 FI endpoint.
- No second OddsPapi credential is required.
- Direct Feed resolves the bulletin fixture via the existing provider fixture list and calls `/v4/bet365/prematch`.
- Only a complete, validated Bet365 1X2 triple is accepted.
- Direct Feed publishes through an authoritative Bet365 setter, replacing any earlier fallback Bet365 row without touching bwin.
- Legacy Bet365 Motor V2 remains active as fallback and continues to run in parallel.
- RecyclerView scrolling does not trigger odds requests.
