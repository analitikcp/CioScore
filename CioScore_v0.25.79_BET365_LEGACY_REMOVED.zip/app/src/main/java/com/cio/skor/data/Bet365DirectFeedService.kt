package com.cio.skor.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Isolated Bet365 Direct Feed layer.
 *
 * This layer deliberately bypasses the legacy multi-source Bet365 motor.
 * It uses the existing Odds Data API credential and calls the provider's
 * Bet365 FI endpoint directly. Only a validated Bet365 1X2 triple is returned.
 * No other bookmaker is relabeled as Bet365.
 */
class Bet365DirectFeedService(context: Context) {
    companion object {
        private const val TAG = "CioBet365DirectFeed"
    }

    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: String = "DIRECT_FEED",
        val reason: String = ""
    )

    private val api = OddsDataApiService(context)

    fun getApiKey(): String = api.getToken()

    fun setApiKey(value: String) = api.setToken(value)

    fun clearApiKey() = api.clearToken()

    suspend fun resolve(
        homeTeam: String,
        awayTeam: String,
        kickoffEpochSec: Long,
        fixtures: List<OddsDataApiService.ProviderFixture>
    ): Result = withContext(Dispatchers.IO) {
        val token = api.getToken()
        if (token.isBlank()) {
            return@withContext Result(reason = "Odds Data API token ayarlanmadı")
        }

        val fixture = api.matchFixture(homeTeam, awayTeam, kickoffEpochSec, fixtures)
            ?: return@withContext Result(reason = "Bet365 FI fixture eşleşmedi")

        val direct = api.fetchBet365Prematch(fixture)
        val line = direct.value
            ?: return@withContext Result(reason = direct.error ?: "Bet365 Direct Feed yanıtı boş")

        if (!valid(line.home) || !valid(line.draw) || !valid(line.away)) {
            return@withContext Result(reason = "Bet365 Direct Feed 1X2 eksik/geçersiz")
        }

        Log.d(TAG, "DIRECT HIT ${fixture.homeTeam} - ${fixture.awayTeam} FI=${fixture.bet365FixtureId}: ${line.home}/${line.draw}/${line.away}")
        Result(
            odds = SofaScoreService.BookmakerOdds("Bet365", line.home, line.draw, line.away),
            reason = "Odds Data API • Bet365 FI direct 1X2"
        )
    }

    private fun valid(value: String?): Boolean =
        value?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true
}
