# Matcher v0.25.12 — Context Match V2

## Problem addressed

Prediction providers can describe the same fixture with different languages,
abbreviations, transliterations and club-name conventions. The previous identity
graph also required a new prediction record to be pairwise-compatible with every
record already attached to an official fixture. That incorrectly prevented multiple
providers from joining the same Iddaa card when each provider independently matched
the official fixture.

## Matching policy

1. **Official Iddaa is the fixture anchor.**
2. Date and kickoff are used as hard event context when both are available.
3. Competition/league and country are normalized independently; common Turkish/English
   labels are treated as equivalent.
4. Team names pass through `TeamAliasCanonicalizer` before similarity scoring.
5. Official-anchor matching accepts strong two-sided fuzzy identity when the official
   schedule context is aligned.
6. If date + kickoff + league + country all agree, a meaningful two-sided team
   similarity is sufficient even when the provider names are translated.
7. **Each prediction source may attach independently to the same official fixture.**
   Prediction-vs-prediction compatibility is not required once the Iddaa anchor has
   been established.
8. Different official fixture IDs cannot be bridged by this rule.
9. Non-official prediction-to-prediction clustering retains the stricter component
   safety rule to avoid transitive false merges.

## Metadata improvements

All four prediction parsers now attempt to capture date, kickoff time, competition
and country from the smallest available match card/block. If a provider omits the
date, `ScraperRepository` supplies the current Istanbul bulletin date for its
`today` feed. No kickoff time is invented.

The official Iddaa event model also carries country context when the first-party
feed exposes it.

## Safety

A single similar team name is never sufficient. The matcher still compares both
home and away teams, respects youth/reserve tiers, blocks same-source records with
different source IDs, and rejects explicit kickoff contradictions.
