# Matcher V6 — Bulletin Boundary + Canonical Context + Nullable Anchor Metadata

## Changes
- The official İddaa bulletin remains **06:00 → 06:00 Europe/Istanbul** for authoritative bulletin membership.
- The matcher receives a separate **±2 hour boundary candidate pool**. This prevents provider UTC/local-clock drift around 06:00 from hiding a real fixture without redefining the bulletin itself.
- Candidate fixtures outside the core bulletin are not automatically treated as bulletin members; they are only eligible for matching when the fixture identity gates also pass.
- Country names are canonicalized before context comparison (for example `Austria ↔ Avusturya`, `Israel ↔ İsrail`, `Argentina ↔ Arjantin`).
- Missing/nullable country or competition metadata is treated as **unknown**, not as a contradiction. Two explicit conflicting values still veto the candidate before fuzzy team similarity.
- A boundary candidate still requires strong bidirectional team identity and weighted match confidence.
- Diagnostics expose both the core bulletin window and the expanded matching candidate window.

## Safety invariant
The ±2 hour extension is a **candidate-generation tolerance**, not a blanket acceptance rule. It cannot override country/competition contradictions or weak two-sided team identity.
