# GlobalFixtureMatcher V4

## Pipeline

1. Country/league prefilter runs before any fuzzy or phonetic comparison.
2. Team names are canonicalized and then scored with Jaro-Winkler, Levenshtein,
   trigram N-Gram and Double Metaphone evidence.
3. Fixture confidence uses weighted evidence:
   - Home team: 30%
   - Away team: 30%
   - Kickoff/time: 20%
   - Competition: 10%
   - Country: 10%
4. Epoch timestamps are compared as UTC-normalized values. A 30-minute
   publication/rounding tolerance is exact; a wider 3-hour soft window covers
   providers that expose local wall-clock time with an undocumented timezone.
5. Official Iddaa fixtures remain the authoritative fixture anchor.
6. Prediction sources attach independently to the same official fixture; they do
   not need to agree on each other's spelling.
7. Consensus: when at least two independent prediction sources confirm the same
   fixture, `highConfidenceConsensus=true` when weighted consensus >= 0.78.

## Safety

Country/competition contradictions reject a candidate before similarity. This
prevents collisions such as Arsenal (England) vs Arsenal de Sarandi (Argentina).
