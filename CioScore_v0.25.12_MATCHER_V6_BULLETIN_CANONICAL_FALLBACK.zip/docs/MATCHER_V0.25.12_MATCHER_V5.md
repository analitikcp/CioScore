# CioScore Matcher V5 — Context, Timezone, Bidirectional Identity

## Matching order
1. Country/competition canonical taxonomy prefilter.
2. Canonical team identity.
3. Jaro-Winkler + Levenshtein + Trigram + Double Metaphone.
4. Bidirectional team gate: home >= 0.80 AND away >= 0.80.
5. Weighted identity score: 45% home + 45% away + 10% context.
6. Time gate: 30-minute publication tolerance; midnight rollover window up to 12h only around 22:00–02:00; wider timezone soft window remains bounded.
7. Official Iddaa anchor and relaxed missing-time lock only when the bulletin day is compatible.
8. Consensus / source-weighted enrichment.

## Timezone policy
Epoch timestamps are instants and are compared directly. Calendar/time diagnostics are interpreted in `Europe/Istanbul` (UTC+3). A date rollover is not treated as a contradiction when the two local kickoff times fall inside the 22:00–02:00 midnight window and the absolute difference is <= 12 hours.

## Safety invariants
- A strong home match cannot compensate for a weak away match.
- Country/competition contradiction blocks expensive fuzzy similarity.
- Different official fixture IDs never merge.
- Missing provider time does not invent a time; it uses only a constrained official-anchor fallback.
