# Matcher v0.25.12 — Context-First Candidate Prefilter

## Rule

Before any team-name similarity or phonetic comparison is performed, the matcher
checks explicit fixture context:

1. Country, when both records provide it.
2. Competition/league, when both records provide it.

A pair with contradictory explicit country or competition is rejected before the
team similarity engine is invoked. Missing metadata is treated as unknown, not as
an automatic mismatch, so providers that omit league/country data retain recall.

## Why

This prevents cross-country name collisions such as:

- Arsenal (England) vs Arsenal de Sarandí (Argentina)
- United/City-style collisions across different leagues
- identical club names appearing in separate competitions

The context filter is applied both to the official-anchor candidate search and to
global non-official fuzzy clustering.

## Safety

Context filtering is a candidate-space reduction, not the final identity decision.
The final decision still requires two-sided team identity plus schedule/competition
and official-anchor evidence according to `GlobalFixtureMatcher`.
