package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Robust parser for DailySports correct-score prediction cards. */
class DailySportsParser : BaseParser("DailySports") {
    private val predictionScore = Regex(
        "(?i)Prediction\\s+Correct\\s+Score\\s*:\\s*([0-5])\\s*[:\\-]\\s*([0-5])"
    )

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // getElementsContainingOwnText can miss nested <span> markup.
        // Use containing-text and keep the smallest matching element.
        val markers = doc.getElementsContainingText("Prediction Correct Score")
            .filter { predictionScore.containsMatchIn(it.text()) }
            .sortedBy { it.text().length }

        for (marker in markers) {
            val match = predictionScore.find(marker.text()) ?: continue
            val score = "${match.groupValues[1]}-${match.groupValues[2]}"
            val card = findGameCard(marker) ?: continue
            val teams = extractTeams(card)
            if (teams.size < 2) continue

            val home = cleanTeam(teams[0])
            val away = cleanTeam(teams[1])
            if (!valid(home, away)) continue

            val sourceMatchId = card.select("a[href]")
                .map { it.attr("href").trim() }
                .firstOrNull { it.isNotBlank() }
                ?: card.select("[data-match-id], [data-fixture-id], [data-event-id]")
                    .map { element ->
                        listOf(
                            element.attr("data-match-id"),
                            element.attr("data-fixture-id"),
                            element.attr("data-event-id")
                        ).firstOrNull { it.isNotBlank() }.orEmpty()
                    }
                    .firstOrNull { it.isNotBlank() }
                    .orEmpty()

            val meta = fixtureMetadata(card)
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchDate = meta.matchDate,
                matchTime = meta.matchTime,
                competitionName = meta.competitionName,
                countryName = meta.countryName
            )
            val key = if (sourceMatchId.isNotBlank()) {
                "ID|$sourceMatchId"
            } else {
                "${home.lowercase()}|${away.lowercase()}|$score"
            }
            out.putIfAbsent(key, model)
            if (out.size >= 300) break
        }

        return out.values.toList()
    }

    private fun findGameCard(start: Element): Element? {
        var node: Element? = start
        repeat(12) {
            node = node?.parent() ?: return null
            val n = node ?: return null
            val text = clean(n.text())
            if (text.length !in 25..2200) return@repeat

            val scoreHere = predictionScore.find(text)
            if (scoreHere != null) {
                val teams = extractTeams(n)
                if (teams.size >= 2) return n
            }
        }
        return null
    }

    private fun extractTeams(card: Element): List<String> {
        // DailySports currently renders team names through image metadata.
        val imageTeams = card.select("img").flatMap { img ->
            listOf(
                img.attr("alt"),
                img.attr("title"),
                img.attr("aria-label"),
                img.attr("data-alt"),
                img.attr("data-team")
            )
        }.map(::cleanTeamCandidate)
            .filter(::looksLikeTeam)
            .distinct()

        if (imageTeams.size >= 2) return imageTeams.take(2)

        // Some DailySports responses expose the team names as links.
        val linkTeams = card.select("a").flatMap { a ->
            listOf(a.text(), a.attr("title"), a.attr("aria-label"))
        }.map(::cleanTeamCandidate)
            .filter(::looksLikeTeam)
            .distinct()

        if (linkTeams.size >= 2) return linkTeams.take(2)

        return emptyList()
    }

    private fun cleanTeamCandidate(value: String): String {
        return clean(value)
            .removePrefix("Image:")
            .removePrefix("image:")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '|')
    }

    private fun looksLikeTeam(s: String): Boolean {
        if (s.length !in 2..70) return false
        if (s.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        if (predictionScore.containsMatchIn(s)) return false
        val bad = Regex(
            "(?i)^(game|prediction|correct score|time|today|tomorrow|yesterday|show all|image|1x2|o/u|btts|lines|periods|all)$"
        )
        return !bad.matches(s)
    }

    private fun cleanTeam(s: String): String = cleanTeamCandidate(s)
}
