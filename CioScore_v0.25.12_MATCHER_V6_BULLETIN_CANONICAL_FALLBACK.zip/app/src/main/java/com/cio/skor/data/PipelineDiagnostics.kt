package com.cio.skor.data

object PipelineDiagnostics {
    fun log(
        sourceCounts: Map<String, Int>,
        rawPredictions: Int,
        iddaaRaw: Int? = null,
        iddaaParsed: Int? = null,
        gateInput: Int? = null,
        gateOutput: Int? = null,
        matcherInput: Int? = null,
        matcherOutput: Int? = null,
        uiGroups: Int? = null,
        parserStatuses: Map<String, String> = emptyMap(),
        parserEmptyRates: Map<String, Double> = emptyMap()
    ) {
        val lines = buildList {
            add("=== PIPELINE DIAGNOSTIC ===")
            sourceCounts.forEach { (source, count) -> add("$source = $count") }
            parserStatuses.forEach { (source, status) ->
                val rate = parserEmptyRates[source] ?: 0.0
                add("PARSER_HEALTH[$source] = $status emptyRate=${"%.1f".format(rate * 100)}%")
            }
            add("RAW PREDICTIONS = $rawPredictions")
            iddaaRaw?.let { add("IDDAA RAW = $it") }
            iddaaParsed?.let { add("IDDAA PARSED = $it") }
            gateInput?.let { add("GATE INPUT = $it") }
            gateOutput?.let { add("GATE OUTPUT = $it") }
            matcherInput?.let { add("MATCHER INPUT = $it") }
            matcherOutput?.let { add("MATCHER OUTPUT = $it") }
            uiGroups?.let { add("UI GROUPS = $it") }
            add("============================")
        }
        android.util.Log.i("PIPELINE_DIAG", lines.joinToString("\n"))
    }
}
