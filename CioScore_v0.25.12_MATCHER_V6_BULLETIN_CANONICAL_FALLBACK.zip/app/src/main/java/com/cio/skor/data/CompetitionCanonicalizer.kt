package com.cio.skor.data

import java.text.Normalizer
import java.util.Locale

/**
 * Source-independent competition taxonomy.
 * Provider labels are normalized to stable IDs before fuzzy comparison.
 */
object CompetitionCanonicalizer {
    private val aliases = mapOf(
        "trendyol super lig" to "TR_SUPER_LIG",
        "turkey super lig" to "TR_SUPER_LIG",
        "turkish super lig" to "TR_SUPER_LIG",
        "super lig" to "TR_SUPER_LIG",
        "super league turkey" to "TR_SUPER_LIG",
        "premier league" to "EN_PREMIER_LEAGUE",
        "english premier league" to "EN_PREMIER_LEAGUE",
        "england premier league" to "EN_PREMIER_LEAGUE",
        "epl" to "EN_PREMIER_LEAGUE",
        "bundesliga" to "DE_BUNDESLIGA",
        "german bundesliga" to "DE_BUNDESLIGA",
        "1 bundesliga" to "DE_BUNDESLIGA",
        "la liga" to "ES_LA_LIGA",
        "laliga" to "ES_LA_LIGA",
        "spanish la liga" to "ES_LA_LIGA",
        "serie a" to "IT_SERIE_A",
        "italy serie a" to "IT_SERIE_A",
        "serie a italy" to "IT_SERIE_A",
        "ligue 1" to "FR_LIGUE_1",
        "france ligue 1" to "FR_LIGUE_1",
        "eredivisie" to "NL_EREDIVISIE",
        "dutch eredivisie" to "NL_EREDIVISIE",
        "primeira liga" to "PT_PRIMEIRA_LIGA",
        "liga portugal" to "PT_PRIMEIRA_LIGA",
        "champions league" to "UEFA_CHAMPIONS_LEAGUE",
        "uefa champions league" to "UEFA_CHAMPIONS_LEAGUE",
        "ucl" to "UEFA_CHAMPIONS_LEAGUE",
        "europa league" to "UEFA_EUROPA_LEAGUE",
        "uefa europa league" to "UEFA_EUROPA_LEAGUE",
        "uel" to "UEFA_EUROPA_LEAGUE",
        "conference league" to "UEFA_CONFERENCE_LEAGUE",
        "uefa conference league" to "UEFA_CONFERENCE_LEAGUE",
        "world cup" to "FIFA_WORLD_CUP",
        "dunya kupasi" to "FIFA_WORLD_CUP",
        "world cup qualifiers" to "FIFA_WORLD_CUP_QUALIFIERS",
        "dunya kupasi elemeleri" to "FIFA_WORLD_CUP_QUALIFIERS",
        "nations league" to "UEFA_NATIONS_LEAGUE",
        "uefa nations league" to "UEFA_NATIONS_LEAGUE",
        "milletler ligi" to "UEFA_NATIONS_LEAGUE",
        "friendly" to "INTERNATIONAL_FRIENDLY",
        "international friendly" to "INTERNATIONAL_FRIENDLY",
        "dostluk maci" to "INTERNATIONAL_FRIENDLY",
        "dostluk maclari" to "INTERNATIONAL_FRIENDLY"
    )

    fun canonicalId(value: String): String {
        val normalized = normalize(value)
        return aliases[normalized] ?: normalized.uppercase(Locale.ROOT)
    }

    fun canonicalName(value: String): String = canonicalId(value)

    fun similarity(a: String, b: String): Double {
        val ca = canonicalId(a)
        val cb = canonicalId(b)
        if (ca.isBlank() || cb.isBlank()) return 0.0
        if (ca == cb) return 1.0
        // Do not allow a generic fuzzy competition label to override country/league
        // context. Only close canonical labels can survive this layer.
        val aa = ca.lowercase(Locale.ROOT)
        val bb = cb.lowercase(Locale.ROOT)
        val max = maxOf(aa.length, bb.length).coerceAtLeast(1)
        val distance = levenshtein(aa, bb)
        val score = 1.0 - distance.toDouble() / max
        return if (score >= 0.80) score else -1.0
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
            .replace("ş", "s").replace("ö", "o").replace("ç", "c")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var curr = IntArray(b.length + 1)
        for (i in 1..a.length) {
            curr[0] = i
            for (j in 1..b.length) {
                curr[j] = minOf(
                    prev[j] + 1,
                    curr[j - 1] + 1,
                    prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                )
            }
            val tmp = prev; prev = curr; curr = tmp
        }
        return prev[b.length]
    }
}
