package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.CancellationException
import java.util.concurrent.atomic.AtomicInteger
import java.time.ZoneId
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import org.jsoup.Jsoup

/** Prediction-source repository with parser health monitoring and per-source circuit breakers. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private data class BreakerState(var failures: Int = 0, var openedUntil: Long = 0L)
    private val breakers = mutableMapOf<String, BreakerState>()
    private val breakerLock = Any()
    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    private fun isCircuitOpen(name: String): Boolean = synchronized(breakerLock) {
        breakers[name]?.openedUntil?.let { it > System.currentTimeMillis() } == true
    }

    private fun recordHealth(name: String, status: ParserStatus) = synchronized(breakerLock) {
        val state = breakers.getOrPut(name) { BreakerState() }
        if (status == ParserStatus.HEALTHY) {
            state.failures = 0
            state.openedUntil = 0L
        } else {
            state.failures++
            if (state.failures >= 2) state.openedUntil = System.currentTimeMillis() + 2 * 60_000L
        }
    }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val completedCount = AtomicInteger(0)
        val results = sources.map { source ->
            async(Dispatchers.IO) {
                val startTime = System.currentTimeMillis()
                if (isCircuitOpen(source.name)) {
                    val result = SourceResult(source.name, -3, emptyList(), "CIRCUIT_OPEN", 0L, 0, ParserStatus.FAILED, 1.0)
                    onProgress(completedCount.incrementAndGet(), source.name)
                    return@async result
                }
                val result = try {
                    val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                    val (code, html) = withTimeout(15_000L) { withContext(Dispatchers.IO) { http.getFast(source.url, referer) } }
                    val rawBytes = html?.toByteArray(Charsets.UTF_8)?.size ?: 0
                    val isHttpSuccess = code in 200..299 && !html.isNullOrBlank()
                    var scores = emptyList<ScoreModel>()
                    var parserStatus = ParserStatus.FAILED
                    if (isHttpSuccess) {
                        val document = Jsoup.parse(html, source.url)
                        scores = source.parser.parse(document)
                        // JSON-LD / embedded API / fallback selectors only when the
                        // source-specific DOM parser produced no usable rows.
                        if (scores.isEmpty()) scores = source.parser.fallbackParse(document)
                        val zone = ZoneId.of("Europe/Istanbul")
                        val now = java.time.ZonedDateTime.now(zone)
                        val bulletinDate = if (now.toLocalTime().isBefore(LocalTime.of(6, 0))) now.toLocalDate().minusDays(1) else now.toLocalDate()
                        scores = scores.map { model ->
                            if (model.matchDate.isNotBlank()) model else model.copy(matchDate = bulletinDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")))
                        }
                        val emptyRate = emptyFieldRate(scores)
                        parserStatus = when {
                            scores.isEmpty() -> ParserStatus.DOM_CHANGED
                            emptyRate > 0.50 -> ParserStatus.DEGRADED
                            else -> ParserStatus.HEALTHY
                        }
                        val parserError = when (parserStatus) {
                            ParserStatus.HEALTHY -> null
                            ParserStatus.DEGRADED -> "HIGH_EMPTY_FIELD_RATE=${"%.2f".format(emptyRate)}"
                            ParserStatus.DOM_CHANGED -> "DOM_CHANGED_OR_EMPTY"
                            else -> null
                        }
                        val result = SourceResult(source.name, code, scores, parserError, System.currentTimeMillis() - startTime, rawBytes, parserStatus, emptyRate)
                        recordHealth(source.name, parserStatus)
                        result
                    } else {
                        recordHealth(source.name, ParserStatus.FAILED)
                        SourceResult(source.name, code, emptyList(), "HTTP_$code", System.currentTimeMillis() - startTime, rawBytes, ParserStatus.FAILED, 1.0)
                    }
                } catch (e: TimeoutCancellationException) {
                    recordHealth(source.name, ParserStatus.FAILED)
                    SourceResult(source.name, -2, emptyList(), "TIMEOUT_15S", System.currentTimeMillis() - startTime, 0, ParserStatus.FAILED, 1.0)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    recordHealth(source.name, ParserStatus.FAILED)
                    SourceResult(source.name, -1, emptyList(), "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown error"}", System.currentTimeMillis() - startTime, 0, ParserStatus.FAILED, 1.0)
                }
                onProgress(completedCount.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()

        PipelineDiagnostics.log(
            sourceCounts = results.associate { it.source to it.scores.size },
            rawPredictions = results.sumOf { it.scores.size },
            parserStatuses = results.associate { it.source to it.parserStatus.name },
            parserEmptyRates = results.associate { it.source to it.emptyFieldRate }
        )
        results
    }

    private fun emptyFieldRate(scores: List<ScoreModel>): Double {
        if (scores.isEmpty()) return 1.0
        val total = scores.size * 8.0
        val empty = scores.sumOf { s ->
            listOf(s.homeTeam, s.awayTeam, s.predictedScore, s.sourceMatchId, s.matchDate, s.matchTime, s.competitionName, s.countryName)
                .count { it.isBlank() || it == "--:--" }.toDouble()
        }
        return (empty / total).coerceIn(0.0, 1.0)
    }
}
