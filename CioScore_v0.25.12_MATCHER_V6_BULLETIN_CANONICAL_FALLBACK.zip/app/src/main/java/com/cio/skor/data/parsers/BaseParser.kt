package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

abstract class BaseParser(protected val source: String) {
    protected val scoreRegex = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")

    protected fun extractStandardScore(rawText: String): Pair<Int, Int>? {
        val match = scoreRegex.find(rawText) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return home to away
    }

    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    protected fun score(s: String): String? = extractStandardScore(s)?.let { (home, away) -> "$home-$away" }

    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }

    protected data class FixtureMetadata(
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val countryName: String = ""
    )

    protected fun fixtureMetadata(element: Element): FixtureMetadata {
        val text = clean(element.text())
        val date = Regex("\\b(?:\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}|\\d{4}-\\d{1,2}-\\d{1,2})\\b")
            .find(text)?.value.orEmpty()
        val time = Regex("\\b(?:[01]?\\d|2[0-3]):[0-5]\\d\\b").find(text)?.value?.let {
            val parts = it.split(":")
            parts[0].padStart(2, '0') + ":" + parts[1]
        } ?: "--:--"

        fun first(selector: String): String = element.select(selector)
            .map { clean(it.text()) }
            .firstOrNull { it.isNotBlank() && it.length <= 120 }
            .orEmpty()

        val competition = first(".league, .competition, .tournament, [class*=league], [class*=competition], [class*=tournament], [data-league], [data-competition]")
        val country = first(".country, [class*=country], [data-country], [class*=region], [data-region]")
        return FixtureMetadata(date, time, competition, country)
    }

    /**
     * Resilient fallback used only when the source-specific DOM parser returns no
     * records. Order: structured JSON-LD, embedded JSON/API payloads, then a
     * small set of alternative DOM selectors. This prevents a CSS layout change
     * from silently killing an otherwise healthy source.
     */
    fun fallbackParse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        parseStructuredPayloads(doc).forEach { model ->
            val key = model.sourceMatchId.ifBlank { "${model.homeTeam}|${model.awayTeam}|${model.predictedScore}" }
            out.putIfAbsent(key, model)
        }
        if (out.isNotEmpty()) return out.values.toList()

        val selectors = listOf(
            "tr.match-item", "tr.fixture", "tr[data-match-id]", "[data-home-team][data-away-team]",
            "[data-home][data-away]", ".match-item", ".fixture", ".match", "article[class*=match]",
            "article[class*=fixture]", "li[class*=match]", "li[class*=fixture]"
        )
        for (selector in selectors) {
            for (element in doc.select(selector)) {
                val home = firstAttr(element, "data-home-team", "data-home", "data-home-name")
                    .ifBlank { firstChildText(element, ".home, .home-team, [class*=home]", "home") }
                val away = firstAttr(element, "data-away-team", "data-away", "data-away-name")
                    .ifBlank { firstChildText(element, ".away, .away-team, [class*=away]", "away") }
                val parsedScore = score(element.text()) ?: continue
                if (!valid(home, away)) continue
                val meta = fixtureMetadata(element)
                val id = firstAttr(element, "data-match-id", "data-fixture-id", "data-event-id")
                val model = ScoreModel(home, away, parsedScore, source, id, 0L, meta.matchDate, meta.matchTime, meta.competitionName, meta.countryName)
                out.putIfAbsent("$home|$away|$parsedScore", model)
            }
            if (out.isNotEmpty()) break
        }
        return out.values.take(300).toList()
    }

    private fun parseStructuredPayloads(doc: Document): List<ScoreModel> {
        val blocks = buildList {
            doc.select("script[type=application/ld+json]").forEach { add(it.data()) }
            val html = doc.html()
            Regex("(?is)<script[^>]+type=[\\\"']application/json[\\\"'][^>]*>(.*?)</script>").findAll(html)
                .forEach { add(it.groupValues[1]) }
            Regex("(?is)(?:window\\.__INITIAL_STATE__|window\\.__NEXT_DATA__|__NEXT_DATA__|initialState)\\s*=\\s*(\\{.*?\\})(?:;|</script>)")
                .findAll(html).forEach { add(it.groupValues[1]) }
        }
        val out = mutableListOf<ScoreModel>()
        val homeKeys = "(?:homeTeam|home_team|home|homeName|home_name)"
        val awayKeys = "(?:awayTeam|away_team|away|awayName|away_name)"
        val scoreKeys = "(?:correctScore|correct_score|predictedScore|predicted_score|score|prediction)"
        val pairRegex = Regex("(?is)\\\"$homeKeys\\\"\\s*:\\s*(?:\\\"([^\\\"]+)\\\"|\\{[^}]*?\\\"name\\\"\\s*:\\s*\\\"([^\\\"]+)\\\")[^}]{0,1800}?\\\"$awayKeys\\\"\\s*:\\s*(?:\\\"([^\\\"]+)\\\"|\\{[^}]*?\\\"name\\\"\\s*:\\s*\\\"([^\\\"]+)\\\")[^}]{0,1800}?\\\"$scoreKeys\\\"\\s*:\\s*\\\"?([0-9]{1,2}\\s*[-:]\\s*[0-9]{1,2})")
        blocks.forEach { block ->
            pairRegex.findAll(block).forEach { m ->
                val home = clean(m.groupValues[1].ifBlank { m.groupValues[2] })
                val away = clean(m.groupValues[3].ifBlank { m.groupValues[4] })
                val parsed = score(m.groupValues[5]) ?: return@forEach
                if (valid(home, away)) out += ScoreModel(home, away, parsed, source)
            }
        }
        return out
    }

    private fun firstAttr(element: Element, vararg names: String): String =
        names.asSequence().map { element.attr(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()

    private fun firstChildText(element: Element, selector: String, fallbackAttr: String): String {
        val child = element.select(selector).firstOrNull()
        return clean(child?.text().orEmpty()).ifBlank { clean(element.attr(fallbackAttr)) }
    }

    protected fun decodeUrl(value: String): String = runCatching {
        URLDecoder.decode(value, StandardCharsets.UTF_8.name())
    }.getOrDefault(value)

    abstract fun parse(doc: Document): List<ScoreModel>
}
