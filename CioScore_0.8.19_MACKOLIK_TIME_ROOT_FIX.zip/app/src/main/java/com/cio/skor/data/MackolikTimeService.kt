package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalTime

/**
 * Mackolik is the authoritative kickoff-time feed for the UI.
 *
 * This service is intentionally separate from the five prediction sources:
 * it enriches an already merged fixture list and does not count as a CIO
 * prediction source.
 */
class MackolikTimeService(
    private val http: HttpClient = HttpClient()
) {
    data class Kickoff(
        val homeTeam: String,
        val awayTeam: String,
        val time: String,
        val timestamp: Long
    )

    private val urls = listOf(
        "https://www.mackolik.com/iddaa",
        "https://arsiv.mackolik.com/Program/Program.aspx",
        "https://arsiv.mackolik.com/Iddaa-Programi",
        "https://arsiv2.mackolik.com/Iddaa-Programi"
    )

    suspend fun enrich(groups: List<SofaScoreService.MatchGroupData>): List<SofaScoreService.MatchGroupData> =
        withContext(Dispatchers.IO) {
            if (groups.isEmpty()) return@withContext groups

            val kickoffs = loadKickoffs()
            if (kickoffs.isEmpty()) return@withContext groups

            groups.map { group ->
                val found = kickoffs.firstOrNull {
                    MatchMerger.isSameTeam(it.homeTeam, group.homeTeam) &&
                        MatchMerger.isSameTeam(it.awayTeam, group.awayTeam)
                }

                if (found != null) {
                    group.copy(
                        matchTime = found.time,
                        timestamp = found.timestamp
                    )
                } else {
                    group
                }
            }
        }

    private fun loadKickoffs(): List<Kickoff> {
        for (url in urls) {
            val (code, html) = http.get(
                url,
                "https://www.mackolik.com/"
            )
            if (code !in 200..299 || html.isNullOrBlank()) continue

            val parsed = parse(Jsoup.parse(html, url))
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parse(doc: org.jsoup.nodes.Document): List<Kickoff> {
        val out = linkedMapOf<String, Kickoff>()

        // IMPORTANT: Mackolik has changed its markup several times.  Do not
        // depend on a particular team-link href.  The stable information in
        // both the current and archive pages is the visible row text:
        //   HH:mm ... Home - Away ... <id/code> <odds>
        // The previous implementation required hrefs containing /takim/ or
        // /team/ and therefore parsed ZERO matches when Mackolik changed its
        // link structure.  That was the root cause of the empty UI clock.
        doc.select("tr").forEach { row ->
            parseRowText(row.text())?.let { kickoff ->
                out[matchKey(kickoff.homeTeam, kickoff.awayTeam)] = kickoff
            }
        }

        // Some current responsive layouts do not use table rows.  Search
        // likely fixture/event containers as a second pass.
        if (out.isEmpty()) {
            doc.select("[class*=match], [class*=fixture], [class*=event], [data-testid*=match]")
                .forEach { element ->
                    parseRowText(element.text())?.let { kickoff ->
                        out[matchKey(kickoff.homeTeam, kickoff.awayTeam)] = kickoff
                    }
                }
        }

        // Last-resort line parser for server-rendered archive HTML where the
        // fixture is present as plain text but not in a semantic row element.
        if (out.isEmpty()) {
            doc.text()
                .split(Regex("[\\r\\n]+"))
                .map { it.replace(Regex("\\s+"), " ").trim() }
                .filter { it.isNotBlank() }
                .forEach { line ->
                    parseRowText(line)?.let { kickoff ->
                        out[matchKey(kickoff.homeTeam, kickoff.awayTeam)] = kickoff
                    }
                }
        }

        return out.values.toList()
    }

    private fun parseRowText(raw: String): Kickoff? {
        val text = raw.replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        val timeMatch = Regex("\\b([01]?\\d|2[0-3]):([0-5]\\d)\\b").find(text)
            ?: return null
        val time = timeMatch.value.padStart(5, '0')

        // Strip the clock and anything before it (league/header cells).
        val afterTime = text.substring(timeMatch.range.last + 1).trim()
        if (afterTime.isBlank()) return null

        // Preferred shape: Home - Away followed by an id/code and/or decimal
        // odds.  The first 4-6 digit numeric token is the stable Iddaa code.
        val beforeCode = Regex("^(.+?)\\s+-\\s+(.+?)\\s+\\d{4,6}\\b").find(afterTime)
        val pair = beforeCode ?: Regex("^(.+?)\\s+-\\s+(.+?)(?=\\s+\\d+[.,]\\d+\\b|$)").find(afterTime)
            ?: Regex("^(.+?)\\s+-\\s+(.+)$").find(afterTime)
            ?: return null

        var home = cleanTeam(pair.groupValues[1])
        var away = cleanTeam(pair.groupValues[2])

        // Remove trailing numeric/code/odds cells accidentally captured by the
        // broad fallback patterns.
        away = away
            .replace(Regex("\\s+\\d{4,6}\\b.*$"), "")
            .replace(Regex("\\s+\\d+[.,]\\d+\\b.*$"), "")
            .trim()
        home = home.replace(Regex("^.*?\\b(?:LI1|L1|PRN|SEC|1RF|BPD|SEB|FD1|CAP|CUP)\\s+\\d+\\s+"), "").trim()

        if (!validTeam(home) || !validTeam(away)) return null
        if (home.length > 80 || away.length > 80) return null

        val timestamp = LocalDate.now()
            .atTime(LocalTime.parse(time))
            .atZone(ZoneId.systemDefault())
            .toEpochSecond()

        return Kickoff(home, away, time, timestamp)
    }

    private fun matchKey(home: String, away: String): String =
        "${MatchMerger.normalizeTeamName(home)}||${MatchMerger.normalizeTeamName(away)}"

    private fun extractTeams(element: Element): List<String> =
        element.select("a[href]").mapNotNull { a ->
            val href = a.attr("href").lowercase()
            val text = a.text().replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null
            else if (
                href.contains("/takim/") ||
                href.contains("/team/") ||
                href.contains("team")
            ) text
            else null
        }.distinct()

    private fun extractTime(element: Element): String? {
        val text = element.text().replace(Regex("\\s+"), " ").trim()
        val match = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)\b""").find(text)
            ?: return null
        return match.value.padStart(5, '0')
    }

    private fun cleanTeam(raw: String): String =
        raw.replace(Regex("""^\s*(?:[A-ZÇĞİÖŞÜ]{1,5}\s+\d+\s+)?"""), "")
            .replace(Regex("""\s{2,}"""), " ")
            .trim(' ', '|', '-')

    private fun validTeam(name: String): Boolean {
        if (name.length !in 2..80) return false
        val bad = Regex(
            """(?i)^(saat|iddaa|maç sonucu|çifte şans|alt|üst|ev sahibi|misafir|kod|ms|iy)$"""
        )
        return !bad.matches(name) && name.any { it.isLetter() }
    }
}
