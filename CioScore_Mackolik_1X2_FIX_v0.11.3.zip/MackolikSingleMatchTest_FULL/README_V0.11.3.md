# CioScore v0.11.3 – Mackolik 1X2 FIX

Bu paket v0.11.2'nin oranların kartlara gelmemesi sorununu düzeltmek için hazırlandı.

## Yapılan düzeltme

- Maçkolik bülteni tek HTTP GET ile alınır.
- `tr` satırları taranır.
- Takım adı doğrudan `td/th` hücresinden bulunur.
- Satırdaki ilk 5 haneli maç kodu bulunur.
- **Koddan sonra gelen ilk 3 adet `x.xx` değer** MS1 / MSX / MS2 kabul edilir.
- `body *` gibi tüm DOM'u körlemesine tarayan parser kullanılmaz.
- Parse edilen satır sayısı ve örnek maç tarama durumunda gösterilir.
- Takım eşleştirme mevcut `MatchMerger.isSameTeam()` fuzzy mantığıyla yapılır.

## Beklenen test

`MAÇKOLİK TEK MAÇ TESTİ` butonuna basıldığında Cagliari-Lecce için güncel oranlar görünmelidir. Oranlar gün içinde değişebileceği için sabit sayı beklenmemelidir.

Örnek durum:

HTTP: 200
HTML: ... karakter
Cagliari: VAR • Lecce: VAR
MS 1: 1.86   X: 2.84   MS 2: 3.50
SONUÇ: BAŞARILI

## BUGÜNÜ TARA

Tarama sonunda durum satırında:

`Maçkolik: X/Y eşleşme • Z oran • P/Q satır • HTTP 200`

ve bir örnek maç görünür.

**Önemli:** `P/Q` yüksek ve `Z oran` > 0 olduğu halde `X/Y` 0 ise sorun parser değil, beş tahmin kaynağındaki takım adlarının Maçkolik ile eşleştirilmesidir. Bu durumda bir sonraki düzeltme sadece matching katmanına yapılmalıdır.
