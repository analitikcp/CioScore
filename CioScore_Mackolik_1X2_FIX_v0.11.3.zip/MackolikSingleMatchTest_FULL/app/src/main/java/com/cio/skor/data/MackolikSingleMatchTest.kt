package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

/**
 * Tek maç doğrulama testi.
 * Ana 161 maçlık taramaya dokunmaz. Mackolik İddaa Programı'nı tek GET ile okur
 * ve Cagliari - Lecce satırından MS1 / X / MS2 oranlarını çıkarmayı dener.
 */
object MackolikSingleMatchTest {
    private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val homeFound: Boolean,
        val awayFound: Boolean,
        val rowFound: Boolean,
        val ms1: String? = null,
        val msX: String? = null,
        val ms2: String? = null,
        val rowText: String? = null,
        val error: String? = null
    )

    suspend fun testSingleMatch(
        targetHome: String = "Cagliari",
        targetAway: String = "Lecce"
    ): Result = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(PROGRAM_URL)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                .header("Referer", "https://arsiv2.mackolik.com/")
                .build()

            client.newCall(request).execute().use { response ->
                val html = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result(
                        httpCode = response.code,
                        htmlLength = html.length,
                        homeFound = false,
                        awayFound = false,
                        rowFound = false,
                        error = "HTTP ${response.code}"
                    )
                }

                val doc = Jsoup.parse(html)
                val pageText = doc.text()
                val homeFound = pageText.contains(targetHome, ignoreCase = true)
                val awayFound = pageText.contains(targetAway, ignoreCase = true)

                // Gerçek sayfada maçlar tablo satırlarında geliyor. Selector varsayımı
                // yerine tüm TR'leri dolaşıyoruz; böylece küçük HTML değişikliklerinde
                // testin bozulma ihtimali azalıyor.
                val rows = doc.select("tr")
                for (row in rows) {
                    val text = row.text().trim()
                    if (!containsTeam(text, targetHome) || !containsTeam(text, targetAway)) continue

                    // Satırda MS1/X/MS2 ilk üç ondalık oran olarak geliyor.
                    // Kod numaraları 5 haneli olduğu için regex yalnızca 1-2 haneli
                    // ondalık değerleri seçer.
                    val odds = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
                        .findAll(text)
                        .map { it.value.replace(',', '.') }
                        .toList()

                    if (odds.size >= 3) {
                        return@withContext Result(
                            httpCode = response.code,
                            htmlLength = html.length,
                            homeFound = homeFound,
                            awayFound = awayFound,
                            rowFound = true,
                            ms1 = odds[0],
                            msX = odds[1],
                            ms2 = odds[2],
                            rowText = text.take(500)
                        )
                    }
                }

                Result(
                    httpCode = response.code,
                    htmlLength = html.length,
                    homeFound = homeFound,
                    awayFound = awayFound,
                    rowFound = false,
                    error = if (homeFound && awayFound) "Takım isimleri bulundu ancak MS 1/X/2 satırı parse edilemedi" else "Takım satırı bulunamadı"
                )
            }
        } catch (e: Exception) {
            Result(
                httpCode = -1,
                htmlLength = 0,
                homeFound = false,
                awayFound = false,
                rowFound = false,
                error = "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}"
            )
        }
    }

    private fun containsTeam(row: String, team: String): Boolean {
        return normalize(row).contains(normalize(team))
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('ı', 'i')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ş', 's')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("\\s+"), "")
}
