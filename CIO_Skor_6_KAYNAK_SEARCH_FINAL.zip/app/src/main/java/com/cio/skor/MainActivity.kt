package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter
    private var allGroups: List<MatchGroup> = emptyList()
    private lateinit var searchInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        // Maç arama alanı: taranan maçlar arasında ev/deplasman takımına göre filtreler.
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        searchInput = EditText(this).apply {
            hint = "Takım veya maç ara..."
            textSize = 15f
            singleLine = true
            setPadding(16, 0, 16, 0)
        }
        searchRow.addView(searchInput, LinearLayout.LayoutParams(0, 52, 1f))

        val searchButton = Button(this).apply {
            text = "ARA"
            setOnClickListener { applySearch() }
        }
        searchRow.addView(searchButton, LinearLayout.LayoutParams(100, 52))

        header.addView(searchRow)

        val clearButton = Button(this).apply {
            text = "ARAMAYI TEMİZLE"
            setOnClickListener {
                searchInput.setText("")
                adapter.update(allGroups)
                status.text = if (allGroups.isEmpty()) "Hazır" else "${allGroups.size} farklı maç"
            }
        }
        header.addView(clearButton)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            allGroups = groups
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * Collect all raw predictions first, then group by fuzzy HOME + AWAY team
     * matching. Home/away order is intentionally preserved. Source is never
     * part of the match identity.
     */

    private fun applySearch() {
        val query = searchInput.text.toString().trim()
        if (query.isBlank()) {
            adapter.update(allGroups)
            status.text = if (allGroups.isEmpty()) "Hazır" else "${allGroups.size} farklı maç"
            return
        }

        val normalizedQuery = MatchMerger.normalizeTeamName(query)
        val filtered = allGroups.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(normalizedQuery) ||
                away.contains(normalizedQuery) ||
                MatchMerger.isSameTeam(home, normalizedQuery) ||
                MatchMerger.isSameTeam(away, normalizedQuery)
        }

        adapter.update(filtered)
        status.text = "🔎 ${filtered.size} maç bulundu"
    }

    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        if (scores.isEmpty()) return emptyList()

        // Build connected components over ALL raw predictions first.
        // A fixture is the same only when HOME matches HOME and AWAY matches AWAY.
        val parent = IntArray(scores.size) { it }
        fun find(x0: Int): Int {
            var x = x0
            while (parent[x] != x) {
                parent[x] = parent[parent[x]]
                x = parent[x]
            }
            return x
        }
        fun union(a0: Int, b0: Int) {
            val a = find(a0); val b = find(b0)
            if (a != b) parent[b] = a
        }

        for (i in scores.indices) {
            for (j in i + 1 until scores.size) {
                if (MatchMerger.isSameTeam(scores[i].homeTeam, scores[j].homeTeam) &&
                    MatchMerger.isSameTeam(scores[i].awayTeam, scores[j].awayTeam)) {
                    union(i, j)
                }
            }
        }

        val buckets = linkedMapOf<Int, MutableList<ScoreModel>>()
        for (i in scores.indices) {
            buckets.getOrPut(find(i)) { mutableListOf() }.add(scores[i])
        }

        return buckets.values.map { predictions ->
            val first = predictions.first()
            val unique = predictions
                .distinctBy { canonicalSource(it.source) }
            MatchGroup(
                homeTeam = first.homeTeam,
                awayTeam = first.awayTeam,
                predictions = unique
            )
        }
    }

    private fun matchKey(home: String, away: String): String = MatchMerger.key(home, away)

    private fun canonicalSource(value: String): String =
        value.trim().lowercase().replace(Regex("\\s+"), " ")

    private fun sameTeam(a: String, b: String): Boolean =
        canonicalTeam(a) == canonicalTeam(b)

    /** Cross-source team-name normalization. */
    private fun canonicalTeam(value: String): String = MatchMerger.canonicalTeam(value)

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
