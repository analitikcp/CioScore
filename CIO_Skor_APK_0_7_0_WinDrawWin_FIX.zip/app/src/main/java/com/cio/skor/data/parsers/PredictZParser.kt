package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class PredictZParser : BaseParser("PredictZ") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashSet<String>()
        val team = Regex("(?i)([A-Za-zÀ-ÿ0-9.'’&()/-]+(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/-]+){0,5})\\s+v\\s+([A-Za-zÀ-ÿ0-9.'’&()/-]+(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/-]+){0,5})")
        for (el in doc.select("article, li, tr, section, div")) {
            val raw = clean(el.text())
            if (!raw.contains(" v ", true) || raw.length !in 10..500) continue
            val tm = team.find(raw) ?: continue
            val window = raw.substring(tm.range.last + 1).take(220)
            val s = Regex("(?i)(?:correct\\s*score(?:\\s*odds)?|prediction|predicted\\s*score)[^0-9]{0,80}([0-5])\\s*[-:]\\s*([0-5])").find(window)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
                ?: score(window)
                ?: continue
            val a = team(tm.groupValues[1]); val b = team(tm.groupValues[2])
            if (valid(a,b)) out.add("$a|$b|$s")
            if (out.size >= 30) break
        }
        return out.map { val p=it.split("|"); ScoreModel(p[0],p[1],p[2],source) }
    }
}
