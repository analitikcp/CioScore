package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class ForebetParser : BaseParser("Forebet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out=LinkedHashSet<String>()
        for (el in doc.select("tr, .rcs, [class*=rcs], [class*=match]")) {
            val cells=el.select("td,th").map{clean(it.text())}.filter{it.isNotBlank()}
            val row=clean(el.text())
            val s=Regex("(?i)correct\\s*score[^0-9]{0,60}([0-5])\\s*[-:]\\s*([0-5])").find(row)?.let{"${it.groupValues[1]}-${it.groupValues[2]}"}
                ?: Regex("(?i)pred[^0-9]{0,40}([0-5])\\s*[-:]\\s*([0-5])").find(row)?.let{"${it.groupValues[1]}-${it.groupValues[2]}"} ?: continue
            val pair=cells.filter{it.length in 2..60 && !it.contains("correct score",true) && !it.matches(Regex("[0-9.%:-]+"))}.take(2)
            if(pair.size==2 && valid(pair[0],pair[1])) out.add("${pair[0]}|${pair[1]}|$s")
            if(out.size>=30) break
        }
        return out.map{val p=it.split("|"); ScoreModel(p[0],p[1],p[2],source)}
    }
}
