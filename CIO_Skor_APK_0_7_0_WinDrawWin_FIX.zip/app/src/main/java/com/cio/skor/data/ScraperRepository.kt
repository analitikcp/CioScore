package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

class ScraperRepository {
    data class Source(val name:String,val url:String,val parser:BaseParser)
    private val http=HttpClient()
    private val sources=listOf(
        Source("FP.com","https://footballpredictions.com/betting-tips/correct-score/",GenericParser("FP.com")),
        Source("FootballPredictions.net","https://footballpredictions.net/correct-score-predictions-betting-tips",GenericParser("FootballPredictions.net")),
        Source("Forebet","https://www.forebet.com/en/football-tips-and-predictions-for-today/",ForebetParser()),
        Source("PredictZ","https://www.predictz.com/predictions/today/correct-score/",PredictZParser()),
        Source("WinDrawWin","https://www.windrawwin.com/predictions/today/",WinDrawWinParser()),
        Source("BettingTipsToday","https://www.bettingtipstoday.com/",GenericParser("BettingTipsToday")),
        Source("SoccerSeer","https://soccerseer.com/soccer/correct-score-predictions/",GenericParser("SoccerSeer")),
        Source("MightyTips","https://www.mightytips.com/football-predictions/correct-score/",GenericParser("MightyTips")),
        Source("FootyStats","https://footystats.org/predictions",GenericParser("FootyStats")),
        Source("GoalVertex","https://www.goalvertex.com/",GenericParser("GoalVertex")),
        Source("NerdyTips","https://nerdytips.com/",GenericParser("NerdyTips")),
        Source("Vitibet","https://www.vitibet.com/",GenericParser("Vitibet")),
        Source("HuhSports","https://www.huhsports.com/",GenericParser("HuhSports")),
        Source("FootballAnt","https://www.footballant.com/",GenericParser("FootballAnt")),
        Source("DailySports","https://www.dailysports.com/",GenericParser("DailySports")),
        Source("Statarea","https://www.statarea.com/",GenericParser("Statarea"))
    )

    suspend fun fetchAll(onProgress:(Int,String)->Unit):List<SourceResult> = coroutineScope {
        sources.mapIndexed { i,s -> async {
            try { val(code,html)=http.get(s.url); val scores=if(code in 200..299 && !html.isNullOrBlank()) s.parser.parse(Jsoup.parse(html)) else emptyList(); onProgress(i+1,s.name); SourceResult(s.name,code,scores,null) }
            catch(e:Exception){ onProgress(i+1,s.name); SourceResult(s.name,-1,emptyList(),e.javaClass.simpleName) }
        }}.awaitAll()
    }
}
