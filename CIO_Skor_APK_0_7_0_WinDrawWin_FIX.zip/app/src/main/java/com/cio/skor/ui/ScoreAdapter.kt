package com.cio.skor.ui

import android.graphics.Color
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel

class ScoreAdapter(private var items:List<ScoreModel>):RecyclerView.Adapter<ScoreAdapter.VH>(){
    class VH(val tv:TextView):RecyclerView.ViewHolder(tv)
    fun update(v:List<ScoreModel>){items=v;notifyDataSetChanged()}
    override fun onCreateViewHolder(p:ViewGroup,v:Int)=VH(TextView(p.context).apply{setPadding(24,18,24,18);textSize=15f;setTextColor(Color.DKGRAY)})
    override fun getItemCount()=items.size
    override fun onBindViewHolder(h:VH,i:Int){val x=items[i];h.tv.text="⚽ ${x.homeTeam} - ${x.awayTeam}\n🎯 ${x.predictedScore}   •   ${x.source}"}
}
