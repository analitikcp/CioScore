package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class WinDrawWinParser : BaseParser("WinDrawWin") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashSet<String>()

        val elements = doc.select(
            "article, li, tr, section, " +
                "[class*=match], [class*=fixture], [class*=prediction], [class*=game]"
        )

        for (element in elements) {
            val raw = clean(element.text())
            if (raw.length !in 10..450) continue

            val score = extractPredictionScore(raw) ?: continue
            val teams = extractTeams(element, raw) ?: continue

            val home = team(teams.first)
            val away = team(teams.second)

            if (!valid(home, away)) continue

            out.add("$home|$away|$score")
            if (out.size >= 30) break
        }

        return out.map { value ->
            val parts = value.split("|", limit = 3)
            ScoreModel(
                homeTeam = parts[0],
                awayTeam = parts[1],
                predictedScore = parts[2],
                source = source
            )
        }
    }

    private fun extractPredictionScore(raw: String): String? {
        val labelledPatterns = listOf(
            Regex(
                "(?i)(?:correct\\s*score|predicted\\s*score|prediction|score|tips?)\\s*[:\\-]?\\s*[^0-9]{0,50}([0-5])\\s*[-:]\\s*([0-5])"
            ),
            Regex(
                "(?i)(?:correct\\s*score|predicted\\s*score|prediction|score|tips?)\\s+(?:is|=)\\s*([0-5])\\s*[-:]\\s*([0-5])"
            )
        )

        for (pattern in labelledPatterns) {
            val match = pattern.find(raw) ?: continue
            return "${match.groupValues[1]}-${match.groupValues[2]}"
        }

        // Son çare: yalnızca maç benzeri kısa satırlarda skor ara.
        // Sayfanın tamamındaki rastgele skorları kabul etmemek için sınırlı tutulur.
        val scoreMatches = scoreRegex.findAll(raw).toList()
        if (scoreMatches.size == 1) {
            val match = scoreMatches.first()
            return "${match.groupValues[1]}-${match.groupValues[2]}"
        }

        return null
    }

    private fun extractTeams(element: Element, raw: String): Pair<String, String>? {
        val homeSelectors = listOf(
            ".home", ".homeTeam", ".hometeam", ".team-home", ".team1"
        )
        val awaySelectors = listOf(
            ".away", ".awayTeam", ".awayteam", ".team-away", ".team2"
        )

        val home = homeSelectors
            .asSequence()
            .map { selector -> element.select(selector).text().trim() }
            .firstOrNull { it.isNotBlank() }

        val away = awaySelectors
            .asSequence()
            .map { selector -> element.select(selector).text().trim() }
            .firstOrNull { it.isNotBlank() }

        if (!home.isNullOrBlank() && !away.isNullOrBlank()) {
            return Pair(home, away)
        }

        val separators = listOf(" vs ", " v ", " - ", " – ", " — ")

        for (separator in separators) {
            val index = raw.indexOf(separator, ignoreCase = true)
            if (index <= 1) continue

            val left = raw.substring(0, index).trim()
            val rightStart = index + separator.length
            if (rightStart >= raw.length) continue

            var right = raw.substring(rightStart).trim()
            right = trimAfterPredictionLabel(right)

            if (left.isNotBlank() && right.isNotBlank()) {
                return Pair(left, right)
            }
        }

        return null
    }

    private fun trimAfterPredictionLabel(value: String): String {
        val labels = listOf(
            " Prediction",
            " Correct Score",
            " Predicted Score",
            " Tip",
            " Score"
        )

        var end = value.length
        for (label in labels) {
            val index = value.indexOf(label, ignoreCase = true)
            if (index >= 0 && index < end) {
                end = index
            }
        }

        return value.substring(0, end).trim()
    }
}
