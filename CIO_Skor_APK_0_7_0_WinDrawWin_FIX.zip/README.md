CIO Score 0.7.0
Yeni mimari: OkHttp + Jsoup + Coroutines + kaynak bazlı parser sınıfları.
16 kaynak tanımlıdır. PredictZ, Forebet ve WinDrawWin özel parser kullanır; diğer kaynaklar izole GenericParser ile çalışır.
APK arayüzü kaynak hatalarını göstermeden yalnızca temiz skorları listeler.
