package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** SoccerSeer parser: all known card forms plus unlimited DOM/attribute/text fallback. */
class SoccerSeerParser : BaseParser("SoccerSeer") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        doc.select("article, li, tr, [class*=match], [class*=prediction], [class*=game], [class*=fixture], [class*=score], [data-match], [data-event]")
            .forEach { parseElement(it, out) }
        (doc.getElementsContainingText("Correct score") + doc.getElementsContainingText("Predicted score") + doc.getElementsContainingText("Prediction"))
            .sortedBy { it.text().length }.forEach { marker -> climbAndParse(marker, out) }
        genericScoreElements(doc).forEach { parseElement(it, out) }
        return out.values.toList()
    }

    private fun climbAndParse(start: Element, out: LinkedHashMap<String, ScoreModel>) {
        var node: Element? = start
        repeat(10) {
            node = node?.parent()
            val n = node ?: return@repeat
            if (clean(n.text()).length in 8..1600 && scoreRegex.containsMatchIn(n.text())) parseElement(n, out)
            if (clean(n.text()).length in 20..900 && out.values.any { clean(n.text()).contains(it.homeTeam, true) }) return@repeat
        }
    }

    private fun parseElement(el: Element, out: LinkedHashMap<String, ScoreModel>) {
        val raw = buildString {
            append(el.text())
            listOf("title", "aria-label", "data-match", "data-event", "data-teams", "data-home-team", "data-away-team")
                .forEach { key -> el.attr(key).takeIf { it.isNotBlank() }?.let { append(" | ").append(it) } }
        }
        val found = scoreAt(raw) ?: return
        val pair = extractTeams(el, raw, found.first) ?: return
        val h = teamCandidate(pair.first); val a = teamCandidate(pair.second)
        if (!valid(h, a)) return
        // A score prediction page may contain historical result labels. Only reject
        // an element when a clear result marker is present AND there is another
        // prediction score later in the same element.
        if (isFinishedPredictionNoise(raw)) return
        val model = ScoreModel(h, a, found.second, source)
        out[model.matchKey] = model
    }

    private fun extractTeams(el: Element, raw: String, scoreStart: Int): Pair<String, String>? {
        val home = el.selectFirst(".home, .home-team, .homeTeam, .team-home, .team1, [class*=home-team], [data-home-team]")?.text()
        val away = el.selectFirst(".away, .away-team, .awayTeam, .team-away, .team2, [class*=away-team], [data-away-team]")?.text()
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away
        return genericTeams(el, raw, scoreStart)
    }

    private fun isFinishedPredictionNoise(raw: String): Boolean {
        val t = " ${clean(raw).lowercase()} "
        if (!(t.contains(" full time ") || t.contains(" finished ") || t.contains(" match ended "))) return false
        val scores = scoreRegex.findAll(t).count()
        return scores > 1
    }
}
