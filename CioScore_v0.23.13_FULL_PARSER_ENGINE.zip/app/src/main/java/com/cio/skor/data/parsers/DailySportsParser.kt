package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** DailySports parser: explicit prediction label first, shared fallback second. */
class DailySportsParser : BaseParser("DailySports") {
    private val predictionLabel = Regex("(?i)prediction\\s+correct\\s+score")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val markers = doc.getElementsContainingText("Prediction Correct Score")
        markers.sortedBy { it.text().length }.forEach { marker ->
            findCard(marker)?.let { parseCard(it, out) }
        }
        doc.select("article, li, [class*=match], [class*=game], [class*=prediction], [class*=fixture], [data-game]")
            .forEach { parseCard(it, out) }
        genericScoreElements(doc).forEach { parseCard(it, out) }
        return out.values.toList()
    }

    private fun findCard(start: Element): Element? {
        var node: Element? = start
        repeat(12) {
            node = node?.parent()
            val n = node ?: return@repeat
            val t = clean(n.text())
            if (t.length in 20..2200 && predictionLabel.containsMatchIn(t) && scoreRegex.containsMatchIn(t)) return n
        }
        return null
    }

    private fun parseCard(card: Element, out: LinkedHashMap<String, ScoreModel>) {
        val raw = clean(card.text())
        val found = predictionScore(raw) ?: scoreAt(raw) ?: return
        val pair = extractTeams(card, raw, found.first) ?: return
        val h = teamCandidate(pair.first); val a = teamCandidate(pair.second)
        if (!valid(h, a)) return
        val model = ScoreModel(h, a, found.second, source)
        out[model.matchKey] = model
    }

    private fun predictionScore(text: String): Pair<Int, String>? {
        for (m in predictionLabel.findAll(text)) {
            scoreAt(text.substring(m.range.last + 1))?.let { return m.range.last + 1 + it.first to it.second }
        }
        return null
    }

    private fun extractTeams(card: Element, raw: String, scoreStart: Int): Pair<String, String>? {
        val imageTeams = card.select("img").flatMap { img ->
            listOf(img.attr("alt"), img.attr("title"), img.attr("aria-label"), img.attr("data-alt"), img.attr("data-team"))
        }.map(::teamCandidate).filter(::looksLikeTeam).distinct()
        if (imageTeams.size >= 2) return imageTeams[0] to imageTeams[1]

        val links = card.select("a").flatMap { a -> listOf(a.text(), a.attr("title"), a.attr("aria-label")) }
            .map(::teamCandidate).filter(::looksLikeTeam).distinct()
        if (links.size >= 2) return links[0] to links[1]

        return genericTeams(card, raw, scoreStart)
    }
}
