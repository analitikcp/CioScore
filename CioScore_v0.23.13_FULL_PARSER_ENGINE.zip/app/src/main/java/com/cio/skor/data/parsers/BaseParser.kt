package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Shared, defensive extraction engine used by all five score sources.
 * The source-specific parsers run their known selectors first, then use these
 * layered fallbacks so a CSS redesign does not make an entire source disappear.
 */
abstract class BaseParser(protected val source: String) {
    protected val scoreRegex = Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
    private val badTeam = Regex(
        "(?i)^(?:home|away|draw|prediction|predicted|pred|correct score|correct score odds|" +
            "odds|tip|tips|pick|match preview|preview|analysis|statistics|stats|" +
            "view|read more|more|today|tomorrow|yesterday|ft|final|finished|" +
            "btts|over|under|1x2|avg goals|results?)$"
    )

    protected fun clean(s: String): String = s
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    protected fun score(s: String): String? = scoreRegex.find(clean(s))?.let {
        "${it.groupValues[1]}-${it.groupValues[2]}"
    }

    protected fun scoreAt(s: String): Pair<Int, String>? = scoreRegex.find(clean(s))?.let {
        it.range.first to "${it.groupValues[1]}-${it.groupValues[2]}"
    }

    protected fun team(s: String): String = clean(s)
        .replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score|match preview)\\b"), " ")
        .replace(Regex("\\([^)]*\\)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|', ',')

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..70 || b.length !in 2..70 || a.equals(b, true)) return false
        return !isNoise(a) && !isNoise(b)
    }

    /** Layer 2/3: anchors, data attributes, alt/title and aria-labels. */
    protected fun firstTeamPairFromLinks(element: Element): Pair<String, String>? {
        val candidates = element.select(
            "a[href], [data-home-team], [data-away-team], [data-team], [data-home], [data-away], " +
                "[data-team-name], img[alt], img[title], [aria-label]"
        ).flatMap { n ->
            listOf(
                n.text(), n.attr("title"), n.attr("aria-label"), n.attr("data-team"),
                n.attr("data-team-name"), n.attr("data-home-team"), n.attr("data-away-team"),
                n.attr("data-home"), n.attr("data-away"), n.attr("alt")
            )
        }.map(::teamCandidate)
            .filter(::looksLikeTeam)
            .distinct()

        if (candidates.size >= 2) return candidates[0] to candidates[1]
        return null
    }

    /** Layer 4: visible text in common A vs B / A v B forms. */
    protected fun pairFromVisibleText(text: String): Pair<String, String>? {
        val cleaned = clean(text)
        val patterns = listOf(
            Regex("(?i)(.{2,80}?)\\s+(?:vs\\.?|v\\.?|versus)\\s+(.{2,80}?)(?=\\s+(?:prediction|predicted|correct score|odds|tip|pick|$))"),
            Regex("(?i)^(.{2,80}?)\\s+(?:vs\\.?|v\\.?|versus)\\s+(.{2,80})$")
        )
        for (p in patterns) {
            val m = p.find(cleaned) ?: continue
            val h = teamCandidate(m.groupValues[1])
            val a = teamCandidate(m.groupValues[2])
            if (valid(h, a)) return h to a
        }
        return null
    }

    /**
     * Generic fallback: find every DOM element containing a score, climb only
     * as far as necessary, and recover teams from classes/attributes/links/text.
     * There is deliberately no result-count cap here.
     */
    protected fun genericScoreElements(doc: Document): Sequence<Element> = sequence {
        val seen = LinkedHashSet<Element>()
        for (node in doc.getAllElements()) {
            if (!scoreRegex.containsMatchIn(node.ownText()) && !scoreRegex.containsMatchIn(node.text())) continue
            var current: Element? = node
            repeat(8) {
                val e = current ?: return@repeat
                val t = clean(e.text())
                if (t.length in 8..1400 && scoreRegex.containsMatchIn(t)) {
                    if (seen.add(e)) yield(e)
                    return@repeat
                }
                current = e.parent()
            }
        }
    }

    /** Layered team recovery for a single candidate card. */
    protected fun genericTeams(element: Element, raw: String, scoreStart: Int = -1): Pair<String, String>? {
        // 1. explicit home/away classes and data attributes
        val home = firstNonBlank(element,
            ".team-home", ".home-team", ".homeTeam", ".team1", ".home", "[data-home-team]", "[data-home]"
        )
        val away = firstNonBlank(element,
            ".team-away", ".away-team", ".awayTeam", ".team2", ".away", "[data-away-team]", "[data-away]"
        )
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) {
            val h = teamCandidate(home); val a = teamCandidate(away)
            if (valid(h, a)) return h to a
        }

        // 2. href slug, including /match/home-vs-away and /home-vs-away
        for (a in element.select("a[href]")) {
            val pair = pairFromSlug(a.attr("href"))
            if (pair != null) return pair
        }

        // 3. explicit attributes / image metadata / link text
        firstTeamPairFromLinks(element)?.let { if (valid(it.first, it.second)) return it }

        // 4. text around the score
        if (scoreStart >= 0) {
            pairAroundScore(raw, scoreStart)?.let { if (valid(it.first, it.second)) return it }
        }
        pairFromVisibleText(raw)?.let { return it }

        // 5. last resort: two plausible team labels in the card
        val labels = element.select("a, h1, h2, h3, h4, h5, strong, b, span, [class*=team], [data-team-name]")
            .flatMap { n -> listOf(n.text(), n.attr("title"), n.attr("aria-label"), n.attr("alt")) }
            .map(::teamCandidate)
            .filter(::looksLikeTeam)
            .distinct()
        if (labels.size >= 2) return labels[0] to labels[1]
        return null
    }

    private fun pairAroundScore(raw: String, start: Int): Pair<String, String>? {
        val normalized = clean(raw)
        val m = scoreRegex.find(normalized, start) ?: scoreRegex.find(normalized) ?: return null
        val left = normalized.substring(0, m.range.first)
        val right = normalized.substring(m.range.last + 1)
        val leftCandidates = tokenizeCandidates(left)
        val rightCandidates = tokenizeCandidates(right)
        for (h0 in leftCandidates.reversed()) {
            for (a0 in rightCandidates) {
                val h = teamCandidate(h0); val a = teamCandidate(a0)
                if (valid(h, a)) return h to a
            }
        }
        return null
    }

    private fun tokenizeCandidates(s: String): List<String> = clean(s)
        .split(Regex("\\s{2,}|\\||•|→|»|›"))
        .map(::teamCandidate)
        .filter { it.length in 2..70 && !isNoise(it) }

    private fun pairFromSlug(href: String): Pair<String, String>? {
        if (href.isBlank()) return null
        val decoded = try { URLDecoder.decode(href, StandardCharsets.UTF_8.name()) } catch (_: Exception) { href }
        var slug = decoded.substringBefore('?').substringBefore('#').trimEnd('/')
            .substringAfterLast('/').lowercase()
        slug = slug.replace(Regex("-(?:prediction|predictions|tip|tips|correct-score|odds|preview).*$"), "")
        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = slug.indexOf(marker)
            if (idx > 0) {
                val h = slugWords(slug.substring(0, idx))
                val a = slugWords(slug.substring(idx + marker.length))
                if (valid(h, a)) return h to a
            }
        }
        return null
    }

    private fun slugWords(s: String): String = s.replace('-', ' ')
        .replace(Regex("\\s+"), " ").trim()
        .split(' ').filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.replaceFirstChar { c -> c.uppercase() } }

    protected fun teamCandidate(value: String): String = team(value)
        .replace(Regex("(?i)\\b(?:home|away)\\s*[:|-]\\s*"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|', ',')

    protected fun looksLikeTeam(value: String): Boolean {
        val v = teamCandidate(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        if (badTeam.matches(v)) return false
        if (v.contains(Regex("(?i)correct\\s*score|prediction|predicted|match preview|last 5|goals scored|goals conceded|read more"))) return false
        return true
    }

    private fun isNoise(value: String): Boolean = !looksLikeTeam(value)

    private fun firstNonBlank(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val v = element.selectFirst(selector)?.text()?.let(::teamCandidate)
            if (!v.isNullOrBlank() && looksLikeTeam(v)) return v
        }
        return null
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
