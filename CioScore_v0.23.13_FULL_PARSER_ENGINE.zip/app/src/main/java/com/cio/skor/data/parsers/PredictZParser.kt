package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** PredictZ parser: legacy classes + current card markers + unlimited generic fallback. */
class PredictZParser : BaseParser("PredictZ") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        doc.select(".ptcnt, [class*=ptcnt], .match-container, [data-game], article, li, [class*=match], [class*=prediction], [class*=correct-score]")
            .forEach { parseBlock(it, out) }
        (doc.getElementsContainingText("Correct Score") + doc.getElementsContainingText("MATCH PREVIEW"))
            .sortedBy { it.text().length }.forEach { marker ->
                smallestCard(marker)?.let { parseBlock(it, out) }
            }
        genericScoreElements(doc).forEach { parseBlock(it, out) }
        return out.values.toList()
    }

    private fun parseBlock(block: Element, out: LinkedHashMap<String, ScoreModel>) {
        val found = extractPredictionScore(block) ?: return
        val pair = extractTeams(block, found.first) ?: return
        val h = teamCandidate(pair.first); val a = teamCandidate(pair.second)
        if (!valid(h, a)) return
        val model = ScoreModel(h, a, found.second, source)
        out[model.matchKey] = model
    }

    private fun smallestCard(start: Element): Element? {
        var node: Element? = start
        repeat(12) {
            node = node?.parent()
            val n = node ?: return@repeat
            val t = clean(n.text())
            if (t.length in 20..1800 && scoreRegex.containsMatchIn(t)) return n
        }
        return null
    }

    private fun extractTeams(block: Element, scoreStart: Int): Pair<String, String>? {
        val home = block.selectFirst(".ptmobh, [class*=ptmobh], .home-team, .homeTeam, [class*=home-team], [data-home-team]")?.text()
        val away = block.selectFirst(".ptmoba, [class*=ptmoba], .away-team, .awayTeam, [class*=away-team], [data-away-team]")?.text()
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away
        return genericTeams(block, block.text(), scoreStart)
    }

    private fun extractPredictionScore(block: Element): Pair<Int, String>? {
        val marked = block.select(".ptpredboxsml, .ptpredbox, [class*=ptpredbox], [class*=correct-score], [data-prediction], [data-score]")
        for (e in marked) scoreAt(e.text())?.let { return it }
        val text = clean(block.text())
        val labels = Regex("(?i)\\b(?:home|draw|away|prediction|predicted score(?:line)?|correct score(?: odds)?|tip)\\b")
        for (m in labels.findAll(text)) {
            scoreAt(text.substring(m.range.last + 1))?.let { return (m.range.last + 1 + it.first) to it.second }
        }
        return scoreAt(text)
    }
}
