package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** WinDrawWin parser: tip links/cards + shared unlimited fallback engine. */
class WinDrawWinParser : BaseParser("WinDrawWin") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        doc.select("tr[data-game], tr:has(.wt-team), div.matchrow, article, li, [class*=match], [class*=prediction], [class*=tip]")
            .forEach { parseElement(it, out) }
        doc.select("a[href]").forEach { link ->
            if (link.text().contains(Regex("(?i)\\b(?:tip|pick)\\b"))) parseElement(link.parent() ?: link, out)
        }
        genericScoreElements(doc).forEach { parseElement(it, out) }
        return out.values.toList()
    }

    private fun parseElement(el: Element, out: LinkedHashMap<String, ScoreModel>) {
        val found = scoreAt(el.text()) ?: return
        val pair = extractTeams(el, found.first) ?: return
        val h = teamCandidate(pair.first); val a = teamCandidate(pair.second)
        if (!valid(h, a)) return
        val model = ScoreModel(h, a, found.second, source)
        out[model.matchKey] = model
    }

    private fun extractTeams(el: Element, scoreStart: Int): Pair<String, String>? {
        val home = el.selectFirst(".home-team, .wt-home, .team1, .home, [class*=home-team], [data-home-team]")?.text()
        val away = el.selectFirst(".away-team, .wt-away, .team2, .away, [class*=away-team], [data-away-team]")?.text()
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away
        return genericTeams(el, el.text(), scoreStart)
    }
}
