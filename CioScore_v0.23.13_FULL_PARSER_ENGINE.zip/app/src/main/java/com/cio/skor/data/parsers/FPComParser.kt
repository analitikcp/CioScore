package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** FootballPredictions parser: known markup first, shared unlimited fallback second. */
class FPComParser : BaseParser("FP.com") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val primary = doc.select("table tr, article, li, .prediction-card, .match-box, [class*=match], [class*=fixture], [class*=prediction], [class*=correct-score]")
        primary.forEach { parseElement(it, out) }
        genericScoreElements(doc).forEach { parseElement(it, out) }
        return out.values.toList()
    }

    private fun parseElement(el: Element, out: LinkedHashMap<String, ScoreModel>) {
        val found = scoreAt(el.text()) ?: return
        val pair = extractTeams(el, found.first) ?: return
        val h = teamCandidate(pair.first); val a = teamCandidate(pair.second)
        if (!valid(h, a)) return
        val model = ScoreModel(h, a, found.second, source)
        out[model.matchKey] = model
    }

    private fun extractTeams(el: Element, scoreStart: Int): Pair<String, String>? {
        val home = el.selectFirst(".home-team, .homeTeam, .team-home, .team1, .home, [class*=home-team], [data-home-team]")?.text()
        val away = el.selectFirst(".away-team, .awayTeam, .team-away, .team2, .away, [class*=away-team], [data-away-team]")?.text()
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away
        return genericTeams(el, el.text(), scoreStart)
    }
}
