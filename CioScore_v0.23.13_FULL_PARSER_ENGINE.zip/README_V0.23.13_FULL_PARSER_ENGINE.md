# CioScore v0.23.13 — FULL PARSER ENGINE

## Refactor
- Removed artificial extraction limits from all five score parsers.
- Added a shared layered fallback engine to `BaseParser`:
  1. explicit home/away CSS selectors
  2. `data-*` attributes
  3. href/URL slug (`home-vs-away`)
  4. link/image `alt`/`title`/`aria-label`
  5. visible `home v away` text
  6. score-adjacent text recovery
  7. generic DOM candidate scan
- All fallback scans are unlimited; there is no `take(100)`, `>= 50`, or `>= 300` truncation in score extraction.
- PredictZ, FP.com, WinDrawWin, SoccerSeer and DailySports now run their known selectors and then the shared fallback engine.
- `ScraperRepository` keeps `SourceDiagnostic` and `ScraperScanReport`, including HTTP code, parsed count and error message.
- `lastScanReport` is retained for post-scan diagnostics.
- MainActivity logs scan failures instead of silently swallowing the entire scan.
- HTTP fetching uses the resilient `get()` path with retry rather than the old 12-second `getFast()` path.

## Diagnostic log tag
`CioScoreScraper`

Example:
`PredictZ: 38 matches, http=200, success=true, error=null`

`TOTAL RAW MATCHES: 477`

## Important
This package is source-refactored and statically checked in this environment. A full Android/Gradle build still requires the Android SDK/Gradle toolchain on the build machine.
