# Country / National-Team Name Matching Fix

This revision hardens multilingual national-team identity matching in `TeamAliasCanonicalizer`.

Requested 26 English -> Turkish pairs are canonicalized to one stable identity:

- Armenia -> Ermenistan
- Latvia -> Letonya
- Georgia -> Gürcistan
- Northern Ireland -> Kuzey İrlanda
- Hungary -> Macaristan
- Ukraine -> Ukrayna
- Montenegro -> Karadağ
- Cyprus -> Kıbrıs
- Poland -> Polonya
- Bosnia and Herzegovina -> Bosna Hersek
- Turkey -> Türkiye
- Algeria -> Cezayir
- Zambia -> Zambiya
- Gambia -> Gambiya
- Somalia -> Somali
- Nigeria -> Nijerya
- Madagascar -> Madagaskar
- Morocco -> Fas
- Cape Verde -> Yeşil Burun Adaları
- Malawi -> Malavi
- South Sudan -> Güney Sudan
- Rwanda -> Ruanda
- Liberia -> Liberya
- Ethiopia -> Etiyopya
- Tanzania -> Tanzanya
- Niger -> Nijer

Provider-decorated forms such as `Armenia National Team`, `Turkey National Football Team`
and `Ermenistan Milli Futbol Takımı` are also normalized, but only when the remaining
base name is one of the explicit national-team identities. This avoids turning generic
club names into country identities.

Youth/reserve separation remains intact. For example, `Armenia U21` does not become
the same team identity as senior `Armenia`.

`BaseParser.looksLikeCountry()` now delegates these requested national-team country
names to the same canonical layer used by `GlobalFixtureMatcher`, preventing a separate
country vocabulary from drifting away from the team matcher.
