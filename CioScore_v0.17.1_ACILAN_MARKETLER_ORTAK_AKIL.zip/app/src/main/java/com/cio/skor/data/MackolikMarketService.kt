package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.json.JSONObject
import java.text.Normalizer
import java.time.LocalDate
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Maçkolik'te BUGÜN açılmış futbol marketlerini bulur.
 *
 * Akış:
 * 1) Maçkolik canlı skor JSON'undan bugünün İddaa maç ID'leri alınır.
 * 2) Her maçın /mac/.../iddaa/{id} detay sayfası okunur.
 * 3) widget-iddaa-markets__markets-list içindeki gerçek market başlıkları
 *    ve oranları ayrıştırılır.
 *
 * Böylece sadece MS 1/X/2 oranına bakıp HT/FT veya Doğru Skor'u yanlışlıkla
 * "kapalı" kabul etmeyiz.
 */
class MackolikMarketService {
    data class OpenedMarketMatch(
        val homeTeam: String,
        val awayTeam: String,
        val hasHtFt: Boolean,
        val hasCorrectScore: Boolean,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
        val correctScoreOdds: LinkedHashMap<String, String> = linkedMapOf()
    )

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val error: String? = null
    )

    private data class Candidate(
        val homeTeam: String,
        val awayTeam: String,
        val detailUrl: String
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(16, TimeUnit.SECONDS)
        .build()

    private val base = "https://www.mackolik.com"
    private val liveUrl = "https://www.mackolik.com/perform/p0/ajax/components/competition/livescores/json"
    private val archiveUrl = "https://arsiv2.mackolik.com/Iddaa-Programi"

    private val htFtLabel = Regex("^[1X2]/[1X2]$", RegexOption.IGNORE_CASE)
    private val scoreLabel = Regex("^\\d{1,2}[-:]\\d{1,2}$")
    private val oddValue = Regex("^(?:[0-9]{1,3})(?:[.,][0-9]{1,2})$")

    suspend fun fetchOpenedMarkets(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(35_000L) {
            try {
                val candidates = fetchLiveCandidates().ifEmpty {
                    val html = get(archiveUrl)
                        ?: return@withTimeoutOrNull Result(emptyList(), 0, "Maçkolik bülteni alınamadı")
                    parseCandidates(Jsoup.parse(html, archiveUrl))
                }

                if (candidates.isEmpty()) {
                    return@withTimeoutOrNull Result(
                        emptyList(),
                        0,
                        "Bugünün İddaa maç bağlantıları bulunamadı"
                    )
                }

                val found = coroutineScope {
                    candidates.chunked(8).flatMap { chunk ->
                        chunk.map { candidate ->
                            async(Dispatchers.IO) { inspect(candidate) }
                        }.awaitAll().filterNotNull()
                    }
                }

                val merged = found
                    .groupBy { MatchMerger.key(it.homeTeam, it.awayTeam) }
                    .values
                    .map { same ->
                        val first = same.first()
                        val ht = linkedMapOf<String, String>()
                        val cs = linkedMapOf<String, String>()
                        same.forEach {
                            ht.putAll(it.htFtOdds)
                            cs.putAll(it.correctScoreOdds)
                        }
                        first.copy(
                            hasHtFt = same.any { it.hasHtFt } || ht.isNotEmpty(),
                            hasCorrectScore = same.any { it.hasCorrectScore } || cs.isNotEmpty(),
                            htFtOdds = ht,
                            correctScoreOdds = cs
                        )
                    }

                Result(merged, candidates.size)
            } catch (e: Exception) {
                Result(emptyList(), 0, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, "Market taraması zaman aşımına uğradı")
    }

    private fun fetchLiveCandidates(): List<Candidate> {
        val date = LocalDate.now().toString()
        val body = getWithQuery(
            liveUrl,
            mapOf("sports[]" to "Soccer", "matchDate" to date)
        ) ?: return emptyList()

        return runCatching {
            val matches = JSONObject(body)
                .optJSONObject("data")
                ?.optJSONObject("matches")
                ?: return emptyList()

            val out = LinkedHashMap<String, Candidate>()
            val keys = matches.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = matches.optJSONObject(id) ?: continue
                val iddaaCode = item.optString("iddaaCode", "")
                if (iddaaCode.isBlank() || iddaaCode.equals("None", true)) continue

                val name = item.optString("matchName", "")
                    .replace(Regex("\\s+"), " ")
                    .trim()
                val pair = splitPair(name) ?: continue

                val slug = "${pair.first}-vs-${pair.second}"
                    .lowercase(Locale.ROOT)
                    .replace(Regex("[^a-z0-9]+"), "-")
                    .trim('-')

                val detail = "$base/mac/$slug/iddaa/$id"
                out[MatchMerger.key(pair.first, pair.second)] = Candidate(
                    pair.first,
                    pair.second,
                    detail
                )
            }
            out.values.toList()
        }.getOrDefault(emptyList())
    }

    private fun parseCandidates(doc: Document): List<Candidate> {
        val out = LinkedHashMap<String, Candidate>()
        for (row in doc.select("tr")) {
            val pair = findTeamPair(row) ?: continue
            val link = row.select("a[href]")
                .mapNotNull { it.attr("abs:href").ifBlank { null } }
                .firstOrNull { it.contains("/iddaa/", true) }
                ?: row.select("a[href]")
                    .mapNotNull { it.attr("abs:href").ifBlank { null } }
                    .firstOrNull { it.contains("/mac/", true) && it.contains("mackolik.com", true) }
                ?: continue
            out[MatchMerger.key(pair.first, pair.second)] = Candidate(pair.first, pair.second, link)
        }
        return out.values.toList()
    }

    private fun findTeamPair(row: Element): Pair<String, String>? = row.select("td, th")
        .asSequence()
        .map { it.text().replace(Regex("\\s+"), " ").trim() }
        .mapNotNull(::splitPair)
        .firstOrNull()

    private fun splitPair(text: String): Pair<String, String>? {
        val matches = Regex("\\s+-\\s+").findAll(text).toList()
        if (matches.size != 1) return null
        val p = matches.first()
        val home = text.substring(0, p.range.first).trim()
        val away = text.substring(p.range.last + 1).trim()
        if (home.length !in 2..80 || away.length !in 2..80) return null
        if (home.count(Char::isLetter) < 2 || away.count(Char::isLetter) < 2) return null
        return home to away
    }

    private fun inspect(candidate: Candidate): OpenedMarketMatch? {
        val html = get(candidate.detailUrl) ?: return null
        val doc = Jsoup.parse(html, candidate.detailUrl)
        val marketList = doc.selectFirst("ul.widget-iddaa-markets__markets-list") ?: return null

        val htFt = linkedMapOf<String, String>()
        val correctScore = linkedMapOf<String, String>()

        for (market in marketList.children()) {
            val header = market.selectFirst("h2")?.text()
                ?.replace(Regex("\\s+"), " ")
                ?.trim()
                ?: continue

            val normalizedHeader = normalize(header)
            val isHtFtHeader = isHtFtHeader(normalizedHeader)
            val isCorrectScoreHeader = normalizedHeader.contains("dogru skor") ||
                normalizedHeader.contains("correct score") ||
                normalizedHeader.contains("mac skoru")

            if (!isHtFtHeader && !isCorrectScoreHeader) continue

            val content = market.selectFirst(".widget-iddaa-markets__market-content") ?: continue
            for (li in content.select("li")) {
                val spans = li.select("span").map { it.text().trim() }
                var i = 0
                while (i + 1 < spans.size) {
                    val label = spans[i]
                    val value = spans[i + 1].replace(',', '.').trim()
                    if (oddValue.matches(value) && value != "1.00") {
                        when {
                            isHtFtHeader && htFtLabel.matches(label) -> htFt[label.uppercase(Locale.ROOT)] = value
                            isCorrectScoreHeader && scoreLabel.matches(label) -> correctScore[label.replace(':', '-')] = value
                        }
                    }
                    i += 2
                }
            }
        }

        if (htFt.isEmpty() && correctScore.isEmpty()) return null

        return OpenedMarketMatch(
            homeTeam = candidate.homeTeam,
            awayTeam = candidate.awayTeam,
            hasHtFt = htFt.isNotEmpty(),
            hasCorrectScore = correctScore.isNotEmpty(),
            htFtOdds = LinkedHashMap(htFt),
            correctScoreOdds = LinkedHashMap(correctScore)
        )
    }

    private fun isHtFtHeader(normalized: String): Boolean =
        (normalized.contains("iy") && normalized.contains("ms")) ||
            normalized.contains("ilk yari mac sonucu") ||
            normalized.contains("ilk yari sonucu") ||
            normalized.contains("devre mac sonucu")

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i')
            .replace('ö', 'o').replace('ş', 's').replace('ü', 'u')
        v = Normalizer.normalize(v, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        return v.replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private fun getWithQuery(url: String, query: Map<String, String>): String? {
        val request = Request.Builder()
            .url(url + "?" + query.entries.joinToString("&") { "${it.key}=${it.value}" })
            .header("User-Agent", userAgent())
            .header("Accept", "application/json,text/plain,*/*")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Referer", base + "/")
            .build()
        return execute(request)
    }

    private fun get(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent())
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Referer", base + "/")
            .build()
        return execute(request)
    }

    private fun execute(request: Request): String? = runCatching {
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) null else response.body?.string()
        }
    }.getOrNull()

    private fun userAgent() =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
}
