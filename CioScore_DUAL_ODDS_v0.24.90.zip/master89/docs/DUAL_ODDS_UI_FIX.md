# v0.24.86 — ORANLAR button visibility fix

The first-ZIP independent odds panel is now explicitly placed immediately below the home/away team row and ABOVE the main-card Iddaa + Bet365 odds table.

This preserves both systems:

1. Main-card odds: Iddaa + Bet365 remain visible directly on every match card.
2. Independent ORANLAR panel: tapping `📊 ORANLAR` opens a separate panel for that fixture with Iddaa.com + Bet365.
3. The panel keeps its own provider path and can later receive Bwin/Pinnacle/1xBet/etc. without changing the main-card odds pipeline.

The previous source already contained the button code, but it was placed after the main odds table. The supplied screenshots show the runtime card without the button, so this version moves it to a prominent, deterministic position near the top of each card.
