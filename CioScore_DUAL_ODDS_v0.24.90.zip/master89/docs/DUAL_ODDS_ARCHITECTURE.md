# CioScore v0.24.85 — Dual Odds Architecture

## Main match card
The second ZIP's behavior is preserved:
- Official Iddaa MS1/MSX/MS2 is shown directly in the card.
- Bet365 MS1/MSX/MS2 is fetched per match through the existing serialized odds queue.
- Bet365 fallback order remains GoalLineExpert -> SofaScore -> Flashscore -> WinComparator.

## ORANLAR button
The first ZIP's interaction is restored inside the same card:
- `📊 ORANLAR` is rendered on every match card.
- Tapping it opens a per-match bottom sheet.
- The panel initially exposes exactly two bureaus: `İddaa.com` and `Bet365`.
- The panel uses `OddsPanelService`, separate from the main-card odds queue/cache.

## Future bookmakers
Additional panel bookmakers should be added inside `OddsPanelService` as independent providers. The ScoreModel, official Iddaa verification, prediction-source merge, and main-card renderer do not need to change.

## Important separation
There are intentionally two odds presentations for the same fixture:
1. **Automatic main-card odds** from the second ZIP.
2. **On-demand ORANLAR panel** from the first ZIP concept.

They are not mutually exclusive and neither is used as an identity/verification gate for the score-analysis pipeline.
