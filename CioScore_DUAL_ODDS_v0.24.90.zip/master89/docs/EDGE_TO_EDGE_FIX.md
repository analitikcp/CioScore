# Edge-to-edge bottom safe-area fix — v0.24.88

The previous RecyclerView-only bottom padding did not reliably prevent the final match card from appearing underneath Android navigation controls on edge-to-edge devices.

This version uses a dedicated `bottomSystemSpacer` **outside** the RecyclerView. Its height is driven by the navigation-bar inset with a conservative 104dp minimum. The final card therefore has a real layout area after it and can always be scrolled fully above the system navigation surface. RecyclerView bottom padding remains as a secondary safeguard.

No ScoreModel, odds provider, bookmaker fallback, Iddaa verification, or match-card odds logic was changed.
