# Bwin ORANLAR adapteri

v0.24.90 adds Bwin as the third bookmaker in the independent ORANLAR panel.

- The main-card Iddaa + Bet365 renderer is unchanged.
- The existing Bet365 fallback chain is unchanged.
- `BwinOddsService` is a separate provider adapter.
- The adapter discovers the current Bwin provider id from the odds-provider catalogue, resolves the same fixture independently, and reads only full-time 1X2.
- Bwin has its own 5-minute panel cache and trace fields.
- If Bwin is unavailable, the panel reports the miss without suppressing Iddaa or Bet365.

This adapter is intentionally small so additional bookmakers can follow the same provider-local contract.
