package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun getFast(url: String, referer: String? = null): Pair<Int, String?> {
        val requestBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")

        if (!referer.isNullOrBlank()) requestBuilder.header("Referer", referer)

        val fastClient = client.newBuilder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(9, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build()

        return try {
            fastClient.newCall(requestBuilder.build()).execute().use { response ->
                response.code to response.body?.string()
            }
        } catch (e: SocketTimeoutException) {
            -100 to "Socket Timeout: ${e.localizedMessage ?: "timeout"}"
        } catch (e: UnknownHostException) {
            -101 to "DNS/Host Error: ${e.localizedMessage ?: "unknown host"}"
        } catch (e: SSLHandshakeException) {
            -102 to "SSL Error: ${e.localizedMessage ?: "handshake failed"}"
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown Network Error"}"
        }
    }


    /**
     * Browser-like fetch for stricter sites. This is deliberately conservative:
     * it does not attempt to defeat CAPTCHA/JS challenges or other access controls.
     * A 403 is retried once with a normal desktop browser profile because some
     * CDNs return different responses based on the requested client profile.
     */
    fun getSource(url: String, referer: String): Pair<Int, String?> {
        val profiles = listOf(
            BrowserProfile(
                userAgent = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
                accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
            ),
            BrowserProfile(
                userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
            )
        )

        var lastCode = -1
        var lastBody: String? = null

        for ((index, profile) in profiles.withIndex()) {
            val sourceClient = client.newBuilder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(14, TimeUnit.SECONDS)
                .callTimeout(18, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", profile.userAgent)
                    .header("Accept", profile.accept)
                    .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                    .header("Cache-Control", "no-cache")
                    .header("Pragma", "no-cache")
                    .header("Referer", referer)
                    .header("Upgrade-Insecure-Requests", "1")
                    .header("Sec-Fetch-Dest", "document")
                    .header("Sec-Fetch-Mode", "navigate")
                    .header("Sec-Fetch-Site", "same-origin")
                    .header("Sec-Fetch-User", "?1")
                    .build()

                sourceClient.newCall(request).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string()

                    if (response.isSuccessful) return response.code to lastBody

                    // Do not retry normal client errors or server errors here.
                    // Only a second ordinary browser profile is worth trying for 403.
                    if (response.code != 403 || index == profiles.lastIndex) {
                        return response.code to lastBody
                    }
                }
            } catch (e: Exception) {
                lastCode = when (e) {
                    is SocketTimeoutException -> -100
                    is UnknownHostException -> -101
                    is SSLHandshakeException -> -102
                    else -> -1
                }
                lastBody = e.localizedMessage
            }
        }

        return lastCode to lastBody
    }

    private data class BrowserProfile(
        val userAgent: String,
        val accept: String
    )

    fun get(url: String, referer: String? = null): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null

        repeat(2) { attempt ->
            val requestBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36")
                .header("Accept", if (url.contains("api.sofascore.com") || url.contains("lsapp.eu")) "application/json,text/plain,*/*" else "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")

            if (!referer.isNullOrBlank()) requestBuilder.header("Referer", referer)
            if (url.contains("flashscore") || url.contains("lsapp.eu")) {
                requestBuilder.header("x-fsign", "SW9D1eZo")
                requestBuilder.header("Origin", "https://www.flashscore.com")
            }

            try {
                client.newCall(requestBuilder.build()).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string()
                    if (response.isSuccessful || response.code in 400..499 && response.code != 429) {
                        return response.code to lastBody
                    }
                }
            } catch (_: Exception) {
                lastCode = -1
                lastBody = null
            }

            if (attempt == 0 && (lastCode == 429 || lastCode >= 500 || lastCode == -1)) {
                Thread.sleep(700)
            }
        }

        return lastCode to lastBody
    }
}
