package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import java.util.Locale

/**
 * Independent Bwin 1X2 adapter for the ORANLAR panel.
 *
 * This adapter deliberately does not modify ScoreModel, Iddaa verification or
 * the main-card Bet365 pipeline. It resolves the fixture, discovers the Bwin
 * provider id from the current odds catalogue, and reads only full-time 1X2.
 */
class BwinOddsService {
    data class Odds(val ms1: String, val msX: String, val ms2: String)
    data class LookupResult(
        val odds: Odds?,
        val source: String?,
        val attemptedSources: List<String>,
        val errors: List<String>
    )

    private data class EventRef(val id: Long, val home: String, val away: String)
    private data class Provider(val id: Long, val name: String, val slug: String, val weight: Int)

    private val http = HttpClient()
    private val base = "https://api.sofascore.com/api/v1"

    suspend fun fetch(homeTeam: String, awayTeam: String): Odds? =
        fetchWithTrace(homeTeam, awayTeam).odds

    suspend fun fetchWithTrace(homeTeam: String, awayTeam: String): LookupResult = withContext(Dispatchers.IO) {
        val attempted = mutableListOf<String>()
        val errors = mutableListOf<String>()

        attempted += "SofaScore/Bwin provider"
        val provider = runCatching { findBwinProvider() }
            .onFailure { errors += "provider:${it.javaClass.simpleName}" }
            .getOrNull()

        if (provider == null) {
            return@withContext LookupResult(null, null, attempted, errors + "Bwin provider not found")
        }

        attempted += "SofaScore/Bwin odds"
        val event = runCatching { findEvent(homeTeam, awayTeam) }
            .onFailure { errors += "event:${it.javaClass.simpleName}" }
            .getOrNull()

        if (event == null) {
            return@withContext LookupResult(null, "SofaScore/Bwin provider ${provider.name}", attempted, errors + "fixture not found")
        }

        val odds = runCatching { loadProviderOdds(event.id, provider.id) }
            .onFailure { errors += "odds:${it.javaClass.simpleName}" }
            .getOrNull()

        if (odds != null) {
            return@withContext LookupResult(odds, "SofaScore/${provider.name}", attempted, errors)
        }

        LookupResult(null, "SofaScore/${provider.name}", attempted, errors + "complete 1X2 not found")
    }

    private fun findBwinProvider(): Provider? {
        val regions = listOf("INT", "DE", "FR", "GB", "TR")
        val providers = mutableListOf<Provider>()
        for (region in regions) {
            val (code, body) = http.get("$base/odds/providers/$region/web", "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            providers += parseProviders(body)
        }
        return providers
            .distinctBy { it.id }
            .filter { it.name.contains("bwin", true) || it.slug.contains("bwin", true) }
            .maxByOrNull { it.weight }
    }

    private fun parseProviders(body: String): List<Provider> = runCatching {
        val root = body.trim()
        val array = if (root.startsWith("[")) JSONArray(root) else {
            val obj = JSONObject(root)
            obj.optJSONArray("providers") ?: obj.optJSONArray("data") ?: obj.optJSONArray("items") ?: JSONArray()
        }
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val wrapper = item.optJSONObject("provider")
                val fallback = item.optJSONObject("fallbackProvider")
                val oddsFrom = wrapper?.optJSONObject("oddsFrom")
                val liveOddsFrom = wrapper?.optJSONObject("liveOddsFrom")
                val candidates = listOfNotNull(fallback, oddsFrom, liveOddsFrom, wrapper, item)
                val source = candidates.firstOrNull { it.optLong("id", -1L) > 0L } ?: continue
                val id = source.optLong("id", -1L)
                val name = source.optString("name").trim()
                    .ifBlank { wrapper?.optString("name")?.trim().orEmpty() }
                    .ifBlank { item.optString("name").trim() }
                val slug = source.optString("slug").trim()
                    .ifBlank { wrapper?.optString("slug")?.trim().orEmpty() }
                    .ifBlank { item.optString("slug").trim() }
                val weight = item.optInt("weight", wrapper?.optInt("weight", 0) ?: 0)
                if (id > 0 && name.isNotBlank()) add(Provider(id, name, slug, weight))
            }
        }
    }.getOrDefault(emptyList())

    private fun findEvent(homeTeam: String, awayTeam: String): EventRef? {
        val today = LocalDate.now()
        val dates = listOf(today.minusDays(1), today, today.plusDays(1), today.plusDays(2))
        dates.forEach { date ->
            loadEventsForDate(date).firstOrNull { oddsTeamsSame(it.home, homeTeam) && oddsTeamsSame(it.away, awayTeam) }
                ?.let { return it }
        }
        val query = URLEncoder.encode("$homeTeam $awayTeam", Charsets.UTF_8.name())
        val urls = listOf("$base/search/events/?q=$query&page=0", "$base/search/events?q=$query&page=0")
        for (url in urls) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            val results = runCatching { JSONObject(body).optJSONArray("results") }.getOrNull() ?: continue
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val event = item.optJSONObject("event") ?: item.optJSONObject("entity") ?: item
                val id = event.optLong("id", -1L)
                val home = event.optJSONObject("homeTeam")?.optString("name").orEmpty()
                val away = event.optJSONObject("awayTeam")?.optString("name").orEmpty()
                if (id > 0 && oddsTeamsSame(home, homeTeam) && oddsTeamsSame(away, awayTeam)) return EventRef(id, home, away)
            }
        }
        return null
    }

    private fun loadEventsForDate(date: LocalDate): List<EventRef> {
        val (code, body) = http.get("$base/sport/football/scheduled-events/$date", "https://www.sofascore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return runCatching {
            val events = JSONObject(body).optJSONArray("events") ?: return@runCatching emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val id = e.optLong("id", -1L)
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) add(EventRef(id, home, away))
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun loadProviderOdds(eventId: Long, providerId: Long): Odds? {
        val paths = listOf(
            "$base/event/$eventId/odds/$providerId/featured",
            "$base/event/$eventId/odds/$providerId/all"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseOdds(JSONObject(body))?.let { return it }
        }
        return null
    }

    private fun parseOdds(root: JSONObject): Odds? {
        fun choices(value: JSONObject): Odds? {
            val array = value.optJSONArray("choices") ?: return null
            var one: String? = null
            var draw: String? = null
            var two: String? = null
            for (i in 0 until array.length()) {
                val c = array.optJSONObject(i) ?: continue
                val name = c.optString("name").trim().uppercase(Locale.US)
                val decimal = c.opt("decimalValue")?.toString()?.toDoubleOrNull()
                    ?: fractionalToDecimal(c.optString("fractionalValue"))
                if (decimal == null || decimal <= 1.0 || decimal > 100.0) continue
                val formatted = String.format(Locale.US, "%.2f", decimal)
                when (name) { "1", "HOME" -> one = formatted; "X", "DRAW" -> draw = formatted; "2", "AWAY" -> two = formatted }
            }
            return if (one != null && draw != null && two != null) Odds(one!!, draw!!, two!!) else null
        }

        root.optJSONObject("featured")?.let { featured ->
            val keys = featured.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val market = featured.optJSONObject(key) ?: continue
                val id = market.optInt("marketId", -1)
                val name = market.optString("marketName").lowercase(Locale.US)
                if (id == 1 || name.contains("full time") || key.equals("default", true) || key.equals("fullTime", true)) choices(market)?.let { return it }
            }
        }
        root.optJSONObject("odds")?.let { parseOdds(it)?.let { return it } }
        root.optJSONArray("markets")?.let { markets ->
            for (i in 0 until markets.length()) {
                val market = markets.optJSONObject(i) ?: continue
                val id = market.optInt("marketId", -1)
                val name = market.optString("marketName").lowercase(Locale.US)
                if (id == 1 || name.contains("full time") || name == "1x2") choices(market)?.let { return it }
            }
        }
        return null
    }

    private fun fractionalToDecimal(value: String): Double? {
        val parts = value.trim().split('/')
        if (parts.size != 2) return null
        val a = parts[0].toDoubleOrNull() ?: return null
        val b = parts[1].toDoubleOrNull() ?: return null
        if (b == 0.0) return null
        return 1.0 + a / b
    }

    private fun oddsTeamKey(value: String): String =
        MatchMerger.normalizeTeamName(value).lowercase(Locale.US).replace("'", "")
            .split(Regex("\\s+"))
            .filterNot { it in setOf("k", "w", "f", "women", "woman", "womens", "female", "ladies", "ue", "fc", "cf", "afc", "sc", "ac", "as", "sk", "cd") }
            .joinToString("")

    private fun oddsTeamsSame(actual: String, wanted: String): Boolean {
        if (MatchMerger.isSameTeam(actual, wanted)) return true
        val a = oddsTeamKey(actual)
        val b = oddsTeamKey(wanted)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        return a.length >= 7 && b.length >= 7 && (a.contains(b) || b.contains(a))
    }
}
