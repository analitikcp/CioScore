package com.cio.skor.data

import android.content.Context

/**
 * Independent odds-panel pipeline.
 *
 * This service is deliberately isolated from the main-card odds queue. The
 * panel owns its own provider list and can grow without touching ScoreModel,
 * the official Iddaa verification flow, or the main-card odds renderer.
 */
class OddsPanelService(context: Context) {
    data class OddsRow(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String,
        val primary: Boolean = false
    )

    data class LookupResult(
        val row: OddsRow?,
        val source: String?,
        val attemptedSources: List<String>,
        val errors: List<String>
    )

    private val bet365 = SofaScoreService(context)
    private val bwin = BwinOddsService()
    private val bet365Cache = mutableMapOf<String, Pair<Long, LookupResult>>()
    private val bwinCache = mutableMapOf<String, Pair<Long, LookupResult>>()
    private val cacheTtlMs = 5 * 60 * 1000L

    /** Bookmakers exposed by the panel. Add future providers here only. */
    fun supportedBookmakers(): List<String> = listOf("İddaa.com", "Bet365", "Bwin")

    suspend fun fetchBet365(homeTeam: String, awayTeam: String): OddsRow? =
        fetchBet365WithTrace(homeTeam, awayTeam).row

    suspend fun fetchBet365WithTrace(homeTeam: String, awayTeam: String): LookupResult {
        val key = cacheKey(homeTeam, awayTeam)
        val now = System.currentTimeMillis()
        synchronized(bet365Cache) {
            bet365Cache[key]?.takeIf { now - it.first < cacheTtlMs }?.second?.let { return it }
            bet365Cache.remove(key)
        }

        val lookup = bet365.fetchBet365WithTrace(homeTeam, awayTeam)
        val result = LookupResult(
            row = lookup.rows.firstOrNull { it.bookmaker.contains("Bet365", true) }?.let {
                OddsRow("Bet365", it.ms1, it.msX, it.ms2, primary = true)
            },
            source = lookup.source,
            attemptedSources = lookup.attemptedSources,
            errors = lookup.errors
        )
        synchronized(bet365Cache) { bet365Cache[key] = now to result }
        return result
    }


    suspend fun fetchBwinWithTrace(homeTeam: String, awayTeam: String): LookupResult {
        val key = cacheKey(homeTeam, awayTeam)
        val now = System.currentTimeMillis()
        synchronized(bwinCache) {
            bwinCache[key]?.takeIf { now - it.first < cacheTtlMs }?.second?.let { return it }
            bwinCache.remove(key)
        }
        val lookup = bwin.fetchWithTrace(homeTeam, awayTeam)
        val result = LookupResult(
            row = lookup.odds?.let { OddsRow("Bwin", it.ms1, it.msX, it.ms2, primary = false) },
            source = lookup.source,
            attemptedSources = lookup.attemptedSources,
            errors = lookup.errors
        )
        synchronized(bwinCache) { bwinCache[key] = now to result }
        return result
    }

    fun iddaaRow(ms1: String?, msX: String?, ms2: String?): OddsRow? {
        if (ms1 == null && msX == null && ms2 == null) return null
        return OddsRow(
            bookmaker = "İddaa.com",
            ms1 = ms1 ?: "-",
            msX = msX ?: "-",
            ms2 = ms2 ?: "-"
        )
    }

    private fun cacheKey(home: String, away: String): String =
        "${MatchMerger.normalizeTeamName(home)}::${MatchMerger.normalizeTeamName(away)}"
}
