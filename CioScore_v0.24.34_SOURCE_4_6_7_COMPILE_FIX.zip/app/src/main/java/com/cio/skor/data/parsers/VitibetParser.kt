package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Vitibet/Vitisport parser. Uses stable textual markers first, DOM selectors second. */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Current quicktips pages expose rows as plain text:
        // 13:30 Tottenham 1 : 0 Aston Villa INDEX +0.98 ... Tip 1-0 1X
        // Parse these rows from the complete document text so CSS-class changes
        // cannot make the source silently return zero scores.
        val body = clean(doc.body()?.text().orEmpty())
        val rowRegex = Regex(
            "(?i)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(\\d{1,2})\\s*:\\s*(\\d{1,2})\\s+(?:Tip|Ipucu|Vihje|Dica)\\s+(?:1X|X2|1|X|2)?\\s*(.+?)(?=\\s+INDEX\\b|$)"
        )
        for (m in rowRegex.findAll(body)) {
            val home = cleanTeam(m.groupValues[2])
            val away = cleanTeam(m.groupValues[5])
            val score = "${m.groupValues[3].toIntOrNull() ?: continue}-${m.groupValues[4].toIntOrNull() ?: continue}"
            build(home, away, score)?.let { out[it.matchKey] = it }
        }

        // Fallback for DOM variants where the predicted score is only exposed
        // as Tip/Ipucu and not as an inline H : A value.
        if (out.isEmpty()) {
            for (node in doc.select("tr, article, li, div, p")) {
                parseTipContainer(node)?.let { out[it.matchKey] = it }
                if (out.size >= 250) break
            }
        }

        // Last fallback: match-detail anchors often contain exactly one fixture.
        if (out.isEmpty()) {
            for (link in doc.select("a[href]")) {
                val text = clean(link.text())
                val tip = extractTipScore(text) ?: continue
                val fixture = splitVsFixture(text) ?: continue
                build(fixture.first, fixture.second, tip)?.let { out[it.matchKey] = it }
            }
        }

        return out.values.toList()
    }

    private fun parseTipContainer(element: Element): ScoreModel? {
        val text = clean(element.text())
        val predicted = extractTipScore(text) ?: return null

        // Prefer explicit team anchors; Vitibet uses logo/team links around each row.
        val teams = element.select("a[href]")
            .map { cleanTeam(it.text()) }
            .filter { isTeamCandidate(it) }
            .distinct()
        if (teams.size >= 2) return build(teams[0], teams[1], predicted)

        // Legacy row: time + home + Tip + away.
        val tipMatch = Regex("(?i)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(?:Tip|Ipucu|Vihje|Dica)\\s+\\d{1,2}\\s*[-:]\\s*\\d{1,2}\\s+(.+?)(?=\\s+INDEX\\b|$)").find(text)
        if (tipMatch != null) {
            return build(cleanTeam(tipMatch.groupValues[2]), cleanTeam(tipMatch.groupValues[3]), predicted)
        }
        return null
    }

    private fun extractTipScore(text: String): String? = Regex(
        "(?i)\\b(?:Tip|Ipucu|Vihje|Dica)\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun splitVsFixture(raw: String): Pair<String, String>? {
        val m = Regex("(?i)^(.+?)\\s+vs\\s+(.+?)$").find(clean(raw)) ?: return null
        return cleanTeam(m.groupValues[1]) to cleanTeam(m.groupValues[2])
    }

    private fun build(homeRaw: String, awayRaw: String, score: String): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        return ScoreModel(homeTeam = home, awayTeam = away, predictedScore = score, source = source)
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..70) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|LIVE|FT|Odds|Status)\\b.*$"), "")
        .trim(' ', '-', ':', '|')
}
