package com.cio.skor.data

/** Independent odds-panel pipeline. Bet365 uses MoviOdds -> ChekiOdds -> OddsPapi. */
class OddsPanelService {
    data class OddsRow(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String,
        val primary: Boolean = false
    )

    private val bet365 = Bet365OddsService()
    private val tipsterArea = TipsterAreaOddsService()

    suspend fun fetchBet365(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): OddsRow? =
        bet365.fetch(homeTeam, awayTeam, kickoffEpochMs).odds?.let { odds ->
            OddsRow("Bet365", odds.ms1, odds.msX, odds.ms2, primary = true)
        }

    suspend fun fetchTipsterArea(homeTeam: String, awayTeam: String, matchDate: String): List<OddsRow> =
        tipsterArea.fetch(homeTeam, awayTeam, matchDate)
            .filterNot { it.bookmaker.contains("Bet365", ignoreCase = true) }
            .map { OddsRow(it.bookmaker, it.ms1, it.msX, it.ms2) }

    fun iddaaRow(ms1: String?, msX: String?, ms2: String?): OddsRow? {
        if (ms1 == null && msX == null && ms2 == null) return null
        return OddsRow("İddaa.com", ms1 ?: "-", msX ?: "-", ms2 ?: "-")
    }
}
