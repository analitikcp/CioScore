package com.cio.skor.data

/**
 * Unified Bet365 pipeline used by all screens.
 * Order: MoviOdds -> ChekiOdds -> OddsPapi.
 */
class Bet365OddsService {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val source: String = "", val reason: String = "")

    private val movi = MoviOddsBet365Service()
    private val cheki = ChekiOddsBet365Service()
    private val oddsPapi = OddsPapiBet365Service()

    suspend fun preload(kickoffEpochMs: Collection<Long>) {
        runCatching { movi.preload() }
        runCatching { cheki.preload(kickoffEpochMs) }
        // Keep OddsPapi as a real third source, but do not fail the whole scan
        // when its optional API key has not been configured yet.
        runCatching { oddsPapi.preload() }
    }

    fun lookup(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        movi.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        cheki.lookup(homeTeam, awayTeam, kickoffEpochMs).let { if (it.odds != null) return Result(it.odds, it.reason) }
        oddsPapi.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        return Result(reason = "MoviOdds + ChekiOdds + OddsPapi: Bet365 1X2 bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        val local = lookup(homeTeam, awayTeam, kickoffEpochMs)
        if (local.odds != null) return local

        val m = movi.fetch(homeTeam, awayTeam)
        if (m.odds != null) return Result(m.odds, m.reason)
        val c = cheki.fetch(homeTeam, awayTeam, kickoffEpochMs)
        if (c.odds != null) return Result(c.odds, c.reason)
        val p = oddsPapi.fetch(homeTeam, awayTeam)
        if (p.odds != null) return Result(p.odds, p.reason)
        return Result(reason = "${m.reason}; ${c.reason}; ${p.reason}")
    }
}
