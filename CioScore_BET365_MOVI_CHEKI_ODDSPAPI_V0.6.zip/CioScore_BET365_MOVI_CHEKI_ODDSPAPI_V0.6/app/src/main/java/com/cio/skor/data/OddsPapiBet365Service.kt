package com.cio.skor.data

import com.cio.skor.BuildConfig
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** Third Bet365 fallback. Requires an OddsPapi API key; empty key safely disables it. */
class OddsPapiBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")
    private data class Row(val home: String, val away: String, val odds: SofaScoreService.BookmakerOdds)

    private val http = HttpClient()
    private val rows = ConcurrentHashMap<String, Row>()
    private var loadedAt = 0L
    private val apiKey: String get() = BuildConfig.ODDS_PAPI_API_KEY.trim()

    companion object { private const val TTL_MS = 2 * 60 * 1000L }

    suspend fun preload() = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw IllegalStateException("OddsPapi API anahtarı tanımlı değil")
        if (System.currentTimeMillis() - loadedAt < TTL_MS && rows.isNotEmpty()) return@withContext
        val url = "https://api.oddspapi.io/v4/odds?apiKey=${java.net.URLEncoder.encode(apiKey, "UTF-8")}&sportId=10&bookmakers=bet365"
        val (code, body) = http.get(url, "https://oddspapi.io/")
        if (code !in 200..299 || body.isNullOrBlank()) throw IllegalStateException("OddsPapi HTTP $code")
        val parsed = parse(body)
        rows.clear(); rows.putAll(parsed); loadedAt = System.currentTimeMillis()
        if (rows.isEmpty()) throw IllegalStateException("OddsPapi Bet365 1X2 maç bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String): Result = withContext(Dispatchers.IO) {
        runCatching { preload() }.getOrElse { return@withContext Result(reason = "OddsPapi: ${it.message}") }
        lookup(homeTeam, awayTeam)
    }

    fun lookup(homeTeam: String, awayTeam: String): Result {
        val exact = rows[fixtureKey(homeTeam, awayTeam)]
        if (exact != null) return Result(exact.odds, "OddsPapi • Bet365 1X2")
        val best = rows.values.asSequence()
            .map { it to ((TeamAliasCanonicalizer.similarity(homeTeam, it.home) + TeamAliasCanonicalizer.similarity(awayTeam, it.away)) / 2.0) }
            .filter { it.second >= 0.84 }
            .maxByOrNull { it.second }?.first
        return best?.let { Result(it.odds, "OddsPapi • Bet365 1X2") }
            ?: Result(reason = "OddsPapi'da Bet365 1X2 eşleşmesi bulunamadı")
    }

    internal fun parse(body: String): Map<String, Row> {
        val root = JSONObject(body)
        val data = root.optJSONArray("data") ?: root.optJSONArray("fixtures") ?: JSONArray()
        val out = HashMap<String, Row>()
        for (i in 0 until data.length()) {
            val fixture = data.optJSONObject(i) ?: continue
            val participants = fixture.optJSONObject("participants")
            val home = participants?.optJSONObject("home")?.optString("name").orEmpty().trim()
            val away = participants?.optJSONObject("away")?.optString("name").orEmpty().trim()
            if (home.isBlank() || away.isBlank()) continue
            val bookmaker = fixture.optJSONObject("bookmakerOdds")?.optJSONObject("bet365") ?: continue
            val markets = bookmaker.optJSONObject("markets") ?: continue
            val market = markets.optJSONObject("101") ?: findWinnerMarket(markets) ?: continue
            val values = extractOneXTwo(market, home, away)
            if (values != null) out[fixtureKey(home, away)] = Row(home, away, SofaScoreService.BookmakerOdds("Bet365", values[0], values[1], values[2]))
        }
        return out
    }

    private fun findWinnerMarket(markets: JSONObject): JSONObject? {
        val keys = markets.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val obj = markets.optJSONObject(key) ?: continue
            val name = obj.optString("name") + " " + obj.optString("marketName")
            if (name.contains("match winner", true) || name.contains("full time result", true) || name.equals("1X2", true)) return obj
        }
        return null
    }

    private fun extractOneXTwo(market: JSONObject, home: String, away: String): List<String>? {
        val selections = market.optJSONArray("selections") ?: market.optJSONArray("outcomes") ?: return null
        var h: String? = null; var d: String? = null; var a: String? = null
        for (i in 0 until selections.length()) {
            val s = selections.optJSONObject(i) ?: continue
            val label = (s.optString("name") + " " + s.optString("label") + " " + s.optString("selectionName")).trim()
            val odd = s.optDouble("odds", Double.NaN).takeIf { it.isFinite() } ?: s.optDouble("price", Double.NaN)
            if (!odd.isFinite() || odd <= 1.0 || odd > 1000.0) continue
            val value = odd.toString()
            when {
                label.equals(home, true) || label.equals("1", true) || label.contains(home, true) -> h = value
                label.equals(away, true) || label.equals("2", true) || label.contains(away, true) -> a = value
                label.equals("X", true) || label.contains("draw", true) || label.contains("tie", true) -> d = value
            }
        }
        return if (h != null && d != null && a != null) listOf(h!!, d!!, a!!) else null
    }

    private fun fixtureKey(home: String, away: String): String =
        "${MatchMerger.canonicalTeamId(home)}||${MatchMerger.canonicalTeamId(away)}"
}
