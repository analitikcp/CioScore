package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.cio.skor.data.AiScoreMatch
import com.cio.skor.data.AiScoreRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/**
 * AiScore-style match flow. It is intentionally a separate screen: the
 * existing CioScore prediction/Iddaa pipeline remains untouched.
 */
class AiScoreMatchListActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = AiScoreRepository()
    private lateinit var listRoot: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var matches: List<AiScoreMatch> = emptyList()
    private var officialPairs: List<AiScoreRepository.OfficialFixtureLite> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val homes = intent.getStringArrayListExtra(EXTRA_OFFICIAL_HOMES).orEmpty()
        val aways = intent.getStringArrayListExtra(EXTRA_OFFICIAL_AWAYS).orEmpty()
        officialPairs = homes.zip(aways).map { AiScoreRepository.OfficialFixtureLite(it.first, it.second) }
        setContentView(buildContent())
        load()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).roundToInt()

    private fun message(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(0xFFCBD5E1.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(20), dp(16), dp(20))
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF11161B.toInt())
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
            setBackgroundColor(0xFF20262D.toInt())
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = "‹"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { finish() }
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        })
        titleRow.addView(TextView(this).apply {
            text = "AiScore Maç Listesi"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val refresh = Button(this).apply {
            text = "↻"
            textSize = 18f
            setOnClickListener { load() }
            setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF374151.toInt())
        }
        titleRow.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(42)))
        header.addView(titleRow)
        header.addView(TextView(this).apply {
            text = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy, EEEE", Locale("tr", "TR")))
            textSize = 12f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "AiScore fikstürü • Bet365 1X2 • İddaa çapraz eşleşmesi"
            textSize = 11f
            setTextColor(0xFF94A3B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        root.addView(header)

        status = TextView(this).apply {
            text = "Maçlar yükleniyor…"
            textSize = 12f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this).apply { isIndeterminate = true }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        listRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(110))
        }
        scroll.addView(listRoot)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun load() {
        progress.visibility = View.VISIBLE
        status.text = "AiScore fikstürü + Bet365 (MoviOdds→ChekiOdds→OddsPapi) 1X2 alınıyor…"
        listRoot.removeAllViews()
        scope.launch {
            val loaded = withContext(Dispatchers.IO) { repository.fetchToday(officialPairs) }
            val bet365Service = com.cio.skor.data.Bet365OddsService()
            val kickoffs = loaded.map { kickoffTimestamp(it.matchTime) }
            runCatching { bet365Service.preload(kickoffs) }
            val mapped = loaded.map { match ->
                val kickoff = kickoffTimestamp(match.matchTime)
                val odds = runCatching {
                    bet365Service.lookup(match.homeTeam, match.awayTeam, kickoff).odds
                }.getOrNull()
                if (odds == null) match else match.copy(
                    bet365 = com.cio.skor.data.Bet365OpeningClosing(
                        latestHome = odds.ms1, latestDraw = odds.msX, latestAway = odds.ms2,
                        latestCapturedAt = System.currentTimeMillis()
                    )
                )
            }
            matches = mapped
            progress.visibility = View.GONE
            if (mapped.isEmpty()) {
                status.text = "AiScore maç listesi alınamadı."
                listRoot.addView(message("AiScore sayfası erişilemez veya sayfa yapısı değişmiş olabilir."))
                return@launch
            }
            val hitCount = mapped.count { it.bet365.hasLatest() }
            status.text = "${mapped.size} maç • Bet365 eşleşmesi: $hitCount"
            render(mapped)
        }
    }

    private fun render(items: List<AiScoreMatch>) {
        listRoot.removeAllViews()
        var lastLeague = ""
        items.forEach { match ->
            val league = match.leagueName.ifBlank { "AiScore" }
            if (league != lastLeague) {
                lastLeague = league
                listRoot.addView(TextView(this).apply {
                    text = "⚽ $league"
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFFFFC107.toInt())
                    setPadding(dp(8), dp(10), dp(8), dp(5))
                })
            }
            listRoot.addView(matchCard(match))
        }
    }

    private fun matchCard(match: AiScoreMatch): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xFF192027.toInt())
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(5)
            }
            setOnClickListener { showOdds(match) }
        }

        card.addView(TextView(this).apply {
            text = match.matchTime
            textSize = 12f
            setTextColor(0xFF9CA3AF.toInt())
            gravity = Gravity.TOP
            layoutParams = LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        val teams = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        teams.addView(teamText(match.homeTeam, true))
        teams.addView(teamText(match.awayTeam, false))
        if (match.iddaaMatched) teams.addView(TextView(this).apply {
            text = "✓ İDDAA eşleşti"
            textSize = 9f
            setTextColor(0xFF34D399.toInt())
        })
        card.addView(teams)

        val hasOdds = match.bet365.hasLatest()
        val odds = TextView(this).apply {
            text = if (hasOdds) "${match.bet365.latestHome}\n${match.bet365.latestDraw}\n${match.bet365.latestAway}" else "-\n-\n-"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(if (hasOdds) 0xFF34D399.toInt() else 0xFFCBD5E1.toInt())
            tag = match.matchId
            layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        card.addView(odds)
        card.tag = match.matchId
        card.setOnLongClickListener {
            showOdds(match)
            true
        }
        return card
    }

    private fun teamText(name: String, bold: Boolean): TextView = TextView(this).apply {
        text = name
        textSize = 14f
        setTextColor(0xFFF1F5F9.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }


    private fun showOdds(match: AiScoreMatch) {
        val sheet = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(0xFFF8FAFC.toInt())
        }
        fun label(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(0xFF101828.toInt())
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        root.addView(label("ORAN ANALİZİ", 20f, true))
        root.addView(label("${match.homeTeam}  -  ${match.awayTeam}", 14f, true))
        root.addView(label("Kaynak: MoviOdds → ChekiOdds → OddsPapi • Bet365 • MS1 / MSX / MS2", 11f))
        if (match.bet365.hasLatest()) {
            root.addView(label("MS1: ${match.bet365.latestHome}", 14f))
            root.addView(label("MSX: ${match.bet365.latestDraw}", 14f))
            root.addView(label("MS2: ${match.bet365.latestAway}", 14f))
        } else {
            root.addView(label("Bu maç için Bet365 1X2 bulunamadı.", 12f))
        }
        sheet.setContentView(root)
        sheet.show()
    }

    private fun formatEpoch(epochSec: Long): String = Instant.ofEpochSecond(epochSec)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("dd.MM HH:mm:ss", Locale("tr", "TR")))


    private fun kickoffTimestamp(time: String): Long {
        val parts = time.split(':')
        if (parts.size != 2) return System.currentTimeMillis()
        val now = ZonedDateTime.now()
        return now.withHour(parts[0].toIntOrNull() ?: now.hour)
            .withMinute(parts[1].toIntOrNull() ?: now.minute)
            .withSecond(0).withNano(0)
            .toInstant().toEpochMilli()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_OFFICIAL_HOMES = "AISCORE_OFFICIAL_HOMES"
        const val EXTRA_OFFICIAL_AWAYS = "AISCORE_OFFICIAL_AWAYS"
    }
}
