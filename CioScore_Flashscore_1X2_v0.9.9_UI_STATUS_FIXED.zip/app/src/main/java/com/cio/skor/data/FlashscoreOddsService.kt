package com.cio.skor.data

import android.util.Log
import com.cio.skor.data.SofaScoreService.MatchGroupData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Flashscore 1X2 background enrichment.
 *
 * v0.9.7 deliberately does NOT scrape the rendered Flashscore HTML. The match
 * list is obtained from Flashscore's compact x/feed payload (AA = event id,
 * AE/AF = home/away) and odds are resolved from the odds JSON service.
 *
 * This service is fail-fast and independent from the main CIO scan.
 */
class FlashscoreOddsService {
    data class Odds(val home: String, val draw: String, val away: String)

    private data class FlashEvent(
        val id: String,
        val home: String,
        val away: String
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .callTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val semaphore = Semaphore(4)

    suspend fun enrich(
        groups: List<MatchGroupData>,
        onProgress: (completed: Int, found: Int, total: Int) -> Unit = { _, _, _ -> },
        onItem: (group: MatchGroupData) -> Unit = {}
    ): List<MatchGroupData> = supervisorScope {
        if (groups.isEmpty()) return@supervisorScope groups

        val events = loadTodayEvents()
        Log.d(TAG, "EVENT_INDEX size=${events.size}")

        if (events.isEmpty()) {
            onProgress(groups.size, 0, groups.size)
            return@supervisorScope groups
        }

        var completed = 0
        var found = 0
        val lock = Any()

        groups.map { group ->
            async(Dispatchers.IO) {
                try {
                    semaphore.withPermit {
                        val event = resolveEvent(group.homeTeam, group.awayTeam, events)
                        val odds = event?.let { loadOdds(it.id) }
                        val result = group.copy(
                            odds = odds?.let { SofaScoreService.Odds(it.home, it.draw, it.away) }
                        )

                        if (odds != null) {
                            Log.d(TAG, "ODDS_OK ${group.homeTeam} - ${group.awayTeam}: ${odds.home}/${odds.draw}/${odds.away}")
                            onItem(result)
                        } else if (event == null) {
                            Log.d(TAG, "MATCH_NOT_FOUND ${group.homeTeam} - ${group.awayTeam}")
                        } else {
                            Log.d(TAG, "ODDS_EMPTY event=${event.id} ${group.homeTeam} - ${group.awayTeam}")
                        }

                        val progress = synchronized(lock) {
                            completed += 1
                            if (odds != null) found += 1
                            Triple(completed, found, groups.size)
                        }
                        onProgress(progress.first, progress.second, progress.third)
                        result
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "ENRICH_FAIL ${group.homeTeam} - ${group.awayTeam}: ${e.javaClass.simpleName}")
                    val progress = synchronized(lock) {
                        completed += 1
                        Triple(completed, found, groups.size)
                    }
                    onProgress(progress.first, progress.second, progress.third)
                    group
                }
            }
        }.awaitAll()
    }

    private fun loadTodayEvents(): List<FlashEvent> {
        // Flashscore feed layout has changed host/language variants over time.
        // Keep a very small fallback set, but stop as soon as one valid feed is parsed.
        val feeds = listOf(
            "https://www.flashscore.com/x/feed/f_1_0_3_en-gb_1",
            "https://www.flashscore.com/x/feed/f_1_0_3_en_1",
            "https://d.flashscore.com/x/feed/f_1_0_3_en_1"
        )

        for (url in feeds) {
            val body = get(url, "https://www.flashscore.com/football/") ?: continue
            val parsed = parseFeed(body)
            Log.d(TAG, "FEED url=$url parsed=${parsed.size}")
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parseFeed(raw: String): List<FlashEvent> {
        if (!raw.contains('÷')) return emptyList()

        val out = LinkedHashMap<String, FlashEvent>()
        for (section in raw.split('~')) {
            val fields = HashMap<String, String>()
            for (part in section.split('¬')) {
                val at = part.indexOf('÷')
                if (at <= 0) continue
                fields[part.substring(0, at)] = part.substring(at + 1)
            }

            val id = fields["AA"].orEmpty().trim()
            val home = fields["AE"].orEmpty().trim()
            val away = fields["AF"].orEmpty().trim()
            if (id.isNotBlank() && home.isNotBlank() && away.isNotBlank()) {
                out[id] = FlashEvent(id, home, away)
            }
        }
        return out.values.toList()
    }

    private fun resolveEvent(home: String, away: String, events: List<FlashEvent>): FlashEvent? {
        return events
            .asSequence()
            .map { it to teamPairScore(home, away, it.home, it.away) }
            .filter { it.second >= 0.72 }
            .maxByOrNull { it.second }
            ?.first
    }

    private fun loadOdds(eventId: String): Odds? {
        // Project 2/global is the current flashscore.com odds service. Project 46
        // is retained only as a short fallback because some regional feeds use it.
        val urls = listOf(
            "https://global.ds.lsapp.eu/odds/pq_graphql?_hash=oce&eventId=$eventId&projectId=2&geoIpCode=TR",
            "https://46.ds.lsapp.eu/pq_graphql?_hash=ope&eventId=$eventId&projectId=46&geoIpCode=TR"
        )

        for (url in urls) {
            val body = get(url, "https://www.flashscore.com/") ?: continue
            try {
                val root = JSONObject(body)
                findThreeWayOdds(root)?.let { return it }
            } catch (e: Exception) {
                Log.w(TAG, "ODDS_PARSE_FAIL event=$eventId ${e.javaClass.simpleName}")
            }
        }
        return null
    }

    /**
     * The exact persisted-query nesting can change. Walk the JSON and select a
     * FULL_TIME market containing three plausible decimal prices. This avoids
     * binding the app to one fragile object path while still requiring a 1X2 shape.
     */
    private fun findThreeWayOdds(value: Any?): Odds? {
        when (value) {
            is JSONObject -> {
                val scope = value.optString("bettingScope", "")
                val type = value.optString("bettingType", "")
                val arr = value.optJSONArray("odds")

                if (arr != null && arr.length() >= 3 &&
                    (scope.equals("FULL_TIME", true) || scope.isBlank()) &&
                    !type.contains("OVER_UNDER", true) &&
                    !type.contains("HANDICAP", true)
                ) {
                    val nums = mutableListOf<Double>()
                    for (i in 0 until minOf(arr.length(), 3)) {
                        val item = arr.opt(i)
                        val n = when (item) {
                            is JSONObject -> item.opt("value").toString().toDoubleOrNull()
                            is Number -> item.toDouble()
                            is String -> item.toDoubleOrNull()
                            else -> null
                        }
                        if (n != null) nums += n
                    }
                    if (nums.size == 3 && nums.all { it > 1.0 && it < 100.0 }) {
                        return Odds(format(nums[0]), format(nums[1]), format(nums[2]))
                    }
                }

                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    findThreeWayOdds(value.opt(key))?.let { return it }
                }
            }
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    findThreeWayOdds(value.opt(i))?.let { return it }
                }
            }
        }
        return null
    }

    private fun get(url: String, referer: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
            .header("Accept", "*/*")
            .header("Accept-Language", "en-GB,en;q=0.9,tr;q=0.8")
            .header("Referer", referer)
            .header("Origin", "https://www.flashscore.com")
            .header("X-Requested-With", "XMLHttpRequest")
            .header("x-fsign", "SW9D1eZo")
            .header("x-geoip", "1")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                Log.d(TAG, "HTTP ${response.code} ${request.url.host}${request.url.encodedPath}")
                if (!response.isSuccessful) null else response.body?.string()
            }
        } catch (e: Exception) {
            Log.w(TAG, "HTTP_FAIL ${request.url.host}: ${e.javaClass.simpleName}")
            null
        }
    }

    private fun teamPairScore(wantedHome: String, wantedAway: String, actualHome: String, actualAway: String): Double {
        val direct = (teamScore(wantedHome, actualHome) + teamScore(wantedAway, actualAway)) / 2.0
        val reversed = (teamScore(wantedHome, actualAway) + teamScore(wantedAway, actualHome)) / 2.0
        return maxOf(direct, reversed - 0.12)
    }

    private fun teamScore(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = normalize(a)
        val bb = normalize(b)
        if (aa.isBlank() || bb.isBlank()) return 0.0
        if (aa.contains(bb) || bb.contains(aa)) return 0.94
        val maxLen = maxOf(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]"), "")

    private fun format(value: Double): String = String.format(Locale.US, "%.2f", value)

    companion object {
        private const val TAG = "Flashscore"
    }
}
