# STEP 19 — Visible source buttons

Each score-prediction source row has a real Android `Button` on the right.

- Label: `AÇ`
- Fixed size: 64dp × 32dp
- Blue background, white text, border, elevation
- Row click and button click open the same source URL
- 8 sources: FP.com, PredictZ, WinDrawWin, DailySports, BallPrediction, Correct-Score.net, FootballScorePredictor, AccurateTip
- App version: 0.9.29

Note: this source package was not APK-built in the current environment because Gradle dependency access is unavailable.
