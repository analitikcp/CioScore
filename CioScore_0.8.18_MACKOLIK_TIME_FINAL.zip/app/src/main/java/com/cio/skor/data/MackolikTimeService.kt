package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalTime

/**
 * Mackolik is the authoritative kickoff-time feed for the UI.
 *
 * This service is intentionally separate from the five prediction sources:
 * it enriches an already merged fixture list and does not count as a CIO
 * prediction source.
 */
class MackolikTimeService(
    private val http: HttpClient = HttpClient()
) {
    data class Kickoff(
        val homeTeam: String,
        val awayTeam: String,
        val time: String,
        val timestamp: Long
    )

    private val urls = listOf(
        "https://www.mackolik.com/iddaa",
        "https://arsiv.mackolik.com/Program/Program.aspx"
    )

    suspend fun enrich(groups: List<SofaScoreService.MatchGroupData>): List<SofaScoreService.MatchGroupData> =
        withContext(Dispatchers.IO) {
            if (groups.isEmpty()) return@withContext groups

            val kickoffs = loadKickoffs()
            if (kickoffs.isEmpty()) return@withContext groups

            groups.map { group ->
                val found = kickoffs.firstOrNull {
                    MatchMerger.isSameTeam(it.homeTeam, group.homeTeam) &&
                        MatchMerger.isSameTeam(it.awayTeam, group.awayTeam)
                }

                if (found != null) {
                    group.copy(
                        matchTime = found.time,
                        timestamp = found.timestamp
                    )
                } else {
                    group
                }
            }
        }

    private fun loadKickoffs(): List<Kickoff> {
        for (url in urls) {
            val (code, html) = http.get(
                url,
                "https://www.mackolik.com/"
            )
            if (code !in 200..299 || html.isNullOrBlank()) continue

            val parsed = parse(Jsoup.parse(html, url))
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parse(doc: org.jsoup.nodes.Document): List<Kickoff> {
        val out = linkedMapOf<String, Kickoff>()

        // Current Mackolik pages expose team links inside match rows.
        // Prefer table rows first so a parent container containing many matches
        // can never combine the wrong two teams.
        val rowContainers = doc.select("tr")
        val containers = if (rowContainers.isNotEmpty()) {
            rowContainers
        } else {
            doc.select("[class*=match], [class*=fixture], [class*=event]")
        }

        for (element in containers) {
            val time = extractTime(element) ?: continue
            val teams = extractTeams(element)
            if (teams.size < 2) continue

            val home = teams[teams.size - 2]
            val away = teams[teams.size - 1]
            if (!validTeam(home) || !validTeam(away)) continue

            val timestamp = LocalDate.now()
                .atTime(LocalTime.parse(time))
                .atZone(ZoneId.systemDefault())
                .toEpochSecond()

            val key = "${MatchMerger.normalizeTeamName(home)}||${MatchMerger.normalizeTeamName(away)}"
            out[key] = Kickoff(home, away, time, timestamp)
        }

        // Fallback for markup where team names are plain text rather than links.
        if (out.isEmpty()) {
            doc.select("tr").forEach { row ->
                val text = row.text().replace(Regex("\\s+"), " ").trim()
                val time = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)\b""")
                    .find(text)?.value ?: return@forEach

                val pair = Regex("""(?i)([^|]+?)\s+-\s+([^|]+?)(?=\s+\d+[.,]\d+|\s*$)""")
                    .find(text) ?: return@forEach

                val home = cleanTeam(pair.groupValues[1])
                val away = cleanTeam(pair.groupValues[2])
                if (!validTeam(home) || !validTeam(away)) return@forEach

                val timestamp = LocalDate.now()
                    .atTime(LocalTime.parse(time))
                    .atZone(ZoneId.systemDefault())
                    .toEpochSecond()

                val key = "${MatchMerger.normalizeTeamName(home)}||${MatchMerger.normalizeTeamName(away)}"
                out[key] = Kickoff(home, away, time, timestamp)
            }
        }

        return out.values.toList()
    }

    private fun extractTeams(element: Element): List<String> =
        element.select("a[href]").mapNotNull { a ->
            val href = a.attr("href").lowercase()
            val text = a.text().replace(Regex("\\s+"), " ").trim()
            if (text.isBlank()) null
            else if (
                href.contains("/takim/") ||
                href.contains("/team/") ||
                href.contains("team")
            ) text
            else null
        }.distinct()

    private fun extractTime(element: Element): String? {
        val text = element.text().replace(Regex("\\s+"), " ").trim()
        val match = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)\b""").find(text)
            ?: return null
        return match.value.padStart(5, '0')
    }

    private fun cleanTeam(raw: String): String =
        raw.replace(Regex("""^\s*(?:[A-ZÇĞİÖŞÜ]{1,5}\s+\d+\s+)?"""), "")
            .replace(Regex("""\s{2,}"""), " ")
            .trim(' ', '|', '-')

    private fun validTeam(name: String): Boolean {
        if (name.length !in 2..80) return false
        val bad = Regex(
            """(?i)^(saat|iddaa|maç sonucu|çifte şans|alt|üst|ev sahibi|misafir|kod|ms|iy)$"""
        )
        return !bad.matches(name) && name.any { it.isLetter() }
    }
}
