package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Bet365 1X2 source backed by WBookie.
 *
 * WBookie exposes a server-rendered bookmaker comparison table where the Bet365
 * column contains MS1/MSX/MS2 in that exact order. We never infer Bet365 from
 * another bookmaker and never use the removed legacy Bet365 providers.
 */
class WBookieOddsService {
    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: String = "WBOOKIE",
        val reason: String = ""
    )

    private data class CachedPage(val expiresAt: Long, val html: String)

    private val http = HttpClient()
    private val pageCache = ConcurrentHashMap<LocalDate, CachedPage>()
    private val cacheTtlMs = 3 * 60 * 1000L
    private val zone = ZoneId.systemDefault()

    suspend fun fetch(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result =
        withContext(Dispatchers.IO) {
            val targetDate = Instant.ofEpochMilli(kickoffEpochMs).atZone(zone).toLocalDate()
            val dates = listOf(targetDate, targetDate.minusDays(1), targetDate.plusDays(1)).distinct()
            for (date in dates) {
                val html = getPage(date) ?: continue
                val row = parsePage(html, homeTeam, awayTeam)
                if (row != null) {
                    return@withContext Result(
                        odds = SofaScoreService.BookmakerOdds("Bet365", row[0], row[1], row[2]),
                        reason = "WBookie • Bet365 1X2"
                    )
                }
            }
            Result(reason = "WBookie'de Bet365 1X2 satırı bulunamadı")
        }

    private suspend fun getPage(date: LocalDate): String? {
        val now = System.currentTimeMillis()
        pageCache[date]?.takeIf { it.expiresAt > now }?.let { return it.html }
        val url = "https://www.wbookie.com/en/odds?date=${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}"
        val (code, body) = http.getSource(url, "https://www.wbookie.com/en/odds")
        if (code !in 200..299 || body.isNullOrBlank()) return null
        pageCache[date] = CachedPage(now + cacheTtlMs, body)
        return body
    }

    internal fun parsePage(html: String, homeTeam: String, awayTeam: String): List<String>? {
        val document = Jsoup.parse(html, "https://www.wbookie.com/en/odds")
        val wantedHome = normalizeTeam(homeTeam)
        val wantedAway = normalizeTeam(awayTeam)
        if (wantedHome.isBlank() || wantedAway.isBlank()) return null

        for (table in document.select("table")) {
            val header = table.select("tr").firstOrNull { row ->
                row.select("th,td").any { it.text().trim().equals("Bet365", true) } &&
                    row.select("th,td").any { it.text().contains("Pick", true) }
            } ?: continue
            val cells = header.select("th,td")
            val bet365Index = cells.indexOfFirst { it.text().trim().equals("Bet365", true) }
            if (bet365Index < 0) continue

            val rows = table.select("tr")
            val headerIndex = rows.indexOf(header)
            for (row in rows.drop(headerIndex + 1)) {
                val rowCells = row.select("td,th")
                if (rowCells.size <= bet365Index) continue
                val pair = extractTeams(row)
                if (pair == null) continue
                if (!teamsMatch(pair.first, wantedHome) || !teamsMatch(pair.second, wantedAway)) continue

                val odds = extractOdds(rowCells[bet365Index])
                if (odds.size == 3 && odds.all { isValidOdd(it) }) return odds
            }
        }
        return null
    }

    private fun extractTeams(row: Element): Pair<String, String>? {
        val matchLinks = row.select("a").map { it.text().trim() }.filter { it.isNotBlank() }
        if (matchLinks.size >= 2) {
            val likely = matchLinks.filterNot { it.startsWith("Compare", true) }
            if (likely.size >= 2) return likely.first() to likely[1]
        }

        val pickCell = row.select("td,th").getOrNull(1)
        val pickText = pickCell?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
        val m = Regex("^1\\s*[·•.]\\s*(.*?)\\s+X\\s*[·•.]\\s*(?:Draw|Nul|Tie|Empate)\\s+2\\s*[·•.]\\s*(.*)$", RegexOption.IGNORE_CASE).find(pickText)
        if (m != null) return m.groupValues[1].trim() to m.groupValues[2].trim()

        return null
    }

    private fun extractOdds(cell: Element): List<String> {
        val text = cell.text().replace(',', '.')
        return Regex("(?<![A-Za-z])\\d{1,3}(?:\\.\\d{1,3})?(?![A-Za-z])")
            .findAll(text)
            .map { it.value }
            .toList()
            .take(3)
    }

    private fun isValidOdd(value: String): Boolean =
        value.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true

    private fun teamsMatch(actual: String, wanted: String): Boolean {
        val a = normalizeTeam(actual)
        if (a == wanted) return true
        if (MatchMerger.isSameTeam(actual, wanted)) return true
        return a.length >= 6 && wanted.length >= 6 && (a.contains(wanted) || wanted.contains(a))
    }

    private fun normalizeTeam(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("[^a-z0-9]+"), "")
            .removeSuffix("fc")
            .removeSuffix("cf")
            .removeSuffix("afc")
            .removeSuffix("sc")
            .removeSuffix("ac")
}
