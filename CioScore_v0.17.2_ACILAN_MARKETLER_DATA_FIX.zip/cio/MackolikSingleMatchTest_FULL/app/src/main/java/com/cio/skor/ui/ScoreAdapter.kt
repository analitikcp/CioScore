package com.cio.skor.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.CioScoreEngine
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SofaScoreService

/** One card per unified match. Default view is intentionally compact; details are expandable. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    val odds: SofaScoreService.Odds? = null,
    val oddsSource: String = "Maçkolik"
)

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String) -> Unit = {}
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList
    private var currentQuery = ""

    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5"
    )

    private fun displaySourceName(source: String): String {
        val normalized = source.trim().lowercase()
        return sourceLabels[normalized]
            ?: sourceLabels.entries.firstOrNull { normalized.contains(it.key) }?.value
            ?: normalized
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        refreshDisplayed()
    }

    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        displayedList = if (q.isEmpty()) {
            fullList
        } else {
            fullList.filter { match ->
                val home = MatchMerger.normalizeTeamName(match.homeTeam)
                val away = MatchMerger.normalizeTeamName(match.awayTeam)
                home.contains(q) || away.contains(q) ||
                    MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
            }
        }
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun updateOdds(
        homeTeam: String,
        awayTeam: String,
        odds: SofaScoreService.Odds,
        oddsSource: String = "Maçkolik"
    ) {
        fun same(match: MatchGroup): Boolean =
            MatchMerger.isSameTeam(match.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(match.awayTeam, awayTeam)

        val fullIndex = fullList.indexOfFirst(::same)
        if (fullIndex >= 0) {
            fullList = fullList.toMutableList().apply {
                val old = this[fullIndex]
                this[fullIndex] = old.copy(odds = odds, oddsSource = oddsSource)
            }
        }

        val displayedIndex = displayedList.indexOfFirst(::same)
        if (displayedIndex >= 0) {
            displayedList = displayedList.toMutableList().apply {
                val old = this[displayedIndex]
                this[displayedIndex] = old.copy(odds = odds, oddsSource = oddsSource)
            }
            notifyItemChanged(displayedIndex)
        }
    }

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(ctx, 8), dp(ctx, 5), dp(ctx, 8), dp(ctx, 5))
            }
            val padding = dp(ctx, 12)
            setPadding(padding, padding, padding, padding)
            background = GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = dp(ctx, 14).toFloat()
                setStroke(dp(ctx, 1), 0xFFE7EAF0.toInt())
            }
            elevation = dp(ctx, 3).toFloat()
            clipChildren = false
            clipToPadding = false
        }
        return VH(card)
    }

    override fun getItemCount(): Int = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ctx = holder.card.context
        val match = displayedList[position]
        holder.card.removeAllViews()

        val cio = CioScoreEngine.calculate(match.predictions, match.odds)
        val prob = cio.cioProbabilities
        val model = cio.modelProbabilities
        val market = cio.marketProbabilities

        // ------------------------------------------------
        // 1) HER ZAMAN GÖRÜNEN KOMPAKT ÖZET
        // ------------------------------------------------
        val teams = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val home = teamText(ctx, match.homeTeam).apply {
            setOnClickListener { onTeamClick(match.homeTeam) }
            isClickable = true
        }

        val vs = TextView(ctx).apply {
            text = "VS"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF667085.toInt())
            background = GradientDrawable().apply {
                setColor(0xFFF2F4F7.toInt())
                shape = GradientDrawable.OVAL
            }
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 42), dp(ctx, 42)).apply {
                leftMargin = dp(ctx, 5)
                rightMargin = dp(ctx, 5)
            }
        }

        val away = teamText(ctx, match.awayTeam).apply {
            setOnClickListener { onTeamClick(match.awayTeam) }
            isClickable = true
        }

        teams.addView(home, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        teams.addView(vs)
        teams.addView(away, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        holder.card.addView(teams)

        val scoreRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 6) }
        }

        scoreRow.addView(TextView(ctx).apply {
            text = "CioScore"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF475467.toInt())
        })

        scoreRow.addView(TextView(ctx).apply {
            text = "${cio.score}/100" + if (cio.score >= 80) " 🔥" else ""
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })

        scoreRow.addView(TextView(ctx).apply {
            text = "Güven: ${cio.confidence}"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER
        })
        holder.card.addView(scoreRow)

        // Tek kritik olasılık satırı: nihai CIO olasılığı.
        holder.card.addView(TextView(ctx).apply {
            text = "CIO OLASILIK  •  MS1: ${prob["1"] ?: 0}%   MSX: ${prob["X"] ?: 0}%   MS2: ${prob["2"] ?: 0}%"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 5) }
        })

        if (cio.topScores.isNotEmpty()) {
            val top = cio.topScores.first()
            holder.card.addView(TextView(ctx).apply {
                text = "🎯 En olası skor: ${top.score}  (${top.percent}%)"
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 3) }
            })
        }

        // Küçük detay aç/kapa satırı.
        val details = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val detailToggle = TextView(ctx).apply {
            text = "▼ Detaylar"
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 7), 0, dp(ctx, 2))
            isClickable = true
        }

        fun toggleDetails() {
            val expanded = details.visibility == View.VISIBLE
            details.visibility = if (expanded) View.GONE else View.VISIBLE
            detailToggle.text = if (expanded) "▼ Detaylar" else "▲ Detayları Gizle"
        }

        detailToggle.setOnClickListener { toggleDetails() }

        // Kartın herhangi bir boş alanına dokunmak da detayları açar/kapatır.
        holder.card.setOnClickListener { toggleDetails() }

        holder.card.addView(detailToggle)

        // ------------------------------------------------
        // 2) DETAYLAR — varsayılan olarak gizli
        // ------------------------------------------------
        val modelLine = TextView(ctx).apply {
            text = "MODEL  •  MS1: ${model["1"] ?: 0}%   MSX: ${model["X"] ?: 0}%   MS2: ${model["2"] ?: 0}%"
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 5), 0, 0)
        }
        details.addView(modelLine)

        if (market.isNotEmpty()) {
            details.addView(TextView(ctx).apply {
                text = "PİYASA  •  MS1: ${market["1"] ?: 0}%   MSX: ${market["X"] ?: 0}%   MS2: ${market["2"] ?: 0}%"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
                setPadding(0, dp(ctx, 3), 0, 0)
            })
        }

        if (cio.topScores.isNotEmpty()) {
            val top3 = cio.topScores.joinToString("   •   ") { "${it.score} (${it.percent}%)" }
            details.addView(TextView(ctx).apply {
                text = "🎯 EN OLASI SKORLAR  •  $top3"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
                gravity = Gravity.CENTER
                setPadding(0, dp(ctx, 3), 0, 0)
            })
        }

        match.odds?.let { odds ->
            details.addView(TextView(ctx).apply {
                text = "${match.oddsSource} • MS 1X2"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
                setPadding(0, dp(ctx, 7), 0, 0)
            })

            val oddsRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            fun oddsCell(label: String, value: String): LinearLayout = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                addView(TextView(ctx).apply {
                    text = label
                    textSize = 10f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                })
                addView(TextView(ctx).apply {
                    text = value
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                    gravity = Gravity.CENTER
                })
            }

            oddsRow.addView(oddsCell("MS 1", odds.home))
            oddsRow.addView(oddsCell("MS X", odds.draw))
            oddsRow.addView(oddsCell("MS 2", odds.away))
            details.addView(oddsRow)
        }

        if (match.predictions.isNotEmpty()) {
            details.addView(View(ctx).apply {
                setBackgroundColor(0xFFE7EAF0.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 1)
                ).apply {
                    topMargin = dp(ctx, 7)
                    bottomMargin = dp(ctx, 4)
                }
            })

            match.predictions.forEach { prediction ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = dp(ctx, 2)
                        bottomMargin = dp(ctx, 2)
                    }
                }

                row.addView(TextView(ctx).apply {
                    text = displaySourceName(prediction.source)
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })

                row.addView(TextView(ctx).apply {
                    text = "→"
                    textSize = 16f
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(ctx, 28), ViewGroup.LayoutParams.WRAP_CONTENT)
                })

                row.addView(TextView(ctx).apply {
                    text = prediction.predictedScore
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    maxLines = 1
                    gravity = Gravity.END or Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                })

                details.addView(row)
            }
        }

        holder.card.addView(details)

        holder.card.layoutParams = (holder.card.layoutParams
            ?: RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )).apply {
            width = ViewGroup.LayoutParams.MATCH_PARENT
            height = ViewGroup.LayoutParams.WRAP_CONTENT
        }
    }

    private fun teamText(ctx: Context, name: String): TextView = TextView(ctx).apply {
        text = name
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(0xFF101828.toInt())
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun dp(context: Context, value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        context.resources.displayMetrics
    ).toInt()
}
