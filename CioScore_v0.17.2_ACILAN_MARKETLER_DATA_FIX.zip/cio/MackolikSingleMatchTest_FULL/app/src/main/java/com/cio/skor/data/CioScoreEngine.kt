package com.cio.skor.data

/**
 * CioScore 2.1
 *
 * CIO1-5 = external prediction consensus.
 * Market odds are an independent signal.
 * The displayed model probability blends CIO consensus with margin-cleaned market probability.
 *
 * CioScore itself remains a confidence/strength index, not a literal win probability.
 */
object CioScoreEngine {
    data class ScoreConsensus(val score: String, val count: Int, val percent: Int)

    data class Result(
        val score: Int,
        val confidence: String,
        val exactConsensus: Int,
        val outcomeConsensus: Int,
        val marketConfidence: Int,
        val directionAgreement: Int,
        val sourceCoverage: Int,
        val topScores: List<ScoreConsensus>,
        val cioProbabilities: Map<String, Int>,
        val modelProbabilities: Map<String, Int>,
        val marketProbabilities: Map<String, Int>
    )

    fun calculate(
        predictions: List<ScoreModel>,
        odds: SofaScoreService.Odds?
    ): Result {
        if (predictions.isEmpty()) {
            return Result(
                score = 0, confidence = "Düşük", exactConsensus = 0, outcomeConsensus = 0,
                marketConfidence = 0, directionAgreement = 0, sourceCoverage = 0, topScores = emptyList(),
                cioProbabilities = emptyMap(), modelProbabilities = emptyMap(),
                marketProbabilities = emptyMap()
            )
        }

        val n = predictions.size.toDouble()
        val scoreCounts = predictions
            .map { it.predictedScore.trim() }
            .filter { Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").matches(it) }
            .groupingBy { it }
            .eachCount()

        val exactMax = scoreCounts.values.maxOrNull() ?: 0
        val exact = exactMax / n
        val topScores = scoreCounts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(3)
            .map { ScoreConsensus(it.key, it.value, (it.value / n * 100.0).toInt()) }

        val outcomes = predictions.mapNotNull { outcome(it.predictedScore) }
        val outcomeCounts = outcomes.groupingBy { it }.eachCount()
        val outcomeMax = outcomeCounts.values.maxOrNull() ?: 0
        val outcome = if (outcomes.isEmpty()) 0.0 else outcomeMax / outcomes.size.toDouble()
        val cioProb = outcomeProbabilities(outcomes)

        val market = odds?.let { marketProbabilities(it) }
        val modelProb = blendModels(cioProb, market ?: emptyMap(), predictions.size, outcome)
        val marketConfidence = market?.values?.maxOrNull() ?: 0.0
        val modelDirection = modelProb.maxByOrNull { it.value }?.key
        val marketDirection = market?.maxByOrNull { it.value }?.key
        val agreement = if (modelDirection != null && marketDirection != null && modelDirection == marketDirection) 1.0 else 0.0

        val sourceCoverage = (predictions.map { it.source.trim().lowercase() }.distinct().size / 5.0).coerceIn(0.0, 1.0)
        val stability = if (outcomes.isEmpty()) 0.0 else outcomeCounts.values.maxOrNull()!!.toDouble() / outcomes.size.toDouble()

        val raw =
            25.0 * exact +
            20.0 * outcome +
            15.0 * marketConfidence +
            15.0 * agreement +
            10.0 * sourceCoverage +
            15.0 * stability

        val score = raw.coerceIn(0.0, 100.0).toInt()
        val confidence = when {
            score >= 80 -> "Yüksek"
            score >= 65 -> "Orta-Yüksek"
            score >= 50 -> "Orta"
            else -> "Düşük"
        }

        val marketMap = market?.mapValues { (it.value * 100.0).toInt() } ?: emptyMap()
        val cioMap = cioProb.mapValues { (it.value * 100.0).toInt() }
        val modelMap = modelProb.mapValues { (it.value * 100.0).toInt() }

        return Result(
            score = score,
            confidence = confidence,
            exactConsensus = (exact * 100).toInt(),
            outcomeConsensus = (outcome * 100).toInt(),
            marketConfidence = (marketConfidence * 100).toInt(),
            directionAgreement = (agreement * 100).toInt(),
            sourceCoverage = (sourceCoverage * 100).toInt(),
            topScores = topScores,
            cioProbabilities = cioMap,
            modelProbabilities = modelMap,
            marketProbabilities = marketMap
        )
    }

    private fun blendModels(
        cio: Map<String, Double>,
        market: Map<String, Double>,
        sourceCount: Int,
        outcomeConsensus: Double
    ): Map<String, Double> {
        if (market.isEmpty()) return normalize(cio)

        // Market is independent of the CIO consensus, so MODEL is no longer a copy of CIO.
        // More source coverage / stronger consensus gives CIO slightly more authority.
        val coverage = (sourceCount.coerceIn(1, 5) / 5.0)
        val cioWeight = (0.45 + 0.20 * coverage + 0.15 * outcomeConsensus).coerceIn(0.45, 0.80)
        val marketWeight = 1.0 - cioWeight

        return normalize(listOf("1", "X", "2").associateWith { key ->
            cioWeight * (cio[key] ?: 0.0) + marketWeight * (market[key] ?: 0.0)
        })
    }

    private fun normalize(values: Map<String, Double>): Map<String, Double> {
        val total = values.values.sum()
        if (total <= 0.0) return mapOf("1" to 1.0 / 3, "X" to 1.0 / 3, "2" to 1.0 / 3)
        return values.mapValues { it.value / total }
    }

    private fun outcomeProbabilities(outcomes: List<String>): Map<String, Double> {
        if (outcomes.isEmpty()) return mapOf("1" to 1.0 / 3, "X" to 1.0 / 3, "2" to 1.0 / 3)
        val counts = outcomes.groupingBy { it }.eachCount()
        val prior = 0.5
        val denominator = outcomes.size + prior * 3.0
        return listOf("1", "X", "2").associateWith { key ->
            ((counts[key] ?: 0) + prior) / denominator
        }
    }

    private fun marketProbabilities(odds: SofaScoreService.Odds): Map<String, Double>? {
        val values = listOf(odds.home.toDoubleOrNull(), odds.draw.toDoubleOrNull(), odds.away.toDoubleOrNull())
        if (values.any { value -> value == null || value <= 1.0 }) return null
        val raw = values.map { 1.0 / (it ?: return null) }
        val total = raw.sum()
        if (total <= 0.0) return null
        return mapOf("1" to raw[0] / total, "X" to raw[1] / total, "2" to raw[2] / total)
    }

    private fun outcome(score: String): String? {
        val m = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = m.groupValues[1].toIntOrNull() ?: return null
        val away = m.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }
}
