# CioScore v0.15.2

Current architecture:
- 5 CIO prediction sources (CIO1-CIO5)
- MatchMerger with normalized/fuzzy team matching
- Mackolik 1X2 odds enrichment
- SofaScore team last-five match enrichment
- CioScore engine: CIO consensus + margin-cleaned market probability
- Main UI contains only the scan button, search, clear-search button and match cards
- Diagnostic source counters, footer counters and ranking/filter buttons are removed from the UI
