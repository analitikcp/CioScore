package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.LocalDate
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Mackolik'teki gercekten acilmis IY/MS ve Dogru Skor marketlerini bulur.
 * v0.17.2: aday mac kesfi daha toleransli, market DOM parser'i daha esnek,
 * ana mac listesi market yok diye asla kaybolmaz ve tanisal sayaclar tutulur.
 */
class MackolikMarketService {
    data class OpenedMarketMatch(
        val homeTeam: String,
        val awayTeam: String,
        val hasHtFt: Boolean,
        val hasCorrectScore: Boolean,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
        val correctScoreOdds: LinkedHashMap<String, String> = linkedMapOf()
    )

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val error: String? = null
    )

    private data class Candidate(val homeTeam: String, val awayTeam: String, val detailUrl: String)
    private data class CandidateResult(val match: OpenedMarketMatch?, val reason: String)

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(18, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val base = "https://www.mackolik.com"
    private val liveUrls = listOf(
        "https://www.mackolik.com/perform/p0/ajax/components/competition/livescores/json",
        "https://www.mackolik.com/perform/p0/ajax/components/competition/livescores",
        "https://www.mackolik.com/perform/p0/ajax/components/competition/livescores/json?matchDate="
    )
    private val archiveUrl = "https://arsiv2.mackolik.com/Iddaa-Programi"

    private val htFtLabel = Regex("^[1X2]/[1X2]$", RegexOption.IGNORE_CASE)
    private val scoreLabel = Regex("^\\d{1,2}[-:]\\d{1,2}$")
    private val oddValue = Regex("^(?:[0-9]{1,3})(?:[.,][0-9]{1,2})$")

    suspend fun fetchOpenedMarkets(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(45_000L) {
            try {
                var candidates = fetchLiveCandidates()
                var source = "live"
                if (candidates.isEmpty()) {
                    candidates = parseArchiveCandidates(get(archiveUrl)?.let { Jsoup.parse(it, archiveUrl) })
                    source = "archive"
                }

                if (candidates.isEmpty()) {
                    return@withTimeoutOrNull Result(
                        emptyList(), 0,
                        "Bugünün İddaa maç bağlantıları alınamadı (Maçkolik aday maç servisi boş döndü)"
                    )
                }

                val results = coroutineScope {
                    candidates.chunked(6).flatMap { chunk ->
                        chunk.map { candidate -> async(Dispatchers.IO) { inspect(candidate) } }.awaitAll()
                    }
                }

                val found = results.mapNotNull { it.match }
                val merged = found.groupBy { MatchMerger.key(it.homeTeam, it.awayTeam) }.values.map { same ->
                    val first = same.first()
                    val ht = linkedMapOf<String, String>()
                    val cs = linkedMapOf<String, String>()
                    same.forEach { ht.putAll(it.htFtOdds); cs.putAll(it.correctScoreOdds) }
                    first.copy(
                        hasHtFt = ht.isNotEmpty(), hasCorrectScore = cs.isNotEmpty(),
                        htFtOdds = ht, correctScoreOdds = cs
                    )
                }

                val failures = results.groupingBy { it.reason }.eachCount()
                val diagnostic = buildString {
                    append("Kaynak=$source • Aday=${candidates.size} • Marketli=${merged.size}")
                    failures.filterKeys { it != "OK" }.entries.take(4).forEach { append(" • ${it.key}:${it.value}") }
                }
                Result(merged, candidates.size, if (merged.isEmpty()) diagnostic else null)
            } catch (e: Exception) {
                Result(emptyList(), 0, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, "Market taraması zaman aşımına uğradı")
    }

    /**
     * Eski sürüm yalnızca data.matches + iddaaCode bekliyordu. Mackolik response
     * yapısı değişirse bütün aday listesi 0 oluyordu. Burada JSON ağacını dolaşıp
     * matchName + id/iddaaCode taşıyan nesneleri de yakalıyoruz.
     */
    private fun fetchLiveCandidates(): List<Candidate> {
        val date = LocalDate.now().toString()
        for (endpoint in liveUrls) {
            val url = if (endpoint.endsWith("=")) endpoint + date else endpoint
            val body = getWithQuery(url, if (endpoint.contains("?")) emptyMap() else mapOf("sports[]" to "Soccer", "matchDate" to date))
                ?: continue
            val parsed = parseLiveJson(body)
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parseLiveJson(body: String): List<Candidate> = runCatching {
        val root = JSONObject(body)
        val out = LinkedHashMap<String, Candidate>()
        walkJson(root, out)
        out.values.toList()
    }.getOrDefault(emptyList())

    private fun walkJson(value: Any?, out: MutableMap<String, Candidate>) {
        when (value) {
            is JSONObject -> {
                val name = firstString(value, "matchName", "name", "match_name", "fixtureName", "fixture_name")
                val id = firstString(value, "id", "matchId", "match_id", "iddaaId", "iddaa_id")
                val iddaaCode = firstString(value, "iddaaCode", "iddaa_code")
                if (!name.isNullOrBlank() && (!id.isNullOrBlank() || !iddaaCode.isNullOrBlank())) {
                    splitPairLoose(name)?.let { pair ->
                        val matchId = iddaaCode?.takeIf { it.isNotBlank() && !it.equals("None", true) }
                            ?: id?.takeIf { it.isNotBlank() } ?: ""
                        if (matchId.isNotBlank()) {
                            val slug = slug(pair.first + "-vs-" + pair.second)
                            out[MatchMerger.key(pair.first, pair.second)] = Candidate(
                                pair.first, pair.second, "$base/mac/$slug/iddaa/$matchId"
                            )
                        }
                    }
                }
                val keys = value.keys()
                while (keys.hasNext()) walkJson(value.opt(keys.next()), out)
            }
            is JSONArray -> for (i in 0 until value.length()) walkJson(value.opt(i), out)
        }
    }

    private fun firstString(o: JSONObject, vararg names: String): String? = names.firstNotNullOfOrNull { n ->
        o.opt(n)?.toString()?.takeIf { it.isNotBlank() && !it.equals("null", true) }
    }

    private fun parseArchiveCandidates(doc: Document?): List<Candidate> {
        if (doc == null) return emptyList()
        val out = LinkedHashMap<String, Candidate>()
        for (a in doc.select("a[href]")) {
            val href = a.attr("abs:href").ifBlank { continue }
            val text = a.text().replace(Regex("\\s+"), " ").trim()
            val pair = splitPairLoose(text) ?: continue
            if (!href.contains("/mac/", true) && !href.contains("/iddaa/", true)) continue
            out[MatchMerger.key(pair.first, pair.second)] = Candidate(pair.first, pair.second, href)
        }
        // Bazı bülten sürümlerinde takım isimleri aynı satırdaki hücrelerde bulunuyor.
        if (out.isEmpty()) {
            for (row in doc.select("tr")) {
                val pair = row.select("td,th").map { it.text() }.firstNotNullOfOrNull { splitPairLoose(it) } ?: continue
                val href = row.select("a[href]").map { it.attr("abs:href") }
                    .firstOrNull { it.contains("/mac/", true) || it.contains("/iddaa/", true) } ?: continue
                out[MatchMerger.key(pair.first, pair.second)] = Candidate(pair.first, pair.second, href)
            }
        }
        return out.values.toList()
    }

    private fun inspect(candidate: Candidate): CandidateResult {
        val html = get(candidate.detailUrl) ?: return CandidateResult(null, "HTTP")
        val doc = Jsoup.parse(html, candidate.detailUrl)
        val marketRoots = doc.select(
            "ul.widget-iddaa-markets__markets-list, " +
                "[class*=widget-iddaa-markets__markets-list], " +
                "[data-widget*=iddaa-markets]"
        )
        if (marketRoots.isEmpty()) return CandidateResult(null, "MARKET_DOM")

        val ht = linkedMapOf<String, String>()
        val cs = linkedMapOf<String, String>()
        for (root in marketRoots) parseMarketRoot(root, ht, cs)

        if (ht.isEmpty() && cs.isEmpty()) return CandidateResult(null, "MARKET_EMPTY")
        return CandidateResult(
            OpenedMarketMatch(candidate.homeTeam, candidate.awayTeam, ht.isNotEmpty(), cs.isNotEmpty(), ht, cs), "OK"
        )
    }

    private fun parseMarketRoot(root: Element, ht: LinkedHashMap<String, String>, cs: LinkedHashMap<String, String>) {
        val blocks = root.select("li, div").filter { it.selectFirst("h2,h3,[class*=title],[class*=header]") != null }
        val candidates = if (blocks.isEmpty()) listOf(root) else blocks
        for (market in candidates) {
            val header = market.selectFirst("h2,h3,[class*=market-title],[class*=market-header],[class*=title]")?.text()
                ?: market.text().lineSequence().firstOrNull().orEmpty()
            val n = normalize(header)
            val isHt = isHtFtHeader(n)
            val isCs = n.contains("dogru skor") || n.contains("correct score") || n.contains("mac skoru") || n.contains("score") && n.contains("match")
            if (!isHt && !isCs) continue

            val text = market.text().replace(Regex("\\s+"), " ")
            // Önce klasik label + oran çiftleri.
            val labels = htFtLabel.findAll(text).map { it.value.uppercase(Locale.ROOT) }.toList()
            val odds = Regex("(?<![0-9])(?:[0-9]{1,3})[.,][0-9]{2}(?![0-9])").findAll(text)
                .map { it.value.replace(',', '.') }.toList()
            if (isHt) {
                labels.forEachIndexed { i, label -> if (i < odds.size && odds[i] != "1.00") ht[label] = odds[i] }
            }

            for (score in Regex("\\b\\d{1,2}[-:]\\d{1,2}\\b").findAll(text)) {
                val label = score.value.replace(':', '-')
                val after = text.substring(score.range.last + 1)
                val odd = Regex("^(?:\\s*)([0-9]{1,3}[.,][0-9]{2})").find(after)?.groupValues?.getOrNull(1)
                if (isCs && odd != null && odd != "1.00") cs[label] = odd.replace(',', '.')
            }

            // DOM bazen label ve oranı ayrı span'larda verir; bu yöntem özellikle güvenilir.
            val spans = market.select("span, b, strong, em").map { it.text().trim() }.filter { it.isNotBlank() }
            for (i in 0 until spans.lastIndex) {
                val label = spans[i]
                val value = spans[i + 1].replace(',', '.')
                if (oddValue.matches(value) && value != "1.00") {
                    if (isHt && htFtLabel.matches(label)) ht[label.uppercase(Locale.ROOT)] = value
                    if (isCs && scoreLabel.matches(label)) cs[label.replace(':','-')] = value
                }
            }
        }
    }

    private fun isHtFtHeader(n: String): Boolean =
        (n.contains("iy") && n.contains("ms")) ||
            n.contains("ilk yari mac sonucu") || n.contains("ilk yari sonucu") ||
            n.contains("devre mac sonucu") || n.contains("half time full time") || n == "ht ft"

    private fun splitPairLoose(text: String): Pair<String, String>? {
        val cleaned = text.replace(Regex("\\s+"), " ").trim()
        val matches = Regex("\\s+[–—-]\\s+").findAll(cleaned).toList()
        if (matches.size != 1) return null
        val p = matches.first()
        val home = cleaned.substring(0, p.range.first).trim()
        val away = cleaned.substring(p.range.last + 1).trim()
        if (home.length !in 2..80 || away.length !in 2..80) return null
        if (home.count(Char::isLetter) < 2 || away.count(Char::isLetter) < 2) return null
        if (home.contains("iddaa", true) || away.contains("iddaa", true)) return null
        return home to away
    }

    private fun slug(v: String): String = normalize(v).replace(Regex("[^a-z0-9]+"), "-").trim('-')

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('ç','c').replace('ğ','g').replace('ı','i').replace('ö','o').replace('ş','s').replace('ü','u')
        v = Normalizer.normalize(v, Normalizer.Form.NFD).replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        return v.replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private fun getWithQuery(url: String, query: Map<String, String>): String? {
        val builder = url.toHttpUrl().newBuilder()
        query.forEach { (k,v) -> builder.addQueryParameter(k,v) }
        return execute(Request.Builder().url(builder.build()).header("User-Agent", userAgent())
            .header("Accept", "application/json,text/plain,*/*").header("Accept-Language","tr-TR,tr;q=0.9,en;q=0.7")
            .header("Referer", "$base/").build())
    }

    private fun get(url: String): String? = execute(Request.Builder().url(url).header("User-Agent", userAgent())
        .header("Accept","text/html,application/xhtml+xml,application/json,text/plain,*/*;q=0.8")
        .header("Accept-Language","tr-TR,tr;q=0.9,en;q=0.7").header("Referer","$base/").build())

    private fun execute(request: Request): String? = runCatching {
        client.newCall(request).execute().use { response -> if (response.isSuccessful) response.body?.string() else null }
    }.getOrNull()

    private fun userAgent() = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36"
}
