package com.cio.skor

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.cio.skor.data.MackolikMarketService
import com.cio.skor.data.MatchMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OpenedMarketsActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = MackolikMarketService()
    private lateinit var content: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var filterAll: Button
    private lateinit var filterHtFt: Button
    private lateinit var filterScore: Button
    private var matches: List<MackolikMarketService.OpenedMarketMatch> = emptyList()
    private var filter = Filter.ALL

    private enum class Filter { ALL, HTFT, SCORE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF6F8FB.toInt())
            setPadding(dp(14), dp(8), dp(14), 0)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top + dp(8), view.paddingRight, view.paddingBottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "📊 Açılan Marketler"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF0F172A.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        header.addView(Button(this).apply {
            text = "KAPAT"
            setOnClickListener { finish() }
        })
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "Bugün Maçkolik'te gerçekten oranı bulunan marketler"
            textSize = 13f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, dp(2), 0, dp(7))
        })

        val filters = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        filterAll = filterButton("TÜMÜ")
        filterHtFt = filterButton("⚡ İY/MS")
        filterScore = filterButton("🎯 DOĞRU SKOR")
        filterRow.addView(filterAll)
        filterRow.addView(filterHtFt)
        filterRow.addView(filterScore)
        filters.addView(filterRow)
        root.addView(filters)

        filterAll.setOnClickListener { filter = Filter.ALL; renderList() }
        filterHtFt.setOnClickListener { filter = Filter.HTFT; renderList() }
        filterScore.setOnClickListener { filter = Filter.SCORE; renderList() }
        updateFilterButtons()

        progress = ProgressBar(this).apply { visibility = View.VISIBLE }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(38)))
        status = TextView(this).apply {
            text = "Maçkolik marketleri taranıyor…"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF475569.toInt())
            setPadding(0, 0, 0, dp(4))
        }
        root.addView(status)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply {
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        load()
    }

    private fun load() {
        scope.launch {
            val result = withContext(Dispatchers.IO) { service.fetchOpenedMarkets() }
            progress.visibility = View.GONE
            matches = result.matches
            if (matches.isEmpty()) {
                status.text = result.error ?: "Bugün açılmış HT/FT veya Doğru Skor marketi bulunamadı."
            } else {
                status.text = "${matches.size} maç bulundu • ${result.scanned} maç kontrol edildi"
            }
            renderList()
        }
    }

    private fun renderList() {
        updateFilterButtons()
        content.removeAllViews()
        val visible = when (filter) {
            Filter.ALL -> matches
            Filter.HTFT -> matches.filter { it.hasHtFt }
            Filter.SCORE -> matches.filter { it.hasCorrectScore }
        }

        if (matches.isNotEmpty()) {
            status.text = when (filter) {
                Filter.ALL -> "${matches.size} maç • HT/FT: ${matches.count { it.hasHtFt }} • Doğru Skor: ${matches.count { it.hasCorrectScore }}"
                Filter.HTFT -> "${visible.size} maçta İY/MS oranı açık"
                Filter.SCORE -> "${visible.size} maçta Doğru Skor oranı açık"
            }
        }

        if (visible.isEmpty()) {
            content.addView(TextView(this).apply {
                text = "Bu filtrede açılmış market bulunamadı."
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(0xFF64748B.toInt())
                setPadding(0, dp(30), 0, dp(30))
            })
            return
        }

        visible.sortedWith(compareBy({ MatchMerger.normalizeTeamName(it.homeTeam) }, { MatchMerger.normalizeTeamName(it.awayTeam) }))
            .forEach { addMatchRow(it) }
    }

    private fun addMatchRow(match: MackolikMarketService.OpenedMarketMatch) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
            elevation = dp(2).toFloat()
            setOnClickListener { showMarketDetails(match) }
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(TextView(this).apply {
            text = "${match.homeTeam}  VS  ${match.awayTeam}"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF0F172A.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })

        val badges = mutableListOf<String>()
        if (match.hasHtFt) badges += "İY/MS"
        if (match.hasCorrectScore) badges += "SKOR"
        top.addView(TextView(this).apply {
            text = badges.joinToString(" • ")
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
        })
        row.addView(top)

        val preview = when (filter) {
            Filter.HTFT -> match.htFtOdds.entries.take(4)
            Filter.SCORE -> match.correctScoreOdds.entries.take(4)
            Filter.ALL -> (match.htFtOdds.entries.take(2) + match.correctScoreOdds.entries.take(2))
        }
        if (preview.isNotEmpty()) {
            row.addView(TextView(this).apply {
                text = preview.joinToString("   •   ") { "${it.key}: ${it.value}" }
                textSize = 11f
                setTextColor(0xFF475569.toInt())
                setPadding(0, dp(7), 0, 0)
            })
        }

        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(7)
        })
    }

    private fun showMarketDetails(match: MackolikMarketService.OpenedMarketMatch) {
        val lines = buildString {
            append(match.homeTeam).append("  VS  ").append(match.awayTeam).append("\n\n")
            if (match.htFtOdds.isNotEmpty()) {
                append("İY/MS\n")
                match.htFtOdds.forEach { (k, v) -> append(k).append("   ").append(v).append("\n") }
                append("\n")
            }
            if (match.correctScoreOdds.isNotEmpty()) {
                append("DOĞRU SKOR\n")
                match.correctScoreOdds.forEach { (k, v) -> append(k).append("   ").append(v).append("\n") }
            }
        }.trim()

        AlertDialog.Builder(this)
            .setTitle("Açılan Marketler")
            .setMessage(lines)
            .setPositiveButton("KAPAT", null)
            .show()
    }

    private fun filterButton(label: String): Button = Button(this).apply {
        text = label
        textSize = 11f
        setTypeface(typeface, Typeface.BOLD)
        isAllCaps = false
        minHeight = dp(42)
        minWidth = 0
        setPadding(dp(12), 0, dp(12), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(42)).apply {
            rightMargin = dp(6)
        }
    }

    private fun updateFilterButtons() {
        val active = 0xFF00796B.toInt()
        val inactive = 0xFFFFFFFF.toInt()
        listOf(filterAll to (filter == Filter.ALL), filterHtFt to (filter == Filter.HTFT), filterScore to (filter == Filter.SCORE))
            .forEach { (button, selected) ->
                button.setBackgroundColor(if (selected) active else inactive)
                button.setTextColor(if (selected) 0xFFFFFFFF.toInt() else 0xFF00796B.toInt())
            }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
