package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance
import java.text.Normalizer as JavaNormalizer

/**
 * Central place for team-name canonicalisation and cross-source fixture merging.
 *
 * The important rule is: source names are presentation data, never identity.
 * A fixture is identified by canonical home + canonical away team names.
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    private val removableSuffixes = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "club"
    )

    /**
     * Explicit aliases for names that are commonly shortened by one source.
     * We deliberately do NOT blindly remove words such as "city" or "united"
     * because that can merge genuinely different clubs.
     */
    private val canonicalAliases = mapOf(
        // England / Championship / Premier League style source variants
        "cardiff" to "cardiff city",
        "cardiff city" to "cardiff city",
        "stoke" to "stoke city",
        "stoke city" to "stoke city",
        "norwich" to "norwich city",
        "norwich city" to "norwich city",
        "coventry" to "coventry city",
        "coventry city" to "coventry city",
        "leicester" to "leicester city",
        "leicester city" to "leicester city",
        "swansea" to "swansea city",
        "swansea city" to "swansea city",
        "birmingham" to "birmingham city",
        "birmingham city" to "birmingham city",
        "hull" to "hull city",
        "hull city" to "hull city",
        "lincoln" to "lincoln city",
        "lincoln city" to "lincoln city",

        // High-frequency abbreviations / short source labels
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "spurs" to "tottenham hotspur",
        "tottenham" to "tottenham hotspur",
        "tottenham hotspur" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "wolverhampton wanderers" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "west bromwich albion" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "nottingham forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "brighton and hove albion" to "brighton and hove albion",
        "qpr" to "queens park rangers",
        "queens park rangers" to "queens park rangers",
        "newcastle" to "newcastle united",
        "newcastle utd" to "newcastle united",
        "newcastle united" to "newcastle united",

        // Frequently abbreviated European names
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "paris saint germain" to "paris saint germain"
    )

    /**
     * Standardise a raw team name for comparison/key generation.
     * This function is intentionally deterministic and locale-independent.
     */
    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        value = value
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = value.split(' ')
            .filter { it.isNotBlank() && it !in removableSuffixes }

        val cleaned = tokens.joinToString(" ").trim()
        if (cleaned.isBlank()) return ""

        // Canonical alias lookup is done AFTER punctuation/diacritic cleanup.
        return canonicalAliases[cleaned] ?: cleaned
    }

    private fun compact(value: String): String =
        normalizeTeamName(value).replace(" ", "")

    /** Stable fixture identity: canonical home + canonical away. */
    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    /**
     * Returns true only when the two names are safely equivalent.
     * Canonical aliases are checked first; fuzzy matching is deliberately
     * conservative so unrelated clubs are not accidentally merged.
     */
    fun isSameTeam(name1: String, name2: String): Boolean {
        val norm1 = compact(name1)
        val norm2 = compact(name2)

        if (norm1.isBlank() || norm2.isBlank()) return false
        if (norm1 == norm2) return true

        // Safe token containment for multi-word variants, e.g. a source that
        // drops an organisational suffix but leaves the distinctive club name.
        val tokens1 = normalizeTeamName(name1).split(' ').filter { it.isNotBlank() }
        val tokens2 = normalizeTeamName(name2).split(' ').filter { it.isNotBlank() }
        val shorterTokens = if (tokens1.size <= tokens2.size) tokens1 else tokens2
        val longerTokens = if (tokens1.size <= tokens2.size) tokens2 else tokens1
        val safeContainment = shorterTokens.isNotEmpty() &&
            (shorterTokens.size >= 2 || shorterTokens.joinToString("").length >= 8) &&
            shorterTokens.all { it in longerTokens }
        if (safeContainment) return true

        val maxLength = maxOf(norm1.length, norm2.length)
        if (maxLength == 0) return true

        val distance = levenshtein.apply(norm1, norm2)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.88
    }

    data class UnifiedMatch(
        val mainHomeTeam: String,
        val mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf()
    )

    /**
     * Merge all raw source predictions into one fixture group.
     *
     * Two records merge only when BOTH home and away teams are the same after
     * canonicalisation/fuzzy validation. Source name is never part of fixture
     * identity. A source contributes at most one prediction to a fixture.
     */
    fun mergeMatches(scrapedList: List<ScoreModel>): List<UnifiedMatch> {
        val unifiedMatches = mutableListOf<UnifiedMatch>()

        for (scraped in scrapedList) {
            val existingMatch = unifiedMatches.find { unified ->
                isSameTeam(unified.mainHomeTeam, scraped.homeTeam) &&
                    isSameTeam(unified.mainAwayTeam, scraped.awayTeam)
            }

            if (existingMatch != null) {
                val sourceExists = existingMatch.predictions.any {
                    it.first.trim().equals(scraped.source.trim(), ignoreCase = true)
                }
                if (!sourceExists) {
                    existingMatch.predictions.add(scraped.source to scraped.predictedScore)
                }
            } else {
                // Display canonical names for known aliases so the user sees
                // one consistent club name even when the first source used a
                // shortened label such as "Cardiff".
                unifiedMatches.add(
                    UnifiedMatch(
                        mainHomeTeam = normalizeDisplayName(scraped.homeTeam),
                        mainAwayTeam = normalizeDisplayName(scraped.awayTeam),
                        predictions = mutableListOf(scraped.source to scraped.predictedScore)
                    )
                )
            }
        }

        return unifiedMatches
    }

    private fun normalizeDisplayName(raw: String): String {
        val canonical = normalizeTeamName(raw)
        return when (canonical) {
            "cardiff city" -> "Cardiff City"
            "stoke city" -> "Stoke City"
            "norwich city" -> "Norwich City"
            "coventry city" -> "Coventry City"
            "leicester city" -> "Leicester City"
            "swansea city" -> "Swansea City"
            "birmingham city" -> "Birmingham City"
            "hull city" -> "Hull City"
            "lincoln city" -> "Lincoln City"
            "manchester united" -> "Manchester United"
            "manchester city" -> "Manchester City"
            "tottenham hotspur" -> "Tottenham Hotspur"
            "wolverhampton wanderers" -> "Wolverhampton Wanderers"
            "west bromwich albion" -> "West Bromwich Albion"
            "nottingham forest" -> "Nottingham Forest"
            "brighton and hove albion" -> "Brighton & Hove Albion"
            "queens park rangers" -> "Queens Park Rangers"
            "newcastle united" -> "Newcastle United"
            "paris saint germain" -> "Paris Saint-Germain"
            else -> raw.trim()
        }
    }
}
