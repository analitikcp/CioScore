# CioScore v0.25.12 Matcher V6.1 — Edge Hardening

## Added
- CountryCanonicalizer: Unicode/diacritic stripping, Turkish character normalization and provider-language aliases.
- UNKNOWN-aware hard metadata conflict: only two known, canonically different countries can reject; the same rule applies to competitions.
- Competition conflict uses canonical competition IDs before fuzzy fallback, preventing EPL/Premier League false conflicts.
- Iddaa matching candidate pool is explicitly evaluated with `Instant`/epoch timestamps and a ±2 hour boundary tolerance.
- Official bulletin membership remains the authoritative 06:00 → 06:00 window; the widened window is candidate-only.

## Regression coverage
- Côte d'Ivoire ↔ Ivory Coast
- Türkiye ↔ Turkey
- Bosna Hersek ↔ Bosnia and Herzegovina
- Unknown metadata does not create a conflict
- Known country/competition conflict hard-rejects
- Candidate window includes exactly ±2h and excludes outside timestamps
