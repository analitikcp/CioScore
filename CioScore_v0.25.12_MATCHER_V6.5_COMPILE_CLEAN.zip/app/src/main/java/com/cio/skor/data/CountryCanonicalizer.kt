package com.cio.skor.data

import java.text.Normalizer
import java.util.Locale

/**
 * Source-independent country taxonomy. Raw provider labels are normalized to
 * an ASCII-safe canonical ID before conflict checks or similarity scoring.
 */
object CountryCanonicalizer {
    private val aliases = mapOf(
        "turkiye" to "TR",
        "turkey" to "TR",
        "turkiye cumhuriyeti" to "TR",
        "england" to "GB-ENG",
        "ingiltere" to "GB-ENG",
        "germany" to "DE",
        "almanya" to "DE",
        "spain" to "ES",
        "ispanya" to "ES",
        "italy" to "IT",
        "italya" to "IT",
        "france" to "FR",
        "fransa" to "FR",
        "portugal" to "PT",
        "portekiz" to "PT",
        "netherlands" to "NL",
        "hollanda" to "NL",
        "belgium" to "BE",
        "belcika" to "BE",
        "austria" to "AT",
        "avusturya" to "AT",
        "switzerland" to "CH",
        "isvicre" to "CH",
        "greece" to "GR",
        "yunanistan" to "GR",
        "croatia" to "HR",
        "hirvatistan" to "HR",
        "bosnia and herzegovina" to "BA",
        "bosnia herzegovina" to "BA",
        "bosnia" to "BA",
        "bosna hersek" to "BA",
        "bosna" to "BA",
        "serbia" to "RS",
        "sirbistan" to "RS",
        "slovenia" to "SI",
        "slovenya" to "SI",
        "cote d ivoire" to "CI",
        "cote divoire" to "CI",
        "cote d'ivoire" to "CI",
        "ivory coast" to "CI",
        "fildisi sahili" to "CI",
        "united states" to "US",
        "usa" to "US",
        "abd" to "US",
        "amerika" to "US",
        "argentina" to "AR",
        "arjantin" to "AR",
        "brazil" to "BR",
        "brezilya" to "BR",
        "colombia" to "CO",
        "kolombiya" to "CO",
        "chile" to "CL",
        "sili" to "CL",
        "ecuador" to "EC",
        "ekvador" to "EC",
        "mexico" to "MX",
        "meksika" to "MX",
        "canada" to "CA",
        "kanada" to "CA",
        "australia" to "AU",
        "avustralya" to "AU",
        "israel" to "IL",
        "israil" to "IL"
    )

    fun normalize(value: String?): String {
        if (value.isNullOrBlank()) return "UNKNOWN"
        return Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank { "UNKNOWN" }
    }

    fun canonicalId(value: String?): String {
        val normalized = normalize(value)
        if (normalized == "UNKNOWN") return "UNKNOWN"
        return aliases[normalized] ?: normalized.uppercase(Locale.ROOT)
    }
}
