package com.cio.skor

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.cio.skor.data.CioAiAnalyzer

class CioAiActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val home = intent.getStringExtra(EXTRA_HOME).orEmpty()
        val away = intent.getStringExtra(EXTRA_AWAY).orEmpty()
        val iddaa1 = intent.getStringExtra(EXTRA_1)
        val iddaaX = intent.getStringExtra(EXTRA_X)
        val iddaa2 = intent.getStringExtra(EXTRA_2)
        val sourceScores = intent.getStringArrayListExtra(EXTRA_SCORES).orEmpty().mapNotNull {
            val parts = it.split("|", limit = 2)
            if (parts.size == 2) parts[0] to parts[1] else null
        }
        val bookmakerOdds = intent.getStringArrayListExtra(EXTRA_BOOKS).orEmpty().mapNotNull {
            val p = it.split("|", limit = 4)
            if (p.size == 4) Triple(p[1], p[2], p[3]) else null
        }

        val result = CioAiAnalyzer.analyze(CioAiAnalyzer.Input(home, away, iddaa1, iddaaX, iddaa2, sourceScores, bookmakerOdds))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        root.addView(text("🤖 Cio AI", 26f, 0xFF101828, true, Gravity.CENTER))
        root.addView(text("$home  •  $away", 16f, 0xFF344054, true, Gravity.CENTER, 12))
        root.addView(card("AI ÖZETİ", "MS $primaryLabel(result.primary)\nAlternatif: ${result.secondary}\nGüven skoru: %${result.confidence}\nGol eğilimi: ${result.goalLean}"))
        root.addView(card("OLASILIKLER", "MS 1     %${result.ms1}\nMS X     %${result.msX}\nMS 2     %${result.ms2}"))
        root.addView(card("CİO AI NEDEN BÖYLE DÜŞÜNÜYOR?", result.reasons.joinToString("\n• ", prefix = "• ")))
        root.addView(text("Not: Bu sürüm mevcut CioScore verilerini birleştiren yerel analiz motorudur. Kesinlik veya garanti iddiası yoktur.", 12f, 0xFF667085, false, Gravity.CENTER, 8))

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun card(title: String, body: String): TextView = text("$title\n\n$body", 15f, 0xFF101828, false, Gravity.START, 12).apply {
        setPadding(dp(14), dp(14), dp(14), dp(14))
        setBackgroundColor(0xFFFFFFFF.toInt())
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean, gravity: Int, top: Int = 0) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = gravity
        if (bold) setTypeface(typeface, Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top); bottomMargin = dp(6) }
    }

    private fun primaryLabel(value: String) = when (value) { "1" -> "1"; "X" -> "X"; else -> "2" }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_HOME = "home"
        const val EXTRA_AWAY = "away"
        const val EXTRA_1 = "ms1"
        const val EXTRA_X = "msx"
        const val EXTRA_2 = "ms2"
        const val EXTRA_SCORES = "scores"
        const val EXTRA_BOOKS = "books"
    }
}
