package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Shared parser for secondary public prediction sources.
 *
 * These sites deliberately have different layouts, so the parser uses two
 * conservative strategies: structured table rows (BallPrediction/FootyStats)
 * and explicit prediction sentences/cards (Sports Mole/Opta/SheKicks/
 * William Hill). It never invents a score: a row is emitted only when both
 * teams and an explicit score are found in the same fixture scope.
 */
class AdditionalPredictionParser(
    source: String,
    private val mode: Mode
) : BaseParser(source) {

    enum class Mode { TABLE, ARTICLE, MIXED }

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        if (mode == Mode.TABLE || mode == Mode.MIXED) parseTables(doc, out)
        if (mode == Mode.ARTICLE || mode == Mode.MIXED) parseArticles(doc, out)
        return out.values.toList()
    }

    private fun parseTables(doc: Document, out: LinkedHashMap<String, ScoreModel>) {
        for (row in doc.select("table tr")) {
            val text = clean(row.text())
            if (text.length !in 15..1800) continue
            val scoreMatches = scoreRegex.findAll(text).toList()
            if (scoreMatches.isEmpty()) continue
            val scoreMatch = scoreMatches.last()
            val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
            val teams = extractTeams(row)
            if (teams.size < 2) continue
            add(out, teams[0], teams[1], score, row)
        }
    }

    private fun parseArticles(doc: Document, out: LinkedHashMap<String, ScoreModel>) {
        val markerRegex = Regex(
            "(?i)(?:we\\s+say|our\\s+prediction|prediction|tip)\\s*[:：-]?[^.]{0,180}?\\b([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})\\b"
        )
        val candidates = doc.getElementsContainingText("prediction")
            .asSequence()
            .plus(doc.getElementsContainingText("Prediction").asSequence())
            .plus(doc.select("article, .article, [class*=preview], [class*=prediction], [class*=match]").asSequence())
            .distinct()
            .sortedBy { it.text().length }

        for (element in candidates) {
            val text = clean(element.text())
            if (text.length !in 25..5000) continue
            val match = markerRegex.find(text) ?: continue
            val score = "${match.groupValues[1]}-${match.groupValues[2]}"
            val card = fixtureScope(element) ?: continue
            val teams = extractTeams(card)
            if (teams.size < 2) continue
            add(out, teams[0], teams[1], score, card)
        }
    }

    private fun fixtureScope(start: Element): Element? {
        var node: Element? = start
        repeat(8) {
            val current = node ?: return null
            val text = clean(current.text())
            val teams = extractTeams(current)
            if (teams.size >= 2 && text.length <= 6000) return current
            node = current.parent()
        }
        return null
    }

    private fun extractTeams(element: Element): List<String> {
        val imageTeams = element.select("img").flatMap { img ->
            listOf(img.attr("alt"), img.attr("title"), img.attr("aria-label"), img.attr("data-team"))
        }.map(::cleanTeam).filter(::looksLikeTeam).distinct()
        if (imageTeams.size >= 2) return imageTeams.take(2)

        val links = element.select("a").flatMap { a ->
            listOf(a.text(), a.attr("title"), a.attr("aria-label"))
        }.map(::cleanTeam).filter(::looksLikeTeam).distinct()
        if (links.size >= 2) return links.take(2)

        val headings = element.select("h1,h2,h3,h4,h5,h6,[class*=team],[class*=home],[class*=away]")
            .map { cleanTeam(it.text()) }
            .filter(::looksLikeTeam)
            .distinct()
        return headings.take(2)
    }

    private fun add(
        out: LinkedHashMap<String, ScoreModel>,
        homeRaw: String,
        awayRaw: String,
        score: String,
        scope: Element
    ) {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!looksLikeTeam(home) || !looksLikeTeam(away) || home.equals(away, true)) return
        val metadata = extractFixtureMetadata(scope)
        val sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty()
        val model = ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            sourceMatchId = sourceMatchId,
            matchTimestamp = metadata.matchTimestamp,
            matchDate = metadata.matchDate,
            matchTime = metadata.matchTime,
            competitionName = metadata.competitionName,
            competitionCountry = metadata.competitionCountry
        )
        val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
        out.putIfAbsent(key, model)
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)^image\\s*:\\s*"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', ':', '|')

    private fun looksLikeTeam(value: String): Boolean {
        if (value.length !in 2..80) return false
        if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        if (value.contains(Regex("(?i)^(prediction|correct score|today|tomorrow|tip|1x2|o/u|btts|home|draw|away|odds|image)$"))) return false
        if (value.contains(Regex("(?i)^(over|under)\\s*[0-9]"))) return false
        return true
    }
}
