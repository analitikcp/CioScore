package com.cio.skor.data.parsers

import android.util.Log

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone
import java.util.Locale

/**
 * Vitibet homepage parser.
 *
 * The current Vitibet quicktips page exposes each fixture as a link/row whose
 * text looks like:
 *   15:00 Bournemouth Liverpool FT 0-1 INDEX -1.89 ... Tip 0-1 ...
 *   21:00 AC Milan US Lecce INDEX +6.23 ... Tip 3-0 ...
 *
 * IMPORTANT: FT/LIVE is the current/result score, while the prediction is the
 * value following "Tip".  We therefore extract the Tip score, not FT/LIVE.
 *
 * DOM-first parsing is used so team boundaries do not depend on one giant
 * body-text regex. A text fallback is retained for minor markup changes.
 */
class VitibetParser : BaseParser("Vitibet") {

    companion object { private const val TAG = "VITIBET_PARSER" }

    // BUILD MARKER: VITIBET_PARSER_v0.24.44_DATELOCK_02
    // Target: active "Matches for: dd.MM.yyyy" section only.

    private val timeRegex = Regex("^\\d{1,2}:\\d{2}$")
    private val liveMinuteRegex = Regex("^\\d{1,3}'$")
    private val scoreTokenRegex = Regex("^\\d{1,2}[-:]\\d{1,2}$")
    private val statusRegex = Regex("(?i)^(FT|LIVE|HT|POSTPONED|CANCELLED|SUSPENDED)$")
    private val indexRegex = Regex("(?i)^INDEX$")

    override fun parse(doc: Document): List<ScoreModel> {
        val dateFormatter = SimpleDateFormat("dd.MM.yyyy", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("Europe/Istanbul")
        }
        val today = dateFormatter.format(Date())

        // HARD BUILD MARKER: this parser is fixture-anchor based.
        Log.i(TAG, "VITIBET_PARSER=v0.24.44-ANCHOR-01 targetDate=$today")

        val fixtureAnchors = findFixtureAnchors(doc, today)

        val result = LinkedHashMap<String, ScoreModel>()
        var rejected = 0

        for (anchor in fixtureAnchors) {
            val model = parseFixtureAnchor(anchor, today)
            if (model == null) {
                rejected++
                continue
            }
            result.putIfAbsent(model.matchKey, model)
        }

        Log.i(
            TAG,
            "VITIBET_ANCHOR_DIAG candidates=${fixtureAnchors.size} " +
                "unique=${result.size} rejected=$rejected targetDate=$today"
        )

        return result.values.toList()
    }

    /**
     * Find actual fixture anchors only.
     *
     * Vitibet's quicktips page contains many other links/cards. A fixture is
     * identified from an <a> whose visible text contains:
     *   - a kickoff time
     *   - a "Tip H-A" score
     *
     * We start only after the active "Matches for: dd.MM.yyyy" heading and
     * never use the whole-body text as a fixture source.
     */
    private fun findFixtureAnchors(doc: Document, today: String): List<Element> {
        val marker = Regex("(?i)\\bMatches\\s+for\\s*:\\s*$today\\b")

        val heading = doc.getAllElements()
            .firstOrNull { marker.containsMatchIn(clean(it.ownText())) }
            ?: run {
                Log.w(TAG, "VITIBET_ANCHOR_DIAG active-date-heading-not-found=$today")
                return emptyList()
            }

        val anchors = ArrayList<Element>()
        val seen = HashSet<String>()
        var afterHeading = false

        for (element in doc.getAllElements()) {
            if (element === heading) {
                afterHeading = true
                continue
            }
            if (!afterHeading || element.tagName() != "a") continue

            val text = clean(element.text())
            if (text.isBlank()) continue

            // A real quicktips fixture anchor has both kickoff time and Tip score.
            val time = Regex("""\b([01]?\d|2[0-3]):[0-5]\d\b""").find(text) ?: continue
            val tip = Regex("""(?i)\bTip\s*[:\-]?\s*(\d{1,2})\s*[-:]\s*(\d{1,2})\b""").find(text)
                ?: continue

            // Do not accidentally consume explicit dates from other sections.
            val dates = Regex("""\b\d{2}\.\d{2}\.\d{4}\b""")
                .findAll(text)
                .map { it.value }
                .toList()
            if (dates.any { it != today }) continue

            // Stable DOM-level key. This removes duplicate desktop/mobile
            // representations of the same fixture.
            val key = buildString {
                append(time.groupValues[0])
                append('|')
                append(tip.groupValues[1])
                append('-')
                append(tip.groupValues[2])
                append('|')
                append(text.lowercase(Locale.ROOT))
            }

            if (seen.add(key)) anchors.add(element)
        }

        return anchors
    }

    /**
     * Converts one actual fixture <a> into ScoreModel.
     *
     * We deliberately parse the Tip score, not FT/LIVE score.
     */
    private fun parseFixtureAnchor(anchor: Element, today: String): ScoreModel? {
        val text = clean(anchor.text())

        val timeMatch = Regex("""\b([01]?\d|2[0-3]):([0-5]\d)\b""").find(text) ?: return null
        val tipMatch = Regex("""(?i)\bTip\s*[:\-]?\s*(\d{1,2})\s*[-:]\s*(\d{1,2})\b""")
            .find(text) ?: return null

        val time = timeMatch.value
        val predictedScore = "${tipMatch.groupValues[1]}-${tipMatch.groupValues[2]}"

        // Remove metadata while retaining the fixture's visible team text.
        var teamText = text
        teamText = teamText.replace(timeMatch.value, " ")
        teamText = teamText.replace(tipMatch.value, " ")
        teamText = teamText.replace(
            Regex("""(?i)\b(?:FT|LIVE|INDEX|1|X|2|Tip)\b.*$"""),
            " "
        )
        teamText = clean(teamText)

        val teams = splitTeamText(teamText) ?: return null
        val home = clean(teams.first)
        val away = clean(teams.second)

        if (home.length < 2 || away.length < 2) return null
        if (home.equals(away, ignoreCase = true)) return null

        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = predictedScore,
            source = "Vitibet",
            matchDate = today,
            matchTime = time
        )
    }

    private fun parseAnchor(anchor: Element, date: String): ScoreModel? {
        val raw = clean(anchor.text())
        val tip = Regex("(?i)\\bTip\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b")
            .find(raw) ?: return null
        val predictedScore = "${tip.groupValues[1]}-${tip.groupValues[2]}"

        val leaves = anchor
            .select("*")
            .filter { it.children().isEmpty() }
            .map { clean(it.text()) }
            .filter { it.isNotEmpty() }
            .distinct()
            .toMutableList()

        // If the DOM does not expose useful leaf nodes, use the conservative
        // textual parser below.
        val pair = extractTeamsFromDom(leaves) ?: extractTeamsFromText(raw) ?: return null
        val time = extractTime(raw) ?: "--:--"

        return build(pair.first, pair.second, predictedScore, date, time)
    }

    private fun extractTeamsFromDom(parts: List<String>): Pair<String, String>? {
        if (parts.size < 3) return null

        val timeIndex = parts.indexOfFirst { timeRegex.matches(it) || liveMinuteRegex.matches(it) }
        if (timeIndex < 0) return null

        val start = timeIndex + 1
        val endCandidates = listOf(
            parts.indexOfFirstFrom(start) { statusRegex.matches(it) },
            parts.indexOfFirstFrom(start) { indexRegex.matches(it) }
        ).filter { it >= 0 }
        val end = endCandidates.minOrNull() ?: return null
        if (end - start < 2) return null

        val teamParts = parts.subList(start, end)
            .filterNot { statusRegex.matches(it) || scoreTokenRegex.matches(it) }
        if (teamParts.size < 2) return null

        // In the current DOM the home and away teams are separate leaf nodes.
        // If there are extra leaf fragments, split at the most natural midpoint.
        val home = cleanTeam(teamParts.first())
        val away = cleanTeam(teamParts.drop(1).joinToString(" "))
        if (valid(home, away) && isTeamCandidate(home) && isTeamCandidate(away)) {
            return home to away
        }

        if (teamParts.size >= 2) {
            for (split in 1 until teamParts.size) {
                val h = cleanTeam(teamParts.take(split).joinToString(" "))
                val a = cleanTeam(teamParts.drop(split).joinToString(" "))
                if (valid(h, a) && isTeamCandidate(h) && isTeamCandidate(a)) return h to a
            }
        }
        return null
    }

    private fun extractTeamsFromText(raw: String): Pair<String, String>? {
        val tipStart = Regex("(?i)\\bTip\\s+\\d{1,2}[-:]\\d{1,2}\\b").find(raw)?.range?.first ?: raw.length
        val withoutTip = raw.substring(0, tipStart)
        val indexPos = Regex("(?i)\\bINDEX\\b").find(withoutTip)?.range?.first ?: withoutTip.length
        val head = clean(withoutTip.substring(0, indexPos))

        val timeMatch = Regex("^\\s*(?:\\d{1,2}:\\d{2}|\\d{1,3}')\\s+").find(head) ?: return null
        var teams = head.substring(timeMatch.range.last + 1).trim()
        teams = teams.replace(Regex("(?i)\\s+(FT|LIVE|HT|POSTPONED|CANCELLED|SUSPENDED)\\s+\\d{1,2}[-:]\\d{1,2}.*$"), "")
        teams = teams.replace(Regex("\\s+"), " ").trim()

        // Text-only fallback cannot know arbitrary team-name boundaries safely.
        // Accept only the common two-token form; DOM parsing is the primary path.
        val words = teams.split(' ').filter { it.isNotBlank() }
        if (words.size != 2) return null
        return cleanTeam(words[0]) to cleanTeam(words[1])
    }

    private fun extractTime(raw: String): String? =
        Regex("^(\\d{1,2}:\\d{2})\\b").find(raw)?.groupValues?.get(1)

    private fun build(homeRaw: String, awayRaw: String, score: String, date: String, time: String): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            matchDate = date,
            matchTime = time
        )
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..80) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction|score|1|0|2)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|Odds|Status)\\b.*$"), "")
        .replace(Regex("(?i)\\s+(?:FT|LIVE|HT|POSTPONED|CANCELLED|SUSPENDED)\\s*$"), "")
        .replace(Regex("\\s+(?:1X|X2|12|10|02|1|X|2)\\s*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', ':', '|')

    private fun <T> List<T>.indexOfFirstFrom(start: Int, predicate: (T) -> Boolean): Int {
        for (i in start until size) if (predicate(this[i])) return i
        return -1
    }


    private fun splitTeamText(raw: String): Pair<String, String>? {
        val cleaned = raw.replace(Regex("\\s+"), " ").trim()
        val words = cleaned.split(' ').filter { it.isNotBlank() }
        if (words.size != 2) return null
        return cleanTeam(words[0]) to cleanTeam(words[1])
    }
}
