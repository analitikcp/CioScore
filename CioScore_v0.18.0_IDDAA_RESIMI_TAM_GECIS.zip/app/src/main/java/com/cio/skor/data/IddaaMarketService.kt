package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Official Iddaa sportsbook feed.
 *
 * Source: https://sportsbookv2.iddaa.com/sportsbook
 * Events endpoint returns event-level markets in JSON; market-config maps
 * (t, st) to the Turkish market name. No Mackolik scraping is used here.
 */
class IddaaMarketService {
    data class OpenedMarketMatch(
        val matchId: String,
        val homeTeam: String,
        val awayTeam: String,
        val matchTime: String,
        val ms1: String? = null,
        val msX: String? = null,
        val ms2: String? = null,
        val hasHtFt: Boolean = false,
        val hasCorrectScore: Boolean = false,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
        val correctScoreOdds: LinkedHashMap<String, String> = linkedMapOf()
    ) {
        val hasMatchResult: Boolean get() = ms1 != null || msX != null || ms2 != null
    }

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val marketMatches: Int,
        val httpEvents: Int,
        val httpMarketConfig: Int,
        val error: String? = null
    )

    private data class MarketConfig(val name: String)

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private companion object {
        const val BASE = "https://sportsbookv2.iddaa.com/sportsbook"
        const val EVENTS = "$BASE/events?st=1&type=0&version=0"
        const val CONFIG = "$BASE/get_market_config"
    }

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(30_000L) {
            try {
                val eventsResponse = get(EVENTS)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, -1, 0, "İddaa events HTTP hatası")
                val configResponse = get(CONFIG)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, eventsResponse.code, -1, "İddaa market config HTTP hatası")

                val configs = parseMarketConfig(configResponse.body)
                val parsed = parseEvents(eventsResponse.body, configs)
                val today = LocalDate.now(ZoneId.systemDefault())
                val todayMatches = parsed.filter {
                    runCatching {
                        Instant.ofEpochSecond(it.first)
                            .atZone(ZoneId.systemDefault()).toLocalDate() == today
                    }.getOrDefault(true)
                }.map { it.second }

                val marketMatches = todayMatches.count { it.hasHtFt || it.hasCorrectScore }
                Result(
                    matches = todayMatches,
                    scanned = todayMatches.size,
                    marketMatches = marketMatches,
                    httpEvents = eventsResponse.code,
                    httpMarketConfig = configResponse.code
                )
            } catch (e: Exception) {
                Result(emptyList(), 0, 0, -1, -1, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, 0, -1, -1, "İddaa resmi veri taraması zaman aşımına uğradı")
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun get(url: String): HttpResult? = runCatching {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json, text/plain, */*")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Origin", "https://www.iddaa.com")
            .header("Referer", "https://www.iddaa.com/")
            .build()
        client.newCall(request).execute().use { response ->
            HttpResult(response.code, response.body?.string().orEmpty())
        }
    }.getOrNull()

    private fun parseMarketConfig(response: HttpResult): Map<String, MarketConfig> {
        val root = JSONObject(response.body)
        val data = root.optJSONObject("data") ?: return emptyMap()
        val markets = data.optJSONObject("m") ?: return emptyMap()
        val out = HashMap<String, MarketConfig>()
        val keys = markets.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = markets.optJSONObject(key) ?: continue
            out[key] = MarketConfig(item.optString("n", "Unknown Market"))
        }
        return out
    }

    private fun parseEvents(
        response: HttpResult,
        configs: Map<String, MarketConfig>
    ): List<Pair<Long, OpenedMarketMatch>> {
        val root = JSONObject(response)
        val events = root.optJSONObject("data")?.optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Pair<Long, OpenedMarketMatch>>(events.length())

        for (index in 0 until events.length()) {
            val event = events.optJSONObject(index) ?: continue
            val id = event.optString("i", "")
            val home = event.optString("hn", "").trim()
            val away = event.optString("an", "").trim()
            if (id.isBlank() || home.isBlank() || away.isBlank()) continue

            val timestamp = event.optLong("d", 0L)
            val matchTime = if (timestamp > 0) {
                Instant.ofEpochSecond(timestamp).atZone(ZoneId.systemDefault()).toLocalTime().toString().take(5)
            } else "--:--"

            var ms1: String? = null
            var msX: String? = null
            var ms2: String? = null
            val htFt = linkedMapOf<String, String>()
            val correctScore = linkedMapOf<String, String>()
            val markets = event.optJSONArray("m")

            if (markets != null) {
                for (mIndex in 0 until markets.length()) {
                    val market = markets.optJSONObject(mIndex) ?: continue
                    val t = market.optInt("t", -1)
                    val st = market.optInt("st", -1)
                    val config = configs["${t}_${st}"]
                    val name = normalize(config?.name ?: "")
                    val outcomes = market.optJSONArray("o") ?: continue

                    when {
                        isMatchResult(name) -> {
                            for (oIndex in 0 until outcomes.length()) {
                                val outcome = outcomes.optJSONObject(oIndex) ?: continue
                                val label = normalizeOutcome(outcome.optString("n", ""))
                                val odd = outcome.optDouble("odd", Double.NaN)
                                if (!odd.isFinite() || odd <= 1.0) continue
                                val value = formatOdd(odd)
                                when (label) {
                                    "1" -> ms1 = value
                                    "x", "0" -> msX = value
                                    "2" -> ms2 = value
                                }
                            }
                        }
                        isHtFt(name) -> {
                            for (oIndex in 0 until outcomes.length()) {
                                val outcome = outcomes.optJSONObject(oIndex) ?: continue
                                val label = outcome.optString("n", "").trim().uppercase(Locale.ROOT)
                                val odd = outcome.optDouble("odd", Double.NaN)
                                if (label.matches(Regex("^[1X2]/[1X2]$")) && odd.isFinite() && odd > 1.0) {
                                    htFt[label] = formatOdd(odd)
                                }
                            }
                        }
                        isCorrectScore(name) -> {
                            for (oIndex in 0 until outcomes.length()) {
                                val outcome = outcomes.optJSONObject(oIndex) ?: continue
                                val label = outcome.optString("n", "").trim()
                                val odd = outcome.optDouble("odd", Double.NaN)
                                if (label.matches(Regex("^\\d{1,2}[-:]\\d{1,2}$")) && odd.isFinite() && odd > 1.0) {
                                    correctScore[label.replace(':', '-')] = formatOdd(odd)
                                }
                            }
                        }
                    }
                }
            }

            // Only expose a match when at least one relevant official market exists.
            if (ms1 != null || msX != null || ms2 != null || htFt.isNotEmpty() || correctScore.isNotEmpty()) {
                out += timestamp to OpenedMarketMatch(
                    matchId = id,
                    homeTeam = home,
                    awayTeam = away,
                    matchTime = matchTime,
                    ms1 = ms1,
                    msX = msX,
                    ms2 = ms2,
                    hasHtFt = htFt.isNotEmpty(),
                    hasCorrectScore = correctScore.isNotEmpty(),
                    htFtOdds = htFt,
                    correctScoreOdds = correctScore
                )
            }
        }
        return out
    }

    private fun isMatchResult(name: String): Boolean =
        name == "mac sonucu" || name == "match result"

    private fun isHtFt(name: String): Boolean =
        name.contains("ilk yari / mac sonucu") ||
            name.contains("ilk yari/mac sonucu") ||
            name.contains("ilk yari mac sonucu") ||
            name.contains("first half / match result") ||
            name.contains("half time / full time")

    private fun isCorrectScore(name: String): Boolean =
        name.contains("dogru skor") || name.contains("correct score") || name.contains("mac skoru")

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('&', ' ')
        v = Normalizer.normalize(v, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        v = v.replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ç', 'c').replace('ö', 'o').replace('ü', 'u')
        return v.replace(Regex("\\s+"), " ").trim()
    }

    private fun normalizeOutcome(value: String): String =
        value.trim().lowercase(Locale.ROOT).replace("0", "x")

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    fun findForTeamPair(
        matches: List<OpenedMarketMatch>,
        homeTeam: String,
        awayTeam: String
    ): OpenedMarketMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) && MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
