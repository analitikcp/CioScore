package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.bottomsheet.BottomSheetDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.DropReason
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener { showDiagnostics() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all 5 score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all 6 before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, source ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Kaynaklar: $completed/${repo.sourceCount} — $source"
                            }
                        }
                    }
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    scanStatus.text = "Tüm tahmin kaynakları başarısız oldu."
                    Toast.makeText(this@MainActivity, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else ""

                val rawScores = results.sumOf { it.scores.size }
                val filteredScores = results.flatMap { result: SourceResult -> result.scores }
                    .filter(::isDisplayable)
                val invalidScores = rawScores - filteredScores.size
                val scores: List<ScoreModel> = filteredScores.distinctBy {
                    "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                    "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                    "${it.predictedScore}|${it.source.trim().lowercase()}"
                }

                // Official Iddaa enrichment is optional for the main prediction list.
                // Never let a slow/unavailable official feed block the core scan.
                val officialResult = try {
                    withTimeoutOrNull(10_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) return@launch

                val unified = MatchMerger.mergeMatches(
                    scores,
                    officialResult?.matches.orEmpty()
                )

                val displayableUnified = unified.filter { it.predictions.isNotEmpty() }
                val iddaaMatched = unified.count { it.officialMatch != null }

                val reports = results.map { result ->
                    val status = when {
                        result.httpCode !in 200..299 -> ParserStatus.FAILED
                        result.scores.isEmpty() -> ParserStatus.DOM_CHANGED
                        result.error != null -> ParserStatus.DEGRADED
                        else -> ParserStatus.HEALTHY
                    }
                    ParserHealthReport(
                        sourceName = result.source,
                        httpCode = result.httpCode,
                        rawHtmlBytes = result.rawHtmlBytes,
                        parsedCount = result.scores.size,
                        durationMs = result.durationMs,
                        status = status,
                        errorMessage = result.error
                    )
                }
                val drops = buildList {
                    if (invalidScores > 0) add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                    val domChanged = reports.count { it.status == ParserStatus.DOM_CHANGED }
                    if (domChanged > 0) add(DropReason(PipelineStage.PARSER, "DOM_CHANGED", domChanged, reports.filter { it.status == ParserStatus.DOM_CHANGED }.map { it.sourceName }))
                    // Official Iddaa fixtures are intentionally included in the
                    // identity graph as anchors. An official-only fixture is not a
                    // merge failure: it simply has no prediction source attached.
                    // Count it separately so MERGE diagnostics describe actual
                    // prediction loss rather than the size of the official roster.
                    val officialOnly = unified.count {
                        it.officialMatch != null && it.predictions.isEmpty()
                    }
                    if (officialOnly > 0) {
                        add(DropReason(
                            PipelineStage.IDDAA_ENRICHMENT,
                            "OFFICIAL_ONLY_FIXTURE",
                            officialOnly
                        ))
                    }

                    // This is the meaningful enrichment gap for prediction cards:
                    // prediction-bearing fixtures for which no official Iddaa anchor
                    // was found. Do not include official-only fixtures here.
                    val noOfficial = unified.count {
                        it.predictions.isNotEmpty() && it.officialMatch == null
                    }
                    if (noOfficial > 0) {
                        add(DropReason(
                            PipelineStage.IDDAA_ENRICHMENT,
                            "OFFICIAL_NOT_MATCHED",
                            noOfficial
                        ))
                    }
                }
                ObservabilityBus.publish(
                    ScanTrace(
                        parserReports = reports,
                        stageMetrics = linkedMapOf(
                            PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                            PipelineStage.PARSER to rawScores,
                            PipelineStage.NORMALIZATION to scores.size,
                            PipelineStage.IDENTITY to unified.size,
                            PipelineStage.CONFIDENCE to unified.count { it.fixtureConfidence >= 0.80 },
                            PipelineStage.MERGE to displayableUnified.size,
                            PipelineStage.IDDAA_ENRICHMENT to iddaaMatched,
                            PipelineStage.UI to displayableUnified.size
                        ),
                        dropReasons = drops,
                        totalDurationMs = System.currentTimeMillis() - scanStartMs
                    )
                )

                val baseGroups = displayableUnified
                    // iddaa.com is source 6 for identity/market enrichment; it does
                    // not add new prediction-only cards to the main analysis list.
                    .map { match ->
                    SofaScoreService.MatchGroupData(
                        homeTeam = match.mainHomeTeam,
                        awayTeam = match.mainAwayTeam,
                        predictions = match.predictions.map { (source, score) ->
                            ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                        }
                    )
                }

                // SofaScore is enrichment only. If its endpoint is slow/down,
                // render the already merged source data instead of losing the scan.
                val groupsWithIds = try {
                    withTimeoutOrNull(5_000L) {
                        sofaScore.enrichTeamIds(baseGroups)
                    } ?: baseGroups
                } catch (_: Exception) {
                    baseGroups
                }

                // IMPORTANT: enrichTeamIds preserves input order. Do not re-find
                // the official fixture by fuzzy team names here; that would create
                // a second, weaker matching layer and can reintroduce duplicates.
                // GlobalFixtureMatcher is the single identity authority.
                allGroups = displayableUnified.mapIndexed { index, unifiedMatch ->
                    val match = groupsWithIds.getOrNull(index)
                    val official = unifiedMatch.officialMatch

                    MatchGroup(
                        homeTeam = match?.homeTeam ?: unifiedMatch.mainHomeTeam,
                        awayTeam = match?.awayTeam ?: unifiedMatch.mainAwayTeam,
                        predictions = match?.predictions ?: unifiedMatch.predictions.map { (source, score) ->
                            ScoreModel(unifiedMatch.mainHomeTeam, unifiedMatch.mainAwayTeam, score, source)
                        },
                        iddaaMs1 = official?.ms1,
                        iddaaMsX = official?.msX,
                        iddaaMs2 = official?.ms2,
                        htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                        hasHtFt = official?.hasHtFt == true,
                        matchTimestamp = official?.matchTimestamp ?: 0L,
                        displayTime = official?.matchTime ?: "--:--",
                        displayDate = official?.matchDate ?: "",
                        homeTeamId = match?.homeTeamId,
                        awayTeamId = match?.awayTeamId
                    )
                }
                // One identity engine -> one fixture -> one UI card. There is no
                // second canonical groupBy pass because that can collapse distinct
                // same-team fixtures and hide identity errors.
                .distinctBy { MatchMerger.key(it.homeTeam, it.awayTeam) }
                .sortedWith(
                    compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                        .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                        .thenBy { it.homeTeam.lowercase() }
                )

                val previousTrace = ObservabilityBus.lastTrace.value
                if (previousTrace != null) {
                    ObservabilityBus.publish(previousTrace.copy(
                        stageMetrics = previousTrace.stageMetrics.toMutableMap().apply { this[PipelineStage.UI] = allGroups.size },
                        totalDurationMs = System.currentTimeMillis() - scanStartMs
                    ))
                }
                adapter.submitList(allGroups)
                scanStatus.text = "${allGroups.size} maç • Teşhis: 🔍"
                focusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                scanStatus.text = "Tarama hatası: ${e.javaClass.simpleName}"
                Toast.makeText(
                    this@MainActivity,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) setScanningUi(false)
            }
        }
    }


    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    companion object {
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 28, 40, 36)
        }

        fun addText(text: String, bold: Boolean = false, size: Float = 14f) {
            box.addView(TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 5, 0, 5)
            })
        }

        addText("SCAN DIAGNOSTIC PANEL [#${trace.scanId}]", true, 19f)
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        addText("SÜRE: ${trace.totalDurationMs} ms  •  DURUM: $successful/${trace.parserReports.size} kaynak", true)
        addText("PIPELINE TRACE", true, 16f)
        trace.stageMetrics.forEach { (stage, count) -> addText("• ${stage.name.padEnd(20)} : $count") }

        addText("PARSER HEALTH", true, 16f)
        trace.parserReports.forEach { r ->
            addText("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}")
        }

        addText("DROPPED ITEMS", true, 16f)
        if (trace.dropReasons.isEmpty()) addText("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            addText("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }

        scroll.addView(box)
        dialog.setContentView(scroll)
        dialog.show()
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        if (active) scanStatus.text = "5 kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
