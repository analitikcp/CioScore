package com.cio.skor.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FixtureIdentityTest {
    @Test fun aliasesShareOneTeamIdentity() {
        assertEquals(
            TeamAliasCanonicalizer.identity("AEK Athens FC").canonicalId,
            TeamAliasCanonicalizer.identity("AEK Atina").canonicalId
        )
        assertEquals(
            TeamAliasCanonicalizer.identity("LASK Linz").canonicalId,
            TeamAliasCanonicalizer.identity("LASK").canonicalId
        )
    }

    @Test fun differentCompetitionsDoNotMerge() {
        val a = GlobalFixtureMatcher.Record("Team A", "Team B", "1-0", "A", competitionName = "Premier League")
        val b = GlobalFixtureMatcher.Record("Team A", "Team B", "1-0", "B", competitionName = "FA Cup")
        assertFalse(GlobalFixtureMatcher.isSameMatchPipeline(a, b))
    }

    @Test fun differentKnownKickoffsDoNotMerge() {
        val a = GlobalFixtureMatcher.Record("Team A", "Team B", "1-0", "A", matchTimestamp = 1_000_000L)
        val b = GlobalFixtureMatcher.Record("Team A", "Team B", "1-0", "B", matchTimestamp = 20_000_000L)
        assertFalse(GlobalFixtureMatcher.isSameMatchPipeline(a, b))
    }

    @Test fun sameFixtureWithDifferentNamesMerges() {
        val a = ScoreModel("AEK Athens FC", "LASK Linz", "1-0", "FP.com", matchTimestamp = 100_000L, competitionName = "Europa League")
        val b = ScoreModel("AEK Atina", "LASK", "2-1", "PredictZ", matchTimestamp = 120_000L, competitionName = "Europa League")
        val result = GlobalFixtureMatcher.merge(listOf(a, b), emptyList())
        assertEquals(1, result.size)
        assertEquals(2, result.first().predictions.size)
    }
}
