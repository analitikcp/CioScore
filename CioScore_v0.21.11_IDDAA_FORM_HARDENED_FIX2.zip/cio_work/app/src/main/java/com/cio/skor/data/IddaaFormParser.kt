package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** First-party Iddaa team-form reader. */
class IddaaFormParser {
    data class TeamMatchResult(
        val opponentName: String,
        val score: String,
        val isHome: Boolean,
        val resultType: String,
        val date: String = "",
        val league: String = "",
        val source: String = "FORM"
    )

    private val http = HttpClient()
    private val base = "https://sportslive.iddaa.com/api"

    suspend fun fetchTeamLastMatches(teamId: Long, limit: Int = 5): List<TeamMatchResult> =
        withContext(Dispatchers.IO) {
            if (teamId <= 0L) return@withContext emptyList()
            val safeLimit = limit.coerceIn(1, 20)
            val url = "$base/team/$teamId/lastmatches?limit=$safeLimit"
            val (code, body) = http.get(url, "https://www.iddaa.com/")
            if (code !in 200..299 || body.isNullOrBlank()) return@withContext emptyList()
            runCatching { parse(JSONObject(body), teamId).take(safeLimit) }.getOrDefault(emptyList())
        }

    suspend fun fetchH2H(matchId: String, teamId: Long? = null, limit: Int = 5): List<TeamMatchResult> =
        withContext(Dispatchers.IO) {
            if (matchId.isBlank()) return@withContext emptyList()
            val safeLimit = limit.coerceIn(1, 20)
            val url = "$base/match/${matchId.trim()}/h2h"
            val (code, body) = http.get(url, "https://www.iddaa.com/")
            if (code !in 200..299 || body.isNullOrBlank()) return@withContext emptyList()
            runCatching { parse(JSONObject(body), teamId).take(safeLimit) }.getOrDefault(emptyList())
        }

    private fun parse(root: JSONObject, teamId: Long?): List<TeamMatchResult> {
        val array = findArray(root, "matches", "lastMatches", "events", "data") ?: return emptyList()
        val out = mutableListOf<TeamMatchResult>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val homeObj = firstObject(item, "homeTeam", "home", "ht")
            val awayObj = firstObject(item, "awayTeam", "away", "at")
            val homeName = firstString(item, "homeTeamName", "homeName", "home", "hn")
                .ifBlank { firstString(homeObj, "name", "teamName", "n") }
            val awayName = firstString(item, "awayTeamName", "awayName", "away", "an")
                .ifBlank { firstString(awayObj, "name", "teamName", "n") }
            if (homeName.isBlank() || awayName.isBlank()) continue

            val homeId = firstLong(item, "homeTeamId", "homeId", "hid", "hi") ?: firstLong(homeObj, "id", "teamId", "i")
            val awayId = firstLong(item, "awayTeamId", "awayId", "aid", "ai") ?: firstLong(awayObj, "id", "teamId", "i")
            val isHome: Boolean? = when {
                teamId != null && homeId == teamId -> true
                teamId != null && awayId == teamId -> false
                else -> firstBoolean(item, "isHome", "home")
            }
            // H2H has no focal team ID in the endpoint call. Never silently
            // assume the first side is home; only explicit feed metadata may decide.
            if (isHome == null) continue

            val homeScore = firstInt(item, "homeScore", "homeGoals", "hs", "hg")
            val awayScore = firstInt(item, "awayScore", "awayGoals", "as", "ag")
            val score = if (homeScore != null && awayScore != null) "$homeScore-$awayScore"
            else firstString(item, "score", "result", "finalScore")
            if (score.isBlank()) continue

            val parts = score.replace("–", "-").replace("—", "-").split("-")
            val result = if (parts.size >= 2) {
                val h = parts[0].trim().toIntOrNull()
                val a = parts[1].trim().toIntOrNull()
                if (h != null && a != null) {
                    val teamGoals = if (isHome) h else a
                    val oppGoals = if (isHome) a else h
                    when {
                        teamGoals > oppGoals -> "G"
                        teamGoals < oppGoals -> "M"
                        else -> "B"
                    }
                } else normalizeResult(firstString(item, "resultType", "result"))
            } else normalizeResult(firstString(item, "resultType", "result"))

            out += TeamMatchResult(
                opponentName = if (isHome) awayName else homeName,
                score = score,
                isHome = isHome,
                resultType = result,
                date = firstString(item, "date", "matchDate", "eventDate", "d"),
                league = firstString(item, "league", "leagueName", "competition", "competitionName", "tournament")
            )
        }
        return out
    }

    private fun findArray(root: JSONObject, vararg keys: String): JSONArray? {
        for (key in keys) {
            val direct = root.optJSONArray(key)
            if (direct != null) return direct
            val obj = root.optJSONObject(key)
            if (obj != null) {
                findArray(obj, *keys)?.let { return it }
            }
        }
        return root.optJSONObject("data")?.let { data ->
            keys.firstNotNullOfOrNull { data.optJSONArray(it) }
        }
    }

    private fun firstObject(o: JSONObject?, vararg keys: String): JSONObject? =
        keys.firstNotNullOfOrNull { o?.optJSONObject(it) }

    private fun firstString(o: JSONObject?, vararg keys: String): String =
        keys.asSequence().mapNotNull { key -> o?.opt(key)?.toString()?.trim() }
            .firstOrNull { it.isNotBlank() && it != "null" } ?: ""

    private fun firstLong(o: JSONObject?, vararg keys: String): Long? =
        keys.asSequence().mapNotNull { key ->
            when (val v = o?.opt(key)) {
                is Number -> v.toLong().takeIf { it > 0L }
                is String -> v.trim().toLongOrNull()?.takeIf { it > 0L }
                else -> null
            }
        }.firstOrNull()

    private fun firstInt(o: JSONObject?, vararg keys: String): Int? =
        keys.asSequence().mapNotNull { key ->
            when (val v = o?.opt(key)) {
                is Number -> v.toInt()
                is String -> v.trim().toIntOrNull()
                else -> null
            }
        }.firstOrNull()

    private fun firstBoolean(o: JSONObject?, vararg keys: String): Boolean? =
        keys.asSequence().mapNotNull { key ->
            when (val v = o?.opt(key)) {
                is Boolean -> v
                is String -> v.trim().lowercase().let { if (it == "true") true else if (it == "false") false else null }
                else -> null
            }
        }.firstOrNull()

    private fun normalizeResult(value: String): String = when (value.uppercase()) {
        "W", "WIN", "G" -> "G"
        "D", "DRAW", "B" -> "B"
        "L", "LOSS", "M" -> "M"
        else -> "?"
    }
}
