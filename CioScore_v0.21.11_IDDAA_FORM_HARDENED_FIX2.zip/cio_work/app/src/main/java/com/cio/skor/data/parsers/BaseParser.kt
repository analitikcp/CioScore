package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.Instant
import java.time.OffsetDateTime
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale

abstract class BaseParser(protected val source: String) {
    data class FixtureMetadata(
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = ""
    )

    protected val scoreRegex = Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()
    protected fun score(s: String): String? = scoreRegex.find(s)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        return t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
    }
    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }

    /** Best-effort source fixture identity. Site-specific parsers can still add stronger IDs later. */
    protected fun fixtureMetadata(element: Element): FixtureMetadata {
        val nodes = generateSequence(element) { it.parent() }.take(5).toList()
        fun attr(vararg names: String): String {
            for (node in nodes) for (name in names) {
                val v = node.attr(name).trim()
                if (v.isNotBlank()) return v
            }
            return ""
        }
        val id = attr("data-match-id", "data-matchid", "data-event-id", "data-eventid", "data-fixture-id", "data-fixtureid", "data-id", "data-code", "data-event-code")
        val rawDateTime = attr("datetime", "data-datetime", "data-kickoff", "data-start", "data-date-time")
        val rawDate = attr("data-date", "data-match-date", "data-event-date", "data-day", "date")
        val rawTime = attr("data-time", "data-match-time", "data-kickoff-time", "time")
        val league = attr("data-league", "data-league-name", "data-competition", "data-competition-name", "data-tournament", "data-tournament-name")
        val parsed = parseTimestamp(rawDateTime.ifBlank { rawDate + if (rawTime.isNotBlank()) "T$rawTime" else "" })
        val date = rawDate.ifBlank { if (parsed > 0L) Instant.ofEpochMilli(parsed).toString().substring(0, 10) else "" }
        val time = when {
            rawTime.matches(Regex("^\\d{1,2}:\\d{2}")) -> rawTime.take(5).padStart(5, '0')
            parsed > 0L -> runCatching {
                val z = java.time.ZonedDateTime.ofInstant(Instant.ofEpochMilli(parsed), java.time.ZoneId.systemDefault())
                "%02d:%02d".format(Locale.ROOT, z.hour, z.minute)
            }.getOrDefault("--:--")
            else -> "--:--"
        }
        return FixtureMetadata(id, parsed, date, time, league)
    }

    protected fun predictionKey(model: ScoreModel): String = buildString {
        append(model.source.lowercase(Locale.ROOT)).append('|')
        append(com.cio.skor.data.TeamAliasCanonicalizer.identity(model.homeTeam).canonicalId).append('|')
        append(com.cio.skor.data.TeamAliasCanonicalizer.identity(model.awayTeam).canonicalId).append('|')
        append(model.matchTimestamp).append('|').append(model.matchDate).append('|')
        append(model.competitionName.lowercase(Locale.ROOT)).append('|').append(model.predictedScore)
    }

    private fun parseTimestamp(value: String): Long {
        val v = value.trim()
        if (v.isBlank()) return 0L
        v.toLongOrNull()?.let { n -> return if (n < 10_000_000_000L) n * 1000L else n }
        val candidates = listOf<() -> Long>(
            { OffsetDateTime.parse(v).toInstant().toEpochMilli() },
            { Instant.parse(v).toEpochMilli() },
            { LocalDateTime.parse(v, DateTimeFormatter.ISO_LOCAL_DATE_TIME).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() },
            { LocalDateTime.parse(v.replace(' ', 'T'), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm", Locale.ROOT)).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() }
        )
        for (candidate in candidates) try { return candidate() } catch (_: DateTimeParseException) {} catch (_: Exception) {}
        return 0L
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
