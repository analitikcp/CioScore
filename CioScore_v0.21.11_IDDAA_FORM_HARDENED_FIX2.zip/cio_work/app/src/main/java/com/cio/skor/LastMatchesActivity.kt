package com.cio.skor

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.SofaScoreService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LastMatchesActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_last_matches)

        val teamName = intent.getStringExtra(EXTRA_TEAM_NAME).orEmpty().ifBlank { "Takım" }
        val iddaaTeamId = intent.getLongExtra(EXTRA_IDDAA_TEAM_ID, -1L)
        val sofaTeamId = intent.getLongExtra(EXTRA_SOFA_TEAM_ID, -1L)
        val officialMatchId = intent.getStringExtra(EXTRA_IDDAA_MATCH_ID).orEmpty()
        val title = findViewById<TextView>(R.id.tvTeamName)
        val status = findViewById<TextView>(R.id.tvHistoryStatus)
        val recycler = findViewById<RecyclerView>(R.id.rvLastMatches)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }

        title.text = teamName
        recycler.layoutManager = LinearLayoutManager(this)
        status.text = "Son 5 maç yükleniyor…"

        scope.launch {
            val iddaaParser = IddaaFormParser()
            val iddaaMatches = if (iddaaTeamId > 0L) {
                runCatching { iddaaParser.fetchTeamLastMatches(iddaaTeamId, 5) }.getOrDefault(emptyList())
            } else emptyList()
            val h2hMatches = if (officialMatchId.isNotBlank()) {
                runCatching { iddaaParser.fetchH2H(officialMatchId, iddaaTeamId.takeIf { it > 0L }, 5) }
                    .getOrDefault(emptyList())
                    .map { it.copy(source = "H2H") }
            } else emptyList()

            if (isFinishing || isDestroyed) return@launch

            if (iddaaMatches.isNotEmpty() || h2hMatches.isNotEmpty()) {
                recycler.adapter = IddaaLastMatchesAdapter(iddaaMatches + h2hMatches)
                status.text = when {
                    iddaaMatches.isNotEmpty() && h2hMatches.isNotEmpty() -> "İddaa resmi verisi • Son 5 maç + H2H"
                    h2hMatches.isNotEmpty() -> "İddaa resmi verisi • H2H"
                    else -> "İddaa resmi verisi • Son 5 maç"
                }
            } else {
                // Fallback kept intentionally: if the official feed did not expose
                // a team ID for this fixture, the existing SofaScore enrichment can
                // still provide history without blocking the main screen.
                val sofa = SofaScoreService()
                val sofaMatches = if (sofaTeamId > 0L) {
                    runCatching { sofa.getLastFiveByTeamId(sofaTeamId) }.getOrDefault(emptyList())
                } else emptyList()
                recycler.adapter = LastMatchesAdapter(sofaMatches)
                status.text = if (sofaMatches.isEmpty()) "Son 5 maç verisi alınamadı." else "Yedek kaynak • Son 5 maç"
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TEAM_NAME = "TEAM_NAME"
        const val EXTRA_IDDAA_TEAM_ID = "IDDAA_TEAM_ID"
        const val EXTRA_SOFA_TEAM_ID = "SOFA_TEAM_ID"
        const val EXTRA_IDDAA_MATCH_ID = "IDDAA_MATCH_ID"
    }
}


private class IddaaLastMatchesAdapter(
    private val matches: List<IddaaFormParser.TeamMatchResult>
) : RecyclerView.Adapter<IddaaLastMatchesAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val opponent: TextView = view.findViewById(R.id.tvMatchOpponent)
        val meta: TextView = view.findViewById(R.id.tvMatchMeta)
        val result: TextView = view.findViewById(R.id.tvResult)
        val score: TextView = view.findViewById(R.id.tvScore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_last_match, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = matches[position]
        holder.opponent.text = match.opponentName
        holder.meta.text = buildString {
            if (match.date.isNotBlank()) append(match.date).append(" • ")
            append(if (match.isHome) "EV" else "DEP")
            if (match.league.isNotBlank()) append(" • ").append(match.league)
            if (match.source.isNotBlank()) append(" • ").append(match.source)
        }
        holder.score.text = match.score.replace("-", " - ")
        val (letter, color) = when (match.resultType) {
            "G" -> "G" to Color.rgb(16, 185, 129)
            "B" -> "B" to Color.rgb(100, 116, 139)
            "M" -> "M" to Color.rgb(239, 68, 68)
            else -> "?" to Color.rgb(148, 163, 184)
        }
        holder.result.text = letter
        holder.result.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    override fun getItemCount(): Int = matches.size
}

private class LastMatchesAdapter(
    private val matches: List<SofaScoreService.RecentMatch>
) : RecyclerView.Adapter<LastMatchesAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val opponent: TextView = view.findViewById(R.id.tvMatchOpponent)
        val meta: TextView = view.findViewById(R.id.tvMatchMeta)
        val result: TextView = view.findViewById(R.id.tvResult)
        val score: TextView = view.findViewById(R.id.tvScore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_last_match, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = matches[position]
        holder.opponent.text = match.opponent
        holder.meta.text = buildString {
            if (match.date.isNotBlank()) append(match.date).append(" • ")
            append(if (match.isHome) "EV" else "DEP")
            if (match.league.isNotBlank()) append(" • ").append(match.league)
        }
        holder.score.text = match.score.replace("-", " - ")

        val (letter, color) = when (match.result) {
            "G" -> "G" to Color.rgb(16, 185, 129)
            "B" -> "B" to Color.rgb(100, 116, 139)
            "M" -> "M" to Color.rgb(239, 68, 68)
            else -> "?" to Color.rgb(148, 163, 184)
        }

        holder.result.text = letter
        holder.result.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    override fun getItemCount(): Int = matches.size
}
