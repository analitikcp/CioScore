package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * SoccerSeer parser based on the older working parser that successfully
 * returned SoccerSeer scores. Only an explicit finished/full-time marker
 * rejects a card; prediction cards without such a marker are accepted.
 */
class SoccerSeerParser : BaseParser("SoccerSeer") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val candidates = doc.select(
            "article, li, tr, [class*=match], [class*=prediction], [class*=game], " +
            "[class*=fixture], [class*=score]"
        )

        for (el in candidates) {
            val raw = buildRaw(el)
            if (raw.length !in 8..500) continue
            if (isFinished(raw)) continue

            val predicted = findPredictionScore(raw) ?: continue
            val pair = extractTeams(el, raw, predicted.first) ?: continue

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue
            if (looksLikeNoise(home) || looksLikeNoise(away)) continue

            val meta = fixtureMetadata(el)
            val model = ScoreModel(home, away, predicted.second, source, meta.sourceMatchId, meta.matchTimestamp, meta.matchDate, meta.matchTime, meta.competitionName)
            out[predictionKey(model)] = model
        }

        return out.values.take(100)
    }

    private fun buildRaw(el: Element): String = buildString {
        append(el.text())
        listOf("title", "aria-label", "data-match", "data-event", "data-teams").forEach { key ->
            val value = el.attr(key).trim()
            if (value.isNotEmpty()) append(" | ").append(value)
        }
    }.replace(Regex("\\s+"), " ").trim()

    /** Returns score start position + normalized score. */
    private fun findPredictionScore(raw: String): Pair<Int, String>? {
        val normalized = raw.replace(Regex("\\s+"), " ").trim()
        val keywords = listOf(
            "correct score", "predicted score", "prediction", "predicted", "pred", "tip"
        )

        for (keyword in keywords) {
            val idx = normalized.indexOf(keyword, ignoreCase = true)
            if (idx >= 0) {
                val end = minOf(normalized.length, idx + keyword.length + 180)
                val windowStart = idx + keyword.length
                val window = normalized.substring(windowStart, end)
                val m = scoreRegex.find(window)
                if (m != null) {
                    val absolute = windowStart + m.range.first
                    return absolute to "${m.groupValues[1]}-${m.groupValues[2]}"
                }
            }
        }

        // IMPORTANT: older SoccerSeer HTML cards often contain only ONE score
        // and do not put a 'Prediction:' label immediately before it.
        val all = scoreRegex.findAll(normalized).toList()
        if (all.size == 1) {
            val m = all[0]
            return m.range.first to "${m.groupValues[1]}-${m.groupValues[2]}"
        }

        return null
    }

    private fun extractTeams(el: Element, raw: String, scoreStart: Int): Pair<String, String>? {
        val homeSelectors = listOf(
            ".home", ".home-team", ".homeTeam", ".team-home", ".team1",
            "[class*=home-team]", "[class*=homeTeam]"
        )
        val awaySelectors = listOf(
            ".away", ".away-team", ".awayTeam", ".team-away", ".team2",
            "[class*=away-team]", "[class*=awayTeam]"
        )

        val home = homeSelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { it.length in 2..80 }
        val away = awaySelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { it.length in 2..80 }
        if (home != null && away != null) return home to away

        // Fallback used by the previously working implementation.
        var beforeScore = raw.substring(0, scoreStart).trim()
        beforeScore = beforeScore.replace(
            Regex("(?i)\\b(?:prediction|pred|tip|correct score|correct score predictions?|confidence|conf\\.)\\b.*$"),
            ""
        ).trim()

        val separators = listOf(" v ", " vs ", " - ", " – ", " — ", " @ ")
        for (sep in separators) {
            val parts = beforeScore.split(sep, limit = 2)
            if (parts.size == 2) {
                val h = cleanTeamText(parts[0])
                val a = cleanTeamText(parts[1])
                if (h.length in 2..80 && a.length in 2..80) return h to a
            }
        }

        return null
    }

    private fun cleanTeamText(value: String): String = value
        .replace(Regex("\\b(?:today|tomorrow|preview|analysis|prediction|predicted|correct score|odds|tips?)\\b.*$", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\b(?:FT|Final|Finished|Full Time)\\b.*$", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', ',', ';', '.')

    private fun isFinished(text: String): Boolean {
        val t = text.lowercase()
        val padded = " $t "
        val markers = listOf(
            " full time ", " full-time ", " finished ", " final ", " ft ",
            " result:", " result ", " completed ", " match ended ", " ended "
        )
        return markers.any { padded.contains(it) }
    }

    private fun looksLikeNoise(value: String): Boolean {
        val v = value.trim()
        if (v.matches(Regex("[0-9:%./+ -]+"))) return true
        val bad = listOf(
            "prediction", "predicted", "correct score", "confidence", "odds",
            "results", "best leagues", "score", "tip", "tips"
        )
        return bad.any { v.equals(it, ignoreCase = true) }
    }
}
