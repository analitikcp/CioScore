# CioScore v0.21.10 – Iddaa Form First

- Added `IddaaFormParser` for `sportslive.iddaa.com/api/team/{teamId}/lastmatches?limit=5` and H2H endpoint support.
- Main match model now carries first-party Iddaa home/away team IDs when exposed by the official event feed.
- Team history UI now tries Iddaa first and falls back to the existing SofaScore history only when an Iddaa team ID/result is unavailable.
- Existing main scan, HT/FT, popular bets and fixture matching logic is preserved.
