# v0.24.87 – Edge-to-edge bottom inset fix

The main `RecyclerView` now applies the Android navigation-bar bottom inset plus a small safety gap.
This prevents the last match card and its lower controls from sitting underneath the system navigation buttons.

The change is UI-only: odds providers, ScoreModel, İddaa verification, Bet365 fallback chain, and the independent ORANLAR panel are unchanged.
