CIO Score 0.8.6

MightyTips parser build-safe revision.
PredictZ, FP.com and WinDrawWin are preserved from 0.8.4.
MightyTips is source-specific and anchored to the site's "Score:" field.
