# CioScore v0.20.0

Final official Iddaa bulletin integration.

- MS1/MSX/MS2: official Iddaa Match Result market only.
- HT/FT: official Iddaa First Half / Match Result market.
- Kickoff time: official Iddaa event timestamp `d`, Europe/Istanbul.
- UI: kickoff time -> MS1/MSX/MS2 -> teams -> TAHMİN MS1/MSX/MS2 -> HT/FT.
- Removed CioScore 0-100/confidence/result label from match cards.
- No Mackolik odds integration.
