package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Parser for TheFootballPredictions correct-score page.
 *
 * The current page does not expose matches as a conventional table.  Each
 * fixture is represented by a match <a> whose href contains:
 *   /home-vs-away-prediction-tip-date-...-match-game-id-...
 *
 * The visible page text places the fixture date/time and the Tip score around
 * that anchor.  We therefore use the match URL as the stable team boundary
 * and only use the nearest DOM container for time/score extraction.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    private val matchHref = Regex(
        "(?i)/([^/]+?)-vs-([^/]+?)-prediction-tip-date-"
    )
    private val timeRegex = Regex("(?<!\\d)([01]\\d|2[0-3]):[0-5]\\d(?!\\d)")
    private val dateRegex = Regex("(?<!\\d)(\\d{2}\\.\\d{2})(?!\\d)")

    override fun parse(doc: Document): List<ScoreModel> {
        val results = LinkedHashMap<String, ScoreModel>()

        // Match links are the reliable fixture boundary on this page.  Do not
        // fall back to every <tr>: the current site is not a normal table.
        val matchLinks = doc.select("a[href*=-vs-][href*=-prediction-tip-date-]")

        for (link in matchLinks) {
            try {
                val parsed = parseMatchLink(link) ?: continue
                val container = findMatchContainer(link) ?: continue
                val containerText = clean(container.text())

                val predictedScore = findScore(container, link) ?: continue
                if (!ScoreModel.hasRenderablePrediction(predictedScore)) continue

                val time = timeRegex.find(containerText)?.value ?: "--:--"
                val date = dateRegex.find(containerText)?.groupValues?.get(1).orEmpty()

                val href = link.absUrl("href").ifBlank { link.attr("href").trim() }
                val key = if (href.isNotBlank()) href else parsed.sourceMatchId

                results[key] = ScoreModel(
                    homeTeam = parsed.homeTeam,
                    awayTeam = parsed.awayTeam,
                    predictedScore = predictedScore,
                    source = source,
                    sourceMatchId = href,
                    matchDate = date,
                    matchTime = time
                )
            } catch (_: Exception) {
                // One malformed fixture must not invalidate the source.
            }
        }

        return results.values.toList()
    }

    private data class ParsedMatch(
        val homeTeam: String,
        val awayTeam: String,
        val sourceMatchId: String
    )

    private fun parseMatchLink(link: Element): ParsedMatch? {
        val href = link.attr("href").trim()
        val path = href.substringBefore("?").substringBefore("#")
        val match = matchHref.find(path) ?: return null

        val home = slugToTeam(match.groupValues[1])
        val away = slugToTeam(match.groupValues[2])
        if (!valid(home, away)) return null

        return ParsedMatch(home, away, href)
    }

    private fun slugToTeam(value: String): String {
        return team(
            value
                .replace(Regex("[-_]+"), " ")
                .replace(Regex("\\s+"), " ")
        )
    }

    /**
     * Walk only a few ancestors.  The first container containing one time and
     * one score is the fixture card/row; walking farther can accidentally join
     * two neighbouring fixtures.
     */
    private fun findMatchContainer(link: Element): Element? {
        var current: Element? = link
        repeat(6) {
            val node = current ?: return null
            val text = clean(node.text())
            val hasTime = timeRegex.containsMatchIn(text)
            val hasScore = extractStandardScore(text) != null
            if (hasTime && hasScore) return node
            current = node.parent()
        }
        return null
    }

    private fun findScore(container: Element, matchLink: Element): String? {
        // Prefer an element explicitly associated with the Tip/score column.
        val explicitSelectors = listOf(
            ".correct-score",
            ".prediction-tip",
            ".predicted-score",
            "[class*=correct-score]",
            "[class*=prediction-tip]",
            "[class*=predicted-score]"
        )
        for (selector in explicitSelectors) {
            for (element in container.select(selector)) {
                score(element.text())?.let { return it }
            }
        }

        // Current layout renders the score as text near the match link.  The
        // first score in the smallest fixture container is the Tip value;
        // Pts (e.g. 13 87) are deliberately ignored because they contain no
        // '-' or ':' separator.
        score(container.text())?.let { return it }

        // Last-resort: inspect the immediate siblings of the match link before
        // accepting a wider container.
        var sibling = matchLink.nextElementSibling()
        repeat(4) {
            val node = sibling ?: return@repeat
            score(node.text())?.let { return it }
            sibling = node.nextElementSibling()
        }
        return null
    }
}
