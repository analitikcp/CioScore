package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * SureWinPredict correct-score parser.
 *
 * The /correct-score/YYYY-MM-DD page renders each fixture as an <a> whose
 * href is a match URL such as:
 *   /match/mc-alger-vs-mc-oran-1611385-2/2026-09-22
 *
 * The visible text is compact (time, home, away, probability, tip, odds), so
 * the match URL is used as the authoritative home/away boundary and the
 * visible text is used only for time + correct-score extraction.
 */
class SureWinPredictParser : BaseParser("SureWinPredict") {

    private val matchHref = Regex(
        "(?i)^/match/([^/?#]+?)-vs-([^/?#]+?)-(\\d+)-\\d+(?:/|$)"
    )
    private val timeRegex = Regex("(?<!\\d)([01]\\d|2[0-3]):[0-5]\\d(?!\\d)")

    override fun parse(doc: Document): List<ScoreModel> {
        val results = LinkedHashMap<String, ScoreModel>()

        // Every prediction card on the current correct-score page is a match
        // link.  Do not parse generic tr/div elements: that also sees live,
        // article and navigation content and caused the previous 0-result /
        // DOM_CHANGED failure.
        val matchLinks = doc.select("a[href*=/match/]")

        for (link in matchLinks) {
            try {
                val parsed = parseMatchLink(link) ?: continue
                val text = clean(link.text())

                // A normal prediction card has a kickoff time and a correct
                // score token.  The probability/odds are intentionally ignored.
                val predictedScore = extractPrediction(text) ?: continue
                if (!ScoreModel.hasRenderablePrediction(predictedScore)) continue

                val time = timeRegex.find(text)?.value ?: "--:--"
                val href = link.absUrl("href").ifBlank { link.attr("href").trim() }
                if (href.isBlank()) continue

                results[href] = ScoreModel(
                    homeTeam = parsed.homeTeam,
                    awayTeam = parsed.awayTeam,
                    predictedScore = predictedScore,
                    source = source,
                    sourceMatchId = href,
                    matchTime = time
                )
            } catch (_: Exception) {
                // Ignore malformed/non-fixture links and continue parsing.
            }
        }

        return results.values.toList()
    }

    private data class ParsedMatch(
        val homeTeam: String,
        val awayTeam: String
    )

    private fun parseMatchLink(link: Element): ParsedMatch? {
        val href = link.attr("href").trim()
        val path = href.substringBefore("?").substringBefore("#")
        val match = matchHref.find(path) ?: return null

        val home = slugToTeam(match.groupValues[1])
        val away = slugToTeam(match.groupValues[2])
        if (!valid(home, away)) return null

        return ParsedMatch(home, away)
    }

    private fun slugToTeam(value: String): String {
        return team(
            value
                .replace(Regex("[-_]+"), " ")
                .replace(Regex("\\s+"), " ")
        )
    }

    private fun extractPrediction(text: String): String? {
        // On the correct-score page the only score-like token in a normal
        // prediction card is the Tip (e.g. 2-0, 1-1, 2-1). Probability is
        // rendered as 18.52% and odds as 5.40, so they cannot match this regex.
        val scores = scoreRegex.findAll(text)
            .mapNotNull { score(it.value) }
            .toList()

        return scores.firstOrNull()
    }
}
