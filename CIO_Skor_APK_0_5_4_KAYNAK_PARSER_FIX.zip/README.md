CIO Score 0.4.9

0.4.7 de çalışan kaynak tarama + güvenli çıktı temizleme tabanı.
0.4.8 derleme hatasına neden olan findAll/groupValues yaklaşımı kullanılmaz.
