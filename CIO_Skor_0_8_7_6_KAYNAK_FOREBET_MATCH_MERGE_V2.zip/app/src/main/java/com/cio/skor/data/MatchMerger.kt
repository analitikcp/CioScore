package com.cio.skor.data

import java.text.Normalizer

/**
 * Cross-source fixture merger.  All raw predictions are collected first;
 * only then are team names canonicalized and fixtures grouped.
 */
object MatchMerger {
    fun canonicalTeam(value: String): String {
        var s = Normalizer.normalize(value.trim().lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("ø", "o")
            .replace("đ", "d")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace("&", " and ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")

        // Competition/site labels that frequently appear around the club name.
        val removable = setOf(
            "fc", "fk", "cf", "sc", "afc", "ac", "cd", "rc", "sk", "nk",
            "bv", "ks", "ss", "sv", "if", "bk", "mk", "as", "us", "ud"
        )
        s = s.split(' ').filter { it.isNotBlank() && it !in removable }.joinToString(" ")

        // Exact variants observed in the six-source feed.
        val aliases = mapOf(
            "jagiellonia bialystok" to "jagiellonia",
            "jagiellonia" to "jagiellonia",
            "kairat almaty" to "kairat",
            "kairat" to "kairat",
            "ferencvarosi" to "ferencvaros",
            "ferencvaros budapest" to "ferencvaros",
            "ferencvaros" to "ferencvaros",
            "jablonec 97" to "jablonec",
            "jablonec" to "jablonec",
            "rangers" to "rangers",
            "fc twente" to "twente",
            "twente enschede" to "twente",
            "twente" to "twente",
            "riga football club" to "riga",
            "riga" to "riga",
            "ki klaksvik" to "klaksvik",
            "klaksvik" to "klaksvik",
            "agf aarhus" to "aarhus",
            "aarhus gf" to "aarhus",
            "aarhus" to "aarhus",
            "fc thun" to "thun",
            "thun" to "thun",
            "nk rijeka" to "rijeka",
            "rijeka" to "rijeka",
            "partizan belgrade" to "partizan",
            "partizan" to "partizan",
            "inter club descaldes" to "inter escaldes",
            "inter d escaldes" to "inter escaldes",
            "inter escaldes" to "inter escaldes",
            "cska sofia" to "cska sofia",
            "qarabag fk" to "qarabag",
            "qarabag" to "qarabag",
            "lech poznan" to "lech poznan",
            "fc inter" to "inter turku",
            "inter turku" to "inter turku",
            "inter milan" to "inter",
            "internazionale" to "inter",
            "manchester united" to "manutd",
            "manchester utd" to "manutd",
            "man utd" to "manutd",
            "manchester city" to "mancity",
            "man city" to "mancity",
            "tottenham hotspur" to "tottenham",
            "tottenham" to "tottenham",
            "psv eindhoven" to "psv",
            "paris saint germain" to "psg",
            "paris sg" to "psg",
            "borussia dortmund" to "dortmund",
            "bayern munich" to "bayern",
            "bayern munchen" to "bayern",
            "lillestrom" to "lillestrom",
            "egnatia rogozhine" to "egnatia",
            "egnatia rogzhine" to "egnatia",
            "egnatia" to "egnatia",
            "st truidense" to "st truidense",
            "sint truidense" to "st truidense",
            "omonia nicosia" to "omonia nicosia",
            "fc thun" to "thun"
        )

        return aliases[s] ?: s.replace(" ", "")
    }

    fun key(home: String, away: String): String =
        canonicalTeam(home) + "||" + canonicalTeam(away)
}
