# CIO Score 0.4.7

0.4.6 build fix. The previous cleanup layer contained invalid Kotlin `String.replace`/regex usage.
0.4.7 keeps the working 0.4.5 scanning architecture and fixes only the cleanup code compilation issues.

Upload this ZIP to GitHub and run the existing build workflow.
