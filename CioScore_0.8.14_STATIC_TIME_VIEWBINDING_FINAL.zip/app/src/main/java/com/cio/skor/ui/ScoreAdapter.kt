package com.cio.skor.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.databinding.ItemScoreBinding
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.MatchGroup
import com.cio.skor.data.ScoreModel

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String) -> Unit = {}
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val binding: ItemScoreBinding) : RecyclerView.ViewHolder(binding.root) {
        val card: LinearLayout = binding.scoreCard
        val content: LinearLayout = binding.scoreContent
    }

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    // UI MASKESİ: ScoreModel.source değerleri değiştirilmez.
    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5"
    )

    private fun displaySourceName(source: String): String {
        val normalized = source.trim().lowercase()

        return sourceLabels[normalized]
            ?: sourceLabels.entries
                .firstOrNull { normalized.contains(it.key) }
                ?.value
            ?: normalized
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)

        displayedList =
            if (q.isEmpty()) {
                fullList
            } else {
                fullList.filter { match ->
                    val home =
                        MatchMerger.normalizeTeamName(match.homeTeam)
                    val away =
                        MatchMerger.normalizeTeamName(match.awayTeam)

                    home.contains(q) ||
                        away.contains(q) ||
                        MatchMerger.isSameTeam(home, q) ||
                        MatchMerger.isSameTeam(away, q)
                }
            }

        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemScoreBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        val holder = VH(binding)
        val ctx = parent.context
        holder.card.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            val horizontal = dp(ctx, 8)
            val vertical = dp(ctx, 6)
            setMargins(horizontal, vertical, horizontal, vertical)
        }
        holder.card.background = GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt())
            cornerRadius = dp(ctx, 14).toFloat()
            setStroke(dp(ctx, 1), 0xFFE7EAF0.toInt())
        }
        holder.card.elevation = dp(ctx, 3).toFloat()
        return holder
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.content.removeAllViews()

        // ------------------------------------------------
        // BAŞLAMA SAATİ — statik XML ViewBinding.
        // Veri yoksa bile alan görünür ve --:-- gösterilir.
        // ------------------------------------------------
        val displayTime = match.matchTime.trim().ifBlank { "--:--" }
        holder.binding.tvMatchTime.text = "BAŞLAMA • $displayTime"
        holder.binding.tvMatchTime.visibility = View.VISIBLE

        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam) }
                isClickable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam) }
                isClickable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.content.addView(teams)

        // ------------------------------------------------
        // MS 1 / MS X / MS 2 — SofaScore odds
        // ------------------------------------------------
        match.odds?.let { odds ->
            val oddsRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 6) }
            }
            fun oddsCell(label: String, value: String): LinearLayout {
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                box.addView(TextView(ctx).apply {
                    text = label
                    textSize = 10f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                })
                box.addView(TextView(ctx).apply {
                    text = value
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                    gravity = Gravity.CENTER
                })
                return box
            }
            oddsRow.addView(oddsCell("MS 1", odds.home))
            oddsRow.addView(oddsCell("MS X", odds.draw))
            oddsRow.addView(oddsCell("MS 2", odds.away))
            holder.content.addView(oddsRow)
        }

        // ------------------------------------------------
        // KONSENSÜS
        // ------------------------------------------------

        val counts =
            match.predictions
                .groupingBy {
                    it.predictedScore
                }
                .eachCount()

        val consensus =
            counts.entries.maxWithOrNull(
                compareBy<Map.Entry<String, Int>> {
                    it.value
                }.thenBy {
                    it.key
                }
            )

        if (
            consensus != null &&
            match.predictions.size > 1
        ) {

            val label =
                TextView(ctx).apply {

                    text = "KONSENSÜS"
                    textSize = 12f

                    gravity =
                        Gravity.CENTER

                    setTextColor(
                        0xFF008F83.toInt()
                    )

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = dp(ctx, 4)
                        }
                }

            val score =
                TextView(ctx).apply {

                    text = consensus.key
                    textSize = 30f

                    gravity =
                        Gravity.CENTER

                    setTextColor(
                        0xFF009688.toInt()
                    )

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            val strength =
                TextView(ctx).apply {

                    text =
                        "${consensus.value}/${match.predictions.size} kaynak"

                    textSize = 12f

                    gravity =
                        Gravity.CENTER

                    setTextColor(
                        0xFFFFFFFF.toInt()
                    )

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    background =
                        GradientDrawable().apply {
                            setColor(
                                0xFF18A86B.toInt()
                            )
                            cornerRadius =
                                dp(ctx, 18).toFloat()
                        }

                    val h = dp(ctx, 18)
                    val v = dp(ctx, 8)

                    setPadding(
                        h,
                        v,
                        h,
                        v
                    )
                }

            val wrap =
                LinearLayout(ctx).apply {
                    gravity = Gravity.CENTER
                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            wrap.addView(strength)

            holder.content.addView(label)
            holder.content.addView(score)
            holder.content.addView(wrap)
        }

        // ------------------------------------------------
        // AYIRICI
        // ------------------------------------------------

        val divider =
            View(ctx).apply {
                setBackgroundColor(
                    0xFFE7EAF0.toInt()
                )
            }

        holder.content.addView(
            divider,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(ctx, 1)
            ).apply {
                topMargin = dp(ctx, 8)
                bottomMargin = dp(ctx, 4)
            }
        )

        // ------------------------------------------------
        // KAYNAK + SKORLAR
        // ------------------------------------------------

        match.predictions.forEach { prediction ->

            val row =
                LinearLayout(ctx).apply {

                    orientation =
                        LinearLayout.HORIZONTAL

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = dp(ctx, 2)
                            bottomMargin = dp(ctx, 2)
                        }

                    clipChildren = false
                    clipToPadding = false
                }

            val source =
                TextView(ctx).apply {

                    text =
                        displaySourceName(
                            prediction.source
                        )

                    textSize = 12f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    ellipsize =
                        TextUtils.TruncateAt.END

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1f
                        )
                }

            val arrow =
                TextView(ctx).apply {

                    text = "→"
                    textSize = 16f

                    setTextColor(
                        0xFF667085.toInt()
                    )

                    gravity =
                        Gravity.CENTER

                    layoutParams =
                        LinearLayout.LayoutParams(
                            dp(ctx, 28),
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            val score =
                TextView(ctx).apply {

                    text =
                        prediction.predictedScore

                    textSize = 15f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    gravity =
                        Gravity.END or
                            Gravity.CENTER_VERTICAL

                    // Sabit 60dp yok: skor kendi genişliğini alır.
                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            row.addView(source)
            row.addView(arrow)
            row.addView(score)

            holder.content.addView(row)
        }

        // Kartın kendisi de dinamik yükseklikte kalır.
        holder.card.layoutParams =
            (holder.card.layoutParams
                ?: RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )).apply {
                    width =
                        ViewGroup.LayoutParams.MATCH_PARENT
                    height =
                        ViewGroup.LayoutParams.WRAP_CONTENT
                }
    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 14f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
