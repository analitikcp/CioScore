package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vitibet daily-football parser.
 *
 * IMPORTANT: Vitibet's current football tips page contains multiple date tabs
 * and a large general match-detail pool. We deliberately do NOT scrape that
 * pool. We read only rows belonging to TODAY in the football quicktips table.
 *
 * The current 20.09.2026 table is exposed as rows such as:
 * 20.09 | SC Paderborn 07 | 1899 Hoffenheim | 1 | : | 2 | ...
 *
 * A small homepage fallback is retained for installations where Vitibet serves
 * the compact daily football block instead of the legacy table.
 */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val today = todayDdMm()
        val todayFull = todayFullDate()

        // PRIMARY: today's rows in Vitibet's football quicktips table.
        for (row in doc.select("tr")) {
            parseTodayRow(row, today, todayFull)?.let { out[it.matchKey] = it }
        }

        // FALLBACK: compact "Football tips dd.MM.yyyy" block on the home page.
        if (out.isEmpty()) {
            parseTodayBlock(doc, todayFull).forEach { out[it.matchKey] = it }
        }

        return out.values.toList()
    }

    private fun parseTodayRow(row: Element, today: String, todayFull: String): ScoreModel? {
        val cells = row.select("td,th")
            .map { clean(it.text()) }
            .filter { it.isNotBlank() }
        if (cells.size < 4) return null

        val dateIndex = cells.indexOfFirst { cell ->
            cell.matches(Regex("^${Regex.escape(today)}(?:\\.\\d{4})?\\.?$")) ||
                cell.matches(Regex("^${Regex.escape(todayFull)}\\.?$"))
        }
        if (dateIndex < 0) return null

        val scoreInfo = findScore(cells, dateIndex + 1) ?: return null
        val beforeScore = cells.subList(dateIndex + 1, scoreInfo.startIndex)

        // The row layout is date -> home -> away -> score. Keep only the last
        // two textual cells immediately before the score to avoid percentages,
        // league labels, or other table metadata.
        val teamCells = beforeScore
            .map(::cleanTeam)
            .filter(::isTeamCandidate)
        if (teamCells.size < 2) return null

        val home = teamCells[teamCells.size - 2]
        val away = teamCells[teamCells.size - 1]
        return build(home, away, scoreInfo.score, todayFull, extractTime(row), extractFixtureId(row))
    }

    private data class ScoreHit(val startIndex: Int, val score: String)

    private fun findScore(cells: List<String>, from: Int): ScoreHit? {
        for (i in from until cells.size) {
            val one = Regex("^(\\d{1,2})\\s*:\\s*(\\d{1,2})$").find(cells[i])
            if (one != null) {
                return ScoreHit(i, "${one.groupValues[1]}-${one.groupValues[2]}")
            }
            if (i + 2 < cells.size && cells[i].matches(Regex("^\\d{1,2}$")) &&
                cells[i + 1] == ":" && cells[i + 2].matches(Regex("^\\d{1,2}$"))) {
                return ScoreHit(i, "${cells[i]}-${cells[i + 2]}")
            }
        }
        return null
    }

    private fun parseTodayBlock(doc: Document, todayFull: String): List<ScoreModel> {
        val body = clean(doc.body()?.text().orEmpty())
        val marker = Regex("(?i)(?:Football tips|Futbol tahminleri)\\s+${Regex.escape(todayFull)}")
            .find(body) ?: return emptyList()
        val start = marker.range.last + 1
        val tail = body.substring(start)

        val rows = Regex("(?i)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(\\d{1,2})\\s*:\\s*(\\d{1,2})\\s+(.+?)(?=\\s+\\d{1,2}:\\d{2}\\s+|$)")
        val out = ArrayList<ScoreModel>()
        for (m in rows.findAll(tail)) {
            val time = m.groupValues[1]
            val home = cleanTeam(m.groupValues[2])
            val away = cleanTeam(m.groupValues[5])
                .replace(Regex("\\s+(?:1X|X2|12|10|02|1|X|2)\\s*$"), "")
                .trim()
            if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) continue
            build(home, away, "${m.groupValues[3]}-${m.groupValues[4]}", todayFull, time, "")?.let(out::add)
        }
        return out
    }

    private fun build(
        homeRaw: String,
        awayRaw: String,
        score: String,
        date: String,
        time: String,
        sourceMatchId: String
    ): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            sourceMatchId = sourceMatchId,
            matchDate = date,
            matchTime = time.ifBlank { "--:--" }
        )
    }

    private fun extractTime(row: Element): String {
        val m = Regex("\\b(\\d{1,2}:\\d{2})\\b").find(clean(row.text()))
        return m?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun extractFixtureId(row: Element): String {
        return row.select("a[href]")
            .asSequence()
            .map { it.attr("href") }
            .mapNotNull { Regex("(?i)[?&]fixture_id=(\\d+)").find(it)?.groupValues?.getOrNull(1) }
            .firstOrNull()
            .orEmpty()
    }

    private fun todayDdMm(): String = SimpleDateFormat("dd.MM", Locale.US).format(Date())
    private fun todayFullDate(): String = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..70) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction|score|1|0|2)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|Odds|Status)\\b.*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', ':', '|')
}
