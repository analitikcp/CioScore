package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

/**
 * Maçkolik İddaa Programı'nı TEK HTTP isteğiyle okur.
 *
 * Doğrulanmış sayfa: https://arsiv2.mackolik.com/Iddaa-Programi
 * Her maç satırındaki ilk üç ondalık değer MS1 / MSX / MS2 olarak alınır.
 */
class MackolikOddsService {
    companion object {
        private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    data class MackolikMatch(
        val homeTeam: String,
        val awayTeam: String,
        val odds: SofaScoreService.Odds
    )

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val matches: List<MackolikMatch>,
        val error: String? = null
    )

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(PROGRAM_URL)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                .header("Referer", "https://arsiv2.mackolik.com/")
                .build()

            client.newCall(request).execute().use { response ->
                val html = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result(
                        response.code,
                        html.length,
                        emptyList(),
                        "HTTP ${response.code}"
                    )
                }

                val doc = Jsoup.parse(html)
                val parsed = LinkedHashMap<String, MackolikMatch>()

                // TEK MAÇ TESTİNDE ÇALIŞAN MANTIK AYNI ŞEKİLDE BÜTÜN SATIRLARA UYGULANIYOR.
                // Mackolik'in gerçek satır formatı:
                // [saat] TAKIM 1 - TAKIM 2  [5 haneli kod] [MS1] [MSX] [MS2] ...
                val rows = doc.select("tr")
                val oddsRegex = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
                val rowRegex = Regex(
                    "^(?:\\d{1,2}:\\d{2}\\s+)?(.+?)\\s+-\\s+(.+?)\\s+\\d{5}\\s+" +
                        "([0-9]{1,2}[.,][0-9]{2})\\s+" +
                        "([0-9]{1,2}[.,][0-9]{2})\\s+" +
                        "([0-9]{1,2}[.,][0-9]{2})(?:\\s|$)"
                )
                val codeRegex = Regex("\\b\\d{5}\\b")

                for (row in rows) {
                    val text = row.text().replace(Regex("\\s+"), " ").trim()
                    if (text.isBlank()) continue

                    // Önce tek maç testinde kanıtlanan doğrudan satır regex'i.
                    val direct = rowRegex.find(text)
                    if (direct != null) {
                        val home = cleanTeam(direct.groupValues[1])
                        val away = cleanTeam(direct.groupValues[2])
                        val values = listOf(
                            direct.groupValues[3],
                            direct.groupValues[4],
                            direct.groupValues[5]
                        ).map { it.replace(',', '.') }

                        if (isValidTeam(home) && isValidTeam(away) && isValidOdds(values)) {
                            val key = MatchMerger.key(home, away)
                            parsed[key] = MackolikMatch(
                                homeTeam = home,
                                awayTeam = away,
                                odds = SofaScoreService.Odds(values[0], values[1], values[2])
                            )
                            continue
                        }
                    }

                    // İkinci toleranslı geçiş: saat / HTML hücre düzeni değişse bile
                    // önce 5 haneli MS kodunu, ardından ilk üç 1X2 oranını bul.
                    val code = codeRegex.find(text) ?: continue
                    val prefix = text.substring(0, code.range.first).trim()
                    val afterCode = text.substring(code.range.last + 1)
                    val odds = oddsRegex.findAll(afterCode)
                        .take(3)
                        .map { it.value.replace(',', '.') }
                        .toList()

                    if (odds.size < 3) continue

                    val teams = extractTeams(prefix) ?: continue
                    val home = cleanTeam(teams.first)
                    val away = cleanTeam(teams.second)
                    if (!isValidTeam(home) || !isValidTeam(away)) continue

                    val key = MatchMerger.key(home, away)
                    parsed[key] = MackolikMatch(
                        homeTeam = home,
                        awayTeam = away,
                        odds = SofaScoreService.Odds(odds[0], odds[1], odds[2])
                    )
                }

                Result(response.code, html.length, parsed.values.toList())
            }
        } catch (e: Exception) {
            Result(
                -1,
                0,
                emptyList(),
                "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}"
            )
        }
    }

    fun findForTeamPair(
        matches: List<MackolikMatch>,
        homeTeam: String,
        awayTeam: String
    ): MackolikMatch? {
        return matches.firstOrNull {
            MatchMerger.isSameTeam(it.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(it.awayTeam, awayTeam)
        }
    }

    private fun cleanTeam(value: String): String {
        return value
            .replace(Regex("\\s+"), " ")
            .trim(' ', '|', '•')
            .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
            .trim()
    }

    private fun isValidTeam(home: String, away: String = ""): Boolean {
        val bad = setOf("İddaa", "Programı", "MS", "Kod", "Lig", "Tümü", "Tarih")
        return home.length in 2..80 &&
            (away.isEmpty() || away.length in 2..80) &&
            bad.none { home.equals(it, true) || (away.isNotEmpty() && away.equals(it, true)) }
    }

    private fun isValidOdds(values: List<String>): Boolean =
        values.size == 3 && values.all { it.matches(Regex("\\d{1,2}\\.\\d{2}")) }

    private fun extractTeams(prefix: String): Pair<String, String>? {
        var value = prefix
            .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
            .trim()

        // Satırdaki ilk " - " takım ayracıdır. Maçkolik bazı uzun takım
        // adlarını kısaltabildiği için ikinci bir ayraç oluşsa bile burada
        // ilk ayraç üzerinden çalışıyoruz.
        val dash = value.indexOf(" - ")
        if (dash <= 0 || dash >= value.length - 3) return null

        val home = cleanTeam(value.substring(0, dash))
        val away = cleanTeam(value.substring(dash + 3))
        return if (isValidTeam(home, away)) home to away else null
    }
}
