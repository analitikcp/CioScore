# CioScore v0.11.1 — Maçkolik All-Match Parser

Bu sürümde tek maç testinde doğrulanan Maçkolik `tr` satırı mantığı bütün bültene uygulanır.

- Tek HTTP GET: `https://arsiv2.mackolik.com/Iddaa-Programi`
- Her `tr` satırı taranır.
- `5 haneli kod + MS1 + MSX + MS2` dizisi aranır.
- İlk geçiş doğrudan tek-maç testindeki satır formatını kullanır.
- İkinci geçiş daha toleranslı kod/oran taraması yapar.
- Aynı maçlar `MatchMerger` ile fuzzy takım adı eşleştirmesiyle mevcut CIO kartlarına bağlanır.
- Kartlarda bulunan oranlar `Maçkolik • MS 1X2` olarak gösterilir.
