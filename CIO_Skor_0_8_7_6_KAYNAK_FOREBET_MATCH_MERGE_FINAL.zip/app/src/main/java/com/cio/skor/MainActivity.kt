package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * Same match = same normalized home + normalized away team.
     * We deliberately keep home/away order so a reversed fixture is not merged.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        // Önce tüm ham skorları tek havuzda topluyoruz. Sonra takım adlarını
        // canonicalTeam() ile normalize edip aynı ev/deplasman eşleşmesini tek
        // maç altında birleştiriyoruz. Bir kaynağın aynı maçı iki farklı adla
        // döndürmesi durumunda da tek tahmin tutulur.
        val grouped = LinkedHashMap<String, MutableList<ScoreModel>>()

        for (score in scores) {
            val key = matchKey(score.homeTeam, score.awayTeam)
            grouped.getOrPut(key) { mutableListOf() }.add(score)
        }

        return grouped.values.mapNotNull { raw ->
            // Aynı kaynaktan aynı maç için birden fazla kayıt geldiyse ilk
            // geçerli tahmini tut. Kaynak sayısı böylece gerçekten farklı
            // kaynakları gösterir.
            val ordered = raw.distinctBy { canonicalSource(it.source) }
            if (ordered.isEmpty()) return@mapNotNull null

            MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    private fun matchKey(home: String, away: String): String {
        return canonicalTeam(home) + "||" + canonicalTeam(away)
    }

    private fun canonicalSource(value: String): String =
        value.trim().lowercase().replace(Regex("\\s+"), " ")

    private fun sameTeam(a: String, b: String): Boolean =
        canonicalTeam(a) == canonicalTeam(b)

    /**
     * Cross-source team-name normalization.
     *
     * The important part is that we do NOT use fuzzy matching here. Fuzzy
     * matching can incorrectly merge different clubs. Instead we normalize
     * accents/punctuation/common prefixes/suffixes and keep a small alias table
     * for the variants actually seen in the six-source feed.
     */
    private fun canonicalTeam(value: String): String {
        var s = value.trim().lowercase()

        // Turkish / European diacritics and apostrophes.
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("ø", "o")
            .replace("đ", "d")
            .replace("ð", "d")
            .replace("þ", "th")

        // Remove punctuation, then normalize whitespace.
        s = s.replace("&", " and ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")

        // Common club labels which are not part of the club identity.
        val removableTokens = setOf(
            "fc", "fk", "cf", "sc", "afc", "ac", "cd", "rc", "sk", "nk",
            "bv", "ks", "ss", "sv", "if", "bk", "mk", "as", "us", "ud"
        )
        s = s.split(' ')
            .filter { it.isNotBlank() && it !in removableTokens }
            .joinToString(" ")

        // Normalize well-known aliases/variants visible in the current feed.
        val aliases = mapOf(
            "kairat almaty" to "kairat",
            "ferencvarosi" to "ferencvaros",
            "ferencvaros budapest" to "ferencvaros",
            "jablonec 97" to "jablonec",
            "fk jablonec" to "jablonec",
            "fc twente" to "twente",
            "twente enschede" to "twente",
            "riga fc" to "riga",
            "riga football club" to "riga",
            "ki klaksvik" to "klaksvik",
            "klaksvik" to "klaksvik",
            "agf aarhus" to "aarhus",
            "aarhus gf" to "aarhus",
            "fc thun" to "thun",
            "thun" to "thun",
            "lech poznan" to "lech poznan",
            "nk rijeka" to "rijeka",
            "rijeka" to "rijeka",
            "partizan belgrade" to "partizan",
            "partizan" to "partizan",
            "inter club descaldes" to "inter escaldes",
            "inter club descaldes" to "inter escaldes",
            "inter d escaldes" to "inter escaldes",
            "inter escaldes" to "inter escaldes",
            "cska sofia" to "cska sofia",
            "cska 1948 sofia" to "cska 1948 sofia",
            "qarabag" to "qarabag",
            "qarabag fk" to "qarabag",
            "manchester united" to "manutd",
            "manchester utd" to "manutd",
            "man utd" to "manutd",
            "manchester city" to "mancity",
            "man city" to "mancity",
            "tottenham hotspur" to "tottenham",
            "tottenham" to "tottenham",
            "internazionale" to "inter",
            "inter milan" to "inter",
            "psv eindhoven" to "psv",
            "paris saint germain" to "psg",
            "paris sg" to "psg",
            "borussia dortmund" to "dortmund",
            "bayern munich" to "bayern",
            "bayern munchen" to "bayern"
        )

        return aliases[s] ?: s.replace(" ", "")
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
