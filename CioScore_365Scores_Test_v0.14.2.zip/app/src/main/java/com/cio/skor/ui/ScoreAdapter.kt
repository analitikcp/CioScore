package com.cio.skor.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.CioScoreEngine
import com.cio.skor.data.FootballDataService
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SofaScoreService

/** One card per unified match; source names are displayed as CIO labels. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    val odds: SofaScoreService.Odds? = null,
    val oddsSource: String = "Maçkolik",
    val historical: FootballDataService.MatchContext? = null
)

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String) -> Unit = {}
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList
    private var strongestMode = false
    private var currentQuery = ""
    private var rankingMode = RankingMode.STRONGEST

    enum class RankingMode { STRONGEST, SCORE_CONSENSUS }
    private val strongestLimit = 15

    // UI MASKESİ: ScoreModel.source değerleri değiştirilmez.
    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5"
    )

    private fun displaySourceName(source: String): String {
        val normalized = source.trim().lowercase()

        return sourceLabels[normalized]
            ?: sourceLabels.entries
                .firstOrNull { normalized.contains(it.key) }
                ?.value
            ?: normalized
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        refreshDisplayed()
    }

    fun setStrongestMode(enabled: Boolean) {
        strongestMode = enabled
        refreshDisplayed()
    }

    fun setRankingMode(mode: RankingMode) {
        rankingMode = mode
        strongestMode = true
        refreshDisplayed()
    }

    fun isStrongestMode(): Boolean = strongestMode

    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        var list = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        if (strongestMode) {
            list = when (rankingMode) {
                RankingMode.STRONGEST -> list.sortedWith(
                    compareByDescending<MatchGroup> { CioScoreEngine.calculate(it.predictions, it.odds, it.historical).score }
                        .thenByDescending { it.predictions.size }
                )
                RankingMode.SCORE_CONSENSUS -> list.sortedWith(
                    compareByDescending<MatchGroup> { CioScoreEngine.calculate(it.predictions, it.odds, it.historical).exactConsensus }
                        .thenByDescending { CioScoreEngine.calculate(it.predictions, it.odds, it.historical).score }
                )
            }.take(strongestLimit)
        }
        displayedList = list
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    /** Update one visible match card without redrawing the whole list. */
    fun updateOdds(homeTeam: String, awayTeam: String, odds: SofaScoreService.Odds, oddsSource: String = "Maçkolik") {
        fun same(match: MatchGroup): Boolean =
            MatchMerger.isSameTeam(match.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(match.awayTeam, awayTeam)

        val fullIndex = fullList.indexOfFirst(::same)
        if (fullIndex >= 0) {
            fullList = fullList.toMutableList().apply {
                val old = this[fullIndex]
                this[fullIndex] = old.copy(odds = odds, oddsSource = oddsSource)
            }
        }

        val displayedIndex = displayedList.indexOfFirst(::same)
        if (displayedIndex >= 0) {
            displayedList = displayedList.toMutableList().apply {
                val old = this[displayedIndex]
                this[displayedIndex] = old.copy(odds = odds, oddsSource = oddsSource)
            }
            notifyItemChanged(displayedIndex)
        }
    }

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val ctx = parent.context

        // Kart: yükseklik kesinlikle WRAP_CONTENT.
        val card = LinearLayout(ctx).apply {

            orientation = LinearLayout.VERTICAL

            layoutParams =
                RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val horizontal = dp(ctx, 8)
                    val vertical = dp(ctx, 6)
                    setMargins(
                        horizontal,
                        vertical,
                        horizontal,
                        vertical
                    )
                }

            val padding = dp(ctx, 10)
            setPadding(
                padding,
                padding,
                padding,
                padding
            )

            background =
                GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(ctx, 14).toFloat()
                    setStroke(
                        dp(ctx, 1),
                        0xFFE7EAF0.toInt()
                    )
                }

            elevation = dp(ctx, 3).toFloat()

            clipChildren = false
            clipToPadding = false
        }

        return VH(card)
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.card.removeAllViews()

        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam) }
                isClickable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam) }
                isClickable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.card.addView(teams)

        // ------------------------------------------------
        // CIO SCORE — tek puanda tüm mevcut verinin özeti
        // ------------------------------------------------
        val cio = CioScoreEngine.calculate(match.predictions, match.odds, match.historical)
        val scoreRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 7) }
        }
        val scoreLabel = TextView(ctx).apply {
            text = "CioScore"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF475467.toInt())
        }
        val scoreValue = TextView(ctx).apply {
            text = "${cio.score}/100" + if (cio.score >= 80) " 🔥" else ""
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val confidence = TextView(ctx).apply {
            text = "Güven: ${cio.confidence}"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER
        }
        scoreRow.addView(scoreLabel)
        scoreRow.addView(scoreValue)
        scoreRow.addView(confidence)
        holder.card.addView(scoreRow)

        // ------------------------------------------------
        // MODEL OLASILIK + PİYASA
        // ------------------------------------------------
        val insight = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 6) }
        }

        val prob = cio.cioProbabilities
        val model = cio.modelProbabilities
        val market = cio.marketProbabilities

        if (cio.historicalConfidence > 0) {
            insight.addView(TextView(ctx).apply {
                text = "MODEL OLASILIK  •  MS1: ${model["1"] ?: 0}%   MSX: ${model["X"] ?: 0}%   MS2: ${model["2"] ?: 0}%"
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF00796B.toInt())
                gravity = Gravity.CENTER
            })
            insight.addView(TextView(ctx).apply {
                val hp = cio.historicalProbabilities
                text = "📊 FOOTBALL-DATA  •  MS1: ${hp["1"] ?: 0}%   MSX: ${hp["X"] ?: 0}%   MS2: ${hp["2"] ?: 0}%  •  Güven ${cio.historicalConfidence}%"
                textSize = 9f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
                gravity = Gravity.CENTER
            })
        }

        insight.addView(TextView(ctx).apply {
            text = if (cio.historicalConfidence > 0) {
                "CIO KONSENSÜS  •  MS1: ${prob["1"] ?: 0}%   MSX: ${prob["X"] ?: 0}%   MS2: ${prob["2"] ?: 0}%"
            } else {
                "CIO OLASILIK  •  MS1: ${prob["1"] ?: 0}%   MSX: ${prob["X"] ?: 0}%   MS2: ${prob["2"] ?: 0}%"
            }
            textSize = if (cio.historicalConfidence > 0) 9f else 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
        })

        if (market.isNotEmpty()) {
            insight.addView(TextView(ctx).apply {
                text = "PİYASA  •  MS1: ${market["1"] ?: 0}%   MSX: ${market["X"] ?: 0}%   MS2: ${market["2"] ?: 0}%"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
            })
        }

        // En çok tekrarlanan 3 skor artık doğrudan kartta görünür.
        if (cio.topScores.isNotEmpty()) {
            val top3 = cio.topScores.joinToString("   •   ") { "${it.score} (${it.percent}%)" }
            insight.addView(TextView(ctx).apply {
                text = "🎯 EN OLASI SKORLAR  •  $top3"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF475467.toInt())
                gravity = Gravity.CENTER
            })
        }
        holder.card.addView(insight)

        // ------------------------------------------------
        // MS 1 / MS X / MS 2 — Maçkolik odds
        // ------------------------------------------------
        match.odds?.let { odds ->
            val oddsRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 6) }
            }
            fun oddsCell(label: String, value: String): LinearLayout {
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                box.addView(TextView(ctx).apply {
                    text = label
                    textSize = 10f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                })
                box.addView(TextView(ctx).apply {
                    text = value
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                    gravity = Gravity.CENTER
                })
                return box
            }
            val oddsHeader = TextView(ctx).apply {
                text = "${match.oddsSource} • MS 1X2"
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 6) }
            }
            holder.card.addView(oddsHeader)

            oddsRow.addView(oddsCell("MS 1", odds.home))
            oddsRow.addView(oddsCell("MS X", odds.draw))
            oddsRow.addView(oddsCell("MS 2", odds.away))
            holder.card.addView(oddsRow)
        }

        // ------------------------------------------------
        // AYIRICI
        // ------------------------------------------------

        val divider =
            View(ctx).apply {
                setBackgroundColor(
                    0xFFE7EAF0.toInt()
                )
            }

        holder.card.addView(
            divider,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(ctx, 1)
            ).apply {
                topMargin = dp(ctx, 8)
                bottomMargin = dp(ctx, 4)
            }
        )

        // ------------------------------------------------
        // KAYNAK + SKORLAR
        // ------------------------------------------------

        match.predictions.forEach { prediction ->

            val row =
                LinearLayout(ctx).apply {

                    orientation =
                        LinearLayout.HORIZONTAL

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = dp(ctx, 2)
                            bottomMargin = dp(ctx, 2)
                        }

                    clipChildren = false
                    clipToPadding = false
                }

            val source =
                TextView(ctx).apply {

                    text =
                        displaySourceName(
                            prediction.source
                        )

                    textSize = 12f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    ellipsize =
                        TextUtils.TruncateAt.END

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1f
                        )
                }

            val arrow =
                TextView(ctx).apply {

                    text = "→"
                    textSize = 16f

                    setTextColor(
                        0xFF667085.toInt()
                    )

                    gravity =
                        Gravity.CENTER

                    layoutParams =
                        LinearLayout.LayoutParams(
                            dp(ctx, 28),
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            val score =
                TextView(ctx).apply {

                    text =
                        prediction.predictedScore

                    textSize = 15f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    gravity =
                        Gravity.END or
                            Gravity.CENTER_VERTICAL

                    // Sabit 60dp yok: skor kendi genişliğini alır.
                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            row.addView(source)
            row.addView(arrow)
            row.addView(score)

            holder.card.addView(row)
        }

        // Kartın kendisi de dinamik yükseklikte kalır.
        holder.card.layoutParams =
            (holder.card.layoutParams
                ?: RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )).apply {
                    width =
                        ViewGroup.LayoutParams.MATCH_PARENT
                    height =
                        ViewGroup.LayoutParams.WRAP_CONTENT
                }
    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 14f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
