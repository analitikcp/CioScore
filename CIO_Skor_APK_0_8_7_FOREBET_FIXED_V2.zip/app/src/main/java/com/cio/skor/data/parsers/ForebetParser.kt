package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Forebet parser. Existing parser API is preserved; only DOM fallbacks are added. */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Legacy/current Forebet pages both use rcnt match rows. The broader
        // fallback catches class variants without scanning unrelated page text.
        val blocks = doc.select("div.rcnt")
            .ifEmpty { doc.select("div[class*=rcnt]") }
            .ifEmpty { doc.select("a.tnmscn").mapNotNull { it.closest("div") } }

        for (block in blocks) {
            val teams = extractTeams(block) ?: continue
            val cleanHome = cleanForebetTeam(teams.first)
            val cleanAway = cleanForebetTeam(teams.second)
            if (!valid(cleanHome, cleanAway)) continue

            val predictedScore = extractCorrectScore(block) ?: continue

            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source
            )
            out[model.matchKey] = model
            if (out.size >= 150) break
        }

        return out.values.toList()
    }

    private fun extractTeams(block: Element): Pair<String, String>? {
        val home = firstText(block, ".homeTeam")
        val away = firstText(block, ".awayTeam")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // Older Forebet pages expose the match name through meta[itemprop=name].
        val meta = block.select("meta[itemprop=name][content]").firstOrNull()
            ?.attr("content")
            ?.trim()
        if (!meta.isNullOrBlank()) {
            val pair = splitTeams(meta)
            if (pair != null) return pair
        }

        // Final fallback: the team link contains the two visible team spans.
        val link = block.select("a.tnmscn").firstOrNull()
        if (link != null) {
            val h = firstText(link, ".homeTeam")
            val a = firstText(link, ".awayTeam")
            if (!h.isNullOrBlank() && !a.isNullOrBlank()) return h to a
        }
        return null
    }

    private fun splitTeams(value: String): Pair<String, String>? {
        val s = value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        val parts = Regex("\\s+(?:vs|v|[-–—])\\s+", RegexOption.IGNORE_CASE).split(s)
        return if (parts.size >= 2) parts[0].trim() to parts[1].trim() else null
    }

    private fun firstText(root: Element, selector: String): String? {
        val element = root.select(selector).firstOrNull() ?: return null
        val span = element.select("span").firstOrNull()?.text()?.takeIf { it.isNotBlank() }
        return (span ?: element.text())
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .takeIf { it.isNotBlank() }
    }

    private fun extractCorrectScore(block: Element): String? {
        // Correct score is explicitly marked by ex_sc on Forebet.
        val candidates = block.select(
            "div.ex_sc.tabonly, div.ex_sc, [class*=ex_sc]"
        )
        for (element in candidates) {
            exactScore(element.text())?.let { return it }
        }

        // Some responses flatten class names/text. Search only within the
        // match row, never the entire document.
        val text = block.text().replace('\u00A0', ' ').replace(Regex("\\s+"), " ")
        val marker = Regex("(?i)correct\\s+score\\s*[:]?\\s*([0-9])\\s*[-:]\\s*([0-9])")
            .find(text)
        if (marker != null) return "${marker.groupValues[1]}-${marker.groupValues[2]}"

        return null
    }

    private fun exactScore(value: String): String? {
        val text = value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
        val match = Regex("^([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})$").matchEntire(text)
            ?: Regex("(?<!\\d)([0-9])\\s*[-:]\\s*([0-9])(?!\\d)").find(text)
            ?: return null
        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun cleanForebetTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')
}
