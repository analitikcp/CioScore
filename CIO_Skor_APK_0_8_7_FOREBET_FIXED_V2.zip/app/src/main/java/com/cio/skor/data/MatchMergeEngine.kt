package com.cio.skor.data

import java.text.Normalizer
import java.util.Locale
import kotlin.math.max

/**
 * Cross-source fixture merger.
 *
 * Parser output is treated as immutable. This class only decides whether two
 * ScoreModel rows describe the same home/away fixture. Missing sources are
 * never manufactured and every real prediction remains attached to its match.
 */
object MatchMergeEngine {

    data class MergedMatch(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>
    )

    data class Result(
        val matches: List<MergedMatch>,
        val scoredSourceCount: Int,
        val scoredSources: List<String>,
        val cleanScoreCount: Int
    )

    private data class TeamKey(
        val normalized: String,
        val tokens: Set<String>
    )

    private val suffixes = listOf(
        "footballclub", "soccerclub", "sportsclub", "sportingclub",
        "club", "football", "soccer", "fc", "fk", "cf", "sc", "afc"
    )

    private val stopWords = setOf(
        "the", "de", "of", "and", "a", "fc", "fk", "cf", "sc", "afc",
        "club", "football", "soccer"
    )

    fun merge(scores: List<ScoreModel>): Result {
        val groups = mutableListOf<MutableList<ScoreModel>>()

        // Process in parser/source order. Existing rows are never discarded;
        // they are only assigned to the closest already-known fixture.
        for (score in scores) {
            val target = groups.firstOrNull { sameFixture(it.first(), score) }
            if (target == null) {
                groups += mutableListOf(score)
            } else {
                target += score
            }
        }

        val merged = groups.map { group ->
            // One prediction per source is displayed. If a parser accidentally
            // emits duplicates, prefer the first valid row from that source.
            val predictions = group.distinctBy { it.source.trim().lowercase(Locale.ROOT) }
            MergedMatch(
                homeTeam = predictions.first().homeTeam,
                awayTeam = predictions.first().awayTeam,
                predictions = predictions
            )
        }

        val scoredSources = scores
            .asSequence()
            .map { it.source.trim() }
            .filter { it.isNotEmpty() }
            .distinctBy { it.lowercase(Locale.ROOT) }
            .sorted()
            .toList()

        return Result(
            matches = merged,
            scoredSourceCount = scoredSources.size,
            scoredSources = scoredSources,
            cleanScoreCount = scores.size
        )
    }

    private fun sameFixture(a: ScoreModel, b: ScoreModel): Boolean {
        // Home/away order is intentional. A reversed fixture must not be merged.
        return teamSimilarity(a.homeTeam, b.homeTeam) >= 0.84 &&
            teamSimilarity(a.awayTeam, b.awayTeam) >= 0.84
    }

    private fun teamSimilarity(a: String, b: String): Double {
        val x = teamKey(a)
        val y = teamKey(b)
        if (x.normalized.isEmpty() || y.normalized.isEmpty()) return 0.0
        if (x.normalized == y.normalized) return 1.0

        val tokenScore = tokenSimilarity(x.tokens, y.tokens)
        val editScore = normalizedLevenshtein(x.normalized, y.normalized)

        // A strong token match is useful for "Galatasaray FC" vs "Galatasaray";
        // edit distance catches small spelling/punctuation variations.
        return max(tokenScore, editScore * 0.92)
    }

    private fun teamKey(value: String): TeamKey {
        var s = transliterate(value)
        s = s.lowercase(Locale.ROOT)
            .replace("&", " and ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

        var compact = s.replace(" ", "")
        var changed = true
        while (changed) {
            changed = false
            for (suffix in suffixes) {
                if (compact.endsWith(suffix) && compact.length > suffix.length + 2) {
                    compact = compact.removeSuffix(suffix)
                    changed = true
                    break
                }
            }
        }

        val tokens = compact
            .replace(Regex("(?<=[a-z])(?=[0-9])"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in stopWords }
            .toSet()

        // When compacting removed spaces, reconstruct a token set from the
        // original cleaned value as well. This keeps multi-word club names
        // comparable without making spaces part of identity.
        val originalTokens = s.split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in stopWords }

        return TeamKey(
            normalized = compact,
            tokens = (tokens + originalTokens).toSet()
        )
    }

    private fun tokenSimilarity(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0

        val intersection = a.intersect(b).size.toDouble()
        val union = a.union(b).size.toDouble()
        val jaccard = if (union == 0.0) 0.0 else intersection / union

        val containment = intersection / minOf(a.size, b.size).toDouble()
        return max(jaccard, containment * 0.90)
    }

    private fun normalizedLevenshtein(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + cost
                )
            }
            val tmp = previous
            previous = current
            current = tmp
        }

        val distance = previous[b.length]
        return 1.0 - distance.toDouble() / max(a.length, b.length).toDouble()
    }

    private fun transliterate(value: String): String {
        var s = value
            .replace('ı', 'i').replace('İ', 'I')
            .replace('ğ', 'g').replace('Ğ', 'G')
            .replace('ü', 'u').replace('Ü', 'U')
            .replace('ş', 's').replace('Ş', 'S')
            .replace('ö', 'o').replace('Ö', 'O')
            .replace('ç', 'c').replace('Ç', 'C')

        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")

        return s
    }
}
