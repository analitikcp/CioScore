package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    // Forebet has changed/redirected its public prediction URLs over time.
    // Try the current predictions endpoint first, then the legacy pages.
    private val forebetUrls = listOf(
        "https://www.forebet.com/en/football-predictions",
        "https://www.forebet.com/en/football-tips-and-predictions-for-today/",
        "https://www.forebet.com/en/football-tips-and-predictions-for-today/by-league",
        "https://www.forebet.com/en/football-tips-and-predictions-for-today/predictions-1x2",
        "https://www.forebet.com/index.php/en/football-tips-and-predictions-for-today",
        "https://www.forebet.com/en/"
    )

    fun get(url: String): Pair<Int, String?> = request(
        url = url,
        userAgent = MOBILE_USER_AGENT,
        referer = null
    )

    fun getForebet(): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null

        for (url in forebetUrls) {
            try {
                val (code, body) = request(
                    url = url,
                    userAgent = DESKTOP_USER_AGENT,
                    referer = "https://www.forebet.com/en/"
                )
                lastCode = code
                lastBody = body

                if (code in 200..299 && !body.isNullOrBlank() && looksLikeForebet(body)) {
                    return code to body
                }
            } catch (_: Exception) {
                // Continue with the next public Forebet endpoint.
            }
        }
        return lastCode to lastBody
    }

    private fun request(url: String, userAgent: String, referer: String?): Pair<Int, String?> {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .header("Upgrade-Insecure-Requests", "1")
            .header("Sec-Fetch-Dest", "document")
            .header("Sec-Fetch-Mode", "navigate")
            .header("Sec-Fetch-Site", "same-origin")

        if (!referer.isNullOrBlank()) builder.header("Referer", referer)

        client.newCall(builder.build()).execute().use { response ->
            return response.code to response.body?.string()
        }
    }

    private fun looksLikeForebet(body: String): Boolean {
        val s = body.lowercase()
        if (s.contains("just a moment") ||
            s.contains("cf-chl-") ||
            s.contains("challenge-platform") ||
            s.contains("attention required") ||
            s.contains("access denied")) return false

        // Accept both the legacy rcnt markup and the current prediction-page
        // markup. The parser itself performs the final validation.
        return s.contains("forebet") &&
            (s.contains("correct score") || s.contains("home team") || s.contains("rcnt"))
    }

    private companion object {
        const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36 CIOScore/0.8"
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    }
}
