package com.cio.skor.data

import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Conservative inference for sources whose current-day pages expose time but omit the date. */
object TimestampInference {
    private val DISPLAY = DateTimeFormatter.ofPattern("dd.MM.yyyy")

    fun inferTodayDateIfTimeOnly(
        date: String,
        time: String,
        source: String,
        pageUrl: String,
        zone: ZoneId = KickoffNormalizer.ZONE
    ): String {
        if (date.isNotBlank() || !isValidTime(time)) return date
        val todayPage = when (source) {
            "DailySports" -> pageUrl.contains("/correct-score", ignoreCase = true)
            "WinDrawWin" -> pageUrl.contains("/predictions/today", ignoreCase = true)
            else -> false
        }
        return if (todayPage) LocalDate.now(zone).format(DISPLAY) else ""
    }

    private fun isValidTime(value: String): Boolean =
        Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(value.trim())
}
