package com.cio.skor.data

/** Hard identity guard for tiers where time/identity relaxation is unsafe. */
object AnchorSafetyGuard {
    private val STRICT_TOKENS = setOf(
        "u16", "u17", "u18", "u19", "u20", "u21", "u23",
        "reserve", "reserves", "res", "ii", "iii", "bteam", "b-team",
        "women", "woman", "womens", "femeni", "feminine", "ladies"
    )

    fun isStrictAnchorRequired(home: String, away: String): Boolean =
        tokenize(home).any { it in STRICT_TOKENS } || tokenize(away).any { it in STRICT_TOKENS }

    private fun tokenize(value: String): Set<String> = value.lowercase()
        .replace("’", "'")
        .split(Regex("[^a-z0-9]+"))
        .filter { it.isNotBlank() }
        .toSet()
}
