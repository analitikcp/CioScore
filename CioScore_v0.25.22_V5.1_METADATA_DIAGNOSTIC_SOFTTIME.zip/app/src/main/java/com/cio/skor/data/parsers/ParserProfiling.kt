package com.cio.skor.data.parsers

data class ParserProfiling(
    val domBuildMs: Long = 0L,
    val selectorExtractMs: Long = 0L,
    val totalParserMs: Long = 0L,
    val selectorHits: Int = 0
)
