# CioScore v0.9.14 — Build Fix + Alias Regression Guard

- Restored MainActivity helper methods required by the scan pipeline.
- Fixed compact diagnostic report compile error caused by calling String.isNotBlank() on UnmatchedReason.
- Preserved compact diagnostic report: aggregate counts + problem examples only.
- Preserved explicit Broadmeadow/Adelaide City aliases and two-sided fixture gates.
- Matcher pipeline: v0.25.50-CLUB-ALIAS-REGRESSION-SCHEDULE-IDENTITY-V6.1.
- versionCode 298 / versionName 0.9.14.
