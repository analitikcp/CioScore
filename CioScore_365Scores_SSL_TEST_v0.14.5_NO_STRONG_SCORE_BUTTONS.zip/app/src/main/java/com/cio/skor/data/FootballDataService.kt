package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.File
import java.time.LocalDate
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow

/**
 * Football-Data.co.uk historical context.
 *
 * The service deliberately uses only matches dated before the target fixture.
 * It builds a lightweight Poisson-style team model from historical home/away
 * goals, points and (where available) shots/on-target data. No future result
 * is allowed to leak into the model.
 */
class FootballDataService(private val cacheDir: File? = null) {
    data class MatchContext(
        val homeTeam: String,
        val awayTeam: String,
        val homeMatches: Int,
        val awayMatches: Int,
        val homePpg: Double,
        val awayPpg: Double,
        val homeGoalsFor: Double,
        val homeGoalsAgainst: Double,
        val awayGoalsFor: Double,
        val awayGoalsAgainst: Double,
        val homeShotsOnTarget: Double?,
        val awayShotsOnTarget: Double?,
        val homeWinRate: Double,
        val awayWinRate: Double,
        val homeExpectedGoals: Double,
        val awayExpectedGoals: Double,
        val probabilities: Map<String, Double>,
        val confidence: Int,
        val league: String
    )

    data class AnalysisResult(
        val contexts: Map<String, MatchContext>,
        val datasetsLoaded: Int,
        val datasetsTotal: Int,
        val errorCount: Int
    )

    private data class Row(
        val date: LocalDate,
        val home: String,
        val away: String,
        val fthg: Int,
        val ftag: Int,
        val ftr: String,
        val hs: Double?,
        val as_: Double?,
        val hst: Double?,
        val ast: Double?,
        val league: String
    )

    private data class Dataset(val code: String, val league: String)

    private val http = HttpClient()
    private val memoryCache = HashMap<String, String>()

    // Main leagues where Football-Data provides long historical coverage.
    // Two seasons are enough for a first production pass and keep scan latency sane.
    private val datasets = listOf(
        Dataset("E0", "England Premier League"),
        Dataset("E1", "England Championship"),
        Dataset("D1", "Germany Bundesliga"),
        Dataset("D2", "Germany 2 Bundesliga"),
        Dataset("I1", "Italy Serie A"),
        Dataset("I2", "Italy Serie B"),
        Dataset("SP1", "Spain La Liga"),
        Dataset("SP2", "Spain La Liga 2"),
        Dataset("F1", "France Ligue 1"),
        Dataset("F2", "France Ligue 2"),
        Dataset("N1", "Netherlands Eredivisie"),
        Dataset("B1", "Belgium Jupiler"),
        Dataset("P1", "Portugal Liga"),
        Dataset("T1", "Turkey Super Lig"),
        Dataset("G1", "Greece Super League"),
        Dataset("SC0", "Scotland Premiership"),
        Dataset("SC1", "Scotland Championship"),
        Dataset("POL", "Poland Ekstraklasa"),
        Dataset("ROU", "Romania Liga 1"),
        Dataset("AUT", "Austria Bundesliga"),
        Dataset("SWE", "Sweden Allsvenskan"),
        Dataset("NOR", "Norway Eliteserien"),
        Dataset("FIN", "Finland Veikkausliiga")
    )

    suspend fun analyzeMatches(groups: List<SofaScoreService.MatchGroupData>): AnalysisResult = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope AnalysisResult(emptyMap(), 0, 0, 0)

        // Load current + previous season. Current season may have only a few matches,
        // while the previous season provides the stable baseline.
        val seasons = listOf("2627", "2526")
        val jobs = datasets.flatMap { ds -> seasons.map { season -> ds to season } }
        val loaded = jobs.chunked(6).flatMap { chunk ->
            chunk.map { (ds, season) ->
                async(Dispatchers.IO) {
                    val key = "${season}_${ds.code}"
                    val csv = loadCsv(key, season, ds.code)
                    Triple(ds, season, csv)
                }
            }.awaitAll()
        }

        val usable = loaded.filter { it.third != null }
        val rows = mutableListOf<Row>()
        usable.forEach { (ds, _, csv) ->
            rows += parseCsv(csv!!, ds.league)
        }

        val contexts = groups.associate { group ->
            val key = MatchMerger.key(group.homeTeam, group.awayTeam)
            key to buildContext(group.homeTeam, group.awayTeam, rows)
        }.filterValues { it != null }.mapValues { it.value!! }

        AnalysisResult(
            contexts = contexts,
            datasetsLoaded = usable.size,
            datasetsTotal = jobs.size,
            errorCount = jobs.size - usable.size
        )
    }

    private fun loadCsv(cacheKey: String, season: String, code: String): String? {
        memoryCache[cacheKey]?.let { return it }
        val file = cacheDir?.let { File(it, "fd_$cacheKey.csv") }
        if (file != null && file.exists() && System.currentTimeMillis() - file.lastModified() < 12L * 60L * 60L * 1000L) {
            return runCatching { file.readText(Charsets.UTF_8) }.getOrNull()?.also { memoryCache[cacheKey] = it }
        }

        val url = "https://www.football-data.co.uk/mmz4281/$season/$code.csv"
        val (httpCode, body) = http.getFast(url, "https://www.football-data.co.uk/")
        if (httpCode !in 200..299 || body.isNullOrBlank()) return null
        val normalized = body.removePrefix("\uFEFF")
        memoryCache[cacheKey] = normalized
        if (file != null) runCatching { file.writeText(normalized, Charsets.UTF_8) }
        return normalized
    }

    private fun parseCsv(csv: String, league: String): List<Row> {
        val lines = csv.replace("\r", "").split('\n')
        if (lines.isEmpty()) return emptyList()
        val header = splitCsv(lines.first()).map { normalizeHeader(it) }
        fun idx(vararg names: String): Int = names.firstNotNullOfOrNull { n -> header.indexOf(normalizeHeader(n)).takeIf { it >= 0 } } ?: -1
        val dateI = idx("Date")
        val homeI = idx("HomeTeam")
        val awayI = idx("AwayTeam")
        val fthgI = idx("FTHG")
        val ftagI = idx("FTAG")
        val ftrI = idx("FTR")
        val hsI = idx("HS")
        val asI = idx("AS")
        val hstI = idx("HST")
        val astI = idx("AST")
        if (dateI < 0 || homeI < 0 || awayI < 0 || fthgI < 0 || ftagI < 0 || ftrI < 0) return emptyList()

        val out = ArrayList<Row>()
        for (line in lines.drop(1)) {
            if (line.isBlank()) continue
            val p = splitCsv(line)
            if (p.size <= maxOf(dateI, homeI, awayI, fthgI, ftagI, ftrI)) continue
            val home = p[homeI].trim()
            val away = p[awayI].trim()
            val date = parseDate(p[dateI].trim()) ?: continue
            val fthg = p[fthgI].trim().toIntOrNull() ?: continue
            val ftag = p[ftagI].trim().toIntOrNull() ?: continue
            val ftr = p[ftrI].trim().uppercase().let { if (it == "H") "H" else if (it == "A") "A" else "D" }
            out += Row(
                date = date,
                home = home,
                away = away,
                fthg = fthg,
                ftag = ftag,
                ftr = ftr,
                hs = p.getOrNull(hsI)?.toDoubleOrNull(),
                as_ = p.getOrNull(asI)?.toDoubleOrNull(),
                hst = p.getOrNull(hstI)?.toDoubleOrNull(),
                ast = p.getOrNull(astI)?.toDoubleOrNull(),
                league = league
            )
        }
        return out
    }

    private fun buildContext(homeTeam: String, awayTeam: String, allRows: List<Row>): MatchContext? {
        val relevant = allRows.filter { it.date.isBefore(LocalDate.now().plusDays(1)) }

        // Football-Data team names often differ from prediction-site names
        // (e.g. "Man United" vs "Manchester United"). Use the same guarded
        // fuzzy matcher as fixture merging instead of exact normalized equality.
        val homeRows = relevant
            .filter { MatchMerger.isSameTeam(it.home, homeTeam) }
            .sortedByDescending { it.date }
            .take(14)
        val awayRows = relevant
            .filter { MatchMerger.isSameTeam(it.away, awayTeam) }
            .sortedByDescending { it.date }
            .take(14)
        if (homeRows.size < 4 || awayRows.size < 4) return null

        val homeLeague = homeRows.groupingBy { it.league }.eachCount().maxByOrNull { it.value }?.key ?: "Football-Data"
        val awayLeague = awayRows.groupingBy { it.league }.eachCount().maxByOrNull { it.value }?.key ?: homeLeague
        val homeLeagueRows = relevant.filter { it.league == homeLeague }
        val awayLeagueRows = relevant.filter { it.league == awayLeague }
        val homeLeagueGoals = homeLeagueRows.map { it.fthg.toDouble() }.averageOrNull() ?: 1.45
        val awayLeagueGoals = awayLeagueRows.map { it.ftag.toDouble() }.averageOrNull() ?: 1.15

        // Recent matches matter more, but older matches still stabilize the estimate.
        // 0.90^index gives roughly half weight after 6-7 matches.
        fun weightedAverage(rows: List<Row>, selector: (Row) -> Double): Double {
            var sum = 0.0
            var weightSum = 0.0
            rows.forEachIndexed { index, row ->
                val w = 0.90.pow(index.toDouble())
                sum += selector(row) * w
                weightSum += w
            }
            return if (weightSum > 0.0) sum / weightSum else 0.0
        }

        val hGFraw = weightedAverage(homeRows) { it.fthg.toDouble() }
        val hGAraw = weightedAverage(homeRows) { it.ftag.toDouble() }
        val aGFraw = weightedAverage(awayRows) { it.ftag.toDouble() }
        val aGAraw = weightedAverage(awayRows) { it.fthg.toDouble() }

        // Empirical-Bayes shrinkage: small samples are pulled toward league mean.
        // This prevents four unusual games from creating extreme probabilities.
        fun shrink(value: Double, mean: Double, n: Int, priorGames: Double = 6.0): Double {
            return (value * n + mean * priorGames) / (n + priorGames)
        }
        val hGF = shrink(hGFraw, homeLeagueGoals, homeRows.size)
        val hGA = shrink(hGAraw, awayLeagueGoals, homeRows.size)
        val aGF = shrink(aGFraw, awayLeagueGoals, awayRows.size)
        val aGA = shrink(aGAraw, homeLeagueGoals, awayRows.size)

        val homeAttack = (hGF / max(homeLeagueGoals, 0.25)).coerceIn(0.55, 1.85)
        val awayDefense = (aGA / max(homeLeagueGoals, 0.25)).coerceIn(0.55, 1.85)
        val awayAttack = (aGF / max(awayLeagueGoals, 0.25)).coerceIn(0.55, 1.85)
        val homeDefense = (hGA / max(awayLeagueGoals, 0.25)).coerceIn(0.55, 1.85)

        val lambdaHome = (homeLeagueGoals * homeAttack * awayDefense).coerceIn(0.25, 3.25)
        val lambdaAway = (awayLeagueGoals * awayAttack * homeDefense).coerceIn(0.20, 2.85)
        val probs = poisson1x2(lambdaHome, lambdaAway)

        val homePpg = pointsPerGame(homeRows, MatchMerger.normalizeTeamName(homeTeam))
        val awayPpg = pointsPerGame(awayRows, MatchMerger.normalizeTeamName(awayTeam))
        val homeWins = homeRows.count { it.ftr == "H" }.toDouble() / homeRows.size
        val awayWins = awayRows.count { it.ftr == "A" }.toDouble() / awayRows.size
        val hst = homeRows.mapNotNull { it.hst }.averageOrNull()
        val ast = awayRows.mapNotNull { it.ast }.averageOrNull()

        // Confidence reflects usable sample size and whether both teams are drawn
        // from the same competition family. Cross-league games stay a little lower.
        val sampleConfidence = 38 + minOf(homeRows.size, 14) * 2 + minOf(awayRows.size, 14) * 2
        val leaguePenalty = if (homeLeague == awayLeague) 0 else 8
        val confidence = (sampleConfidence - leaguePenalty).coerceIn(45, 90)
        return MatchContext(
            homeTeam = homeTeam,
            awayTeam = awayTeam,
            homeMatches = homeRows.size,
            awayMatches = awayRows.size,
            homePpg = homePpg,
            awayPpg = awayPpg,
            homeGoalsFor = hGF,
            homeGoalsAgainst = hGA,
            awayGoalsFor = aGF,
            awayGoalsAgainst = aGA,
            homeShotsOnTarget = hst,
            awayShotsOnTarget = ast,
            homeWinRate = homeWins,
            awayWinRate = awayWins,
            homeExpectedGoals = lambdaHome,
            awayExpectedGoals = lambdaAway,
            probabilities = probs,
            confidence = confidence,
            league = if (homeLeague == awayLeague) homeLeague else "$homeLeague / $awayLeague"
        )
    }

    private fun pointsPerGame(rows: List<Row>, teamNorm: String): Double {
        var points = 0
        rows.forEach { r ->
            val teamIsHome = MatchMerger.normalizeTeamName(r.home) == teamNorm
            val won = if (teamIsHome) r.ftr == "H" else r.ftr == "A"
            val draw = r.ftr == "D"
            points += when { won -> 3; draw -> 1; else -> 0 }
        }
        return points.toDouble() / rows.size.coerceAtLeast(1)
    }

    private fun poisson1x2(homeLambda: Double, awayLambda: Double): Map<String, Double> {
        var one = 0.0
        var draw = 0.0
        var two = 0.0
        for (h in 0..7) for (a in 0..7) {
            val p = poisson(h, homeLambda) * poisson(a, awayLambda)
            when { h > a -> one += p; h == a -> draw += p; else -> two += p }
        }
        val total = one + draw + two
        if (total <= 0.0) return mapOf("1" to 0.33, "X" to 0.34, "2" to 0.33)
        return mapOf("1" to one / total, "X" to draw / total, "2" to two / total)
    }

    private fun poisson(k: Int, lambda: Double): Double {
        var fact = 1.0
        for (i in 2..k) fact *= i
        return exp(-lambda) * Math.pow(lambda, k.toDouble()) / fact
    }

    private fun splitCsv(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        for (c in line) {
            when {
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out += sb.toString(); sb.setLength(0) }
                else -> sb.append(c)
            }
        }
        out += sb.toString()
        return out
    }

    private fun normalizeHeader(s: String): String = s.trim().removePrefix("\uFEFF").lowercase()

    private fun parseDate(raw: String): LocalDate? {
        val cleaned = raw.trim()
        val patterns = listOf("d/M/yy", "dd/MM/yy", "d/M/yyyy", "dd/MM/yyyy", "yyyy-MM-dd")
        for (p in patterns) runCatching {
            return java.time.format.DateTimeFormatter.ofPattern(p).parse(cleaned, LocalDate::from)
        }
        return null
    }

    private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()
}
