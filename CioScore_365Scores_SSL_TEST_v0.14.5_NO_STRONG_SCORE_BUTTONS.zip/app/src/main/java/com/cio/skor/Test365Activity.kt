package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.cio.skor.test.TestFetcher365

class Test365Activity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_365test)

        val btnRun = findViewById<Button>(R.id.btnRunTest)
        val tvHttp = findViewById<TextView>(R.id.tvHttpStatus)
        val tvJson = findViewById<TextView>(R.id.tvJsonStatus)
        val tvCount = findViewById<TextView>(R.id.tvMatchCount)
        val tvBody = findViewById<TextView>(R.id.tvBodyLength)
        val tvMatch = findViewById<TextView>(R.id.tvFirstMatch)

        btnRun.setOnClickListener {
            btnRun.isEnabled = false
            tvHttp.text = "HTTP: ..."
            tvJson.text = "JSON: Yükleniyor..."
            tvCount.text = "Maç sayısı: --"
            tvBody.text = "JSON boyutu: --"
            tvMatch.text = "İlk maç: --"

            TestFetcher365.runTest(object : TestFetcher365.TestCallback {
                override fun onSuccess(httpCode: Int, matchCount: Int, firstMatchText: String, bodyLength: Int) {
                    runOnUiThread {
                        btnRun.isEnabled = true
                        tvHttp.text = "HTTP: $httpCode"
                        tvJson.text = "JSON: OK"
                        tvCount.text = "Maç sayısı: $matchCount"
                        tvBody.text = "JSON boyutu: $bodyLength karakter"
                        tvMatch.text = "İlk maç:\n$firstMatchText"
                    }
                }

                override fun onError(errorMessage: String) {
                    runOnUiThread {
                        btnRun.isEnabled = true
                        tvHttp.text = "HTTP: FAIL"
                        tvJson.text = "HATA: $errorMessage"
                        tvCount.text = "Maç sayısı: 0"
                        tvBody.text = "JSON boyutu: --"
                        tvMatch.text = "İlk maç: --"
                    }
                }
            })
        }
    }
}
