package com.cio.skor.test

import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * 365Scores connectivity/JSON test.
 *
 * WARNING: the trust-all TLS client below is intentionally DEBUG/TEST ONLY.
 * Never use it for production data traffic because it disables certificate
 * and hostname verification.
 */
object TestFetcher365 {
    private const val TEST_URL =
        "https://webapi.365scores.com/web/games/current/?appTypeId=5&langId=29&timezoneName=Europe/Istanbul"

    private val client: OkHttpClient by lazy {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(
                    chain: Array<out X509Certificate>?,
                    authType: String?
                ) = Unit

                override fun checkServerTrusted(
                    chain: Array<out X509Certificate>?,
                    authType: String?
                ) = Unit

                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            })

            val trustManager = trustAllCerts[0] as X509TrustManager
            val sslContext = SSLContext.getInstance("TLS").apply {
                init(null, trustAllCerts, SecureRandom())
            }

            OkHttpClient.Builder()
                .sslSocketFactory(sslContext.socketFactory, trustManager)
                .hostnameVerifier { _, _ -> true }
                .followRedirects(true)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
        } catch (e: Exception) {
            OkHttpClient.Builder()
                .followRedirects(true)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
        }
    }

    interface TestCallback {
        fun onSuccess(httpCode: Int, matchCount: Int, firstMatchText: String, bodyLength: Int)
        fun onError(errorMessage: String)
    }

    fun runTest(callback: TestCallback) {
        val request = Request.Builder()
            .url(TEST_URL)
            .addHeader(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            )
            .addHeader("Referer", "https://www.365scores.com/")
            .addHeader("Accept", "application/json, text/plain, */*")
            .addHeader("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback.onError(
                    "CONNECTION ERROR: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    val statusCode = res.code
                    val body = res.body?.string()

                    if (!res.isSuccessful) {
                        callback.onError("HTTP $statusCode")
                        return
                    }

                    if (body.isNullOrEmpty()) {
                        callback.onError("HTTP $statusCode (EMPTY BODY)")
                        return
                    }

                    try {
                        val json = JSONObject(body)
                        val gamesArray = json.optJSONArray("games")
                            ?: run {
                                callback.onError("JSON PARSE ERROR: 'games' dizisi bulunamadı")
                                return
                            }

                        val count = gamesArray.length()
                        var firstMatchInfo = "Maç bulunamadı"

                        if (count > 0) {
                            val firstGame = gamesArray.optJSONObject(0)
                            if (firstGame != null) {
                                val homeTeam = firstGame.optJSONObject("homeCompetitor")
                                    ?.optString("name")
                                    .orEmpty()
                                    .ifBlank { "Ev" }
                                val awayTeam = firstGame.optJSONObject("awayCompetitor")
                                    ?.optString("name")
                                    .orEmpty()
                                    .ifBlank { "Dep" }
                                firstMatchInfo = "$homeTeam vs $awayTeam"
                            }
                        }

                        callback.onSuccess(statusCode, count, firstMatchInfo, body.length)
                    } catch (e: Exception) {
                        callback.onError(
                            "JSON PARSE ERROR: ${e.message ?: e.javaClass.simpleName}"
                        )
                    }
                }
            }
        })
    }
}
