package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * FootballPredictions.com (FP.com) Correct Score parser.
 *
 * The page exposes a table with the logical columns:
 * Match | Correct Score Tip | Odds | Probability.
 * We therefore read the score from a cell whose whole value is a score,
 * and read team names from the match cell/links instead of scanning all text.
 */
class FPComParser : BaseParser("FP.com") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val rows = doc.select("table tr")
        for (row in rows) {
            val score = extractScoreFromRow(row) ?: continue
            val teams = extractTeams(row) ?: continue

            val home = cleanTeam(teams.first)
            val away = cleanTeam(teams.second)

            if (!valid(home, away)) continue
            if (looksLikeNoise(home) || looksLikeNoise(away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        // Some layouts use cards rather than a table. Only use this fallback
        // when the table parser found nothing.
        if (out.isEmpty()) {
            parseCards(doc, out)
        }

        return out.values.toList()
    }

    private fun extractScoreFromRow(row: Element): String? {
        // Prefer a cell whose complete text is exactly the correct-score tip.
        for (cell in row.select("th, td")) {
            val text = clean(cell.text())
            val exact = Regex("^(?:[0-5])\\s*[-:]\\s*(?:[0-5])$").matchEntire(text)
            if (exact != null) {
                return text.replace(Regex("\\s*[-:]\\s*"), "-")
            }
        }

        // Fallback for markup such as <span class="correct-score">2-1</span>.
        val labelled = row.select(
            ".correct-score, .correct_score, .score-tip, .score, " +
                "[class*=correct-score], [class*=correct_score], [class*=score-tip]"
        )

        for (element in labelled) {
            val text = clean(element.text())
            val match = Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)").find(text)
            if (match != null) {
                return "${match.groupValues[1]}-${match.groupValues[2]}"
            }
        }

        return null
    }

    private fun extractTeams(row: Element): Pair<String, String>? {
        // FP.com places the two team names in the Match cell. Prefer links,
        // because the visible match cell also contains date/time and numbers.
        val matchCells = row.select("td, th").filter { cell ->
            val text = clean(cell.text())
            text.contains(Regex("(?i)\\b(?:202[0-9]|20[0-9]{2})[-/]\\d{1,2}[-/]\\d{1,2}")) ||
                text.contains(Regex("\\d{1,2}/\\d{1,2}/\\d{4}"))
        }

        val candidates = LinkedHashSet<String>()
        for (cell in matchCells) {
            for (a in cell.select("a")) {
                val name = clean(a.text())
                if (isTeamCandidate(name)) candidates.add(name)
            }
        }

        if (candidates.size >= 2) {
            val list = candidates.toList()
            return list[0] to list[1]
        }

        // Alternate card markup: explicit home/away selectors.
        val home = firstNonBlank(row,
            ".home-team", ".homeTeam", ".team-home", ".home", "[class*=home-team]"
        )
        val away = firstNonBlank(row,
            ".away-team", ".awayTeam", ".team-away", ".away", "[class*=away-team]"
        )
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) {
            return home to away
        }

        // Last fallback: a textual "Home v Away" representation.
        val text = clean(row.text())
        val separator = Regex("\\s+(?:v|vs|versus)\\s+", RegexOption.IGNORE_CASE)
        val match = separator.find(text)
        if (match != null) {
            val left = text.substring(0, match.range.first)
            val right = text.substring(match.range.last + 1)
            val rightClean = right
                .replace(Regex("\\d{1,2}/\\d{1,2}/\\d{4}.*$"), "")
                .trim()
            if (isTeamCandidate(left) && isTeamCandidate(rightClean)) {
                return left to rightClean
            }
        }

        return null
    }

    private fun parseCards(doc: Document, out: LinkedHashMap<String, ScoreModel>) {
        val cards = doc.select(
            "article, .prediction-card, .match-card, " +
                "[class*=correct-score], [class*=prediction-card]"
        )

        for (card in cards) {
            val scoreText = clean(card.text())
            val scoreMatch = Regex(
                "(?i)(?:correct\\s*score(?:\\s*tip)?|score\\s*tip)[^0-9]{0,40}([0-5])\\s*[-:]\\s*([0-5])"
            ).find(scoreText) ?: continue

            val home = firstNonBlank(card,
                ".home-team", ".homeTeam", ".team-home", ".home", "[class*=home-team]"
            ) ?: continue
            val away = firstNonBlank(card,
                ".away-team", ".awayTeam", ".team-away", ".away", "[class*=away-team]"
            ) ?: continue

            val h = cleanTeam(home)
            val a = cleanTeam(away)
            if (!valid(h, a)) continue

            val model = ScoreModel(
                homeTeam = h,
                awayTeam = a,
                predictedScore = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}",
                source = source
            )
            out[model.matchKey] = model
            if (out.size >= 50) return
        }
    }

    private fun firstNonBlank(row: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = row.select(selector).firstOrNull()?.text()?.let(::clean)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun cleanTeam(value: String): String {
        return clean(value)
            .replace(Regex("\\b(?:correct\\s*score|odds|probability|prediction|tip)\\b.*$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\d{1,2}/\\d{1,2}/\\d{4}.*$"), "")
            .trim(' ', '-', '–', '—', ':', '|')
    }

    private fun isTeamCandidate(value: String): Boolean {
        val v = clean(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("\\d+"))) return false
        if (v.contains(Regex("(?i)correct score|probability|odds|prediction|read more|betting tips"))) return false
        if (v.matches(Regex("\\d{1,2}/\\d{1,2}/\\d{4}.*"))) return false
        return true
    }

    private fun looksLikeNoise(value: String): Boolean {
        return value.contains(Regex("(?i)correct score|probability|odds|read more|betting tips|prediction")) ||
            value.matches(Regex(".*\\d{1,2}/\\d{1,2}/\\d{4}.*"))
    }
}
