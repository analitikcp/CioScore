# CIO Score 0.8.13.1 - 5 Kaynak - Conservative Match Merge

Bu sürüm 0.8.12 çalışan temel sürümünü korur. Aynı maçları birleştirmede ev/deplasman taraflarını ayrı ve muhafazakâr eşiklerle karşılaştırır; belirsiz eşleşmeleri birleştirmek yerine ayrı bırakır.

Aktif kaynaklar: FP.com, PredictZ, WinDrawWin, SoccerSeer ve DailySports.

SofaScore yalnızca yardımcı katmandır: son 5 maç ve 1X2 oran zenginleştirmesi için kullanılır; CIO kaynak sayısına dahil değildir.
