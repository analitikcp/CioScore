package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * FootyStats Correct Score parser.
 * Supports the English page and the live Turkish /tr/predictions/correct-score page.
 * Only the full-time primary score is accepted; 1H and secondary picks are ignored.
 */
class FootyStatsParser : BaseParser("FootyStats") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val fullTimeHeading = doc.select("h1, h2, h3, h4, h5").firstOrNull { heading ->
            val text = cleanText(heading.text())
            text.contains("Correct Score Predictions For Today", ignoreCase = true) ||
                text.contains("Günün Maç Skoru Tahminleri", ignoreCase = true)
        } ?: return emptyList()

        val firstHalfHeading = doc.select("h1, h2, h3, h4, h5").firstOrNull { heading ->
            val text = cleanText(heading.text())
            text.contains("Correct Score 1st Half Predictions", ignoreCase = true) ||
                text.contains("İlk Yarı için Skor Tahminleri", ignoreCase = true)
        }

        val candidates = collectBetween(fullTimeHeading, firstHalfHeading)
            .filter { element ->
                val text = cleanText(element.text())
                (text.contains("Predicted Scoreline", ignoreCase = true) ||
                    text.contains("Skor Tahmini", ignoreCase = true)) &&
                    !text.contains("Predicted 1H Scoreline", ignoreCase = true) &&
                    !text.contains("Alternatif İlk Yarı Skor Tahmini", ignoreCase = true)
            }

        for (scoreElement in candidates) {
            val score = extractFullTimeScore(scoreElement) ?: continue
            val fixture = findFixture(scoreElement) ?: continue

            val home = cleanTeam(fixture.first)
            val away = cleanTeam(fixture.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        return out.values.toList()
    }

    private fun collectBetween(start: Element, end: Element?): List<Element> {
        val root = start.ownerDocument() ?: return emptyList()
        val all = root.select("body *")
        val startIndex = all.indexOf(start)
        if (startIndex < 0) return emptyList()

        val endIndex = if (end != null) {
            val idx = all.indexOf(end)
            if (idx > startIndex) idx else all.size
        } else {
            all.size
        }

        return all.subList(startIndex + 1, endIndex)
    }

    private fun extractFullTimeScore(element: Element): String? {
        val text = cleanText(element.text())
        if (Regex("(?i)Predicted\\s+1H\\s+Scoreline").containsMatchIn(text) ||
            text.contains("İlk Yarı", ignoreCase = true)) return null

        val match = Regex(
            "(?i)(?:Predicted\\s+Scoreline|Skor\\s+Tahmini)\\s*:\\s*([0-5])\\s*[:\\-]\\s*([0-5])\\b"
        ).find(text) ?: return null

        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun findFixture(element: Element): Pair<String, String>? {
        var current: Element? = element
        repeat(8) {
            val parent = current ?: return null
            val link = parent.select("a[href]")
                .firstOrNull { anchor ->
                    val text = cleanText(anchor.text())
                    Regex("(?i)\\s+vs\\s+").containsMatchIn(text) ||
                        Regex("\\s+[–—-]\\s+").containsMatchIn(text)
                }

            if (link != null) return splitFixture(link.text())
            current = parent.parent()
        }
        return null
    }

    private fun splitFixture(raw: String): Pair<String, String>? {
        val text = cleanText(raw)
            .replace(Regex("(?i)\\s*Predictions?\\s*[›>].*$"), "")
            .replace(Regex("(?i)\\s*Tahminler\\s*[›>].*$"), "")
            .trim()

        val match = Regex("(?i)^(.+?)\\s+vs\\s+(.+)$").find(text)
            ?: Regex("^(.+?)\\s+[–—-]\\s+(.+)$").find(text)
            ?: return null

        val home = match.groupValues[1].trim()
        val away = match.groupValues[2].trim()
        if (home.isBlank() || away.isBlank()) return null
        return home to away
    }

    private fun cleanTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')

    private fun cleanText(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
