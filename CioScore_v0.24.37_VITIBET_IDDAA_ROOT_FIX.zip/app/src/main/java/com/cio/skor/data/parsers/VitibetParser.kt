package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Vitibet/Vitisport parser. Uses stable textual markers first, DOM selectors second. */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Current quicktips pages expose rows as plain text:
        // 13:30 Tottenham 1 : 0 Aston Villa INDEX +0.98 ... Tip 1-0 1X
        // Parse these rows from the complete document text so CSS-class changes
        // cannot make the source silently return zero scores.
        val body = clean(doc.body()?.text().orEmpty())
        // Vitibet's plain-text layout is not "time home score Tip away".
        // The actual row is closer to: "time home H : A away [result/index...]
        // time ...". The previous regex consumed the Tip text as the away team,
        // producing unusable team identities and causing all 243 Vitibet rows to
        // miss the official Iddaa fixture gate. Parse each time-delimited row and
        // take the first H:A as the predicted score; the text between that score
        // and the next row is the away side plus provider metadata.
        val rowRegex = Regex(
            "(?is)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(\\d{1,2})\\s*:\\s*(\\d{1,2})\\s+(.+?)(?=\\s+\\d{1,2}:\\d{2}\\s+|$)"
        )
        for (m in rowRegex.findAll(body)) {
            val home = cleanTeam(m.groupValues[2])
            val score = "${m.groupValues[3].toIntOrNull() ?: continue}-${m.groupValues[4].toIntOrNull() ?: continue}"
            var awayRaw = m.groupValues[5]
            // Strip provider metadata that follows the away team. Current pages
            // commonly append a single 0/1/2 result marker before the next row.
            awayRaw = awayRaw
                .replace(Regex("\\s+INDEX\\b.*$", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+(?:Tip|Ipucu|Vihje|Dica)\\b.*$", RegexOption.IGNORE_CASE), "")
                .replace(Regex("\\s+[012]\\s*$"), "")
                .trim()
            val away = cleanTeam(awayRaw)
            build(home, away, score, m.groupValues[1])?.let { out[it.matchKey] = it }
        }

        // Fallback for DOM variants where the predicted score is only exposed
        // as Tip/Ipucu and not as an inline H : A value.
        if (out.isEmpty()) {
            for (node in doc.select("tr, article, li, div, p")) {
                parseTipContainer(node)?.let { out[it.matchKey] = it }
                if (out.size >= 250) break
            }
        }

        // Last fallback: match-detail anchors often contain exactly one fixture.
        if (out.isEmpty()) {
            for (link in doc.select("a[href]")) {
                val text = clean(link.text())
                val tip = extractTipScore(text) ?: continue
                val fixture = splitVsFixture(text) ?: continue
                val kickoff = Regex("(?<!\\d)(\\d{1,2}:\\d{2})(?!\\d)").find(text)?.groupValues?.getOrNull(1)
                build(fixture.first, fixture.second, tip, kickoff)?.let { out[it.matchKey] = it }
            }
        }

        return out.values.toList()
    }

    private fun parseTipContainer(element: Element): ScoreModel? {
        val text = clean(element.text())
        val predicted = extractTipScore(text) ?: return null

        // Prefer explicit team anchors; Vitibet uses logo/team links around each row.
        val teams = element.select("a[href]")
            .map { cleanTeam(it.text()) }
            .filter { isTeamCandidate(it) }
            .distinct()
        if (teams.size >= 2) {
            val kickoff = Regex("(?<!\\d)(\\d{1,2}:\\d{2})(?!\\d)").find(text)?.groupValues?.getOrNull(1)
            return build(teams[0], teams[1], predicted, kickoff)
        }

        // Legacy row: time + home + Tip + away.
        val tipMatch = Regex("(?i)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(?:Tip|Ipucu|Vihje|Dica)\\s+\\d{1,2}\\s*[-:]\\s*\\d{1,2}\\s+(.+?)(?=\\s+INDEX\\b|$)").find(text)
        if (tipMatch != null) {
            return build(cleanTeam(tipMatch.groupValues[2]), cleanTeam(tipMatch.groupValues[3]), predicted, tipMatch.groupValues[1])
        }
        return null
    }

    private fun extractTipScore(text: String): String? = Regex(
        "(?i)\\b(?:Tip|Ipucu|Vihje|Dica)\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun splitVsFixture(raw: String): Pair<String, String>? {
        val m = Regex("(?i)^(.+?)\\s+vs\\s+(.+?)$").find(clean(raw)) ?: return null
        return cleanTeam(m.groupValues[1]) to cleanTeam(m.groupValues[2])
    }

    private fun build(homeRaw: String, awayRaw: String, score: String, kickoff: String? = null): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        val parsedTime = kickoff?.let {
            runCatching { LocalTime.parse(it, DateTimeFormatter.ofPattern("H:mm")) }.getOrNull()
        }
        val zone = ZoneId.of("Europe/Istanbul")
        val today = LocalDate.now(zone)
        val timestamp = parsedTime?.atDate(today)?.atZone(zone)?.toInstant()?.toEpochMilli() ?: 0L
        val date = if (parsedTime != null) today.toString() else ""
        val time = parsedTime?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "--:--"
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            matchTimestamp = timestamp,
            matchDate = date,
            matchTime = time
        )
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..70) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|LIVE|FT|Odds|Status)\\b.*$"), "")
        .trim(' ', '-', ':', '|')
}
