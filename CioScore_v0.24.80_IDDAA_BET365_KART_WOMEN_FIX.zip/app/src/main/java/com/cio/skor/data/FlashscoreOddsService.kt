package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Flashscore fallback for bookmaker 1X2 odds.
 *
 * Important: football 1X2 is HOME_DRAW_AWAY on the current Flashscore odds
 * feed (HOME_AWAY is used for two-way sports such as basketball/tennis).
 */
class FlashscoreOddsService {
    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    private val http = HttpClient()

    // Flashscore has changed the locale portion of this feed over time. Try
    // the current en-gb form first, then the shorter en form.
    private val feedUrls = listOf(
        "https://www.flashscore.com/x/feed/f_1_-1_3_en-gb_1",
        "https://www.flashscore.com/x/feed/f_1_-1_3_en_1"
    )

    // Both hosts are used by current/public Flashscore integrations. The
    // projectId=2 + _hash=oce combination is the normal football odds query;
    // ope is retained as a compatibility fallback.
    private val oddsHosts = listOf(
        "https://global.ds.lsapp.eu/odds/pq_graphql",
        "https://2.ds.lsapp.eu/pq_graphql"
    )

    suspend fun fetchBookmakerOdds(homeTeam: String, awayTeam: String): List<BookmakerOdds> =
        withContext(Dispatchers.IO) {
            val eventId = findEventId(homeTeam, awayTeam)
            if (eventId == null) {
                Log.d(TAG, "No Flashscore event: $homeTeam - $awayTeam")
                return@withContext emptyList()
            }

            // PHASE 1: only Bet365.  Do not dilute the first test with other
            // bookmakers.  Flashscore exposes Bet365 in the UK catalogue and
            // bet365.de in Germany; US can expose bet365.us depending on IP.
            val regions = listOf("GB", "DE", "US")
            val rows = coroutineScope {
                regions.map { geo ->
                    async(Dispatchers.IO) { fetchEventOdds(eventId, geo) }
                }.awaitAll().flatten()
            }

            val bet365Rows = rows
                .filter { it.ms1.isNotBlank() && it.msX.isNotBlank() && it.ms2.isNotBlank() }
                .filter { normalizeBookmaker(it.bookmaker).startsWith("bet365") }
                .groupBy { normalizeBookmaker(it.bookmaker) }
                .values
                .mapNotNull { it.firstOrNull() }

            // Prefer the plain "bet365" row over regional labels such as
            // "bet365.de" / "bet365 USA" when more than one catalogue is
            // returned.  We still accept a regional Bet365 row as fallback.
            val result = bet365Rows.sortedWith(compareBy<BookmakerOdds> {
                when (normalizeBookmaker(it.bookmaker)) {
                    "bet365" -> 0
                    "bet365de" -> 1
                    "bet365usa" -> 2
                    else -> 3
                }
            }).take(1)

            Log.d(TAG, "Flashscore BET365 $homeTeam - $awayTeam event=$eventId rows=${result.size} " +
                result.joinToString { "${it.bookmaker}=${it.ms1}/${it.msX}/${it.ms2}" })
            result
        }

    private fun findEventId(homeTeam: String, awayTeam: String): String? {
        val homeNorm = normalize(homeTeam)
        val awayNorm = normalize(awayTeam)

        for (url in feedUrls) {
            val (code, body) = http.get(url, "https://www.flashscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue

            for (section in body.split('~')) {
                val fields = parseFields(section)
                val id = fields["AA"] ?: continue
                val home = fields["AE"].orEmpty()
                val away = fields["AF"].orEmpty()
                if (isSameTeam(home, homeNorm) && isSameTeam(away, awayNorm)) {
                    return id
                }
            }
        }
        return null
    }

    private fun fetchEventOdds(eventId: String, geo: String): List<BookmakerOdds> {
        val hashes = listOf("oce", "ope")
        for (host in oddsHosts) {
            for (hash in hashes) {
                val q = buildString {
                    append(host)
                    append("?_hash=").append(hash)
                    append("&eventId=").append(URLEncoder.encode(eventId, StandardCharsets.UTF_8.name()))
                    append("&projectId=2")
                    append("&geoIpCode=").append(geo)
                }

                val (code, body) = http.get(q, "https://www.flashscore.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue

                val parsed = parseOddsResponse(body)
                if (parsed.isNotEmpty()) return parsed
            }
        }
        return emptyList()
    }

    private fun parseOddsResponse(body: String): List<BookmakerOdds> = runCatching {
        val root = JSONObject(body)
        val eventOdds = root.optJSONObject("data")?.optJSONObject("findOddsByEventId")
            ?: return@runCatching emptyList()

        // The current Flashscore response puts bookmaker metadata under
        // settings.bookmakers.  Build the ID -> name map from that exact
        // structure instead of recursively guessing through the JSON tree.
        val bookmakerNames = HashMap<String, String>()
        val settings = eventOdds.optJSONObject("settings")
        val bookmakers = settings?.optJSONArray("bookmakers")
        if (bookmakers != null) {
            for (i in 0 until bookmakers.length()) {
                val entry = bookmakers.optJSONObject(i) ?: continue
                val bk = entry.optJSONObject("bookmaker") ?: continue
                val id = bk.opt("id")?.toString().orEmpty()
                val name = bk.optString("name").trim()
                if (id.isNotBlank() && name.isNotBlank()) bookmakerNames[id] = name
            }
        }

        val oddsArray = eventOdds.optJSONArray("odds") ?: return@runCatching emptyList()
        val out = mutableListOf<BookmakerOdds>()

        for (i in 0 until oddsArray.length()) {
            val item = oddsArray.optJSONObject(i) ?: continue

            // FOOTBALL 1X2: HOME_DRAW_AWAY. Older code incorrectly required
            // HOME_AWAY, which caused every foreign row to be discarded.
            val bettingType = item.optString("bettingType").uppercase()
            if (bettingType.isNotBlank() &&
                bettingType != "HOME_DRAW_AWAY" && bettingType != "HOME_AWAY") continue

            val scope = item.optString("bettingScope").uppercase()
            if (scope.isNotBlank() && scope != "FULL_TIME") continue

            val oddsType = item.optString("oddsType").uppercase()
            if (oddsType.isNotBlank() && oddsType != "PREMATCH") continue

            val values = item.optJSONArray("odds") ?: continue
            val parsed = parseThreeWay(values) ?: continue

            val bookmakerId = item.opt("bookmakerId")?.toString().orEmpty()
            var name = bookmakerNames[bookmakerId].orEmpty()
            if (name.isBlank()) {
                name = item.optJSONObject("bookmaker")?.optString("name").orEmpty().trim()
            }
            if (name.isBlank()) continue

            // PHASE 1 is deliberately Bet365-only.
            if (!normalizeBookmaker(name).startsWith("bet365")) continue
            out += BookmakerOdds(name, parsed.first, parsed.second, parsed.third)
        }
        out
    }.getOrElse {
        Log.d(TAG, "Flashscore odds parse failed: ${it.message}")
        emptyList()
    }

    private fun parseThreeWay(values: JSONArray): Triple<String, String, String>? {
        if (values.length() < 3) return null

        // Current feed normally comes in HOME, DRAW, AWAY order. If selection
        // labels are present, use them explicitly so ordering cannot drift.
        var home: String? = null
        var draw: String? = null
        var away: String? = null

        for (i in 0 until values.length()) {
            val obj = values.optJSONObject(i) ?: continue
            val value = decimal(obj) ?: continue
            when (obj.optString("selection").uppercase()) {
                "HOME", "1" -> home = value
                "DRAW", "X" -> draw = value
                "AWAY", "2" -> away = value
            }
        }

        if (home != null && draw != null && away != null) {
            return Triple(home!!, draw!!, away!!)
        }

        val one = decimal(values.optJSONObject(0)) ?: return null
        val two = decimal(values.optJSONObject(1)) ?: return null
        val three = decimal(values.optJSONObject(2)) ?: return null
        return Triple(one, two, three)
    }

    private fun decimal(obj: JSONObject?): String? {
        if (obj == null) return null
        val raw = obj.opt("value") ?: obj.opt("odds") ?: obj.opt("decimal") ?: return null
        val value = raw.toString().toDoubleOrNull() ?: return null
        if (value <= 1.0 || value > 100.0) return null
        return String.format(java.util.Locale.US, "%.2f", value)
    }

    private fun collectBookmakers(value: JSONObject, out: MutableMap<String, String>) {
        val keys = value.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val child = value.opt(key)
            when (child) {
                is JSONObject -> {
                    if (key.equals("bookmaker", true)) {
                        val id = child.opt("id")?.toString().orEmpty()
                        val name = child.optString("name").trim()
                        if (id.isNotBlank() && name.isNotBlank()) out[id] = name
                    }
                    collectBookmakers(child, out)
                }
                is JSONArray -> {
                    for (i in 0 until child.length()) {
                        child.optJSONObject(i)?.let { collectBookmakers(it, out) }
                    }
                }
            }
        }
    }

    private fun parseFields(section: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (part in section.split('¬')) {
            val pos = part.indexOf('÷')
            if (pos <= 0) continue
            out[part.substring(0, pos)] = part.substring(pos + 1)
        }
        return out
    }

    /**
     * Flashscore labels women's teams as "Barcelona W" / "Paris FC W", while
     * the official CioScore/İddaa side can expose the same fixtures as
     * "Barcelona (K)" / "Paris FC (K)".  Gender markers are provider metadata
     * for this Flashscore lookup; removing them here keeps the identity gate
     * strict without changing the global canonicalizer.
     */
    private fun normalize(value: String): String {
        val base = MatchMerger.normalizeTeamName(value)
        return base
            .split(' ')
            .filterNot { it in setOf("k", "w", "women", "woman", "female", "fem", "ladies") }
            .joinToString("")
    }

    private fun isSameTeam(actual: String, normalizedWanted: String): Boolean {
        if (MatchMerger.isSameTeam(actual, normalizedWanted)) return true
        val a = normalize(actual)
        val wanted = normalize(normalizedWanted)
        if (a == wanted) return true
        if (a.isBlank() || wanted.isBlank()) return false
        return a.contains(wanted) || wanted.contains(a)
    }

    private fun normalizeBookmaker(name: String): String = name.lowercase()
        .replace("★", "")
        .replace(Regex("[^a-z0-9]"), "")
        .replace("usa", "")

    companion object {
        private const val TAG = "CioScoreOdds"
    }
}
