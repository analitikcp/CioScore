# CioScore v0.22.0 — Popular Bets Engine v2

## Changes
- Four operator parsers now expose source-specific URL fallback lists.
- Parser reads explicit popularity attributes plus HTML card/table fallbacks.
- Numeric percentage is normalized into `PopularBetModel.percentage`.
- Source health is surfaced in the UI: HTTP/result count per source.
- Same fixture + same selection consensus is calculated per merged match.
- Consensus shows source count and average percentage when numeric percentages are available.
- Existing fixture matching remains unchanged.

## Important limitation
The app does not bypass authentication, anti-bot controls, or private/undocumented APIs. If an operator renders popularity data only after JavaScript execution, the Android HTTP parser may still receive no records. The UI now makes that failure visible instead of silently presenting an empty list.
