package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.PopularBetCluster
import com.cio.skor.data.PopularBetRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PopularBetsActivity : Activity() {
    private val COLOR_TEXT: Int = android.graphics.Color.rgb(16, 24, 40)
    private val COLOR_MUTED: Int = android.graphics.Color.rgb(102, 112, 133)
    private val COLOR_SECONDARY: Int = android.graphics.Color.rgb(52, 64, 84)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = PopularBetRepository()
    private lateinit var recycler: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(12))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        val title = TextView(this).apply {
            text = "🔥 TÜRKİYE'DE EN ÇOK OYNANANLAR"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        progress = ProgressBar(this)
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(COLOR_MUTED)
            setPadding(0, dp(4), 0, dp(8))
        }
        empty = TextView(this).apply {
            text = "Veri bulunamadı. Kaynaklar dinamik olabilir; tekrar deneyebilirsin."
            textSize = 14f
            setTextColor(COLOR_MUTED)
            gravity = Gravity.CENTER
            visibility = TextView.GONE
        }
        recycler = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@PopularBetsActivity) }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(empty, LinearLayout.LayoutParams(-1, dp(70)))
        root.addView(recycler, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        progress.visibility = ProgressBar.VISIBLE
        empty.visibility = TextView.GONE
        scope.launch {
            val result = withContext(Dispatchers.IO) { repository.fetchAllWithStatus() }
            val clusters = repository.cluster(result.first)
            val sourceText = result.second.joinToString("   •   ") { "${it.sourceName}: ${it.recordCount}${if (it.httpOk) " ✓" else " ✕"}" }
            status.text = sourceText
            progress.visibility = ProgressBar.GONE
            if (clusters.isEmpty()) empty.visibility = TextView.VISIBLE
            recycler.adapter = PopularAdapter(clusters)
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private inner class PopularAdapter(private val items: List<PopularBetCluster>) : RecyclerView.Adapter<PopularAdapter.VH>() {
        inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply { setColor(android.graphics.Color.WHITE); cornerRadius = dp(14).toFloat(); setStroke(dp(1), android.graphics.Color.rgb(231, 234, 240)) }
                elevation = dp(2).toFloat()
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(5), dp(4), dp(5)) }
            }
            return VH(card)
        }
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.card.removeAllViews()
            holder.card.addView(text("${item.homeTeam}  —  VS  —  ${item.awayTeam}", 16f, true, COLOR_TEXT))
            val consensus = item.consensusByPrediction().firstOrNull()
            val consensusText = consensus?.let { " • ${it.sourceCount}/4 aynı seçim" + (it.averagePercentage?.let { p -> " • ort. %.1f%%".format(p) } ?: "") } ?: ""
            val summary = "${item.sourceCount}/4 kaynak • ${item.bets.size} popüler tercih$consensusText"
            holder.card.addView(text(summary, 12f, false, COLOR_MUTED))
            item.bets.forEach { bet ->
                val line = "${bet.sourceName}: ${bet.prediction.ifBlank { "Popüler tercih" }}" +
                    (if (bet.ratioOrCount.isNotBlank()) "  ${bet.ratioOrCount}" else "") +
                    (if (bet.odds.isNotBlank()) "  oran ${bet.odds}" else "")
                holder.card.addView(text(line, 13f, false, COLOR_SECONDARY))
            }
        }
        private fun text(value: String, size: Float, bold: Boolean, color: Int): TextView = TextView(this@PopularBetsActivity).apply {
            text = value; textSize = size; setTextColor(color); setTypeface(typeface, if (bold) Typeface.BOLD else Typeface.NORMAL)
            setPadding(0, dp(3), 0, dp(3))
        }
    }
}
