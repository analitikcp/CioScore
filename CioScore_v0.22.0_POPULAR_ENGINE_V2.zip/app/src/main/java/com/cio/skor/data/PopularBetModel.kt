package com.cio.skor.data

/** Raw popular-bet record from one Turkish operator. */
data class PopularBetModel(
    val sourceName: String,
    val rawHomeTeam: String,
    val rawAwayTeam: String,
    val matchCode: String = "",
    val prediction: String,
    val ratioOrCount: String = "",
    val odds: String = "",
    val matchTimestamp: Long = 0L,
    val matchDate: String = "",
    val matchTime: String = "--:--",
    /** Numeric popularity percentage when the source exposes one. */
    val percentage: Double? = null
)

data class PopularSourceStatus(
    val sourceName: String,
    val url: String,
    val httpOk: Boolean,
    val recordCount: Int,
    val error: String = ""
)

data class PopularBetCluster(
    val fixtureKey: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchCode: String,
    val bets: List<PopularBetModel>
) {
    val sourceCount: Int get() = bets.map { it.sourceName }.distinct().size

    /** Same market/selection consensus across operators. */
    fun consensusByPrediction(): List<PopularConsensus> =
        bets.groupBy { it.prediction.trim().uppercase() }
            .filterKeys { it.isNotBlank() }
            .map { (prediction, rows) ->
                val percentages = rows.mapNotNull { it.percentage }
                PopularConsensus(
                    prediction = prediction,
                    sourceCount = rows.map { it.sourceName }.distinct().size,
                    averagePercentage = percentages.takeIf { it.isNotEmpty() }?.average(),
                    maxPercentage = percentages.maxOrNull()
                )
            }
            .sortedWith(compareByDescending<PopularConsensus> { it.sourceCount }
                .thenByDescending { it.averagePercentage ?: -1.0 })
}

data class PopularConsensus(
    val prediction: String,
    val sourceCount: Int,
    val averagePercentage: Double?,
    val maxPercentage: Double?
)
