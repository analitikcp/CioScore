package com.cio.skor.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class PopularBetRepository(
    private val parsers: List<PopularBetParser> = listOf(
        IddaaPopularParser(), NesinePopularParser(), MisliPopularParser(), BilyonerPopularParser()
    )
) {
    suspend fun fetchAllWithStatus(): Pair<List<PopularBetModel>, List<PopularSourceStatus>> = coroutineScope {
        val results = parsers.map { parser -> async { runCatching { parser.fetchWithStatus() }.getOrElse { emptyList<PopularBetModel>() to PopularSourceStatus(parser.sourceName, parser.pageUrls.firstOrNull().orEmpty(), false, 0, it.message ?: "Bilinmeyen hata") } } }.awaitAll()
        results.flatMap { it.first } to results.map { it.second }
    }

    suspend fun fetchAll(): List<PopularBetModel> = fetchAllWithStatus().first
    fun cluster(raw: List<PopularBetModel>): List<PopularBetCluster> = PopularBetMerger.merge(raw)
}
