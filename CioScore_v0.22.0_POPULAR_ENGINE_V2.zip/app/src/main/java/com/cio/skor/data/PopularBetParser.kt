package com.cio.skor.data

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

interface PopularBetParser {
    val sourceName: String
    val pageUrls: List<String>
    fun fetchWithStatus(): Pair<List<PopularBetModel>, PopularSourceStatus> {
        var lastError = ""
        for (url in pageUrls) {
            val response = PopularBetHttpClient.get(url)
            if (response != null) {
                val parsed = parseHtml(response, url)
                if (parsed.isNotEmpty()) return parsed to PopularSourceStatus(sourceName, url, true, parsed.size)
                lastError = "HTTP OK, ancak popüler bahis kaydı bulunamadı"
            } else lastError = "HTTP erişimi başarısız"
        }
        return emptyList<PopularBetModel>() to PopularSourceStatus(sourceName, pageUrls.firstOrNull().orEmpty(), false, 0, lastError)
    }

    fun fetch(): List<PopularBetModel> = fetchWithStatus().first

    fun parseHtml(body: String, baseUrl: String = pageUrls.firstOrNull().orEmpty()): List<PopularBetModel> {
        val doc = Jsoup.parse(body, baseUrl)
        val result = mutableListOf<PopularBetModel>()
        val candidates = doc.select(
            "[data-home-team][data-away-team], [data-hometeam][data-awayteam], [data-home][data-away], " +
            "[data-team-home][data-team-away], [data-home-name][data-away-name]"
        )
        for (el in candidates) addCandidate(result, el)

        // Second pass: tables/cards whose text contains a recognisable market and percentage.
        if (result.isEmpty()) {
            val blocks = doc.select("tr, li, article, [class*=match], [class*=event], [class*=popular], [class*=bet]")
            for (el in blocks.take(5000)) {
                val text = el.text().replace(Regex("\\s+"), " ").trim()
                val ratio = guessPercentage(text) ?: guessRatio(text)
                if (ratio.isBlank()) continue
                val teams = guessTeams(text) ?: continue
                val market = guessMarket(text)
                if (market.isBlank()) continue
                result += PopularBetModel(
                    sourceName = sourceName,
                    rawHomeTeam = teams.first,
                    rawAwayTeam = teams.second,
                    matchCode = attrAny(el, "data-match-code", "data-code", "data-event-code", "data-id"),
                    prediction = market,
                    ratioOrCount = ratio,
                    odds = guessOdds(text),
                    percentage = parsePercentage(ratio)
                )
            }
        }
        return result.distinctBy { "${it.rawHomeTeam}|${it.rawAwayTeam}|${it.prediction}|${it.sourceName}" }
    }

    private fun addCandidate(result: MutableList<PopularBetModel>, el: Element) {
        val home = attrAny(el, "data-home-team", "data-hometeam", "data-home", "data-team-home", "data-home-name")
        val away = attrAny(el, "data-away-team", "data-awayteam", "data-away", "data-team-away", "data-away-name")
        if (home.isBlank() || away.isBlank()) return
        val text = el.text().replace(Regex("\\s+"), " ").trim()
        val ratio = attrAny(el, "data-percentage", "data-ratio", "data-count", "data-percent", "data-popularity").ifBlank { guessPercentage(text) ?: guessRatio(text) }
        val market = attrAny(el, "data-market", "data-bet", "data-prediction", "data-selection").ifBlank { guessMarket(text) }
        if (market.isBlank()) return
        result += PopularBetModel(
            sourceName = sourceName,
            rawHomeTeam = home,
            rawAwayTeam = away,
            matchCode = attrAny(el, "data-match-code", "data-code", "data-event-code", "data-id"),
            prediction = market,
            ratioOrCount = ratio,
            odds = attrAny(el, "data-odds", "data-odd", "data-rate").ifBlank { guessOdds(text) },
            percentage = parsePercentage(ratio)
        )
    }

    fun attrAny(el: Element, vararg names: String): String = names.asSequence().map { el.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: ""

    fun guessMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        val patterns = listOf("MS 1", "MS X", "MS 2", "MAÇ SONUCU", "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KG VAR", "KG YOK", "İLK YARI 1", "İLK YARI X", "İLK YARI 2")
        return patterns.firstOrNull { upper.contains(it) } ?: ""
    }

    fun guessPercentage(text: String): String? = Regex("(?<!\\d)%\\s?\\d{1,3}(?:[.,]\\d+)?").find(text)?.value?.trim()

    fun guessRatio(text: String): String = Regex("(?:\\d[\\d.]*\\s*(?:Kişi|oynama|kupon|tercih))", RegexOption.IGNORE_CASE).find(text)?.value?.trim() ?: ""

    fun guessOdds(text: String): String = Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)").find(text)?.value ?: ""

    fun parsePercentage(value: String): Double? = Regex("(?<!\\d)(\\d{1,3}(?:[.,]\\d+)?)\\s*%").find(value)?.groupValues?.getOrNull(1)?.replace(',', '.')?.toDoubleOrNull()?.takeIf { it in 0.0..100.0 }

    private fun guessTeams(text: String): Pair<String, String>? {
        val parts = Regex("^(.{2,50}?)\\s+(?:[-–—]|vs|v|VS)\\s+(.{2,50}?)(?:\\s+MS\\s*[12X].*)?$", RegexOption.IGNORE_CASE).find(text) ?: return null
        return parts.groupValues[1].trim() to parts.groupValues[2].trim()
    }
}

class IddaaPopularParser : PopularBetParser {
    override val sourceName = "İddaa"
    override val pageUrls = listOf("https://www.iddaa.com/populer-bahisler/futbol")
}

class NesinePopularParser : PopularBetParser {
    override val sourceName = "Nesine"
    override val pageUrls = listOf("https://www.nesine.com/iddaa/dakika-bahis", "https://www.nesine.com/")
}

class MisliPopularParser : PopularBetParser {
    override val sourceName = "Misli"
    override val pageUrls = listOf("https://www.misli.com/iddaa/en-cok-oynanan-tum-maclar", "https://www.misli.com/")
}

class BilyonerPopularParser : PopularBetParser {
    override val sourceName = "Bilyoner"
    override val pageUrls = listOf("https://www.bilyoner.com/iddaa/populer-bahisler", "https://www.bilyoner.com/")
}
