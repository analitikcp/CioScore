package com.cio.skor.data

import android.content.Context
import com.cio.skor.data.parsers.BaseParser
import com.cio.skor.data.parsers.custom.*
import com.cio.skor.network.HttpClient
import com.cio.skor.network.SiteWebViewFetcher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/**
 * STANDALONE 9-SOURCE TEST PROJECT.
 * The original 5 working sources are intentionally NOT included here.
 */
class ScraperRepository(private val context: Context) {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()
    private val siteWeb = SiteWebViewFetcher(context)

    private val sources = listOf(
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/", MightyTipsParser()),
        Source("FootyStats", "https://footystats.org/predictions/correct-score", FootyStatsParser()),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions", GoalVertexParser()),
        Source("NerdyTips", "https://nerdytips.com/correct-score-predictions-today", NerdyTipsParser()),
        Source("Vitibet", "https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal", VitibetParser()),
        Source("HuhSports", "https://www.huhsports.com/", HuhSportsParser()),
        Source("FootballAnt", "https://www.footballant.com/prediction/correct-score-predictions", FootballAntParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Statarea", "https://www.statarea.com/", StatareaParser())
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = http.get(source.url)
                    var scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else emptyList()

                    // These 9 sites are intentionally isolated from the original 5.
                    // If direct HTTP returns no usable scores, render the actual site
                    // in Android WebView and parse the resulting DOM.
                    if (scores.isEmpty()) {
                        val webHtml = siteWeb.fetch(source.url)
                        if (!webHtml.isNullOrBlank()) {
                            scores = source.parser.parse(Jsoup.parse(webHtml, source.url))
                        }
                    }

                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
