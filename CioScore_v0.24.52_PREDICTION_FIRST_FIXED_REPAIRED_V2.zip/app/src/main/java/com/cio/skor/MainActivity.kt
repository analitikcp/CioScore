package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import com.google.android.material.bottomsheet.BottomSheetDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.DropReason
import com.cio.skor.data.UnmatchedDiagnosticItem
import com.cio.skor.data.UnmatchedReason
import com.cio.skor.data.MatchOutlookCandidateDiagnostic
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    private data class GateResult(
        val keptScores: List<ScoreModel>,
        val notInIddaa: List<String>,
        val outsideBulletin: List<String>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        recyclerView.layoutManager = LinearLayoutManager(this)
        // 94+ official fixtures are valid. Disable change animations and keep
        // RecyclerView work predictable so a large bulletin cannot stall the UI.
        recyclerView.setHasFixedSize(false)
        recyclerView.itemAnimator = null
        recyclerView.setItemViewCacheSize(4)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener { showDiagnostics() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all configured score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all prediction sources before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, source ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Kaynaklar: $completed/${repo.sourceCount} — $source"
                            }
                        }
                    }
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    scanStatus.text = "Tüm tahmin kaynakları başarısız oldu."
                    Toast.makeText(this@MainActivity, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else ""

                val rawScores = results.sumOf { it.scores.size }

                val filteredScores = results.flatMap { result: SourceResult -> result.scores }
                    .filter(::isDisplayable)
                val invalidScores = rawScores - filteredScores.size

                // Diagnostic only: count prediction records after the displayability filter.
                runCatching {
                    val diagnosticCounts = filteredScores.groupingBy { it.source }.eachCount()
                    com.cio.skor.data.PipelineDiagnostics.log(
                        sourceCounts = diagnosticCounts,
                        rawPredictions = filteredScores.size
                    )
                }

                // Official Iddaa enrichment is fetched BEFORE the final prediction-source
                // gate. The prediction sites often expose the next calendar day's fixtures
                // while their page is still labelled "today". Our bulletin day is NOT a
                // calendar day: it is a strict 06:00 -> next-day 06:00 Istanbul window.
                // We therefore use the authoritative Iddaa event timestamps to reject a
                // prediction fixture when the same canonical HOME/AWAY fixture exists in
                // Iddaa outside the active bulletin window. This is deliberately an EXACT
                // team-identity gate; fuzzy similarity must never decide whether a prediction
                // belongs to the next bulletin.

                // Official Iddaa enrichment uses the FULL official football bulletin.
                // HT/FT availability is only a market property; it must NEVER restrict
                // the official fixture candidate pool used by GlobalFixtureMatcher.
                // The main scan tolerates a slower official response so the full bulletin
                // has time to arrive before matching.
                val officialResult = try {
                    withTimeoutOrNull(25_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) return@launch

                // Main league/competition filtering is intentionally disabled.
                // The full official bulletin remains the authoritative identity/gate universe.
                // Do not reject fixtures based on provider-specific competition labels.
                val officialGateMatches = officialResult?.allParsedMatches.orEmpty()

                // Deduplicate only true provider duplicates. Team names + score + source
                // are NOT a sufficient identity: the same clubs can legitimately play more
                // than once in the bulletin. Prefer the provider's match ID; otherwise keep
                // kickoff/date/time/competition metadata in the fallback key.
                val dedupedScores: List<ScoreModel> = filteredScores.distinctBy { prediction ->
                    val home = MatchMerger.normalizeTeamName(prediction.homeTeam)
                    val away = MatchMerger.normalizeTeamName(prediction.awayTeam)
                    val source = prediction.source.trim().lowercase()
                    val providerId = prediction.sourceMatchId.trim()
                    if (providerId.isNotBlank()) {
                        "ID|$source|$providerId"
                    } else {
                        "META|$source|$home|$away|${prediction.predictedScore.trim()}|" +
                            "${prediction.matchTimestamp}|${prediction.matchDate.trim()}|" +
                            "${prediction.matchTime.trim()}|${prediction.competitionName.trim().lowercase()}"
                    }
                }

                val gateResult = withContext(Dispatchers.Default) {
                    val notInIddaa = mutableListOf<String>()
                    val outsideBulletin = mutableListOf<String>()

                    if (officialResult != null &&
                        officialGateMatches.isNotEmpty() &&
                        officialResult.bulletinStartMillis > 0L &&
                        officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                    ) {
                        // IMPORTANT: use the same GlobalFixtureMatcher evidence engine for
                        // source -> official matching. The old gate had a second, separate
                        // fuzzy implementation which could disagree with the matcher and
                        // was especially harmful when an official record is marked
                        // as an official anchor so the matcher can apply its verified
                        // two-sided identity rules.
                        val officialRecords = officialGateMatches.mapNotNull { official ->
                            val record = GlobalFixtureMatcher.Record(
                                homeTeam = official.homeTeam,
                                awayTeam = official.awayTeam,
                                source = "IDDAA",
                                sourceMatchId = official.matchId,
                                matchTimestamp = official.matchTimestamp,
                                matchDate = official.matchDate,
                                matchTime = official.matchTime,
                                competitionName = official.competitionName,
                                official = official
                            )
                            if (record.homeCanonicalId.isBlank() || record.awayCanonicalId.isBlank()) null
                            else record to official
                        }

                        val kept = dedupedScores.filter { prediction ->
                            val predictionRecord = GlobalFixtureMatcher.Record(
                                homeTeam = prediction.homeTeam,
                                awayTeam = prediction.awayTeam,
                                predictedScore = prediction.predictedScore,
                                source = prediction.source,
                                sourceMatchId = prediction.sourceMatchId,
                                matchTimestamp = prediction.matchTimestamp,
                                matchDate = prediction.matchDate,
                                matchTime = prediction.matchTime,
                                competitionName = prediction.competitionName
                            )

                            val inBulletinCandidates = officialRecords.asSequence()
                                .filter { (_, official) ->
                                    official.matchTimestamp >= officialResult.bulletinStartMillis &&
                                        official.matchTimestamp < officialResult.bulletinEndMillis
                                }
                                .mapNotNull { (officialRecord, official) ->
                                    val evidence = GlobalFixtureMatcher.score(predictionRecord, officialRecord)
                                    if (evidence.accepted) {
                                        Triple(official, evidence.confidence, evidence)
                                    } else {
                                        null
                                    }
                                }
                                .sortedByDescending { it.second }
                                .toList()

                            if (inBulletinCandidates.isEmpty()) {
                                // A prediction may name an official fixture correctly but refer
                                // to a kickoff outside the active 06:00->06:00 bulletin. Classify
                                // that separately instead of incorrectly calling it "not in Iddaa".
                                val exactOutsideBulletin = officialRecords.any { (officialRecord, official) ->
                                    official.matchTimestamp > 0L &&
                                        (official.matchTimestamp < officialResult.bulletinStartMillis ||
                                            official.matchTimestamp >= officialResult.bulletinEndMillis) &&
                                        predictionRecord.homeCanonicalId.isNotBlank() &&
                                        predictionRecord.homeCanonicalId == officialRecord.homeCanonicalId &&
                                        predictionRecord.awayCanonicalId.isNotBlank() &&
                                        predictionRecord.awayCanonicalId == officialRecord.awayCanonicalId
                                }
                                if (exactOutsideBulletin) {
                                    outsideBulletin +=
                                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | IDDAA=outside-bulletin"
                                } else {
                                    notInIddaa +=
                                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | IDDAA=fixture-yok"
                                }
                                false
                            } else {
                                true
                            }
                        }

                        GateResult(kept, notInIddaa, outsideBulletin)
                    } else {
                        GateResult(emptyList(), notInIddaa, outsideBulletin)
                    }
                }

                val predictionNotInIddaaDetails = gateResult.notInIddaa
                val predictionOutsideBulletinDetails = gateResult.outsideBulletin

                // DISPLAY CONTRACT: Iddaa is enrichment only. A prediction source
                // must NOT be discarded merely because it has no official Iddaa match.
                // The old code used gateResult.keptScores here, which silently removed
                // prediction-only fixtures before MatchMerger could render them.
                val scores: List<ScoreModel> = dedupedScores

                // IMPORTANT: the official feed is the full football bulletin, but the UI
                // card universe must be restricted to the active 06:00 -> next-day 06:00
                // bulletin window. Previously we correctly gated prediction records but
                // then merged the UNFILTERED officialGateMatches back into the UI, which
                // leaked out-of-window official fixtures into the main cards.
                val officialInBulletinWindow = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    // Use the service's already merged official fixture pool. Reusing
                    // allParsedMatches here would re-introduce duplicate official records
                    // that the service intentionally collapsed before the identity graph.
                    officialResult.matches.filter { official ->
                        official.matchTimestamp >= officialResult.bulletinStartMillis &&
                            official.matchTimestamp < officialResult.bulletinEndMillis
                    }
                } else {
                    emptyList()
                }

                // MatchOutlook -> official candidate diagnostics: inspect every parsed
                // MatchOutlook prediction against the SAME official bulletin-window pool
                // used by the card merger. This is diagnostic-only and never changes matching.
                val matchOutlookCandidateDiagnostics = withContext(Dispatchers.Default) {
                    val matchOutlookScores = dedupedScores.filter {
                        it.source.trim().equals("matchoutlook", ignoreCase = true)
                    }
                    val officialRecords = officialInBulletinWindow.map { official ->
                        official to GlobalFixtureMatcher.Record(
                            homeTeam = official.homeTeam,
                            awayTeam = official.awayTeam,
                            source = "IDDAA",
                            sourceMatchId = official.matchId,
                            matchTimestamp = official.matchTimestamp,
                            matchDate = official.matchDate,
                            matchTime = official.matchTime,
                            competitionName = official.competitionName,
                            official = official
                        )
                    }
                    matchOutlookScores.map { prediction ->
                        val predictionRecord = GlobalFixtureMatcher.Record(
                            homeTeam = prediction.homeTeam,
                            awayTeam = prediction.awayTeam,
                            predictedScore = prediction.predictedScore,
                            source = prediction.source,
                            sourceMatchId = prediction.sourceMatchId,
                            matchTimestamp = prediction.matchTimestamp,
                            matchDate = prediction.matchDate,
                            matchTime = prediction.matchTime,
                            competitionName = prediction.competitionName
                        )
                        val candidates = officialRecords.map { (official, record) ->
                            official to GlobalFixtureMatcher.score(predictionRecord, record)
                        }.sortedByDescending { (_, evidence) ->
                            (evidence.homeSimilarity + evidence.awaySimilarity) / 2.0
                        }
                        val best = candidates.firstOrNull()
                        if (best == null) {
                            MatchOutlookCandidateDiagnostic(
                                predictionHome = prediction.homeTeam,
                                predictionAway = prediction.awayTeam,
                                predictedScore = prediction.predictedScore,
                                predictionHomeCanonical = predictionRecord.homeIdentity.canonicalName,
                                predictionAwayCanonical = predictionRecord.awayIdentity.canonicalName
                            )
                        } else {
                            val (official, evidence) = best
                            val reason = when {
                                evidence.accepted -> "ACCEPTED_BY_MATCHER"
                                evidence.homeSimilarity < 0.72 || evidence.awaySimilarity < 0.72 -> "LOW_NAME_SIMILARITY"
                                evidence.teamScore < 0.78 -> "LOW_COMBINED_SIMILARITY"
                                else -> "MATCHER_REJECTED"
                            }
                            MatchOutlookCandidateDiagnostic(
                                predictionHome = prediction.homeTeam,
                                predictionAway = prediction.awayTeam,
                                predictedScore = prediction.predictedScore,
                                predictionHomeCanonical = evidence.homeCanonicalA,
                                predictionAwayCanonical = evidence.awayCanonicalA,
                                bestOfficialHome = official.homeTeam,
                                bestOfficialAway = official.awayTeam,
                                officialMatchId = official.matchId,
                                officialHomeCanonical = evidence.homeCanonicalB,
                                officialAwayCanonical = evidence.awayCanonicalB,
                                homeSimilarity = evidence.homeSimilarity,
                                awaySimilarity = evidence.awaySimilarity,
                                combinedSimilarity = evidence.teamScore,
                                timeScore = evidence.timeScore,
                                competitionScore = evidence.competitionScore,
                                confidence = evidence.confidence,
                                acceptedByMatcher = evidence.accepted,
                                reason = reason
                            )
                        }
                    }
                }

                Log.d("MatchOutlookCandidateDiag", matchOutlookCandidateDiagnostics.joinToString("\n") { item ->
                    "${item.predictionHome} vs ${item.predictionAway} | ${item.predictedScore} | " +
                        "CANDIDATE=${item.bestOfficialHome ?: "-"} vs ${item.bestOfficialAway ?: "-"} | " +
                        "H=${String.format(java.util.Locale.US, "%.3f", item.homeSimilarity)} " +
                        "A=${String.format(java.util.Locale.US, "%.3f", item.awaySimilarity)} " +
                        "COMB=${String.format(java.util.Locale.US, "%.3f", item.combinedSimilarity)} " +
                        "CONF=${String.format(java.util.Locale.US, "%.3f", item.confidence)} | " +
                        "accepted=${item.acceptedByMatcher} | ${item.reason}"
                })

                Log.d("PredictionBulletinGate",
                    "input=${dedupedScores.size} kept=${scores.size} dropped=${predictionNotInIddaaDetails.size + predictionOutsideBulletinDetails.size} " +
                        "window=${officialResult?.bulletinWindow ?: "unknown"}")

                val preparedGroups = withContext(Dispatchers.Default) {
                    // Merge against the full authoritative bulletin. Main league/competition
                    // filtering is disabled; the old full-bulletin display behavior is restored.
                    val unified = MatchMerger.mergeMatches(
                        scores,
                        officialInBulletinWindow
                    )

                    // The official bulletin window controls Iddaa enrichment only.
                    // Prediction-only fixtures are intentionally retained in the UI.
                    // MAIN UI CONTRACT:
                    // A card requires a real prediction score, but it does NOT require
                    // an official Iddaa match. Iddaa is optional enrichment.
                    // This is what allows 5-source prediction fixtures to remain visible
                    // even when the official bulletin has no matching fixture.
                    fun hasRenderablePrediction(match: GlobalFixtureMatcher.UnifiedMatch): Boolean =
                        match.predictions.any { (_, score) ->
                            Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").matches(score.trim())
                        }

                    val displayableUnified = unified.filter(::hasRenderablePrediction)
                    val iddaaMatched = unified.count { it.predictions.isNotEmpty() && it.officialMatch != null }
                    val officialOnlyFixtureCount = unified.count { it.predictions.isEmpty() && it.officialMatch != null }
                    val predictionFixtureCount = unified.count { it.predictions.isNotEmpty() }

                    val reports = results.map { result ->
                        val status = when {
                            result.httpCode !in 200..299 -> ParserStatus.FAILED
                            result.scores.isEmpty() -> ParserStatus.DOM_CHANGED
                            result.error != null -> ParserStatus.DEGRADED
                            else -> ParserStatus.HEALTHY
                        }
                        ParserHealthReport(
                            sourceName = result.source,
                            httpCode = result.httpCode,
                            rawHtmlBytes = result.rawHtmlBytes,
                            parsedCount = result.scores.size,
                            durationMs = result.durationMs,
                            status = status,
                            errorMessage = result.error
                        )
                    }
                    val drops = buildList {
                        if (invalidScores > 0) add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                        if (predictionNotInIddaaDetails.isNotEmpty()) {
                            add(DropReason(
                                PipelineStage.PARSER,
                                "PREDICTION_NOT_IN_IDDAA_BULLETIN",
                                predictionNotInIddaaDetails.size,
                                predictionNotInIddaaDetails.take(12)
                            ))
                        }
                        if (predictionOutsideBulletinDetails.isNotEmpty()) {
                            add(DropReason(
                                PipelineStage.PARSER,
                                "PREDICTION_OUTSIDE_06_00_BULLETIN",
                                predictionOutsideBulletinDetails.size,
                                predictionOutsideBulletinDetails.take(12)
                            ))
                        }
                        val domChanged = reports.count { it.status == ParserStatus.DOM_CHANGED }
                        if (domChanged > 0) add(DropReason(PipelineStage.PARSER, "DOM_CHANGED", domChanged, reports.filter { it.status == ParserStatus.DOM_CHANGED }.map { it.sourceName }))
                        // Official-only fixtures are valid identity-graph records, not merge drops.
                        // NO_PREDICTIONS must therefore count only records that contain no prediction
                        // AND are not official-only fixtures.
                        val officialOnly = unified.count { it.predictions.isEmpty() && it.officialMatch != null }
                        if (officialOnly > 0) add(DropReason(PipelineStage.IDDAA_ENRICHMENT, "OFFICIAL_ONLY_FIXTURE", officialOnly))

                        val noPredictions = unified.count { it.predictions.isEmpty() && it.officialMatch == null }
                        if (noPredictions > 0) add(DropReason(PipelineStage.MERGE, "NO_PREDICTIONS", noPredictions))

                        // This is the real official-enrichment gap: prediction-bearing unified
                        // fixtures that failed to attach to an official Iddaa fixture.
                        val noOfficial = unified.count { it.predictions.isNotEmpty() && it.officialMatch == null }
                        if (noOfficial > 0) add(DropReason(PipelineStage.IDDAA_ENRICHMENT, "OFFICIAL_NOT_MATCHED", noOfficial))
                    }
                    // Diagnostic-only visibility for the real official matching gap.
                    // Diagnostics must follow the same hard candidate gate as production
                    // matching; unrelated official fixtures are never shown as "best" candidates.
                    val unmatchedDiagnostics = if (officialResult != null) {
                        unified.asSequence()
                            .filter { it.predictions.isNotEmpty() && it.officialMatch == null }
                            .map { unmatched ->
                                // Diagnostics MUST use the exact same matcher gate as production
                                // merging. Never use a raw maxByOrNull over every official fixture: 
                                // that turns an unrelated match into a misleading "best candidate".
                                // Use the real prediction record that produced this unified
                                // fixture. Rebuilding it from display names erased kickoff/date
                                // metadata and made DATE_WINDOW_MISMATCH impossible to diagnose.
                                val predictionRecord = unmatched.predictionRecords
                                    .firstOrNull { !it.predictedScore.isNullOrBlank() }
                                    ?: GlobalFixtureMatcher.Record(
                                        homeTeam = unmatched.mainHomeTeam,
                                        awayTeam = unmatched.mainAwayTeam,
                                        source = "DIAGNOSTIC",
                                        matchTimestamp = 0L,
                                        matchDate = ""
                                    )

                                // Diagnostic MUST retain the best scored official fixture even
                                // when production acceptance rejects it. Previously we filtered
                                // evidence.accepted first; every rejected candidate then became
                                // candidate=null and the UI falsely printed SIM=0.00.
                                val bestCandidate = officialResult.matches
                                    .asSequence()
                                    .map { official ->
                                        val officialRecord = GlobalFixtureMatcher.Record(
                                            homeTeam = official.homeTeam,
                                            awayTeam = official.awayTeam,
                                            source = "IDDAA",
                                            sourceMatchId = official.matchId,
                                            matchTimestamp = official.matchTimestamp,
                                            matchDate = official.matchDate,
                                            matchTime = official.matchTime,
                                            competitionName = official.competitionName,
                                            official = official
                                        )
                                        official to GlobalFixtureMatcher.score(predictionRecord, officialRecord)
                                    }
                                    .maxByOrNull { (_, evidence) ->
                                        (evidence.homeSimilarity + evidence.awaySimilarity) / 2.0
                                    }

                                if (bestCandidate == null) {
                                    UnmatchedDiagnosticItem(
                                        predictionHome = unmatched.mainHomeTeam,
                                        predictionAway = unmatched.mainAwayTeam,
                                        bestOfficialHome = null,
                                        bestOfficialAway = null,
                                        homeSimilarity = 0.0,
                                        awaySimilarity = 0.0,
                                        combinedSimilarity = 0.0,
                                        dateDifferenceDays = 0,
                                        probableReason = UnmatchedReason.NO_OFFICIAL_CANDIDATE
                                    )
                                } else {
                                    val (bestOfficial, evidence) = bestCandidate
                                    Log.d(
                                        "OfficialMatchGap",
                                        "UNMATCHED_WITH_VALID_CANDIDATE | ${unmatched.mainHomeTeam} vs ${unmatched.mainAwayTeam} | " +
                                            "predictions=${unmatched.predictions.size} | BEST_OFFICIAL=${bestOfficial.homeTeam} vs ${bestOfficial.awayTeam} | " +
                                            "homeSim=${String.format(java.util.Locale.US, "%.3f", evidence.homeSimilarity)} | " +
                                            "awaySim=${String.format(java.util.Locale.US, "%.3f", evidence.awaySimilarity)} | " +
                                            "confidence=${String.format(java.util.Locale.US, "%.3f", evidence.confidence)} | officialId=${bestOfficial.matchId}"
                                    )
                                    UnmatchedDiagnosticItem(
                                        predictionHome = unmatched.mainHomeTeam,
                                        predictionAway = unmatched.mainAwayTeam,
                                        bestOfficialHome = bestOfficial.homeTeam,
                                        bestOfficialAway = bestOfficial.awayTeam,
                                        homeSimilarity = evidence.homeSimilarity,
                                        awaySimilarity = evidence.awaySimilarity,
                                        homeCanonicalPrediction = evidence.homeCanonicalA,
                                        homeCanonicalOfficial = evidence.homeCanonicalB,
                                        awayCanonicalPrediction = evidence.awayCanonicalA,
                                        awayCanonicalOfficial = evidence.awayCanonicalB,
                                        combinedSimilarity = evidence.teamScore,
                                        dateDifferenceDays = if (
                                            predictionRecord.matchTimestamp > 0L &&
                                            bestOfficial.matchTimestamp > 0L
                                        ) {
                                            kotlin.math.abs(
                                                java.time.temporal.ChronoUnit.DAYS.between(
                                                    java.time.Instant.ofEpochMilli(predictionRecord.matchTimestamp)
                                                        .atZone(java.time.ZoneId.of("Europe/Istanbul"))
                                                        .toLocalDate(),
                                                    java.time.Instant.ofEpochMilli(bestOfficial.matchTimestamp)
                                                        .atZone(java.time.ZoneId.of("Europe/Istanbul"))
                                                        .toLocalDate()
                                                )
                                            ).toInt()
                                        } else 0,
                                        probableReason = when {
                                            evidence.timeScore < 0.0 ->
                                                UnmatchedReason.DATE_WINDOW_MISMATCH
                                            evidence.homeSimilarity >= 0.90 &&
                                                evidence.awaySimilarity >= 0.90 ->
                                                UnmatchedReason.ALIAS_STEMMING_PROBLEM
                                            else ->
                                                UnmatchedReason.LOW_NAME_SIMILARITY
                                        }
                                    )
                                }
                            }
                            .sortedByDescending { (it.homeSimilarity + it.awaySimilarity) / 2.0 }
                            .toList()
                    } else emptyList()

                    ObservabilityBus.publish(
                        ScanTrace(
                            parserReports = reports,
                            stageMetrics = linkedMapOf(
                                PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                                PipelineStage.PARSER to rawScores,
                                PipelineStage.NORMALIZATION to scores.size,
                                PipelineStage.IDENTITY to unified.size,
                                PipelineStage.CONFIDENCE to unified.count { it.fixtureConfidence >= 0.80 },
                                PipelineStage.MERGE to displayableUnified.size,
                                PipelineStage.IDDAA_ENRICHMENT to iddaaMatched,
                                PipelineStage.UI to displayableUnified.size
                            ),
                            dropReasons = drops,
                            totalDurationMs = System.currentTimeMillis() - scanStartMs,
                            unmatchedOfficialDiagnostics = unmatchedDiagnostics,
                            matchOutlookCandidateDiagnostics = matchOutlookCandidateDiagnostics,
                            officialFeedDiagnostics = officialResult?.let { result ->
                                com.cio.skor.data.OfficialFeedDiagnostics(
                                    httpEvents = result.httpEvents,
                                    httpMarketConfig = result.httpMarketConfig,
                                    rawEventCount = result.rawEventCount,
                                    parsedEventCount = result.parsedEventCount,
                                    timestampedEventCount = result.timestampedEventCount,
                                    bulletinEventCountBeforeMerge = result.bulletinEventCountBeforeMerge,
                                    bulletinDate = result.bulletinDate,
                                    bulletinWindow = result.bulletinWindow,
                                    mergedFixtureCount = result.mergedFixtureCount,
                                    marketMatches = result.marketMatches,
                                    error = result.error,
                                    dateDistribution = result.dateDistribution,
                                    sampleFixtures = result.sampleFixtures
                                )
                            },
                            predictionFixtureCount = predictionFixtureCount,
                            officialMatchedPredictionCount = iddaaMatched,
                            officialOnlyFixtureCount = officialOnlyFixtureCount,
                            predictionNotInIddaaCount = predictionNotInIddaaDetails.size,
                            predictionNotInIddaaDetails = predictionNotInIddaaDetails.toList(),
                            predictionNotInIddaaBySource = predictionNotInIddaaDetails.mapNotNull { it.split(" | ").getOrNull(1) }.groupingBy { it }.eachCount(),
                            predictionOutsideBulletinCount = predictionOutsideBulletinDetails.size,
                            predictionOutsideBulletinDetails = predictionOutsideBulletinDetails.toList(),
                            predictionOutsideBulletinBySource = predictionOutsideBulletinDetails.mapNotNull { it.split(" | ").getOrNull(1) }.groupingBy { it }.eachCount()
                        )
                    )

                    // UI bridge for the fifth source (MatchOutlook).
                    // MatchOutlook has no reliable kickoff metadata, so its records can be
                    // rejected by the production gate even when the two team identities are
                    // the same. Attach it only to an EXISTING official card, using the same
                    // conservative two-sided fixture rule as MatchMerger.areMatchesSame(),
                    // and only when the best official candidate is unambiguous.
                    //
                    // Important: this is a presentation bridge only. It does NOT add
                    // prediction-only fixtures and does NOT alter GlobalFixtureMatcher.
                    val uiBridgeSource = "matchoutlook"
                    val uiBridgePool = dedupedScores.filter {
                        it.source.trim().lowercase() == uiBridgeSource
                    }
                    val usedMatchOutlookKeys = mutableSetOf<String>()

                    // MatchOutlook currently has no reliable kickoff metadata. The normal
                    // production matcher therefore remains the authority for the main
                    // identity graph, but the UI also needs to surface a MatchOutlook
                    // prediction when it clearly belongs to an EXISTING official bulletin
                    // fixture. Use the official fixture as the anchor and require both
                    // team identities to agree. This is intentionally stricter than the
                    // old generic similarity bridge.
                    fun selectMatchOutlook(official: IddaaMarketService.OpenedMarketMatch): ScoreModel? {
                        if (uiBridgePool.isEmpty()) return null

                        val officialRecord = GlobalFixtureMatcher.Record(
                            homeTeam = official.homeTeam,
                            awayTeam = official.awayTeam,
                            source = "IDDAA",
                            sourceMatchId = official.matchId,
                            matchTimestamp = official.matchTimestamp,
                            matchDate = official.matchDate,
                            matchTime = official.matchTime,
                            competitionName = official.competitionName,
                            official = official
                        )

                        // MatchOutlook has no reliable kickoff metadata. Reuse the production
                        // matcher rather than maintaining a second similarity implementation.
                        // The official fixture remains the anchor and the matcher enforces
                        // two-sided identity/tier safety.
                        val candidates = uiBridgePool.mapNotNull { candidate ->
                            val candidateKey = candidate.matchKey
                            if (candidateKey in usedMatchOutlookKeys) return@mapNotNull null

                            val predictionRecord = GlobalFixtureMatcher.Record(
                                homeTeam = candidate.homeTeam,
                                awayTeam = candidate.awayTeam,
                                predictedScore = candidate.predictedScore,
                                source = candidate.source,
                                sourceMatchId = candidate.sourceMatchId,
                                matchTimestamp = candidate.matchTimestamp,
                                matchDate = candidate.matchDate,
                                matchTime = candidate.matchTime,
                                competitionName = candidate.competitionName
                            )
                            val evidence = GlobalFixtureMatcher.score(predictionRecord, officialRecord)
                            if (evidence.accepted) candidate to evidence else null
                        }.sortedByDescending { it.second.confidence }

                        val selected = when {
                            candidates.isEmpty() -> null
                            candidates.size == 1 -> candidates.first().first
                            candidates[0].second.confidence - candidates[1].second.confidence >= 0.05 ->
                                candidates.first().first
                            else -> null
                        }

                        if (selected == null) {
                            val top = candidates.take(2).joinToString(" | ") { (candidate, evidence) ->
                                "${candidate.homeTeam} vs ${candidate.awayTeam}=" +
                                    String.format(java.util.Locale.US, "%.3f", evidence.confidence)
                            }
                            Log.d(
                                "MatchOutlookCardBridge",
                                "REJECT ${official.homeTeam} vs ${official.awayTeam} | top=$top"
                            )
                        }
                        return selected
                    }

                    val bridgedUnified = displayableUnified.map { original ->
                        if (original.predictions.any { it.first.trim().lowercase() == uiBridgeSource }) {
                            original
                        } else {
                            val official = original.officialMatch
                            val selected = official?.let(::selectMatchOutlook)
                            if (selected != null) {
                                usedMatchOutlookKeys += selected.matchKey
                                original.predictions.add(selected.source to selected.predictedScore)
                                original.predictionRecords.add(
                                    GlobalFixtureMatcher.Record(
                                        homeTeam = selected.homeTeam,
                                        awayTeam = selected.awayTeam,
                                        predictedScore = selected.predictedScore,
                                        source = selected.source,
                                        sourceMatchId = selected.sourceMatchId,
                                        matchTimestamp = selected.matchTimestamp,
                                        matchDate = selected.matchDate,
                                        matchTime = selected.matchTime,
                                        competitionName = selected.competitionName
                                    )
                                )
                                Log.d(
                                    "MatchOutlookCardBridge",
                                    "ATTACHED ${selected.homeTeam} vs ${selected.awayTeam} -> " +
                                        "${official.homeTeam} vs ${official.awayTeam}"
                                )
                            }
                            original
                        }
                    }.toMutableList()

                    // If MatchOutlook is the ONLY prediction source for an official
                    // bulletin fixture, the production matcher may leave it outside
                    // displayableUnified. Build a card directly from the authoritative
                    // official fixture only when the same conservative two-sided identity
                    // rescue succeeds. This does not create prediction-only cards.
                    if (uiBridgePool.isNotEmpty()) {
                        officialInBulletinWindow.forEach { official ->
                            if (bridgedUnified.any {
                                    it.officialMatch?.matchId == official.matchId ||
                                        (it.officialMatch != null &&
                                            MatchMerger.key(it.officialMatch!!.homeTeam, it.officialMatch!!.awayTeam) ==
                                            MatchMerger.key(official.homeTeam, official.awayTeam))
                                }) return@forEach

                            val selected = selectMatchOutlook(official) ?: return@forEach
                            usedMatchOutlookKeys += selected.matchKey
                            bridgedUnified += GlobalFixtureMatcher.UnifiedMatch(
                                mainHomeTeam = official.homeTeam,
                                mainAwayTeam = official.awayTeam,
                                predictions = mutableListOf(selected.source to selected.predictedScore),
                                predictionRecords = mutableListOf(
                                    GlobalFixtureMatcher.Record(
                                        homeTeam = selected.homeTeam,
                                        awayTeam = selected.awayTeam,
                                        predictedScore = selected.predictedScore,
                                        source = selected.source,
                                        sourceMatchId = selected.sourceMatchId,
                                        matchTimestamp = selected.matchTimestamp,
                                        matchDate = selected.matchDate,
                                        matchTime = selected.matchTime,
                                        competitionName = selected.competitionName
                                    )
                                ),
                                officialMatch = official,
                                fixtureConfidence = 0.90,
                                officialMatchId = official.matchId,
                                fixtureKey = MatchMerger.key(official.homeTeam, official.awayTeam)
                            )
                            Log.d(
                                "MatchOutlookCardBridge",
                                "CREATED OFFICIAL CARD ${selected.homeTeam} vs ${selected.awayTeam} -> " +
                                    "${official.homeTeam} vs ${official.awayTeam}"
                            )
                        }
                    }

                    // A MatchOutlook record that was rescued onto an official card must not
                    // remain as a second prediction-only card. Remove only that rescued source;
                    // preserve any other prediction sources that legitimately belong to the
                    // prediction-only fixture.
                    bridgedUnified.forEach { unified ->
                        if (unified.officialMatch == null) {
                            val homeAwayKey = MatchMerger.key(unified.mainHomeTeam, unified.mainAwayTeam)
                            if (homeAwayKey in usedMatchOutlookKeys) {
                                unified.predictionRecords.removeAll { record ->
                                    record.source.trim().equals(uiBridgeSource, ignoreCase = true) &&
                                        MatchMerger.key(record.homeTeam, record.awayTeam) == homeAwayKey
                                }
                                unified.predictions.removeAll { (source, _) ->
                                    source.trim().equals(uiBridgeSource, ignoreCase = true)
                                }
                            }
                        }
                    }
                    bridgedUnified.removeAll { it.predictions.isEmpty() }

                    // FINAL DISPLAY CONTRACT -------------------------------------------------
                    // The identity graph is the single source of truth for fixture grouping.
                    // Do NOT group dedupedScores by canonical team key here: doing so can
                    // collapse two fixtures that GlobalFixtureMatcher deliberately kept apart
                    // because of time/identity evidence.
                    fun toScoreModel(record: GlobalFixtureMatcher.Record): ScoreModel =
                        ScoreModel(
                            homeTeam = record.homeTeam,
                            awayTeam = record.awayTeam,
                            predictedScore = record.predictedScore.orEmpty(),
                            source = record.source,
                            sourceMatchId = record.sourceMatchId,
                            matchTimestamp = record.matchTimestamp,
                            matchDate = record.matchDate,
                            matchTime = record.matchTime,
                            competitionName = record.competitionName
                        )

                    val predictionGroups = bridgedUnified
                        .asSequence()
                        .filter { it.predictionRecords.isNotEmpty() }
                        .mapNotNull { unified ->
                            val predictions = unified.predictionRecords
                                .filter { !it.predictedScore.isNullOrBlank() }
                                .map(::toScoreModel)
                                .filter { prediction ->
                                    Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$")
                                        .matches(prediction.predictedScore.trim())
                                }
                            if (predictions.isEmpty()) return@mapNotNull null

                            val official = unified.officialMatch
                            MatchGroup(
                                homeTeam = official?.homeTeam ?: unified.mainHomeTeam,
                                awayTeam = official?.awayTeam ?: unified.mainAwayTeam,
                                iddaaProgramUrl = official?.let { buildIddaaProgramUrl(it.matchDate) },
                                predictions = predictions,
                                iddaaMs1 = official?.ms1,
                                iddaaMsX = official?.msX,
                                iddaaMs2 = official?.ms2,
                                htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                                hasHtFt = official?.hasHtFt == true,
                                matchTimestamp = official?.matchTimestamp
                                    ?: predictions.map { it.matchTimestamp }.filter { it > 0L }.minOrNull()
                                    ?: 0L,
                                displayTime = official?.matchTime
                                    ?: predictions.firstOrNull { it.matchTime.isNotBlank() }?.matchTime
                                    ?: "--:--",
                                displayDate = official?.matchDate
                                    ?: predictions.firstOrNull { it.matchDate.isNotBlank() }?.matchDate
                                    ?: "",
                                homeTeamId = null,
                                awayTeamId = null
                            )
                        }
                        .sortedWith(
                            compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                                .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                                .thenBy { it.homeTeam.lowercase() }
                        )
                        .toList()

                    // No fallback card is ever created from official-only fixtures.
                    // Every object handed to RecyclerView contains a real prediction.
                    val trialGroups = predictionGroups.filter { group ->
                        group.predictions.any { prediction ->
                            Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").matches(prediction.predictedScore.trim())
                        }
                    }

                    val previousTrace = ObservabilityBus.lastTrace.value
                    if (previousTrace != null) {
                        ObservabilityBus.publish(previousTrace.copy(
                            stageMetrics = previousTrace.stageMetrics.toMutableMap().apply { this[PipelineStage.UI] = trialGroups.size },
                            totalDurationMs = System.currentTimeMillis() - scanStartMs
                        ))
                    }
                    trialGroups
                }
                allGroups = preparedGroups
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(preparedGroups)
                recyclerView.post {
                    recyclerView.visibility = View.VISIBLE
                    recyclerView.invalidate()
                }
                scanStatus.text = "${allGroups.size} maç • Teşhis: 🔍"
                focusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                scanStatus.text = "Tarama hatası: ${e.javaClass.simpleName}"
                Toast.makeText(
                    this@MainActivity,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) setScanningUi(false)
            }
        }
    }


    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    companion object {
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun diagnosticReportText(trace: ScanTrace): String {
        val sb = StringBuilder()
        sb.appendLine("SCAN DIAGNOSTIC PANEL [#${trace.scanId}]")
        sb.appendLine("MATCHER_CANONICAL_PIPELINE: ${com.cio.skor.data.GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}")
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        sb.appendLine("SÜRE: ${trace.totalDurationMs} ms | DURUM: $successful/${trace.parserReports.size} kaynak")
        sb.appendLine("PIPELINE TRACE")
        trace.stageMetrics.forEach { (stage, count) -> sb.appendLine("• ${stage.name} : $count") }
        val matchOutlookParserCount = trace.parserReports
            .firstOrNull { it.sourceName.trim().equals("MatchOutlook", ignoreCase = true) }
            ?.parsedCount ?: 0
        sb.appendLine("MATCHOUTLOOK KÖPRÜ TEŞHİSİ")
        sb.appendLine("• PARSED: $matchOutlookParserCount | CANDIDATE DIAGNOSTIC: ${trace.matchOutlookCandidateDiagnostics.size}")
        if (trace.matchOutlookCandidateDiagnostics.isEmpty()) {
            sb.appendLine("• UYARI: MatchOutlook aday teşhisi BOŞ")
        } else {
            trace.matchOutlookCandidateDiagnostics.forEachIndexed { index, item ->
                sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway} | SKOR=${item.predictedScore}")
                sb.appendLine("   MAP: HOME=${if (item.predictionHome.isBlank()) "EMPTY" else "OK"} | AWAY=${if (item.predictionAway.isBlank()) "EMPTY" else "OK"} | SCORE=${if (item.predictedScore.isBlank()) "EMPTY" else "OK"}")
                sb.appendLine("   MO CANONICAL: H=${item.predictionHomeCanonical.ifBlank { "-" }} | A=${item.predictionAwayCanonical.ifBlank { "-" }}")
                if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                    sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway} | ID=${item.officialMatchId ?: "-"}")
                    sb.appendLine("   IDDAA CANONICAL: H=${item.officialHomeCanonical.ifBlank { "-" }} | A=${item.officialAwayCanonical.ifBlank { "-" }}")
                } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
                sb.appendLine("   SIM: H=${"%.3f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.3f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.3f".format(java.util.Locale.US, item.combinedSimilarity)} | TIME=${"%.3f".format(java.util.Locale.US, item.timeScore)} | COMP=${"%.3f".format(java.util.Locale.US, item.competitionScore)} | CONF=${"%.3f".format(java.util.Locale.US, item.confidence)}")
                sb.appendLine("   MATCHER: ${if (item.acceptedByMatcher) "ACCEPTED" else "REJECTED"} | ${item.reason}")
            }
        }
        sb.appendLine("MAÇ KÜMESİ / İDDAA EŞLEŞMESİ")
        sb.appendLine("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        sb.appendLine("• İddaa ile eşleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        sb.appendLine("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        sb.appendLine("• Tahmin kaynağı İddaa bülteninde bulunmayan: ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_NOT_IN_IDDAA KAYNAK DAĞILIMI:")
            trace.predictionNotInIddaaBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            sb.appendLine("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        sb.appendLine("• Tahmin kaynağı 06:00 dışı elenen: ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_OUTSIDE_06_00 KAYNAK DAĞILIMI:")
            trace.predictionOutsideBulletinBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            sb.appendLine("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        trace.officialFeedDiagnostics?.let { f ->
            sb.appendLine("İDDAA RESMİ FEED TEŞHİSİ")
            sb.appendLine("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            sb.appendLine("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            sb.appendLine("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            sb.appendLine("• RAW EVENTS: ${f.rawEventCount}")
            sb.appendLine("• PARSED EVENTS: ${f.parsedEventCount}")
            sb.appendLine("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            sb.appendLine("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            sb.appendLine("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            sb.appendLine("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                sb.appendLine("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { sb.appendLine("   - $it") }
            }
            if (!f.error.isNullOrBlank()) sb.appendLine("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                sb.appendLine("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { sb.appendLine("   - $it") }
            }
        } ?: sb.appendLine("• İDDAA FEED SONUCU: alınamadı")
        sb.appendLine("PARSER HEALTH")
        trace.parserReports.forEach { r ->
            sb.appendLine("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}")
        }
        sb.appendLine("DROPPED ITEMS")
        if (trace.dropReasons.isEmpty()) sb.appendLine("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            sb.appendLine("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        sb.appendLine("MATCHOUTLOOK → OFFICIAL CANDIDATE DETAYLARI (${trace.matchOutlookCandidateDiagnostics.size})")
        trace.matchOutlookCandidateDiagnostics.forEachIndexed { index, item ->
            sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway} | SKOR=${item.predictedScore}")
            if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway} | ID=${item.officialMatchId ?: "-"}")
                sb.appendLine("   SIM: H=${"%.3f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.3f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.3f".format(java.util.Locale.US, item.combinedSimilarity)} | CONF=${"%.3f".format(java.util.Locale.US, item.confidence)}")
            } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
            sb.appendLine("   MATCHER: ${if (item.acceptedByMatcher) "ACCEPTED" else "REJECTED"} | ${item.reason}")
        }
        sb.appendLine("OFFICIAL NOT MATCHED DETAYLARI (${trace.unmatchedOfficialDiagnostics.size})")
        trace.unmatchedOfficialDiagnostics.forEachIndexed { index, item ->
            sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway}")
            if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway}")
            } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
            sb.appendLine("   TAHMİN CANONICAL: H=${item.homeCanonicalPrediction.ifBlank { "-" }} | A=${item.awayCanonicalPrediction.ifBlank { "-" }}")
            sb.appendLine("   İDDAA ADAY CANONICAL: H=${item.homeCanonicalOfficial.ifBlank { "-" }} | A=${item.awayCanonicalOfficial.ifBlank { "-" }}")
            sb.appendLine("   SIM: H=${"%.2f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.2f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.2f".format(java.util.Locale.US, item.combinedSimilarity)}")
            sb.appendLine("   TEŞHİS: ${diagnosticReasonLabel(item.probableReason)}")
        }
        return sb.toString()
    }

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SCAN DIAGNOSTIC PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyButton = Button(this).apply {
            text = "📋 KOPYALA"
            textSize = 11f
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("CioScore Scan Diagnostic", diagnosticReportText(trace)))
                Toast.makeText(this@MainActivity, "Teşhis raporu panoya kopyalandı.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(title)
        header.addView(copyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(header)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        fun addText(text: String, bold: Boolean = false, size: Float = 14f) {
            box.addView(TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 4, 0, 4)
            })
        }

        addText("MATCHER CANONICAL PIPELINE: ${com.cio.skor.data.GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}", true, 13f)
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        addText("SÜRE: ${trace.totalDurationMs} ms  •  DURUM: $successful/${trace.parserReports.size} kaynak", true)
        addText("PIPELINE TRACE", true, 16f)
        trace.stageMetrics.forEach { (stage, count) -> addText("• ${stage.name.padEnd(20)} : $count") }

        // MatchOutlook diagnostics are intentionally placed near the top so the user
        // cannot miss them by scrolling past DROPPED ITEMS. This also exposes a
        // stale/wrong APK immediately: parser count and diagnostic-record count must
        // both be visible after every scan.
        val matchOutlookParserCount = trace.parserReports
            .firstOrNull { it.sourceName.trim().equals("MatchOutlook", ignoreCase = true) }
            ?.parsedCount ?: 0
        addText("MATCHOUTLOOK KÖPRÜ TEŞHİSİ", true, 16f)
        addText("• PARSED: $matchOutlookParserCount | CANDIDATE DIAGNOSTIC: ${trace.matchOutlookCandidateDiagnostics.size}")
        if (trace.matchOutlookCandidateDiagnostics.isEmpty()) {
            addText("⚠ MatchOutlook aday teşhisi BOŞ. Bu build'de diagnostic listesi taramaya taşınmamış olabilir.", false, 12f)
        } else {
            trace.matchOutlookCandidateDiagnostics.forEachIndexed { index, item ->
                addText("${index + 1}. ${item.predictionHome} vs ${item.predictionAway} | SKOR=${item.predictedScore}", true, 13f)
                addText(if (item.bestOfficialHome != null && item.bestOfficialAway != null)
                    "   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway} | ID=${item.officialMatchId ?: "-"}"
                else "   ADAY: Resmi bültende aday bulunamadı", false, 12f)
                addText("   SIM: H=${String.format(java.util.Locale.US, "%.3f", item.homeSimilarity)} | A=${String.format(java.util.Locale.US, "%.3f", item.awaySimilarity)} | COMBINED=${String.format(java.util.Locale.US, "%.3f", item.combinedSimilarity)} | CONF=${String.format(java.util.Locale.US, "%.3f", item.confidence)}", false, 11f)
                addText("   MATCHER: ${if (item.acceptedByMatcher) "ACCEPTED" else "REJECTED"} | ${item.reason}", false, 12f)
            }
        }
        addText("MAÇ KÜMESİ / İDDAA EŞLEŞMESİ", true, 16f)
        addText("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        addText("• İddaa ile eşleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        addText("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        addText("• Tahmin kaynağı İddaa bülteninde bulunmayan: ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            addText("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        addText("• Tahmin kaynağı 06:00 dışı elenen: ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            addText("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        trace.officialFeedDiagnostics?.let { f ->
            addText("İDDAA RESMİ FEED TEŞHİSİ", true, 16f)
            addText("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            addText("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            addText("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            addText("• RAW EVENTS: ${f.rawEventCount}")
            addText("• PARSED EVENTS: ${f.parsedEventCount}")
            addText("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            addText("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            addText("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            addText("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                addText("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { addText("   - $it", false, 12f) }
            }
            if (!f.error.isNullOrBlank()) addText("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                addText("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { addText("   - $it", false, 12f) }
            }
        } ?: addText("• İDDAA FEED SONUCU: alınamadı")
        addText("PARSER HEALTH", true, 16f)
        trace.parserReports.forEach { r -> addText("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}") }
        addText("DROPPED ITEMS", true, 16f)
        if (trace.dropReasons.isEmpty()) addText("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            addText("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        addText("MATCHOUTLOOK → OFFICIAL CANDIDATE DETAYLARI (${trace.matchOutlookCandidateDiagnostics.size})", true, 16f)
        trace.matchOutlookCandidateDiagnostics.forEachIndexed { index, item ->
            addText("${index + 1}. ${item.predictionHome} vs ${item.predictionAway} | SKOR=${item.predictedScore}", true, 14f)
            addText("   MAP: HOME=${if (item.predictionHome.isBlank()) "EMPTY" else "OK"} | AWAY=${if (item.predictionAway.isBlank()) "EMPTY" else "OK"} | SCORE=${if (item.predictedScore.isBlank()) "EMPTY" else "OK"}", false, 13f)
            addText("   MO CANONICAL: H=${item.predictionHomeCanonical.ifBlank { "-" }} | A=${item.predictionAwayCanonical.ifBlank { "-" }}", false, 12f)
            addText(if (item.bestOfficialHome != null && item.bestOfficialAway != null) "   Aday: ${item.bestOfficialHome} vs ${item.bestOfficialAway} | ID=${item.officialMatchId ?: "-"}" else "   Aday: Resmi bültende aday bulunamadı", false, 13f)
            addText("   IDDAA CANONICAL: H=${item.officialHomeCanonical.ifBlank { "-" }} | A=${item.officialAwayCanonical.ifBlank { "-" }}", false, 12f)
            addText("   SIM: H=${String.format(java.util.Locale.US, "%.3f", item.homeSimilarity)} | A=${String.format(java.util.Locale.US, "%.3f", item.awaySimilarity)} | COMBINED=${String.format(java.util.Locale.US, "%.3f", item.combinedSimilarity)} | TIME=${String.format(java.util.Locale.US, "%.3f", item.timeScore)} | COMP=${String.format(java.util.Locale.US, "%.3f", item.competitionScore)} | CONF=${String.format(java.util.Locale.US, "%.3f", item.confidence)}", false, 12f)
            addText("   MATCHER: ${if (item.acceptedByMatcher) "ACCEPTED" else "REJECTED"} | ${item.reason}", false, 13f)
        }
        addText("OFFICIAL NOT MATCHED DETAYLARI (${trace.unmatchedOfficialDiagnostics.size})", true, 16f)
        trace.unmatchedOfficialDiagnostics.forEachIndexed { index, item ->
            addText("${index + 1}. ${item.predictionHome} vs ${item.predictionAway}", true, 14f)
            addText(if (item.bestOfficialHome != null && item.bestOfficialAway != null) "   Aday: ${item.bestOfficialHome} vs ${item.bestOfficialAway}" else "   Aday: Resmi bültende aday bulunamadı", false, 13f)
            addText("   TAHMİN CANONICAL: H=${item.homeCanonicalPrediction.ifBlank { "-" }} | A=${item.awayCanonicalPrediction.ifBlank { "-" }}", false, 12f)
            addText("   İDDAA ADAY CANONICAL: H=${item.homeCanonicalOfficial.ifBlank { "-" }} | A=${item.awayCanonicalOfficial.ifBlank { "-" }}", false, 12f)
            addText("   SIM: H: ${String.format(java.util.Locale.US, "%.2f", item.homeSimilarity)} | A: ${String.format(java.util.Locale.US, "%.2f", item.awaySimilarity)} | COMBINED: ${String.format(java.util.Locale.US, "%.2f", item.combinedSimilarity)}", false, 13f)
            addText("   Teşhis: ${diagnosticReasonLabel(item.probableReason)}", false, 13f)
        }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.show()
    }

    private fun diagnosticReasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "🟡 ALIAS_STEMMING_PROBLEM"
        UnmatchedReason.DATE_WINDOW_MISMATCH -> "🔴 DATE_WINDOW_MISMATCH"
        UnmatchedReason.LOW_NAME_SIMILARITY -> "🟠 LOW_NAME_SIMILARITY"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "⚫ NO_OFFICIAL_CANDIDATE"
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        if (active) scanStatus.text = "6 kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
