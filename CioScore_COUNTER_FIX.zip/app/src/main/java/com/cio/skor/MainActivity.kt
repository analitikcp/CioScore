package com.cio.skor
import android.util.Log

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.network.OddsApiClient
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.navigationBarColor = Color.WHITE
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightNavigationBars = true
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Footer, gesture/navigation barın altında kalmasın.
            view.setPadding(
                view.paddingLeft,
                systemBars.top,
                view.paddingRight,
                systemBars.bottom
            )
            insets
        }

        status = findViewById(R.id.tvStatus)
        findViewById<TextView>(R.id.tvStatSources).text = repo.sourceCount.toString()
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        val recycler = findViewById<RecyclerView>(R.id.recyclerScores)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(emptyList())
        recycler.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        findViewById<Button>(R.id.btnScan).setOnClickListener { scan() }
        findViewById<Button>(R.id.btnClearSearch).setOnClickListener {
            searchInput.setText("")
            adapter.submitList(allGroups)
        }

        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        adapter.submitList(emptyList())

        scope.launch {
            // 1) Existing 5-source pipeline runs and renders independently.
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { _, _ ->
                    // Source names intentionally hidden from the UI.
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)

            val unified = MatchMerger.mergeMatches(scores)

            // Alt istatistik şeridi: ekranda gerçekten birleştirilen maçları göster.
            // TEMİZ SKOR = aynı skorun en az 3 kaynak tarafından verildiği maç sayısı.
            val cleanScoreCount = unified.count { match ->
                match.predictions
                    .groupingBy { it.second.trim() }
                    .eachCount()
                    .values
                    .any { count -> count >= 3 }
            }

            findViewById<TextView>(R.id.tvStatSources).text = repo.sourceCount.toString()
            findViewById<TextView>(R.id.tvStatScores).text = cleanScoreCount.toString()
            findViewById<TextView>(R.id.tvStatMatches).text = unified.size.toString()

            allGroups = unified.map { match ->
                MatchGroup(
                    homeTeam = match.mainHomeTeam,
                    awayTeam = match.mainAwayTeam,
                    predictions = match.predictions.map { (source, score) ->
                        ScoreModel(
                            match.mainHomeTeam,
                            match.mainAwayTeam,
                            score,
                            source
                        )
                    }
                )
            }

            // 2) Show the working scraper data BEFORE Odds API.
            adapter.submitList(allGroups)

            // 3) Odds API is optional; failure cannot hide scraper results.
            val odds = withContext(Dispatchers.IO) {
                OddsApiClient.fetchOdds()
            }

            if (odds.isEmpty() || allGroups.isEmpty()) return@launch

            fun findOdds(home: String, away: String) =
                odds.firstOrNull {
                    MatchMerger.isSameTeam(home, it.homeTeam) &&
                        MatchMerger.isSameTeam(away, it.awayTeam)
                }

            allGroups = allGroups.map { match ->
                val o = findOdds(match.homeTeam, match.awayTeam)
                if (o == null) {
                Log.d(
                    "OddsApiClient",
                    "MATCH_NOT_FOUND ${match.homeTeam} - ${match.awayTeam}"
                )
                match
            } else {
                Log.d(
                    "OddsApiClient",
                    "MATCH_MATCHED ${match.homeTeam} - ${match.awayTeam} " +
                        "=> ${o.bookmakerName} ${o.odd1}/${o.oddX}/${o.odd2}"
                )
                match.copy(
                    bookmakerName = o.bookmakerName,
                    odd1 = o.odd1,
                    oddX = o.oddX,
                    odd2 = o.odd2
                )
            }
            }

            adapter.submitList(allGroups)
        }
    }

    private fun sourceLabel(source: String): String = when (source.trim().lowercase()) {
        "fp.com" -> "cio1"
        "predictz" -> "cio2"
        "windrawwin" -> "cio3"
        "soccerseer" -> "cio4"
        "dailysports" -> "cio5"
        "cio1", "cio2", "cio3", "cio4", "cio5" -> source.trim().lowercase()
        else -> source.trim().lowercase()
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
