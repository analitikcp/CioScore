# CioScore v0.24.16 — ANR / matcher hot-path fix

## Root cause found

The scan was already moving network work and the main merge block to coroutine dispatchers, so the primary problem was not a raw OkHttp call on the Android UI thread.

The expensive path was the identity graph itself:

1. `GlobalFixtureMatcher.Record.homeCanonicalId` / `awayCanonicalId` recalculated `TeamAliasCanonicalizer.identity(...)` every access.
2. `GlobalFixtureMatcher.score()` recalculated canonical names and string similarity for the same team pairs repeatedly.
3. `componentsCompatible()` rescanned **all records** to rediscover both Union-Find components on every accepted pair.
4. The official-anchor pass compared every prediction record with the full official roster even when the canonical HOME/AWAY pair was already known.
5. The diagnostic pass then rescored prediction/official pairs again.

With several hundred prediction records plus the official bulletin, this created a large CPU hot path. On a phone this can make the scan appear frozen and can contribute to Android ANR symptoms even when the network requests themselves are asynchronous.

## Fixes applied

- Cached canonical team strings and team identities in `TeamAliasCanonicalizer`.
- Cached canonical similarity results keyed by canonical names + youth/reserve tier.
- `GlobalFixtureMatcher.Record` now computes immutable team identities once.
- Union-Find now maintains component membership incrementally; the safety rule is unchanged, but it no longer scans the whole record list to find component members.
- Added a local pair-evidence cache inside `GlobalFixtureMatcher.merge()`.
- Added an official fixture index by canonical HOME/AWAY fixture key. Exact canonical candidates are checked first; the old full-roster fuzzy fallback remains when the exact candidates are rejected, preserving recall behavior.
- Existing strict acceptance gates, official authority, 12-hour contradiction rule, and component-wide compatibility rule are retained.
- Corrected the CI source-lock checks from stale 6-source/FootyStats assumptions to the actual 7-source repository (removed source + MatchOutlook).
- Updated the visible scan status from stale `6 kaynak` wording to `7 kaynak`.

## Validation performed

- Kotlin compiler check passed for the modified `TeamAliasCanonicalizer` and `GlobalFixtureMatcher` with isolated project stubs.
- Synthetic 530-record benchmark (430 predictions + 100 official) completed in ~0.44–0.48 seconds in the container.
- Synthetic 840-record benchmark (700 predictions + 140 official) completed in ~0.83 seconds.
- Regression sanity check kept unrelated fixtures separate (`Orlando City–Toronto FC`, `Inter Miami–Nashville SC`, `Philadelphia Union–Cincinnati`).

A full Android APK build was not run in this environment because the supplied project ZIP has no Gradle wrapper and the execution container does not have Gradle installed. The repository's GitHub Actions workflow remains the authoritative full Android build path.


## Follow-up v0.24.17

- Fixed verified team aliases for `B. Leverkusen`/`Bayer Leverkusen` and `RB Leipzig`/`Leipzig`.
- Prediction bulletin gate now has a conservative two-sided high-confidence alias fallback after exact canonical lookup.
- `ScoreAdapter` now renders all 7 prediction sources; removed source and MatchOutlook are no longer hidden.
