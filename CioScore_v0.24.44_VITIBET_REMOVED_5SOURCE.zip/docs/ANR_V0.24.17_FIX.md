# CioScore v0.24.17 — identity/gate + 7-source visibility fix

## Issue 1: B. Leverkusen – Leipzig showed TAHMİN YOK

The prediction bulletin gate required an exact canonical HOME/AWAY key before a prediction could enter the global matcher. Provider spellings such as `B. Leverkusen` and `Bayer Leverkusen`, or `RB Leipzig` and `Leipzig`, could therefore be dropped even when the prediction source had valid data.

### Fix
- Added explicit, high-confidence aliases for:
  - `B. Leverkusen` -> `Bayer Leverkusen`
  - `RB Leipzig` / `R B Leipzig` / `Red Bull Leipzig` -> `Leipzig`
- Explicit aliases are resolved before generic reserve-tier token removal, so the leading `B` is not lost.
- A verified senior `B. Leverkusen` shorthand is not treated as a reserve tier. Genuine `B`, `II`, `U21`, `Reserve`, etc. remain protected.
- The official bulletin gate still prefers exact canonical identity. If exact identity is absent, it now permits only a two-sided high-confidence official match (home >= 0.90 AND away >= 0.90). Iddaa remains authoritative and the bulletin time window remains mandatory.

## Issue 2: sources 6 and 7 were parsed but never displayed

The repository already fetched all seven prediction parsers, and the scan reported 7/7. However, `ScoreAdapter.kt` rendered only five source rows (`FP.com`, `PredictZ`, `WinDrawWin`, `SoccerSeer`, `DailySports`). `removed source` and `MatchOutlook` were absent from the UI list, so their predictions could exist in the merged model but were invisible on cards.

### Fix
The UI source order now contains all seven:
1. FP.com
2. PredictZ
3. WinDrawWin
4. SoccerSeer
5. DailySports
6. removed source
7. MatchOutlook

No score-engine or merger rewrite was made for this UI defect.
