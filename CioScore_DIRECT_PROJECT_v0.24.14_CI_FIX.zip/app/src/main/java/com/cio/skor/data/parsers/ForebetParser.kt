package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet mathematical football prediction parser.
 *
 * Forebet renders prediction cards as div.rcnt rows.  The public page exposes
 * the home/away team names, model 1X2 prediction (span.forepr) and the
 * model's correct-score forecast (div.ex_sc.tabonly).  We intentionally use
 * the upcoming row's correct-score forecast as the ScoreModel prediction and
 * do not scrape finished/live score values.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (row in doc.select("div.rcnt")) {
            val home = firstText(row, "span.homeTeam", ".homeTeam") ?: continue
            val away = firstText(row, "span.awayTeam", ".awayTeam") ?: continue
            if (!isRealTeam(home) || !isRealTeam(away)) continue

            // Forebet's ex_sc cell is the model's correct-score forecast.
            // Ignore rows where that forecast is absent (for example some
            // preview/live-only rows).
            val predictedScore = extractScore(
                row.selectFirst("div.ex_sc.tabonly")?.text()
                    ?: row.selectFirst(".ex_sc")?.text()
                    ?: ""
            ) ?: continue

            val model = ScoreModel(
                homeTeam = clean(home),
                awayTeam = clean(away),
                predictedScore = predictedScore,
                source = source
            )
            out[model.matchKey] = model
            if (out.size >= 100) break
        }

        return out.values.toList()
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.selectFirst(selector)?.text()?.let(::clean)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun isRealTeam(value: String): Boolean {
        val v = clean(value)
        if (v.length !in 2..80) return false
        val bad = Regex("(?i)^(prediction|predictions|correct score|odds|analysis|preview|home|away)$")
        return !bad.matches(v) && v.count { it.isLetter() } >= 2
    }

    private fun extractScore(raw: String): String? {
        val value = raw.replace('\u00A0', ' ').trim()
        val match = Regex("(?<!\\d)([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})(?!\\d)").find(value)
            ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return "$home-$away"
    }
}
