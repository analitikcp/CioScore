package com.cio.skor.data

import com.cio.skor.ui.MatchGroup
import kotlin.math.roundToInt

/** Deterministic match analysis built only from source score predictions and Mackolik 1X2 odds. */
object CioScoreAnalyzer {
    data class Analysis(
        val score: Int,
        val confidence: String,
        val bestOutcome: String,
        val bestValuePercent: Int?,
        val consensusScore: String,
        val consensusCount: Int,
        val predictionCount: Int,
        val ms1Percent: Int,
        val msXPercent: Int,
        val ms2Percent: Int,
        val kgYesPercent: Int,
        val over25Percent: Int,
        val under25Percent: Int,
        val topScores: List<String>,
        val risk: String
    )

    fun analyze(match: MatchGroup): Analysis {
        val predictions = match.predictions.mapNotNull { parseScore(it.predictedScore) }
        val n = predictions.size
        if (n == 0) {
            return Analysis(
                0, "Yetersiz", "-", null, "-", 0, 0,
                0, 0, 0, 0, 0, 0, emptyList(), "Yüksek"
            )
        }

        val scoreCounts = predictions.groupingBy { "${it.first}-${it.second}" }.eachCount()
        val consensus = scoreCounts.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key }
        )!!
        val consensusRatio = consensus.value.toDouble() / n

        // Existing CioScore formula is preserved: agreement + source coverage + market alignment.
        val agreementPoints = (15.0 + 35.0 * consensusRatio).coerceAtMost(50.0)
        val coveragePoints = (20.0 * (n.toDouble() / 5.0)).coerceAtMost(20.0)

        var oddsPoints = 0.0
        var bestOutcome = outcomeFromScore(consensus.key)
        var bestValue: Double? = null

        match.odds?.let { odds ->
            val oddsValues = listOf(parseOdds(odds.home), parseOdds(odds.draw), parseOdds(odds.away))
            if (oddsValues.all { it != null && it > 1.0 }) {
                val raw = oddsValues.map { 1.0 / it!! }
                val total = raw.sum()
                val marketProb = raw.map { it / total }
                val sourceProb = outcomeProbabilities(predictions)

                // Blend the bookmaker market with the source predictions.
                // Market odds are the anchor (60%), while the five-source model
                // contributes 40%. This prevents a missing/fragmented source
                // consensus from incorrectly forcing an outcome to 0%.
                val blendedProb = marketProb.indices.map { i ->
                    marketProb[i] * 0.60 + sourceProb[i] * 0.40
                }

                val modelBest = blendedProb.indices.maxByOrNull { blendedProb[it] } ?: 0
                bestOutcome = listOf("MS 1", "MS X", "MS 2")[modelBest]
                val edge = blendedProb[modelBest] * oddsValues[modelBest]!! - 1.0
                bestValue = edge * 100.0

                val marketFavorite = marketProb.indices.maxByOrNull { marketProb[it] } ?: 0
                val consensusOutcome = outcomeIndex(outcomeFromScore(consensus.key))
                oddsPoints = if (consensusOutcome == marketFavorite) {
                    20.0
                } else {
                    val distance = kotlin.math.abs(blendedProb[consensusOutcome] - marketProb[consensusOutcome])
                    (14.0 - distance * 40.0).coerceIn(0.0, 14.0)
                }
            }
        }

        val total = (agreementPoints + coveragePoints + oddsPoints).roundToInt().coerceIn(0, 100)
        val confidence = when {
            total >= 80 -> "Çok yüksek"
            total >= 65 -> "Yüksek"
            total >= 50 -> "Orta"
            else -> "Düşük"
        }

        val valuePercent = bestValue?.let { if (it > 0.0) it.roundToInt() else null }
        val outcomeCounts = outcomeCounts(predictions)
        val topScores = scoreCounts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(3)
            .map { "${it.key} (${it.value}/${n})" }

        val kgYes = predictions.count { it.first > 0 && it.second > 0 }
        val over25 = predictions.count { it.first + it.second >= 3 }
        val risk = when {
            n <= 1 || consensusRatio < 0.40 -> "Yüksek"
            consensusRatio < 0.60 -> "Orta"
            else -> "Düşük"
        }

        return Analysis(
            score = total,
            confidence = confidence,
            bestOutcome = bestOutcome,
            bestValuePercent = valuePercent,
            consensusScore = consensus.key,
            consensusCount = consensus.value,
            predictionCount = n,
            ms1Percent = probabilityPercent(predictions, match.odds, 0),
            msXPercent = probabilityPercent(predictions, match.odds, 1),
            ms2Percent = probabilityPercent(predictions, match.odds, 2),
            kgYesPercent = percent(kgYes, n),
            over25Percent = percent(over25, n),
            under25Percent = percent(n - over25, n),
            topScores = topScores,
            risk = risk
        )
    }

    private fun percent(count: Int, total: Int): Int = (count * 100.0 / total).roundToInt()

    /** 60% Mackolik implied probability + 40% source prediction probability. */
    private fun probabilityPercent(
        predictions: List<Pair<Int, Int>>,
        odds: MatchGroup.Odds?,
        index: Int
    ): Int {
        val source = outcomeProbabilities(predictions)
        val market = odds?.let { o ->
            val values = listOf(parseOdds(o.home), parseOdds(o.draw), parseOdds(o.away))
            if (values.all { it != null && it > 1.0 }) {
                val raw = values.map { 1.0 / it!! }
                val total = raw.sum()
                raw.map { it / total }
            } else null
        }
        val probability = if (market != null) {
            market[index] * 0.60 + source[index] * 0.40
        } else {
            source[index]
        }
        return (probability * 100.0).roundToInt().coerceIn(0, 100)
    }

    private fun parseScore(value: String): Pair<Int, Int>? {
        val m = Regex("^(\\d{1,2})-(\\d{1,2})$").matchEntire(value.trim()) ?: return null
        return m.groupValues[1].toIntOrNull()?.let { h ->
            m.groupValues[2].toIntOrNull()?.let { a -> h to a }
        }
    }

    private fun parseOdds(value: String): Double? = value.replace(',', '.').toDoubleOrNull()

    private fun outcomeFromScore(score: String): String {
        val p = parseScore(score) ?: return "MS X"
        return when {
            p.first > p.second -> "MS 1"
            p.first < p.second -> "MS 2"
            else -> "MS X"
        }
    }

    private fun outcomeIndex(outcome: String): Int = when (outcome) {
        "MS 1" -> 0
        "MS 2" -> 2
        else -> 1
    }

    private fun outcomeProbabilities(predictions: List<Pair<Int, Int>>): List<Double> {
        if (predictions.isEmpty()) return listOf(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
        val counts = outcomeCounts(predictions).map { it.toDouble() }
        return counts.map { it / predictions.size }
    }

    private fun outcomeCounts(predictions: List<Pair<Int, Int>>): IntArray {
        val counts = intArrayOf(0, 0, 0)
        predictions.forEach { (h, a) ->
            counts[when {
                h > a -> 0
                h < a -> 2
                else -> 1
            }]++
        }
        return counts
    }
}
