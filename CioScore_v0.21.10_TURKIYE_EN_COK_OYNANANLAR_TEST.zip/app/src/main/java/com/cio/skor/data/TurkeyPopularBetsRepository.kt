package com.cio.skor.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Consolidates popular bets from İddaa.com, Bilyoner, Nesine and Misli.
 *
 * Score model:
 * - every source can contribute 0..25 points
 * - combined Turkey Trend Score is therefore 0..100
 * - source percentage, play-count and rank-like text are normalized to 0..25
 * - identical fixture + market records are merged through the global identity layer
 *
 * Reliability:
 * - 4 minute in-memory cache
 * - if a refresh fails/returns empty, the last successful snapshot is preserved
 */
class TurkeyPopularBetsRepository(
    private val parsers: List<PopularBetParser> = listOf(
        IddaaPopularParser(),
        BilyonerPopularParser(),
        NesinePopularParser(),
        MisliPopularParser()
    )
) {
    companion object {
        private const val CACHE_TTL_MS = 4L * 60L * 1000L
        @Volatile private var cachedAt: Long = 0L
        @Volatile private var cached: List<TurkeyPopularBetModel> = emptyList()
        @Volatile private var lastSuccessfulSnapshot: List<TurkeyPopularBetModel> = emptyList()
    }

    suspend fun getTurkeyPopularBets(forceRefresh: Boolean = false): List<TurkeyPopularBetModel> = coroutineScope {
        val now = System.currentTimeMillis()
        if (!forceRefresh && cached.isNotEmpty() && now - cachedAt < CACHE_TTL_MS) return@coroutineScope cached

        val fetched = parsers.map { parser ->
            async {
                parser.sourceName to runCatching { parser.fetch() }.getOrDefault(emptyList())
            }
        }.awaitAll()

        val flat = fetched.flatMap { (source, bets) ->
            bets.map { if (it.sourceName == source) it else it.copy(sourceName = source) }
        }

        val consolidated = consolidate(flat)
        if (consolidated.isNotEmpty()) {
            cached = consolidated
            cachedAt = now
            lastSuccessfulSnapshot = consolidated
            consolidated
        } else {
            lastSuccessfulSnapshot.ifEmpty { cached }
        }
    }

    private data class MutableTrend(
        var matchId: String,
        var homeTeam: String,
        var awayTeam: String,
        var matchTime: String,
        var leagueName: String,
        var marketName: String,
        var odds: String,
        val sourceScores: MutableMap<String, Int> = linkedMapOf()
    )

    private fun consolidate(raw: List<PopularBetModel>): List<TurkeyPopularBetModel> {
        val groups = mutableListOf<MutableTrend>()

        raw.filter { it.rawHomeTeam.isNotBlank() && it.rawAwayTeam.isNotBlank() }.forEach { bet ->
            val home = TeamAliasCanonicalizer.identity(bet.rawHomeTeam).canonicalName
            val away = TeamAliasCanonicalizer.identity(bet.rawAwayTeam).canonicalName
            val market = normalizeMarket(bet.prediction)
            if (home.isBlank() || away.isBlank() || market.isBlank()) return@forEach

            val existing = groups.firstOrNull { trend ->
                sameFixture(home, away, bet, trend) && normalizeMarket(trend.marketName) == market
            }

            val contribution = sourceContribution(bet)
            if (existing == null) {
                groups += MutableTrend(
                    matchId = bet.matchCode.ifBlank { "${TeamAliasCanonicalizer.identity(home).canonicalId}__${TeamAliasCanonicalizer.identity(away).canonicalId}" },
                    homeTeam = home,
                    awayTeam = away,
                    matchTime = bet.matchTime.ifBlank { "--:--" },
                    leagueName = bet.leagueName,
                    marketName = market,
                    odds = bet.odds,
                    sourceScores = linkedMapOf(bet.sourceName to contribution)
                )
            } else {
                val old = existing.sourceScores[bet.sourceName] ?: 0
                existing.sourceScores[bet.sourceName] = maxOf(old, contribution)
                if (existing.odds.isBlank() && bet.odds.isNotBlank()) existing.odds = bet.odds
                if ((existing.matchTime == "--:--" || existing.matchTime.isBlank()) && bet.matchTime.isNotBlank()) existing.matchTime = bet.matchTime
                if (existing.leagueName.isBlank() && bet.leagueName.isNotBlank()) existing.leagueName = bet.leagueName
                if (existing.matchId.isBlank() && bet.matchCode.isNotBlank()) existing.matchId = bet.matchCode
            }
        }

        return groups.map { g ->
            TurkeyPopularBetModel(
                matchId = g.matchId,
                homeTeam = displayTeam(g.homeTeam),
                awayTeam = displayTeam(g.awayTeam),
                matchTime = g.matchTime.ifBlank { "--:--" },
                leagueName = g.leagueName,
                marketName = g.marketName,
                odds = g.odds,
                totalPopularityScore = g.sourceScores.values.sum().coerceIn(0, 100),
                sources = g.sourceScores.keys.sortedBy(::sourceOrder)
            )
        }.sortedWith(
            compareByDescending<TurkeyPopularBetModel> { it.totalPopularityScore }
                .thenByDescending { it.sources.size }
                .thenBy { it.homeTeam }
        )
    }

    private fun sameFixture(home: String, away: String, bet: PopularBetModel, trend: MutableTrend): Boolean {
        if (bet.matchCode.isNotBlank() && trend.matchId == bet.matchCode) return true
        val a = GlobalFixtureMatcher.Record(
            homeTeam = home,
            awayTeam = away,
            source = bet.sourceName,
            sourceMatchId = bet.matchCode,
            matchTimestamp = bet.matchTimestamp,
            matchDate = bet.matchDate,
            matchTime = bet.matchTime,
            competitionName = bet.leagueName
        )
        val b = GlobalFixtureMatcher.Record(
            homeTeam = trend.homeTeam,
            awayTeam = trend.awayTeam,
            source = "TurkeyTrend",
            sourceMatchId = trend.matchId,
            matchTime = trend.matchTime,
            competitionName = trend.leagueName
        )
        return GlobalFixtureMatcher.score(a, b).accepted
    }

    private fun sourceContribution(bet: PopularBetModel): Int {
        val raw = bet.ratioOrCount.trim()
        val percent = Regex("%\\s*(\\d{1,3})").find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()
            ?: Regex("(\\d{1,3})\\s*%").find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (percent != null) return (percent.coerceIn(0, 100) * 0.25).roundToInt().coerceIn(1, 25)

        val countText = raw.lowercase(Locale.ROOT).replace(".", "").replace(",", "")
        val count = Regex("(\\d{2,})").find(countText)?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (count != null) {
            // Saturating scale: ~50 plays = 5 pts, ~250 = 15 pts, >=1000 = 25 pts.
            return when {
                count >= 1000 -> 25
                count >= 500 -> 21
                count >= 250 -> 17
                count >= 100 -> 12
                count >= 50 -> 8
                else -> 5
            }
        }

        // Being present in an operator's popular list is itself a trend signal.
        return 10
    }

    private fun normalizeMarket(raw: String): String {
        var value = raw.uppercase(Locale("tr", "TR"))
            .replace(',', '.')
            .replace(Regex("\\s+"), " ")
            .trim()
        value = value
            .replace("MAÇ SONUCU 1", "MS 1")
            .replace("MAÇ SONUCU X", "MS X")
            .replace("MAÇ SONUCU 2", "MS 2")
            .replace("KARŞILIKLI GOL VAR", "KG VAR")
            .replace("KARŞILIKLI GOL YOK", "KG YOK")
            .replace("2.5 GOL ÜST", "2.5 ÜST")
            .replace("2.5 GOL ALT", "2.5 ALT")
        return value
    }

    private fun sourceOrder(source: String): Int = when (source) {
        "İddaa.com", "İddaa" -> 0
        "Bilyoner" -> 1
        "Nesine" -> 2
        "Misli" -> 3
        else -> 9
    }

    private fun displayTeam(canonical: String): String = canonical.split(' ')
        .filter { it.isNotBlank() }
        .joinToString(" ") { token -> token.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("tr", "TR")) else it.toString() } }
}
