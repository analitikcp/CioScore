package com.cio.skor.data

/** Raw popular-bet record from one of the four Turkish operators. */
data class PopularBetModel(
    val sourceName: String,
    val rawHomeTeam: String,
    val rawAwayTeam: String,
    val matchCode: String = "",
    val prediction: String,
    val ratioOrCount: String = "",
    val odds: String = "",
    val matchTimestamp: Long = 0L,
    val matchDate: String = "",
    val matchTime: String = "--:--",
    val leagueName: String = ""
)

data class PopularBetCluster(
    val fixtureKey: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchCode: String,
    val bets: List<PopularBetModel>
) {
    val sourceCount: Int get() = bets.map { it.sourceName }.distinct().size
}
