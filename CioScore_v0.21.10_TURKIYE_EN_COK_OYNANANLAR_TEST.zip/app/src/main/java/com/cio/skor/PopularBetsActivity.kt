package com.cio.skor

import android.app.Activity
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.TurkeyPopularBetModel
import com.cio.skor.data.TurkeyPopularBetsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PopularBetsActivity : Activity() {
    private val COLOR_TEXT = android.graphics.Color.rgb(16, 24, 40)
    private val COLOR_MUTED = android.graphics.Color.rgb(102, 112, 133)
    private val COLOR_SECONDARY = android.graphics.Color.rgb(52, 64, 84)
    private val COLOR_BLUE = android.graphics.Color.rgb(30, 136, 229)
    private val COLOR_GREEN = android.graphics.Color.rgb(2, 122, 72)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = TurkeyPopularBetsRepository()
    private lateinit var recycler: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(12))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        val title = TextView(this).apply {
            text = "🇹🇷 TÜRKİYE EN ÇOK OYNANANLAR"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(4))
        }
        val subtitle = TextView(this).apply {
            text = "İddaa.com • Bilyoner • Nesine • Misli"
            textSize = 12f
            setTextColor(COLOR_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        progress = ProgressBar(this)
        empty = TextView(this).apply {
            text = "Şu anda ortak popüler bahis verisi alınamadı. Son başarılı veri varsa otomatik gösterilir."
            textSize = 14f
            setTextColor(COLOR_MUTED)
            gravity = Gravity.CENTER
            visibility = TextView.GONE
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@PopularBetsActivity)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(empty, LinearLayout.LayoutParams(-1, dp(80)))
        root.addView(recycler, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        progress.visibility = ProgressBar.VISIBLE
        empty.visibility = TextView.GONE
        scope.launch {
            val items = withContext(Dispatchers.IO) { repository.getTurkeyPopularBets() }
            progress.visibility = ProgressBar.GONE
            empty.visibility = if (items.isEmpty()) TextView.VISIBLE else TextView.GONE
            recycler.adapter = PopularAdapter(items)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private inner class PopularAdapter(
        private val items: List<TurkeyPopularBetModel>
    ) : RecyclerView.Adapter<PopularAdapter.VH>() {

        inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply {
                    setColor(android.graphics.Color.WHITE)
                    cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), android.graphics.Color.rgb(231, 234, 240))
                }
                elevation = dp(2).toFloat()
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
                    setMargins(dp(4), dp(5), dp(4), dp(5))
                }
            }
            return VH(card)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.card.removeAllViews()

            val meta = listOf(item.leagueName, item.matchTime)
                .filter { it.isNotBlank() && it != "--:--" }
                .joinToString(" • ")
            if (meta.isNotBlank()) holder.card.addView(text(meta, 12f, false, COLOR_MUTED))

            holder.card.addView(text("${item.homeTeam} vs ${item.awayTeam}", 16f, true, COLOR_TEXT))
            val oddText = if (item.odds.isNotBlank()) " (Oran: ${item.odds})" else ""
            holder.card.addView(text("Tercih: ${item.marketName}$oddText", 14f, true, COLOR_SECONDARY))

            val score = TextView(this@PopularBetsActivity).apply {
                text = "🇹🇷 Türkiye Trend Skoru: ${item.totalPopularityScore}/100"
                textSize = 14f
                setTextColor(COLOR_GREEN)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(8), 0, dp(5))
            }
            holder.card.addView(score)

            val sourceTitle = text("Trend Kaynakları", 12f, false, COLOR_MUTED)
            holder.card.addView(sourceTitle)

            val badges = LinearLayout(this@PopularBetsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.START
            }
            item.sources.forEach { source ->
                val badge = TextView(this@PopularBetsActivity).apply {
                    text = source
                    textSize = 11f
                    setTextColor(android.graphics.Color.WHITE)
                    setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(8), dp(5), dp(8), dp(5))
                    background = GradientDrawable().apply {
                        setColor(COLOR_BLUE)
                        cornerRadius = dp(12).toFloat()
                    }
                }
                badges.addView(badge, LinearLayout.LayoutParams(-2, -2).apply {
                    marginEnd = dp(6)
                    topMargin = dp(3)
                })
            }
            holder.card.addView(badges)
        }

        private fun text(value: String, size: Float, bold: Boolean, color: Int): TextView =
            TextView(this@PopularBetsActivity).apply {
                text = value
                textSize = size
                setTextColor(color)
                setTypeface(typeface, if (bold) Typeface.BOLD else Typeface.NORMAL)
                setPadding(0, dp(3), 0, dp(3))
            }
    }
}
