package com.cio.skor.network

import android.util.Log
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class Bet365Odds(
    val homeTeam: String,
    val awayTeam: String,
    val odd1: String,
    val oddX: String,
    val odd2: String
)

object OddsApiClient {

    // SECURITY: API key is intentionally not committed to the APK/source.
    // Replace this with BuildConfig.ODDS_API_KEY when wiring a GitHub secret.
    private const val API_KEY = "YOUR_ODDS_API_KEY"

    private const val BASE_URL =
        "https://api.the-odds-api.com/v4/sports/soccer_epl/odds/"

    var remainingRequests: String = "-"

    fun fetchBet365Odds(): List<Bet365Odds> {
        if (API_KEY == "YOUR_ODDS_API_KEY") {
            Log.w("OddsApiClient", "Odds API key is not configured.")
            return emptyList()
        }

        val result = mutableListOf<Bet365Odds>()
        var connection: HttpURLConnection? = null

        try {
            val url = URL(
                "$BASE_URL?apiKey=$API_KEY" +
                    "&regions=eu,uk" +
                    "&markets=h2h" +
                    "&oddsFormat=decimal"
            )

            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 15000
            connection.readTimeout = 15000

            remainingRequests =
                connection.getHeaderField("x-requests-remaining") ?: "-"

            Log.d(
                "OddsApiClient",
                "Odds API remaining: $remainingRequests"
            )

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                Log.e(
                    "OddsApiClient",
                    "HTTP ${connection.responseCode}"
                )
                return emptyList()
            }

            val json = connection.inputStream
                .bufferedReader()
                .use { it.readText() }

            val events = JSONArray(json)

            for (i in 0 until events.length()) {
                val event = events.getJSONObject(i)

                val home = event.optString("home_team").trim()
                val away = event.optString("away_team").trim()

                if (home.isBlank() || away.isBlank()) continue

                val bookmakers = event.optJSONArray("bookmakers")
                    ?: continue

                // Bet365 is selected by title/key only.
                // If Bet365 is unavailable for an event, we leave odds empty
                // instead of silently showing another bookmaker as Bet365.
                var bet365 = -1

                for (b in 0 until bookmakers.length()) {
                    val bookmaker = bookmakers.getJSONObject(b)
                    val key = bookmaker.optString("key")
                    val title = bookmaker.optString("title")

                    if (
                        key.contains("bet365", ignoreCase = true) ||
                        title.contains("bet365", ignoreCase = true)
                    ) {
                        bet365 = b
                        break
                    }
                }

                if (bet365 < 0) continue

                val bookmaker = bookmakers.getJSONObject(bet365)
                val markets = bookmaker.optJSONArray("markets")
                    ?: continue

                var odd1 = "-"
                var oddX = "-"
                var odd2 = "-"

                for (m in 0 until markets.length()) {
                    val market = markets.getJSONObject(m)

                    if (market.optString("key") != "h2h") continue

                    val outcomes = market.optJSONArray("outcomes")
                        ?: continue

                    for (j in 0 until outcomes.length()) {
                        val outcome = outcomes.getJSONObject(j)
                        val name = outcome.optString("name").trim()
                        val price = outcome.optDouble("price", Double.NaN)

                        if (price.isNaN()) continue

                        when {
                            name.equals(home, ignoreCase = true) ->
                                odd1 = formatOdd(price)

                            name.equals(away, ignoreCase = true) ->
                                odd2 = formatOdd(price)

                            name.equals("Draw", ignoreCase = true) ->
                                oddX = formatOdd(price)
                        }
                    }

                    break
                }

                if (odd1 != "-" || oddX != "-" || odd2 != "-") {
                    result += Bet365Odds(
                        homeTeam = home,
                        awayTeam = away,
                        odd1 = odd1,
                        oddX = oddX,
                        odd2 = odd2
                    )
                }
            }

        } catch (e: Exception) {
            Log.e(
                "OddsApiClient",
                "Odds API error",
                e
            )
        } finally {
            connection?.disconnect()
        }

        return result
    }

    private fun formatOdd(value: Double): String =
        String.format(java.util.Locale.US, "%.2f", value)
}
