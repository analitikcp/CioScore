# CIO Skor 0.3.1

16 kaynak üzerinden futbol skor tahminlerini taramak için Android uygulaması.

## Build

GitHub Actions, Android Gradle Plugin 8.13.0 ile uyumlu **Gradle 8.13** kullanır.

APK çıktısı: `app/build/outputs/apk/debug/app-debug.apk`
