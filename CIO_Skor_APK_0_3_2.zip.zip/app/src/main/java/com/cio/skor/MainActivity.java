package com.cio.skor;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static class Source {
        final String name, url;
        Source(String name, String url) { this.name = name; this.url = url; }
    }

    private static class Pick {
        final String home, away, score;
        Pick(String home, String away, String score) {
            this.home = home; this.away = away; this.score = score;
        }
    }

    private final List<Source> sources = new ArrayList<>();
    private final List<Pick> allPicks = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Pattern scorePattern = Pattern.compile("(?<!\\d)([0-9]{1,2})\\s*[-–:]\\s*([0-9]{1,2})(?!\\d)");

    private LinearLayout results;
    private TextView summary;
    private TextView consensus;
    private Button scan;
    private ProgressBar progress;
    private WebView web;
    private int index = 0;
    private boolean running = false;
    private Runnable timeout;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildSources();
        buildUi();
        setupWebView();
    }

    private void buildSources() {
        sources.add(new Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"));
        sources.add(new Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"));
        sources.add(new Source("Forebet", "https://www.forebet.com/en/football-predictions/"));
        sources.add(new Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"));
        sources.add(new Source("WinDrawWin", "https://www.windrawwin.com/football-predictions/correct-score/"));
        sources.add(new Source("BettingTipsToday", "https://www.bettingtipstoday.com/correct-score-predictions/"));
        sources.add(new Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"));
        sources.add(new Source("MightyTips", "https://www.mightytips.com/football-predictions/"));
        sources.add(new Source("FootyStats", "https://footystats.org/predictions"));
        sources.add(new Source("GoalVertex", "https://www.goalvertex.com/football-predictions/"));
        sources.add(new Source("NerdyTips", "https://nerdytips.com/football-predictions"));
        sources.add(new Source("Vitibet", "https://www.vitibet.com/index.php?cl=football-predictions"));
        sources.add(new Source("HuhSports", "https://www.huhsports.com/tr/predictions"));
        sources.add(new Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"));
        sources.add(new Source("DailySports", "https://dailysports.net/stat/"));
        sources.add(new Source("Statarea", "https://www.statarea.com/predictions"));
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private TextView tv(String text, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8, 11, 16));

        TextView title = tv("⚽ CIO SKOR", 28, Color.WHITE);
        title.setTypeface(null, 1); title.setPadding(dp(16), dp(18), dp(16), 0);
        TextView sub = tv("16 kaynak • gerçek skor verisi", 17, Color.LTGRAY);
        sub.setPadding(dp(16), 0, dp(16), dp(8));

        scan = new Button(this);
        scan.setText("🔄  BUGÜNÜ TARA"); scan.setTextSize(18);
        scan.setOnClickListener(v -> startScan());

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        progress.setPadding(dp(16), dp(4), dp(16), dp(4));

        summary = tv("Hazır. Tara butonuna bas.", 14, Color.LTGRAY);
        consensus = tv("", 15, Color.WHITE);
        consensus.setVisibility(View.GONE);

        ScrollView sv = new ScrollView(this);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(dp(10), dp(4), dp(10), dp(20));
        sv.addView(results);

        root.addView(title); root.addView(sub); root.addView(scan);
        root.addView(progress); root.addView(summary); root.addView(consensus);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        web = new WebView(this);
        LinearLayout.LayoutParams hidden = new LinearLayout.LayoutParams(1, 1);
        hidden.gravity = Gravity.END;
        root.addView(web, hidden);
        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(false);
        s.setBlockNetworkImage(true);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (!running) return;
                // Let client-side tables/data finish rendering before DOM extraction.
                handler.postDelayed(() -> extractPage(), 3500);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) finishCurrent("🔴 erişim hatası");
            }
        });
    }

    private void startScan() {
        if (running) return;
        running = true; index = 0; allPicks.clear();
        results.removeAllViews(); consensus.setVisibility(View.GONE);
        scan.setEnabled(false); progress.setVisibility(View.VISIBLE);
        summary.setText("16 kaynak taranıyor…");
        scanNext();
    }

    private void scanNext() {
        if (!running) return;
        if (index >= sources.size()) {
            running = false; scan.setEnabled(true); progress.setVisibility(View.GONE);
            summary.setText("Tarama tamamlandı • " + allPicks.size() + " maç/skor kaydı bulundu");
            showConsensus();
            return;
        }

        Source src = sources.get(index);
        addCard(src.name, "🟡 sayfa açılıyor…", Color.LTGRAY);
        summary.setText("Kaynak " + (index + 1) + "/" + sources.size() + " • " + src.name);
        web.stopLoading();
        if (timeout != null) handler.removeCallbacks(timeout);
        timeout = () -> finishCurrent("🟠 zaman aşımı / veri okunamadı");
        handler.postDelayed(timeout, 18000);
        web.loadUrl(src.url);
    }

    /**
     * Extracts candidate rows from the rendered DOM instead of blindly scanning
     * the whole page for every number that looks like a score.
     */
    private void extractPage() {
        String js = "(function(){" +
                "var out=[],seen={};" +
                "var re=/(^|\\s)([0-9]{1,2})\\s*[-–:]\\s*([0-9]{1,2})(?=\\s|$)/;" +
                "function clean(s){return (s||'').replace(/\\u00a0/g,' ').replace(/\\s+/g,' ').trim();}" +
                "function add(el){" +
                " var t=clean(el.innerText||el.textContent);" +
                " if(!t||t.length>900||!re.test(t))return;" +
                " var key=t.toLowerCase(); if(seen[key])return; seen[key]=1;" +
                " var m=t.match(/(^|\\s)([0-9]{1,2})\\s*[-–:]\\s*([0-9]{1,2})(?=\\s|$)/);" +
                " if(!m)return;" +
                " out.push({text:t,score:m[2]+'-'+m[3]});" +
                "}" +
                "var els=document.querySelectorAll('tr,li,article,[class*=match],[class*=game],[class*=fixture],[class*=prediction],[class*=score],div');" +
                "for(var i=0;i<els.length&&out.length<120;i++) add(els[i]);" +
                "return JSON.stringify(out);" +
                "})()";

        web.evaluateJavascript(js, value -> {
            if (!running) return;
            if (timeout != null) handler.removeCallbacks(timeout);
            String json = unescapeJs(value);
            List<Pick> picks = parseCandidates(json);
            if (picks.isEmpty()) {
                finishCurrent("🟠 sayfa açıldı, maç + skor bulunamadı");
            } else {
                allPicks.addAll(picks);
                finishCurrent("🟢 " + picks.size() + " maç/skor bulundu");
                updateCardDetails(index - 1, picks);
            }
        });
    }

    private List<Pick> parseCandidates(String json) {
        List<Pick> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length() && out.size() < 30; i++) {
                JSONObject o = arr.getJSONObject(i);
                String text = normalizeSpaces(o.optString("text"));
                String score = o.optString("score");
                if (!isValidScore(score)) continue;
                String[] teams = findTeams(text, score);
                if (teams == null) continue;
                String home = cleanTeam(teams[0]);
                String away = cleanTeam(teams[1]);
                if (home.length() < 2 || away.length() < 2) continue;
                if (home.equalsIgnoreCase(away)) continue;
                Pick p = new Pick(home, away, score);
                boolean dup = false;
                for (Pick q : out) if (norm(q.home).equals(norm(home)) && norm(q.away).equals(norm(away)) && q.score.equals(score)) { dup = true; break; }
                if (!dup) out.add(p);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private String[] findTeams(String text, String score) {
        String noScore = text.replaceFirst(Pattern.quote(score), " |SCORE| ");
        noScore = normalizeSpaces(noScore);

        // Best case: a row has "Home - Away" / "Home vs Away".
        Pattern p = Pattern.compile("(.{2,90}?)\\s+(?:-|–|—|vs\\.?|v\\.)\\s+(.{2,90}?)(?:\\s+\\|SCORE\\||$)", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(noScore);
        if (m.find()) return new String[]{m.group(1), m.group(2)};

        // Common table layout: team line, team line, score line.
        String[] lines = text.split("\\n|\\r|\\t");
        List<String> useful = new ArrayList<>();
        for (String line : lines) {
            String x = normalizeSpaces(line);
            if (x.isEmpty()) continue;
            if (x.matches(".*\\d{1,2}\\s*[-–:]\\s*\\d{1,2}.*")) continue;
            if (looksLikeTeamLine(x)) useful.add(x);
        }
        if (useful.size() >= 2) return new String[]{useful.get(useful.size()-2), useful.get(useful.size()-1)};

        // Last fallback: text before/after the score token.
        String[] parts = noScore.split("\\|SCORE\\|");
        if (parts.length == 2) {
            String a = lastPhrase(parts[0]);
            String b = firstPhrase(parts[1]);
            if (looksLikeTeamLine(a) && looksLikeTeamLine(b)) return new String[]{a,b};
        }
        return null;
    }

    private boolean looksLikeTeamLine(String s) {
        s = normalizeSpaces(s);
        if (s.length() < 2 || s.length() > 80) return false;
        if (s.matches(".*https?://.*|.*[%$€£].*")) return false;
        String low = s.toLowerCase(Locale.ROOT);
        String[] bad = {"correct score","prediction","odds","probability","today","football predictions","home team","away team","full time","half time"};
        for (String b : bad) if (low.contains(b)) return false;
        int letters = 0;
        for (int i=0;i<s.length();i++) if (Character.isLetter(s.charAt(i))) letters++;
        return letters >= 3;
    }

    private String lastPhrase(String s) {
        String[] a = s.split("\\s{2,}|[|•]");
        return a.length == 0 ? s : a[a.length-1].trim();
    }
    private String firstPhrase(String s) {
        String[] a = s.split("\\s{2,}|[|•]");
        return a.length == 0 ? s : a[0].trim();
    }

    private boolean isValidScore(String score) {
        return score != null && score.matches("\\d{1,2}-\\d{1,2}");
    }

    private String cleanTeam(String s) {
        s = normalizeSpaces(s);
        s = s.replaceAll("^(?:⚽|🏟️|Home|Away)\\s*", "");
        return s.replaceAll("[|•]+$", "").trim();
    }

    private String norm(String s) {
        String x = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim();
        return x;
    }

    private String normalizeSpaces(String s) { return (s == null ? "" : s).replace('\u00a0',' ').replaceAll("\\s+", " ").trim(); }

    private String unescapeJs(String s) {
        if (s == null) return "";
        String x = s;
        if (x.startsWith("\"") && x.endsWith("\"")) x = x.substring(1, x.length()-1);
        return x.replace("\\\"", "\"").replace("\\n", " ").replace("\\r", " ").replace("\\t", " ").replace("\\/", "/").replace("\\u003C", "<").replace("\\u003E", ">");
    }

    private void addCard(String name, String status, int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL); card.setBackgroundColor(Color.rgb(25,31,41));
        card.setPadding(dp(8), dp(5), dp(8), dp(5));
        TextView a = tv("⚽ " + name, 16, Color.WHITE); a.setTypeface(null,1);
        TextView b = tv(status, 13, color);
        card.addView(a); card.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(5),0,dp(5)); results.addView(card, lp);
    }

    private void updateCardDetails(int cardIndex, List<Pick> picks) {
        if (cardIndex < 0 || cardIndex >= results.getChildCount()) return;
        View v = results.getChildAt(cardIndex);
        if (!(v instanceof LinearLayout)) return;
        LinearLayout c = (LinearLayout)v;
        int max = Math.min(8, picks.size());
        for (int i=0;i<max;i++) {
            Pick p = picks.get(i);
            c.addView(tv("• " + p.home + " - " + p.away + " → " + p.score, 12, Color.LTGRAY));
        }
        if (picks.size() > max) c.addView(tv("+ " + (picks.size()-max) + " kayıt daha", 12, Color.GRAY));
    }

    private void finishCurrent(String status) {
        if (!running) return;
        if (timeout != null) handler.removeCallbacks(timeout);
        if (index < results.getChildCount()) {
            View v = results.getChildAt(index);
            if (v instanceof LinearLayout) {
                LinearLayout c = (LinearLayout)v;
                if (c.getChildCount() > 1) {
                    TextView t = (TextView)c.getChildAt(1);
                    t.setText(status);
                    t.setTextColor(status.startsWith("🟢") ? Color.rgb(90,220,110) : Color.LTGRAY);
                }
            }
        }
        index++;
        handler.postDelayed(this::scanNext, 450);
    }

    private void showConsensus() {
        Map<String, Integer> count = new LinkedHashMap<>();
        Map<String, String> label = new LinkedHashMap<>();
        Map<String, String> score = new LinkedHashMap<>();
        for (Pick p : allPicks) {
            String key = norm(p.home) + "||" + norm(p.away) + "||" + p.score;
            count.put(key, count.getOrDefault(key,0)+1);
            label.put(key, p.home + " - " + p.away);
            score.put(key, p.score);
        }
        List<Map.Entry<String,Integer>> entries = new ArrayList<>(count.entrySet());
        entries.sort((a,b) -> Integer.compare(b.getValue(), a.getValue()));
        StringBuilder sb = new StringBuilder("🎯 KONSENSÜS\n");
        int shown = 0;
        for (Map.Entry<String,Integer> e : entries) {
            if (shown++ >= 10) break;
            sb.append(label.get(e.getKey())).append(" → ").append(score.get(e.getKey())).append("  (").append(e.getValue()).append(" kaynak)\n");
        }
        if (entries.isEmpty()) sb.append("Henüz eşleşen maç bulunamadı.");
        consensus.setText(sb.toString()); consensus.setVisibility(View.VISIBLE);
    }

    @Override protected void onDestroy() {
        running = false;
        if (timeout != null) handler.removeCallbacks(timeout);
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
