# CioScore v0.25.26 — Team Identity / Fixture Merge Patch

- Team identity now carries `tier` and `isReserve` and includes tier in `canonicalId`.
- Tier extraction is isolated from `canonical()` and therefore cannot be erased by aliases.
- `Bayer Leverkusen` / `B Leverkusen` remain senior; `Bayer Leverkusen II` remains reserve.
- Bare `Leverkusen` is no longer aliased to Bayer Leverkusen.
- `Başakşehir`, `Basaksehir`, `Başakşehir FK`, `Istanbul Basaksehir` converge to one canonical identity.
- `Beşiktaş`, `Besiktas`, `Beşiktaş JK` converge to one canonical identity.
- Flora Tallinn senior and Flora reserve are separated; Flora II/U21/B reserve labels use the verified `flora-reserve` tier.
- The global fixture matcher continues to require both home and away team evidence plus its existing time/official-anchor gates.

Validation performed in the build environment:
- TeamAliasCanonicalizer + fingerprint dependencies compile with kotlinc.
- Regression checks for Başakşehir, Beşiktaş, Bayer Leverkusen senior/reserve, and Flora senior/reserve pass.
- Full Gradle APK build could not be executed because this environment cannot resolve `services.gradle.org` to download the Gradle 9.5.0 distribution.
