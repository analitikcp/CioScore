package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer

/**
 * Source-independent team identity layer.
 *
 * The same club can arrive as AEK Athens / AEK Atina / AEK Athina or
 * LASK / LASK Linz.  Canonicalization is applied BEFORE matching so the
 * merger never depends on which source arrived first.
 */
object TeamAliasCanonicalizer {
    private val removableEdgeTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio"
    )

    /** Explicit aliases only; meaningful words are not globally deleted. */
    private val aliases = mapOf(
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek fc" to "aek athens",
        "aek athens fc" to "aek athens",
        "lask" to "lask",
        "lask linz" to "lask",
        "lask fc" to "lask",
        "ifk mariehamn" to "ifk mariehamn",
        "mariehamn" to "ifk mariehamn",
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "man city" to "manchester city",
        "spurs" to "tottenham hotspur",
        "tottenham" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",
        "newcastle" to "newcastle united",
        "newcastle utd" to "newcastle united",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "cardiff" to "cardiff city",
        "stoke" to "stoke city",
        "norwich" to "norwich city",
        "coventry" to "coventry city",
        "leicester" to "leicester city",
        "swansea" to "swansea city",
        "birmingham" to "birmingham city",
        "hull" to "hull city",
        "lincoln" to "lincoln city",
        "inter milan" to "inter",
        "internazionale" to "inter",
        "inter milano" to "inter",
        "psv eindhoven" to "psv",
        "sporting lisbon" to "sporting cp",
        "sporting lisboa" to "sporting cp",
        "red bull salzburg" to "salzburg",
        "rb salzburg" to "salzburg",
        "olympiacos piraeus" to "olympiacos",
        "olympiakos" to "olympiacos",
        "dinamo zagreb" to "dinamo zagreb",
        "dynamo kyiv" to "dynamo kyiv",
        "dynamo kiev" to "dynamo kyiv"
    )

    fun canonical(name: String): String {
        if (name.isBlank()) return ""

        var value = name.trim().lowercase()
            // Turkish characters first, then Unicode decomposition.
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        var tokens = value.split(' ').filter { it.isNotBlank() }.toMutableList()

        // Gemini-style language normalization, but token-aware: Athens is changed
        // only as a complete token, never inside Panathinaikos etc.
        tokens = tokens.map { token ->
            when (token) {
                "athens", "atina", "athina" -> "athens"
                else -> token
            }
        }.toMutableList()

        // Safe generic club suffix/prefix removal.
        while (tokens.isNotEmpty() && tokens.first() in removableEdgeTokens) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in removableEdgeTokens) tokens.removeAt(tokens.lastIndex)

        value = tokens.joinToString(" ").trim()
        return aliases[value] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        return a.isNotBlank() && a == b
    }

    /**
     * Levenshtein similarity as requested by the Gemini proposal.
     * Exact aliases are always 1.0.  No blind contains() rule is used because
     * it can incorrectly merge clubs whose names share a short token.
     */
    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        return ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean {
        if (exact(name1, name2)) return true
        return similarity(name1, name2) >= 0.90
    }

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
