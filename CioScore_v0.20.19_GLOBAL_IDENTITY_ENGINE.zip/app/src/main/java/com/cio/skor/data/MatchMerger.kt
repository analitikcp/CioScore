package com.cio.skor.data

/**
 * Public compatibility facade for the global matcher.
 *
 * The old greedy MatchMerger is intentionally gone.  All six sources are
 * handed to GlobalFixtureMatcher in one pass.
 */
object MatchMerger {
    fun normalizeTeamName(name: String): String = TeamAliasCanonicalizer.canonical(name)

    fun key(homeTeam: String, awayTeam: String): String =
        "${TeamAliasCanonicalizer.canonical(homeTeam)}||${TeamAliasCanonicalizer.canonical(awayTeam)}"

    fun isSameTeam(name1: String, name2: String): Boolean =
        TeamAliasCanonicalizer.isSameTeam(name1, name2)

    /** Gemini proposal: explicit home+away fuzzy check at 90% threshold. */
    fun areMatchesSame(
        match1Home: String,
        match1Away: String,
        match2Home: String,
        match2Away: String
    ): Boolean {
        val homeSimilarity = calculateSimilarity(match1Home, match2Home)
        val awaySimilarity = calculateSimilarity(match1Away, match2Away)
        return homeSimilarity >= 0.90 && awaySimilarity >= 0.90
    }

    fun calculateSimilarity(s1: String, s2: String): Double =
        TeamAliasCanonicalizer.similarity(s1, s2)

    fun mergeMatches(
        scrapedList: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()
    ): List<GlobalFixtureMatcher.UnifiedMatch> =
        GlobalFixtureMatcher.merge(scrapedList, officialMatches)
}
