package com.cio.skor.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Production-oriented global fixture identity engine.
 *
 * Pass order is intentional:
 *  1) TeamAliasCanonicalizer / canonical team identity
 *  2) Official Iddaa fixture anchor (hard ID)
 *  3) Date/time blocking + confidence
 *  4) Two-sided fuzzy team matching
 *  5) Union-Find global clustering
 *
 * A source never "wins" merely because it arrived first.
 */
object GlobalFixtureMatcher {
    private const val FUZZY_TEAM_THRESHOLD = 0.80
    private const val STRONG_TEAM_THRESHOLD = 0.90
    private const val ACCEPT_THRESHOLD = 0.80
    private const val TIME_WINDOW_MS = 3L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val externalFixtureId: String = "",
        val homeTeamId: Long? = null,
        val awayTeamId: Long? = null,
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    )

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean
    )

    private class UnionFind(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)
        fun find(value: Int): Int {
            var x = value
            while (parent[x] != x) x = parent[x]
            val root = x
            x = value
            while (parent[x] != x) {
                val next = parent[x]
                parent[x] = root
                x = next
            }
            return root
        }
        fun union(a: Int, b: Int) {
            var ra = find(a); var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) { val t = ra; ra = rb; rb = t }
            parent[rb] = ra
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)
        scraped.forEach { s ->
            records += Record(
                s.homeTeam, s.awayTeam, s.predictedScore, s.source,
                s.sourceMatchId, s.externalFixtureId, s.homeTeamId, s.awayTeamId,
                s.matchTimestamp, s.matchDate, s.matchTime
            )
        }
        officialMatches.forEach { o ->
            records += Record(
                o.homeTeam, o.awayTeam, null, "IDDAA", o.matchId,
                externalFixtureId = o.matchId,
                matchTimestamp = o.matchTimestamp, matchDate = o.matchDate,
                matchTime = o.matchTime, official = o
            )
        }
        if (records.isEmpty()) return emptyList()

        val uf = UnionFind(records.size)

        // PASS 1 — hard official anchor. Never use team names to override an ID.
        val officialIds = HashMap<String, Int>()
        records.indices.forEach { i ->
            val r = records[i]
            if (r.official != null && r.sourceMatchId.isNotBlank()) {
                officialIds[r.sourceMatchId.trim()]?.let { uf.union(it, i) }
                    ?: run { officialIds[r.sourceMatchId.trim()] = i }
            }
        }

        // PASS 2 — canonical fixture identity.
        val exact = HashMap<String, Int>()
        records.indices.forEach { i ->
            val key = fixtureKey(records[i])
            if (key != "||") exact[key]?.let { j ->
                if (sameSourceDifferentIds(records[i], records[j])) return@let
                uf.union(j, i)
            } ?: run { exact[key] = i }
        }

        // PASS 3 — global pair scoring. No arrival-order greedy matching.
        for (i in records.indices) for (j in i + 1 until records.size) {
            val a = records[i]; val b = records[j]
            if (sameSourceDifferentIds(a, b)) continue
            if (score(a, b).accepted) uf.union(i, j)
        }

        val groups = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { i -> groups.getOrPut(uf.find(i)) { mutableListOf() }.add(records[i]) }
        return groups.values.map(::buildUnified)
    }

    private fun fixtureKey(r: Record) =
        TeamAliasCanonicalizer.canonical(r.homeTeam) + "||" + TeamAliasCanonicalizer.canonical(r.awayTeam)

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, true)) return false
        val x = a.sourceMatchId.trim(); val y = b.sourceMatchId.trim()
        return x.isNotBlank() && y.isNotBlank() && x != y
    }

    fun score(a: Record, b: Record): MatchEvidence {
        val home = TeamAliasCanonicalizer.similarity(a.homeTeam, b.homeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.awayTeam, b.awayTeam)
        val teamScore = (home + away) / 2.0
        val idAnchor = sameComparableId(a, b)
        val officialAnchor = a.official != null || b.official != null
        val time = timeScore(a, b)

        if (idAnchor) return MatchEvidence(home, away, teamScore, time, true, officialAnchor, 1.0, true)
        if (time < 0.0) return MatchEvidence(home, away, teamScore, time, false, officialAnchor, 0.0, false)

        // A direct official-anchor attachment requires both sides to be strong.
        if (officialAnchor) {
            val accepted = home >= STRONG_TEAM_THRESHOLD && away >= STRONG_TEAM_THRESHOLD
            val confidence = if (accepted) {
                (0.45 * home + 0.45 * away + 0.10 * time.coerceAtLeast(0.0)).coerceIn(0.0, 0.99)
            } else 0.0
            return MatchEvidence(home, away, teamScore, time, false, true, confidence, accepted)
        }

        // Soft pass: both teams must be plausible. Stronger team identity compensates
        // for modest naming differences; time remains a guard, not a hard requirement.
        if (home < FUZZY_TEAM_THRESHOLD || away < FUZZY_TEAM_THRESHOLD) {
            return MatchEvidence(home, away, teamScore, time, false, false, 0.0, false)
        }
        val timeComponent = if (time == 0.0) 0.50 else time.coerceAtLeast(0.0)
        val confidence = (0.70 * teamScore + 0.30 * timeComponent).coerceIn(0.0, 0.99)
        return MatchEvidence(home, away, teamScore, time, false, false, confidence, confidence >= ACCEPT_THRESHOLD)
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val ids = listOf(a.externalFixtureId, a.sourceMatchId).map { it.trim() }.filter { it.isNotBlank() }
        val other = listOf(b.externalFixtureId, b.sourceMatchId).map { it.trim() }.filter { it.isNotBlank() }
        if (ids.isEmpty() || other.isEmpty()) return false
        return ids.any { it in other } && (a.source.equals(b.source, true) || a.official != null || b.official != null)
    }

    /** Returns 0 when time is unavailable, -1 when > +/-3h, otherwise 0..1. */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_WINDOW_MS) return -1.0
            return 1.0 - delta.toDouble() / TIME_WINDOW_MS
        }
        val da = parseDate(a.matchDate); val db = parseDate(b.matchDate)
        if (da != null && db != null) return if (da == db) 0.85 else -1.0
        return 0.0
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim(); if (v.isBlank()) return null
        listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy").forEach { p ->
            runCatching { LocalDate.parse(v, DateTimeFormatter.ofPattern(p)) }.getOrNull()?.let { return it }
        }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = if (official != null) official.homeTeam to official.awayTeam
        else group.maxByOrNull { TeamAliasCanonicalizer.canonical(it.homeTeam).length + TeamAliasCanonicalizer.canonical(it.awayTeam).length }
            ?.let { it.homeTeam to it.awayTeam } ?: (group.first().homeTeam to group.first().awayTeam)
        val result = UnifiedMatch(display.first, display.second, officialMatch = official, officialMatchId = official?.matchId.orEmpty())

        val bySource = LinkedHashMap<String, Record>()
        group.filter { !it.predictedScore.isNullOrBlank() }.forEach { r ->
            val k = r.source.trim().lowercase()
            val old = bySource[k]
            if (old == null || sourcePriority(r) > sourcePriority(old)) bySource[k] = r
        }
        bySource.values.forEach { result.predictions += it.source to it.predictedScore.orEmpty() }
        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun sourcePriority(r: Record): Int =
        (if (!r.predictedScore.isNullOrBlank()) 5 else 0) +
        (if (r.matchTimestamp > 0) 2 else 0) +
        (if (r.sourceMatchId.isNotBlank()) 1 else 0) +
        (if (r.official != null) 10 else 0)

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        var total = 0.0; var count = 0
        for (i in 0 until group.lastIndex) for (j in i + 1..group.lastIndex) {
            val e = score(group[i], group[j])
            if (e.accepted) { total += e.confidence; count++ }
        }
        return if (count == 0) 0.0 else total / count
    }
}
