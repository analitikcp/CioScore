package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Result(val name: String, val code: Int, val scores: List<String>, val error: String? = null)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/all-games/all-stakes/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 12, 17))
            setPadding(28, 30, 28, 20)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 18)
        }
        root.addView(sub)

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 18f
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 60))

        val info = TextView(this).apply {
            text = "Gerçek sayfalardan HTTP + HTML taraması yapar. Kaynak erişilemezse nedenini gösterir."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 12, 0, 12)
        }
        root.addView(info)

        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this)
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInitialRows()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        sources.forEachIndexed { index, s ->
            val row = row("${index + 1}. ${s.name}", "⏳ Henüz taranmadı")
            resultBox.addView(row)
        }
    }

    private fun scanAll() {
        scanButton.isEnabled = false
        scanButton.text = "⏳  16 KAYNAK TARANIYOR..."
        resultBox.removeAllViews()

        val rows = HashMap<String, TextView>()
        sources.forEachIndexed { index, s ->
            val r = row("${index + 1}. ${s.name}", "⏳ Bekliyor...")
            val detail = r.getChildAt(1) as TextView
            rows[s.name] = detail
            resultBox.addView(r)
        }

        val done = AtomicInteger(0)
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                runOnUiThread {
                    val detail = rows[source.name]
                    if (detail != null) {
                        detail.text = formatResult(result)
                        detail.setTextColor(if (result.scores.isNotEmpty()) Color.rgb(70, 220, 130) else Color.rgb(255, 190, 70))
                    }
                    if (done.incrementAndGet() == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                    }
                }
            }
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(25, 31, 39))
        }
        val t = TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 5, 0, 0)
        }
        box.addView(t)
        box.addView(d)
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 4, 0, 4) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        return try {
            val connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 20000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "Boş HTML")
            val doc = Jsoup.parse(html)
            val text = doc.text()
            val scores = extractScores(text)
            Result(source.name, code, scores)
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), e.javaClass.simpleName + ": " + (e.message ?: "hata"))
        }
    }

    private fun extractScores(text: String): List<String> {
        val p = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
        val m = p.matcher(text)
        val counts = LinkedHashMap<String, Int>()
        while (m.find()) {
            val score = "${m.group(1)}-${m.group(2)}"
            counts[score] = (counts[score] ?: 0) + 1
        }
        return counts.entries.sortedByDescending { it.value }.take(8).map { "${it.key} (${it.value})" }
    }

    private fun formatResult(r: Result): String {
        if (r.error != null) return "❌ ${r.error} • skor deseni bulunamadı"
        if (r.scores.isEmpty()) return "⚠️ HTTP ${r.code} • HTML geldi ama skor deseni bulunamadı"
        return "✅ HTTP ${r.code} • ${r.scores.joinToString("  ")}"
    }
}
