# CIO Score 0.4.0

16 kaynaklı gerçek HTTP/HTML tarama arayüzü.

- 16 kaynak aynı anda taranır.
- HTTP durumu gösterilir.
- HTML içinden bulunan doğru skor desenleri gösterilir.
- Kaynak erişilemezse hata açıkça gösterilir.
