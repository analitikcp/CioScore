package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.max

/**
 * Optional external-data enrichment.
 *
 * 1X2 odds are now taken from AiScore first.  The odds layer is deliberately
 * isolated from the five CIO sources: if AiScore is unavailable, the core
 * scan still completes normally.
 *
 * Recent-form data remains on the already-working team-event path so the
 * successful Son 5 Maç feature is not broken while the odds provider changes.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)

    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    private val http = HttpClient()
    private val sofaBase = "https://api.sofascore.com/api/v1"

    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> =
        with(Dispatchers.IO) {
            if (groups.isEmpty()) return@with groups

            // One lightweight SofaScore schedule request supplies reliable
            // kickoff timestamps for today's fixtures. It is enrichment only:
            // if it fails, the CIO result list remains intact.
            val scheduled = loadTodayScheduledEvents()

            // AiScore remains the odds provider. If its pages are unavailable,
            // kickoff times are still retained.
            val pages = loadAiScorePages()

            groups.map { group ->
                val kickoff = findScheduledKickoff(
                    scheduled, group.homeTeam, group.awayTeam
                )
                val odds = if (pages.isNotEmpty()) {
                    val matchUrl = findAiScoreMatchUrl(pages, group.homeTeam, group.awayTeam)
                    matchUrl?.let { loadAiScoreOdds(it) }
                } else null

                group.copy(
                    odds = odds ?: group.odds,
                    startTimestamp = kickoff ?: group.startTimestamp
                )
            }
        }

    private data class ScheduledEvent(
        val homeTeam: String,
        val awayTeam: String,
        val startTimestamp: Long
    )

    private fun loadTodayScheduledEvents(): List<ScheduledEvent> {
        val date = LocalDate.now().toString()
        val url = "$sofaBase/sport/football/scheduled-events/$date"
        val (code, body) = http.get(url, "https://www.sofascore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()

        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            val out = mutableListOf<ScheduledEvent>()
            for (i in 0 until events.length()) {
                val event = events.optJSONObject(i) ?: continue
                val status = event.optJSONObject("status")?.optString("type").orEmpty()
                if (status == "finished" || status == "canceled" || status == "postponed") continue
                val home = event.optJSONObject("homeTeam")?.optString("name").orEmpty()
                val away = event.optJSONObject("awayTeam")?.optString("name").orEmpty()
                val start = event.optLong("startTimestamp", 0L)
                if (home.isBlank() || away.isBlank() || start <= 0L) continue
                out += ScheduledEvent(home, away, start)
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun findScheduledKickoff(
        events: List<ScheduledEvent>,
        homeTeam: String,
        awayTeam: String
    ): Long? {
        var best: ScheduledEvent? = null
        var bestScore = 0.0
        for (event in events) {
            val homeScore = teamSimilarity(event.homeTeam, homeTeam)
            val awayScore = teamSimilarity(event.awayTeam, awayTeam)
            if (homeScore < 0.86 || awayScore < 0.86) continue
            val score = (homeScore + awayScore) / 2.0
            if (score > bestScore) {
                bestScore = score
                best = event
            }
        }
        return best?.startTimestamp
    }

    suspend fun getLastFive(teamName: String): List<RecentMatch> = with(Dispatchers.IO) {
        val teamId = findTeamId(teamName) ?: return@with emptyList()
        val (code, body) = http.get(
            "$sofaBase/team/$teamId/events/last/0",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return@with emptyList()
        parseRecentMatches(JSONObject(body), teamId).take(5)
    }

    private data class SchedulePage(val url: String, val doc: org.jsoup.nodes.Document)

    private fun loadAiScorePages(): List<SchedulePage> {
        val date = LocalDate.now().toString().replace("-", "")
        val urls = listOf(
            "https://m.aiscore.com/$date",
            "https://www.aiscore.com/live",
            "https://m.aiscore.com/"
        )

        val pages = mutableListOf<SchedulePage>()
        for (url in urls) {
            val (code, body) = http.get(url, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                pages += SchedulePage(url, org.jsoup.Jsoup.parse(body, url))
            } catch (_: Exception) {
                // Try the next public page.
            }
        }
        return pages
    }

    private fun findAiScoreMatchUrl(
        pages: List<SchedulePage>,
        homeTeam: String,
        awayTeam: String
    ): String? {
        val home = MatchMerger.normalizeTeamName(homeTeam).replace(" ", "")
        val away = MatchMerger.normalizeTeamName(awayTeam).replace(" ", "")
        if (home.isBlank() || away.isBlank()) return null

        val homeSlug = home.replace("-", "")
        val awaySlug = away.replace("-", "")

        for (page in pages) {
            for (a in page.doc.select("a[href]")) {
                val href = a.attr("abs:href").ifBlank { a.attr("href") }
                if (!href.contains("aiscore.com") || !href.contains("/match-")) continue

                val anchorText = MatchMerger.normalizeTeamName(a.text()).replace(" ", "")
                val parentText = MatchMerger.normalizeTeamName(a.parent()?.text().orEmpty()).replace(" ", "")
                val hrefText = href.lowercase().replace(Regex("[^a-z0-9]"), "")

                val textHit =
                    (anchorText.contains(home) && anchorText.contains(away)) ||
                    (parentText.contains(home) && parentText.contains(away))
                val slugHit = hrefText.contains(homeSlug) && hrefText.contains(awaySlug)

                if (textHit || slugHit) return href.substringBefore("?")
            }
        }
        return null
    }

    private fun loadAiScoreOdds(matchUrl: String): Odds? {
        // AiScore match pages expose an Odds section; the same page is enough
        // for the first available 1/X/2 triplet and avoids one extra API call.
        val oddsUrl = if (matchUrl.endsWith("/odds")) matchUrl else "$matchUrl/odds"
        val urls = listOf(oddsUrl, matchUrl)

        for (url in urls) {
            val (code, body) = http.get(url, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            val odds = parseAiScoreOdds(body)
            if (odds != null) return odds
        }
        return null
    }

    private fun parseAiScoreOdds(body: String): Odds? {
        return try {
            val doc = org.jsoup.Jsoup.parse(body)
            val text = doc.text().replace(Regex("\\s+"), " ")

            // Public AiScore match pages label the market as "1 X 2" and
            // render decimal odds in order. See the site's odds pages.
            val marker = Regex("(?i)\\b1\\s+X\\s+2\\b").find(text)
            val window = if (marker != null) {
                text.substring(marker.range.last + 1, minOf(text.length, marker.range.last + 1000))
            } else {
                text
            }

            val triplet = Regex(
                "\\b([1-9]\\d?(?:\\.\\d{1,2})?)\\s+([1-9]\\d?(?:\\.\\d{1,2})?)\\s+([1-9]\\d?(?:\\.\\d{1,2})?)\\b"
            ).find(window)

            if (triplet != null) {
                val values = listOf(
                    triplet.groupValues[1].toDoubleOrNull(),
                    triplet.groupValues[2].toDoubleOrNull(),
                    triplet.groupValues[3].toDoubleOrNull()
                )
                if (values.all { it != null && it > 1.0 && it <= 100.0 }) {
                    return Odds(
                        String.format(java.util.Locale.US, "%.2f", values[0]),
                        String.format(java.util.Locale.US, "%.2f", values[1]),
                        String.format(java.util.Locale.US, "%.2f", values[2])
                    )
                }
            }

            // JSON/state fallback for pages where the visible text is not
            // server-rendered but the odds are embedded in the HTML.
            val jsonTriplet = Regex(
                "(?i)\\\"(?:1|home)\\\"\\s*[:=]\\s*\\\"?([0-9]+(?:\\.[0-9]+)?)\\\"?.*?" +
                    "\\\"(?:x|draw)\\\"\\s*[:=]\\s*\\\"?([0-9]+(?:\\.[0-9]+)?)\\\"?.*?" +
                    "\\\"(?:2|away)\\\"\\s*[:=]\\s*\\\"?([0-9]+(?:\\.[0-9]+)?)\\\"?"
            ).find(body)

            jsonTriplet?.let {
                val values = listOf(
                    it.groupValues[1].toDoubleOrNull(),
                    it.groupValues[2].toDoubleOrNull(),
                    it.groupValues[3].toDoubleOrNull()
                )
                if (values.all { v -> v != null && v > 1.0 && v <= 100.0 }) {
                    return Odds(
                        String.format(java.util.Locale.US, "%.2f", values[0]),
                        String.format(java.util.Locale.US, "%.2f", values[1]),
                        String.format(java.util.Locale.US, "%.2f", values[2])
                    )
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$sofaBase/search/all?q=$query",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase()
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result)
        }
        return out.sortedByDescending { it.date }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null,
        val startTimestamp: Long? = null
    )
}
