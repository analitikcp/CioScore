# CIO Score 0.8.15.1 - 5 Kaynak - Build Safe

0.8.15 tabanı korunur. Bu düzeltmede yalnızca Apache Commons Text bağımlılığı kaldırılmış ve Levenshtein hesabı Kotlin içinde uygulanmıştır; amaç GitHub Actions derlemesinde dış bağımlılık kaynaklı risk bırakmamaktır.
