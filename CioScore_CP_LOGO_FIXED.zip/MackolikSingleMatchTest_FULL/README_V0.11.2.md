# CioScore v0.11.2 - Mackolik ALL 1X2

Bu sürüm tek maç testinde doğrulanan Maçkolik HTML yapısını bütün bültene uygular.

- Tek HTTP GET: `https://arsiv2.mackolik.com/Iddaa-Programi`
- Gerçek `<tr>` maç satırları taranır.
- Takım adı hücresi doğrudan `<td>/<th>` içinden alınır.
- 5 haneli İddaa kodu bulunur.
- Koddan sonra gelen ilk üç decimal değer MS1 / MSX / MS2 olarak alınır.
- Bütün bülten bellekte parse edilir; maç başına HTTP isteği yoktur.
- Ana tarama coroutine'i Maçkolik sonucunu bekler; sonuç gelmeden "tarama tamamlandı" yazılmaz.
- UI'da Maçkolik eşleşme sayısı ve HTTP sonucu gösterilir.
