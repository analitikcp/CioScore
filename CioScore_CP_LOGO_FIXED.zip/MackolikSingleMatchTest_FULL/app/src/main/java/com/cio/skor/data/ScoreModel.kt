package com.cio.skor.data

data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String
) {
    /** Stable fixture identity derived from the normalized team names. */
    val matchKey: String
        get() = MatchMerger.key(homeTeam, awayTeam)
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null
)
