package com.cio.skor

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()
    private val mackolikOdds = com.cio.skor.data.MackolikOddsService()

    private lateinit var status: TextView
    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        status = findViewById(R.id.tvStatus)
        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)
        findViewById<TextView>(R.id.tvStatSources).text = repo.sourceCount.toString()
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        val recycler = findViewById<RecyclerView>(R.id.recyclerScores)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(emptyList()) { team -> showLastFive(team) }
        recycler.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnClearSearch).setOnClickListener {
            searchInput.setText("")
            adapter.submitList(allGroups)
        }

        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        scanning = true
        setScanningUi(true)

        adapter.submitList(emptyList())
        findViewById<TextView>(R.id.tvStatSources).text = "0"
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        scope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, _ ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Taranıyor…  $completed/${repo.sourceCount} kaynak"
                            }
                        }
                    }
                }

                val scores: List<ScoreModel> = results
                    .flatMap { result: SourceResult -> result.scores }
                    .filter(::isDisplayable)
                    .distinctBy {
                        "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                        "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                        "${it.predictedScore}|${it.source.trim().lowercase()}"
                    }

                val goodSources = scores.map { sourceLabel(it.source) }
                    .filter { it.isNotEmpty() }
                    .distinct()

                // Önce bütün ham kayıtlar toplanır, sonra MatchMerger ile birleştirilir.
                val unified = MatchMerger.mergeMatches(scores)
                val baseGroups = unified.map { match ->
                    SofaScoreService.MatchGroupData(
                        homeTeam = match.mainHomeTeam,
                        awayTeam = match.mainAwayTeam,
                        predictions = match.predictions.map { (source, score) ->
                            ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                        }
                    )
                }

                // CORE RESULTS ARE SHOWN IMMEDIATELY. Maçkolik bütün bülteni tek GET ile okur.
                allGroups = baseGroups.map { match ->
                    MatchGroup(
                        homeTeam = match.homeTeam,
                        awayTeam = match.awayTeam,
                        predictions = match.predictions,
                        odds = null,
                        oddsSource = "Maçkolik"
                    )
                }
                adapter.submitList(allGroups)
                findViewById<TextView>(R.id.tvStatSources).text = goodSources.size.toString()
                findViewById<TextView>(R.id.tvStatScores).text = scores.size.toString()
                findViewById<TextView>(R.id.tvStatMatches).text = allGroups.size.toString()
                scanStatus.text = "Tarama bitti • ${goodSources.size}/${repo.sourceCount} kaynak\nMaçkolik: bülten okunuyor…"

                // KRİTİK: Maçkolik isteği ayrı, kontrolsüz bir scope.launch içinde değil.
                // Aynı tarama coroutine'i içinde bekleniyor; böylece sonuç gelmeden
                // tarama tamamlandı durumu gösterilmiyor ve UI güncellemesi kaybolmuyor.
                try {
                    val result = withContext(Dispatchers.IO) { mackolikOdds.fetchToday() }

                    if (runId != scanGeneration) return@launch

                    val oddsMap = result.matches.associateBy {
                        MatchMerger.key(it.homeTeam, it.awayTeam)
                    }

                    allGroups = allGroups.map { group ->
                        val exact = oddsMap[MatchMerger.key(group.homeTeam, group.awayTeam)]
                            ?: result.matches.firstOrNull {
                                MatchMerger.isSameTeam(it.homeTeam, group.homeTeam) &&
                                    MatchMerger.isSameTeam(it.awayTeam, group.awayTeam)
                            }

                        if (exact != null) {
                            group.copy(odds = exact.odds, oddsSource = "Maçkolik")
                        } else {
                            group
                        }
                    }

                    adapter.submitList(allGroups)
                    val foundOdds = allGroups.count { it.odds != null }

                    scanStatus.text = if (result.error == null) {
                        "Tarama tamamlandı • ${goodSources.size}/${repo.sourceCount} kaynak\n" +
                            "Maçkolik: $foundOdds/${allGroups.size} eşleşme • " +
                            "${result.matches.size} oran • ${result.parsedRows}/${result.rowCount} satır • HTTP ${result.httpCode}\n" +
                            "Örnek: ${result.sample}"
                    } else {
                        "Tarama tamamlandı • ${goodSources.size}/${repo.sourceCount} kaynak\n" +
                            "Maçkolik: HATA ${result.error}"
                    }
                } catch (e: Exception) {
                    scanStatus.text =
                        "Tarama tamamlandı • ${goodSources.size}/${repo.sourceCount} kaynak\n" +
                            "Maçkolik: HATA ${e.javaClass.simpleName}"
                }
            } catch (e: Exception) {
                scanStatus.text = "Tarama tamamlanamadı: ${e.javaClass.simpleName}"
            } finally {
                setScanningUi(false)
            }
        }
    }

    private fun showLastFive(teamName: String) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("$teamName • Son 5 Maç")
            .setMessage("Son maçlar yükleniyor…")
            .setNegativeButton("KAPAT", null)
            .create()
        dialog.show()

        scope.launch {
            val matches = withContext(Dispatchers.IO) { sofaScore.getLastFive(teamName) }
            if (isFinishing || isDestroyed) return@launch
            val message = if (matches.isEmpty()) {
                "SofaScore'dan son 5 maç verisi alınamadı."
            } else {
                buildString {
                    matches.forEach { m ->
                        val venue = if (m.isHome) "E" else "D"
                        append(m.date)
                        append("  •  ")
                        append(venue)
                        append("  ")
                        append(m.result)
                        append("  ")
                        append(m.score)
                        append("  ")
                        append(m.opponent)
                        append("\n")
                    }
                    append("\nG = Galibiyet   B = Beraberlik   M = Mağlubiyet")
                }
            }
            dialog.setMessage(message)
        }
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        scanStatus.visibility = View.VISIBLE
        if (active) {
            scanStatus.text = "Kaynaklar taranıyor…"
        }
    }

    private fun sourceLabel(source: String): String = when (source.trim().lowercase()) {
        "fp.com" -> "cio1"
        "predictz" -> "cio2"
        "windrawwin" -> "cio3"
        "soccerseer" -> "cio4"
        "dailysports" -> "cio5"
        "cio1", "cio2", "cio3", "cio4", "cio5" -> source.trim().lowercase()
        else -> source.trim().lowercase()
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
