CioScore v0.11.0 — Maçkolik 1X2

VERİLEN TEST SONUCU
- Maçkolik arsiv2.mackolik.com/Iddaa-Programi Android OkHttp ile HTTP 200 döndü.
- HTML yaklaşık 686 KB geldi.
- Cagliari ve Lecce bulundu.
- MS1 1.86 / MSX 2.84 / MS2 3.50 bulundu.

YENİ MİMARİ
- Flashscore 161 ayrı istekli odds taraması kaldırıldı.
- Maçkolik İddaa Programı TEK HTTP GET ile okunuyor.
- HTML içindeki maç satırları parse edilerek MS1 / X / MS2 map'e alınıyor.
- CioScore maçları MatchMerger fuzzy eşleştirmesi ile Maçkolik maçlarına bağlanıyor.
- Bulunan oranlar kartlara "Maçkolik • MS 1X2" olarak yazılıyor.
- Durum satırında "Maçkolik: bulunan X/Y oran • bülten Z maç" gösteriliyor.

GITHUB
1) ZIP'i repoya yükle.
2) Mevcut Actions workflow'unun bu ZIP'i açtığından emin ol.
3) Commit/push yap.
4) Actions -> Build Android APK -> başarılı build -> artifact APK.
5) APK'yı telefona kur.
6) BUGÜNÜ TARA'ya bas.

İLK TEST
