CioScore CP LOGO FIX

This patch changes only the launcher identity:
- Application label: CioScore
- android:icon: @mipmap/ic_launcher
- android:roundIcon: @mipmap/ic_launcher_round
- All density launcher PNGs are the CP logo.
- Legacy adaptive v26 launcher XMLs were removed to avoid resource-resolution ambiguity.
- CP source logo remains at res/drawable-nodpi/cp_logo.png.

The football sources, Mackolik odds parser, matching and UI logic were not intentionally changed.
