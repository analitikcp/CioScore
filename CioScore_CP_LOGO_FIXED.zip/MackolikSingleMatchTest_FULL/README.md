CioScore v0.9.6 - Flashscore 1X2 odds

AiScore odds enrichment removed. Flashscore is used for MS 1 / MS X / MS 2. The core scan is independent and odds are streamed into cards in the background.
