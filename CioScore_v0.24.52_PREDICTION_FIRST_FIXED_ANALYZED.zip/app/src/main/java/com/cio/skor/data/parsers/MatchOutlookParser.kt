package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** MatchOutlook parser for the current compact DOM: "Home vs AwayResult: H-A". */
class MatchOutlookParser : BaseParser("MatchOutlook") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // The live page currently renders Result directly adjacent to the away team
        // in text (e.g. "Noah vs FC VanResult: 2-0"). Do not require whitespace.
        for (node in doc.select("body *")
            .filter { hasNumericResult(it.text()) && Regex("(?i)\\bvs\\b").containsMatchIn(clean(it.text())) }
            .sortedBy { it.text().length }) {
            parseNode(node)?.let { out[it.matchKey] = it }
            if (out.size >= 250) break
        }

        // Some deployments render the same cards as table-like rows rather than
        // a literal "vs Result:" text run. Recover HOME | SCORE | AWAY rows too.
        if (out.isEmpty()) {
            for (row in doc.select("tr")) {
                val cells = row.select("th, td").map { clean(it.text()) }.filter { it.isNotBlank() }
                val scoreIndex = cells.indexOfFirst { scoreRegex.matches(it.trim()) }
                if (scoreIndex <= 0 || scoreIndex >= cells.lastIndex) continue
                val score = score(cells[scoreIndex]) ?: continue
                val home = team(cells[scoreIndex - 1])
                val away = team(cells[scoreIndex + 1])
                if (!valid(home, away)) continue
                val model = ScoreModel(home, away, score, source)
                out[model.matchKey] = model
                if (out.size >= 250) break
            }
        }

        // Text-only fallback: parse compact fixture/result records from the body.
        if (out.isEmpty()) {
            val body = clean(doc.body()?.text().orEmpty())
            val compact = Regex("(?i)([A-Za-zÀ-ÿ0-9.'’&()/_-]{2,}(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/_-]{2,}){0,8})\\s+vs\\s+([A-Za-zÀ-ÿ0-9.'’&()/_-]{2,}(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/_-]{2,}){0,8})\\s*Result\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})")
            for (m in compact.findAll(body)) {
                build(m.groupValues[1], m.groupValues[2], "${m.groupValues[3]}-${m.groupValues[4]}")?.let { out[it.matchKey] = it }
            }
        }

        // Anchor/ancestor fallback for DOMs where fixture and Result are split.
        if (out.isEmpty()) {
            for (link in doc.select("a[href]")) {
                val fixture = splitFixture(clean(link.text())) ?: continue
                var current: Element? = link
                repeat(10) {
                    val n = current ?: return@repeat
                    val score = extractResult(clean(n.text()))
                    if (score != null) {
                        build(fixture.first, fixture.second, score)?.let { out[it.matchKey] = it }
                        return@repeat
                    }
                    current = n.parent()
                }
            }
        }
        return out.values.toList()
    }

    private fun parseNode(node: Element): ScoreModel? {
        val text = clean(node.text())
        val score = extractResult(text) ?: return null
        val fixture = splitFixture(text.substring(0, Regex("(?i)Result\\s*:").find(text)?.range?.first ?: text.length).trim())
            ?: return null
        return build(fixture.first, fixture.second, score)
    }

    private fun hasNumericResult(text: String): Boolean =
        Regex("(?i)Result\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b").containsMatchIn(clean(text))

    private fun extractResult(text: String): String? = Regex(
        "(?i)Result\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun splitFixture(raw: String): Pair<String, String>? {
        val text = clean(raw)
        val match = Regex("(?i)^(.+?)\\s+vs\\s+(.+)$").find(text) ?: return null
        val home = team(match.groupValues[1])
        val away = team(match.groupValues[2])
        return home to away
    }

    private fun build(homeRaw: String, awayRaw: String, predictedScore: String): ScoreModel? {
        val home = team(homeRaw).replace(Regex("(?i)^(?:yesterday|tomorrow)\\s+"), "")
        val away = team(awayRaw)
        if (!valid(home, away)) return null
        return ScoreModel(homeTeam = home, awayTeam = away, predictedScore = predictedScore, source = source)
    }
}
