package com.cio.skor

import kotlin.math.roundToInt
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.DropReason
import com.cio.skor.data.UnmatchedDiagnosticItem
import com.cio.skor.data.UnmatchedReason
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore by lazy { SofaScoreService(applicationContext) }
    private val oddsPanelService by lazy { com.cio.skor.data.OddsPanelService(applicationContext) }
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var iddaaBulletinButton: Button
    private lateinit var otherMatchesButton: Button
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    // Bookmaker odds use the existing, known-good SofaScoreService path.
    // Requests are serialized so a bulletin with many matches does not fire
    // dozens of network lookups at once.
    private val oddsQueue = ArrayDeque<Pair<String, String>>()
    private val oddsQueuedKeys = mutableSetOf<String>()
    private var oddsQueueRunning = false
    private val oddsRetryCount = mutableMapOf<String, Int>()

    private fun oddsKey(home: String, away: String): String =
        "${MatchMerger.normalizeTeamName(home)}::${MatchMerger.normalizeTeamName(away)}"

    private fun enqueueOdds(home: String, away: String) {
        val key = oddsKey(home, away)
        if (!oddsQueuedKeys.add(key)) return
        oddsQueue.addLast(home to away)
        processNextOdds()
    }

    private fun processNextOdds() {
        if (oddsQueueRunning || oddsQueue.isEmpty()) return
        val next = oddsQueue.removeFirst()
        val key = oddsKey(next.first, next.second)
        oddsQueueRunning = true

        scope.launch {
            val rows = runCatching {
                withContext(Dispatchers.IO) {
                    sofaScore.fetchBookmakerOdds(next.first, next.second)
                }
            }.getOrDefault(emptyList())

            adapter.setExternalOdds(next.first, next.second, rows)
            oddsQueuedKeys.remove(key)
            oddsQueueRunning = false

            // A transient CDN/DNS/HTTP miss must not leave the card at "...".
            // Retry a failed Bet365 lookup twice with a short backoff; after the
            // fallback sources are exhausted we stop rather than creating a loop.
            if (rows.isEmpty()) {
                val attempt = (oddsRetryCount[key] ?: 0) + 1
                oddsRetryCount[key] = attempt
                if (attempt <= 2) {
                    scope.launch {
                        delay(2500L)
                        enqueueOdds(next.first, next.second)
                    }
                }
            } else {
                oddsRetryCount.remove(key)
            }
            processNextOdds()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        val bottomSystemSpacer = findViewById<View>(R.id.bottomSystemSpacer)

        // STRONG BOTTOM-SAFE-AREA FIX
        // Android 15+/targetSdk 36 uses edge-to-edge. The navigation surface may
        // be transparent, so merely padding the RecyclerView can still leave the
        // final card visually underneath the system buttons. We reserve a real
        // layout area AFTER the RecyclerView. That area is never occupied by a
        // match card, so the last card can always be scrolled completely above
        // the navigation bar. Keep the RecyclerView padding as a secondary
        // safeguard for gesture-navigation devices.
        val baseRecyclerBottomPadding = recyclerView.paddingBottom
        val minimumBottomSafeArea = dp(104)
        ViewCompat.setOnApplyWindowInsetsListener(recyclerView) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                baseRecyclerBottomPadding + dp(16)
            )
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomSystemSpacer) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            val safeHeight = maxOf(minimumBottomSafeArea, navigationBottom + dp(24))
            view.layoutParams = view.layoutParams.apply { height = safeHeight }
            view.requestLayout()
            insets
        }
        ViewCompat.requestApplyInsets(recyclerView)
        ViewCompat.requestApplyInsets(bottomSystemSpacer)

        recyclerView.layoutManager = LinearLayoutManager(this)
        // 94+ official fixtures are valid. Disable change animations and keep
        // RecyclerView work predictable so a large bulletin cannot stall the UI.
        recyclerView.setHasFixedSize(false)
        recyclerView.itemAnimator = null
        recyclerView.setItemViewCacheSize(4)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            },
            onExternalOddsRequest = { home, away -> enqueueOdds(home, away) },
            onOddsClick = { match -> showOddsPanel(match) }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        iddaaBulletinButton = findViewById(R.id.btnIddaaBulletin)
        otherMatchesButton = findViewById(R.id.btnOtherMatches)
        iddaaBulletinButton.setOnClickListener {
            adapter.setBulletinFilter(ScoreAdapter.BulletinFilter.IDDAA_BULLETIN)
            updateBulletinFilterButtons()
        }
        otherMatchesButton.setOnClickListener {
            adapter.setBulletinFilter(ScoreAdapter.BulletinFilter.OTHER_MATCHES)
            updateBulletinFilterButtons()
        }
        updateBulletinFilterButtons()
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener { showDiagnostics() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun updateBulletinFilterButtons() {
        val iddaaSelected = adapter.getBulletinFilter() == ScoreAdapter.BulletinFilter.IDDAA_BULLETIN
        val iddaaCount = allGroups.count { it.isIddaaBulletinMatch }
        val otherCount = allGroups.size - iddaaCount
        iddaaBulletinButton.text = "İDDAA BÜLTENİ ($iddaaCount)"
        otherMatchesButton.text = "DİĞER MAÇLAR ($otherCount)"
        iddaaBulletinButton.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (iddaaSelected) android.graphics.Color.rgb(0, 121, 107) else android.graphics.Color.rgb(100, 116, 139)
        )
        otherMatchesButton.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (!iddaaSelected) android.graphics.Color.rgb(0, 121, 107) else android.graphics.Color.rgb(100, 116, 139)
        )
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all configured score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all prediction sources before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, source ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Kaynaklar: $completed/${repo.sourceCount} — $source"
                            }
                        }
                    }
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    scanStatus.text = "Tüm tahmin kaynakları başarısız oldu."
                    Toast.makeText(this@MainActivity, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else ""

                val rawScores = results.sumOf { it.scores.size }

                // PREDICTION-FIRST HARD RULE: every parsed provider prediction is eligible
                // for the UI. Iddaa is enrichment only and is never a source gate.
                val parsedPredictionScores = results.flatMap { result: SourceResult -> result.scores }
                val displayableScores = parsedPredictionScores.filter(::isDisplayable)
                val invalidScores = rawScores - displayableScores.size

                // Diagnostic only: count prediction records after the displayability filter.
                runCatching {
                    val diagnosticCounts = parsedPredictionScores.groupingBy { it.source }.eachCount()
                    com.cio.skor.data.PipelineDiagnostics.log(
                        sourceCounts = diagnosticCounts,
                        rawPredictions = parsedPredictionScores.size
                    )
                }

                // Iddaa is fetched only for optional enrichment. It MUST NOT gate, reject,
                // or shrink the provider prediction set, regardless of bulletin window.

                // Official Iddaa enrichment uses the FULL official football bulletin.
                // HT/FT availability is only a market property; it must NEVER restrict
                // the official fixture candidate pool used by GlobalFixtureMatcher.
                // The main scan tolerates a slower official response so the full bulletin
                // has time to arrive before matching.
                val officialResult = try {
                    withTimeoutOrNull(25_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) return@launch

                // No official fixture pool is used as a gate. Provider predictions remain
                // displayable even when the official bulletin has no matching fixture.

                // Deduplicate only true provider duplicates. Team names + score + source
                // are NOT a sufficient identity: the same clubs can legitimately play more
                // than once in the bulletin. Prefer the provider's match ID; otherwise keep
                // kickoff/date/time/competition metadata in the fallback key.
                val dedupedScores: List<ScoreModel> = displayableScores.distinctBy { prediction ->
                    val home = MatchMerger.normalizeTeamName(prediction.homeTeam)
                    val away = MatchMerger.normalizeTeamName(prediction.awayTeam)
                    val source = prediction.source.trim().lowercase()
                    val providerId = prediction.sourceMatchId.trim()
                    if (providerId.isNotBlank()) {
                        "ID|$source|$providerId"
                    } else {
                        "META|$source|$home|$away|${prediction.predictedScore.trim()}|" +
                            "${prediction.matchTimestamp}|${prediction.matchDate.trim()}|" +
                            "${prediction.matchTime.trim()}|${prediction.competitionName.trim().lowercase()}"
                    }
                }

                // IMPORTANT: there is NO Iddaa prediction gate anymore.
                // We only load the official bulletin so it can optionally enrich
                // prediction cards with MS1/MSX/MS2 and HT/FT data.
                val officialInBulletinWindow = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    // Use the service's already merged official fixture pool. Reusing
                    // allParsedMatches here would re-introduce duplicate official records
                    // that the service intentionally collapsed before the identity graph.
                    officialResult.matches.filter { official ->
                        official.matchTimestamp >= officialResult.bulletinStartMillis &&
                            official.matchTimestamp < officialResult.bulletinEndMillis
                    }
                } else {
                    emptyList()
                }

                // PREDICTION-FIRST DISPLAY: never let the official Iddaa bulletin
                // determine whether a provider prediction exists in the UI. The official
                // 06:00-06:00 window has already been applied inside IddaaMarketService
                // to the official feed only; it is deliberately NOT applied to predictions.
                // The previous implementation still routed every prediction through
                // GlobalFixtureMatcher before building cards; that collapsed the 117
                // provider records into only 4 unified fixtures in the APK.
                // Build the display fixture set directly from provider predictions.
                // Iddaa is consulted afterwards, only as optional enrichment.
                val preparedGroups = withContext(Dispatchers.Default) {
                    buildPredictionFirstGroups(
                        predictions = dedupedScores,
                        officialMatches = officialInBulletinWindow
                    )
                }

                val iddaaMatchedForUi = preparedGroups.count {
                    it.iddaaMs1 != null || it.iddaaMsX != null || it.iddaaMs2 != null
                }
                val predictionNotInIddaaDetails = preparedGroups
                    .filter { it.iddaaMs1 == null && it.iddaaMsX == null && it.iddaaMs2 == null }
                    .flatMap { group ->
                        group.predictions.map { prediction ->
                            "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | IDDAA=fixture-yok"
                        }
                    }
                // IMPORTANT: the 06:00-06:00 rule belongs ONLY to the official İddaa
                // bulletin. Prediction providers and SofaScore/Flashscore-derived odds
                // are never filtered by that window. This diagnostic list only records
                // predictions whose own timestamp falls outside the official bulletin;
                // it NEVER removes them from preparedGroups or the UI.
                val predictionOutsideBulletinDetails = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    dedupedScores.filter { prediction ->
                        val ts = prediction.matchTimestamp
                        ts > 0L && (
                            ts < officialResult.bulletinStartMillis ||
                                ts >= officialResult.bulletinEndMillis
                            )
                    }.map { prediction ->
                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | " +
                            "IDDAA_BULLETIN_WINDOW_DISJOINT"
                    }
                } else {
                    emptyList()
                }

                ObservabilityBus.publish(
                    ScanTrace(
                        // Build parser health reports inline. This is diagnostic-only and
                        // never filters, rejects, or removes prediction matches.
                        parserReports = results.map { result ->
                            val status = when {
                                result.error == null && result.httpCode in 200..299 && result.scores.isNotEmpty() ->
                                    ParserStatus.HEALTHY
                                result.httpCode in 200..299 && result.scores.isEmpty() ->
                                    ParserStatus.DOM_CHANGED
                                else ->
                                    ParserStatus.FAILED
                            }
                            ParserHealthReport(
                                sourceName = result.source,
                                httpCode = result.httpCode,
                                rawHtmlBytes = result.rawHtmlBytes,
                                parsedCount = result.scores.size,
                                durationMs = result.durationMs,
                                status = status,
                                errorMessage = result.error
                            )
                        },
                        stageMetrics = linkedMapOf(
                            PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                            PipelineStage.PARSER to rawScores,
                            PipelineStage.NORMALIZATION to dedupedScores.size,
                            PipelineStage.IDENTITY to preparedGroups.size,
                            PipelineStage.CONFIDENCE to preparedGroups.count { it.predictions.size >= 2 },
                            PipelineStage.MERGE to preparedGroups.size,
                            PipelineStage.IDDAA_ENRICHMENT to iddaaMatchedForUi,
                            PipelineStage.UI to preparedGroups.size
                        ),
                        // Only genuinely invalid provider records are drops.
                        // A prediction missing from Iddaa is explicitly NOT a drop.
                        dropReasons = buildList {
                            if (invalidScores > 0) {
                                add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                            }
                        },
                        totalDurationMs = System.currentTimeMillis() - scanStartMs,
                        unmatchedOfficialDiagnostics = emptyList(),
                        officialFeedDiagnostics = officialResult?.let { result ->
                            com.cio.skor.data.OfficialFeedDiagnostics(
                                httpEvents = result.httpEvents,
                                httpMarketConfig = result.httpMarketConfig,
                                rawEventCount = result.rawEventCount,
                                parsedEventCount = result.parsedEventCount,
                                timestampedEventCount = result.timestampedEventCount,
                                bulletinEventCountBeforeMerge = result.bulletinEventCountBeforeMerge,
                                bulletinDate = result.bulletinDate,
                                bulletinWindow = result.bulletinWindow,
                                mergedFixtureCount = result.mergedFixtureCount,
                                marketMatches = result.marketMatches,
                                error = result.error,
                                dateDistribution = result.dateDistribution,
                                sampleFixtures = result.sampleFixtures
                            )
                        },
                        predictionFixtureCount = preparedGroups.size,
                        officialMatchedPredictionCount = iddaaMatchedForUi,
                        officialOnlyFixtureCount = 0,
                        // These two fields are enrichment diagnostics only. They do NOT
                        // represent dropped predictions.
                        predictionNotInIddaaCount = predictionNotInIddaaDetails.size,
                        predictionNotInIddaaDetails = predictionNotInIddaaDetails.toList(),
                        predictionNotInIddaaBySource = predictionNotInIddaaDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        predictionOutsideBulletinCount = predictionOutsideBulletinDetails.size,
                        predictionOutsideBulletinDetails = predictionOutsideBulletinDetails.toList(),
                        predictionOutsideBulletinBySource = predictionOutsideBulletinDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount()
                    )
                )

                allGroups = preparedGroups
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(preparedGroups)
                recyclerView.post {
                    recyclerView.visibility = View.VISIBLE
                    recyclerView.invalidate()
                }
                scanStatus.text = "${allGroups.size} maç • Teşhis: 🔍"
                updateBulletinFilterButtons()
                focusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                scanStatus.text = "Tarama hatası: ${e.javaClass.simpleName}"
                Toast.makeText(
                    this@MainActivity,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) setScanningUi(false)
            }
        }
    }


    /** Prediction-first UI grouping. Iddaa is enrichment only and never a gate. */
    private fun buildPredictionFirstGroups(
        predictions: List<ScoreModel>,
        officialMatches: List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>
    ): List<MatchGroup> {
        // IMPORTANT: never regroup predictions with a simple home||away key here.
        // That bypassed GlobalFixtureMatcher and caused multilingual names or
        // damaged home names to split an otherwise identical fixture into cards.
        // The matcher is now the single source of truth for provider clustering.
        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        fun findScoreModel(record: GlobalFixtureMatcher.Record): ScoreModel? =
            predictions.firstOrNull { p ->
                p.source.equals(record.source, ignoreCase = true) &&
                    (record.sourceMatchId.isBlank() || p.sourceMatchId == record.sourceMatchId) &&
                    p.homeTeam == record.homeTeam &&
                    p.awayTeam == record.awayTeam &&
                    p.predictedScore == record.predictedScore
            }

        fun officialFor(records: List<GlobalFixtureMatcher.Record>): com.cio.skor.data.IddaaMarketService.OpenedMarketMatch? {
            var best: Pair<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch, Double>? = null
            for (record in records) {
                for (o in officialMatches) {
                    val officialRecord = GlobalFixtureMatcher.Record(
                        homeTeam = o.homeTeam, awayTeam = o.awayTeam, source = "IDDAA",
                        sourceMatchId = o.matchId, matchTimestamp = o.matchTimestamp,
                        matchDate = o.matchDate, matchTime = o.matchTime,
                        competitionName = o.competitionName, official = o
                    )
                    val evidence = GlobalFixtureMatcher.score(record, officialRecord)
                    if (evidence.accepted && (best == null || evidence.confidence > best!!.second)) {
                        best = o to evidence.confidence
                    }
                }
            }
            return best?.first
        }

        // CRITICAL INVARIANT: Iddaa is enrichment only. Provider predictions
        // always create a card, while a successfully matched Iddaa fixture only
        // enriches that card with official names/odds/bulletin state.
        return unified.mapNotNull { match ->
            val cardPredictions = match.predictionRecords
                .mapNotNull(::findScoreModel)
                .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                .distinctBy { it.source.trim().lowercase() }
            if (cardPredictions.isEmpty()) return@mapNotNull null

            val primary = cardPredictions.first()
            val official = officialFor(match.predictionRecords)
            MatchGroup(
                isIddaaBulletinMatch = official != null,
                homeTeam = official?.homeTeam ?: match.mainHomeTeam.ifBlank { primary.homeTeam },
                awayTeam = official?.awayTeam ?: match.mainAwayTeam.ifBlank { primary.awayTeam },
                predictions = cardPredictions,
                iddaaProgramUrl = official?.let { buildIddaaProgramUrl(it.matchDate) },
                iddaaMs1 = official?.ms1, iddaaMsX = official?.msX, iddaaMs2 = official?.ms2,
                htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                hasHtFt = official?.hasHtFt ?: false,
                matchTimestamp = official?.matchTimestamp?.takeIf { it > 0L }
                    ?: match.predictionRecords.maxOfOrNull { it.matchTimestamp }?.takeIf { it > 0L }
                    ?: primary.matchTimestamp,
                displayTime = official?.matchTime?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchTime.isNotBlank() && it.matchTime != "--:--" }?.matchTime
                    ?: primary.matchTime,
                displayDate = official?.matchDate?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchDate.isNotBlank() }?.matchDate
                    ?: primary.matchDate,
                homeTeamId = null, awayTeamId = null
            )
        }.sortedWith(
            compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                .thenBy { it.homeTeam.lowercase() }
                .thenBy { it.awayTeam.lowercase() }
        )
    }

    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    /**
     * First-ZIP style odds panel, now embedded in every match card via the
     * ORANLAR button. It is intentionally independent from the main-card
     * odds queue: opening one panel only requests that single fixture.
     */
    private fun showOddsPanel(match: MatchGroup) {
        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        fun label(text: String, size: Float = 13f, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF101828.toInt())
                if (bold) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(4), 0, dp(4))
            }

        fun addRow(row: com.cio.skor.data.OddsPanelService.OddsRow) {
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (row.primary) 0xFFF0FDF4.toInt() else 0xFFF8FAFC.toInt())
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(1), if (row.primary) 0xFFBBE7CA.toInt() else 0xFFE4E7EC.toInt())
                }
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            }
            container.addView(TextView(this).apply {
                text = if (row.primary) "★ ${row.bookmaker}" else row.bookmaker
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f)
            })
            listOf(row.ms1, row.msX, row.ms2).forEach { value ->
                container.addView(TextView(this).apply {
                    text = value
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setTextColor(0xFF155EEF.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
            }
            root.addView(container)
        }

        root.addView(label("ORANLAR", 20f, true))
        root.addView(label("${match.homeTeam}  -  ${match.awayTeam}", 13f, true))
        root.addView(label("MS1 / MSX / MS2", 11f))

        oddsPanelService.iddaaRow(match.iddaaMs1, match.iddaaMsX, match.iddaaMs2)?.let(::addRow)

        val loading = label("Yurtdışı oranlar yükleniyor…", 12f)
        root.addView(loading)
        dialog.setContentView(root)
        dialog.show()

        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val bet365 = runCatching {
                    oddsPanelService.fetchBet365(match.homeTeam, match.awayTeam)
                }.getOrNull()
                val tipster = runCatching {
                    oddsPanelService.fetchTipsterArea(
                        match.homeTeam,
                        match.awayTeam,
                        match.displayDate
                    )
                }.getOrDefault(emptyList())
                bet365 to tipster
            }

            if (!dialog.isShowing) return@launch
            root.removeView(loading)

            val bet365 = result.first
            val tipster = result.second
            if (bet365 != null) {
                addRow(bet365)
                root.addView(label("Kaynak: Bet365 fallback zinciri", 10f))
            } else {
                root.addView(label("Bet365 oranı bu maç için bulunamadı.", 12f))
            }

            if (tipster.isNotEmpty()) {
                tipster.forEach(::addRow)
                root.addView(label("Kaynak: TipsterArea · Standard 1X2", 10f))
            } else {
                root.addView(label("TipsterArea oranları bu maç için bulunamadı.", 12f))
            }
        }
    }

    private fun dp(value: Int): Int =
        android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    companion object {
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun diagnosticReportText(trace: ScanTrace): String {
        val sb = StringBuilder()
        sb.appendLine("SCAN DIAGNOSTIC PANEL [#${trace.scanId}]")
        sb.appendLine("MATCHER_CANONICAL_PIPELINE: 0.25.00-PREDICTION-FIRST")
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        sb.appendLine("SÜRE: ${trace.totalDurationMs} ms | DURUM: $successful/${trace.parserReports.size} kaynak")
        sb.appendLine("PIPELINE TRACE")
        trace.stageMetrics.forEach { (stage, count) -> sb.appendLine("• ${stage.name} : $count") }
        sb.appendLine("MAÇ KÜMESİ / İDDAA ZENGİNLEŞTİRME")
        sb.appendLine("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        sb.appendLine("• İddaa ile zenginleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        sb.appendLine("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        sb.appendLine("• İddaa ile eşleşmeyen tahmin (ATILMADI): ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_NOT_IN_IDDAA KAYNAK DAĞILIMI:")
            trace.predictionNotInIddaaBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            sb.appendLine("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        sb.appendLine("• İddaa dışında kalan tahmin (ATILMADI): ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_OUTSIDE_06_00 KAYNAK DAĞILIMI:")
            trace.predictionOutsideBulletinBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            sb.appendLine("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        trace.officialFeedDiagnostics?.let { f ->
            sb.appendLine("İDDAA RESMİ FEED TEŞHİSİ")
            sb.appendLine("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            sb.appendLine("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            sb.appendLine("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            sb.appendLine("• RAW EVENTS: ${f.rawEventCount}")
            sb.appendLine("• PARSED EVENTS: ${f.parsedEventCount}")
            sb.appendLine("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            sb.appendLine("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            sb.appendLine("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            sb.appendLine("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                sb.appendLine("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { sb.appendLine("   - $it") }
            }
            if (!f.error.isNullOrBlank()) sb.appendLine("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                sb.appendLine("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { sb.appendLine("   - $it") }
            }
        } ?: sb.appendLine("• İDDAA FEED SONUCU: alınamadı")
        sb.appendLine("PARSER HEALTH")
        trace.parserReports.forEach { r ->
            sb.appendLine("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}")
        }
        sb.appendLine("DROPPED ITEMS")
        if (trace.dropReasons.isEmpty()) sb.appendLine("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            sb.appendLine("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        sb.appendLine("OFFICIAL NOT MATCHED DETAYLARI (${trace.unmatchedOfficialDiagnostics.size})")
        trace.unmatchedOfficialDiagnostics.forEachIndexed { index, item ->
            sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway}")
            if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway}")
            } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
            sb.appendLine("   TAHMİN CANONICAL: H=${item.homeCanonicalPrediction.ifBlank { "-" }} | A=${item.awayCanonicalPrediction.ifBlank { "-" }}")
            sb.appendLine("   İDDAA ADAY CANONICAL: H=${item.homeCanonicalOfficial.ifBlank { "-" }} | A=${item.awayCanonicalOfficial.ifBlank { "-" }}")
            sb.appendLine("   SIM: H=${"%.2f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.2f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.2f".format(java.util.Locale.US, item.combinedSimilarity)}")
            sb.appendLine("   TEŞHİS: ${diagnosticReasonLabel(item.probableReason)}")
        }
        return sb.toString()
    }

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SCAN DIAGNOSTIC PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyButton = Button(this).apply {
            text = "📋 KOPYALA"
            textSize = 11f
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("CioScore Scan Diagnostic", diagnosticReportText(trace)))
                Toast.makeText(this@MainActivity, "Teşhis raporu panoya kopyalandı.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(title)
        header.addView(copyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(header)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        fun addText(text: String, bold: Boolean = false, size: Float = 14f) {
            box.addView(TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 4, 0, 4)
            })
        }

        addText("MATCHER CANONICAL PIPELINE: ${com.cio.skor.data.GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}", true, 13f)
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        addText("SÜRE: ${trace.totalDurationMs} ms  •  DURUM: $successful/${trace.parserReports.size} kaynak", true)
        addText("PIPELINE TRACE", true, 16f)
        trace.stageMetrics.forEach { (stage, count) -> addText("• ${stage.name.padEnd(20)} : $count") }

        addText("MAÇ KÜMESİ / İDDAA ZENGİNLEŞTİRME", true, 16f)
        addText("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        addText("• İddaa ile zenginleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        addText("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        addText("• İddaa ile eşleşmeyen tahmin (ATILMADI): ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            addText("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        addText("• İddaa dışında kalan tahmin (ATILMADI): ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            addText("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        trace.officialFeedDiagnostics?.let { f ->
            addText("İDDAA RESMİ FEED TEŞHİSİ", true, 16f)
            addText("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            addText("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            addText("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            addText("• RAW EVENTS: ${f.rawEventCount}")
            addText("• PARSED EVENTS: ${f.parsedEventCount}")
            addText("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            addText("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            addText("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            addText("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                addText("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { addText("   - $it", false, 12f) }
            }
            if (!f.error.isNullOrBlank()) addText("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                addText("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { addText("   - $it", false, 12f) }
            }
        } ?: addText("• İDDAA FEED SONUCU: alınamadı")
        addText("PARSER HEALTH", true, 16f)
        trace.parserReports.forEach { r -> addText("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}") }
        addText("DROPPED ITEMS", true, 16f)
        if (trace.dropReasons.isEmpty()) addText("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            addText("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.show()
    }

    private fun diagnosticReasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "🟡 ALIAS_STEMMING_PROBLEM"
        UnmatchedReason.DATE_WINDOW_MISMATCH -> "🔴 DATE_WINDOW_MISMATCH"
        UnmatchedReason.LOW_NAME_SIMILARITY -> "🟠 LOW_NAME_SIMILARITY"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "⚫ NO_OFFICIAL_CANDIDATE"
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        if (active) scanStatus.text = "${repo.sourceCount} kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!ScoreModel.hasRenderablePrediction(x.predictedScore)) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
