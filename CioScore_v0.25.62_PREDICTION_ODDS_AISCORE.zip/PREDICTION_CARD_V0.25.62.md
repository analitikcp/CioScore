# CioScore v0.25.62 — Prediction Card + AiScore Odds Bridge

- Main card UI remains the compact v0.25.60 design.
- Restored the four real prediction-source scores on each card: FP.com, PredictZ, WinDrawWin, DailySports.
- Prediction values come from the existing parser/merge pipeline; missing source data renders as `—`, never synthesized.
- AiScore Bet365 opening/closing remains independent from current Bet365 odds.
- AiScore live fixture URLs with a canonical match id are converted directly to the public `/match-.../<id>/odds` page before HTML parsing.
- No bookmaker source is used as a substitute for prediction scores.
