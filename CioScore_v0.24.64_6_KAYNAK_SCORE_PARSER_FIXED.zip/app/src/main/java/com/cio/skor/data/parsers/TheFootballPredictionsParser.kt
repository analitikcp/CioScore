package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * The Football Predictions exact-score list parser.
 *
 * The public page exposes each fixture as a link whose slug contains
 * `home-vs-away`, while the surrounding row contains kickoff time and the
 * predicted exact score. We deliberately use the fixture URL as identity
 * instead of trying to split the concatenated visible team text.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    private val fixtureHref = Regex("/([^/?#]+-vs-[^/?#]+-prediction[^/?#]*)", RegexOption.IGNORE_CASE)
    private val dateInSlug = Regex("date-(\\d{2}-\\d{2}-\\d{4})", RegexOption.IGNORE_CASE)
    private val gameId = Regex("game-id-([A-Za-z0-9_-]+)", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href]")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            if (!fixtureHref.containsMatchIn(href)) continue
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            val pair = splitFixture(slug) ?: continue

            // TFP renders the correct score as `2 - 1` outside the fixture link.
            // Do NOT use the generic loose score regex here: the same row contains
            // point percentages (e.g. 16 / 84), and broad ancestor text can mix rows.
            val row = nearestSingleScoreContainer(link) ?: continue
            val context = row.text().replace('\u00A0', ' ')
            val score = extractTfpCorrectScore(context) ?: continue
            val time = timeRegex.find(context)?.value ?: "--:--"
            val date = dateInSlug.find(slug)?.groupValues?.get(1)?.let(::toIsoDate).orEmpty()
            val id = gameId.find(slug)?.groupValues?.get(1).orEmpty()

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = id,
                matchDate = date,
                matchTime = time
            )
            val key = if (id.isNotBlank()) "ID|$id" else model.matchKey
            out[key] = model
        }
        return out.values.toList()
    }

    private val tfpCorrectScoreRegex = Regex("(?<!\\d)([0-9])\\s+-\\s+([0-9])(?!\\d)")

    private fun extractTfpCorrectScore(text: String): String? =
        tfpCorrectScoreRegex.findAll(text).toList().singleOrNull()?.let {
            "${it.groupValues[1]}-${it.groupValues[2]}"
        }

    private fun nearestSingleScoreContainer(link: org.jsoup.nodes.Element): org.jsoup.nodes.Element? {
        var current: org.jsoup.nodes.Element? = link.parent()
        repeat(7) {
            val element = current ?: return null
            val text = element.text().replace('\u00A0', ' ')
            if (tfpCorrectScoreRegex.findAll(text).count() == 1) return element
            current = element.parent()
        }
        return null
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val base = slug.replace(Regex("-prediction.*$", RegexOption.IGNORE_CASE), "")
        val marker = "-vs-"
        val idx = base.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(base.substring(0, idx))
        val away = slugWords(base.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun toIsoDate(value: String): String {
        val parts = value.split('-')
        return if (parts.size == 3) "${parts[2]}-${parts[1]}-${parts[0]}" else ""
    }
}
