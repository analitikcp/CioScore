package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** SureWinPredict daily correct-score page parser. */
class SureWinPredictParser : BaseParser("SureWinPredict") {

    private val matchPath = Regex("/match/([^/?#]+-vs-[^/?#]+?)(?:-\\d+-\\d+)?/(\\d{4}-\\d{2}-\\d{2})", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href*='/match/']")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val match = matchPath.find(href) ?: continue
            val fixtureSlug = match.groupValues[1]
            val date = match.groupValues[2]
            val pair = splitFixture(fixtureSlug) ?: continue

            // SureWinPredict wraps the entire fixture line (time, teams, probability,
            // correct score, odds) in the match <a>. Reading a broad ancestor can
            // accidentally pick a score/number belonging to another row.
            // The fixture link itself is therefore the primary score container.
            val linkText = link.text().replace('\u00A0', ' ')
            val row = link.closest("tr") ?: link.parent()?.parent()?.parent() ?: link.parent()
            val context = linkText.ifBlank { row?.text()?.replace('\u00A0', ' ') ?: "" }
            val scorePair = extractSureWinCorrectScore(linkText)
                ?: extractSureWinCorrectScoreFromSingleContainer(row?.text())
                ?: continue
            val predictedScore = "${scorePair.first}-${scorePair.second}"
            val time = timeRegex.find(context)?.value ?: "--:--"

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val sourceId = href.substringAfter("/match/").substringBefore('/').trim()
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = predictedScore,
                source = source,
                sourceMatchId = sourceId,
                matchDate = date,
                matchTime = time
            )
            out["ID|$sourceId"] = model
        }

        return out.values.toList()
    }

    private val sureWinScoreRegex = Regex("(?<!\\d)([0-9])\\s*-\\s*([0-9])(?!\\d)")

    private fun extractSureWinCorrectScore(text: String): Pair<Int, Int>? =
        sureWinScoreRegex.find(text)?.let { it.groupValues[1].toInt() to it.groupValues[2].toInt() }

    private fun extractSureWinCorrectScoreFromSingleContainer(text: String?): Pair<Int, Int>? {
        val value = text?.replace('\u00A0', ' ') ?: return null
        val matches = sureWinScoreRegex.findAll(value).toList()
        return if (matches.size == 1) {
            matches[0].groupValues[1].toInt() to matches[0].groupValues[2].toInt()
        } else null
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val marker = "-vs-"
        val idx = slug.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(slug.substring(0, idx))
        val away = slugWords(slug.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
