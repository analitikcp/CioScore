package com.cio.skor.data

import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

/** One normalized record from a single Turkish betting source. */
data class PopularBetItem(
    val homeTeam: String,
    val awayTeam: String,
    val prediction: String,
    val playCount: Long,
    val ratio: String,
    val source: String
)

private fun JSONObject.optStringTrim(key: String, default: String = ""): String =
    optString(key, default).trim()

private fun JSONObject.optLongFlexible(key: String, default: Long = 0L): Long {
    val value = opt(key) ?: return default
    return when (value) {
        is Number -> value.toLong()
        is String -> value.filter(Char::isDigit).toLongOrNull() ?: default
        else -> value.toString().filter(Char::isDigit).toLongOrNull() ?: default
    }
}

private fun JSONObject.optOdds(key: String): String {
    val value = opt(key) ?: return ""
    val number = when (value) {
        is Number -> value.toDouble()
        is String -> value.replace(',', '.').trim().toDoubleOrNull()
        else -> value.toString().replace(',', '.').trim().toDoubleOrNull()
    }
    return if (number != null && number > 0.0) String.format(Locale.US, "%.2f", number) else ""
}

class IddaaParser {
    fun parse(jsonResponse: String): List<PopularBetItem> = runCatching {
        val root = JSONObject(jsonResponse)
        val dataArray = root.optJSONArray("data") ?: root.optJSONArray("items") ?: return@runCatching emptyList()
        buildList {
            for (i in 0 until dataArray.length()) {
                val item = dataArray.optJSONObject(i) ?: continue
                val match = item.optJSONObject("match") ?: item.optJSONObject("event")
                val home = match?.optStringTrim("homeTeam")
                    ?: match?.optStringTrim("homeName")
                    ?: item.optStringTrim("homeTeam")
                val away = match?.optStringTrim("awayTeam")
                    ?: match?.optStringTrim("awayName")
                    ?: item.optStringTrim("awayTeam")
                val prediction = item.optStringTrim("predictionName", "Popüler tercih")
                val count = item.optLongFlexible("playedCount")
                val odds = item.optOdds("odds")
                if (home.isNotBlank() && away.isNotBlank()) {
                    add(PopularBetItem(home, away, prediction, count, odds, "İddaa"))
                }
            }
        }
    }.getOrDefault(emptyList())
}

class BilyonerParser {
    fun parse(jsonResponse: String): List<PopularBetItem> = runCatching {
        val root = JSONObject(jsonResponse)
        val events = root.optJSONArray("events") ?: root.optJSONArray("data") ?: return@runCatching emptyList()
        buildList {
            for (i in 0 until events.length()) {
                val obj = events.optJSONObject(i) ?: continue
                val home = obj.optStringTrim("homeName").ifBlank { obj.optStringTrim("homeTeamName") }
                val away = obj.optStringTrim("awayName").ifBlank { obj.optStringTrim("awayTeamName") }
                val selection = obj.optStringTrim("marketValue", "Popüler tercih")
                val playedCount = obj.optLongFlexible("couponCount")
                val odds = obj.optOdds("ratio")
                if (home.isNotBlank() && away.isNotBlank()) {
                    add(PopularBetItem(home, away, selection, playedCount, odds, "Bilyoner"))
                }
            }
        }
    }.getOrDefault(emptyList())
}

class NesineParser {
    fun parseHtml(htmlContent: String): List<PopularBetItem> =
        PopularBetHtmlHeuristics.parse(htmlContent, "Nesine")
}

class MisliParser {
    fun parse(jsonResponse: String): List<PopularBetItem> = runCatching {
        val root = JSONObject(jsonResponse)
        val bets = root.optJSONArray("data") ?: root.optJSONArray("bets") ?: root.optJSONArray("items")
            ?: return@runCatching emptyList()
        buildList {
            for (i in 0 until bets.length()) {
                val betObj = bets.optJSONObject(i) ?: continue
                val home = betObj.optStringTrim("homeTeamName").ifBlank { betObj.optStringTrim("homeName") }
                val away = betObj.optStringTrim("awayTeamName").ifBlank { betObj.optStringTrim("awayName") }
                val outcome = betObj.optStringTrim("outcomeName", "Popüler tercih")
                val played = betObj.optLongFlexible("totalPlayed")
                val odds = betObj.optOdds("rate")
                if (home.isNotBlank() && away.isNotBlank()) {
                    add(PopularBetItem(home, away, outcome, played, odds, "Misli"))
                }
            }
        }
    }.getOrDefault(emptyList())
}

/** Rendered-page fallback. Selectors are intentionally layered to survive SPA class changes. */
object PopularBetHtmlHeuristics {
    private val marketTokens = listOf(
        "MS 1", "MS X", "MS 2", "MAÇ SONUCU", "TOPLAM GOL", "ALT/ÜST", "ALT/ÜST 2.5",
        "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KARŞILIKLI GOL", "KG VAR", "KG YOK",
        "EV. GOL", "1.Y GOL", "1. Y GOL"
    )

    fun parse(html: String, source: String): List<PopularBetItem> {
        if (html.isBlank()) return emptyList()
        val doc = Jsoup.parse(html)
        val result = LinkedHashMap<String, PopularBetItem>()
        val selectors = listOf(
            "div.popular-bet-row", "tr.pop-table-row", "tr", 
            "[class*=popular-bet]", "[class*=popular]", "[class*=bet-row]", "[class*=event-row]"
        )
        for (selector in selectors) {
            for (element in doc.select(selector)) addCandidate(element, source, result)
        }
        for (counter in doc.getAllElements()) {
            if (counter.text().matches(Regex("(?s).*\\b\\d[\\d.\\s,+]*\\s*(?:kez\\s*oynandı|kez\\s*oynandi|oynandı|oynandi).*", RegexOption.IGNORE_CASE))) {
                addCandidate(nearestUsefulContainer(counter), source, result)
            }
        }
        return result.values.toList()
    }

    private fun nearestUsefulContainer(start: Element): Element {
        var node = start
        repeat(6) {
            val text = clean(node.text())
            if (text.length in 20..900 && (text.contains(" - ") || text.contains("–"))) return node
            node = node.parent() ?: return node
        }
        return start
    }

    private fun addCandidate(element: Element?, source: String, result: MutableMap<String, PopularBetItem>) {
        if (element == null) return
        val text = clean(element.text())
        if (text.length < 12 || text.length > 1200) return
        val pair = findTeamPair(text) ?: return
        val count = extractPlayCount(text)
        if (count <= 0L) return
        val market = findMarket(text)
        val odds = extractOdds(text)
        val key = "${pair.first}|${pair.second}|${market.lowercase(Locale.ROOT)}|$source"
        result.putIfAbsent(key, PopularBetItem(pair.first, pair.second, market, count, odds, source))
    }

    private fun findTeamPair(text: String): Pair<String, String>? {
        val compact = clean(text)
        val separators = listOf(" - ", " – ", " — ")
        for (separator in separators) {
            val parts = compact.split(separator, limit = 2)
            if (parts.size == 2) {
                val home = parts[0].substringAfterLast("|").trim()
                val away = parts[1].substringBefore(Regex("(?i)\\s+(?:TV|MAÇ|MAÇ SONUCU|KARŞILIKLI|TOPLAM|ALT/ÜST|MS\\b|\\d+(?:[.,]\\d+)?\\s*(?:KEZ|OYNA|OYNA[NN]DI))")).trim()
                if (validTeam(home) && validTeam(away)) return home to away
            }
        }
        return null
    }

    private fun validTeam(value: String): Boolean =
        value.length >= 2 && value.length <= 90 &&
            !value.contains("Bugün", true) && !value.contains("Oynan", true)

    private fun extractPlayCount(text: String): Long {
        Regex("(?i)(\\d[\\d.\\s,+]*)\\s*(?:kez\\s*oynandı|kez\\s*oynandi|kez|oynandı|oynandi)")
            .find(text)?.groupValues?.getOrNull(1)?.let { parseCount(it) }?.let { if (it > 0) return it }
        return Regex("(?<![\\d.,])(?:\\d{1,3}(?:[.]\\d{3})+|\\d{4,})(?![\\d.,])")
            .findAll(text).mapNotNull { parseCount(it.value) }.filter { it >= 1000 }.maxOrNull() ?: 0L
    }

    private fun parseCount(value: String): Long =
        value.replace(".", "").replace(",", "").replace(" ", "").replace("+", "").toLongOrNull() ?: 0L

    private fun findMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        return marketTokens.firstOrNull { upper.contains(it) } ?: "Popüler tercih"
    }

    private fun extractOdds(text: String): String =
        Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)").find(text)?.value?.replace(',', '.') ?: ""

    private fun clean(text: String): String = text.replace(Regex("\\s+"), " ").trim()
}

internal fun PopularBetItem.toModel(source: String = this.source): PopularBetModel = PopularBetModel(
    sourceName = source,
    rawHomeTeam = homeTeam,
    rawAwayTeam = awayTeam,
    prediction = prediction,
    ratioOrCount = playCount.toString(),
    odds = ratio,
)
