package com.cio.skor.data

import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

interface PopularBetParser {
    val sourceName: String
    val pageUrl: String
    fun fetch(): SourceFetchResult

    /** Source-specific parser first; rendered-HTML heuristic second. */
    fun parseBody(body: String): List<PopularBetModel>

    fun fetchFromPage(): SourceFetchResult {
        val http = PopularBetHttpClient.get(pageUrl)
        if (!http.isSuccess) {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.HTTP, http.code, http.attempts, http.error)
        }
        val records = runCatching { parseBody(http.body.orEmpty()) }.getOrElse {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.PARSE, http.code, http.attempts, it.message)
        }
        if (records.isEmpty()) {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.EMPTY, http.code, http.attempts, "HTTP başarılı fakat source parser veri çıkaramadı")
        }
        return SourceFetchResult.success(sourceName, pageUrl, records, http.code, http.attempts)
    }

    fun attrAny(el: Element, vararg names: String): String =
        names.asSequence().map { el.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: ""

    fun guessMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        val patterns = listOf("MS 1", "MS X", "MS 2", "MAÇ SONUCU", "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KG VAR", "KG YOK")
        return patterns.firstOrNull { upper.contains(it) } ?: ""
    }

    fun guessRatio(text: String): String = Regex("(?:%\\s?\\d{1,3}|\\d[\\d.]*\\s*(?:Kişi|oynama|oynandı|kez))", RegexOption.IGNORE_CASE)
        .find(text)?.value?.trim() ?: ""

    fun guessOdds(text: String): String = Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)")
        .find(text)?.value ?: ""

    fun canonicalMarket(value: String): String = value.lowercase(Locale("tr", "TR"))
        .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
        .replace("ş", "s").replace("ö", "o").replace("ç", "c")
        .replace(Regex("\\s+"), " ").trim()
}

enum class SourceFailure { HTTP, PARSE, EMPTY, EXCEPTION }

data class SourceFetchResult(
    val sourceName: String,
    val url: String,
    val records: List<PopularBetModel>,
    val failure: SourceFailure? = null,
    val httpCode: Int = 0,
    val attempts: Int = 0,
    val errorMessage: String? = null
) {
    val ok: Boolean get() = failure == null && records.isNotEmpty()
    companion object {
        fun success(source: String, url: String, records: List<PopularBetModel>, code: Int, attempts: Int) =
            SourceFetchResult(source, url, records, null, code, attempts, null)
        fun failure(source: String, url: String, reason: SourceFailure, code: Int, attempts: Int, message: String?) =
            SourceFetchResult(source, url, emptyList(), reason, code, attempts, message)
    }
}

class IddaaPopularParser : PopularBetParser {
    override val sourceName = "İddaa"
    override val pageUrl = "https://www.iddaa.com/populer-bahisler/futbol"
    private val json = IddaaParser()
    override fun fetch(): SourceFetchResult = fetchFromPage()
    override fun parseBody(body: String): List<PopularBetModel> {
        val jsonItems = runCatching { json.parse(body) }.getOrDefault(emptyList())
        return if (jsonItems.isNotEmpty()) jsonItems.map { it.toModel(sourceName) }
        else PopularBetHtmlHeuristics.parse(body, sourceName).map { it.toModel(sourceName) }
    }
}

class NesinePopularParser : PopularBetParser {
    override val sourceName = "Nesine"
    override val pageUrl = "https://www.nesine.com/iddaa/dakika-bahis"
    override fun fetch(): SourceFetchResult = fetchFromPage()
    override fun parseBody(body: String): List<PopularBetModel> =
        NesineParser().parseHtml(body).map { it.toModel(sourceName) }
}

class MisliPopularParser : PopularBetParser {
    override val sourceName = "Misli"
    // Verified user-provided current page; previous /en-cok-oynanan-tum-maclar path was wrong.
    override val pageUrl = "https://www.misli.com/iddaa/anlik-bahis"
    private val json = MisliParser()
    override fun fetch(): SourceFetchResult = fetchFromPage()
    override fun parseBody(body: String): List<PopularBetModel> {
        val jsonItems = runCatching { json.parse(body) }.getOrDefault(emptyList())
        return if (jsonItems.isNotEmpty()) jsonItems.map { it.toModel(sourceName) }
        else PopularBetHtmlHeuristics.parse(body, sourceName).map { it.toModel(sourceName) }
    }
}

class BilyonerPopularParser : PopularBetParser {
    override val sourceName = "Bilyoner"
    override val pageUrl = "https://www.bilyoner.com/iddaa/populer-bahisler"
    private val json = BilyonerParser()
    override fun fetch(): SourceFetchResult = fetchFromPage()
    override fun parseBody(body: String): List<PopularBetModel> {
        val jsonItems = runCatching { json.parse(body) }.getOrDefault(emptyList())
        return if (jsonItems.isNotEmpty()) jsonItems.map { it.toModel(sourceName) }
        else PopularBetHtmlHeuristics.parse(body, sourceName).map { it.toModel(sourceName) }
    }
}
