package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext

class PopularBetRepository(
    private val parsers: List<PopularBetParser> = listOf(
        IddaaPopularParser(),
        BilyonerPopularParser(),
        NesinePopularParser(),
        MisliPopularParser()
    )
) {
    suspend fun fetchDetailed(): List<SourceFetchResult> = withContext(Dispatchers.IO) {
        supervisorScope {
            parsers.map { parser ->
                async {
                    runCatching { parser.fetch() }.getOrElse { error ->
                        SourceFetchResult.failure(parser.sourceName, parser.pageUrl, SourceFailure.EXCEPTION, 0, 1, error.message)
                    }
                }
            }.awaitAll()
        }
    }

    suspend fun fetchAll(): List<PopularBetModel> = fetchDetailed().flatMap { it.records }

    fun cluster(raw: List<PopularBetModel>): List<PopularBetCluster> = PopularBetMerger.merge(raw)
}
