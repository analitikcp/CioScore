package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.PopularBetCluster
import com.cio.skor.data.PopularBetRepository
import com.cio.skor.data.SourceFetchResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PopularBetsActivity : Activity() {
    private val COLOR_TEXT = android.graphics.Color.rgb(16, 24, 40)
    private val COLOR_MUTED = android.graphics.Color.rgb(102, 112, 133)
    private val COLOR_SECONDARY = android.graphics.Color.rgb(52, 64, 84)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = PopularBetRepository()
    private lateinit var recycler: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(12))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        val title = TextView(this).apply {
            text = "🇹🇷 TÜRKİYE EN ÇOK OYNANANLAR\nİddaa • Bilyoner • Nesine • Misli"
            textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        progress = ProgressBar(this)
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(COLOR_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(8))
        }
        recycler = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@PopularBetsActivity) }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(42)))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(recycler, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        progress.visibility = ProgressBar.VISIBLE
        status.text = "4 platform taranıyor…"
        scope.launch {
            val results = withContext(Dispatchers.IO) { repository.fetchDetailed() }
            val clusters = repository.cluster(results.flatMap { it.records })
            progress.visibility = ProgressBar.GONE
            status.text = buildStatus(results, clusters)
            recycler.adapter = PopularAdapter(clusters)
        }
    }

    private fun buildStatus(results: List<SourceFetchResult>, clusters: List<PopularBetCluster>): String {
        val sourceLine = results.joinToString("   •   ") { r ->
            val detail = if (r.ok) "✓ ${r.records.size}" else "✗ ${r.failure?.name ?: "ERROR"}${if (r.httpCode > 0) " ${r.httpCode}" else ""}"
            "${r.sourceName}: $detail"
        }
        return if (clusters.isEmpty()) "$sourceLine\nOrtak liste oluşmadı. Kaynak/HTML parser ayrıntıları yukarıdaki durumdan görülebilir."
        else "$sourceLine\n${clusters.size} ortak maç/market bulundu."
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private inner class PopularAdapter(private val items: List<PopularBetCluster>) : RecyclerView.Adapter<PopularAdapter.VH>() {
        inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = GradientDrawable().apply { setColor(android.graphics.Color.WHITE); cornerRadius = dp(14).toFloat(); setStroke(dp(1), android.graphics.Color.rgb(231, 234, 240)) }
                elevation = dp(2).toFloat()
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(dp(4), dp(5), dp(4), dp(5)) }
            }
            return VH(card)
        }
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.card.removeAllViews()
            holder.card.addView(text("${item.homeTeam}  —  VS  —  ${item.awayTeam}", 16f, true, COLOR_TEXT))
            holder.card.addView(text("${item.marketName}   •   🇹🇷 Türkiye Trend Skoru: ${item.totalPopularityScore}/100", 14f, true, COLOR_TEXT))
            holder.card.addView(text("Trend kaynakları: ${item.sources.joinToString(" • ")}", 12f, false, COLOR_MUTED))
            item.bets.forEach { bet ->
                val line = "${bet.sourceName}: ${bet.prediction.ifBlank { "Popüler tercih" }}" +
                    (if (bet.ratioOrCount.isNotBlank()) "  ${bet.ratioOrCount}" else "") +
                    (if (bet.odds.isNotBlank()) "  oran ${bet.odds}" else "")
                holder.card.addView(text(line, 13f, false, COLOR_SECONDARY))
            }
        }
        private fun text(value: String, size: Float, bold: Boolean, color: Int): TextView = TextView(this@PopularBetsActivity).apply {
            text = value; textSize = size; setTextColor(color); setTypeface(typeface, if (bold) Typeface.BOLD else Typeface.NORMAL)
            setPadding(0, dp(3), 0, dp(3))
        }
    }
}
