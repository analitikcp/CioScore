package com.cio.skor.data

/** Raw popular-bet record from one Turkish operator. */
data class PopularBetModel(
    val sourceName: String,
    val rawHomeTeam: String,
    val rawAwayTeam: String,
    val matchCode: String = "",
    val prediction: String,
    val ratioOrCount: String = "",
    val odds: String = "",
    val matchTimestamp: Long = 0L,
    val matchDate: String = "",
    val matchTime: String = "--:--"
)

data class PopularBetCluster(
    val fixtureKey: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchCode: String,
    val marketName: String,
    val totalPopularityScore: Int,
    val sources: List<String>,
    val bets: List<PopularBetModel>
) {
    val sourceCount: Int get() = sources.distinct().size
}
