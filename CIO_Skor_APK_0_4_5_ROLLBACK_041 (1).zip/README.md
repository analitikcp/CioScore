# CIO Skor 0.4.1

16 kaynaklı otomatik tarama APK. Uygulama açıldığında tarama otomatik başlar. Her kaynak HTTP durumunu ve parser sonucunu gösterir.
