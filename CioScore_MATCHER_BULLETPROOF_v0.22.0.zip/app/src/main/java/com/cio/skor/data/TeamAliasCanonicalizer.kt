package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer
import java.util.Locale

/**
 * Global team identity layer.
 *
 * Rules are deliberately conservative:
 * - Unicode / Turkish characters are normalized.
 * - Punctuation and harmless club suffixes are removed only as edge tokens.
 * - Explicit aliases are preferred over broad fuzzy rules.
 * - The returned canonicalId is stable and source-independent.
 */
object TeamAliasCanonicalizer {

    private val removableEdgeTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio",
        "u21", "u20", "u19", "u18", "ii", "reserve", "reserves"
    )

    // These words can carry useful identity information (e.g. Manchester City
    // and Manchester United), so they are NEVER removed from canonical identity.
    // They only receive a small weight during fuzzy comparison.
    private val lowWeightTokens = setOf("city", "united", "club")

    // Common article/prefix variants are ignored only for fuzzy comparison.
    // Canonical IDs remain conservative to avoid accidental collisions.
    private val comparisonEdgeNoise = setOf("al", "el", "the", "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc", "club")

    /**
     * High-confidence aliases only. Avoid broad mappings such as plain
     * "newcastle" -> "newcastle united" because they can collide with
     * Newcastle Jets / other clubs.
     */
    private val aliases = mapOf(
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek athens fc" to "aek athens",

        "lask" to "lask",
        "lask linz" to "lask",
        "lask linz fc" to "lask",

        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "manchester united fc" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "tottenham" to "tottenham hotspur",
        "spurs" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",

        // Sporting CP / Sporting Lisbon are the same club. Keep this alias
        // explicit so city-name variants cannot create duplicate fixtures.
        "sporting cp" to "sporting clube de portugal",
        "sporting lisbon" to "sporting clube de portugal",
        "sporting lisboa" to "sporting clube de portugal",
        "sporting clube de portugal" to "sporting clube de portugal",
        "sporting portugal" to "sporting clube de portugal"
    )

    data class TeamIdentity(
        val canonicalId: String,
        val canonicalName: String,
        val compactName: String
    )

    fun identity(rawName: String): TeamIdentity {
        val canonicalName = canonical(rawName)
        return TeamIdentity(
            canonicalId = canonicalName.replace(' ', '-'),
            canonicalName = canonicalName,
            compactName = canonicalName.replace(" ", "")
        )
    }

    fun canonical(name: String): String {
        if (name.isBlank()) return ""

        var value = name.trim().lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (value.isBlank()) return ""

        var tokens = value.split(' ').filter(String::isNotBlank).toMutableList()

        // Language/city variants are token-level only. This prevents accidental
        // substring corruption of unrelated club names.
        tokens = tokens.map { token ->
            when (token) {
                "athens", "atina", "athina" -> "athens"
                else -> token
            }
        }.toMutableList()

        // Remove harmless club-type tokens only at the edges.
        while (tokens.isNotEmpty() && tokens.first() in removableEdgeTokens) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in removableEdgeTokens) tokens.removeAt(tokens.lastIndex)

        value = tokens.joinToString(" ").trim()
        if (value.isBlank()) return ""

        // Alias lookup must happen after normalization and edge-token cleanup.
        return aliases[value] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        return a.isNotBlank() && a == b
    }

    /**
     * Conservative fuzzy similarity over canonical identities.
     * Exact aliases always score 1.0.
     */
    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        if (ca == cb) return 1.0

        // Compare a second, conservative representation with harmless edge
        // noise removed. This handles variants such as "Al Ahly SC" /
        // "El Ahly" without weakening canonical IDs globally.
        val comparisonA = comparisonName(a)
        val comparisonB = comparisonName(b)
        if (comparisonA.isNotBlank() && comparisonA == comparisonB) return 0.98

        val weighted = weightedTokenSimilarity(a, b)
        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        val raw = ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)
        return maxOf(raw, weighted).coerceIn(0.0, 1.0)
    }

    private fun comparisonName(canonicalName: String): String {
        val tokens = canonicalName.split(' ').filter(String::isNotBlank).toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in comparisonEdgeNoise) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in comparisonEdgeNoise) tokens.removeAt(tokens.lastIndex)
        return tokens.joinToString(" ")
    }

    private fun weightedTokenSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank)
        val bt = b.split(' ').filter(String::isNotBlank)
        if (at.isEmpty() || bt.isEmpty()) return 0.0

        fun tokenWeight(token: String): Double = if (token in lowWeightTokens) 0.35 else 1.0

        fun bestAverage(from: List<String>, to: List<String>): Double {
            var weightedSum = 0.0
            var totalWeight = 0.0
            for (token in from) {
                val weight = tokenWeight(token)
                val best = to.maxOfOrNull { other ->
                    if (token == other) 1.0 else {
                        val maxLength = maxOf(token.length, other.length)
                        if (maxLength == 0) 1.0 else
                            1.0 - levenshtein(token, other).toDouble() / maxLength
                    }
                } ?: 0.0
                weightedSum += best.coerceIn(0.0, 1.0) * weight
                totalWeight += weight
            }
            return if (totalWeight == 0.0) 0.0 else weightedSum / totalWeight
        }

        return ((bestAverage(at, bt) + bestAverage(bt, at)) / 2.0).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        exact(name1, name2) || similarity(name1, name2) >= 0.80

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
