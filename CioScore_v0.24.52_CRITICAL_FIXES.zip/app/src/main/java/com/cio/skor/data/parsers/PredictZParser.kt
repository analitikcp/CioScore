package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.MatchMerger
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * PredictZ correct-score parser.
 *
 * Important: PredictZ pages contain many numeric form/stat columns next to the
 * team names. We therefore NEVER derive team names from the whole block text.
 * We use PredictZ's own match/team elements first and read the prediction from
 * its prediction box.
 */
class PredictZParser : BaseParser("PredictZ") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // PredictZ's match card/table container.
        val blocks = doc.select(".ptcnt, [class*=ptcnt]")

        for (block in blocks) {
            val home = firstText(
                block,
                ".ptmobh",
                "[class*=ptmobh]",
                ".ptmobh a",
                "[data-home-team]",
                "[data-team-home]",
                ".home-team",
                ".team-home"
            ) ?: continue

            val away = firstText(
                block,
                ".ptmoba",
                "[class*=ptmoba]",
                ".ptmoba a",
                "[data-away-team]",
                "[data-team-away]",
                ".away-team",
                ".team-away"
            ) ?: continue

            val cleanHome = cleanPredictZTeam(home)
            val cleanAway = cleanPredictZTeam(away)

            if (!valid(cleanHome, cleanAway)) continue

            val predictedScore = extractPredictionScore(block) ?: continue

            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        return out.values.toList()
    }

    private fun firstText(block: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = block.select(selector)
                .firstOrNull()
                ?.text()
                ?.replace("\u00A0", " ")
                ?.replace(Regex("\\s+"), " ")
                ?.trim()

            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun extractPredictionScore(block: Element): String? {
        // PredictZ's prediction boxes are deliberately checked first. This
        // prevents form/stat numbers from being mistaken for the score.
        val predictionElements = block.select(
            ".ptpredboxsml, .ptpredbox, [class*=ptpredbox]"
        )

        for (element in predictionElements) {
            val text = clean(element.text())
            val score = scoreFromPredictionText(text)
            if (score != null) return score
        }

        // On the correct-score page the block can expose the recommendation as
        // "Home 1-0", "Draw 1-1" or "Away 0-2". Only inspect those explicit
        // labels; do NOT scan arbitrary digits from the match block.
        val blockText = clean(block.text())
        val labelled = Regex(
            "(?i)\\b(?:home|draw|away)\\s+([0-5])\\s*[-:]\\s*([0-5])\\b"
        ).find(blockText)

        if (labelled != null) {
            return "${labelled.groupValues[1]}-${labelled.groupValues[2]}"
        }

        // Last safe fallback: an explicitly labelled Correct Score field.
        val explicit = Regex(
            "(?i)correct\\s*score(?:\\s+odds)?[^0-9]{0,40}([0-5])\\s*[-:]\\s*([0-5])\\b"
        ).find(blockText)

        return explicit?.let {
            "${it.groupValues[1]}-${it.groupValues[2]}"
        }
    }

    private fun scoreFromPredictionText(text: String): String? {
        val patterns = listOf(
            Regex("(?i)\\b(?:correct\\s*score|predicted\\s*score(?:line)?|prediction|tip)\\b[^0-9]{0,50}([0-5])\\s*[-:]\\s*([0-5])\\b"),
            Regex("\\b([0-5])\\s*[-:]\\s*([0-5])\\b")
        )

        for (pattern in patterns) {
            val match = pattern.find(text) ?: continue
            return "${match.groupValues[1]}-${match.groupValues[2]}"
        }

        return null
    }

    private fun cleanPredictZTeam(value: String): String {
        return value
            .replace("\u00A0", " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', '|')
    }
}
