package com.cio.skor.ui

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(initialList: List<MatchGroup> = emptyList()) : RecyclerView.Adapter<ScoreAdapter.VH>() {
    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5",
        "forebet" to "cio6",
        "cio1" to "cio1",
        "cio2" to "cio2",
        "cio3" to "cio3",
        "cio4" to "cio4",
        "cio5" to "cio5",
        "cio6" to "cio6"
    )

    // SADECE GÖRÜNÜM: veri modelindeki source değeri değiştirilmez.
    private fun displaySourceName(source: String): String =
        sourceLabels[source.trim().lowercase()] ?: source.trim()

    private fun Int.dp(ctx: android.content.Context): Int =
        (this * ctx.resources.displayMetrics.density).toInt()

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)
        displayedList = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18.dp(ctx), 16.dp(ctx), 18.dp(ctx), 16.dp(ctx))
            background = GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = 22.dp(ctx).toFloat()
                setStroke(1.dp(ctx), 0xFFE2E8F0.toInt())
            }
            elevation = 4.dp(ctx).toFloat()
            clipChildren = false
            clipToPadding = false
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(10.dp(ctx), 6.dp(ctx), 10.dp(ctx), 6.dp(ctx))
            }
        }
        return VH(card)
    }

    override fun getItemCount(): Int = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ctx = holder.card.context
        val match = displayedList[position]
        holder.card.removeAllViews()

        val teams = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        teams.addView(teamText(ctx, match.homeTeam), LinearLayout.LayoutParams(0, 54.dp(ctx), 1f))
        teams.addView(TextView(ctx).apply {
            text = "VS"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFF667085.toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFF2F4F7.toInt())
            }
        }, LinearLayout.LayoutParams(46.dp(ctx), 46.dp(ctx)))
        teams.addView(teamText(ctx, match.awayTeam), LinearLayout.LayoutParams(0, 54.dp(ctx), 1f))
        holder.card.addView(teams)

        val counts = match.predictions.groupingBy { it.predictedScore.trim() }.eachCount()
        val consensus = counts.entries.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key }
        )

        if (consensus != null && match.predictions.size > 1) {
            holder.card.addView(TextView(ctx).apply {
                text = "KONSENSÜS"
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF008F83.toInt())
            }, LinearLayout.LayoutParams(-1, 24.dp(ctx)))

            holder.card.addView(TextView(ctx).apply {
                text = consensus.key
                textSize = 32f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF009688.toInt())
            }, LinearLayout.LayoutParams(-1, 46.dp(ctx)))

            val badge = TextView(ctx).apply {
                text = "${consensus.value}/${match.predictions.size} kaynak"
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFFFFFFFF.toInt())
                background = GradientDrawable().apply {
                    setColor(0xFF18A86B.toInt())
                    cornerRadius = 16.dp(ctx).toFloat()
                }
                setPadding(16.dp(ctx), 6.dp(ctx), 16.dp(ctx), 6.dp(ctx))
            }
            holder.card.addView(badge, LinearLayout.LayoutParams(-2, 36.dp(ctx)).apply {
                gravity = Gravity.CENTER
                topMargin = 2.dp(ctx)
                bottomMargin = 6.dp(ctx)
            })
        }

        holder.card.addView(View(ctx), LinearLayout.LayoutParams(-1, 1.dp(ctx)).apply {
            topMargin = 4.dp(ctx)
            bottomMargin = 4.dp(ctx)
        }.also { it.initDivider(holder.card) })

        match.predictions.forEach { prediction ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = 38.dp(ctx)
            }

            row.addView(TextView(ctx).apply {
                text = displaySourceName(prediction.source)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF101828.toInt())
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
            }, LinearLayout.LayoutParams(0, 38.dp(ctx), 1f))

            row.addView(TextView(ctx).apply {
                text = "→"
                textSize = 16f
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(32.dp(ctx), 38.dp(ctx)))

            row.addView(TextView(ctx).apply {
                text = prediction.predictedScore.trim()
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF101828.toInt())
                gravity = Gravity.CENTER
                includeFontPadding = false
            }, LinearLayout.LayoutParams(58.dp(ctx), 38.dp(ctx)))

            holder.card.addView(row, LinearLayout.LayoutParams(-1, 38.dp(ctx)))
        }

        // Kart yüksekliğini SABİTLEME. RecyclerView + LinearLayout, tüm çocukları
        // ölçerek gerçek wrap_content yüksekliğini kendisi hesaplamalıdır.
        // Önceki sabit yükseklik hesabı son kaynak/skor satırlarını kırpıyordu.
        holder.card.layoutParams = (holder.card.layoutParams as RecyclerView.LayoutParams).apply {
            width = ViewGroup.LayoutParams.MATCH_PARENT
            height = ViewGroup.LayoutParams.WRAP_CONTENT
        }
        holder.card.requestLayout()
    }

    private fun LinearLayout.LayoutParams.initDivider(@Suppress("UNUSED_PARAMETER") parent: LinearLayout) {
        // Marker method: keeps divider LayoutParams construction readable.
    }

    private fun teamText(ctx: android.content.Context, name: String) = TextView(ctx).apply {
        text = name
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(0xFF101828.toInt())
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
}
