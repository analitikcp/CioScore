package com.cio.skor.data

/**
 * Main-scan competition policy.
 *
 * Only the explicitly requested senior competitions are accepted:
 * - 40 primary leagues from the user's reference list
 * - an explicit allowlist of senior men's cup / UEFA competitions
 *
 * Unknown competitions fail closed. Youth, women, reserve/B teams and friendly
 * competitions are rejected before they reach the identity/matcher pipeline.
 */
object CompetitionFilter {

    private val blockedMarkers = listOf(
        "women", "woman", "ladies", "feminine",
        "u17", "u18", "u19", "u20", "u21", "u22", "u23", "u24",
        "youth", "junior", "academy", "reserve", "reserves",
        " b team", " b-team", " b ", " ii", " iii",
        "friendly", "friendlies", "pre season", "pre-season", "test match"
    )

    private val aliases: Map<String, String> = buildMap {
        // 40 requested primary leagues.
        putAll(mapOf(
            "argentina liga profesional" to "ARGENTINA_LIGA_PROFESIONAL",
            "liga profesional argentina" to "ARGENTINA_LIGA_PROFESIONAL",
            "liga profesional" to "ARGENTINA_LIGA_PROFESIONAL",

            "austria bundesliga" to "AUSTRIA_BUNDESLIGA",
            "bundesliga austria" to "AUSTRIA_BUNDESLIGA",
            "austria 2 liga" to "AUSTRIA_2_LIGA",
            "2 liga austria" to "AUSTRIA_2_LIGA",

            "belgium jupiler pro league" to "BELGIUM_JUPILER_PRO_LEAGUE",
            "jupiler pro league" to "BELGIUM_JUPILER_PRO_LEAGUE",

            "brazil serie a betano" to "BRAZIL_SERIE_A_BETANO",
            "serie a betano" to "BRAZIL_SERIE_A_BETANO",

            "denmark superliga" to "DENMARK_SUPERLIGA",
            "superliga denmark" to "DENMARK_SUPERLIGA",
            "denmark 1st division" to "DENMARK_1ST_DIVISION",
            "1st division denmark" to "DENMARK_1ST_DIVISION",

            "england premier league" to "ENGLAND_PREMIER_LEAGUE",
            "premier league" to "ENGLAND_PREMIER_LEAGUE",
            "england championship" to "ENGLAND_CHAMPIONSHIP",
            "championship" to "ENGLAND_CHAMPIONSHIP",
            "england league one" to "ENGLAND_LEAGUE_ONE",
            "league one" to "ENGLAND_LEAGUE_ONE",
            "england league two" to "ENGLAND_LEAGUE_TWO",
            "league two" to "ENGLAND_LEAGUE_TWO",
            "england national league" to "ENGLAND_NATIONAL_LEAGUE",
            "national league england" to "ENGLAND_NATIONAL_LEAGUE",

            "finland veikkausliiga" to "FINLAND_VEIKKAUSLIIGA",
            "veikkausliiga" to "FINLAND_VEIKKAUSLIIGA",

            "france ligue 1" to "FRANCE_LIGUE_1",
            "ligue 1" to "FRANCE_LIGUE_1",
            "france ligue 2" to "FRANCE_LIGUE_2",
            "ligue 2" to "FRANCE_LIGUE_2",

            "germany bundesliga" to "GERMANY_BUNDESLIGA",
            "bundesliga germany" to "GERMANY_BUNDESLIGA",
            "bundesliga" to "GERMANY_BUNDESLIGA",
            "germany 2 bundesliga" to "GERMANY_2_BUNDESLIGA",
            "2 bundesliga" to "GERMANY_2_BUNDESLIGA",
            "germany 3 liga" to "GERMANY_3_LIGA",
            "3 liga germany" to "GERMANY_3_LIGA",

            "greece super league" to "GREECE_SUPER_LEAGUE",
            "super league greece" to "GREECE_SUPER_LEAGUE",

            "ireland premier division" to "IRELAND_PREMIER_DIVISION",
            "premier division ireland" to "IRELAND_PREMIER_DIVISION",

            "italy serie a" to "ITALY_SERIE_A",
            "serie a italy" to "ITALY_SERIE_A",
            "italy serie b" to "ITALY_SERIE_B",
            "serie b italy" to "ITALY_SERIE_B",

            "japan j1 league" to "JAPAN_J1_LEAGUE",
            "j1 league" to "JAPAN_J1_LEAGUE",

            "netherlands eredivisie" to "NETHERLANDS_EREDIVISIE",
            "eredivisie" to "NETHERLANDS_EREDIVISIE",
            "netherlands eerste divisie" to "NETHERLANDS_EERSTE_DIVISIE",
            "eerste divisie" to "NETHERLANDS_EERSTE_DIVISIE",

            "norway eliteserien" to "NORWAY_ELITESERIEN",
            "eliteserien" to "NORWAY_ELITESERIEN",

            "poland ekstraklasa" to "POLAND_EKSTRAKLASA",
            "ekstraklasa" to "POLAND_EKSTRAKLASA",

            "portugal liga portugal" to "PORTUGAL_LIGA_PORTUGAL",
            "liga portugal" to "PORTUGAL_LIGA_PORTUGAL",

            "scotland premiership" to "SCOTLAND_PREMIERSHIP",
            "scottish premiership" to "SCOTLAND_PREMIERSHIP",
            "scotland championship" to "SCOTLAND_CHAMPIONSHIP",
            "scottish championship" to "SCOTLAND_CHAMPIONSHIP",
            "scotland league one" to "SCOTLAND_LEAGUE_ONE",
            "scottish league one" to "SCOTLAND_LEAGUE_ONE",
            "scotland league two" to "SCOTLAND_LEAGUE_TWO",
            "scottish league two" to "SCOTLAND_LEAGUE_TWO",

            "south korea k league 1" to "SOUTH_KOREA_K_LEAGUE_1",
            "k league 1" to "SOUTH_KOREA_K_LEAGUE_1",
            "korea k league 1" to "SOUTH_KOREA_K_LEAGUE_1",

            "spain laliga" to "SPAIN_LALIGA",
            "la liga" to "SPAIN_LALIGA",
            "laliga" to "SPAIN_LALIGA",
            "spain laliga2" to "SPAIN_LALIGA2",
            "laliga2" to "SPAIN_LALIGA2",
            "la liga 2" to "SPAIN_LALIGA2",

            "sweden allsvenskan" to "SWEDEN_ALLSVENSKAN",
            "allsvenskan" to "SWEDEN_ALLSVENSKAN",
            "sweden superettan" to "SWEDEN_SUPERETTAN",
            "superettan" to "SWEDEN_SUPERETTAN",

            "switzerland super league" to "SWITZERLAND_SUPER_LEAGUE",
            "swiss super league" to "SWITZERLAND_SUPER_LEAGUE",

            "turkey super lig" to "TURKEY_SUPER_LIG",
            "turkey super league" to "TURKEY_SUPER_LIG",
            "super lig" to "TURKEY_SUPER_LIG",
            "super lig turkey" to "TURKEY_SUPER_LIG",

            "usa mls" to "USA_MLS",
            "mls" to "USA_MLS"
        ))

        // Explicit senior men's / open UEFA cup competitions.
        putAll(mapOf(
            "uefa champions league" to "UEFA_CHAMPIONS_LEAGUE",
            "champions league" to "UEFA_CHAMPIONS_LEAGUE",
            "uefa europa league" to "UEFA_EUROPA_LEAGUE",
            "europa league" to "UEFA_EUROPA_LEAGUE",
            "uefa conference league" to "UEFA_CONFERENCE_LEAGUE",
            "conference league" to "UEFA_CONFERENCE_LEAGUE",

            "fa cup" to "ENGLAND_FA_CUP",
            "the fa cup" to "ENGLAND_FA_CUP",
            "efl cup" to "ENGLAND_EFL_CUP",
            "carabao cup" to "ENGLAND_EFL_CUP",

            "copa del rey" to "SPAIN_COPA_DEL_REY",
            "coppa italia" to "ITALY_COPPA_ITALIA",
            "dfb pokal" to "GERMANY_DFB_POKAL",
            "dfb-pokal" to "GERMANY_DFB_POKAL",
            "coupe de france" to "FRANCE_COUP_DE_FRANCE",
            "knvb beker" to "NETHERLANDS_KNVB_BEKER",
            "taca de portugal" to "PORTUGAL_TACA_DE_PORTUGAL",
            "portugal cup" to "PORTUGAL_TACA_DE_PORTUGAL",
            "turkiye kupasi" to "TURKEY_TURKIYE_KUPASI",
            "turkey cup" to "TURKEY_TURKIYE_KUPASI",
            "copa do brasil" to "BRAZIL_COPA_DO_BRASIL",
            "copa argentina" to "ARGENTINA_COPA_ARGENTINA",
            "greek cup" to "GREECE_CUP",
            "greece cup" to "GREECE_CUP",
            "scottish cup" to "SCOTLAND_SCOTTISH_CUP",
            "scottish league cup" to "SCOTLAND_LEAGUE_CUP",
            "league cup scotland" to "SCOTLAND_LEAGUE_CUP",
            "belgian cup" to "BELGIUM_CUP",
            "belgium cup" to "BELGIUM_CUP",
            "austrian cup" to "AUSTRIA_CUP",
            "swiss cup" to "SWITZERLAND_CUP",
            "polish cup" to "POLAND_CUP",
            "danish cup" to "DENMARK_CUP",
            "norwegian cup" to "NORWAY_CUP",
            "swedish cup" to "SWEDEN_CUP",
            "svenska cupen" to "SWEDEN_CUP",
            "emperor cup" to "JAPAN_EMPEROR_CUP",
            "emperor's cup" to "JAPAN_EMPEROR_CUP",
            "japan emperor cup" to "JAPAN_EMPEROR_CUP",
            "korean fa cup" to "SOUTH_KOREA_FA_CUP",
            "korea fa cup" to "SOUTH_KOREA_FA_CUP",
            "mls cup" to "USA_MLS_CUP"
        ))
    }

    fun canonical(name: String): String? {
        val n = normalize(name)
        if (n.isBlank() || isBlocked(n)) return null
        aliases[n]?.let { return it }

        // Common source format: "Country - Competition" or "Country: Competition".
        val stripped = n.replace(Regex("^(argentina|austria|belgium|brazil|denmark|england|finland|france|germany|greece|ireland|italy|japan|netherlands|norway|poland|portugal|scotland|south korea|spain|sweden|switzerland|turkey|usa|united states|uefa)\\s+"), "")
        return aliases[stripped]
    }

    fun isAllowed(name: String): Boolean = canonical(name) != null

    private fun isBlocked(n: String): Boolean {
        if (blockedMarkers.any { marker -> n.contains(marker) }) return true
        // Explicit numeric youth/reserve forms not covered by the token list.
        if (Regex("\\bu\\s*([0-9]{2})\\b").containsMatchIn(n)) return true
        if (Regex("\\b(reserves?|reserve team|b team|second team|third team)\\b").containsMatchIn(n)) return true
        return false
    }

    private fun normalize(raw: String): String {
        return raw.lowercase()
            .replace('ı', 'i')
            .replace('İ', 'i')
            .replace('ş', 's')
            .replace('Ş', 's')
            .replace('ğ', 'g')
            .replace('Ğ', 'g')
            .replace('ü', 'u')
            .replace('Ü', 'u')
            .replace('ö', 'o')
            .replace('Ö', 'o')
            .replace('ç', 'c')
            .replace('Ç', 'c')
            .replace("&", " and ")
            .replace(Regex("[’'`´]"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }
}
