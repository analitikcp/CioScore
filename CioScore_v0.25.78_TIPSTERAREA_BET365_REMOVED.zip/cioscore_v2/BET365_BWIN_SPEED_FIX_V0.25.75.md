# CioScore v0.25.75 — Bet365 çözümü + bwin hızlandırma

- Bet365 kaynakları API / TotalCorner / Flashscore / SofaScore / AiScore paralel sorgulanır.
- TotalCorner varsa gerçek Bet365 1X2 ayrı kaynak olarak kabul edilir; başka bookmaker oranı Bet365'e kopyalanmaz.
- API, fixture ID/FI ve güncel `results[]` + `name` parserı korunur.
- Cache yalnızca doğrulanmış aynı maç ve taze kayıt için fallbacktir.
- bwin, Bet365'i beklemeden kendi sonucunu karta yazar.
- RecyclerView `onBind` artık ağ isteğinin tetikleyicisi değildir.
- Tarama tamamlanınca bütün maçların odds preload kuyruğu başlar.
- Aynı anda en fazla 4 maçın bookmaker motoru çalışır.
- bwin -> TipsterArea -> bwin Sports API -> SofaScore zinciri her maçta bağımsız çalışır.
- Bet365 ve bwin sonuçları ayrı UI güncellemeleriyle yayınlanır; yavaş kaynak hızlı kaynağı bloke etmez.
