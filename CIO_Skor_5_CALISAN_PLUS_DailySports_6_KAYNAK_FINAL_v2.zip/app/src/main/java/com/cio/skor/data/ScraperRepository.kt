package com.cio.skor.data

import com.cio.skor.data.parsers.FPComParser
import com.cio.skor.data.parsers.ForebetParser
import com.cio.skor.data.parsers.PredictZParser
import com.cio.skor.data.parsers.SoccerSeerParser
import com.cio.skor.data.parsers.WinDrawWinParser
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: com.cio.skor.data.parsers.BaseParser)

    private val http = HttpClient()

    // Proven working 5-source base + separately verified DailySports.
    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", com.cio.skor.data.parsers.DailySportsParser())
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = http.get(source.url)
                    val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else emptyList()
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
