# Step 15 — Skor Kaynakları Tıklanabilir Butonlar

- 8 skor/tahmin kaynağı kartı tıklanabilir hale getirildi.
- Her kaynak satırı Android tarayıcı açarak ilgili kaynağın doğrudan sayfasına gider.
- Kaynak başındaki emoji/şekiller kaldırıldı; isimler standart metin olarak gösteriliyor.
- Kaynak adı ve URL tek `PredictionSourceCatalog` üzerinden yönetiliyor.
- Mevcut skor/prediction verisi değişmedi; yalnızca UI etkileşimi ve standartlaştırma yapıldı.
- `PredictionSourceCatalogTest` ile tüm kaynakların HTTPS URL'si ve isimleri doğrulanıyor.
