package com.cio.skor

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()

    private lateinit var status: TextView
    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private var scanning = false
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        status = findViewById(R.id.tvStatus)
        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)
        findViewById<TextView>(R.id.tvStatSources).text = repo.sourceCount.toString()
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        val recycler = findViewById<RecyclerView>(R.id.recyclerScores)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(emptyList()) { team -> showLastFive(team) }
        recycler.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnClearSearch).setOnClickListener {
            searchInput.setText("")
            adapter.submitList(allGroups)
        }

        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        setScanningUi(true)

        adapter.submitList(emptyList())
        findViewById<TextView>(R.id.tvStatSources).text = "0"
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        scope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, _ ->
                        runOnUiThread {
                            if (scanning) {
                                scanStatus.text = "Taranıyor…  $completed/${repo.sourceCount} kaynak"
                            }
                        }
                    }
                }

                val scores = results
                    .flatMap { result -> result.scores }
                    .filter(::isDisplayable)
                    .distinctBy {
                        "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                        "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                        "${it.predictedScore}|${it.source.trim().lowercase()}"
                    }

                val goodSources = scores.map { sourceLabel(it.source) }
                    .filter { it.isNotEmpty() }
                    .distinct()

                // Önce bütün ham kayıtlar toplanır, sonra MatchMerger ile birleştirilir.
                val unified = MatchMerger.mergeMatches(scores)
                val baseGroups = unified.map { match ->
                    SofaScoreService.MatchGroupData(
                        homeTeam = match.mainHomeTeam,
                        awayTeam = match.mainAwayTeam,
                        predictions = match.predictions.map { (source, score) ->
                            ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                        }
                    )
                }

                // AiScore is enrichment only. If it fails or has no odds, the
                // five-source CIO results are still shown normally.
                val enriched = sofaScore.enrichOdds(baseGroups)
                // Maçları başlama saatine göre sırala. Saati bulunamayanlar
                // en alta gider; böylece eksik enrichment ana listeyi bozmaz.
                allGroups = enriched
                    .sortedWith(
                        compareBy<SofaScoreService.MatchGroupData> { it.startTimestamp == null }
                            .thenBy { it.startTimestamp ?: Long.MAX_VALUE }
                            .thenBy { it.homeTeam.lowercase() }
                    )
                    .map { match ->
                        MatchGroup(
                            homeTeam = match.homeTeam,
                            awayTeam = match.awayTeam,
                            predictions = match.predictions,
                            odds = match.odds,
                            startTimestamp = match.startTimestamp
                        )
                    }

                adapter.submitList(allGroups)
                findViewById<TextView>(R.id.tvStatSources).text = goodSources.size.toString()
                findViewById<TextView>(R.id.tvStatScores).text = scores.size.toString()
                findViewById<TextView>(R.id.tvStatMatches).text = allGroups.size.toString()
                scanStatus.text = "Tarama tamamlandı • ${goodSources.size}/${repo.sourceCount} kaynak veri verdi"
            } catch (e: Exception) {
                scanStatus.text = "Tarama tamamlanamadı: ${e.javaClass.simpleName}"
            } finally {
                setScanningUi(false)
            }
        }
    }

    private fun showLastFive(teamName: String) {
        val ctx = this

        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }

        val title = TextView(ctx).apply {
            text = teamName
            textSize = 23f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF101828.toInt())
            gravity = Gravity.CENTER
        }
        content.addView(title, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(2) })

        val subtitle = TextView(ctx).apply {
            text = "SON 5 MAÇ • FORM"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF008F83.toInt())
            gravity = Gravity.CENTER
        }
        content.addView(subtitle, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        val body = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(body, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(330)
        ))

        body.addView(TextView(ctx).apply {
            text = "Son maçlar yükleniyor…"
            textSize = 14f
            setTextColor(0xFF667085.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val dialog = AlertDialog.Builder(ctx)
            .setView(content)
            .setNegativeButton("KAPAT", null)
            .create()
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        scope.launch {
            val matches = withContext(Dispatchers.IO) { sofaScore.getLastFive(teamName) }
            if (isFinishing || isDestroyed || !dialog.isShowing) return@launch

            body.removeAllViews()
            if (matches.isEmpty()) {
                body.addView(TextView(ctx).apply {
                    text = "Son 5 maç verisi alınamadı."
                    textSize = 14f
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(24), dp(12), dp(24))
                }, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                ))
                return@launch
            }

            val wins = matches.count { it.result == "G" }
            val draws = matches.count { it.result == "B" }
            val losses = matches.count { it.result == "M" }
            val goalsFor = matches.sumOf { it.score.substringBefore('-').toIntOrNull() ?: 0 }
            val goalsAgainst = matches.sumOf { it.score.substringAfter('-').toIntOrNull() ?: 0 }

            val summary = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(4), dp(2), dp(10))
            }
            summary.addView(formStat(ctx, "G", wins.toString(), 0xFF0B8F55.toInt()))
            summary.addView(formStat(ctx, "B", draws.toString(), 0xFF667085.toInt()))
            summary.addView(formStat(ctx, "M", losses.toString(), 0xFFE53935.toInt()))
            summary.addView(formStat(ctx, "GF", goalsFor.toString(), 0xFF00796B.toInt()))
            summary.addView(formStat(ctx, "GA", goalsAgainst.toString(), 0xFF475467.toInt()))
            body.addView(summary)

            val scroll = ScrollView(ctx).apply {
                isFillViewport = true
                clipToPadding = false
                setPadding(0, 0, 0, dp(2))
            }
            val list = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
            }
            scroll.addView(list, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))

            matches.forEachIndexed { index, m ->
                list.addView(recentMatchCard(ctx, teamName, index + 1, m))
            }
            body.addView(scroll, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            ))
        }
    }

    private fun recentMatchCard(
        ctx: android.content.Context,
        teamName: String,
        number: Int,
        m: SofaScoreService.RecentMatch
    ): LinearLayout {
        // Compact match row inspired by score-history lists: date | teams | score | result.
        val resultColor = when (m.result) {
            "G" -> 0xFF0B9F5A.toInt()
            "B" -> 0xFFE0A800.toInt()
            else -> 0xFFE53935.toInt()
        }
        val resultText = m.result.ifBlank { "?" }

        val parts = m.score.split("-")
        val teamGoals = parts.getOrNull(0)?.trim().orEmpty()
        val oppGoals = parts.getOrNull(1)?.trim().orEmpty()
        val homeName = if (m.isHome) teamName else m.opponent
        val awayName = if (m.isHome) m.opponent else teamName
        val homeGoals = if (m.isHome) teamGoals else oppGoals
        val awayGoals = if (m.isHome) oppGoals else teamGoals

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(9), dp(4), dp(9))
            background = GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
            }
        }

        val dateCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        dateCol.addView(TextView(ctx).apply {
            text = formatShortDate(m.date)
            textSize = 10.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF52606D.toInt())
            gravity = Gravity.CENTER
        })
        dateCol.addView(TextView(ctx).apply {
            text = if (m.isHome) "EV" else "DEP"
            textSize = 8.5f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF98A2B3.toInt())
            gravity = Gravity.CENTER
        })
        row.addView(dateCol, LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.WRAP_CONTENT))

        val home = TextView(ctx).apply {
            text = homeName
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        row.addView(home, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dp(6)
            rightMargin = dp(4)
        })

        val score = TextView(ctx).apply {
            text = "$homeGoals  -  $awayGoals"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF1D2939.toInt())
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0xFFF2F7F9.toInt())
                cornerRadius = dp(7).toFloat()
            }
            setPadding(dp(7), dp(5), dp(7), dp(5))
        }
        row.addView(score, LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            leftMargin = dp(4)
            rightMargin = dp(4)
        })

        val away = TextView(ctx).apply {
            text = awayName
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        row.addView(away, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            leftMargin = dp(4)
            rightMargin = dp(6)
        })

        val badge = TextView(ctx).apply {
            text = resultText
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(3), dp(2), dp(3))
            background = GradientDrawable().apply {
                setColor(resultColor)
                cornerRadius = dp(6).toFloat()
            }
        }
        row.addView(badge, LinearLayout.LayoutParams(dp(30), dp(30)))

        val wrapper = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
            addView(View(ctx).apply {
                setBackgroundColor(0xFFE4E7EC.toInt())
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)
            ))
        }
        return wrapper.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun formatShortDate(raw: String): String {
        val parts = raw.split("-")
        return if (parts.size == 3) "${parts[2]}.${parts[1]}" else raw
    }

    private fun formStat(ctx: android.content.Context, label: String, value: String, color: Int): LinearLayout {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(3), dp(7), dp(3))
        }
        box.addView(TextView(ctx).apply {
            text = value
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(color)
            gravity = Gravity.CENTER
        })
        box.addView(TextView(ctx).apply {
            text = label
            textSize = 9f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF64748B.toInt())
            gravity = Gravity.CENTER
        })
        return box
    }

    private fun pill(ctx: android.content.Context, text: String, color: Int): TextView = TextView(ctx).apply {
        this.text = text
        textSize = 8.5f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(7), dp(4), dp(7), dp(4))
        background = GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt())
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), 0xFFD0D5DD.toInt())
        }
    }

    private fun formatDate(raw: String): String {
        val parts = raw.split("-")
        return if (parts.size == 3) "${parts[2]}.${parts[1]}.${parts[0]}" else raw
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        scanStatus.visibility = View.VISIBLE
        if (active) {
            scanStatus.text = "Kaynaklar taranıyor…"
        }
    }

    private fun sourceLabel(source: String): String = when (source.trim().lowercase()) {
        "fp.com" -> "cio1"
        "predictz" -> "cio2"
        "windrawwin" -> "cio3"
        "soccerseer" -> "cio4"
        "dailysports" -> "cio5"
        "cio1", "cio2", "cio3", "cio4", "cio5" -> source.trim().lowercase()
        else -> source.trim().lowercase()
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
