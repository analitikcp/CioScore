package com.cio.skor.data.parsers.custom

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.parsers.BaseParser
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Shared DOM helpers for sources whose markup changes frequently. */
abstract class SitePredictionParser(source: String) : BaseParser(source) {
    protected fun parseBlocks(doc: Document, selectors: String): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (el in doc.select(selectors)) {
            val raw = clean(el.text())
            if (raw.length !in 12..900) continue
            val score = extractScore(raw) ?: continue
            val teams = extractTeams(el, raw) ?: continue
            if (!valid(teams.first, teams.second)) continue
            val model = ScoreModel(teams.first, teams.second, score, source)
            out.putIfAbsent(model.matchKey, model)
            if (out.size >= 100) break
        }
        return out.values.toList()
    }

    protected fun extractScore(raw: String): String? {
        val labelled = Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|exact\\s*score|score|tip)[^0-9]{0,100}([0-5])\\s*[-:]\\s*([0-5])").find(raw)
        return labelled?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: score(raw)
    }

    protected fun extractTeams(el: Element, raw: String): Pair<String, String>? {
        val homeSelectors = listOf("[class*=home]", "[class*=team-home]", ".home", ".team1", ".home-team")
        val awaySelectors = listOf("[class*=away]", "[class*=team-away]", ".away", ".team2", ".away-team")
        val h = homeSelectors.asSequence().mapNotNull { el.selectFirst(it)?.text()?.let(::team) }.firstOrNull()
        val a = awaySelectors.asSequence().mapNotNull { el.selectFirst(it)?.text()?.let(::team) }.firstOrNull()
        if (!h.isNullOrBlank() && !a.isNullOrBlank() && valid(h, a)) return h to a

        val patterns = listOf(
            Regex("(?i)(.{2,70}?)\\s+(?:vs\\.?|v\\.?|versus)\\s+(.{2,70}?)\\b"),
            Regex("(.{2,70}?)\\s+[–—-]\\s+(.{2,70}?)\\s+(?=(?:correct|predicted|exact|score|tip|prediction)\\b)")
        )
        for (p in patterns) {
            val m = p.find(raw) ?: continue
            val h2 = team(m.groupValues[1]); val a2 = team(m.groupValues[2])
            if (valid(h2, a2)) return h2 to a2
        }
        return null
    }
}
