# CioScore v0.18.7

- Match cards now display the official Iddaa kickoff time.
- Match time is normalized to epoch milliseconds for sorting and matching.
- Supports epoch seconds, epoch milliseconds and common ISO/local date strings from the official event feed.
- Today's official Iddaa matches are sorted chronologically.
- HT/FT remains official Iddaa only; Mackolik is not used for HT/FT odds.
- Fixed malformed MainActivity official-odds fallback block inherited from v0.18.6.
