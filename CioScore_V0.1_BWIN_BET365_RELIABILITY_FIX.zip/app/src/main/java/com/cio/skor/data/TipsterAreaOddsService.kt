package com.cio.skor.data

import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * API-free TipsterArea odds transport.
 *
 * TipsterArea publishes a server-rendered "Leading Bookmakers Odds / Standard
 * 1X2" table.  The bookmaker labels are often image alt attributes rather than
 * normal text, so discovery and parsing must not depend on Element.text().
 */
class TipsterAreaOddsService {
    data class Odds(val bookmaker: String, val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()

    // TipsterArea is a bwin/other-bookmaker source only. Bet365 is deliberately
    // blocked here so it can NEVER become a Bet365 source, even if TipsterArea
    // changes its HTML and exposes a Bet365 row. Bet365 is handled exclusively
    // by the dedicated Bet365 providers/direct-feed layers.
    private val wantedBookmakers = linkedMapOf(
        "1xbet" to "1xBet",
        "bet-at-home" to "bet-at-home",
        "betfair" to "Betfair",
        "bwin" to "bwin",
        "unibet" to "Unibet"
    )

    private val blockedBookmakerKeys = setOf("bet365", "bet 365")

    private data class CacheEntry(val expiresAt: Long, val value: List<Odds>)
    private val oddsCache = ConcurrentHashMap<String, CacheEntry>()
    private val urlCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val cacheTtlMs = 5 * 60 * 1000L

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        matchDate: String = ""
    ): List<Odds> {
        val cacheKey = "${normalize(homeTeam)}|${normalize(awayTeam)}|${dateKey(matchDate)}"
        oddsCache[cacheKey]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return it.value }

        val detailUrl = discoverMatchUrl(homeTeam, awayTeam, matchDate) ?: return emptyList()
        val (code, body) = http.getSource(detailUrl, "https://tipsterarea.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()

        val result = parseOdds(body)
        if (result.isNotEmpty()) {
            oddsCache[cacheKey] = CacheEntry(System.currentTimeMillis() + cacheTtlMs, result)
        }
        return result
    }

    private fun discoverMatchUrl(homeTeam: String, awayTeam: String, matchDate: String): String? {
        val home = normalizedTeamVariants(homeTeam)
        val away = normalizedTeamVariants(awayTeam)
        if (home.isEmpty() || away.isEmpty()) return null

        val dates = candidateDates(matchDate)
        for (date in dates) {
            val dateKey = date.toString()
            val urlCacheKey = "${home.joinToString("_")}|${away.joinToString("_")}|$dateKey"
            urlCache[urlCacheKey]?.takeIf { it.first > System.currentTimeMillis() }?.let { return it.second }

            val tipsterDate = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
            val indexUrls = listOf(
                "https://tipsterarea.com/matches/date-$tipsterDate",
                "https://tipsterarea.com/matches-hour/date-$tipsterDate"
            )

            var bestUrl: String? = null
            var bestScore = 0.0
            for (url in indexUrls) {
                val body = fetchTipsterHtml(url) ?: continue
                val doc = Jsoup.parse(body, "https://tipsterarea.com/")
                for (a in doc.select("a[href*='/match/']")) {
                    val href = a.absUrl("href").ifBlank {
                        val raw = a.attr("href")
                        if (raw.startsWith("http")) raw else "https://tipsterarea.com${if (raw.startsWith('/')) raw else "/$raw"}"
                    }
                    if (href.isBlank()) continue
                    val evidence = normalize(href + " " + a.wholeText() + " " + a.attr("title"))
                    val hs = teamSimilarity(evidence, home)
                    val ascore = teamSimilarity(evidence, away)
                    val total = (hs + ascore) / 2.0
                    if (hs >= 0.60 && ascore >= 0.60 && total > bestScore) {
                        bestScore = total
                        bestUrl = href
                    }
                    if (teamPairMatches(evidence, home, away)) {
                        urlCache[urlCacheKey] = System.currentTimeMillis() + cacheTtlMs to href
                        return href
                    }
                }
            }
            if (bestUrl != null && bestScore >= 0.72) {
                urlCache[urlCacheKey] = System.currentTimeMillis() + cacheTtlMs to bestUrl
                return bestUrl
            }
        }
        return null
    }

    private fun teamSimilarity(haystack: String, variants: List<String>): Double {
        if (variants.isEmpty()) return 0.0
        return variants.maxOf { team ->
            if (containsTeamPhrase(haystack, team)) 1.0 else {
                val tokens = team.split(' ').filter { it.length >= 3 }.toSet()
                if (tokens.isEmpty()) 0.0 else tokens.count { haystack.contains(it) }.toDouble() / tokens.size
            }
        }
    }

    /**
     * TipsterArea may return a normal HTML document, a transient 403/429, or
     * an empty body depending on the edge node.  Use the browser-profile fetch
     * first and then the simpler OkHttp path as a second transport.  Neither
     * path bypasses JS/CAPTCHA/access controls.
     */
    private fun fetchTipsterHtml(url: String): String? {
        val primary = http.getSource(url, "https://tipsterarea.com/")
        if (primary.first in 200..299 && !primary.second.isNullOrBlank()) return primary.second

        val fallback = http.get(url, "https://tipsterarea.com/")
        return if (fallback.first in 200..299 && !fallback.second.isNullOrBlank()) fallback.second else null
    }

    private fun candidateDates(raw: String): List<LocalDate> {
        val base = parseDate(raw) ?: LocalDate.now(KickoffNormalizer.ZONE)
        return listOf(base, base.minusDays(1), base.plusDays(1)).distinct()
    }

    private fun parseDate(raw: String): LocalDate? {
        val value = raw.trim().take(10)
        if (value.isBlank()) return null
        val formats = listOf(
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
        )
        return formats.firstNotNullOfOrNull { formatter ->
            try { LocalDate.parse(value, formatter) } catch (_: DateTimeParseException) { null }
        }
    }

    private fun dateKey(raw: String): String = parseDate(raw)?.toString() ?: raw.trim()

    private fun normalizedTeamVariants(value: String): List<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptyList()

        val stripped = base.split(' ')
            .filterNot { it in GENERIC_TEAM_PREFIXES }
            .joinToString(" ")
            .trim()

        return listOf(base, stripped)
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun teamPairMatches(text: String, homeVariants: List<String>, awayVariants: List<String>): Boolean {
        val haystack = normalize(text)
        val homeHit = homeVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        val awayHit = awayVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        return homeHit && awayHit
    }

    private fun containsTeamPhrase(haystack: String, team: String): Boolean {
        if (team.isBlank()) return false
        if (haystack.contains(team)) return true

        // Handle common short-name differences, e.g. "CD Universidad Catolica"
        // vs a URL slug containing only "universidad catolica".
        val tokens = team.split(' ').filter { it.length >= 3 }
        if (tokens.isEmpty()) return false
        val hits = tokens.count { haystack.contains(it) }
        return hits >= maxOf(1, (tokens.size * 0.75).toInt())
    }

    private fun parseOdds(html: String): List<Odds> {
        val doc = Jsoup.parse(html)

        // Prefer the table explicitly marked as Standard 1X2.  If the site's
        // responsive HTML changes, fall back to the table with the strongest
        // bookmaker/1X2 signature instead of returning an empty result.
        val tables = doc.select("table")
        val standardTable = tables.firstOrNull { table ->
            val marker = normalize(
                table.text() + " " + table.select("img[alt]").joinToString(" ") { it.attr("alt") }
            )
            marker.contains("standard 1x2")
        }
        val bookmakerTable = standardTable ?: tables.maxByOrNull { table ->
            val marker = normalize(
                table.text() + " " + table.select("img[alt]").joinToString(" ") { it.attr("alt") }
            )
            wantedBookmakers.keys.count { marker.contains(normalize(it)) } * 10 +
                if (marker.contains("1 x 2")) 2 else 0
        }?.takeIf { table ->
            val marker = normalize(
                table.text() + " " + table.select("img[alt]").joinToString(" ") { it.attr("alt") }
            )
            wantedBookmakers.keys.any { marker.contains(normalize(it)) }
        }

        val rows = bookmakerTable?.select("tr")?.toList()
            ?: doc.select("tr").toList()

        val rowsByBookmaker = linkedMapOf<String, Odds>()
        for (tr in rows) {
            val bookmakerKey = bookmakerFromRow(tr) ?: continue
            val values = numericOddsFromRow(tr)
            if (values.size < 3) continue

            val clean = values.mapNotNull(::cleanOdd)
            if (clean.size < 3) continue

            rowsByBookmaker.putIfAbsent(
                bookmakerKey,
                Odds(
                    wantedBookmakers.getValue(bookmakerKey),
                    clean[clean.lastIndex - 2], clean[clean.lastIndex - 1], clean.last()
                )
            )
        }

        return wantedBookmakers.keys.mapNotNull { rowsByBookmaker[it] }
    }

    private fun bookmakerFromRow(row: Element): String? {
        val imageNames = row.select("img[alt]").map { it.attr("alt") }.filter { it.isNotBlank() }
        val text = buildString {
            append(row.text())
            if (imageNames.isNotEmpty()) append(' ').append(imageNames.joinToString(" "))
        }
        val normalized = normalize(text)

        // HARD BLOCK: TipsterArea must never supply Bet365 data.
        // Do this before bookmaker matching so a future wantedBookmakers change
        // cannot accidentally re-introduce Bet365 through this parser.
        if (blockedBookmakerKeys.any { normalized.contains(normalize(it)) }) return null

        return wantedBookmakers.keys.firstOrNull { key ->
            normalized.contains(normalize(key))
        }
    }

    private fun numericOddsFromRow(row: Element): List<String> {
        val rawParts = row.select("td,th").flatMap { cell ->
            val text = cell.text().trim()
            if (text.isNotBlank()) listOf(text) else emptyList()
        }
        val raw = rawParts.joinToString(" ")
        val matches = ODDS_NUMBER.findAll(raw).map { it.value }.toList()
        if (matches.size >= 3) return matches

        // A few TipsterArea variants put the values in attributes/spans. Fall
        // back to the complete row text, but still require exactly three usable
        // numeric values after bookmaker identification.
        return ODDS_NUMBER.findAll(row.wholeText()).map { it.value }.toList()
    }

    private fun cleanOdd(value: String): String? {
        val normalized = value.replace(',', '.').trim()
        val number = normalized.toDoubleOrNull() ?: return null
        if (number <= 1.0 || number > 100.0) return null
        return String.format(Locale.US, "%.2f", number)
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("https?://|www\\."), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private val ODDS_NUMBER = Regex("(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])")
        private val GENERIC_TEAM_PREFIXES = setOf(
            "fc", "cf", "cd", "sc", "ac", "afc", "fk", "sk", "club", "clube",
            "deportivo", "deportiva", "deportes", "football", "soccer"
        )
    }
}
