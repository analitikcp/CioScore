# CioScore Version Policy

- Current release: **0.9.26**
- Android `versionName`: **0.9.26**
- Android `versionCode`: **300**
- `PROJECT_VERSION.txt`: **0.9.26**
- `BUILD_VERSION.txt`: **0.9.26**

All active build metadata and CI checks must use the values above.

Historical development notes from the former `0.25.x` and `0.9.24` lines are retained only under `docs/archive/legacy-version-notes/` and are not active build metadata.
