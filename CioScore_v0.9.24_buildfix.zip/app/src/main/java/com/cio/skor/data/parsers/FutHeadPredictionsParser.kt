package com.cio.skor.data.parsers

import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** FutHead Predictions: event rows contain score + Time + Date + Details. */
class FutHeadPredictionsExactScoreParser : BaseParser("FutHead Predictions") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, li, div[class*=event], div[class*=match], [class*=prediction]")
            .filter { it.text().contains(Regex("(?i)\\bTime\\s*:|\\bDate\\s*:|\\bPredict\\b")) }
            .sortedBy { it.text().length }
        for (scope in scopes) {
            val text = clean(scope.text())
            if (!Regex("(?i)\\bTime\\s*:\\s*(?:[01]?[0-9]|2[0-3]):[0-5][0-9]").containsMatchIn(text)) continue
            if (!Regex("(?i)\\bDate\\s*:\\s*[0-9]{2}\\.[0-9]{2}\\.[0-9]{2,4}").containsMatchIn(text)) continue
            val score = Regex("(?i)\\b(?:Predict|Score)\\b[^0-9]{0,20}([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})\\b").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
                ?: scorePair(text.substringBefore("Time:"))
                ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "FutHead Predictions", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}
