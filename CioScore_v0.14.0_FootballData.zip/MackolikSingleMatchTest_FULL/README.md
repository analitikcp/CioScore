# CioScore v0.14.0 — Football-Data Historical Model

Bu sürüm CioScore'un 5 kaynaklı tahmin konsensüsünü Football-Data.co.uk tarihsel takım modeliyle birleştirir.

## Yeni matematik
- CIO1-CIO5: dış skor tahmini konsensüsü.
- Football-Data: geçmiş ev/deplasman maçları, gol üretimi/yenilen gol, puan/maç, kazanma oranı ve mevcutsa isabetli şut verileri.
- Basit Poisson gol modeli ile tarihsel 1X2 olasılığı üretilir.
- Nihai **MODEL OLASILIK** = %55 CIO konsensüsü + %45 Football-Data tarihsel modeli.
- Maçkolik oranı model olasılığının içine katılmaz; bağımsız piyasa karşılaştırması olarak kalır.
- VALUE = MODEL OLASILIK × decimal oran − 1 (EV).
- CioScore = güven/konsensüs endeksidir; literal kazanma olasılığı değildir.

## Veri akışı
CIO1-CIO5 → MatchMerger → Football-Data tarihsel model + Maçkolik → CioScore → MODEL OLASILIK / EV.

Football-Data CSV dosyaları ilk kullanımda indirilir ve 12 saatlik cihaz cache'i ile tekrar kullanılır. Güncel + önceki sezon temel alınır. Veriler yalnızca hedef maçtan önce oynanmış maçlardan kullanılır.

## Kartta artık
- CioScore / güven
- MODEL OLASILIK
- TARİHSEL MODEL: lig, güven, gol beklentisi
- CIO KONSENSÜSÜ
- PİYASA
- VALUE (EV)
- ORAN ÇELİŞKİSİ
- CIO skor konsensüsü
- Maçkolik MS 1X2 oranları

## Not
Football-Data doğrudan xG sağlamaz. Bu sürümdeki "gol beklentisi" takımın geçmiş gol oranlarından türetilen Poisson λ değeridir; gerçek sağlayıcı xG'si değildir.

Sürüm: 0.14.0 / versionCode 120
