package com.cio.skor.data

/**
 * CioScore 2.1
 *
 * CIO1-5 = external prediction consensus.
 * Football-Data = historical team-strength / goal model.
 * Market odds are kept OUT of the model probability to avoid circular value.
 *
 * Therefore:
 *   model probability = CIO consensus + Football-Data historical model
 *   value (EV) = model probability * current decimal odds - 1
 *
 * CioScore itself remains a confidence/strength index, not a literal win probability.
 */
object CioScoreEngine {
    data class ScoreConsensus(val score: String, val count: Int, val percent: Int)

    data class Result(
        val score: Int,
        val confidence: String,
        val exactConsensus: Int,
        val outcomeConsensus: Int,
        val marketConfidence: Int,
        val directionAgreement: Int,
        val sourceCoverage: Int,
        val topScores: List<ScoreConsensus>,
        val cioProbabilities: Map<String, Int>,
        val historicalProbabilities: Map<String, Int>,
        val modelProbabilities: Map<String, Int>,
        val marketProbabilities: Map<String, Int>,
        val value: Map<String, Int>,
        val bestValueDirection: String?,
        val bestValuePoints: Int,
        val marketMismatch: Int,
        val historicalConfidence: Int,
        val historicalLabel: String?,
        val expectedGoals: Pair<Double, Double>?
    )

    fun calculate(
        predictions: List<ScoreModel>,
        odds: SofaScoreService.Odds?,
        historical: FootballDataService.MatchContext? = null
    ): Result {
        if (predictions.isEmpty()) {
            return Result(
                score = 0, confidence = "Düşük", exactConsensus = 0, outcomeConsensus = 0,
                marketConfidence = 0, directionAgreement = 0, sourceCoverage = 0, topScores = emptyList(),
                cioProbabilities = emptyMap(), historicalProbabilities = emptyMap(), modelProbabilities = emptyMap(),
                marketProbabilities = emptyMap(), value = emptyMap(), bestValueDirection = null,
                bestValuePoints = 0, marketMismatch = 0, historicalConfidence = 0,
                historicalLabel = null, expectedGoals = null
            )
        }

        val n = predictions.size.toDouble()
        val scoreCounts = predictions
            .map { it.predictedScore.trim() }
            .filter { Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").matches(it) }
            .groupingBy { it }
            .eachCount()

        val exactMax = scoreCounts.values.maxOrNull() ?: 0
        val exact = exactMax / n
        val topScores = scoreCounts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(3)
            .map { ScoreConsensus(it.key, it.value, (it.value / n * 100.0).toInt()) }

        val outcomes = predictions.mapNotNull { outcome(it.predictedScore) }
        val outcomeCounts = outcomes.groupingBy { it }.eachCount()
        val outcomeMax = outcomeCounts.values.maxOrNull() ?: 0
        val outcome = if (outcomes.isEmpty()) 0.0 else outcomeMax / outcomes.size.toDouble()
        val cioProb = outcomeProbabilities(outcomes)

        val historicalProb = historical?.probabilities ?: emptyMap()
        val histConfidence = historical?.confidence ?: 0

        // Do NOT feed market odds into model probability. That would make EV circular.
        // With historical data available, CIO consensus and Football-Data each carry
        // meaningful weight; otherwise the model gracefully falls back to CIO only.
        val modelProb = blendProbabilities(cioProb, historicalProb, historical != null)

        val market = odds?.let { marketProbabilities(it) }
        val marketConfidence = market?.values?.maxOrNull() ?: 0.0
        val modelDirection = modelProb.maxByOrNull { it.value }?.key
        val marketDirection = market?.maxByOrNull { it.value }?.key
        val agreement = if (modelDirection != null && marketDirection != null && modelDirection == marketDirection) 1.0 else 0.0

        val sourceCoverage = (predictions.map { it.source.trim().lowercase() }.distinct().size / 5.0).coerceIn(0.0, 1.0)
        val stability = if (outcomes.isEmpty()) 0.0 else outcomeCounts.values.maxOrNull()!!.toDouble() / outcomes.size.toDouble()

        // Historical data is a first-class signal, but CioScore is still a confidence index.
        val raw = if (historical != null) {
            15.0 * exact +
                15.0 * outcome +
                25.0 * (histConfidence / 100.0) +
                10.0 * marketConfidence +
                15.0 * agreement +
                10.0 * sourceCoverage +
                10.0 * stability
        } else {
            25.0 * exact +
                20.0 * outcome +
                15.0 * marketConfidence +
                15.0 * agreement +
                10.0 * sourceCoverage +
                15.0 * stability
        }

        val score = raw.coerceIn(0.0, 100.0).toInt()
        val confidence = when {
            score >= 80 -> "Yüksek"
            score >= 65 -> "Orta-Yüksek"
            score >= 50 -> "Orta"
            else -> "Düşük"
        }

        val marketMap = market?.mapValues { (it.value * 100.0).toInt() } ?: emptyMap()
        val cioMap = cioProb.mapValues { (it.value * 100.0).toInt() }
        val histMap = historicalProb.mapValues { (it.value * 100.0).toInt() }
        val modelMap = modelProb.mapValues { (it.value * 100.0).toInt() }

        val valueMap = if (market != null) {
            val decimalOdds = mapOf("1" to odds.home, "X" to odds.draw, "2" to odds.away)
                .mapValues { it.value.toDoubleOrNull() ?: 0.0 }
            listOf("1", "X", "2").associateWith { direction ->
                val p = modelProb[direction] ?: 0.0
                val odd = decimalOdds[direction] ?: 0.0
                if (p > 0.0 && odd > 1.0) (p * odd - 1.0) * 100.0 else 0.0
            }.mapValues { kotlin.math.round(it.value).toInt() }
        } else emptyMap()

        val best = valueMap.maxByOrNull { it.value }
        val maxAbsMismatch = if (market != null) {
            listOf("1", "X", "2").maxOfOrNull { direction ->
                kotlin.math.abs((modelProb[direction] ?: 0.0) - (market[direction] ?: 0.0)) * 100.0
            }?.toInt() ?: 0
        } else 0

        return Result(
            score = score,
            confidence = confidence,
            exactConsensus = (exact * 100).toInt(),
            outcomeConsensus = (outcome * 100).toInt(),
            marketConfidence = (marketConfidence * 100).toInt(),
            directionAgreement = (agreement * 100).toInt(),
            sourceCoverage = (sourceCoverage * 100).toInt(),
            topScores = topScores,
            cioProbabilities = cioMap,
            historicalProbabilities = histMap,
            modelProbabilities = modelMap,
            marketProbabilities = marketMap,
            value = valueMap,
            bestValueDirection = best?.key,
            bestValuePoints = best?.value ?: 0,
            marketMismatch = maxAbsMismatch,
            historicalConfidence = histConfidence,
            historicalLabel = historical?.league,
            expectedGoals = historical?.let { it.homeExpectedGoals to it.awayExpectedGoals }
        )
    }

    private fun blendProbabilities(
        cio: Map<String, Double>,
        historical: Map<String, Double>,
        hasHistorical: Boolean
    ): Map<String, Double> {
        if (!hasHistorical || historical.isEmpty()) return normalize(cio)
        // Slightly favor the live five-source consensus, while historical performance
        // prevents a single unusual prediction source from dominating the result.
        val out = listOf("1", "X", "2").associateWith { k ->
            0.55 * (cio[k] ?: 0.0) + 0.45 * (historical[k] ?: 0.0)
        }
        return normalize(out)
    }

    private fun normalize(values: Map<String, Double>): Map<String, Double> {
        val total = values.values.sum()
        if (total <= 0.0) return mapOf("1" to 1.0 / 3, "X" to 1.0 / 3, "2" to 1.0 / 3)
        return values.mapValues { it.value / total }
    }

    private fun outcomeProbabilities(outcomes: List<String>): Map<String, Double> {
        if (outcomes.isEmpty()) return mapOf("1" to 1.0 / 3, "X" to 1.0 / 3, "2" to 1.0 / 3)
        val counts = outcomes.groupingBy { it }.eachCount()
        val prior = 0.5
        val denominator = outcomes.size + prior * 3.0
        return listOf("1", "X", "2").associateWith { key ->
            ((counts[key] ?: 0) + prior) / denominator
        }
    }

    private fun marketProbabilities(odds: SofaScoreService.Odds): Map<String, Double>? {
        val values = listOf(odds.home.toDoubleOrNull(), odds.draw.toDoubleOrNull(), odds.away.toDoubleOrNull())
        if (values.any { value -> value == null || value <= 1.0 }) return null
        val raw = values.map { 1.0 / (it ?: return null) }
        val total = raw.sum()
        if (total <= 0.0) return null
        return mapOf("1" to raw[0] / total, "X" to raw[1] / total, "2" to raw[2] / total)
    }

    private fun outcome(score: String): String? {
        val m = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = m.groupValues[1].toIntOrNull() ?: return null
        val away = m.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }
}
