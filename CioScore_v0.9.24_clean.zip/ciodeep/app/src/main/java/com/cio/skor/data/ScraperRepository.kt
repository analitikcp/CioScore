package com.cio.skor.data

import com.cio.skor.data.SourceResult
import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.CancellationException
import java.util.concurrent.atomic.AtomicInteger
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import org.jsoup.Jsoup

/** Configured score-prediction sources; official iddaa.com remains the authoritative fixture source. */
class ScraperRepository {
    data class Source(
        val name: String,
        val url: String,
        val parser: BaseParser,
        val fallbackUrls: List<String> = emptyList()
    )

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/us/picks/today/correct-score/", PredictZParser(), fallbackUrls = listOf("https://www.predictz.com/predictions/today/correct-score/fixed/")),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Sports Mole", "https://www.sportsmole.co.uk/football/preview/", SportsMoleExactScoreParser()),
        Source("BallPrediction", "https://ballprediction.com/", BallPredictionExactScoreParser()),
        Source("Correct-Score.net", "https://www.correct-score.net/en/", CorrectScoreNetParser(), fallbackUrls = listOf("https://www.correct-score.net/en/predictions/")),
        Source("FootballScorePredictor", "https://www.footballscorepredictor.com/correct-score-predictions/", FootballScorePredictorParser()),
        Source("AccurateTip", "https://www.accuratetip.com/correct-score-predictions", AccurateTipExactScoreParser()),
        Source("FutHead Predictions", "https://www.futheadpredictions.com/football-predictions/correct-score/", FutHeadPredictionsExactScoreParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val completedCount = AtomicInteger(0)
        val results = sources.map { source ->
            async(Dispatchers.IO) {
                val startTime = System.currentTimeMillis()
                val result = try {
                    val referer = when (source.name) {
                        "DailySports" -> "https://dailysports.net/"
                        "FP.com" -> "https://footballpredictions.com/betting-tips/"
                        "PredictZ" -> "https://www.predictz.com/"
                        "WinDrawWin" -> "https://www.windrawwin.com/"
                        "Sports Mole" -> "https://www.sportsmole.co.uk/football/preview/"
                        "BallPrediction" -> "https://ballprediction.com/"
                        "Correct-Score.net" -> "https://www.correct-score.net/en/"
                        "FootballScorePredictor" -> "https://www.footballscorepredictor.com/"
                        "AccurateTip" -> "https://www.accuratetip.com/"
                        "FutHead Predictions" -> "https://www.futheadpredictions.com/"
                        else -> null
                    }
                    // Prediction sites are public HTML pages but several of them
                    // serve different markup to lightweight/mobile clients. Use the
                    // browser-profile fetcher here instead of the old fast client.
                    // IMPORTANT: the timeout belongs to THIS child coroutine.
                    val sourceTimeoutMs = if (source.name == "Sports Mole") 40_000L else 20_000L
                    val fetched = withTimeout(sourceTimeoutMs + 12_000L) {
                        withContext(Dispatchers.IO) {
                            fetchSourceWithFallbacks(
                                source = source,
                                referer = referer ?: source.url,
                                attempts = 2
                            )
                        }
                    }
                    val code = fetched.first
                    val html = fetched.second
                    var fetchedUrl = fetched.third
                    val rawBytes = html?.toByteArray(Charsets.UTF_8)?.size ?: 0
                    val isHttpSuccess = code in 200..299 && !html.isNullOrBlank()
                    if (!isHttpSuccess) {
                        // Transport/HTTP failures are kept separate from parser failures.
                        // A parser exception must never masquerade as HTTP -1.
                        SourceResult(
                            source = source.name,
                            httpCode = code,
                            scores = emptyList(),
                            error = "HTTP_$code",
                            durationMs = System.currentTimeMillis() - startTime,
                            rawHtmlBytes = rawBytes,
                            fetchedUrl = fetchedUrl
                        )
                    } else {
                        try {
                            val document = Jsoup.parse(html, fetchedUrl.ifBlank { source.url })
                            var scores = if (source.name == "Sports Mole") {
                                sanitizeParsedScores(source.name, parseSportsMoleIndex(html.orEmpty(), source.parser))
                            } else {
                                sanitizeParsedScores(source.name, source.parser.parse(document))
                            }

                            // v0.9.17: HTTP 200 does not mean the provider's
                            // current DOM selector still found the prediction.
                            // Run only provider-specific DOM recovery rules.
                            if (scores.isEmpty() && source.name != "Sports Mole") {
                                scores = sanitizeParsedScores(
                                    source.name,
                                    SourceRecoveryParsers.parse(source.name, document)
                                )
                            }

                            // A source fallback is also tried when the primary
                            // page is reachable but its markup no longer exposes
                            if (scores.isEmpty() && source.fallbackUrls.isNotEmpty()) {
                                for (fallbackUrl in source.fallbackUrls) {
                                    val fallbackFetched = fetchUrl(fallbackUrl, referer ?: source.url)
                                    val fallbackCode = fallbackFetched.first
                                    val fallbackHtml = fallbackFetched.second
                                    if (fallbackCode !in 200..299 || fallbackHtml.isNullOrBlank()) continue
                                    val fallbackDoc = Jsoup.parse(fallbackHtml, fallbackUrl)
                                    val parsed = source.parser.parse(fallbackDoc)
                                    val recovered = sanitizeParsedScores(
                                        source.name,
                                        parsed + SourceRecoveryParsers.parse(source.name, fallbackDoc)
                                    )
                                    if (recovered.isNotEmpty()) {
                                        scores = recovered
                                        // The diagnostics must identify the endpoint whose
                                        // HTML actually produced the accepted rows.
                                        fetchedUrl = fallbackUrl
                                        break
                                    }
                                }
                            }
                            SourceResult(
                                source = source.name,
                                httpCode = code,
                                scores = scores,
                                error = if (scores.isEmpty()) "DOM_CHANGED_OR_EMPTY" else null,
                                durationMs = System.currentTimeMillis() - startTime,
                                rawHtmlBytes = rawBytes,
                                fetchedUrl = fetchedUrl
                            )
                        } catch (e: Exception) {
                            SourceResult(
                                source = source.name,
                                httpCode = code,
                                scores = emptyList(),
                                error = "PARSER_${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown parser error"}",
                                durationMs = System.currentTimeMillis() - startTime,
                                rawHtmlBytes = rawBytes,
                                fetchedUrl = fetchedUrl
                            )
                        }
                    }
                } catch (e: TimeoutCancellationException) {
                    // TimeoutCancellationException is normally a CancellationException,
                    // but this one belongs to our local withTimeout and MUST be contained.
                    val timeoutLabel = if (source.name == "Sports Mole") "TIMEOUT_52S" else "TIMEOUT_32S"
                    SourceResult(
                        source = source.name,
                        httpCode = -2,
                        scores = emptyList(),
                        error = timeoutLabel,
                        durationMs = System.currentTimeMillis() - startTime
                    )
                } catch (e: CancellationException) {
                    // Only a cancellation coming from outside this source's local
                    // timeout may cancel the child/parent scan.
                    throw e
                } catch (e: Exception) {
                    SourceResult(
                        source = source.name,
                        httpCode = -1,
                        scores = emptyList(),
                        error = "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown error"}",
                        durationMs = System.currentTimeMillis() - startTime
                    )
                }

                onProgress(completedCount.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()

        // Diagnostic only: observe each source result without changing behavior.
        val sourceCounts = results.associate { result ->
            result.source to result.scores.size
        }
        PipelineDiagnostics.log(
            sourceCounts = sourceCounts,
            rawPredictions = results.sumOf { it.scores.size }
        )

        results
    }

    /**
     * Final parser contract: only complete exact scores with plausible team
     * names leave the source boundary. This does not create predictions; it only
     * rejects malformed parser output before global fixture matching.
     */
    private fun sanitizeParsedScores(source: String, parsed: List<ScoreModel>): List<ScoreModel> =
        parsed.asSequence()
            .filter { it.source.equals(source, ignoreCase = true) }
            .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
            .filter { it.homeTeam.isNotBlank() && it.awayTeam.isNotBlank() }
            .filter { !it.homeTeam.equals(it.awayTeam, ignoreCase = true) }
            .distinctBy {
                val date = it.matchDate.ifBlank { "?" }
                val time = it.matchTime.ifBlank { "--:--" }
                "${it.homeTeam.trim().lowercase()}|${it.awayTeam.trim().lowercase()}|$date|$time|${it.predictedScore}"
            }
            .toList()

    /**
     * Short, source-isolated retry. Retry only transient transport/server failures;
     * never hammer a deterministic 404/403 page. The parser is still run only once
     * against the final successful body, so one source cannot poison the scan.
     */
    private fun fetchSourceWithRetry(
        url: String,
        referer: String,
        attempts: Int
    ): Pair<Int, String?> {
        var last: Pair<Int, String?> = -1 to null
        repeat(attempts.coerceIn(1, 2)) { attempt ->
            last = http.getSource(url, referer)
            val code = last.first
            val transient = code == -1 || code == -2 || code == -100 || code == -101 || code == -102 || code == 408 || code == 429 || code >= 500
            if (!transient || last.second?.isNotBlank() == true && code in 200..299) return last
            if (attempt + 1 < attempts) {
                try { Thread.sleep(500L) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            }
        }
        return last
    }

    /**
     * Sports Mole's /football/preview/ page is an index: exact scores live in the
     * linked preview articles as a "We say:" sentence. Fetch only the preview
     * links present on the index, dedupe them, and let the source parser consume
     * each article. This avoids treating the index as if it were a fixture card.
     */
    /**
     * Provider-specific URL chain. A source may expose the same exact-score
     * dataset through a public history/archive endpoint when the landing page
     * is empty or its layout changes. We only try URLs explicitly declared for
     * that provider; there is still no generic parser fallback.
     */
    private fun fetchUrl(url: String, referer: String): Pair<Int, String?> =
        http.getSource(url, referer)

    private fun fetchSourceWithFallbacks(
        source: Source,
        referer: String,
        attempts: Int
    ): Triple<Int, String?, String> {
        var lastCode = -1
        var lastBody: String? = null
        var lastUrl = source.url
        val urls = listOf(source.url) + source.fallbackUrls
        for (url in urls.distinct()) {
            val (code, body) = fetchSourceWithRetry(url, refererFor(url, referer), attempts)
            lastCode = code
            lastBody = body
            lastUrl = url
            if (code in 200..299 && !body.isNullOrBlank()) {
                return Triple(code, body, url)
            }
            // Deterministic HTTP errors should not cause unrelated endpoints to
            // be hammered; fallback is intended for stale/empty public pages.
            if (code in 401..403 || code == 404 || code == 410) continue
        }
        return Triple(lastCode, lastBody, lastUrl)
    }

    private fun refererFor(url: String, fallback: String): String =
        runCatching {
            val uri = java.net.URI(url)
            "${uri.scheme}://${uri.host}/"
        }.getOrDefault(fallback)

    private suspend fun parseSportsMoleIndex(indexHtml: String, parser: BaseParser): List<ScoreModel> = coroutineScope {
        val doc = Jsoup.parse(indexHtml, "https://www.sportsmole.co.uk/football/preview/")
        val links = doc.select("a[href]")
            .mapNotNull { a ->
                val href = a.absUrl("href").ifBlank { a.attr("href") }
                val title = a.text().trim()
                if (href.contains("/football/") && href.contains("/preview/") &&
                    href.contains("-prediction-team-news-lineups_")) href to title else null
            }
            .distinctBy { it.first }
            .take(30)

        val parsed = links.chunked(6).flatMap { batch ->
            batch.map { (url, _) ->
                async(Dispatchers.IO) {
                    try {
                        val (code, body) = withTimeout(8_000L) {
                            http.getSource(url, "https://www.sportsmole.co.uk/football/preview/")
                        }
                        if (code !in 200..299 || body.isNullOrBlank()) return@async emptyList()
                        parser.parse(Jsoup.parse(body, url))
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
        }
        parsed.distinctBy { it.sourceMatchId.ifBlank { it.matchKey } }
    }

}
