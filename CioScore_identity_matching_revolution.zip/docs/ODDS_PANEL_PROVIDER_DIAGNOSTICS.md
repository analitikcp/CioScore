# ORANLAR Paneli — Provider Bağımsız Teşhis v0.24.89

`v0.24.88` master davranışı korunmuştur. Bu sürümde yalnızca ORANLAR panelinin
Bet365 lookup katmanı güçlendirilmiştir.

## Korunan davranış

- Ana maç kartındaki İddaa + Bet365 oranları aynı zinciri kullanmaya devam eder.
- ORANLAR butonu ayrı bir panel açar.
- Panel ana kartın odds queue'suna bağlı değildir.
- Resmî İddaa doğrulama ve ScoreModel zincirine dokunulmamıştır.

## Yeni yapı

Panel provider listesi `OddsPanelService.supportedBookmakers()` üzerinden tutulur.
Yeni bir bookmaker ekleneceği zaman ana kart renderer'ına dokunmadan bu katmana
provider eklenebilir.

Bet365 panel lookup'ı kaynak bilgisini de taşır:

`GoalLineExpert → SofaScore → Flashscore → WinComparator`

Başarılı olduğunda panel, örneğin `Kaynak: GoalLineExpert` şeklinde hangi
kaynağın değeri sağladığını gösterir. Başarısız olduğunda hangi kaynakların
denendiği görünür.

## Cache

Panelde aynı maç tekrar açılırsa 5 dakikalık bellek cache'i kullanılır. Bu,
ORANLAR butonuna art arda basıldığında aynı ağ isteğinin tekrarlanmasını önler.
Cache yalnızca panel lookup'ına aittir; ana kart odds cache/queue davranışını
değiştirmez.
