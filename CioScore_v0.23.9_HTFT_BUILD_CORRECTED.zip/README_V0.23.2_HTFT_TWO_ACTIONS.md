# CioScore v0.23.2 — HT/FT Two-Action Match Tap

When a user taps an HT/FT match card, the app now presents exactly two actions:

1. **İddaa.com / Uygulama** — opens the official iddaa HTTPS program route with the official match date and event ID as context. Android can hand the URL to the installed official iddaa app when it is registered for the link; otherwise the browser opens iddaa.com.
2. **Skor Analizine Git** — returns to the existing MainActivity instance and focuses the selected fixture in the score-analysis list.

The previous one-action behavior (immediately returning to the score-analysis screen) is removed.

The official Iddaa app package is `com.iddaa.app`.
