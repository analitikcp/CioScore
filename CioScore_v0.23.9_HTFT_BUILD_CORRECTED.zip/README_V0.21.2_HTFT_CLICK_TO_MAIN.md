# v0.21.2 – HT/FT Maçtan Ana Karta Geçiş

Bu sürüm v0.21.0 ZIP'i baz alınarak hazırlanmıştır. Önceki ZIP'ler baz alınmamıştır.

## Akış
HT/FT Açılan Maçlar → maç satırına dokun → mevcut MainActivity'ye dön → seçilen ev/deplasman takımını Intent ile taşı → ana listedeki aynı fixture'ı canonical team identity ile tek karta indir ve ilk sıraya getir.

## Teknik
- HtFtOpenedMatchesActivity: satır click -> Intent extras + CLEAR_TOP/SINGLE_TOP -> finish()
- MainActivity: onNewIntent + pending target + scan tamamlandıktan sonra focus
- ScoreAdapter: focusOnMatch(home, away) exact canonical team ID eşleşmesi
- Mevcut GlobalFixtureMatcher / MatchMerger mimarisi değiştirilmedi.
