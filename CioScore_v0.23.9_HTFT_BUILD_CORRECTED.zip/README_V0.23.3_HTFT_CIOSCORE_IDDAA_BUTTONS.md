# CioScore v0.23.3 — HT/FT Two Action Buttons

When an HT/FT match card is tapped, a dialog opens with exactly two visible actions:
- **CioScore** (left): opens the selected match in the existing score-analysis flow.
- **İddaa** (right): opens the official Iddaa route.

The previous single-tap behavior is replaced by this explicit choice.
