# CioScore v0.23.1 — 5 Kaynak Konsensüs Skoru

- Main score cards now show `📌 KONSENSÜS SKOR`.
- A consensus score is displayed only when all five configured score sources return the exact same score:
  FP.com, PredictZ, WinDrawWin, SoccerSeer, DailySports.
- A consensus is shown when at least 2 different score sources return the same exact score. Missing sources do not invalidate a 2+ source consensus.
- Source matching is case-insensitive and duplicate records from the same source do not count as additional consensus votes.
- No majority/3-of-5 fallback is used; this is intentionally strict 5/5 consensus.
- The removed Popular Bets module remains removed.


## v0.23.1 consensus rule
- Consensus is shown when at least 2 distinct configured sources return the exact same score.
- Missing sources do not invalidate a 2+ source agreement.
- If two or more scores tie for the highest count, all tied scores are displayed (for example `2-1 / 1-1`).
- If no score reaches 2 independent sources, the card displays `KONSENSÜS SKOR: YOK`. If multiple scores tie for the highest count (for example 2-1 and 1-1 both appear twice), all tied scores are shown.
