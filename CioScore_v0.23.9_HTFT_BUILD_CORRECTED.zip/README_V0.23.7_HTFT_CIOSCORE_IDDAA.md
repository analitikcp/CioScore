# CioScore v0.23.7

HT/FT Opened Matches cards now contain two always-visible buttons directly below the HT/FT odds:

- **CioScore** (left): returns the selected fixture to the existing MainActivity score-analysis target flow.
- **İddaa** (right): opens the official iddaa.com program URL using the match date and event id.

No AlertDialog or hidden action row is used.
