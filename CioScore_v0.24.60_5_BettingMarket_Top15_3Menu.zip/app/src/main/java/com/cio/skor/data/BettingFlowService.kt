package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Betting-intelligence layer. The four providers deliberately remain separate:
 * their samples overlap, so their volumes must never simply be summed.
 */
class BettingFlowService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private val providers: List<BettingFlowProvider> = listOf(
        ActionNetworkProvider(client),
        BetfairProvider(),
        SportradarProvider(),
        BsdWeightOfMoneyProvider(),
        OddsMonitorProvider(),
        OddsPortalProvider()
    )

    suspend fun fetchToday(): BettingFlowSnapshot = withContext(Dispatchers.IO) {
        val zone = ZoneId.of("Europe/Istanbul")
        val now = java.time.ZonedDateTime.now(zone)
        val bulletinDate = if (now.toLocalTime().isBefore(java.time.LocalTime.of(6, 0))) {
            now.toLocalDate().minusDays(1)
        } else now.toLocalDate()
        fetchForDate(bulletinDate.format(DateTimeFormatter.ISO_LOCAL_DATE))
    }

    suspend fun fetchForDate(bulletinDate: String): BettingFlowSnapshot = coroutineScope {
        val results = providers.map { provider ->
            async(Dispatchers.IO) { runCatching { provider.fetch(bulletinDate) }.getOrElse { ProviderResult(provider.name, error = it.message) } }
        }.awaitAll()
        val flows = results.flatMap { it.flows }
        BettingFlowSnapshot(
            flows = flows,
            providerCount = providers.size,
            activeProviderCount = results.count { it.flows.isNotEmpty() },
            capturedAt = results.maxOfOrNull { it.capturedAt } ?: System.currentTimeMillis(),
            bulletinDate = bulletinDate,
            errors = results.mapNotNull { it.error }
        )
    }

    fun topMoney(flows: List<BettingFlowModel>, limit: Int = 15): List<BettingFlowModel> =
        flows.sortedWith(compareByDescending<BettingFlowModel> { it.matchedVolume ?: -1.0 }
            .thenByDescending { it.moneySharePct ?: -1.0 })
            .distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.market}|${it.selection}" }
            .take(limit)

    fun topBets(flows: List<BettingFlowModel>, limit: Int = 15): List<BettingFlowModel> =
        flows.sortedWith(compareByDescending<BettingFlowModel> { it.betSharePct ?: -1.0 }
            .thenByDescending { it.moneySharePct ?: -1.0 })
            .distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.market}|${it.selection}" }
            .take(limit)

    fun topOddsMovement(flows: List<BettingFlowModel>, limit: Int = 15): List<BettingFlowModel> =
        flows.sortedWith(compareByDescending<BettingFlowModel> { kotlin.math.abs(it.oddsChange ?: 0.0) }
            .thenByDescending { it.moneySharePct ?: -1.0 })
            .distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.market}|${it.selection}" }
            .take(limit)

    private class ActionNetworkProvider(private val client: OkHttpClient) : BettingFlowProvider {
        override val name = "Action Network"
        override val description = "% Bets / % Money görünür futbol public-betting tablosu"
        override val requiresCredentials = false

        override suspend fun fetch(bulletinDate: String): ProviderResult = withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url("https://www.actionnetwork.com/soccer/public-betting")
                .header("User-Agent", "Mozilla/5.0 (Android) CioScore/0.24")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext ProviderResult(name, error = "HTTP ${response.code}")
                val html = response.body?.string().orEmpty()
                val doc = Jsoup.parse(html)
                val flows = mutableListOf<BettingFlowModel>()
                doc.select("table tr").forEach { row ->
                    val cells = row.select("th,td").map { it.text().trim() }.filter { it.isNotEmpty() }
                    if (cells.size < 5) return@forEach
                    val joined = cells.joinToString(" | ")
                    val pct = Regex("(\\d{1,3})%.*?(\\d{1,3})%").find(joined) ?: return@forEach
                    val bets = pct.groupValues[1].toDoubleOrNull() ?: return@forEach
                    val money = pct.groupValues[2].toDoubleOrNull() ?: return@forEach
                    val teams = cells.firstOrNull { it.contains(" vs ", true) || it.contains(" – ") } ?: return@forEach
                    val parts = Regex("\\s+(?:vs|–|-)\\s+", RegexOption.IGNORE_CASE).split(teams, limit = 2)
                    if (parts.size != 2) return@forEach
                    val selection = cells.firstOrNull { it.equals("Draw", true) || it.equals("RSL", true) || it.equals("SEA", true) }
                        ?: "Market"
                    flows += BettingFlowModel(
                        homeTeam = parts[0].trim(),
                        awayTeam = parts[1].trim(),
                        market = "Public betting",
                        selection = selection,
                        moneySharePct = money,
                        betSharePct = bets,
                        source = name,
                        capturedAt = System.currentTimeMillis(),
                        sourceCoverage = "Action Network public sample",
                        bulletinDate = bulletinDate
                    )
                }
                ProviderResult(name, flows.distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.selection}" })
            }
        }
    }

    /** Credential-backed adapter. Kept isolated so API credentials never enter ScoreModel. */
    private class BetfairProvider : BettingFlowProvider {
        override val name = "Betfair Exchange"
        override val description = "Exchange traded volume / matched money"
        override val requiresCredentials = true
        override suspend fun fetch(bulletinDate: String) = ProviderResult(name, error = "Betfair API anahtarı yapılandırılmadı")
    }

    private class SportradarProvider : BettingFlowProvider {
        override val name = "Sportradar"
        override val description = "150+ bookmaker aggregate: ticket % / stake %"
        override val requiresCredentials = true
        override suspend fun fetch(bulletinDate: String) = ProviderResult(name, error = "Sportradar Betting Splits erişimi yapılandırılmadı")
    }

    private class BsdWeightOfMoneyProvider : BettingFlowProvider {
        override val name = "BSD Weight of Money"
        override val description = "Selection matched volume / market share / odds movement"
        override val requiresCredentials = true
        override suspend fun fetch(bulletinDate: String) = ProviderResult(name, error = "BSD Weight of Money token yapılandırılmadı")
    }

    private class OddsMonitorProvider : BettingFlowProvider {
        override val name = "OddsMonitor.eu"
        override val description = "Matched volume / Back-Lay pressure / Money / Δ Money"
        override val requiresCredentials = true
        override suspend fun fetch(bulletinDate: String) = ProviderResult(name, error = "OddsMonitor.eu erişim yöntemi yapılandırılmadı")
    }

    private class OddsPortalProvider : BettingFlowProvider {
        override val name = "OddsPortal Dropping Odds"
        override val description = "Bookmaker bazlı oran düşüşü ve hareket yoğunluğu"
        override val requiresCredentials = false
        override suspend fun fetch(bulletinDate: String) = ProviderResult(name, error = "OddsPortal Dropping Odds için izinli veri erişimi yapılandırılmadı")
    }
}
