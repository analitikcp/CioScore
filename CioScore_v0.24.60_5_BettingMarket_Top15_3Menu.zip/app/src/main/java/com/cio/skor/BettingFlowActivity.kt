package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Button
import android.view.View
import androidx.core.view.WindowCompat
import com.cio.skor.data.BettingFlowModel
import com.cio.skor.data.BettingFlowService
import kotlinx.coroutines.*
import java.text.NumberFormat
import java.util.Locale

class BettingFlowActivity : Activity() {
    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_MONEY = "money"
        const val MODE_BETS = "bets"
        const val MODE_ODDS = "odds"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = BettingFlowService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 28, 20, 20) }
        val title = TextView(this).apply { textSize = 21f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0,0,0,8) }
        val subtitle = TextView(this).apply { textSize = 12f; gravity = Gravity.CENTER; setPadding(0,0,0,10) }
        val progress = ProgressBar(this)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(title)
        root.addView(subtitle)
        root.addView(progress)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_MONEY
        val moneyMode = mode == MODE_MONEY
        val betsMode = mode == MODE_BETS
        title.text = when (mode) {
            MODE_MONEY -> "💰 EN ÇOK PARA AKIŞI • TOP 15"
            MODE_BETS -> "🎟️ EN ÇOK BAHİS OYNANAN • TOP 15"
            else -> "📉 EN ÇOK ORAN HAREKETİ • TOP 15"
        }
        subtitle.text = "Resmî İddaa 06:00 → ertesi gün 06:00 penceresi • kaynaklar ayrı tutulur"

        scope.launch {
            val snapshot = withContext(Dispatchers.IO) { service.fetchToday() }
            progress.visibility = View.GONE
            val rows = when {
                moneyMode -> service.topMoney(snapshot.flows)
                betsMode -> service.topBets(snapshot.flows)
                else -> service.topOddsMovement(snapshot.flows)
            }
            if (rows.isEmpty()) {
                list.addView(TextView(this@BettingFlowActivity).apply {
                    text = "Şu anda kullanılabilir canlı bahis-akışı verisi bulunamadı.\n\n" +
                        "Etkin kaynak: ${snapshot.activeProviderCount}/${snapshot.providerCount}\n" +
                        snapshot.errors.joinToString("\n")
                    textSize = 14f; gravity = Gravity.CENTER; setPadding(12, 30, 12, 30)
                })
                return@launch
            }
            rows.forEachIndexed { index, flow -> addRow(list, index + 1, flow, moneyMode, mode) }
            list.addView(TextView(this@BettingFlowActivity).apply {
                text = "\nVeri kapsamı: ${snapshot.activeProviderCount}/${snapshot.providerCount} kaynak.\nPara hacimleri kaynaklar arasında toplanmaz; örtüşme nedeniyle ayrı ölçümler korunur."
                textSize = 11f; setPadding(8, 16, 8, 20)
            })
        }
    }

    private fun addRow(parent: LinearLayout, rank: Int, flow: BettingFlowModel, moneyMode: Boolean, mode: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 }
        }
        val head = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; text = "$rank. ${flow.homeTeam} – ${flow.awayTeam}" }
        val choice = TextView(this).apply { textSize = 14f; text = "${flow.market} • ${flow.selection}" }
        val data = TextView(this).apply {
            textSize = 12f
            val money = flow.moneySharePct?.let { "💰 Para %${fmt(it)}" } ?: "💰 Para —"
            val bets = flow.betSharePct?.let { "🎟️ Bahis %${fmt(it)}" } ?: "🎟️ Bahis —"
            val volume = flow.matchedVolume?.let { " • Hacim ${NumberFormat.getNumberInstance(Locale.US).format(it)} ${flow.currency}" } ?: ""
            val odds = flow.currentOdds?.let { " • Oran ${fmt(it)}" } ?: ""
            val gap = flow.moneyBetGap?.let { " • Fark ${if (it >= 0) "+" else ""}${fmt(it)} puan" } ?: ""
            val movement = if (mode == MODE_ODDS && flow.currentOdds != null && flow.previousOdds != null) {
                val pct = if (flow.previousOdds != 0.0) ((flow.currentOdds - flow.previousOdds) / flow.previousOdds) * 100.0 else 0.0
                " • Hareket ${if (pct >= 0) "+" else ""}${fmt(pct)}%"
            } else ""
            text = "$money • $bets$volume$odds$gap$movement\nKaynak: ${flow.source}"
        }
        card.addView(head); card.addView(choice); card.addView(data)
        parent.addView(card)
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.1f", v)

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
