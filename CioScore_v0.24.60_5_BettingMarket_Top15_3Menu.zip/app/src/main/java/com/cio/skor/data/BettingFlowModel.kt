package com.cio.skor.data

/**
 * Normalized market-flow record. Percentages are source-reported shares, not
 * claims about every wager placed worldwide.
 */
data class BettingFlowModel(
    val homeTeam: String,
    val awayTeam: String,
    val market: String,
    val selection: String,
    val moneySharePct: Double? = null,
    val betSharePct: Double? = null,
    val matchedVolume: Double? = null,
    val currency: String = "",
    val currentOdds: Double? = null,
    val previousOdds: Double? = null,
    val source: String,
    val capturedAt: Long = 0L,
    val sourceCoverage: String = "",
    val bulletinDate: String = "",
    val kickoffMillis: Long = 0L
) {
    val oddsChange: Double?
        get() = if (currentOdds != null && previousOdds != null) currentOdds - previousOdds else null

    val moneyBetGap: Double?
        get() = if (moneySharePct != null && betSharePct != null) moneySharePct - betSharePct else null
}

data class BettingFlowSnapshot(
    val flows: List<BettingFlowModel>,
    val providerCount: Int,
    val activeProviderCount: Int,
    val capturedAt: Long,
    val bulletinDate: String,
    val errors: List<String> = emptyList()
)
