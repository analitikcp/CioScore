package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Replacement exact-score sources for providers that previously failed in the
 * live app. These sites publish an explicit Correct Score value in the public
 * daily listing, so we do not need a second detail-page request.
 */

class Tip724ExactScoreParser : BaseParser("Tip724") {
    override fun parse(doc: Document): List<ScoreModel> = parseCards(doc, "Tip724")

    private fun parseCards(doc: Document, source: String): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, li, tr, [class*=match], [class*=fixture], [class*=prediction], [class*=tip]")
            .filter { it.text().contains(Regex("(?i)correct score")) }
            .sortedBy { it.text().length }
        for (el in scopes) {
            val text = clean(el.text())
            if (text.length > 1400) continue
            val marker = Regex("(?i)(.+?)\\s+vs\\s+(.+?)\\s+-\\s*Correct Score prediction").find(text) ?: continue
            val scoreMatch = Regex("(?i)(?:Correct Score prediction|Correct Score)\\s*[^0-9]{0,80}(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?: scoreRegex.findAll(text).firstOrNull {
                    val h = it.groupValues[1].toIntOrNull() ?: -1
                    val a = it.groupValues[2].toIntOrNull() ?: -1
                    h in 0..20 && a in 0..20
                }
                ?: continue
            val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
            val item = modelWithMetadataNew(
                source,
                marker.groupValues[1],
                marker.groupValues[2],
                score,
                el,
                extractNearestCompetition(el)
            ) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

class AccurateTipExactScoreParser : BaseParser("AccurateTip") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, li, tr, [class*=match], [class*=fixture], [class*=prediction], main")
            .filter { it.text().contains(Regex("(?i)correct score")) }
            .sortedBy { it.text().length }
        for (el in scopes) {
            val text = clean(el.text())
            if (text.length > 1400) continue
            val m = Regex("(?is)(?:[A-Z][A-Z\\s-]{1,30}:\\s*)?(.+?)\\s+vs\\s+(.+?)(?:\\s+(?:[01]?\\d|2[0-3]):[0-5]\\d)?\\s+Correct Score\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?: continue
            val score = "${m.groupValues[3]}-${m.groupValues[4]}"
            val item = modelWithMetadataNew(
                "AccurateTip",
                m.groupValues[1],
                m.groupValues[2],
                score,
                el,
                extractNearestCompetition(el)
            ) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

private fun modelWithMetadataNew(
    source: String,
    home: String,
    away: String,
    score: String,
    scope: Element,
    competition: String = ""
): ScoreModel? {
    val h = cleanProviderTeamNew(home)
    val a = cleanProviderTeamNew(away)
    if (!looksLikeProviderTeamNew(h) || !looksLikeProviderTeamNew(a) || h.equals(a, true)) return null
    val parser = object : BaseParser(source) {
        override fun parse(doc: Document): List<ScoreModel> = emptyList()
    }
    val metadata = parser.extractFixtureMetadataForExternal(scope, competition)
    return ScoreModel(
        homeTeam = h,
        awayTeam = a,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = metadata.matchTimestamp,
        matchDate = metadata.matchDate,
        matchTime = metadata.matchTime,
        competitionName = metadata.competitionName,
        competitionCountry = metadata.competitionCountry
    )
}

private fun cleanProviderTeamNew(raw: String): String = raw
    .replace(Regex("(?i)\\b(?:correct score|prediction|predictions|tips?|image|time|date|details|odds)\\b.*$"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':')

private fun looksLikeProviderTeamNew(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.contains(Regex("(?i)^(time|date|details|correct score|prediction|predictions|odds|score|home|away|draw|vs)$"))) return false
    return true
}

private fun BaseParser.extractFixtureMetadataForExternal(scope: Element, competition: String): BaseParser.FixtureMetadata {
    return extractFixtureMetadata(scope).let { base ->
        if (base.competitionName.isNotBlank() || competition.isBlank()) base
        else mergeMetadata(base.matchDate, base.matchTime, competition, base.competitionCountry, base.rawDateTime)
    }
}
