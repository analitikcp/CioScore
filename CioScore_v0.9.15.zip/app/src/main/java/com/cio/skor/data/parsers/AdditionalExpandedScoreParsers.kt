package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * v0.9.14 expansion pool.
 *
 * These providers are intentionally parsed conservatively. A source is counted
 * as useful only when an exact-score marker and BOTH teams occur in the same
 * fixture scope. HTTP 200 alone never counts as a successful score source.
 */
class GenericExactScoreParser(sourceName: String) : BaseParser(sourceName) {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, tr, li, [class*=match], [class*=fixture], [class*=prediction], [class*=game], [class*=event]")
            .filter { it.text().length in 10..1800 }
            .sortedBy { it.text().length }

        for (scope in scopes) {
            val text = clean(scope.text())
            if (!hasPredictionMarker(text)) continue
            val score = findPredictionScore(text) ?: continue
            val teams = findTeams(scope, text) ?: continue
            val metadata = extractFixtureMetadata(scope)
            val competition = metadata.competitionName.ifBlank { extractNearestCompetition(scope) }
            val finalMetadata = if (competition.isBlank()) metadata else mergeMetadata(
                metadata.matchDate, metadata.matchTime, competition,
                metadata.competitionCountry, metadata.rawDateTime
            )
            val model = ScoreModel(
                homeTeam = teams.first,
                awayTeam = teams.second,
                predictedScore = score,
                source = source,
                sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
                matchTimestamp = finalMetadata.matchTimestamp,
                matchDate = finalMetadata.matchDate,
                matchTime = finalMetadata.matchTime,
                competitionName = finalMetadata.competitionName,
                competitionCountry = finalMetadata.competitionCountry
            )
            val safeModel = com.cio.skor.data.PredictionChainValidator.sanitize(model) ?: continue
            out.putIfAbsent(safeModel.source + "|" + safeModel.matchKey, safeModel)
        }
        return out.values.toList()
    }

    private fun hasPredictionMarker(text: String): Boolean = Regex(
        "(?i)(correct\\s*score|predicted\\s*score(?:line)?|full\\s*time\\s*result|score\\s*prediction|exact\\s*score|score\\s*tip)"
    ).containsMatchIn(text)

    private fun findPredictionScore(text: String): String? {
        val patterns = listOf(
            Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|full\\s*time\\s*result|score\\s*prediction|exact\\s*score|score\\s*tip)\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})"),
            Regex("(?i)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\s*(?:correct\\s*score|predicted\\s*score)")
        )
        for (pattern in patterns) {
            val m = pattern.find(text) ?: continue
            val h = m.groupValues[1].toIntOrNull() ?: continue
            val a = m.groupValues[2].toIntOrNull() ?: continue
            if (h in 0..20 && a in 0..20) return "$h-$a"
        }
        return null
    }

    private fun findTeams(scope: Element, text: String): Pair<String, String>? {
        val vs = Regex("(?is)(.{2,90}?)\\s+(?:\\bvs\\b|\\bv\\b)\\s+(.{2,90}?)(?=\\s+(?:correct\\s*score|predicted\\s*score|full\\s*time\\s*result|score\\s*prediction|exact\\s*score)|$)")
            .find(text)
        if (vs != null) {
            val h = cleanTeam(vs.groupValues[1])
            val a = cleanTeam(vs.groupValues[2])
            if (looksLikeTeam(h) && looksLikeTeam(a)) return h to a
        }

        val candidates = scope.select(
            "[class*=home], [class*=away], [class*=team], [class*=participant], [class*=club], td, th, a[href*=match], a[href*=fixture], a[href*=game]"
        ).map { cleanTeam(it.text()) }
            .filter(::looksLikeTeam)
            .distinct()
        if (candidates.size >= 2) return candidates[0] to candidates[1]

        val imageTeams = scope.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("data-team")) }
            .map(::cleanTeam).filter(::looksLikeTeam).distinct()
        if (imageTeams.size >= 2) return imageTeams[0] to imageTeams[1]
        return null
    }

    private fun cleanTeam(raw: String): String = raw
        .replace(Regex("(?i)\\b(?:correct\\s*score|predicted\\s*score(?:line)?|full\\s*time\\s*result|score\\s*prediction|exact\\s*score|score\\s*tip|prediction|predictions|odds|tip|preview|weather)\\b.*$"), " ")
        .replace(Regex("\\b(?:[01]?\\d|2[0-3])[:.]\\d{2}\\b"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '|', '-', ':', '·', '•')

    private fun looksLikeTeam(value: String): Boolean {
        if (value.length !in 2..90) return false
        if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        if (value.contains(Regex("(?i)^(correct score|predicted score|prediction|predictions|odds|tip|score|preview|weather|home|away|draw)$"))) return false
        return true
    }
}
