package com.cio.skor.data

import com.cio.skor.data.SourceResult
import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.CancellationException
import java.util.concurrent.atomic.AtomicInteger
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import org.jsoup.Jsoup

/** Configured score-prediction sources; official iddaa.com remains the authoritative fixture source. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/us/picks/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Sports Mole", "https://www.sportsmole.co.uk/football/preview/", SportsMoleExactScoreParser()),
        Source("BallPrediction", "https://ballprediction.com/", BallPredictionExactScoreParser()),
        Source("Tip724", "https://tip724.com/correct-score-tips", Tip724ExactScoreParser()),
        Source("Correct-Score.net", "https://www.correct-score.net/en/", CorrectScoreNetParser()),
        Source("FootballScorePredictor", "https://www.footballscorepredictor.com/correct-score-predictions/", FootballScorePredictorParser()),
        Source("AccurateTip", "https://www.accuratetip.com/correct-score-predictions", AccurateTipExactScoreParser()),
        // Newly added exact-score candidates. Keep existing sources intact until live diagnostics prove a replacement is better.
        Source("Vitibet", "https://www.vitibet.com/index.php?clanek=quicktips&sekce=fotbal", VitibetExactScoreParser()),
        Source("Betimate", "https://betimate.com/en", BetimateExactScoreParser()),
        Source("FootyStats", "https://footystats.org/predictions/correct-score", FootyStatsExactScoreParser()),
        // v0.9.14 expansion: keep all current providers and add eight new candidates.
        // They are measured independently; HTTP success is not treated as a score success.
        Source("BetClan", "https://www.betclan.com/todays-football-predictions/", GenericExactScoreParser("BetClan")),
        Source("Statarea", "https://www.statarea.com/predictions/default.aspx", GenericExactScoreParser("Statarea")),
        Source("FootballPredictions.com", "https://footballpredictions.com/betting-tips/", GenericExactScoreParser("FootballPredictions.com")),
        Source("BetMines", "https://betmines.com/football-predictions-today", GenericExactScoreParser("BetMines")),
        Source("SoccerPunter", "https://www.soccerpunter.com/", GenericExactScoreParser("SoccerPunter")),
        Source("Betshoot", "https://www.betshoot.com/", GenericExactScoreParser("Betshoot")),
        Source("OLBG", "https://www.olbg.com/football/", GenericExactScoreParser("OLBG")),
        Source("BettingClosed", "https://www.bettingclosed.com/", GenericExactScoreParser("BettingClosed"))
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val completedCount = AtomicInteger(0)
        val results = sources.map { source ->
            async(Dispatchers.IO) {
                val startTime = System.currentTimeMillis()
                val result = try {
                    val referer = when (source.name) {
                        "DailySports" -> "https://dailysports.net/"
                        "FP.com" -> "https://footballpredictions.com/betting-tips/"
                        "PredictZ" -> "https://www.predictz.com/"
                        "WinDrawWin" -> "https://www.windrawwin.com/"
                        "Sports Mole" -> "https://www.sportsmole.co.uk/football/preview/"
                        "BallPrediction" -> "https://ballprediction.com/"
                        "Tip724" -> "https://tip724.com/"
                        "Correct-Score.net" -> "https://www.correct-score.net/en/"
                        "FootballScorePredictor" -> "https://www.footballscorepredictor.com/"
                        "AccurateTip" -> "https://www.accuratetip.com/"
                        "Vitibet" -> "https://www.vitibet.com/"
                        "Betimate" -> "https://betimate.com/en"
                        "FootyStats" -> "https://footystats.org/"
                        "BetClan" -> "https://www.betclan.com/"
                        "Statarea" -> "https://www.statarea.com/"
                        "FootballPredictions.com" -> "https://footballpredictions.com/"
                        "BetMines" -> "https://betmines.com/"
                        "SoccerPunter" -> "https://www.soccerpunter.com/"
                        "Betshoot" -> "https://www.betshoot.com/"
                        "OLBG" -> "https://www.olbg.com/"
                        "BettingClosed" -> "https://www.bettingclosed.com/"
                        else -> null
                    }
                    // Prediction sites are public HTML pages but several of them
                    // serve different markup to lightweight/mobile clients. Use the
                    // browser-profile fetcher here instead of the old fast client.
                    // IMPORTANT: the timeout belongs to THIS child coroutine.
                    val sourceTimeoutMs = if (source.name == "Sports Mole") 40_000L else 20_000L
                    val (code, html) = withTimeout(sourceTimeoutMs + 6_000L) {
                        withContext(Dispatchers.IO) {
                            fetchSourceWithRetry(
                                url = source.url,
                                referer = referer ?: source.url,
                                attempts = 2
                            )
                        }
                    }
                    val rawBytes = html?.toByteArray(Charsets.UTF_8)?.size ?: 0
                    val isHttpSuccess = code in 200..299 && !html.isNullOrBlank()
                    val scores = if (isHttpSuccess) {
                        if (source.name == "Sports Mole") {
                            parseSportsMoleIndex(html.orEmpty(), source.parser)
                        } else {
                            val document = Jsoup.parse(html, source.url)
                            source.parser.parse(document)
                        }
                    } else {
                        emptyList()
                    }
                    val parserError = when {
                        !isHttpSuccess -> "HTTP_$code"
                        scores.isEmpty() -> "DOM_CHANGED_OR_EMPTY"
                        else -> null
                    }
                    SourceResult(
                        source = source.name,
                        httpCode = code,
                        scores = scores,
                        error = parserError,
                        durationMs = System.currentTimeMillis() - startTime,
                        rawHtmlBytes = rawBytes
                    )
                } catch (e: TimeoutCancellationException) {
                    // TimeoutCancellationException is normally a CancellationException,
                    // but this one belongs to our local withTimeout and MUST be contained.
                    val timeoutLabel = if (source.name == "Sports Mole") "TIMEOUT_40S" else "TIMEOUT_20S"
                    SourceResult(
                        source = source.name,
                        httpCode = -2,
                        scores = emptyList(),
                        error = timeoutLabel,
                        durationMs = System.currentTimeMillis() - startTime
                    )
                } catch (e: CancellationException) {
                    // Only a cancellation coming from outside this source's local
                    // timeout may cancel the child/parent scan.
                    throw e
                } catch (e: Exception) {
                    SourceResult(
                        source = source.name,
                        httpCode = -1,
                        scores = emptyList(),
                        error = "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown error"}",
                        durationMs = System.currentTimeMillis() - startTime
                    )
                }

                onProgress(completedCount.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()

        // Diagnostic only: observe each source result without changing behavior.
        val sourceCounts = results.associate { result ->
            result.source to result.scores.size
        }
        PipelineDiagnostics.log(
            sourceCounts = sourceCounts,
            rawPredictions = results.sumOf { it.scores.size }
        )

        results
    }

    /**
     * Short, source-isolated retry. Retry only transient transport/server failures;
     * never hammer a deterministic 404/403 page. The parser is still run only once
     * against the final successful body, so one source cannot poison the scan.
     */
    private fun fetchSourceWithRetry(
        url: String,
        referer: String,
        attempts: Int
    ): Pair<Int, String?> {
        var last: Pair<Int, String?> = -1 to null
        repeat(attempts.coerceIn(1, 2)) { attempt ->
            last = http.getSource(url, referer)
            val code = last.first
            val transient = code == -1 || code == -2 || code == -100 || code == -101 || code == -102 || code == 408 || code == 429 || code >= 500
            if (!transient || last.second?.isNotBlank() == true && code in 200..299) return last
            if (attempt + 1 < attempts) {
                try { Thread.sleep(500L) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            }
        }
        return last
    }

    /**
     * Sports Mole's /football/preview/ page is an index: exact scores live in the
     * linked preview articles as a "We say:" sentence. Fetch only the preview
     * links present on the index, dedupe them, and let the source parser consume
     * each article. This avoids treating the index as if it were a fixture card.
     */
    private suspend fun parseSportsMoleIndex(indexHtml: String, parser: BaseParser): List<ScoreModel> = coroutineScope {
        val doc = Jsoup.parse(indexHtml, "https://www.sportsmole.co.uk/football/preview/")
        val links = doc.select("a[href]")
            .mapNotNull { a ->
                val href = a.absUrl("href").ifBlank { a.attr("href") }
                val title = a.text().trim()
                if (href.contains("/football/") && href.contains("/preview/") &&
                    href.contains("-prediction-team-news-lineups_")) href to title else null
            }
            .distinctBy { it.first }
            .take(30)

        val parsed = links.chunked(6).flatMap { batch ->
            batch.map { (url, _) ->
                async(Dispatchers.IO) {
                    try {
                        val (code, body) = withTimeout(8_000L) {
                            http.getSource(url, "https://www.sportsmole.co.uk/football/preview/")
                        }
                        if (code !in 200..299 || body.isNullOrBlank()) return@async emptyList()
                        parser.parse(Jsoup.parse(body, url))
                    } catch (_: Exception) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
        }
        parsed.distinctBy { it.sourceMatchId.ifBlank { it.matchKey } }
    }

}
