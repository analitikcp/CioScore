package com.cio.skor.data

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object PopularBetHttpClient {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .build()

    fun get(url: String): String? {
        return runCatching {
            client.newCall(buildRequest(url)).execute().use { response ->
                if (!response.isSuccessful) return null
                response.body?.string()
            }
        }.getOrNull()
    }

    fun buildRequest(url: String): Request = Request.Builder()
        .url(url)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
        .header("Accept", "text/html,application/xhtml+xml,application/json,text/plain,*/*")
        .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
        .header("Cache-Control", "no-cache")
        .header("Referer", "https://www.google.com/")
        .build()
}
