package com.cio.skor.data

import kotlin.math.abs

/**
 * Popular-bet identity layer. It deliberately reuses the same canonical team
 * identity rules as the main fixture engine, but keeps popular-market records
 * separate from score predictions.
 */
object PopularBetMerger {
    fun merge(raw: List<PopularBetModel>): List<PopularBetCluster> {
        val clusters = mutableListOf<MutableList<PopularBetModel>>()
        for (item in raw.filter { it.rawHomeTeam.isNotBlank() && it.rawAwayTeam.isNotBlank() }) {
            val match = clusters.firstOrNull { group -> group.any { sameFixture(it, item) } }
            if (match != null) match += item else clusters += mutableListOf(item)
        }
        return clusters.mapNotNull { group ->
            val first = group.firstOrNull() ?: return@mapNotNull null
            PopularBetCluster(
                fixtureKey = MatchMerger.key(first.rawHomeTeam, first.rawAwayTeam),
                homeTeam = preferredName(group.map { it.rawHomeTeam }),
                awayTeam = preferredName(group.map { it.rawAwayTeam }),
                matchCode = group.firstOrNull { it.matchCode.isNotBlank() }?.matchCode.orEmpty(),
                bets = group.sortedWith(compareBy<PopularBetModel> { sourceOrder(it.sourceName) }.thenBy { it.prediction })
            )
        }.sortedWith(compareByDescending<PopularBetCluster> { it.sourceCount }.thenBy { it.homeTeam })
    }

    private fun sameFixture(a: PopularBetModel, b: PopularBetModel): Boolean {
        if (a.matchCode.isNotBlank() && b.matchCode.isNotBlank() && a.matchCode == b.matchCode) return true
        val home = TeamAliasCanonicalizer.similarity(a.rawHomeTeam, b.rawHomeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.rawAwayTeam, b.rawAwayTeam)
        if (home < 0.84 || away < 0.84) return false
        if (a.matchTimestamp > 0 && b.matchTimestamp > 0) {
            val hours = abs(a.matchTimestamp - b.matchTimestamp) / 3_600_000.0
            if (hours > 3.0) return false
        }
        return true
    }

    private fun preferredName(names: List<String>): String =
        names.maxByOrNull { scoreName(it) } ?: ""

    private fun scoreName(name: String): Int = name.length - Regex("\\b(fc|fk|sk|cf|linz|athens|atina)\\b", RegexOption.IGNORE_CASE).findAll(name).count() * 3

    private fun sourceOrder(source: String): Int = when (source) {
        "İddaa" -> 0
        "Nesine" -> 1
        "Misli" -> 2
        "Bilyoner" -> 3
        else -> 9
    }
}
