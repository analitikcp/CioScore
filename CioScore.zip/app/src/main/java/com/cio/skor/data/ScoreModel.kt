package com.cio.skor.data

/**
 * One prediction coming from one external source. Optional fixture metadata is
 * deliberately nullable/defaulted so existing parsers remain source-compatible.
 */
data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String,
    val sourceMatchId: String = "",
    val matchTimestamp: Long = 0L,
    val matchDate: String = "",
    val matchTime: String = "--:--",
    val competitionName: String = ""
) {
    /** Stable canonical fixture key. This is not the only identity signal. */
    val matchKey: String
        get() = MatchMerger.key(homeTeam, awayTeam)
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null
)
