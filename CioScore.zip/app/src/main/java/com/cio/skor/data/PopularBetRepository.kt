package com.cio.skor.data

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

class PopularBetRepository(
    private val parsers: List<PopularBetParser> = listOf(
        IddaaPopularParser(),
        NesinePopularParser(),
        MisliPopularParser(),
        BilyonerPopularParser()
    )
) {
    suspend fun fetchAll(): List<PopularBetModel> = coroutineScope {
        parsers.map { parser -> async { runCatching { parser.fetch() }.getOrDefault(emptyList()) } }
            .awaitAll()
            .flatten()
    }

    fun cluster(raw: List<PopularBetModel>): List<PopularBetCluster> = PopularBetMerger.merge(raw)
}
