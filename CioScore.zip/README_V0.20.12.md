# CioScore v0.20.12

## Birleştirme düzeltmesi
- AEK Athens / AEK Atina aynı takım olarak birleştirilir.
- LASK / LASK Linz aynı takım olarak birleştirilir.
- Resmi İddaa event akışında aynı fixture birden fazla kayıtla gelirse tek kayda indirilir.
- MS ve HT/FT marketleri duplicate kayıtlardan güvenli biçimde birleştirilir.
- Ana ekranda HT/FT butonu korunur; HT/FT oranları ayrı ekranda gösterilir.
- Skor Analiz Filtre1–5 korunur.
