# CioScore v0.21.0 — Popular Bets Hub

Adds a single **🔥 EN ÇOK OYNANANLAR** button to the main screen and a separate screen that combines popular-bet records from:

- iddaa: https://www.iddaa.com/populer-bahisler/futbol
- Nesine: https://www.nesine.com/iddaa/dakika-bahis
- Misli: https://www.misli.com/iddaa/en-cok-oynanan-tum-maclar
- Bilyoner: https://www.bilyoner.com/iddaa/populer-bahisler

## Architecture

`PopularBetModel` → source-specific parsers → `PopularBetRepository` → `PopularBetMerger` → `PopularBetsActivity`.

Popular-bet identity reuses `TeamAliasCanonicalizer`/`MatchMerger.key` from the global fixture system and applies a ±3h time guard when timestamps are available. Official/source match codes are used as a strong identity hint only within the same provider context.

The parsers intentionally do **not** hard-code undocumented API endpoints. They request the supplied public pages and first consume explicit `data-*` attributes exposed by the page. This avoids baking guessed private endpoints into the app. If a site moves its live data behind a JS/API layer, only that source parser needs to be upgraded.

## UI

Main screen: small button under the existing HT/FT button.

Popular screen: one card per unified fixture, with each source's popular selection, ratio/count and odds when available.

## Build note

The supplied project does not contain a Gradle wrapper and the execution environment used to package this ZIP has no system `gradle` binary, so an APK build could not be executed here. Kotlin/Android source changes were kept isolated and the existing project dependencies (OkHttp + Jsoup + coroutines) are reused.
