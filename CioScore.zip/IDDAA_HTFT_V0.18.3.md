# CioScore v0.18.3 — Resmi İddaa HT/FT zorunlu bağlantı

- MS mantığına dokunulmadı: yalnızca resmi `Maç Sonucu / Match Result` marketi MS olur.
- HT/FT tam 9'lu resmi grid imzasıyla okunur: 1/1, 1/X, 1/2, X/1, X/X, X/2, 2/1, 2/X, 2/2.
- İddaa'nın 0 gösterimi X'e normalize edilir.
- 9 oran eksikse `hasHtFt=false`; yabancı/parsiyel veri karta çıkamaz.
- Resmi İddaa bulunamazsa başka kaynaktan oran fallback'i yapılmaz.
- FC/IFK/FF/FK/AS/BSC vb. kulüp ekleri eşleştirmede temizlenir.
- OpenedMarketsActivity ile ana ScoreAdapter aynı IddaaMarketService çıktısını kullanır.

Lahti–Mariehamn test hedefi: 2.07, 16.10, 36.50, 4.31, 6.20, 11.45, 22.65, 18.05, 9.15.
