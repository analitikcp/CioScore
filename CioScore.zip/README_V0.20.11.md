# CioScore v0.20.10

Bu sürüm v0.20.9 üzerine hazırlanmıştır.

- Ana ekranda toplu **⚡ HT/FT AÇILAN MAÇLAR** butonu vardır.
- Buton, ayrı `HtFtOpenedMatchesActivity` ekranını açar ve tüm açık HT/FT maçlarını listeler.
- Ana ekranda HT/FT 9'lu oran matrisi gösterilmez.
- Ana kartta yalnızca HT/FT açıksa **⚡ HT/FT AÇIK** butonu görünür.
- **ARAMAYI TEMİZLE** ana ekrandan kaldırılmıştır.
- Resmi İddaa MS 1 / MS X / MS 2 oranları korunur.
- Skor Analiz Filtre1..5 korunur; Cio1..Cio5 adları UI'da kullanılmaz.
- CioScore 0-100, güven etiketi ve yorum metinleri yoktur.


## v0.20.11
Ana ekrandaki toplu HT/FT butonu daha kompakt hale getirildi; HT/FT listesi ayrı ekranda kalır.
