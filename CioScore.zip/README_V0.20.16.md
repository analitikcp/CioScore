# CioScore v0.20.16 — Global Fixture Matcher

## Why this version exists
The old MatchMerger was a greedy, order-dependent string merger. v0.20.16 replaces that approach with a global fixture identity engine.

## Four required identity layers
1. **TeamAliasCanonicalizer** — Unicode/Turkish normalization, token-aware transliteration, safe club-type edge cleanup and explicit cross-language aliases. Meaningful words such as `IFK` and `Linz` are not globally deleted.
2. **Official Iddaa fixture anchor** — official `matchId` is treated as the strongest identity inside iddaa.com. Official records are also consolidated by canonical home/away when necessary.
3. **Global clustering / Union-Find** — all five prediction sources and official Iddaa records are put into one global set before grouping. Results no longer depend on which source arrives first.
4. **Match ID + date/time confidence** — comparable source IDs, kickoff timestamp/date and two-sided team similarity are combined into an explicit evidence score. Large kickoff contradictions reject fuzzy merges.

## Compatibility
- Existing parser constructors remain unchanged.
- `ScoreModel` now has optional fixture metadata (`sourceMatchId`, `matchTimestamp`, `matchDate`, `matchTime`) with safe defaults, so parsers can adopt it incrementally.
- `MatchMerger` remains as a compatibility facade for existing UI/data calls, while the real logic is in `GlobalFixtureMatcher`.

## AEK/LASK regression
These all resolve to one fixture in the matcher test:
- AEK Athens — LASK
- AEK Atina — LASK Linz
- AEK Athens FC — LASK Linz
- AEK Athina — LASK
- AEK — LASK Linz

With five different prediction sources plus one official Iddaa record, the result is **1 group / 5 predictions**, not duplicate cards. Reversed home/away remains a separate fixture.

## Performance
Exact canonical fixtures are bucketed first. Fuzzy comparisons use a short home/away blocking signature instead of running Levenshtein against every possible pair.
