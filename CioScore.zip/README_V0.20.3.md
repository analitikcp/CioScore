# CioScore v0.20.3

- v0.20.2'nin resmi İddaa saat ve MS1/MSX/MS2 entegrasyonu korunmuştur.
- Karttan CioScore 49/100, güven etiketi ve yorum metinleri çıkarılmıştır.
- Maçkolik oranları kullanılmaz.
- Kartın altına Cio1-Cio5 skor tahminleri tekrar eklenmiştir.
- Tahminler kaynak sırasına göre Cio1, Cio2, Cio3, Cio4, Cio5 olarak gösterilir.
- Her satır `CioN → skor` formatındadır.
