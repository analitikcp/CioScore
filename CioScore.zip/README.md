# CioScore v0.20.16

Global Fixture Matcher release.

- 5 prediction sources + official Iddaa.com
- TeamAliasCanonicalizer
- Official Iddaa matchId anchor
- Global Union-Find clustering
- Match ID + kickoff date/time confidence
- MatchMerger kept as compatibility facade
