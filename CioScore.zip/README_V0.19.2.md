# CioScore v0.19.2

- Official iddaa MS1 / MSX / MS2 odds are displayed immediately after the teams.
- HT/FT remains below the MS 1X2 odds.
- CioScore percentage and misleading result label remain removed.
- Match time remains sourced from the official iddaa event data when available.
