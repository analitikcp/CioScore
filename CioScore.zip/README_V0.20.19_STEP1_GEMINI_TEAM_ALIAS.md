# CioScore v0.20.19 — Gemini Step 1: Team Alias / Canonicalizer

This release implements **only Step 1** of the three Gemini recommendations.
Time-window and external-ID anchoring are intentionally left for the next steps.

## Implemented

- Token-safe Turkish/Unicode normalization.
- Explicit TeamAlias canonicalization.
- AEK Athens / AEK Atina / AEK Athina / AEK -> `aek athens`.
- LASK / LASK Linz -> `lask`.
- Safe FC/FK/SK/CF/SC etc. edge-token removal.
- Levenshtein similarity on canonical identities.
- Team-level fuzzy match threshold of 0.80, as requested by Gemini Step 1.
- Fixture-level matcher remains stricter until Step 2 (date/time tolerance) is implemented.

## Regression expectations

All of these must resolve to the same canonical team identities:

- AEK Athens -> `aek athens`
- AEK Atina -> `aek athens`
- AEK Athina -> `aek athens`
- AEK -> `aek athens`
- LASK -> `lask`
- LASK Linz -> `lask`
- AEK Athens FC -> `aek athens`
- LASK Linz FC -> `lask`

This release does not claim to implement Step 2 or Step 3 yet.
