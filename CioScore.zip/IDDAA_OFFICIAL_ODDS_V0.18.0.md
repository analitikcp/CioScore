# CioScore v0.18.0 — Official Iddaa Odds

## Data source
The betting odds source for match result and opened-market detection is now the official Iddaa sportsbook JSON feed:
- `https://sportsbookv2.iddaa.com/sportsbook/events?st=1&type=0&version=0`
- `https://sportsbookv2.iddaa.com/sportsbook/get_market_config`

The application no longer uses official third-party odds source for odds or opened-market scraping.

## Markets extracted
- MS 1 / X / 2
- İY/MS (HT/FT): 1/1, 1/X, 1/2, X/1, X/X, X/2, 2/1, 2/X, 2/2
- Doğru Skor, when supplied by the official feed

## Important behavior
A match is not removed from the CIO prediction list when a market is unavailable. The Opened Markets screen only shows matches for which the official feed actually contains one of the requested markets.

## Version
0.18.0 (versionCode 130)
