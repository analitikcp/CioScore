# CioScore v0.18.4

## Critical fix
- Official Iddaa sportsbook remains the only odds source.
- HT/FT is detected from the actual 9 outcome labels (1/1..2/2), independent of market-config naming.
- Supports outcome odds returned as JSON arrays or objects.
- Partial HT/FT grids are retained instead of being discarded.
- Match Result is identified by the 1/X/2 signature or official market name.
- No official third-party odds source odds or HTML scraping is used.
