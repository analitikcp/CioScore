# CioScore v0.19.0 — Resmi İddaa MS + HT/FT

## Oran kaynağı
- Maçkolik entegrasyonu yoktur.
- MS1 / MSX / MS2 oranları yalnızca resmi İddaa birinci taraf veri akışından alınır.
- HT/FT (İY/MS) 9'lu grid de aynı resmi İddaa veri akışından alınır.
- Referans program: `https://www.iddaa.com/program/futbol?date=DD.MM.YYYY`
- Uygulama, program sayfasının arkasındaki resmi JSON akışını kullanır; HTML tablo kazıması yapılmaz.

## Maç zamanı
- Resmi event `d` zaman damgası öncelikli olarak kullanılır.
- Saniye/milisaniye/ISO formatları normalize edilir.
- Türkiye saat dilimi (`Europe/Istanbul`) ile `HH:mm` gösterilir.
- Ana kartlar ve HT/FT ekranı kronolojik sıralanır.

## Ana kart
- CioScore 0-100 puanı kaldırılmıştır.
- "Maç berabere biter" gibi sonuç etiketi kullanılmaz.
- Kartta yalnızca `TAHMİN: MS 1`, `TAHMİN: MS X` veya `TAHMİN: MS 2` gösterilir.
- Altında resmi İddaa `MS 1 / MS X / MS 2` oranları gösterilir.
- HT/FT oranları resmi İddaa 9'lu grid olarak gösterilir.

## HT/FT Açılan Maçlar
- Ana ekranda yalnızca `HT/FT AÇILAN MAÇLAR` butonu bulunur.
- Doğru Skor / Açılan Marketler filtreleri kullanılmaz.
- Liste yalnızca gerçekten HT/FT outcome'u bulunan maçları gösterir.

## Eşleştirme
- Resmi İddaa maçları ile CIO tahminleri takım adı normalize/fuzzy eşleştirmesiyle birleştirilir.
