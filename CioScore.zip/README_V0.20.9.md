# CioScore v0.20.9

Bu sürüm kullanıcı tarafından istenen nihai kart düzenini uygular:
- Ana ekranda ARAMAYI TEMİZLE yok.
- Ana ekranda ayrı HT/FT AÇILAN MAÇLAR butonu yok.
- HT/FT oranları ana kartta yok.
- Ana kartta resmi İddaa MS1 / MS X / MS2 oranları var.
- Maç kartında HT/FT AÇIK butonu var; ayrı HT/FT ekranını açar.
- HT/FT ekranında tek başlık ve başlığın yanında maç sayısı var.
- CioScore 49/100, güven etiketi ve yorum metni yok.
- Skor Analiz Filtre 1..5 korunur.
- Resmi İddaa saatleri korunur.
