# CioScore v0.20.15 — Global 6-Source Match Merge Hardened

## Fixture merge
- 5 correct-score prediction sources + official iddaa.com are handled as one global fixture set.
- Team-name normalization is shared by MatchMerger, MainActivity, IddaaMarketService and UI matching.
- `AEK Athens` / `AEK Atina` normalize to `aek athens`.
- `LASK` / `LASK Linz` normalize to `lask`.
- Generic club-type words are removed only at the beginning/end; meaningful words such as `IFK` and `Linz` are not globally deleted.
- Canonical home+away key is checked first; conservative Levenshtein fuzzy matching is only a fallback.
- A fixture can contribute at most one prediction from each of the five prediction sources.
- Official Iddaa data enriches an existing fixture and cannot create a second main-screen card for the same fixture when a prediction-source record already exists.

## Important architecture note
The previous Gemini example used fields such as `predictions` and `isOfficialIddaa` that do not exist in this project's `ScoreModel`. This version keeps the project's actual `ScoreModel` and `IddaaMarketService.OpenedMarketMatch` architecture instead of introducing incompatible fields.
