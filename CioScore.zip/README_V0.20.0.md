# CioScore v0.20.0 — Final İddaa Bülten Düzeni

- MS1 / MSX / MS2 are read only from the official Iddaa "Maç Sonucu" market.
- First-half 1/X/2 is never used as MS1/MSX/MS2.
- HT/FT 1/1..2/2 remains official Iddaa data.
- Kickoff time is read from the official event `d` timestamp (epoch seconds), with defensive fallbacks.
- Card order: kickoff time -> MS1/MSX/MS2 odds -> teams -> TAHMİN: MS 1/MS X/MS 2 -> HT/FT.
- CioScore 0-100, confidence text, and "Maç berabere biter" are not displayed.
- No Maçkolik odds source is used.
