# CioScore v0.19.1 — İddaa MS / HTFT düzeltmesi

- Maçkolik oran kaynağı kullanılmaz.
- **MS1 / MSX / MS2 yalnızca resmi İddaa `Maç Sonucu` marketinden alınır.**
- `İlk Yarı Sonucu` gibi aynı 1/X/2 imzasına sahip marketler MS alanlarına artık kesinlikle düşmez.
- HT/FT 9'lu grid resmi İddaa marketinden alınmaya devam eder.
- Resmi event şemasındaki `d` alanı maç başlangıç zamanı için birincil kaynaktır; saniye -> milisaniye dönüşümü yapılarak `Europe/Istanbul` ile `HH:mm` gösterilir.
- Ana karttaki CioScore puanı ve sonuç etiketi yoktur; yalnızca `TAHMİN: MS 1/MS X/MS 2` gösterilir.
