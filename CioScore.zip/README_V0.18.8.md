# CioScore v0.18.8

- CioScore 0-100 score removed from match cards.
- Prediction is shown only as MS 1 / MS X / MS 2.
- HT/FT opened matches remain sourced only from official Iddaa feed.
- HT/FT screen now displays official match start time and sorts chronologically.
- Event timestamp is normalized to epoch milliseconds and rendered in Europe/Istanbul.
- Correct Score and legacy Opened Markets UI remain disabled.
