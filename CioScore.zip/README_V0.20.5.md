# CioScore v0.20.5

## Madde 2 — HT/FT karttan ayrı ekrana
- Ana maç kartlarından resmi İddaa İY/MS (HT/FT) 9'lu oran matrisi kaldırıldı.
- HT/FT oranları veri modelinde korunuyor; ana kartta yalnızca `⚡ HT/FT AÇIK` butonu gösteriliyor.
- Butona basıldığında HT/FT ekranı yalnızca seçilen maçı açıyor ve resmi 9'lu HT/FT oranlarını gösteriyor.
- Ana kartta saat ve MS 1 / MS X / MS 2 oranları korunuyor.
- Skor Analiz Filtre 1..5 korunuyor.
