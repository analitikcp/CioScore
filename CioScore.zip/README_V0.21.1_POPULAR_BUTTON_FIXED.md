# CioScore v0.21.1

EN ÇOK OYNANANLAR button is explicitly visible in activity_main.xml and wired to PopularBetsActivity.
The previous v0.21.0 already contained the ID, but this revision makes the UI block explicit and adds a build marker.
