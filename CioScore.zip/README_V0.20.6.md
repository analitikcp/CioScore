# CioScore v0.20.6

## Madde 3 — Aramayı Temizle kaldırıldı

Ana ekrandaki `ARAMAYI TEMİZLE` butonu ve buna bağlı click listener tamamen kaldırıldı.
Kullanıcı arama alanındaki metni Android klavyesi ile manuel olarak silebilir.

Korunan özellikler:
- Maç saati
- Resmi İddaa MS 1 / MS X / MS 2 oranları
- TAHMİN: MS 1 / MS X / MS 2
- HT/FT AÇIK akışı
- Resmi İddaa HT/FT 9'lu oranları
- Skor Analiz Filtre 1–5
