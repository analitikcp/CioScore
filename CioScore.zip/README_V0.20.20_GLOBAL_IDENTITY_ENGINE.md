# CioScore v0.20.20 — Global Identity Engine

This release replaces the previous incremental MatchMerger patches with a four-layer fixture identity pipeline for all 6 sources (5 prediction sites + official Iddaa).

## Four layers

1. **TeamAliasCanonicalizer**
   - Stable source-independent canonical team IDs.
   - AEK / AEK Athens / AEK Atina / AEK Athina -> `aek-athens`.
   - LASK / LASK Linz -> `lask`.
   - Unicode/Turkish normalization and safe edge-token removal.
   - Conservative aliases to avoid false merges.

2. **Official Iddaa Fixture Anchor**
   - Official `matchId` is the strongest identity inside the Iddaa namespace.
   - Official Iddaa names are the preferred UI display names.
   - External prediction records are attached to the official fixture only when home + away identities agree.

3. **Global Union-Find Clustering**
   - All six-source records are loaded into one global graph.
   - Exact canonical fixtures union first.
   - Official fixtures are attached next.
   - Remaining sources are compared globally; no greedy first-match merge and no narrow prefix block.

4. **Confidence / date-time validation**
   - Same-provider IDs are respected; different IDs from the same provider never collapse.
   - Kickoff timestamps tolerate up to 3 hours as the soft timezone window.
   - More than 6 hours is a hard contradiction.
   - Missing time is neutral rather than blocking a name-exact match.
   - Both home and away must agree for fuzzy matching.

## Regression target

These records must become one fixture:

- AEK Athens — LASK
- AEK Atina — LASK Linz
- AEK Athina — LASK
- AEK Athens FC — LASK Linz FC

The UI should render one card containing the available prediction filters, not one card per spelling/source.
