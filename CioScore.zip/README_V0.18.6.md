# CioScore v0.18.6

Build-fix release for v0.18.5.

- Official Iddaa feed remains the only odds/HTFT source.
- HT/FT Açılan Maçlar is the only market-opening screen.
- Fixed `IddaaMarketService` HttpResult/body type mismatch.
- Fixed duplicate `readOdd` declaration.
- No external provider odds are used.
