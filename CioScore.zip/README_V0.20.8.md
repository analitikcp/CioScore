# CioScore v0.20.8 FINAL

- Ana kartta MS 1 / MS X / MS 2 resmi İddaa oranları en üstte.
- İY/MS resmi oranları ana kartta gösterilmez.
- HT/FT AÇIK butonu ayrı ekrana yönlendirir.
- HT/FT ekranında tek başlık vardır; maç sayısı başlığın yanında gösterilir.
- Maç saati resmi İddaa event zamanından gösterilir.
- CioScore 49/100, Güven ve yorum metni kaldırılmıştır.
- Skor Analiz Filtre 1, 2, 3, 4, 5 satırları kartta gösterilir.
- ARAMAYI TEMİZLE butonu yoktur; arama alanı klavyeden temizlenebilir.
- Maçkolik oranları kullanılmaz.
