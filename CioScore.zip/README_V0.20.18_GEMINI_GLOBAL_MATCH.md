# CioScore v0.20.18 — Gemini Global Match Merge

Implemented from the Gemini proposal, adapted to the existing six-source CioScore architecture.

## What changed

1. **TeamAliasCanonicalizer**
   - Turkish/Unicode normalization.
   - Explicit aliases such as AEK Athens / AEK Atina / AEK Athina.
   - LASK / LASK Linz convergence.
   - Safe FC/FK/SK/etc. edge-token removal.
   - Levenshtein similarity.

2. **MatchMerger facade**
   - Added Gemini-style `areMatchesSame(home, away, home, away)`.
   - Both home and away must reach 0.90 similarity for fuzzy matching.
   - Old greedy first-match merging is removed.

3. **Official Iddaa fixture anchor**
   - Official `matchId` remains the strongest identity signal.
   - Official names are used as the display anchor.
   - External records attach only when both team identities are strong.

4. **Global clustering / Union-Find**
   - All six-source records are loaded into one global pool.
   - Exact canonical fixtures are unioned first.
   - Remaining records receive a true global home+away comparison; no narrow prefix gate can hide AEK/LASK variants.
   - Connected components become the final fixture cards.

5. **Match ID + date/time confidence**
   - Same comparable ID is an anchor.
   - Kickoff timestamps/dates strengthen or reject fuzzy matches.
   - Large time contradictions block a fuzzy merge.

6. **One card / one source prediction**
   - A unified fixture keeps at most one prediction per source.
   - The five prediction sources therefore appear under the same fixture instead of producing duplicate cards.

## Critical regression case

These inputs must converge to one fixture:

- AEK Athens — LASK
- AEK Atina — LASK Linz
- AEK Athina — LASK
- AEK Athens FC — LASK Linz

Expected result: **one fixture cluster**, not multiple UI cards.
