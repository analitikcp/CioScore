# CioScore v0.20.17 — Global Fixture Matcher Hardened

Fixes the v0.20.16 duplicate-card regression.

- Global union-find matching remains the identity authority.
- Exact canonical fixtures are merged before fuzzy matching.
- Fuzzy blocking is broader than the old 3-character gate.
- Official Iddaa matchId remains the strongest official anchor.
- Same-provider different IDs are protected from unsafe fuzzy merging.
- Team aliases converge after normalization (including AEK Athens/Atina/Athina and LASK/LASK Linz).
- MainActivity has a final canonical-key rendering guard so one fixture cannot render multiple cards.
- One merged card keeps one prediction per source, so five prediction sources appear as five filters on one card.
