# CioScore v0.18.5

- Ana ekrandaki Açılan Marketler butonu kaldırıldı.
- Yerine yalnızca **HT/FT AÇILAN MAÇLAR** butonu eklendi.
- Doğru Skor ekranı/filtrelemesi kaldırıldı.
- HT/FT oranlarının tek bahis oranı kaynağı resmi İddaa veri akışıdır.
- official third-party odds source oran/market entegrasyonu uygulamanın aktif akışından çıkarıldı.
- HT/FT sonuçları 1/1, 1/X, 1/2, X/1, X/X, X/2, 2/1, 2/X, 2/2 olarak normalize edilir.
- HT/FT açık olmayan maçlar HT/FT ekranında gösterilmez.
