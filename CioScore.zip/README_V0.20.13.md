# CioScore v0.20.13

Global fixture merge fix: all five score-analysis sources plus official iddaa.com are treated as six sources for fixture identity. A match is rendered once when home and away teams match after canonicalisation/conservative fuzzy matching. Official iddaa records are merged into the same fixture rather than appended as separate cards.
