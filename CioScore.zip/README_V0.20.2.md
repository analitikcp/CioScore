# CioScore v0.20.2

- Saat resmi İddaa bülteninden kartta gösterilir.
- MS 1 / MS X / MS 2 kartın en üstünde, İddaa Maç Sonucu marketinden alınır.
- İlk Yarı Sonucu oranlarının MS alanına düşmesini engelleyen bağımsız market seçimi eklendi.
- Market-config eksik/uyumsuz olduğunda ilk uygun 3-yollu tam maç marketi kontrollü fallback olarak kullanılır; İlk/İkinci Yarı marketleri açıkça reddedilir.
- HT/FT 1/1..2/2 matrisi yalnız resmi İddaa HT/FT marketlerinden alınır.
- CioScore 49/100, güven etiketi ve yorum metinleri yok.
- Maçkolik oran kaynağı yok.
- Kart sırası: saat → MS1/MSX/MS2 → takımlar → TAHMİN: MS1/MSX/MS2 → HT/FT.
