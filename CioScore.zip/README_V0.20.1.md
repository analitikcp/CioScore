# CioScore v0.20.1

- Resmi İddaa MS 1 / MS X / MS 2 oranları kartın üstünde.
- Resmi İddaa HT/FT 3x3 matrisi footer bölümünde.
- Maç saati üstte.
- Tahmin yalnızca MS 1 / MS X / MS 2.
- CioScore 0-100, güven etiketi ve yorum metinleri yok.
- Maçkolik oran kaynağı yok.
- İlk Yarı Sonucu oranlarının MS alanına düşmesini önlemek için MS yalnızca resmi "Maç Sonucu" market-config'inden alınır.
