# CioScore v0.18.1 — Resmi İddaa oran + HT/FT düzeltmesi

- official third-party odds source odds/market kullanılmaz.
- İddaa sportsbook events + market_config kullanılır.
- HT/FT yalnızca market adından değil, 9'lu outcome gridinden de tespit edilir.
- 0/X varyantı X'e normalize edilir.
- odd sayı veya string gelirse okunur.
- Ana maç kartında MS 1/X/2 ve bulunan 9 HT/FT oranı gösterilir.
- Resmi kaynaktan market verisi gelmezse tahmin kartı silinmez.
