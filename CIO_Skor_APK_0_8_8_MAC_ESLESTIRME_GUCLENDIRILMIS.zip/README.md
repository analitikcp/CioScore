CIO Score 0.8.8

Stronger cross-source fixture matching.
Preserves the four currently working sources: FP.com, PredictZ, WinDrawWin and SoccerSeer.
Does not change parsers.

Matching improvements:
- accent/diacritic normalization
- common club suffix/prefix removal
- token-aware similarity
- edit-distance fallback
- home/away order preserved
- one prediction per source per grouped match
- unmatched SoccerSeer matches remain visible
