package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.max

/** SofaScore enrichment: adds full-time 1X2 odds without affecting CIO scoring. */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)

    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String
    )

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null
    )

    private val http = HttpClient()
    private val bases = listOf(
        "https://api.sofascore.com/api/v1",
        "https://www.sofascore.com/api/v1"
    )

    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups

        // The phone may be in Turkey while SofaScore's event date is UTC.
        // Search yesterday/today/tomorrow so late-night MLS matches are not missed.
        val dates = listOf(-1L, 0L, 1L).map {
            LocalDate.now().plusDays(it).toString()
        }
        val events = dates.flatMap { loadEvents(it) }.distinctBy { it.id }
        if (events.isEmpty()) return@coroutineScope groups

        // Correct bulk endpoint is /sport/football/odds/{date} (no /1/).
        val bulkOdds = dates.flatMap { loadBulkOdds(it).entries }
            .associate { it.toPair() }

        groups.map { group ->
            async(Dispatchers.IO) {
                val event = bestEventFor(group, events)
                if (event == null) {
                    group
                } else {
                    val odds = bulkOdds[event.id] ?: loadEventOdds(event.id)
                    group.copy(odds = odds)
                }
            }
        }.awaitAll()
    }

    private fun bestEventFor(group: MatchGroupData, events: List<EventRef>): EventRef? {
        return events
            .map { event ->
                val home = teamSimilarity(event.home, group.homeTeam)
                val away = teamSimilarity(event.away, group.awayTeam)
                Triple(event, home, away)
            }
            .filter { it.second >= 0.72 && it.third >= 0.72 }
            .maxByOrNull { it.second + it.third }
            ?.first
    }

    private fun loadEvents(date: String): List<EventRef> {
        for (base in bases) {
            val (code, body) = http.get(
                "$base/sport/football/scheduled-events/$date",
                "https://www.sofascore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                val arr = JSONObject(body).optJSONArray("events") ?: continue
                val out = mutableListOf<EventRef>()
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) {
                        out += EventRef(id, home, away)
                    }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) { }
        }
        return emptyList()
    }

    private fun loadBulkOdds(date: String): Map<Long, Odds> {
        for (base in bases) {
            val (code, body) = http.get(
                "$base/sport/football/odds/1/$date",
                "https://www.sofascore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                val root = JSONObject(body)
                val oddsRoot = root.optJSONObject("odds") ?: continue
                val out = mutableMapOf<Long, Odds>()
                val keys = oddsRoot.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val id = key.toLongOrNull() ?: continue
                    parseOddsAny(oddsRoot.opt(key))?.let { out[id] = it }
                }
                if (out.isNotEmpty()) return out
            } catch (_: Exception) { }
        }
        return emptyMap()
    }

    private fun loadEventOdds(eventId: Long): Odds? {
        val paths = listOf(
            "/event/$eventId/odds/1/featured",
            "/event/$eventId/odds/1/all",
            "/event/$eventId/odds/1"
        )
        for (base in bases) {
            for (path in paths) {
                val (code, body) = http.get(
                    "$base$path",
                    "https://www.sofascore.com/"
                )
                if (code !in 200..299 || body.isNullOrBlank()) continue
                try {
                    val root = org.json.JSONTokener(body).nextValue()
                    parseOddsAny(root)?.let { return it }
                } catch (_: Exception) { }
            }
        }
        return null
    }

    /** Parses both bulk {odds:{eventId:{choices:[]}}} and event odds arrays. */
    private fun parseOddsAny(root: Any?): Odds? {
        fun walk(value: Any?): Odds? {
            when (value) {
                is JSONObject -> {
                    val marketName = value.optString("marketName")
                        .ifBlank { value.optString("name") }
                        .ifBlank { value.optString("market") }
                        .lowercase()
                    val group = value.optString("group").lowercase()
                    val period = value.optString("period").lowercase()
                    val isFullTime = (marketName.contains("full time") || marketName == "1x2" || group == "1x2") &&
                        (period.isBlank() || period.contains("full"))
                    if (isFullTime) {
                        parseChoiceSet(value)?.let { return it }
                    }
                    // Bulk odds can expose choices without market metadata.
                    parseChoiceSet(value)?.let { return it }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        walk(value.opt(keys.next()))?.let { return it }
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) {
                        walk(value.opt(i))?.let { return it }
                    }
                }
            }
            return null
        }
        return walk(root)
    }

    private fun parseChoiceSet(value: JSONObject?): Odds? {
        if (value == null) return null
        val choices = value.optJSONArray("choices") ?: return null
        var one: String? = null
        var draw: String? = null
        var two: String? = null

        for (i in 0 until choices.length()) {
            val c = choices.optJSONObject(i) ?: continue
            val name = c.optString("name")
                .ifBlank { c.optString("label") }
                .ifBlank { c.optString("selection") }
                .trim().uppercase()

            val number = extractDecimal(c)
            if (!number.isFinite() || number <= 1.0 || number > 100.0) continue
            val formatted = String.format(java.util.Locale.US, "%.2f", number)
            when (name) {
                "1", "HOME", "H" -> one = formatted
                "X", "DRAW", "D" -> draw = formatted
                "2", "AWAY", "A" -> two = formatted
            }
        }
        return if (one != null && draw != null && two != null) Odds(one!!, draw!!, two!!) else null
    }

    private fun extractDecimal(choice: JSONObject): Double {
        // Current SofaScore payloads may put the live/current value under value.decimal.
        val value = choice.optJSONObject("value")
        if (value != null) {
            val d = value.optDouble("decimal", Double.NaN)
            if (d.isFinite()) return d
            val f = value.optString("fractional")
            fractionalToDecimal(f).let { if (it.isFinite()) return it }
        }
        val initial = choice.optJSONObject("initialValue")
        if (initial != null) {
            val d = initial.optDouble("decimal", Double.NaN)
            if (d.isFinite()) return d
            fractionalToDecimal(initial.optString("fractional")).let { if (it.isFinite()) return it }
        }
        val d = choice.optDouble("decimalValue", Double.NaN)
        if (d.isFinite()) return d
        val d2 = choice.optDouble("decimal", Double.NaN)
        if (d2.isFinite()) return d2
        return fractionalToDecimal(choice.optString("fractionalValue"))
    }

    private fun fractionalToDecimal(value: String): Double {
        if (value.isBlank()) return Double.NaN
        if (value.contains('/')) {
            val parts = value.split('/', limit = 2)
            val numerator = parts.getOrNull(0)?.toDoubleOrNull() ?: return Double.NaN
            val denominator = parts.getOrNull(1)?.toDoubleOrNull() ?: return Double.NaN
            if (denominator == 0.0) return Double.NaN
            return numerator / denominator + 1.0
        }
        return value.toDoubleOrNull() ?: Double.NaN
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        if (aa.contains(bb) || bb.contains(aa)) return 0.94
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    suspend fun getLastFive(teamName: String): List<RecentMatch> = Dispatchers.IO.let {
        val teamId = findTeamId(teamName) ?: return@let emptyList()
        for (base in bases) {
            val (code, body) = http.get(
                "$base/team/$teamId/events/last/0",
                "https://www.sofascore.com/"
            )
            if (code in 200..299 && !body.isNullOrBlank()) {
                val parsed = parseRecentMatches(JSONObject(body), teamId).take(5)
                if (parsed.isNotEmpty()) return@let parsed
            }
        }
        emptyList()
    }

    private fun findTeamId(teamName: String): Long? {
        val query = URLEncoder.encode(teamName, Charsets.UTF_8.name())
        for (base in bases) {
            val (code, body) = http.get(
                "$base/search/all?q=$query",
                "https://www.sofascore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                val results = JSONObject(body).optJSONArray("results") ?: continue
                var bestId: Long? = null
                var bestScore = -1.0
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    if (item.optString("type").lowercase() != "team") continue
                    val entity = item.optJSONObject("entity") ?: continue
                    val id = entity.optLong("id", -1L)
                    val name = entity.optString("name")
                    if (id <= 0 || name.isBlank()) continue
                    val score = teamSimilarity(name, teamName)
                    if (score > bestScore) { bestScore = score; bestId = id }
                }
                if (bestScore >= 0.72) return bestId
            } catch (_: Exception) { }
        }
        return null
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            if (e.optJSONObject("status")?.optString("type") != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when { teamGoals > oppGoals -> "G"; teamGoals < oppGoals -> "M"; else -> "B" }
            val ts = e.optLong("startTimestamp", 0L)
            val date = if (ts > 0) java.time.Instant.ofEpochSecond(ts).atZone(ZoneOffset.UTC).toLocalDate().toString() else ""
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result)
        }
        return out.sortedByDescending { it.date }
    }
}
