CioScore v0.9.4 - AiScore 1X2 FIX

AiScore enrichment now resolves real match IDs from the official today-matches index, reads 1/X/2 from /odds pages, uses fuzzy team matching, and updates cards progressively. Core scan is never blocked by AiScore.