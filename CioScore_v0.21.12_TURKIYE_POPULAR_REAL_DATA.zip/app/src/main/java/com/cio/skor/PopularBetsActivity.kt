package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.PopularBetCluster
import com.cio.skor.data.PopularBetRepository
import com.cio.skor.data.SourceFetchResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PopularBetsActivity : Activity() {
    private val COLOR_TEXT = android.graphics.Color.rgb(16, 24, 40)
    private val COLOR_MUTED = android.graphics.Color.rgb(102, 112, 133)
    private val COLOR_SECONDARY = android.graphics.Color.rgb(52, 64, 84)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository by lazy { PopularBetRepository(applicationContext) }
    private lateinit var recycler: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top + dp(10), view.paddingRight, view.paddingBottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(6))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 38f
            setTextColor(COLOR_TEXT)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(52)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "🇹🇷 TÜRKİYE EN ÇOK OYNANANLAR"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COLOR_TEXT)
        }
        val subtitle = TextView(this).apply {
            text = "İddaa.com • Bilyoner • Nesine • Misli"
            textSize = 13f
            setTextColor(COLOR_MUTED)
            setPadding(0, dp(2), 0, 0)
        }
        titleBox.addView(title)
        titleBox.addView(subtitle)
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))

        progress = ProgressBar(this).apply { isIndeterminate = true }
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(COLOR_MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(8))
        }
        recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@PopularBetsActivity)
            setPadding(0, dp(2), 0, 0)
            clipToPadding = false
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(34)))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(recycler, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load()
    }

    private fun load() {
        progress.visibility = ProgressBar.VISIBLE
        status.text = "4 platform eşzamanlı taranıyor…"
        scope.launch {
            val results = withContext(Dispatchers.IO) { repository.fetchDetailed() }
            val clusters = repository.cluster(results.flatMap { it.records })
            progress.visibility = ProgressBar.GONE
            status.text = buildStatus(results, clusters)
            recycler.adapter = PopularAdapter(clusters)
        }
    }

    private fun buildStatus(results: List<SourceFetchResult>, clusters: List<PopularBetCluster>): String {
        val sourceLine = results.joinToString("   •   ") { r ->
            val detail = if (r.ok) "✓ ${r.records.size}" else "✗ ${r.failure?.name ?: "ERROR"}${if (r.httpCode > 0) " ${r.httpCode}" else ""}"
            "${r.sourceName}: $detail"
        }
        val cacheLine = if (repository.usedStaleCache) "\n⚠ Canlı kaynaklar yanıt vermedi; son başarılı veri gösteriliyor." else ""
        return if (clusters.isEmpty()) "$sourceLine\nHenüz ortak veri oluşmadı. Kaynak tanısı yukarıda.$cacheLine"
        else "$sourceLine\n${clusters.size} ortak maç/market bulundu.$cacheLine"
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private inner class PopularAdapter(private val items: List<PopularBetCluster>) : RecyclerView.Adapter<PopularAdapter.VH>() {
        inner class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val card = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply { setColor(android.graphics.Color.WHITE); cornerRadius = dp(14).toFloat(); setStroke(dp(1), android.graphics.Color.rgb(231, 234, 240)) }
                elevation = dp(2).toFloat()
                layoutParams = RecyclerView.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(5), dp(2), dp(5)) }
            }
            return VH(card)
        }
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.card.removeAllViews()
            holder.card.addView(text("${item.homeTeam}  —  ${item.awayTeam}", 16f, true, COLOR_TEXT))
            val time = item.bets.map { it.matchTime }.firstOrNull { it.isNotBlank() && it != "--:--" }
            if (!time.isNullOrBlank()) holder.card.addView(text("🕒 $time", 12f, false, COLOR_MUTED))
            holder.card.addView(text("${item.marketName}   •   🇹🇷 Trend Skoru: ${item.totalPopularityScore}/100", 14f, true, COLOR_TEXT))
            holder.card.addView(text("Kaynaklar: ${item.sources.joinToString(" • ")}", 12f, false, COLOR_MUTED))
            item.bets.forEach { bet ->
                val line = "${bet.sourceName}: ${bet.prediction.ifBlank { "Popüler tercih" }}" +
                    (if (bet.ratioOrCount.isNotBlank()) "  ${bet.ratioOrCount}" else "") +
                    (if (bet.odds.isNotBlank()) "  oran ${bet.odds}" else "")
                holder.card.addView(text(line, 13f, false, COLOR_SECONDARY))
            }
        }
        private fun text(value: String, size: Float, bold: Boolean, color: Int): TextView = TextView(this@PopularBetsActivity).apply {
            text = value; textSize = size; setTextColor(color); setTypeface(typeface, if (bold) Typeface.BOLD else Typeface.NORMAL)
            setPadding(0, dp(3), 0, dp(3))
        }
    }
}
