package com.cio.skor.data

import android.content.Context
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

interface PopularBetParser {
    val sourceName: String
    val pageUrl: String
    fun parseHtml(body: String): List<PopularBetModel> = emptyList()

    suspend fun fetch(context: Context): SourceFetchResult {
        val http = PopularBetHttpClient.get(pageUrl)
        if (http.isSuccess) {
            val htmlRecords = runCatching { parseHtml(http.body.orEmpty()) }.getOrDefault(emptyList())
            if (htmlRecords.isNotEmpty()) {
                return SourceFetchResult.success(sourceName, pageUrl, htmlRecords, http.code, http.attempts)
            }
        }

        // These operator pages are frequently JS-rendered. If the raw HTML does not
        // contain the betting rows, render the public page in WebView and parse visible text.
        val rendered = PopularBetWebViewFetcher.fetch(context, pageUrl)
        if (!rendered.isNullOrBlank()) {
            val renderedRecords = parseRenderedText(rendered)
            if (renderedRecords.isNotEmpty()) {
                return SourceFetchResult.success(sourceName, pageUrl, renderedRecords, http.code, http.attempts)
            }
        }

        val reason = if (http.code != 0 && !http.isSuccess) SourceFailure.HTTP else SourceFailure.EMPTY
        return SourceFetchResult.failure(
            sourceName,
            pageUrl,
            reason,
            http.code,
            http.attempts,
            http.error ?: "Sayfa yüklendi ancak popüler bahis satırları ayrıştırılamadı"
        )
    }

    private fun parseRenderedText(body: String): List<PopularBetModel> {
        val lines = body.lines()
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }

        val out = mutableListOf<PopularBetModel>()
        val matchRegex = Regex("^(.{2,80}?)\\s+(?:[-–—]|vs\\.?|v\\.?|VS)\\s+(.{2,80})$", RegexOption.IGNORE_CASE)
        val skip = setOf("karşılaşma", "bahis", "oran", "tarih", "maçlar", "popüler bahisler", "anlık bahis")

        for (i in lines.indices) {
            val match = matchRegex.find(lines[i]) ?: continue
            val home = cleanTeam(match.groupValues[1])
            val away = cleanTeam(match.groupValues[2])
            if (home.length < 2 || away.length < 2 || skip.any { lines[i].equals(it, true) }) continue

            val window = lines.subList(i + 1, minOf(lines.size, i + 9))
            val combined = window.joinToString(" | ")
            val popularity = extractPopularity(combined) ?: continue
            val market = extractMarket(window)
            val odds = extractOdds(combined)
            val time = extractTime(window)
            val selection = extractSelection(window, market)
            val prediction = when {
                selection.isNotBlank() -> selection
                market.isNotBlank() -> market
                else -> "Popüler tercih"
            }

            out += PopularBetModel(
                sourceName = sourceName,
                rawHomeTeam = home,
                rawAwayTeam = away,
                prediction = prediction,
                ratioOrCount = popularity,
                odds = odds,
                matchTime = time
            )
        }
        return out.distinctBy { "${it.rawHomeTeam}|${it.rawAwayTeam}|${canonicalMarket(it.prediction)}|${it.ratioOrCount}" }
    }

    fun attrAny(el: Element, vararg names: String): String =
        names.asSequence().map { el.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: ""

    fun guessMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        val patterns = listOf("MS 1", "MS1", "MS X", "MSX", "MS 2", "MS2", "MAÇ SONUCU", "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KARŞILIKLI GOL", "KG VAR", "KG YOK")
        return patterns.firstOrNull { upper.contains(it) } ?: ""
    }

    fun guessRatio(text: String): String = Regex("(?:\\d[\\d.]*\\+?\\s*(?:Kez|kez|oynandı)|%\\s?\\d{1,3})")
        .find(text)?.value?.trim() ?: ""

    fun guessOdds(text: String): String = Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)")
        .find(text)?.value ?: ""

    fun canonicalMarket(value: String): String = value.lowercase(Locale("tr", "TR"))
        .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
        .replace("ş", "s").replace("ö", "o").replace("ç", "c")
        .replace(Regex("\\s+"), " ").trim()

    private fun cleanTeam(value: String): String = value
        .replace(Regex("[•|]+"), " ")
        .replace(Regex("\\b(TV|Canlı|Yeni)\\b", RegexOption.IGNORE_CASE), "")
        .trim(' ', '-', '–', '—')

    private fun extractPopularity(text: String): String? =
        Regex("\\b(\\d[\\d.]*)\\+?\\s*(?:Kez|kez|Oynandı|oynandı)\\b")
            .find(text)?.groupValues?.getOrNull(1)
            ?: Regex("%(?:\\s*)?(\\d{1,3})").find(text)?.groupValues?.getOrNull(1)?.let { "%$it" }

    private fun extractOdds(text: String): String =
        Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)").find(text)?.value.orEmpty()

    private fun extractTime(lines: List<String>): String =
        lines.firstOrNull { Regex("(?:Bugün|Yarın|\\b\\d{1,2}[:.]\\d{2})", RegexOption.IGNORE_CASE).containsMatchIn(it) }
            ?.let { Regex("\\b\\d{1,2}[:.]\\d{2}\\b").find(it)?.value ?: it.take(32) }.orEmpty()

    private fun extractMarket(lines: List<String>): String =
        lines.firstNotNullOfOrNull { line ->
            when {
                line.contains("Maç Sonucu", true) -> "Maç Sonucu"
                line.contains("Karşılıklı Gol", true) -> "Karşılıklı Gol"
                line.contains("Toplam Gol", true) -> "Toplam Gol"
                line.contains("Alt/Üst", true) -> "Alt/Üst"
                line.contains("MS&Toplam", true) -> "MS&Toplam Gol"
                line.contains("1.Y Gol", true) -> "1.Y Gol"
                else -> null
            }
        }.orEmpty()

    private fun extractSelection(lines: List<String>, market: String): String {
        val text = lines.joinToString(" ")
        val direct = Regex("\\bMS\\s*([12X])\\b", RegexOption.IGNORE_CASE).find(text)
        if (direct != null) return "MS ${direct.groupValues[1].uppercase()}"
        if (text.contains("Var", true) && market.contains("Gol", true)) return "KG Var"
        if (text.contains("Yok", true) && market.contains("Gol", true)) return "KG Yok"
        Regex("\\b([12X])\\b").find(lines.take(4).joinToString(" "))?.let { return it.groupValues[1] }
        return ""
    }
}

enum class SourceFailure { HTTP, PARSE, EMPTY, EXCEPTION }

data class SourceFetchResult(
    val sourceName: String,
    val url: String,
    val records: List<PopularBetModel>,
    val failure: SourceFailure? = null,
    val httpCode: Int = 0,
    val attempts: Int = 0,
    val errorMessage: String? = null
) {
    val ok: Boolean get() = failure == null && records.isNotEmpty()
    val error: String? get() = errorMessage
    companion object {
        fun success(source: String, url: String, records: List<PopularBetModel>, code: Int, attempts: Int) =
            SourceFetchResult(source, url, records, null, code, attempts, null)
        fun failure(source: String, url: String, reason: SourceFailure, code: Int, attempts: Int, message: String?) =
            SourceFetchResult(source, url, emptyList(), reason, code, attempts, message)
    }
}

class IddaaPopularParser : PopularBetParser {
    override val sourceName = "İddaa.com"
    override val pageUrl = "https://www.iddaa.com/populer-bahisler/futbol"
    override fun parseHtml(body: String): List<PopularBetModel> = parseStructured(body)

    private fun parseStructured(body: String): List<PopularBetModel> {
        val doc = Jsoup.parse(body, pageUrl)
        return doc.select("[data-home-team][data-away-team], [data-hometeam][data-awayteam], [data-home][data-away]").mapNotNull { el ->
            val home = attrAny(el, "data-home-team", "data-hometeam", "data-home")
            val away = attrAny(el, "data-away-team", "data-awayteam", "data-away")
            if (home.isBlank() || away.isBlank()) null else PopularBetModel(sourceName, home, away, prediction = guessMarket(el.text()), ratioOrCount = guessRatio(el.text()), odds = guessOdds(el.text()))
        }
    }
}

class NesinePopularParser : PopularBetParser {
    override val sourceName = "Nesine"
    override val pageUrl = "https://www.nesine.com/iddaa/dakika-bahis"
}

class MisliPopularParser : PopularBetParser {
    override val sourceName = "Misli"
    override val pageUrl = "https://www.misli.com/iddaa/anlik-bahis"
}

class BilyonerPopularParser : PopularBetParser {
    override val sourceName = "Bilyoner"
    override val pageUrl = "https://www.bilyoner.com/iddaa/populer-bahisler"
}
