package com.cio.skor.data

import kotlin.math.abs
import kotlin.math.roundToInt

/** Consolidates the same fixture + market across the four Turkish sources. */
object PopularBetMerger {
    fun merge(raw: List<PopularBetModel>): List<PopularBetCluster> {
        if (raw.isEmpty()) return emptyList()
        val sourceMax = raw.groupBy { it.sourceName }
            .mapValues { (_, list) -> list.mapNotNull(::numericPopularity).maxOrNull() ?: 0.0 }

        val clusters = mutableListOf<MutableList<PopularBetModel>>()
        for (item in raw.filter { it.rawHomeTeam.isNotBlank() && it.rawAwayTeam.isNotBlank() }) {
            val match = clusters.firstOrNull { group -> group.any { sameFixtureAndMarket(it, item) } }
            if (match != null) match += item else clusters += mutableListOf(item)
        }

        return clusters.mapNotNull { group ->
            val first = group.firstOrNull() ?: return@mapNotNull null
            val score = group.distinctBy { it.sourceName }.sumOf { bet -> sourceContribution(bet, sourceMax[bet.sourceName] ?: 0.0) }
            PopularBetCluster(
                fixtureKey = MatchMerger.key(first.rawHomeTeam, first.rawAwayTeam),
                homeTeam = preferredName(group.map { it.rawHomeTeam }),
                awayTeam = preferredName(group.map { it.rawAwayTeam }),
                matchCode = group.firstOrNull { it.matchCode.isNotBlank() }?.matchCode.orEmpty(),
                marketName = first.prediction.ifBlank { "Popüler tercih" },
                totalPopularityScore = score.coerceIn(0, 100),
                sources = group.map { it.sourceName }.distinct(),
                bets = group.sortedWith(compareBy<PopularBetModel> { sourceOrder(it.sourceName) }.thenBy { it.prediction })
            )
        }.sortedWith(compareByDescending<PopularBetCluster> { it.totalPopularityScore }.thenByDescending { it.sourceCount })
    }

    private fun sameFixtureAndMarket(a: PopularBetModel, b: PopularBetModel): Boolean {
        if (canonicalMarket(a.prediction) != canonicalMarket(b.prediction)) return false
        if (a.matchCode.isNotBlank() && b.matchCode.isNotBlank() && a.sourceName == b.sourceName && a.matchCode != b.matchCode) return false
        val home = TeamAliasCanonicalizer.similarity(a.rawHomeTeam, b.rawHomeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.rawAwayTeam, b.rawAwayTeam)
        val canonicalHome = TeamAliasCanonicalizer.canonical(a.rawHomeTeam)
        val canonicalAway = TeamAliasCanonicalizer.canonical(a.rawAwayTeam)
        val canonicalHomeB = TeamAliasCanonicalizer.canonical(b.rawHomeTeam)
        val canonicalAwayB = TeamAliasCanonicalizer.canonical(b.rawAwayTeam)
        if (canonicalHome.isNotBlank() && canonicalHomeB.isNotBlank() && canonicalHome == canonicalHomeB &&
            canonicalAway.isNotBlank() && canonicalAwayB.isNotBlank() && canonicalAway == canonicalAwayB) return true
        if (home < 0.84 || away < 0.84) return false
        if (a.matchTimestamp > 0 && b.matchTimestamp > 0) {
            val hours = abs(a.matchTimestamp - b.matchTimestamp) / 3_600_000.0
            if (hours > 3.0) return false
        }
        return true
    }

    private fun numericPopularity(bet: PopularBetModel): Double? {
        val value = bet.ratioOrCount.replace("%", "").replace(".", "").replace(",", ".")
            .trim().filter { it.isDigit() || it == '.' }
        return value.toDoubleOrNull()
    }

    private fun sourceContribution(bet: PopularBetModel, sourceMax: Double): Int {
        val raw = numericPopularity(bet) ?: return 25
        val text = bet.ratioOrCount
        return if (text.contains('%')) {
            (raw.coerceIn(0.0, 100.0) / 4.0).roundToInt().coerceIn(0, 25)
        } else if (sourceMax > 0.0) {
            (25.0 * raw / sourceMax).roundToInt().coerceIn(0, 25)
        } else 0
    }

    private fun canonicalMarket(value: String): String = PopularBetParserCanonical.canonical(value)

    private fun preferredName(names: List<String>): String = names.maxByOrNull { scoreName(it) } ?: ""
    private fun scoreName(name: String): Int = name.length - Regex("\\b(fc|fk|sk|cf)\\b", RegexOption.IGNORE_CASE).findAll(name).count() * 3
    private fun sourceOrder(source: String): Int = when (source) { "İddaa" -> 0; "Bilyoner" -> 1; "Nesine" -> 2; "Misli" -> 3; else -> 9 }
}

private object PopularBetParserCanonical {
    fun canonical(value: String): String = value.lowercase()
        .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
        .replace("ş", "s").replace("ö", "o").replace("ç", "c")
        .replace(Regex("\\s+"), " ").trim()
}
