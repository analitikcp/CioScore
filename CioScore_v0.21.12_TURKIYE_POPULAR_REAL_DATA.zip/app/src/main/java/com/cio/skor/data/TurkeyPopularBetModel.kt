package com.cio.skor.data

data class TurkeyPopularBetModel(
    val matchId: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchTime: String,
    val leagueName: String,
    val marketName: String,
    val odds: String,
    val totalPopularityScore: Int,
    val sources: List<String>
)
