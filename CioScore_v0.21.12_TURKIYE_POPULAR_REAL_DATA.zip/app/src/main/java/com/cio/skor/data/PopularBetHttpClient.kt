package com.cio.skor.data

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Network layer for popular-bet sources.
 * It reports HTTP/body diagnostics instead of silently converting every failure
 * into an empty list. Retries are deliberately bounded to avoid hammering sources.
 */
object PopularBetHttpClient {
    data class HttpResult(
        val url: String,
        val code: Int,
        val body: String?,
        val attempts: Int,
        val error: String? = null
    ) {
        val isSuccess: Boolean get() = code in 200..299 && !body.isNullOrBlank()
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    fun get(url: String, maxAttempts: Int = 2): HttpResult {
        var lastError: String? = null
        var lastCode = 0
        repeat(maxAttempts.coerceAtLeast(1)) { attemptIndex ->
            val attempt = attemptIndex + 1
            try {
                client.newCall(buildRequest(url)).execute().use { response ->
                    lastCode = response.code
                    val body = response.body?.string()
                    if (response.isSuccessful && !body.isNullOrBlank()) {
                        return HttpResult(url, response.code, body, attempt)
                    }
                    lastError = "HTTP ${response.code}${if (body.isNullOrBlank()) " / empty body" else ""}"
                }
            } catch (t: Throwable) {
                lastError = "${t::class.simpleName}: ${t.message.orEmpty()}".take(240)
            }
            if (attempt < maxAttempts) Thread.sleep(350L * attempt)
        }
        return HttpResult(url, lastCode, null, maxAttempts.coerceAtLeast(1), lastError ?: "Unknown network error")
    }

    private fun refererFor(url: String): String = url

    fun buildRequest(url: String): Request = Request.Builder()
        .url(url)
        .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
        .header("Accept", "text/html,application/xhtml+xml,application/json,text/plain,*/*")
        .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.7,en;q=0.5")
        .header("Cache-Control", "no-cache")
        .header("Pragma", "no-cache")
        .header("Referer", refererFor(url))
        .build()
}
