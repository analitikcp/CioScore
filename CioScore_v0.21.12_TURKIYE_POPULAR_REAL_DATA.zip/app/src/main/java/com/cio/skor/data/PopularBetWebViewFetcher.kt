package com.cio.skor.data

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Fallback reader for JS-rendered operator pages. It does not bypass WAF/Cloudflare;
 * it simply lets the public page render in Android WebView and reads visible text.
 */
object PopularBetWebViewFetcher {
    @SuppressLint("SetJavaScriptEnabled")
    suspend fun fetch(context: Context, url: String): String? {
        return withTimeoutOrNull(28_000L) {
            suspendCancellableCoroutine { cont ->
                val handler = Handler(Looper.getMainLooper())
                var webView: WebView? = null
                var finished = false

                fun cleanup() {
                    handler.removeCallbacksAndMessages(null)
                    webView?.apply {
                        stopLoading()
                        webChromeClient = null
                        webViewClient = WebViewClient()
                        destroy()
                    }
                    webView = null
                }

                fun complete(value: String?) {
                    if (finished) return
                    finished = true
                    cleanup()
                    if (cont.isActive) cont.resume(value)
                }

                cont.invokeOnCancellation { handler.post { cleanup() } }

                handler.post {
                    try {
                        val wv = WebView(context.applicationContext)
                        webView = wv
                        wv.settings.javaScriptEnabled = true
                        wv.settings.domStorageEnabled = true
                        wv.settings.loadsImagesAutomatically = false
                        wv.settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                            "(KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
                        wv.webChromeClient = WebChromeClient()
                        wv.webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                handler.postDelayed({ extract(wv, ::complete) }, 3_000L)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                handler.postDelayed({ extract(wv, ::complete) }, 1_800L)
                            }

                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
                        }
                        wv.loadUrl(url)
                    } catch (_: Throwable) {
                        complete(null)
                    }
                }
            }
        }
    }

    private fun extract(webView: WebView, complete: (String?) -> Unit) {
        val script = """
            (function(){
              try {
                var t = document && document.body ? document.body.innerText : '';
                return t || '';
              } catch(e) { return ''; }
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) { raw ->
            val text = decodeJsString(raw)
            if (text.length >= 80) complete(text)
        }
    }

    private fun decodeJsString(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        return runCatching {
            org.json.JSONTokener(raw).nextValue()?.toString().orEmpty()
        }.getOrElse { raw.removePrefix("\"").removeSuffix("\"") }
    }
}
