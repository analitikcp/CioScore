package com.cio.skor.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

class PopularBetRepository(
    private val context: Context,
    private val parsers: List<PopularBetParser> = listOf(
        IddaaPopularParser(), BilyonerPopularParser(), NesinePopularParser(), MisliPopularParser()
    )
) {
    companion object {
        private const val PREF = "turkey_popular_cache"
        private const val KEY_DATA = "records"
        private const val KEY_TIME = "saved_at"
        private const val FRESH_MS = 4 * 60 * 1000L
        private const val STALE_MS = 30 * 60 * 1000L
        private val memory = ConcurrentHashMap<String, CachedRecords>()
    }

    data class CachedRecords(val savedAt: Long, val records: List<PopularBetModel>)
    @Volatile var usedStaleCache: Boolean = false
        private set

    suspend fun fetchDetailed(): List<SourceFetchResult> = supervisorScope {
        usedStaleCache = false
        val now = System.currentTimeMillis()
        val cached = loadCache()
        if (cached != null && now - cached.savedAt <= FRESH_MS) {
            return@supervisorScope cached.records.groupBy { it.sourceName }.map { (source, records) ->
                SourceFetchResult.success(source, "cache", records, 200, 0)
            }
        }

        val live = parsers.map { parser ->
            async(Dispatchers.IO) {
                runCatching { parser.fetch(context) }.getOrElse { error ->
                    SourceFetchResult.failure(parser.sourceName, parser.pageUrl, SourceFailure.EXCEPTION, 0, 1, error.message)
                }
            }
        }.awaitAll()

        val freshRecords = live.flatMap { it.records }
        if (freshRecords.isNotEmpty()) saveCache(freshRecords)

        if (freshRecords.isEmpty() && cached != null && now - cached.savedAt <= STALE_MS) {
            usedStaleCache = true
            val cachedBySource = cached.records.groupBy { it.sourceName }
            return@supervisorScope live.map { result ->
                val records = cachedBySource[result.sourceName].orEmpty()
                if (records.isNotEmpty()) result.copy(records = records, failure = null, httpCode = result.httpCode) else result
            }
        }
        live
    }

    suspend fun fetchAll(): List<PopularBetModel> = fetchDetailed().flatMap { it.records }

    fun cluster(raw: List<PopularBetModel>): List<PopularBetCluster> = PopularBetMerger.merge(raw)

    fun getTurkeyPopularBets(raw: List<PopularBetModel>): List<TurkeyPopularBetModel> =
        cluster(raw).map { cluster ->
            TurkeyPopularBetModel(
                matchId = cluster.matchCode.ifBlank { cluster.fixtureKey },
                homeTeam = cluster.homeTeam,
                awayTeam = cluster.awayTeam,
                matchTime = cluster.bets.map { it.matchTime }.firstOrNull { it.isNotBlank() && it != "--:--" }.orEmpty(),
                leagueName = "",
                marketName = cluster.marketName,
                odds = cluster.bets.firstOrNull { it.odds.isNotBlank() }?.odds.orEmpty(),
                totalPopularityScore = cluster.totalPopularityScore,
                sources = cluster.sources
            )
        }

    private fun loadCache(): CachedRecords? {
        memory["all"]?.let { return it }
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val time = prefs.getLong(KEY_TIME, 0L)
        val raw = prefs.getString(KEY_DATA, null) ?: return null
        val records = runCatching {
            val arr = JSONArray(raw)
            buildList(arr.length()) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(PopularBetModel(o.optString("source"), o.optString("home"), o.optString("away"), o.optString("code"), o.optString("prediction"), o.optString("ratio"), o.optString("odds"), o.optLong("ts"), o.optString("date"), o.optString("time")))
                }
            }
        }.getOrDefault(emptyList())
        if (records.isEmpty()) return null
        return CachedRecords(time, records).also { memory["all"] = it }
    }

    private fun saveCache(records: List<PopularBetModel>) {
        val now = System.currentTimeMillis()
        val arr = JSONArray()
        records.forEach { r ->
            arr.put(JSONObject().apply {
                put("source", r.sourceName); put("home", r.rawHomeTeam); put("away", r.rawAwayTeam)
                put("code", r.matchCode); put("prediction", r.prediction); put("ratio", r.ratioOrCount)
                put("odds", r.odds); put("ts", r.matchTimestamp); put("date", r.matchDate); put("time", r.matchTime)
            })
        }
        val cached = CachedRecords(now, records)
        memory["all"] = cached
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putLong(KEY_TIME, now).putString(KEY_DATA, arr.toString()).apply()
    }
}
