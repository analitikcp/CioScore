# CioScore v0.21.12 — Turkey Popular Real Rendered Data

- 4 public operator pages are queried in parallel.
- Raw HTTP is attempted first; JS-rendered pages fall back to Android WebView visible-text extraction.
- Sources: İddaa.com, Bilyoner, Nesine, Misli.
- Misli URL corrected to `/iddaa/anlik-bahis`.
- TeamAliasCanonicalizer is used by PopularBetMerger before fuzzy matching.
- 4-minute fresh cache + 30-minute stale fallback using SharedPreferences.
- Retry remains bounded; no Cloudflare/WAF bypass is attempted.
- Popular screen header is moved below the status bar and given a compact back button.
- No fake/mock betting data is displayed to the user.

Build validation note: this environment does not have a Gradle executable or project wrapper, so APK compilation could not be run locally.
