package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.max

/**
 * Optional SofaScore enrichment layer.
 *
 * The score pipeline does not depend on this service. Odds are fetched only
 * when the user opens a match's ORANLAR panel, which keeps the main scan fast
 * and avoids making dozens of bookmaker requests for every scan.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)

    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String,
        val league: String = ""
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String,
        val homeTeamId: Long?,
        val awayTeamId: Long?
    )

    private data class Provider(
        val id: Long,
        val name: String,
        val slug: String,
        val weight: Int = 0
    )

    private val http = HttpClient()
    private val base = "https://www.sofascore.com/api/v1"

    /**
     * Fetch bookmaker 1X2 odds for one fixture. Provider order is deliberate:
     * Bet365 first, then bwin, then other major books. If one preferred book
     * is unavailable for the fixture, other available providers fill the list.
     */
    suspend fun fetchBookmakerOdds(homeTeam: String, awayTeam: String): List<BookmakerOdds> =
        withContext(Dispatchers.IO) {
            val events = runCatching { loadTodayEvents() }.getOrDefault(emptyList())
            val event = events.firstOrNull {
                MatchMerger.isSameTeam(it.home, homeTeam) &&
                    MatchMerger.isSameTeam(it.away, awayTeam)
            } ?: return@withContext emptyList()

            val providers = loadProviders()
            if (providers.isEmpty()) return@withContext emptyList()

            // Preferred order. The runtime provider catalogue decides which
            // of these are actually available for the current country/event.
            val preferred = listOf(
                "bet365",
                "bwin",
                "betfair",
                "william hill",
                "williamhill",
                "unibet",
                "pinnacle",
                "1xbet",
                "betway"
            )

            val preferredProviders = preferred.mapNotNull { wanted ->
                providers.firstOrNull { p ->
                    p.name.contains(wanted, ignoreCase = true) ||
                        p.slug.contains(wanted.replace(" ", ""), ignoreCase = true) ||
                        p.slug.contains(wanted.replace(" ", "-"), ignoreCase = true)
                }
            }.distinctBy { it.id }

            val fallbackProviders = providers
                .filter { candidate -> preferredProviders.none { it.id == candidate.id } }
                .sortedByDescending { it.weight }

            val selected = (preferredProviders + fallbackProviders).take(8)

            // Keep network pressure bounded. Only 8 provider calls are made and
            // the first five successful complete 1X2 rows are enough for UI.
            val fetched = coroutineScope {
                selected.map { provider ->
                    async(Dispatchers.IO) {
                        loadProviderOdds(event.id, provider)?.let { odds ->
                            BookmakerOdds(provider.name, odds.home, odds.draw, odds.away)
                        }
                    }
                }.awaitAll().filterNotNull()
            }

            // Re-establish the requested provider order even if HTTP completion
            // order differed. Keep more than five when the source provides them.
            fetched.sortedWith(compareBy<BookmakerOdds> {
                val index = preferred.indexOfFirst { key ->
                    it.bookmaker.contains(key, ignoreCase = true) ||
                        it.bookmaker.replace(" ", "").contains(key.replace(" ", ""), ignoreCase = true)
                }
                if (index >= 0) index else 100
            }).take(8)
        }

    /** Legacy helper retained for callers that only need a single 1X2 set. */
    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups
        val out = groups.toMutableList()
        groups.chunked(8).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val rows = fetchBookmakerOdds(group.homeTeam, group.awayTeam)
                    val first = rows.firstOrNull()
                    if (first == null) group else group.copy(
                        odds = Odds(first.ms1, first.msX, first.ms2)
                    )
                }
            }.awaitAll()
            val start = chunkIndex * 8
            results.forEachIndexed { index, value -> out[start + index] = value }
        }
        out
    }

    suspend fun enrichTeamIds(groups: List<MatchGroupData>): List<MatchGroupData> = withContext(Dispatchers.IO) {
        if (groups.isEmpty()) return@withContext groups
        val events = runCatching { loadTodayEvents() }.getOrDefault(emptyList())
        if (events.isEmpty()) return@withContext groups
        groups.map { group ->
            runCatching {
                val event = events.firstOrNull {
                    MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                        MatchMerger.isSameTeam(it.away, group.awayTeam)
                }
                if (event == null) group else group.copy(
                    homeTeamId = event.homeTeamId,
                    awayTeamId = event.awayTeamId
                )
            }.getOrDefault(group)
        }
    }

    suspend fun resolveTeamId(teamName: String): Long? = withContext(Dispatchers.IO) {
        if (teamName.isBlank()) return@withContext null
        findTeamId(teamName)
    }

    suspend fun getLastFiveByTeamId(teamId: Long): List<RecentMatch> = withContext(Dispatchers.IO) {
        if (teamId <= 0L) return@withContext emptyList()
        val (code, body) = http.get("$base/team/$teamId/events/last/0", "https://www.sofascore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return@withContext emptyList()
        runCatching { parseRecentMatches(JSONObject(body), teamId).take(5) }.getOrDefault(emptyList())
    }

    private fun loadProviders(): List<Provider> {
        val urls = listOf(
            "$base/odds/providers/TR/web",
            "$base/odds/providers/INT/web",
            "$base/odds/providers/GB/web"
        )
        for (url in urls) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseProviders(body)?.let { if (it.isNotEmpty()) return it }
        }
        // Bet365's international provider id is stable in SofaScore's provider
        // catalogue and is retained as a last-resort fallback.
        return listOf(Provider(1L, "Bet365", "bet365", 100))
    }

    private fun parseProviders(body: String): List<Provider>? {
        return runCatching {
            val root = body.trim()
            val array = if (root.startsWith("[")) {
                JSONArray(root)
            } else {
                val obj = JSONObject(root)
                obj.optJSONArray("providers")
                    ?: obj.optJSONArray("data")
                    ?: obj.optJSONArray("items")
                    ?: return@runCatching emptyList()
            }
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val provider = item.optJSONObject("provider") ?: item.optJSONObject("fallbackProvider") ?: item
                    val id = provider.optLong("id", item.optLong("id", -1L))
                    val name = provider.optString("name").trim()
                    val slug = provider.optString("slug").trim()
                    val weight = item.optInt("weight", provider.optInt("weight", 0))
                    if (id > 0 && name.isNotBlank()) add(Provider(id, name, slug, weight))
                }
            }
        }.getOrNull()
    }

    private fun loadProviderOdds(eventId: Long, providerId: Long): Odds? {
        val paths = listOf(
            "$base/event/$eventId/odds/$providerId/featured",
            "$base/event/$eventId/odds/$providerId/all"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseOdds(JSONObject(body))?.let { return it }
        }
        return null
    }

    private fun loadTodayEvents(): List<EventRef> {
        val date = LocalDate.now().toString()
        val (code, body) = http.get(
            "$base/sport/football/scheduled-events/$date",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    val homeId = e.optJSONObject("homeTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                    val awayId = e.optJSONObject("awayTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) add(EventRef(id, home, away, homeId, awayId))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseOdds(root: JSONObject): Odds? {
        fun readChoices(value: JSONObject): Odds? {
            val choices = value.optJSONArray("choices") ?: return null
            var one: String? = null
            var draw: String? = null
            var two: String? = null
            for (i in 0 until choices.length()) {
                val c = choices.optJSONObject(i) ?: continue
                val name = c.optString("name").trim().uppercase()
                val decimal = c.opt("decimalValue")?.toString()?.toDoubleOrNull()
                    ?: fractionalToDecimal(c.optString("fractionalValue"))
                if (decimal == null || decimal <= 1.0 || decimal > 100.0) continue
                val formatted = String.format(java.util.Locale.US, "%.2f", decimal)
                when (name) {
                    "1", "HOME" -> one = formatted
                    "X", "DRAW" -> draw = formatted
                    "2", "AWAY" -> two = formatted
                }
            }
            return if (one != null && draw != null && two != null) Odds(one!!, draw!!, two!!) else null
        }

        // Prefer the featured full-time 1X2 market.
        root.optJSONObject("featured")?.let { featured ->
            featured.optJSONObject("fullTime")?.let { readChoices(it)?.let { return it } }
            featured.optJSONObject("default")?.let { readChoices(it)?.let { return it } }
        }
        root.optJSONArray("markets")?.let { markets ->
            for (i in 0 until markets.length()) {
                val market = markets.optJSONObject(i) ?: continue
                val marketId = market.optInt("marketId", -1)
                val name = market.optString("marketName").lowercase()
                if (marketId == 1 || name.contains("full time") || name == "1x2") {
                    readChoices(market)?.let { return it }
                }
            }
        }
        return null
    }

    private fun fractionalToDecimal(value: String): Double? {
        val parts = value.trim().split('/')
        if (parts.size != 2) return null
        val numerator = parts[0].toDoubleOrNull() ?: return null
        val denominator = parts[1].toDoubleOrNull() ?: return null
        if (denominator == 0.0) return null
        return 1.0 + numerator / denominator
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$base/search/all?q=$query",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase()
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            val league = e.optJSONObject("tournament")?.optString("name").orEmpty()
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result, league)
        }
        return out.sortedByDescending { it.date }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null,
        val homeTeamId: Long? = null,
        val awayTeamId: Long? = null
    )
}
