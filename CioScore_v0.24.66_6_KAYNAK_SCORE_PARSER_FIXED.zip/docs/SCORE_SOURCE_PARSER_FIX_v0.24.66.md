# v0.24.66 — 5/6. kaynak skor okuma düzeltmesi

TheFootballPredictions ve SureWinPredict günlük correct-score sayfalarında doğru skor,
puan/olasılık ve oran alanlarından ayrı bir alandır.

Örnek canlı kayıtlar (22.09.2026):
- The Football Predictions: Crewe vs Aston Villa U21 -> 1-1, points 16/84.
- SureWinPredict: Crewe vs Aston Villa U21 -> 1-1, probability 12.50%, odds 8.00.

Parser kuralı:
1. Fixture linkinin en küçük DOM container'ı bulunur.
2. Container içinde başka fixture linki varsa skor okunmaz.
3. Correct-score regex'i yalnızca tek haneli futbol skorunu kabul eder.
4. Container içindeki ilk gerçek `H - A` skor token'ı alınır.
5. 16, 18, 19, 20 gibi puan/olasılık değerleri skor olarak hiçbir koşulda birleştirilmez.

GlobalFixtureMatcher / MatchMerger / alias eşikleri değiştirilmemiştir.
