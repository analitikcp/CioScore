package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** SureWinPredict daily correct-score page parser. */
class SureWinPredictParser : BaseParser("SureWinPredict") {

    private val matchPath = Regex("/match/([^/?#]+-vs-[^/?#]+?)(?:-\\d+-\\d+)?/(\\d{4}-\\d{2}-\\d{2})", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href*='/match/']")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val match = matchPath.find(href) ?: continue
            val fixtureSlug = match.groupValues[1]
            val date = match.groupValues[2]
            val pair = splitFixture(fixtureSlug) ?: continue

            // SureWinPredict's daily list places the exact score in the fixture
            // line itself (or the immediate sibling cell). Never climb to a broad
            // ancestor: those containers also contain live/results/odds numbers.
            val linkText = link.ownText().replace('\u00A0', ' ')
            val row = link.closest("tr")
            val context = row?.text()?.replace('\u00A0', ' ') ?: link.parent()?.text()?.replace('\u00A0', ' ') ?: link.text()
            val scorePair = extractSureWinCorrectScore(linkText)
                ?: scoreFromImmediateRowCells(link)
                ?: continue
            val predictedScore = "${scorePair.first}-${scorePair.second}"
            val time = timeRegex.find(context)?.value ?: "--:--"

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val sourceId = href.substringAfter("/match/").substringBefore('/').trim()
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = predictedScore,
                source = source,
                sourceMatchId = sourceId,
                matchDate = date,
                matchTime = time
            )
            out["ID|$sourceId"] = model
        }

        return out.values.toList()
    }

    // Correct scores are single-digit football scores. Percentages/odds such as
    // 16.00, 18.52 or 20.00 are not scores and must never be combined into one.
    private val sureWinScoreRegex = Regex("(?<!\\d)([0-9])\\s*-\\s*([0-9])(?!\\d)")

    private fun extractSureWinCorrectScore(text: String): Pair<Int, Int>? =
        sureWinScoreRegex.find(text.replace('\u00A0', ' '))?.let {
            it.groupValues[1].toInt() to it.groupValues[2].toInt()
        }

    private fun scoreFromImmediateRowCells(link: org.jsoup.nodes.Element): Pair<Int, Int>? {
        fun first(text: String): Pair<Int, Int>? =
            sureWinScoreRegex.find(text.replace('\u00A0', ' '))?.let {
                it.groupValues[1].toInt() to it.groupValues[2].toInt()
            }

        // The daily page renders one fixture per small clickable item. Select
        // the smallest ancestor containing this link and no second /match link.
        // This avoids crossing into the next fixture or its numbers.
        var node: org.jsoup.nodes.Element? = link
        repeat(8) {
            node = node?.parent()
            val candidate = node ?: return@repeat
            val matchLinks = candidate.select("a[href*='/match/']")
            if (matchLinks.size == 1) {
                first(candidate.text())?.let { return it }
            }
        }

        // Local sibling fallback for responsive markup.
        first(link.parent()?.text().orEmpty())?.let { return it }
        var sibling = link.nextElementSibling()
        repeat(6) {
            val element = sibling ?: return@repeat
            first(element.text())?.let { return it }
            sibling = element.nextElementSibling()
        }
        return null
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val marker = "-vs-"
        val idx = slug.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(slug.substring(0, idx))
        val away = slugWords(slug.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
