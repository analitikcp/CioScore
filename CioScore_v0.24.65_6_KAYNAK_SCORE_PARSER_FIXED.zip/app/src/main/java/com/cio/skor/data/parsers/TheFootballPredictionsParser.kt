package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * The Football Predictions exact-score list parser.
 *
 * The public page exposes each fixture as a link whose slug contains
 * `home-vs-away`, while the surrounding row contains kickoff time and the
 * predicted exact score. We deliberately use the fixture URL as identity
 * instead of trying to split the concatenated visible team text.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    private val fixtureHref = Regex("/([^/?#]+-vs-[^/?#]+-prediction[^/?#]*)", RegexOption.IGNORE_CASE)
    private val dateInSlug = Regex("date-(\\d{2}-\\d{2}-\\d{4})", RegexOption.IGNORE_CASE)
    private val gameId = Regex("game-id-([A-Za-z0-9_-]+)", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href]")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            if (!fixtureHref.containsMatchIn(href)) continue
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            val pair = splitFixture(slug) ?: continue

            // TFP renders the correct score immediately AFTER the fixture link,
            // followed by two point values (e.g. 16 and 84).  Never search an
            // arbitrary ancestor: that is how point values/other rows can become
            // a fake score such as 16-0 or 20-0.
            val score = scoreImmediatelyAfterFixtureLink(link) ?: continue
            val context = fixtureRowText(link)
            val time = timeRegex.find(context)?.value ?: "--:--"
            val date = dateInSlug.find(slug)?.groupValues?.get(1)?.let(::toIsoDate).orEmpty()
            val id = gameId.find(slug)?.groupValues?.get(1).orEmpty()

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = id,
                matchDate = date,
                matchTime = time
            )
            val key = if (id.isNotBlank()) "ID|$id" else model.matchKey
            out[key] = model
        }
        return out.values.toList()
    }

    // TFP's actual correct-score field is always a single-digit football score.
    // The following point columns must NEVER be interpreted as score digits.
    private val tfpCorrectScoreRegex = Regex("(?<!\\d)([0-9])\\s+-\\s+([0-9])(?!\\d)")
    private val fixtureLinkPattern = Regex("/([^/?#]+-vs-[^/?#]+-prediction[^/?#]*)", RegexOption.IGNORE_CASE)

    private fun scoreImmediatelyAfterFixtureLink(link: org.jsoup.nodes.Element): String? {
        // The TFP list is rendered as: fixture link -> exact score -> points.
        // Read only the link's immediate DOM neighborhood. Never use a broad
        // ancestor's full text because that can join unrelated numeric fields.
        fun fromOwnText(element: org.jsoup.nodes.Element?): String? {
            if (element == null) return null
            val text = element.ownText().replace('\u00A0', ' ').trim()
            val matches = tfpCorrectScoreRegex.findAll(text).toList()
            return matches.singleOrNull()?.let {
                "${it.groupValues[1]}-${it.groupValues[2]}"
            }
        }

        // Same container: the score may be a direct text node next to the link.
        fromOwnText(link.parent())?.let { return it }

        // Next siblings of the anchor are the safest non-table representation.
        var sibling = link.nextElementSibling()
        repeat(8) {
            val element = sibling ?: return@repeat
            fromOwnText(element)?.let { return it }
            if (element.selectFirst("a[href]")?.let { fixtureHref.containsMatchIn(it.attr("href")) } == true) {
                return null
            }
            sibling = element.nextElementSibling()
        }

        // Table layout: inspect only the cells after the cell containing this link.
        val cell = link.closest("td,th")
        var cellSibling = cell?.nextElementSibling()
        repeat(6) {
            val element = cellSibling ?: return@repeat
            fromOwnText(element)?.let { return it }
            cellSibling = element.nextElementSibling()
        }

        // Some responsive versions put the score as direct text in a small row
        // container. Walk a few ancestors but inspect OWN text only.
        var ancestor = link.parent()
        repeat(4) {
            ancestor = ancestor?.parent()
            fromOwnText(ancestor)?.let { return it }
        }
        return null
    }

    private fun fixtureRowText(link: org.jsoup.nodes.Element): String {
        val row = link.closest("tr")
        if (row != null) return row.text().replace('\u00A0', ' ')
        return link.parent()?.text()?.replace('\u00A0', ' ') ?: link.text()
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val base = slug.replace(Regex("-prediction.*$", RegexOption.IGNORE_CASE), "")
        val marker = "-vs-"
        val idx = base.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(base.substring(0, idx))
        val away = slugWords(base.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun toIsoDate(value: String): String {
        val parts = value.split('-')
        return if (parts.size == 3) "${parts[2]}-${parts[1]}-${parts[0]}" else ""
    }
}
