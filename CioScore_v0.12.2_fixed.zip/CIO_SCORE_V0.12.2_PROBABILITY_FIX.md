# CioScore v0.12.2 — Olasılık Dengeleme Fix

- MS 1 / X / 2 olasılıkları artık yalnızca kaynak skorlarının çoğunluğundan üretilmiyor.
- Mackolik 1X2 implied probability: %60 ağırlık.
- 5 kaynaklı skor tahminlerinden çıkan sonuç olasılığı: %40 ağırlık.
- Böylece piyasa favorisi MS 1 iken kaynaklarda MS 1 hiç görünmese bile MS 1 otomatik olarak %0 olmaz.
- Value hesabı da aynı harmanlanmış olasılığı kullanır.
- APK sürümü: 0.12.2-cio-score.
