CIO Skor 0.8.18 - Forebet recovery build

BASE: CIO_Skor_APK_0_8_7_SOCCERSEER_OLD_WORKING_PARSER-1.zip

Changes ONLY:
- Android cleartext traffic enabled as a fallback for redirects.
- Forebet parser broadened without changing the other source parsers.

Target: restore Forebet as a working source before touching match merging.
