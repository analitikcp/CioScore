package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser - based on the last known working 0.8.7 parser,
 * with broader DOM fallbacks only. No other source parser is changed.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // 1) Known Forebet match containers.
        val blocks = LinkedHashSet<Element>()
        blocks.addAll(doc.select("div.rcnt"))
        blocks.addAll(doc.select("div[class*=rcnt]"))
        blocks.addAll(doc.select("article[class*=rcnt]"))

        for (block in blocks) {
            addBlock(block, out)
            if (out.size >= 80) break
        }

        // 2) DOM fallback: find team nodes and walk up to a common match card.
        if (out.isEmpty()) {
            val teamNodes = doc.select(
                ".homeTeam, [class*=homeTeam], [class*=hometeam], [class*=home_team]"
            )
            for (homeNode in teamNodes) {
                var parent: Element? = homeNode.parent()
                repeat(7) {
                    val p = parent ?: return@repeat
                    val away = p.select(
                        ".awayTeam, [class*=awayTeam], [class*=awayteam], [class*=away_team]"
                    ).firstOrNull()
                    if (away != null) {
                        addBlock(p, out)
                        if (out.size >= 80) return out.values.toList()
                        return@repeat
                    }
                    parent = p.parent()
                }
            }
        }

        return out.values.toList()
    }

    private fun addBlock(block: Element, out: LinkedHashMap<String, ScoreModel>) {
        val home = firstTeam(block, ".homeTeam, [class*=homeTeam], [class*=hometeam], [class*=home_team]") ?: return
        val away = firstTeam(block, ".awayTeam, [class*=awayTeam], [class*=awayteam], [class*=away_team]") ?: return

        val cleanHome = cleanForebetTeam(home)
        val cleanAway = cleanForebetTeam(away)
        if (!valid(cleanHome, cleanAway)) return

        // Correct Score first, Pred fallback second.
        val predictedScore = extractCorrectScore(block)
            ?: extractPredictedScore(block)
            ?: extractAnyLabeledScore(block)
            ?: return

        val model = ScoreModel(
            homeTeam = cleanHome,
            awayTeam = cleanAway,
            predictedScore = predictedScore,
            source = source
        )
        out[model.matchKey] = model
    }

    private fun firstTeam(block: Element, selector: String): String? {
        val element = block.select(selector).firstOrNull() ?: return null
        val value = element.select("span,a").firstOrNull()?.text()
            ?.takeIf { it.isNotBlank() }
            ?: element.text()
        return value.replace('\u00A0', ' ').trim().takeIf { it.isNotBlank() }
    }

    private fun extractCorrectScore(block: Element): String? {
        for (element in block.select(
            "div.ex_sc.tabonly, div.ex_sc, [class*=ex_sc], [class*=correct-score], [class*=correct_score]"
        )) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun extractPredictedScore(block: Element): String? {
        for (element in block.select("span.forepr, [class*=forepr], [class*=pred], [class*=prediction]")) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun extractAnyLabeledScore(block: Element): String? {
        val text = block.text().replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        val labeled = Regex(
            "(?:Correct\\s*score|Correct\\s*Score|Pred|Prediction|Score)\\s*[:\\-]?\\s*([0-5])\\s*[-:]\\s*([0-5])",
            RegexOption.IGNORE_CASE
        ).find(text)
        if (labeled != null) return "${labeled.groupValues[1]}-${labeled.groupValues[2]}"
        return Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
            .findAll(text).lastOrNull()
            ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
    }

    private fun exactScore(value: String): String? {
        val text = value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        val match = Regex("^([0-5])\\s*[-:]\\s*([0-5])$").matchEntire(text) ?: return null
        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun cleanForebetTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')
}
