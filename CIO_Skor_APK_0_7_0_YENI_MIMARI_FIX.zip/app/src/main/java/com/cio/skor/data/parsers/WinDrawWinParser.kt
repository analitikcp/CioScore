package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class WinDrawWinParser : BaseParser("WinDrawWin") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out=LinkedHashSet<String>()
        for(el in doc.select("article,li,tr,[class*=match],[class*=fixture],[class*=prediction]")){
            val raw=clean(el.text()); if(raw.length !in 10..450) continue
            val s=Regex("(?i)(?:prediction|correct\\s*score|score|tips?)[^0-9]{0,80}([0-5])\\s*[-:]\\s*([0-5])").find(raw)?.let{"${it.groupValues[1]}-${it.groupValues[2]}"} ?: continue
            val before=raw.substringBefore(Regex("(?i)(prediction|correct\\s*score|tips?|score)"))
            val parts=before.split(Regex("\\s+(?:v|vs|[-–—])\\s+"),2)
            if(parts.size==2){val a=team(parts[0]);val b=team(parts[1]);if(valid(a,b))out.add("$a|$b|$s")}
            if(out.size>=30)break
        }
        return out.map{val p=it.split("|");ScoreModel(p[0],p[1],p[2],source)}
    }
}
