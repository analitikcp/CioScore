package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceTimeZone
import com.cio.skor.data.MatchMerger
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * PredictZ correct-score parser.
 *
 * Important: PredictZ pages contain many numeric form/stat columns next to the
 * team names. We therefore NEVER derive team names from the whole block text.
 * We use PredictZ's own match/team elements first and read the prediction from
 * its prediction box.
 */
class PredictZParser : BaseParser("PredictZ", SourceTimeZone.EUROPE_LONDON) {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // PredictZ's match card/table container.
        val blocks = doc.select(".ptcnt, [class*=ptcnt]")

        for (block in blocks) {
            val home = firstText(
                block,
                ".ptmobh",
                "[class*=ptmobh]",
                ".ptmobh a"
            ) ?: continue

            val away = firstText(
                block,
                ".ptmoba",
                "[class*=ptmoba]",
                ".ptmoba a"
            ) ?: continue

            val cleanHome = cleanPredictZTeam(home)
            val cleanAway = cleanPredictZTeam(away)

            if (!valid(cleanHome, cleanAway)) continue

            val predictedScore = extractPredictionScore(block) ?: continue

            val sourceMatchId = block.select("a[href]")
                .map { it.attr("href").trim() }
                .firstOrNull { it.isNotBlank() }
                .orEmpty()

            val raw = extractFixtureMetadata(block)
            val pageDate = extractPageDate(doc)
            val todayPage = doc.location().contains("/predictions/today", ignoreCase = true)
            val resolvedDate = if (todayPage) {
                java.time.LocalDate.now(sourceTimeZone.zoneId)
                    .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            } else raw.matchDate.ifBlank { pageDate }
            val metadata = mergeMetadata(
                date = resolvedDate,
                time = raw.matchTime,
                competition = raw.competitionName.ifBlank { extractNearestCompetition(block) },
                competitionCountry = raw.competitionCountry,
                rawDateTime = raw.rawDateTime
            )
            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source,
                sourceMatchId = sourceMatchId,
                matchTimestamp = metadata.matchTimestamp,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName,
                competitionCountry = metadata.competitionCountry
            )

            val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
            out[key] = model
        }

        // Current PredictZ list pages can use a different card class than the
        // historical .ptcnt markup. Recover from their public /picks/ links and
        // the explicit "PREDICTZ PICK" score label.
        if (out.isEmpty()) {
            parseCurrentPicksPage(doc, out)
        }

        return out.values.toList()
    }

    private fun parseCurrentPicksPage(doc: Document, out: LinkedHashMap<String, ScoreModel>) {
        val scorePattern = Regex("(?i)\bPREDICTZ\s+PICK\b[^0-9]{0,40}([0-5])\s*[-:]\s*([0-5])\b")
        val links = doc.select("a[href]").filter { it.attr("href").contains("/picks/", ignoreCase = true) }
        for (link in links) {
            var node: Element? = link
            var pair: Pair<String, String>? = null
            var score: String? = null
            var container: Element? = null
            repeat(8) {
                node = node?.parent() ?: return@repeat
                val candidate = node ?: return@repeat
                val text = candidate.text().replace('\u00A0', ' ').replace(Regex("\s+"), " ").trim()
                if (text.length > 3500) return@repeat
                val m = scorePattern.find(text)
                if (m != null) score = "${m.groupValues[1]}-${m.groupValues[2]}"
                val anchors = candidate.select("a[href]")
                for (a in anchors) {
                    val visible = a.text().replace('\u00A0', ' ').replace(Regex("\s+"), " ").trim()
                    val p = splitVisible(visible)
                    if (p != null) { pair = p; break }
                }
                if (pair == null) {
                    pair = splitVisibleFromText(text)
                }
                if (pair != null && score != null) { container = candidate; return@repeat }
            }
            val teams = pair ?: continue
            val predicted = score ?: continue
            val home = cleanPredictZTeam(teams.first)
            val away = cleanPredictZTeam(teams.second)
            if (!valid(home, away)) continue
            val href = link.attr("href").trim()
            val raw = extractFixtureMetadata(container ?: link)
            val pageDate = extractPageDate(doc)
            val metadata = mergeMetadata(
                date = raw.matchDate.ifBlank { pageDate },
                time = raw.matchTime,
                competition = raw.competitionName.ifBlank { extractNearestCompetition(container ?: link) },
                competitionCountry = raw.competitionCountry,
                rawDateTime = raw.rawDateTime
            )
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = predicted,
                source = source,
                sourceMatchId = href,
                matchTimestamp = metadata.matchTimestamp,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName,
                competitionCountry = metadata.competitionCountry
            )
            out.putIfAbsent("ID|$href", model)
        }
    }

    private fun splitVisibleFromText(text: String): Pair<String, String>? {
        val cleaned = text.replace('\u00A0', ' ').replace(Regex("\s+"), " ").trim()
        val match = Regex("(?i)([A-Za-z0-9À-ÿ][A-Za-z0-9À-ÿ .&'’()/-]{1,70}?)\s+vs\s+([A-Za-z0-9À-ÿ][A-Za-z0-9À-ÿ .&'’()/-]{1,70}?)(?:\s+PREDICTZ\s+PICK|\s+Correct\s+Score|$)").find(cleaned)
            ?: return null
        val home = cleanPredictZTeam(match.groupValues[1])
        val away = cleanPredictZTeam(match.groupValues[2])
        return if (valid(home, away)) home to away else null
    }

    private fun splitVisible(text: String): Pair<String, String>? {
        val cleaned = text.replace('\u00A0', ' ').replace(Regex("\s+"), " ").trim()
        val m = Regex("(?i)^(.+?)\s+(?:v|vs|versus)\s+(.+)$").find(cleaned) ?: return null
        val home = cleanPredictZTeam(m.groupValues[1])
        val away = cleanPredictZTeam(m.groupValues[2])
        return if (valid(home, away)) home to away else null
    }

    private fun firstText(block: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = block.select(selector)
                .firstOrNull()
                ?.text()
                ?.replace("\u00A0", " ")
                ?.replace(Regex("\\s+"), " ")
                ?.trim()

            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun extractPredictionScore(block: Element): String? {
        // PredictZ's prediction boxes are deliberately checked first. This
        // prevents form/stat numbers from being mistaken for the score.
        val predictionElements = block.select(
            ".ptpredboxsml, .ptpredbox, [class*=ptpredbox]"
        )

        for (element in predictionElements) {
            val text = clean(element.text())
            val score = scoreFromPredictionText(text)
            if (score != null) return score
        }

        // On the correct-score page the block can expose the recommendation as
        // "Home 1-0", "Draw 1-1" or "Away 0-2". Only inspect those explicit
        // labels; do NOT scan arbitrary digits from the match block.
        val blockText = clean(block.text())
        val labelled = Regex(
            "(?i)\\b(?:home|draw|away)\\s+([0-5])\\s*[-:]\\s*([0-5])\\b"
        ).find(blockText)

        if (labelled != null) {
            return "${labelled.groupValues[1]}-${labelled.groupValues[2]}"
        }

        // Last safe fallback: an explicitly labelled Correct Score field.
        val explicit = Regex(
            "(?i)correct\\s*score(?:\\s+odds)?[^0-9]{0,40}([0-5])\\s*[-:]\\s*([0-5])\\b"
        ).find(blockText)

        return explicit?.let {
            "${it.groupValues[1]}-${it.groupValues[2]}"
        }
    }

    private fun scoreFromPredictionText(text: String): String? {
        val patterns = listOf(
            Regex("(?i)\\b(?:correct\\s*score|predicted\\s*score(?:line)?|prediction|tip)\\b[^0-9]{0,50}([0-5])\\s*[-:]\\s*([0-5])\\b"),
            Regex("\\b([0-5])\\s*[-:]\\s*([0-5])\\b")
        )

        for (pattern in patterns) {
            val match = pattern.find(text) ?: continue
            return "${match.groupValues[1]}-${match.groupValues[2]}"
        }

        return null
    }

    private fun cleanPredictZTeam(value: String): String {
        return value
            .replace("\u00A0", " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', '|')
    }
}
