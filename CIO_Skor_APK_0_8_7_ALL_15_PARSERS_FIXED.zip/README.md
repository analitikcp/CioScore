CIO Skor APK 0.8.7 - ALL 15 PARSERS FIXED

This build keeps the six existing working parsers and replaces the former
one-size-fits-all custom parser logic with a more tolerant source-specific
prediction parser layer.

15 sources:
1 FP.com
2 FootballPredictions.net
3 Forebet
4 PredictZ
5 WinDrawWin
6 SoccerSeer
7 MightyTips
8 FootyStats
9 GoalVertex
10 NerdyTips
11 Vitibet
12 HuhSports
13 FootballAnt
14 DailySports
15 Statarea

Verified prediction URLs used by the nine custom sources:
- MightyTips: https://www.mightytips.com/football-predictions/correct-score/
- FootyStats: https://footystats.org/predictions/correct-score
- GoalVertex: https://www.goalvertex.com/correct-score-predictions
- NerdyTips: https://nerdytips.com/correct-score-predictions-today
- Vitibet: https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal
- HuhSports: https://www.huhsports.com/
- FootballAnt: https://www.footballant.com/prediction/correct-score-predictions
- DailySports: https://dailysports.net/mathematical-predictions/correct-score/
- Statarea: https://www.statarea.com/

The merge engine counts only sources that actually return parsed score rows.
No source is counted merely because its parser exists.

Forebet and the original six parser files are preserved; this build does not
replace them with the generic parser.

Note: this archive was statically checked in this environment. An Android
Gradle build must still be run in the user's build environment.
