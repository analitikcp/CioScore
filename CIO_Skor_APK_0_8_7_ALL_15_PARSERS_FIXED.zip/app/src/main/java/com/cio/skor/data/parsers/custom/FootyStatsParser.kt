package com.cio.skor.data.parsers.custom
import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
class FootyStatsParser : SitePredictionParser("FootyStats") {
    override fun parse(doc: Document): List<ScoreModel> {
        // FootyStats has a dedicated Correct Score section; retain only exact-score rows.
        return parseBlocks(doc, "article, tr, [class*=prediction], [class*=fixture], [class*=match], [class*=correct-score]")
    }
}
