package com.cio.skor.data.parsers.custom
import org.jsoup.nodes.Document
class VitibetParser : SitePredictionParser("Vitibet") {
    override fun parse(doc: Document) = parseBlocks(doc, "tr, table tr, .match, [class*=match], [class*=fixture], article")
}
