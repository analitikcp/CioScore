package com.cio.skor.data.parsers.custom
import org.jsoup.nodes.Document
class StatareaParser : SitePredictionParser("Statarea") {
    override fun parse(doc: Document) = parseBlocks(doc, "tr, table tr, article, [class*=match], [class*=fixture], [class*=prediction]")
}
