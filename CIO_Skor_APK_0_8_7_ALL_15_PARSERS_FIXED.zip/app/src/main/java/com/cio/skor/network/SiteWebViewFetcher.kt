package com.cio.skor.network

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Browser fallback for JS-rendered prediction sites. */
class SiteWebViewFetcher(private val context: Context) {
    suspend fun fetch(url: String, timeoutMs: Long = 15_000L): String? =
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
                val webView = WebView(context.applicationContext)
                val handler = Handler(Looper.getMainLooper())
                var finished = false

                fun destroy() {
                    try { webView.stopLoading(); webView.webViewClient = null; webView.destroy() } catch (_: Exception) {}
                }
                fun complete(html: String?) {
                    if (finished || !continuation.isActive) return
                    finished = true
                    handler.removeCallbacksAndMessages(null)
                    destroy()
                    continuation.resume(html)
                }
                val timeout = Runnable { evaluate(webView) { complete(it) } }

                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.settings.databaseEnabled = true
                webView.settings.loadsImagesAutomatically = false
                webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        handler.removeCallbacksAndMessages(null)
                        handler.postDelayed(timeout, timeoutMs)
                    }
                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        handler.postDelayed({ evaluate(webView) { html -> if (!html.isNullOrBlank()) complete(html) } }, 1200L)
                    }
                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) complete(null)
                    }
                }
                webView.loadUrl(url)
                handler.postDelayed(timeout, timeoutMs)
                continuation.invokeOnCancellation { handler.removeCallbacksAndMessages(null); destroy() }
            }
        }

    private fun evaluate(webView: WebView, callback: (String?) -> Unit) {
        webView.evaluateJavascript("document.documentElement ? document.documentElement.outerHTML : ''") { value ->
            callback(unescape(value))
        }
    }
    private fun unescape(value: String?): String? {
        if (value == null || value == "null") return null
        return try { org.json.JSONTokener(value).nextValue()?.toString() } catch (_: Exception) {
            value.removePrefix("\"").removeSuffix("\"").replace("\\u003C", "<").replace("\\u003E", ">")
                .replace("\\\"", "\"").replace("\\n", "\n").replace("\\/", "/")
        }
    }
}
