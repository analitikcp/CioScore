package com.cio.skor.data

import com.cio.skor.data.parsers.*
import android.content.Context
import com.cio.skor.network.HttpClient
import com.cio.skor.network.ForebetWebViewFetcher
import com.cio.skor.network.SiteWebViewFetcher
import com.cio.skor.data.parsers.custom.*
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

class ScraperRepository(private val context: Context) {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()
    private val forebetWeb = ForebetWebViewFetcher(context)
    private val siteWeb = SiteWebViewFetcher(context)

    // BettingTipsToday is intentionally removed: its domain is no longer an active prediction source.
    // The three working parsers (PredictZ, FP.com, WinDrawWin) are kept unchanged.
    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips", FootballPredictionsNetParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/", MightyTipsParser()),
        Source("FootyStats", "https://footystats.org/predictions/correct-score", FootyStatsParser()),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions", GoalVertexParser()),
        Source("NerdyTips", "https://nerdytips.com/correct-score-predictions-today", NerdyTipsParser()),
        Source("Vitibet", "https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal", VitibetParser()),
        Source("HuhSports", "https://www.huhsports.com/", HuhSportsParser()),
        Source("FootballAnt", "https://www.footballant.com/prediction/correct-score-predictions", FootballAntParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Statarea", "https://www.statarea.com/", StatareaParser())
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = http.get(source.url)
                    var scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else {
                        emptyList()
                    }

                    // Forebet may serve an anti-bot/challenge HTML document to
                    // raw OkHttp clients. If that response yields zero scores,
                    // retry the same live page in a real Android WebView.
                    if (source.name == "Forebet" && scores.isEmpty()) {
                        val webHtml = forebetWeb.fetch(source.url)
                        if (!webHtml.isNullOrBlank()) {
                            scores = source.parser.parse(Jsoup.parse(webHtml, source.url))
                        }
                    }

                    // JS-rendered sites: use a real browser DOM only when the
                    // direct HTTP response produced no usable predictions.
                    if (source.name != "Forebet" && scores.isEmpty() && source.name in BROWSER_FALLBACK_SOURCES) {
                        val webHtml = siteWeb.fetch(source.url)
                        if (!webHtml.isNullOrBlank()) {
                            scores = source.parser.parse(Jsoup.parse(webHtml, source.url))
                        }
                    }
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }

    companion object {
        private val BROWSER_FALLBACK_SOURCES = setOf(
            "MightyTips", "FootyStats", "GoalVertex", "NerdyTips", "Vitibet",
            "HuhSports", "FootballAnt", "DailySports", "Statarea"
        )
    }
}
