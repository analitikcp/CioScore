package com.cio.skor.data.parsers.custom
import org.jsoup.nodes.Document
class MightyTipsParser : SitePredictionParser("MightyTips") {
    override fun parse(doc: Document) = parseBlocks(doc, "article, .prediction-card, [class*=prediction], [class*=match], [class*=fixture], tr")
}
