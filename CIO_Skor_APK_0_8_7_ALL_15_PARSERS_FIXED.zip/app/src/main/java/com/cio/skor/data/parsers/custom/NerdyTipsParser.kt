package com.cio.skor.data.parsers.custom
import org.jsoup.nodes.Document
class NerdyTipsParser : SitePredictionParser("NerdyTips") {
    override fun parse(doc: Document) = parseBlocks(doc, "article, tr, [class*=match], [class*=fixture], [class*=prediction], [class*=score]")
}
