package com.cio.skor.data.parsers.custom
import org.jsoup.nodes.Document
class GoalVertexParser : SitePredictionParser("GoalVertex") {
    override fun parse(doc: Document) = parseBlocks(doc, "article, .prediction-card, [class*=prediction], [class*=match], [class*=fixture], section")
}
