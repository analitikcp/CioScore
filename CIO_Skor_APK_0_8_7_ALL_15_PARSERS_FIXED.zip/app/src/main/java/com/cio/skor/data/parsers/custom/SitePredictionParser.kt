package com.cio.skor.data.parsers.custom

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.parsers.BaseParser
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Fallback parser for sites whose prediction cards are frequently rearranged.
 * It deliberately parses the source's visible prediction text instead of
 * relying on one fragile CSS class name.
 */
abstract class SitePredictionParser(source: String) : BaseParser(source) {
    protected fun parseBlocks(doc: Document, selectors: String): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val elements = LinkedHashSet<Element>()
        doc.select(selectors).forEach { el ->
            if (el.text().contains(Regex("(?i)(correct\\s*score|predicted\\s*scoreline|predicted\\s*score|exact\\s*score|\\bscore\\s*:|\\btip\\s+[0-5]\\s*[-:]\\s*[0-5])"))) {
                elements.add(el)
                var parent = el.parent()
                repeat(4) {
                    if (parent != null) { elements.add(parent!!); parent = parent!!.parent() }
                }
            }
        }
        for (el in elements.sortedBy { it.text().length }) {
            addFromText(out, clean(el.text()))
            if (out.size >= 150) break
        }
        if (out.isEmpty()) addFromWholeText(out, clean(doc.body()?.text() ?: ""))
        return out.values.toList()
    }

    private fun addFromWholeText(out: LinkedHashMap<String, ScoreModel>, raw: String) {
        if (raw.isBlank()) return
        val labels = Regex("(?i)(correct\\s*score|predicted\\s*scoreline|predicted\\s*score|exact\\s*score|\\bscore\\s*:|\\btip\\s+)(.{0,180})")
        for (m in labels.findAll(raw)) {
            val score = Regex("(?<!\\d)([0-5])\\s*[-–—:]\\s*([0-5])(?!\\d)").find(m.groupValues[2]) ?: continue
            val before = raw.substring(maxOf(0, m.range.first - 180), m.range.first)
            val teams = findTeams(before) ?: continue
            put(out, teams.first, teams.second, "${score.groupValues[1]}-${score.groupValues[2]}")
        }
    }

    private fun addFromText(out: LinkedHashMap<String, ScoreModel>, raw: String) {
        if (raw.length !in 10..1600) return
        val scoreMatch = Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|exact\\s*score|\\bscore\\s*:|\\btip\\s+)[^0-9]{0,100}([0-5])\\s*[-–—:]\\s*([0-5])").find(raw)
            ?: Regex("(?<!\\d)([0-5])\\s*[-–—:]\\s*([0-5])(?!\\d)").find(raw)
            ?: return
        val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
        val teams = findTeams(raw.substring(0, scoreMatch.range.first)) ?: findTeams(raw) ?: return
        put(out, teams.first, teams.second, score)
    }

    private fun findTeams(text: String): Pair<String, String>? {
        val t = text.replace(Regex("\\s+"), " ").trim()
        val vs = Regex("(?i)([A-Za-zÀ-ÖØ-öø-ÿ0-9.'’&()/-]{2,60}(?:\\s+[A-Za-zÀ-ÖØ-öø-ÿ0-9.'’&()/-]{2,60}){0,4})\\s+(?:vs\\.?|v\\.?|versus)\\s+([A-Za-zÀ-ÖØ-öø-ÿ0-9.'’&()/-]{2,60}(?:\\s+[A-Za-zÀ-ÖØ-öø-ÿ0-9.'’&()/-]{2,60}){0,4})").find(t)
        if (vs != null) {
            val h = team(vs.groupValues[1]); val a = team(vs.groupValues[2])
            if (valid(h, a)) return h to a
        }
        // Many cards print two team names on adjacent lines, then "Score:".
        val lines = t.split(Regex("\\s{2,}|\\n|\\r"))
            .map { team(it) }
            .filter { it.length >= 2 && it.length <= 70 }
            .filterNot { it.matches(Regex("(?i).*(correct|predicted|score|prediction|tip|odds|probability|league|today).*")) }
        if (lines.size >= 2) {
            for (i in 0 until lines.size - 1) {
                val h = lines[i]; val a = lines[i + 1]
                if (valid(h, a)) return h to a
            }
        }
        return null
    }

    private fun put(out: LinkedHashMap<String, ScoreModel>, home: String, away: String, score: String) {
        val h = team(home); val a = team(away)
        if (!valid(h, a)) return
        val model = ScoreModel(h, a, score, source)
        out.putIfAbsent(model.matchKey, model)
    }
}
