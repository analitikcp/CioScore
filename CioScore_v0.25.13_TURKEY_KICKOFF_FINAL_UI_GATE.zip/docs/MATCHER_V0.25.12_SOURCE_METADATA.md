# CioScore v0.25.12 — Source Metadata / Matcher

## Source-specific metadata strategy

- FP.com: reads fixture-row date/time from the table row; falls back to page date; competition comes from the nearest league/section heading.
- PredictZ: reads fixture-card metadata first; falls back to the page's explicit Today/date heading; competition is taken from the nearest league heading and strips the site's `Correct Score Tips` suffix.
- WinDrawWin: uses the exact `View <home> v <away> Tip` fixture anchor, extracts metadata from its fixture container, falls back to the current page date, and captures the nearest league heading.
- DailySports: anchors on the `Prediction Correct Score:` game card, reads the `Time Today HH:MM` context from that card, page date as fallback, and the nearest league heading.

## Match identity

Provider records carry `matchTimestamp`, `matchDate`, `matchTime`, and `competitionName` into the canonical matcher. Official Iddaa remains the fixture authority. A provider with an exact two-sided canonical team identity and a matching provider date can use the official kickoff as its anchor when the provider page does not expose a per-match time.

## Diagnostics

Unmatched predictions are classified as `NO_OFFICIAL_CANDIDATE`, `NAME_MISMATCH`, `DATE_MISMATCH`, `TIME_MISMATCH`, `COMPETITION_MISMATCH`, `AMBIGUOUS_OFFICIAL_CANDIDATE`, `METADATA_MISSING`, or `ALIAS_STEMMING_PROBLEM`. The scan panel also reports metadata completeness per source.

## UI cleanup

The top `İDDAA BÜLTENİ` and `DİĞER MAÇLAR` filter buttons and their filter wiring are removed. The `İDDAA BÜLTENİNDE AÇ` action inside a match card is a separate deep-link action and remains.
