package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import com.cio.skor.data.KickoffNormalizer

/** Shared score/fixture helpers. Site-specific parsers must choose the correct
 * fixture card and then call the metadata helpers with that exact DOM scope. */
abstract class BaseParser(protected val source: String) {

    protected data class FixtureMetadata(
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val matchTimestamp: Long = 0L
    )

    protected val scoreRegex = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")

    protected fun extractStandardScore(rawText: String): Pair<Int, Int>? {
        val match = scoreRegex.find(rawText) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return home to away
    }

    /** Generic metadata fallback. Parsers should prefer their site-specific helper. */
    protected fun extractFixtureMetadata(element: Element): FixtureMetadata {
        var date = firstMetadataText(element,
            "time[datetime]", "[datetime]", "[class*=date]", "[class*=Date]",
            "[class*=match-date]", "[class*=fixture-date]"
        )
        var time = firstMetadataText(element,
            "time", "[class*=kickoff]", "[class*=match-time]", "[class*=fixture-time]",
            "[class*=time]"
        )
        var competition = firstMetadataText(element,
            "[class*=competition]", "[class*=tournament]", "[class*=league]",
            "[class*=country]"
        )

        val text = element.text()
        if (date.isBlank()) date = findDate(text)
        date = normalizeDate(date)
        if (time.isBlank() || time == "--:--") time = findTime(text)
        time = normalizeTime(time)
        competition = normalizeCompetition(competition)
        return buildMetadata(date, time, competition)
    }

    /** Page-level date used by PredictZ/WinDrawWin where the match card omits it. */
    protected fun extractPageDate(doc: Document): String {
        val candidates = buildList {
            add(doc.select("meta[property=article:published_time]").firstOrNull()?.attr("content").orEmpty())
            add(doc.select("meta[name=date], meta[name=publishdate]").firstOrNull()?.attr("content").orEmpty())
            add(doc.title())
            add(doc.select("h1").firstOrNull()?.text().orEmpty())
            add(doc.select("header").firstOrNull()?.text().orEmpty())
        }
        for (candidate in candidates) {
            val found = findLongDate(candidate).ifBlank { findMonthNameDate(candidate) }
            if (found.isNotBlank()) return found
        }
        val pageText = clean(doc.title() + " " + doc.select("h1").firstOrNull()?.text().orEmpty())
        if (pageText.contains(Regex("(?i)\\btoday\\b"))) {
            return LocalDate.now(KickoffNormalizer.ZONE).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        }
        return ""
    }

    /** Find the nearest meaningful league/tournament heading above a fixture card. */
    protected fun extractNearestCompetition(element: Element): String {
        var node: Element? = element
        repeat(10) {
            val current = node ?: return@repeat
            val directHeading = current.children().asSequence()
                .filter { it.tagName().matches(Regex("h[1-6]")) || it.hasAttr("data-league") || it.hasAttr("data-competition") }
                .map { clean(it.text()) }
                .firstOrNull(::isCompetitionCandidate)
            if (!directHeading.isNullOrBlank()) return normalizeCompetition(directHeading)

            var previous = current.previousElementSibling()
            var siblingSteps = 0
            while (siblingSteps < 6 && previous != null) {
                val sibling = previous!!
                val candidates = sibling.select("h1, h2, h3, h4, h5, h6, [class*=league], [class*=competition], [class*=tournament]")
                    .map { clean(it.text()) }
                candidates.firstOrNull(::isCompetitionCandidate)?.let { return normalizeCompetition(it) }
                previous = sibling.previousElementSibling()
                siblingSteps++
            }
            node = current.parent()
        }
        return ""
    }

    protected fun mergeMetadata(
        date: String,
        time: String = "--:--",
        competition: String = ""
    ): FixtureMetadata = buildMetadata(normalizeDate(date), normalizeTime(time), normalizeCompetition(competition))

    protected fun buildMetadata(date: String, time: String, competition: String): FixtureMetadata {
        val timestamp = if (date.isNotBlank() && time != "--:--") {
            runCatching {
                val d = LocalDate.parse(date, DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                val t = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm"))
                LocalDateTime.of(d, t).atZone(KickoffNormalizer.ZONE).toInstant().toEpochMilli()
            }.getOrDefault(0L)
        } else 0L
        return FixtureMetadata(date, time, competition, timestamp)
    }

    protected fun findDate(text: String): String =
        findLongDate(text).ifBlank { findShortDate(text) }

    private fun findLongDate(text: String): String {
        val patterns = listOf(
            Regex("\\b(\\d{4}[-/]\\d{1,2}[-/]\\d{1,2})\\b"),
            Regex("\\b(\\d{1,2}[./-]\\d{1,2}[./-]\\d{4})\\b")
        )
        for (p in patterns) p.find(text)?.groupValues?.get(1)?.let { return normalizeDate(it) }
        return ""
    }

    private fun findShortDate(text: String): String =
        Regex("\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+([A-Za-z]+)\\s+(\\d{4})\\b", RegexOption.IGNORE_CASE)
            .find(text)?.let { normalizeMonthDate(it.groupValues[1], it.groupValues[2], it.groupValues[3]) }.orEmpty()

    private fun findMonthNameDate(text: String): String =
        Regex("\\b(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)?[,]?\\s*(January|February|March|April|May|June|July|August|September|October|November|December)\\s+(\\d{1,2})(?:st|nd|rd|th)?[,]?\\s+(\\d{4})\\b", RegexOption.IGNORE_CASE)
            .find(text)?.let { normalizeMonthDate(it.groupValues[2], it.groupValues[1], it.groupValues[3]) }.orEmpty()

    private fun normalizeMonthDate(day: String, monthName: String, year: String): String {
        val month = runCatching {
            LocalDate.parse("$day $monthName $year", DateTimeFormatter.ofPattern("d MMMM yyyy", Locale.ENGLISH))
        }.getOrNull() ?: runCatching {
            LocalDate.parse("$day ${monthName.take(3)} $year", DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH))
        }.getOrNull() ?: return ""
        return month.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
    }

    protected fun findTime(text: String): String =
        Regex("\\b(?:[01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(text)?.value?.replace('.', ':').let { normalizeTime(it.orEmpty()) }

    protected fun normalizeDate(value: String): String {
        val v = value.trim()
        if (v.isBlank()) return ""
        val direct = listOf("yyyy-MM-dd", "yyyy/MM/dd", "dd.MM.yyyy", "dd/MM/yyyy", "dd-MM-yyyy")
        for (pattern in direct) {
            val parsed = runCatching { LocalDate.parse(v.take(10), DateTimeFormatter.ofPattern(pattern)) }.getOrNull()
            if (parsed != null) return parsed.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        }
        return findLongDate(v)
    }

    protected fun normalizeTime(value: String): String {
        val m = Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(value) ?: return "--:--"
        return "%02d:%s".format(m.groupValues[1].toInt(), m.groupValues[2])
    }

    private fun firstMetadataText(element: Element, vararg selectors: String): String {
        for (selector in selectors) {
            val e = element.select(selector).firstOrNull() ?: continue
            val datetime = e.attr("datetime").trim()
            if (datetime.isNotBlank()) return datetime
            val value = clean(e.text())
            if (value.isNotBlank()) return value
        }
        return ""
    }

    private fun normalizeCompetition(value: String): String = clean(value)
        .replace(Regex("(?i)^(league|competition|tournament|country)\\s*[:\\-]\\s*"), "")
        .replace(Regex("(?i)\\s+correct\\s+score\\s+tips?$"), "")
        .replace(Regex("(?i)\\s+tips?$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
        .takeIf { it.length in 2..100 } ?: ""

    private fun isCompetitionCandidate(value: String): Boolean {
        if (value.length !in 3..100) return false
        val normalized = normalizeCompetition(value)
        if (normalized.isBlank()) return false
        return !normalized.matches(Regex("(?i)^(game|time|prediction|tip|correct score|correct score predictions?|football predictions?|match odds|odds|today|tomorrow|yesterday)$"))
    }

    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    protected fun score(s: String): String? = extractStandardScore(s)?.let { (home, away) -> "$home-$away" }

    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
