package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Vitibet homepage-only parser.
 *
 * This parser intentionally reads ONLY the homepage's "Football tips dd.MM.yyyy"
 * block for today's date. It does not use the multi-day quicktips table or the
 * site's match-detail pool.
 */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val today = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date())
        val body = clean(doc.body()?.text().orEmpty())
        val marker = Regex("(?i)(?:Football tips|Futbol tahminleri|Fotballtips|Fotbollstips)\\s+${Regex.escape(today)}")
            .find(body) ?: return emptyList()

        var section = body.substring(marker.range.last + 1)
        section = section.substringBeforeFirstOf(
            "ACCUMULATOR TIPS", "ACCUMULATORER", "AKKUMULATORER", "KOMBINE TAHMINLERI",
            "KOMBİNE TAHMİNLERİ", "KUPON", "BETTING TIPS FOR TODAY", "TOP BETTING TIPS"
        )

        val out = LinkedHashMap<String, ScoreModel>()
        val rowRegex = Regex(
            "(?i)(\\b\\d{1,2}:\\d{2})\\s+(.+?)\\s+(\\d{1,2})\\s*:\\s*(\\d{1,2})\\s+(.+?)(?=\\s+\\d{1,2}:\\d{2}\\s+|$)"
        )

        for (m in rowRegex.findAll(section)) {
            val time = m.groupValues[1]
            val home = cleanTeam(m.groupValues[2])
            val away = cleanTeam(m.groupValues[5])
            val score = "${m.groupValues[3]}-${m.groupValues[4]}"
            if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) continue
            build(home, away, score, today, time)?.let { out[it.matchKey] = it }
        }

        return out.values.toList()
    }

    private fun build(homeRaw: String, awayRaw: String, score: String, date: String, time: String): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            matchDate = date,
            matchTime = time
        )
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..80) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction|score|1|0|2)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|Odds|Status)\\b.*$"), "")
        .replace(Regex("\\s+(?:1X|X2|12|10|02|1|X|2)\\s*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', ':', '|')

    private fun String.substringBeforeFirstOf(vararg markers: String): String {
        var end = length
        for (marker in markers) {
            val idx = indexOf(marker, ignoreCase = true)
            if (idx >= 0 && idx < end) end = idx
        }
        return substring(0, end)
    }
}
