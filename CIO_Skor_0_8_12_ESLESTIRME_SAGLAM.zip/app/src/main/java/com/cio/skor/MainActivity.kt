package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * One row per real fixture. Parsers are untouched; only the merge layer is changed.
     * Exact canonical names are preferred. If two sites spell the same club differently,
     * a conservative fuzzy match is used only when BOTH home and away names agree strongly.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        // Merge in two passes:
        // 1) deterministic fixture key (strongest, order-independent)
        // 2) fuzzy fixture matching for spelling/name variants not covered by the key.
        val groups = mutableListOf<MutableList<ScoreModel>>()
        val exact = LinkedHashMap<String, MutableList<ScoreModel>>()

        for (score in scores) {
            val key = fixtureKey(score.homeTeam, score.awayTeam)
            val bucket = exact.getOrPut(key) { mutableListOf() }
            if (bucket.none { it.source.equals(score.source, ignoreCase = true) }) {
                bucket.add(score)
            } else {
                // Same source can legitimately contain a duplicate spelling. Keep the
                // first one; never print the same source twice in one fixture.
            }
        }
        groups.addAll(exact.values)

        // Second pass: join only genuinely similar fixtures. Compare against every
        // member so A≈B and B≈C also becomes one group (transitive matching).
        var changed = true
        while (changed) {
            changed = false
            outer@ for (i in 0 until groups.size) {
                for (j in i + 1 until groups.size) {
                    val a = groups[i]
                    val b = groups[j]
                    if (a.any { x -> b.any { y -> x.source.equals(y.source, ignoreCase = true) } }) continue

                    if (fixtureSimilarity(a, b) >= 0.84) {
                        a.addAll(b)
                        groups.removeAt(j)
                        changed = true
                        break@outer
                    }
                }
            }
        }

        return groups.map { group ->
            val ordered = group.sortedBy { sourcePriority(it.source) }
            MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    private fun fixtureKey(home: String, away: String): String {
        // Direction matters: home/away must not be swapped.
        return canonicalTeam(home) + "|" + canonicalTeam(away)
    }

    private fun fixtureSimilarity(a: List<ScoreModel>, b: List<ScoreModel>): Double {
        var best = 0.0
        for (x in a) for (y in b) {
            val direct = (teamSimilarity(x.homeTeam, y.homeTeam) + teamSimilarity(x.awayTeam, y.awayTeam)) / 2.0
            // A few feeds occasionally reverse the fixture. Allow that only when
            // BOTH sides agree strongly; this prevents unrelated matches merging.
            val reversed = (teamSimilarity(x.homeTeam, y.awayTeam) + teamSimilarity(x.awayTeam, y.homeTeam)) / 2.0
            best = maxOf(best, direct, reversed * 0.995)
        }
        return best
    }

    private fun sourcePriority(source: String): Int {
        val s = source.lowercase()
        return when {
            s.contains("fp.com") -> 0
            s.contains("predictz") -> 1
            s.contains("windrawwin") -> 2
            s.contains("soccerseer") -> 3
            s.contains("forebet") -> 4
            else -> 10
        }
    }

    private fun sameTeam(a: String, b: String): Boolean = teamSimilarity(a, b) >= 0.78

    private fun teamSimilarity(a: String, b: String): Double {
        val x = canonicalTeam(a)
        val y = canonicalTeam(b)
        if (x.isBlank() || y.isBlank()) return 0.0
        if (x == y) return 1.0

        val xt = canonicalTokens(a)
        val yt = canonicalTokens(b)
        if (xt == yt && xt.isNotEmpty()) return 0.99

        // Containment catches Bradford vs Bradford City and Newcastle vs Newcastle United.
        if (x.length >= 5 && y.length >= 5 && (x.contains(y) || y.contains(x))) {
            return 0.90
        }

        val lev = normalizedEditSimilarity(x, y)
        val tokenJaccard = if (xt.isEmpty() || yt.isEmpty()) 0.0 else {
            xt.intersect(yt).size.toDouble() / xt.union(yt).size.toDouble()
        }

        // A small typo such as Celie/Celje is handled here.
        return maxOf(lev, tokenJaccard)
    }

    private fun normalizedEditSimilarity(a: String, b: String): Double {
        val maxLen = maxOf(a.length, b.length)
        if (maxLen == 0) return 1.0
        val distance = levenshtein(a, b)
        return 1.0 - distance.toDouble() / maxLen.toDouble()
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + cost
                )
            }
            val tmp = previous
            previous = current
            current = tmp
        }
        return previous[b.length]
    }

    /** Normalize accents, punctuation and common club prefixes/suffixes. */
    private fun canonicalTeam(value: String): String {
        var s = value.trim().lowercase()
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

        val aliases = mapOf(
            "athens aek" to "aek athens",
            "aek athens fc" to "aek athens",
            "rapid vienna" to "rapid wien",
            "inter milan" to "internazionale",
            "internazionale milano" to "internazionale",
            "man utd" to "manchester united",
            "manchester utd" to "manchester united",
            "spurs" to "tottenham",
            "psv eindhoven" to "psv",
            "psv eindhoven fc" to "psv",
            "sporting lisbon" to "sporting cp",
            "sporting lisboa" to "sporting cp"
        )
        s = aliases[s] ?: s

        val tokens = s.split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
        val removable = setOf(
            "football", "soccer", "club", "fc", "fk", "cf", "sc", "afc", "nk", "ik", "if",
            "sv", "sk", "ac", "ec", "calcio", "the"
        )
        tokens.removeAll { it in removable }

        // Common suffixes used by some sources are not part of the club identity.
        // Only remove them when another meaningful token remains.
        // Do NOT globally delete club suffixes here.  "Manchester City" and
        // "Manchester" can be different clubs.  Suffix equivalence is handled
        // conservatively by teamSimilarity() instead.
        return tokens.joinToString("")
    }

    private fun canonicalTokens(value: String): Set<String> {
        val normalized = canonicalTeam(value)
        if (normalized.isBlank()) return emptySet()
        // Use the original normalized word boundaries so Jaccard can still help.
        val s = value.trim().lowercase()
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
        val clean = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        val removable = setOf(
            "football", "soccer", "club", "fc", "fk", "cf", "sc", "afc", "nk", "ik", "if",
            "sv", "sk", "ac", "ec", "calcio", "the", "city", "united", "town", "rovers",
            "wanderers", "athletic", "county"
        )
        return clean.split(Regex("\\s+")).filter { it.isNotBlank() && it !in removable }.toSet()
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
