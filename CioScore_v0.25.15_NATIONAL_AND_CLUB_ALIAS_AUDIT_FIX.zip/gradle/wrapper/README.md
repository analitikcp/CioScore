# Gradle bootstrap wrapper

This project pins Gradle 9.5.0 in `gradle-wrapper.properties` and uses `gradlew` / `gradlew.bat` to download the pinned distribution on first run.

The downloaded distribution is SHA-256 verified before extraction.
