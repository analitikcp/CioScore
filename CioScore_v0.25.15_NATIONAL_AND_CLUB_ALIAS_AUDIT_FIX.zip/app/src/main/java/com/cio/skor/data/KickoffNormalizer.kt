package com.cio.skor.data

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Single canonical kickoff clock for the app.
 *
 * All provider/official fixture timestamps used by the matcher and UI are
 * interpreted/displayed in Europe/Istanbul. Epoch timestamps remain absolute;
 * only local date/time values without an explicit offset are assigned this zone.
 */
object KickoffNormalizer {
    val ZONE: ZoneId = ZoneId.of("Europe/Istanbul")
    private val DATE_OUT = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private val TIME_OUT = DateTimeFormatter.ofPattern("HH:mm")
    private val DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")

    fun toEpochMillis(date: String, time: String): Long {
        val d = parseDate(date) ?: return 0L
        val t = parseTime(time) ?: return 0L
        return LocalDateTime.of(d, t).atZone(ZONE).toInstant().toEpochMilli()
    }

    fun normalizeDate(value: String): String {
        val v = value.trim()
        if (v.isBlank()) return ""
        val direct = listOf(
            "yyyy-MM-dd", "yyyy/MM/dd", "dd.MM.yyyy", "dd/MM/yyyy", "dd-MM-yyyy"
        )
        for (pattern in direct) {
            val parsed = runCatching {
                LocalDate.parse(v.take(10), DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed.format(DATE_OUT)
        }
        return ""
    }

    fun normalizeTime(value: String): String {
        val m = Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(value) ?: return "--:--"
        return "%02d:%s".format(m.groupValues[1].toInt(), m.groupValues[2])
    }

    fun fromEpochMillis(timestamp: Long): Pair<String, String> {
        if (timestamp <= 0L) return "" to "--:--"
        val local = Instant.ofEpochMilli(timestamp).atZone(ZONE)
        return local.toLocalDate().format(DATE_OUT) to local.toLocalTime().format(TIME_OUT)
    }

    fun displayDate(timestamp: Long, fallback: String = ""): String =
        if (timestamp > 0L) fromEpochMillis(timestamp).first else normalizeDate(fallback)

    fun displayTime(timestamp: Long, fallback: String = "--:--"): String =
        if (timestamp > 0L) fromEpochMillis(timestamp).second else normalizeTime(fallback)

    fun isPast(timestamp: Long, nowMillis: Long = System.currentTimeMillis()): Boolean =
        timestamp > 0L && timestamp <= nowMillis

    fun isUpcoming(timestamp: Long, nowMillis: Long = System.currentTimeMillis()): Boolean =
        timestamp > nowMillis

    fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy", "yyyy/MM/dd")
        for (pattern in patterns) {
            runCatching { LocalDate.parse(v.take(10), DateTimeFormatter.ofPattern(pattern)) }
                .getOrNull()?.let { return it }
        }
        return null
    }

    fun parseTime(value: String): LocalTime? {
        val v = normalizeTime(value)
        if (v == "--:--") return null
        return runCatching { LocalTime.parse(v, TIME_OUT) }.getOrNull()
    }

    /** Parse a local date/time string in the app's canonical zone. */
    fun parseLocalDateTime(value: String): Long {
        val text = value.trim()
        if (text.isBlank()) return 0L
        val formatters = listOf(
            DATE_TIME,
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
        )
        for (formatter in formatters) {
            runCatching {
                return LocalDateTime.parse(text, formatter).atZone(ZONE).toInstant().toEpochMilli()
            }
        }
        return 0L
    }
}
