# Prediction-first / İddaa enrichment rule

- The configured prediction providers are the primary display set.
- A prediction is never removed because it cannot be matched to the official İddaa bulletin.
- İddaa is an optional enrichment layer for MS 1/X/2, HT/FT, official team labels, date/time and the program URL.
- If an official match is found with sufficient identity evidence, those fields enrich the prediction card.
- If no official match is found, the card remains visible using the prediction provider data and its İddaa fields remain empty.
- This rule applies even when the official feed fails, times out, or has a different bulletin roster.
