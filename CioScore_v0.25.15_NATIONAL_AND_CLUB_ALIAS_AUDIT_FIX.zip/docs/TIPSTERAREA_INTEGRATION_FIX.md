# TipsterArea integration repair — v0.24.96

## Root cause confirmed

TipsterArea's public daily match index uses URLs in the form `date-DD-MM-YYYY`. The previous integration requested `date-YYYY-MM-DD`, so match discovery could fail before the detail-page parser ever ran.

## v0.24.96 changes

- Corrected TipsterArea daily index URL format to `date-dd-MM-yyyy`.
- Kept the existing team-pair matching and image-alt bookmaker detection.
- Kept the Standard 1X2 parser limited to real numeric 1/X/2 values; no synthetic odds are generated.
- Emits the five independently parsed rows when present: 1xBet, bet-at-home, Betfair, bwin, Unibet.
- Preserved official İddaa verification, score/prediction pipeline, main-card İddaa + Bet365, ORANLAR UI, and bottom safe-area handling.

## Web verification

TipsterArea currently exposes the five bookmaker rows in the Standard 1X2 table on its match pages, and its daily index is published at `https://tipsterarea.com/matches/date-DD-MM-YYYY`.
