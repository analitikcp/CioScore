# CioScore v0.24.92 – Launcher Icon + Bulletin Link Cleanup

- Launcher icon replaced with the gold crown / CP / football artwork.
- Adaptive icon uses a safe inset so Android launcher masks do not crop the crest.
- Removed the duplicate top `İDDAA BÜLTENİ` link from each match card.
- Kept the lower `İDDAA BÜLTENİNDE AÇ` button as the single match-card bulletin action.
- Existing odds, score pipeline, official İddaa gate, and bottom inset behavior are unchanged.
