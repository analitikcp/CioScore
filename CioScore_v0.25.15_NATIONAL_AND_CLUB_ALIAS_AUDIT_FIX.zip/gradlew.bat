@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"
for /f "tokens=2 delims=-" %%V in ('findstr /r /c:"^distributionUrl=.*gradle-[0-9][0-9.]*-bin.zip$" "%PROPS%"') do set "GRADLE_VERSION=%%V"
if not defined GRADLE_VERSION (
  echo ERROR: Could not read Gradle version from gradle-wrapper.properties.
  exit /b 1
)
set "GRADLE_USER_HOME=%GRADLE_USER_HOME%"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "DIST_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%DIST_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
set "DIST_ZIP=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
set "DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_BIN%" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%DIST_URL%' -OutFile '%DIST_ZIP%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$e=(Get-Content '%PROPS%' | Where-Object { $_ -match '^distributionSha256Sum=' }) -replace '^distributionSha256Sum=',''; $a=(Get-FileHash '%DIST_ZIP%' -Algorithm SHA256).Hash.ToLower(); if($a -ne $e.ToLower()){ throw 'Gradle distribution SHA-256 mismatch.' }"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%DIST_ZIP%' -DestinationPath '%DIST_DIR%' -Force"
  if errorlevel 1 exit /b 1
  del /q "%DIST_ZIP%"
)

call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
