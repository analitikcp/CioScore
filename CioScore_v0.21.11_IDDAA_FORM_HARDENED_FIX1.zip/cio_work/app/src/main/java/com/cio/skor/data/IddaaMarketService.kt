package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Official Iddaa sportsbook feed.
 *
 * Source: official Iddaa football program and its first-party sportsbook feed.
 * Program page: https://www.iddaa.com/program/futbol
 * The official events feed returns event-level markets in JSON; market-config
 * maps (t, st) to official market metadata. HT/FT is identified from the
 * 9 official outcome labels and normalized to 1/1..2/2. No third-party odds
 * source is used.
 */
class IddaaMarketService {
    data class OpenedMarketMatch(
        val matchId: String,
        val homeTeam: String,
        val awayTeam: String,
        val homeTeamId: Long? = null,
        val awayTeamId: Long? = null,
        val matchTimestamp: Long = 0L,
        val matchTime: String = "--:--",
        val matchDate: String = "",
        val competitionName: String = "",
        val ms1: String? = null,
        val msX: String? = null,
        val ms2: String? = null,
        val hasHtFt: Boolean = false,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf()
    ) {
        val hasMatchResult: Boolean get() = ms1 != null || msX != null || ms2 != null
    }

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val marketMatches: Int,
        val httpEvents: Int,
        val httpMarketConfig: Int,
        val error: String? = null
    )

    private data class MarketConfig(
        val name: String,
        val normalizedName: String
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private companion object {
        const val PROGRAM = "https://www.iddaa.com/program/futbol"
        const val BASE = "https://sportsbookv2.iddaa.com/sportsbook"
        // First-party JSON feed used by the official iddaa.com football program.
        // MS 1/X/2 and HT/FT are both official Iddaa markets; no third-party odds source is used.
        const val EVENTS = "$BASE/events?st=1&type=0&version=0"
        const val CONFIG = "$BASE/get_market_config"
        val REQUIRED_HTFT = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
    }

    /** Same official feed used by both the main screen and Opened Markets. */
    suspend fun fetchOpenedMarkets(): Result = fetchToday()

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(30_000L) {
            try {
                val zone = ZoneId.of("Europe/Istanbul")
                val today = LocalDate.now(zone)
                val programUrl = "$PROGRAM?date=${today.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))}"

                // The visible program page and this endpoint are first-party Iddaa data.
                // We use the JSON feed behind the page instead of scraping the HTML table.
                val eventsResponse = get(EVENTS, programUrl)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, -1, 0, "İddaa resmi program verisi alınamadı")
                val configResponse = get(CONFIG, programUrl)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, eventsResponse.code, -1, "İddaa market config verisi alınamadı")

                val configs = parseMarketConfig(configResponse)
                val parsed = parseEvents(eventsResponse, configs)
                val todayMatches = parsed
                    .filter { pair ->
                        pair.first <= 0L || Instant.ofEpochMilli(pair.first).atZone(zone).toLocalDate() == today
                    }
                    .map { it.second }
                    // The official feed can expose the same fixture more than once
                    // (for example under slightly different team labels). Merge those
                    // records before either the main screen or HT/FT screen consumes them.
                    .let(::mergeOfficialMatches)
                    .sortedBy { it.matchTimestamp.takeIf { ts -> ts > 0L } ?: Long.MAX_VALUE }

                val marketMatches = todayMatches.count { it.hasHtFt }
                Result(
                    matches = todayMatches,
                    scanned = todayMatches.size,
                    marketMatches = marketMatches,
                    httpEvents = eventsResponse.code,
                    httpMarketConfig = configResponse.code
                )
            } catch (e: Exception) {
                Result(emptyList(), 0, 0, -1, -1, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, 0, -1, -1, "İddaa resmi veri taraması zaman aşımına uğradı")
    }

    private fun mergeOfficialMatches(matches: List<OpenedMarketMatch>): List<OpenedMarketMatch> {
        if (matches.size < 2) return matches

        val merged = LinkedHashMap<String, OpenedMarketMatch>()
        val idToKey = HashMap<String, String>()
        val canonicalToKey = HashMap<String, String>()
        for (incoming in matches) {
            // Official event ID is the strongest identity inside the official feed.
            // Canonical home/away remains a fallback and also catches the rare case
            // where the same official event appears with two IDs in separate payloads.
            val canonicalKey = MatchMerger.key(incoming.homeTeam, incoming.awayTeam)
            val idKey = incoming.matchId.trim().takeIf { it.isNotBlank() }?.let { "ID:$it" }
            val key = idKey?.let { idToKey[it] }
                ?: canonicalToKey[canonicalKey]
                ?: idKey
                ?: canonicalKey
            if (idKey != null) idToKey[idKey] = key
            canonicalToKey[canonicalKey] = key
            val current = merged[key]
            if (current == null) {
                merged[key] = incoming
                continue
            }

            // Keep the richest record while combining independently parsed markets.
            val useIncomingTime = current.matchTimestamp <= 0L && incoming.matchTimestamp > 0L
            val combinedOdds = linkedMapOf<String, String>().apply {
                putAll(current.htFtOdds)
                putAll(incoming.htFtOdds)
            }
            merged[key] = current.copy(
                matchId = if (current.matchId.isNotBlank()) current.matchId else incoming.matchId,
                homeTeam = if (current.homeTeam.isNotBlank()) current.homeTeam else incoming.homeTeam,
                awayTeam = if (current.awayTeam.isNotBlank()) current.awayTeam else incoming.awayTeam,
                matchTimestamp = if (useIncomingTime) incoming.matchTimestamp else current.matchTimestamp,
                matchTime = if (current.matchTime != "--:--") current.matchTime else incoming.matchTime,
                matchDate = if (current.matchDate.isNotBlank()) current.matchDate else incoming.matchDate,
                competitionName = if (current.competitionName.isNotBlank()) current.competitionName else incoming.competitionName,
                homeTeamId = current.homeTeamId ?: incoming.homeTeamId,
                awayTeamId = current.awayTeamId ?: incoming.awayTeamId,
                ms1 = current.ms1 ?: incoming.ms1,
                msX = current.msX ?: incoming.msX,
                ms2 = current.ms2 ?: incoming.ms2,
                hasHtFt = current.hasHtFt || incoming.hasHtFt || combinedOdds.isNotEmpty(),
                htFtOdds = combinedOdds
            )
        }
        return merged.values.toList()
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun get(url: String, refererUrl: String = PROGRAM): HttpResult? = runCatching {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json, text/plain, */*")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Origin", "https://www.iddaa.com")
            .header("Referer", refererUrl)
            .build()
        client.newCall(request).execute().use { response ->
            HttpResult(response.code, response.body?.string().orEmpty())
        }
    }.getOrNull()

    private fun parseMarketConfig(response: HttpResult): Map<String, MarketConfig> {
        val root = JSONObject(response.body)
        val data = root.optJSONObject("data") ?: return emptyMap()
        val markets = data.optJSONObject("m") ?: return emptyMap()
        val out = HashMap<String, MarketConfig>()
        val keys = markets.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = markets.optJSONObject(key) ?: continue
            val name = item.optString("n", "Unknown Market")
            out[key] = MarketConfig(name, normalize(name))
        }
        return out
    }

    private fun parseEvents(
        response: HttpResult,
        configs: Map<String, MarketConfig>
    ): List<Pair<Long, OpenedMarketMatch>> {
        val root = JSONObject(response.body)
        val events = root.optJSONObject("data")?.optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Pair<Long, OpenedMarketMatch>>(events.length())

        for (index in 0 until events.length()) {
            val event = events.optJSONObject(index) ?: continue
            val id = event.optString("i", "")
            val home = event.optString("hn", "").trim()
            val away = event.optString("an", "").trim()
            if (id.isBlank() || home.isBlank() || away.isBlank()) continue

            val timestamp = readTimestampMillis(event)
            val zone = ZoneId.of("Europe/Istanbul")
            val matchTime = readDisplayTime(event, timestamp)
            val matchDate = if (timestamp > 0L) {
                Instant.ofEpochMilli(timestamp).atZone(zone)
                    .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            } else ""
            // Competition/league is part of the fixture identity pipeline.
            // Keep it local to each event so every OpenedMarketMatch carries the
            // metadata parsed from the same official event object.
            val competitionName = readCompetitionName(event)

            var ms1: String? = null
            var msX: String? = null
            var ms2: String? = null
            val htFt = linkedMapOf<String, String>()
            val markets = event.optJSONArray("m")

            if (markets == null) {
                // Keep the official fixture even when no market payload is returned.
                // This preserves the official start time for the main card.
                out += timestamp to OpenedMarketMatch(
                    matchId = id,
                    homeTeam = home,
                    awayTeam = away,
                    homeTeamId = readTeamId(event, true),
                    awayTeamId = readTeamId(event, false),
                    matchTimestamp = timestamp,
                    matchTime = matchTime,
                    matchDate = matchDate,
                    competitionName = competitionName
                )
                continue
            }

            // 1) HT/FT and MS are deliberately parsed as two independent markets.
            // The visible iddaa.com football program places "Maç Sonucu" before
            // "1. Yarı Sonucu". Both markets use 1/X/2 labels, so outcome labels
            // alone are NEVER sufficient to identify the MS market.
            //
            // First pass: collect the official market-config name for every market.
            // Second pass: select exact "Maç Sonucu". If a deployment returns a
            // stale/incomplete market-config, use the FIRST non-half 3-way market
            // as a guarded fallback. This prevents the first-half odds from leaking
            // into the MS 1 / MS X / MS 2 card fields.
            var fallbackMs: Triple<String?, String?, String?>? = null

            for (mIndex in 0 until markets.length()) {
                val market = markets.optJSONObject(mIndex) ?: continue
                val t = market.optInt("t", -1)
                val st = market.optInt("st", -1)
                val marketConfig = configs["${t}_${st}"]
                val configName = marketConfig?.normalizedName.orEmpty()
                val outcomes = readOutcomes(market.opt("o"))
                if (outcomes.isEmpty()) continue

                val htCandidate = linkedMapOf<String, String>()
                val threeWay = linkedMapOf<String, String>()

                for (outcome in outcomes) {
                    val odd = outcome.second ?: continue
                    if (odd <= 1.0) continue

                    normalizeHtFt(outcome.first)?.let { htCandidate[it] = formatOdd(odd) }
                    when (normalizeOutcome(outcome.first)) {
                        "1", "x", "2" -> threeWay[normalizeOutcome(outcome.first)] = formatOdd(odd)
                    }
                }

                // Full 9-cell grid is unambiguous HT/FT.
                if (REQUIRED_HTFT.all { htCandidate.containsKey(it) }) {
                    REQUIRED_HTFT.forEach { htFt[it] = htCandidate.getValue(it) }
                    continue
                }

                // Official market-config match for HT/FT.
                if (isHtFt(configName)) {
                    htCandidate.forEach { (k, v) -> htFt[k] = v }
                    continue
                }

                // EXACT official Match Result market. This is the primary MS source.
                if (isMatchResult(configName) && threeWay.size == 3) {
                    ms1 = threeWay["1"]
                    msX = threeWay["x"]
                    ms2 = threeWay["2"]
                    continue
                }

                // Guarded fallback only when market-config does not identify the
                // market. Explicitly reject first/second-half markets so 2.06/2.42/4.32
                // style first-half odds can never become the MS columns.
                if (fallbackMs == null && threeWay.size == 3 && !isHalfResult(configName) && !isHtFt(configName)) {
                    fallbackMs = Triple(threeWay["1"], threeWay["x"], threeWay["2"])
                }
            }

            if (ms1 == null && msX == null && ms2 == null) {
                ms1 = fallbackMs?.first
                msX = fallbackMs?.second
                ms2 = fallbackMs?.third
            }

            // Keep every official fixture in the result so the main cards can
            // always receive the official start time, even if a market is closed.
            out += timestamp to OpenedMarketMatch(
                matchId = id,
                homeTeam = home,
                awayTeam = away,
                homeTeamId = readTeamId(event, true),
                awayTeamId = readTeamId(event, false),
                matchTimestamp = timestamp,
                matchTime = matchTime,
                matchDate = matchDate,
                competitionName = competitionName,
                ms1 = ms1,
                msX = msX,
                ms2 = ms2,
                hasHtFt = htFt.isNotEmpty(),
                htFtOdds = htFt
            )
        }
        return out
    }

    /**
     * Reads the official event start time defensively. The feed has appeared with
     * epoch seconds, epoch milliseconds and ISO/date strings across deployments.
     * We normalize everything to epoch milliseconds before the UI sees it.
     */
    /**
     * Extract first-party Iddaa team IDs defensively. Deployments can expose
     * them as direct fields or inside a home/away team object.
     */
    private fun readTeamId(event: JSONObject, home: Boolean): Long? {
        val directKeys = if (home) {
            listOf("homeTeamId", "home_team_id", "homeId", "home_id", "homeTeamID", "hid", "hi", "htId")
        } else {
            listOf("awayTeamId", "away_team_id", "awayId", "away_id", "awayTeamID", "aid", "ai", "atId")
        }
        directKeys.forEach { key ->
            parsePositiveLong(event.opt(key))?.let { return it }
        }

        val objectKeys = if (home) listOf("homeTeam", "home", "h", "ht")
        else listOf("awayTeam", "away", "a", "at")
        val nestedKeys = listOf("id", "teamId", "team_id", "i", "teamID")
        for (objectKey in objectKeys) {
            val obj = event.optJSONObject(objectKey) ?: continue
            for (key in nestedKeys) {
                parsePositiveLong(obj.opt(key))?.let { return it }
            }
        }
        return null
    }

    private fun parsePositiveLong(value: Any?): Long? {
        val number = when (value) {
            is Number -> value.toLong()
            is String -> value.trim().toLongOrNull()
            else -> null
        }
        return number?.takeIf { it > 0L }
    }

    private fun readCompetitionName(event: JSONObject): String {
        val preferredKeys = listOf(
            "competitionName", "leagueName", "tournamentName", "competition",
            "league", "tournament", "competition_name", "league_name", "tournament_name"
        )
        fun walk(obj: JSONObject, depth: Int): String {
            if (depth > 4) return ""
            for (key in preferredKeys) {
                val value = obj.opt(key)
                if (value is String && value.trim().isNotBlank()) {
                    return value.trim()
                }
                if (value is JSONObject) {
                    val nested = walk(value, depth + 1)
                    if (nested.isNotBlank()) return nested
                }
            }
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = obj.opt(key)
                if (value is JSONObject) {
                    val nested = walk(value, depth + 1)
                    if (nested.isNotBlank()) return nested
                }
            }
            return ""
        }
        return walk(event, 0)
    }

    private fun readTimestampMillis(event: JSONObject): Long {
        // Official event feeds have used d/ed/eventDate across deployments.
        // Read the direct event fields first, then inspect nested date objects so
        // the UI does not silently fall back to --:-- when eventDate is structured.
        val keys = listOf("d", "ed", "eventDate", "startDate", "date", "startTime", "dt", "kickoff")
        return readTimestampFromObject(event, keys, 0)
    }

    private fun readTimestampFromObject(obj: JSONObject, keys: List<String>, depth: Int): Long {
        if (depth > 3) return 0L

        for (key in keys) {
            if (!obj.has(key)) continue
            val raw = obj.opt(key)
            when (raw) {
                is Number -> {
                    val n = raw.toLong()
                    if (n > 0L) return if (n < 100_000_000_000L) n * 1000L else n
                }
                is String -> {
                    val value = raw.trim()
                    value.toLongOrNull()?.let { n ->
                        if (n > 0L) return if (n < 100_000_000_000L) n * 1000L else n
                    }
                    if (value.isNotBlank()) parseDateString(value)?.let { return it }
                }
                is JSONObject -> {
                    readTimestampFromObject(raw, keys, depth + 1).takeIf { it > 0L }?.let { return it }
                }
            }
        }

        val iterator = obj.keys()
        while (iterator.hasNext()) {
            val key = iterator.next()
            val value = obj.opt(key)
            if (value is JSONObject && (key.contains("date", true) || key.contains("time", true) || key == "e")) {
                readTimestampFromObject(value, keys, depth + 1).takeIf { it > 0L }?.let { return it }
            }
        }
        return 0L
    }

    /**
     * Returns the official kickoff text even when a deployment exposes a
     * preformatted time instead of an epoch value. This is only a fallback;
     * numeric event field d remains authoritative.
     */
    private fun readDisplayTime(event: JSONObject, timestamp: Long): String {
        if (timestamp > 0L) {
            return Instant.ofEpochMilli(timestamp)
                .atZone(ZoneId.of("Europe/Istanbul"))
                .format(DateTimeFormatter.ofPattern("HH:mm"))
        }
        val candidates = listOf("time", "matchTime", "startTimeText", "kickoff", "t")
        for (key in candidates) {
            val value = event.optString(key, "").trim()
            if (Regex("^\\d{1,2}:\\d{2}$").matches(value)) {
                val parts = value.split(":")
                return parts[0].padStart(2, '0') + ":" + parts[1]
            }
        }
        return "--:--"
    }

    private fun parseDateString(raw: String): Long? {
        val value = raw.trim()
        val candidates = listOf(
            java.time.format.DateTimeFormatter.ISO_INSTANT,
            java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME
        )
        for (formatter in candidates) {
            try {
                return if (formatter == java.time.format.DateTimeFormatter.ISO_INSTANT) {
                    Instant.parse(value).toEpochMilli()
                } else {
                    java.time.OffsetDateTime.parse(value, formatter).toInstant().toEpochMilli()
                }
            } catch (_: Exception) { }
        }
        val localFormats = listOf(
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
            java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")
        )
        for (formatter in localFormats) {
            try {
                return java.time.LocalDateTime.parse(value, formatter)
                    .atZone(ZoneId.of("Europe/Istanbul")).toInstant().toEpochMilli()
            } catch (_: Exception) { }
        }
        return null
    }

    private fun readOutcomes(raw: Any?): List<Pair<String, Double?>> {
        val result = ArrayList<Pair<String, Double?>>()
        when (raw) {
            is org.json.JSONArray -> {
                for (i in 0 until raw.length()) {
                    val o = raw.optJSONObject(i) ?: continue
                    result += o.optString("n", "") to readOdd(o.opt("odd"))
                }
            }
            is org.json.JSONObject -> {
                val keys = raw.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = raw.opt(key)
                    if (value is org.json.JSONObject) {
                        result += (value.optString("n", key)) to readOdd(value.opt("odd"))
                    } else {
                        result += key to readOdd(value)
                    }
                }
            }
        }
        return result
    }

    private fun readOdd(raw: Any?): Double? = when (raw) {
        is Number -> raw.toDouble()
        is String -> raw.replace(',', '.').toDoubleOrNull()
        else -> null
    }

    private fun isHalfResult(name: String): Boolean =
        name.contains("ilk yari sonucu") ||
            name.contains("ikinci yari sonucu") ||
            name == "first half result" ||
            name == "second half result"

    private fun isMatchResult(name: String): Boolean {
        if (name.isBlank()) return false
        if (isHalfResult(name)) return false
        if (name.contains("handikap") || name.contains("korner")) return false
        return name == "mac sonucu" ||
            name == "match result" ||
            (name.contains("mac sonucu") &&
                !name.contains("ilk yari") &&
                !name.contains("ikinci yari") &&
                !name.contains("ve karsilikli gol") &&
                !name.contains("ve alt/ust"))
    }

    private fun isHtFt(name: String): Boolean =
        name.contains("ilk yari / mac sonucu") ||
            name.contains("ilk yari/mac sonucu") ||
            name.contains("ilk yari mac sonucu") ||
            name.contains("first half / match result") ||
            name.contains("half time / full time")

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('&', ' ')
        v = Normalizer.normalize(v, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        v = v.replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ç', 'c').replace('ö', 'o').replace('ü', 'u')
        return v.replace(Regex("\\s+"), " ").trim()
    }

    private fun normalizeOutcome(value: String): String =
        value.trim().lowercase(Locale.ROOT)
            .replace("0", "x")
            .replace("beraberlik", "x")
            .replace("draw", "x")

    private fun normalizeHtFt(value: String): String? {
        val v = value.trim().uppercase(Locale.ROOT)
            .replace("0", "X")
            .replace('-', '/')
            .replace(" ", "")
        return if (v.matches(Regex("^[1X2]/[1X2]$"))) v else null
    }

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    fun findForTeamPair(
        matches: List<OpenedMarketMatch>,
        homeTeam: String,
        awayTeam: String
    ): OpenedMarketMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) && MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
