package com.cio.skor.ui

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.os.Handler
import android.os.Looper
import com.cio.skor.data.KickoffNormalizer
import com.cio.skor.data.CioAiAnalyzer
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.PredictionSourceCatalog
import com.cio.skor.data.SofaScoreService

/** One card per unified match; score-analysis sources are displayed as fixed filter labels. */
data class MatchGroup(
    /** True only when this prediction group was successfully matched to an official İddaa bulletin fixture. */
    val isIddaaBulletinMatch: Boolean = false,
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    // Resmi İddaa 1X2 oranları; external odds alanı kullanılmaz.
    val iddaaMs1: String? = null,
    val iddaaMsX: String? = null,
    val iddaaMs2: String? = null,
    // Real Bet365 pre-match history surfaced on the main card. These values
    // come from the fixture-ID based provider history bridge.
    val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
    val hasHtFt: Boolean = false,
    /** Verified public Iddaa bulletin URL for this fixture's bulletin day. */
    val iddaaProgramUrl: String? = null,
    val homeTeamId: Long? = null,
    val awayTeamId: Long? = null,
    val matchTimestamp: Long = 0L,
    val displayTime: String = "--:--",
    val displayDate: String = ""
)

class ScoreAdapter(
    private val context: Context,
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String, Long?) -> Unit = { _, _ -> },
    private val onHtFtClick: (String, String) -> Unit = { _, _ -> },
    private val onExternalOddsRequest: (MatchGroup) -> Unit = { _ -> },
    private val onOddsClick: (MatchGroup) -> Unit = {},
    private val onCioAiClick: (MatchGroup, List<SofaScoreService.BookmakerOdds>) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private fun hasRenderablePrediction(match: MatchGroup): Boolean =
        match.predictions.any { ScoreModel.hasRenderablePrediction(it.predictedScore) }

    /**
     * Final UI safety gate. MainActivity already removes past/unknown kickoffs,
     * but the adapter must never be able to render one if a caller accidentally
     * submits an unfiltered list or if a race occurs between scan completion and
     * rendering. A valid kickoff is mandatory and must be strictly in the future.
     */
    private fun isUpcomingKickoff(match: MatchGroup, nowMillis: Long = System.currentTimeMillis()): Boolean =
        match.matchTimestamp > nowMillis

    private fun isRenderableForUi(match: MatchGroup, nowMillis: Long = System.currentTimeMillis()): Boolean =
        (hasRenderablePrediction(match) || (match.isIddaaBulletinMatch && match.predictions.isEmpty())) &&
            isUpcomingKickoff(match, nowMillis)

    private var fullList: List<MatchGroup> = initialList.filter { isRenderableForUi(it) }
    private var displayedList: List<MatchGroup> = fullList
    private var currentQuery = ""
    private var favoritesOnly = false
    private val favoritePrefs: SharedPreferences =
        context.getSharedPreferences("cio_favorite_matches", Context.MODE_PRIVATE)

    // Incremental rendering state.
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingRender: Runnable? = null
    private var renderGeneration = 0L
    private val renderBatchSize = 24

    private val externalOddsCache =
        mutableMapOf<String, List<SofaScoreService.BookmakerOdds>>()
    private val externalOddsLoading = mutableSetOf<String>()
    private val oddsPreloaded = mutableSetOf<String>()

    private fun oddsKey(match: MatchGroup): String =
        "${MatchMerger.normalizeTeamName(match.homeTeam)}::${MatchMerger.normalizeTeamName(match.awayTeam)}::${match.displayDate.trim().lowercase()}::${match.matchTimestamp}"

    /** Mark all scan matches as preloaded so RecyclerView binding never starts network work. */
    fun prepareOddsPreload(matches: List<MatchGroup>) {
        matches.forEach { oddsPreloaded.add(oddsKey(it)) }
    }

    fun setExternalOdds(
        match: MatchGroup,
        rows: List<SofaScoreService.BookmakerOdds>
    ) {
        val key = oddsKey(match)
        val incoming = rows.filter { row ->
            row.ms1.toDoubleOrNull()?.let { it > 1.0 } == true &&
            row.msX.toDoubleOrNull()?.let { it > 1.0 } == true &&
            row.ms2.toDoubleOrNull()?.let { it > 1.0 } == true
        }
        // Odds sources complete independently. Merge by bookmaker instead of
        // replacing the whole board, otherwise a fast bwin update would erase
        // Bet365 (or vice versa).
        val merged = (externalOddsCache[key].orEmpty() + incoming)
            .distinctBy { it.bookmaker.lowercase() }
        externalOddsCache[key] = merged
        externalOddsLoading.remove(key)
        val index = displayedList.indexOfFirst {
            oddsKey(it) == key
        }
        if (index >= 0) notifyItemChanged(index)
    }


    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        val list = fullList.filter { match ->
            val favoriteOk = !favoritesOnly || isFavorite(match)
            if (!favoriteOk) return@filter false
            if (q.isEmpty()) return@filter true
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        renderIncrementally(list)
    }

    private fun renderIncrementally(target: List<MatchGroup>) {
        pendingRender?.let(mainHandler::removeCallbacks)
        pendingRender = null
        val generation = ++renderGeneration

        if (target.isEmpty()) {
            displayedList = emptyList()
            notifyDataSetChanged()
            return
        }

        displayedList = target.take(renderBatchSize)
        notifyDataSetChanged()

        var shown = displayedList.size
        if (shown >= target.size) return

        val step = object : Runnable {
            override fun run() {
                if (generation != renderGeneration) return
                val next = (shown + renderBatchSize).coerceAtMost(target.size)
                displayedList = target.subList(0, next)
                shown = next
                notifyDataSetChanged()
                if (shown < target.size) {
                    mainHandler.postDelayed(this, 16L)
                } else {
                    pendingRender = null
                }
            }
        }
        pendingRender = step
        mainHandler.postDelayed(step, 16L)
    }

    private fun favoriteKey(match: MatchGroup): String {
        val home = com.cio.skor.data.TeamAliasCanonicalizer.identity(match.homeTeam).canonicalId
        val away = com.cio.skor.data.TeamAliasCanonicalizer.identity(match.awayTeam).canonicalId
        val ts = if (match.matchTimestamp > 0L) match.matchTimestamp / 60000L else match.displayDate.lowercase()
        return "${home}|${away}|$ts"
    }

    private fun isFavorite(match: MatchGroup): Boolean =
        favoritePrefs.getBoolean(favoriteKey(match), false)

    private fun toggleFavorite(match: MatchGroup): Boolean {
        val key = favoriteKey(match)
        val newValue = !favoritePrefs.getBoolean(key, false)
        favoritePrefs.edit().putBoolean(key, newValue).apply()
        return newValue
    }

    fun setFavoritesOnly(enabled: Boolean) {
        favoritesOnly = enabled
        refreshDisplayed()
    }

    fun isShowingFavorites(): Boolean = favoritesOnly

    fun favoriteCount(): Int = fullList.count(::isFavorite)

    fun submitList(v: List<MatchGroup>) {
        fullList = v.filter { isRenderableForUi(it) }
        refreshDisplayed()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    /** Focus the main list on one exact fixture using canonical team identity. */
    fun focusOnMatch(homeTeam: String, awayTeam: String? = null) {
        // HT/FT official names and main-card names can differ slightly
        // (e.g. city/suffix/language variants). Use the same canonical
        // identity layer as the global fixture engine instead of requiring
        // literal canonical IDs to be identical.
        val candidates = fullList.filter { match ->
            val sameHome = MatchMerger.isSameTeam(match.homeTeam, homeTeam)
            val sameAway = awayTeam.isNullOrBlank() ||
                MatchMerger.isSameTeam(match.awayTeam, awayTeam)
            sameHome && sameAway
        }

        val focused = if (candidates.isNotEmpty()) {
            candidates
        } else {
            // Safe fallback: if the away name was rendered differently by a
            // source, locate the home side rather than leaving the screen empty.
            fullList.filter { MatchMerger.isSameTeam(it.homeTeam, homeTeam) }
        }
        renderIncrementally(focused)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val ctx = parent.context

        // Kart: yükseklik kesinlikle WRAP_CONTENT.
        val card = LinearLayout(ctx).apply {

            orientation = LinearLayout.VERTICAL

            layoutParams =
                RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val horizontal = dp(ctx, 8)
                    val vertical = dp(ctx, 6)
                    setMargins(
                        horizontal,
                        vertical,
                        horizontal,
                        vertical
                    )
                }

            val padding = dp(ctx, 10)
            setPadding(
                padding,
                padding,
                padding,
                padding
            )

            background =
                GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(ctx, 14).toFloat()
                    setStroke(
                        dp(ctx, 1),
                        0xFFE7EAF0.toInt()
                    )
                }

            elevation = dp(ctx, 3).toFloat()

            clipChildren = false
            clipToPadding = false
        }

        return VH(card)
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.card.removeAllViews()
        holder.card.isClickable = true
        holder.card.isFocusable = true
        holder.card.setOnClickListener {
            // Card click opens the home team history as a reliable fallback.
            onTeamClick(match.homeTeam, match.homeTeamId)
        }

        val topMeta = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 3) }
        }
        val metaSpacer = View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        topMeta.addView(metaSpacer)
        val favoriteButton = TextView(ctx).apply {
            text = if (isFavorite(match)) "★" else "☆"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(if (isFavorite(match)) 0xFFFFB800.toInt() else 0xFF667085.toInt())
            contentDescription = if (isFavorite(match)) "Favorilerden çıkar" else "Favorilere ekle"
            setPadding(dp(ctx, 5), 0, dp(ctx, 2), 0)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 42), dp(ctx, 34))
            setOnClickListener {
                val nowFavorite = toggleFavorite(match)
                text = if (nowFavorite) "★" else "☆"
                setTextColor(if (nowFavorite) 0xFFFFB800.toInt() else 0xFF667085.toInt())
                contentDescription = if (nowFavorite) "Favorilerden çıkar" else "Favorilere ekle"
                refreshDisplayed()
            }
        }
        topMeta.addView(favoriteButton)
        holder.card.addView(topMeta)

        // ------------------------------------------------
        // MAÇ TARİHİ + BAŞLAMA SAATİ
        // İddaa eşleşmiş olsa da olmasa da kart kendi maç tarih/saatini gösterir.
        // 06:00 bülten kuralı burada uygulanmaz; yalnızca gösterim bilgisidir.
        // ------------------------------------------------
        // The same canonical timestamp used by the past-match gate is the
        // single source of truth for the visible date/time. Never render a stale
        // provider/official text field that disagrees with matchTimestamp.
        val displayDate = if (match.matchTimestamp > 0L) {
            KickoffNormalizer.displayDate(match.matchTimestamp)
        } else ""
        val displayTime = if (match.matchTimestamp > 0L) {
            KickoffNormalizer.displayTime(match.matchTimestamp)
        } else "--:--"
        holder.card.addView(TextView(ctx).apply {
            text = when {
                displayDate.isNotBlank() && displayTime != "--:--" -> "📅 $displayDate   •   🕐 $displayTime"
                displayDate.isNotBlank() -> "📅 $displayDate"
                else -> "🕐 $displayTime"
            }
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 5) }
        })

        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam, match.homeTeamId) }
                isClickable = true
                isFocusable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam, match.awayTeamId) }
                isClickable = true
                isFocusable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.card.addView(teams)

        // ------------------------------------------------
        // ORANLAR — doğrudan maç kartında. Her bookmaker kendi kaynağından gelir.
        // ------------------------------------------------
        val oddsTable = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), 0)
        }

        fun oddsCell(value: String, weight: Float, bold: Boolean = false): TextView =
            TextView(ctx).apply {
                text = value
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (bold) 0xFF155EEF.toInt() else 0xFF344054.toInt())
                if (bold) setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, weight
                )
                setPadding(dp(ctx, 2), dp(ctx, 5), dp(ctx, 2), dp(ctx, 5))
            }

        fun addOddsRow(name: String, ms1: String, msX: String, ms2: String, primary: Boolean) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(if (primary) 0xFFF0FDF4.toInt() else 0xFFF8FAFC.toInt())
                    cornerRadius = dp(ctx, 8).toFloat()
                    setStroke(dp(ctx, 1), if (primary) 0xFFBBE7CA.toInt() else 0xFFE4E7EC.toInt())
                }
                setPadding(dp(ctx, 4), 0, dp(ctx, 4), 0)
                // Keep all prediction source rows exactly the same height.
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 36)
                ).apply { bottomMargin = dp(ctx, 4) }
            }
            row.addView(oddsCell(name, 1.35f, false))
            row.addView(oddsCell(ms1, 1f, true))
            row.addView(oddsCell(msX, 1f, true))
            row.addView(oddsCell(ms2, 1f, true))
            oddsTable.addView(row)
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(oddsCell("", 1.35f))
        header.addView(oddsCell("MS1", 1f))
        header.addView(oddsCell("MSX", 1f))
        header.addView(oddsCell("MS2", 1f))
        oddsTable.addView(header)

        addOddsRow(
            "🇹🇷 İddaa",
            match.iddaaMs1 ?: "-",
            match.iddaaMsX ?: "-",
            match.iddaaMs2 ?: "-",
            false
        )

        val key = oddsKey(match)
        val cachedRows = externalOddsCache[key].orEmpty()
        val cachedBet365 = cachedRows.firstOrNull { it.bookmaker.contains("Bet365", true) }
        val cachedBwin = cachedRows.firstOrNull { it.bookmaker.equals("bwin", true) }

        // bwin ikinci sırada: ana kartta İddaa'nın hemen altında.
        if (cachedBwin != null) {
            addOddsRow(
                "🌍 bwin",
                cachedBwin.ms1,
                cachedBwin.msX,
                cachedBwin.ms2,
                false
            )
        } else {
            addOddsRow("🌍 bwin", "…", "…", "…", false)
        }

        if (cachedBet365 != null) {
            addOddsRow(
                "🌍 Bet365",
                cachedBet365.ms1,
                cachedBet365.msX,
                cachedBet365.ms2,
                true
            )
        } else {
            addOddsRow("🌍 Bet365", "…", "…", "…", true)
        }

        // Broad bookmaker board: keep the compact card useful while exposing
        // the main reference books used for market analysis. Values are never
        // copied between books; each row keeps its own bookmaker identity.
        val preferredBooks = listOf("Pinnacle", "William Hill", "1xBet", "Betfair", "Betsson", "Interwetten")
        preferredBooks.forEach { preferred ->
            val row = cachedRows.firstOrNull { it.bookmaker.equals(preferred, true) } ?: return@forEach
            addOddsRow("🌍 ${row.bookmaker}", row.ms1, row.msX, row.ms2, false)
        }


        if (!oddsPreloaded.contains(key) && externalOddsLoading.add(key)) {
            onExternalOddsRequest(match)
        }

        holder.card.addView(oddsTable)

        // ------------------------------------------------
        // 21 KAYNAKTAN SKOR TAHMİNLERİ
        // CioScore'un ana özelliği: 21 kaynak satırı her maç kartında
        // MUTLAKA görünür. Parser verisi gelirse gerçek skor yazılır;
        // kaynak o maç için veri vermediyse yalnızca "—" gösterilir.
        // Hiçbir koşulda skor uydurulmaz.
        // ------------------------------------------------
        val predictionTable = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 6), dp(ctx, 1), dp(ctx, 6), 0)
        }

        val predictionTitle = TextView(ctx).apply {
            text = "📊 SKOR TAHMİNLERİ"
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF475467.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(ctx, 3), 0, dp(ctx, 2))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        predictionTable.addView(predictionTitle)

        fun addPredictionRow(label: String, score: String) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(0xFFF8FAFC.toInt())
                    cornerRadius = dp(ctx, 8).toFloat()
                    setStroke(dp(ctx, 1), 0xFFE4E7EC.toInt())
                }
                setPadding(dp(ctx, 4), 0, dp(ctx, 4), 0)
                // Keep all prediction source rows exactly the same height.
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 36)
                ).apply { bottomMargin = dp(ctx, 4) }
            }
            row.addView(TextView(ctx).apply {
                text = label
                textSize = 10f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF344054.toInt())
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(ctx, 4), dp(ctx, 5), dp(ctx, 4), dp(ctx, 5))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.7f)
            })
            row.addView(TextView(ctx).apply {
                text = score
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF155EEF.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(ctx, 4), dp(ctx, 5), dp(ctx, 4), dp(ctx, 5))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            predictionTable.addView(row)
        }

        val predictionRows = listOf(
            "⚽ FP.com" to setOf("fp.com", "fp"),
            "🎯 PredictZ" to setOf("predictz"),
            "📈 WinDrawWin" to setOf("windrawwin", "win draw win"),
            "🔮 DailySports" to setOf("dailysports", "daily sports"),
            "🧠 Sports Mole" to setOf("sports mole", "sportsmole"),
            "⚽ BallPrediction" to setOf("ballprediction", "ball prediction"),
            "📐 Forebet" to setOf("forebet"),
            "📈 Tip724" to setOf("tip724"),
            "🎯 Correct-Score.net" to setOf("correct-score.net", "correct score net"),
            "📊 FootballScorePredictor" to setOf("footballscorepredictor", "football score predictor"),
            "🔮 AccurateTip" to setOf("accuratetip", "accurate tip"),
            "🟣 Vitibet" to setOf("vitibet"),
            "🟠 Betimate" to setOf("betimate"),
            "📊 FootyStats" to setOf("footystats"),
            "🟢 BetClan" to setOf("betclan"),
            "🌐 FreeSuperTips" to setOf("freesupertips", "free super tips"),
            "🎯 FutHead Predictions" to setOf("futhead predictions", "futheadpredictions"),
            "⚽ SoccerPunter" to setOf("soccerpunter"),
            "🎯 Betshoot" to setOf("betshoot"),
            "📌 OLBG" to setOf("olbg"),
            "🔒 BettingClosed" to setOf("bettingclosed")
        )
        val predictionsBySource = match.predictions
            .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
            .associateBy { it.source.trim().lowercase() }
        predictionRows.forEach { (label, aliases) ->
            val prediction = aliases.asSequence()
                .mapNotNull { predictionsBySource[it] }
                .firstOrNull()
            addPredictionRow(
                label,
                prediction?.predictedScore ?: "—"
            )
        }

        holder.card.addView(predictionTable)

        // ------------------------------------------------
        // CİO AI — maç kartına bağlı analiz düğmesi.
        // ------------------------------------------------
        val aiButton = android.widget.Button(ctx).apply {
            text = "🤖 Cio AI"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF5B21B6.toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 42)
            ).apply {
                topMargin = dp(ctx, 4)
                bottomMargin = dp(ctx, 2)
            }
            setOnClickListener { onCioAiClick(match, cachedRows) }
        }
        holder.card.addView(aiButton)

        // İddaa bülteni yalnızca ekranın sabit alt çubuğunda bulunur.
        // HT/FT erişimi üst menüden yapılır.

    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 13f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun predictionOutcome(score: String): String? {
        if (!ScoreModel.hasRenderablePrediction(score)) return null
        val match = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
