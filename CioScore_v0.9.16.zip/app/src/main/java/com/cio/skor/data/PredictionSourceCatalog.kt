package com.cio.skor.data

/**
 * Single UI-facing registry for prediction-provider names.
 *
 * The repository owns which providers are actually fetched; this registry only
 * defines their stable display order/labels. Unknown providers are still
 * renderable, which prevents a new parser from silently disappearing from the
 * APK just because the adapter was not updated at the same time.
 */
object PredictionSourceCatalog {
    private val preferredOrder = listOf(
        "FP.com",
        "PredictZ",
        "WinDrawWin",
        "DailySports",
        "Sports Mole",
        "BallPrediction",
        "Forebet",
        "Tip724",
        "Correct-Score.net",
        "FootballScorePredictor",
        "AccurateTip",
        "Vitibet",
        "Betimate",
        "FootyStats",
        "BetClan",
        "FreeSuperTips",
        "FutHead Predictions",
        "SoccerPunter",
        "Betshoot",
        "OLBG",
        "BettingClosed"
    )

    private val labels: Map<String, String> = listOf(
        Pair("fp.com", "Skor Analiz Filtre1"),
        Pair("predictz", "Skor Analiz Filtre2"),
        Pair("windrawwin", "Skor Analiz Filtre3"),
        Pair("dailysports", "Skor Analiz Filtre4"),
        Pair("sports mole", "Sports Mole"),
        Pair("ballprediction", "BallPrediction"),
        Pair("forebet", "Forebet"),
        Pair("tip724", "Tip724"),
        Pair("correct-score.net", "Correct-Score.net"),
        Pair("footballscorepredictor", "FootballScorePredictor"),
        Pair("accuratetip", "AccurateTip"),
        Pair("vitibet", "Vitibet"),
        Pair("betimate", "Betimate"),
        Pair("footystats", "FootyStats"),
        Pair("betclan", "BetClan"),
        Pair("freesupertips", "FreeSuperTips"),
        Pair("futhead predictions", "FutHead Predictions"),
        Pair("soccerpunter", "SoccerPunter"),
        Pair("betshoot", "Betshoot"),
        Pair("olbg", "OLBG"),
        Pair("bettingclosed", "BettingClosed")
    ).toMap()

    fun orderOf(source: String): Int =
        preferredOrder.indexOfFirst { it.equals(source.trim(), ignoreCase = true) }
            .takeIf { it >= 0 } ?: preferredOrder.size

    fun displayLabel(source: String): String {
        labels[source.trim().lowercase()]?.let { return it }
        return "Skor Analiz • ${source.trim()}"
    }
}
