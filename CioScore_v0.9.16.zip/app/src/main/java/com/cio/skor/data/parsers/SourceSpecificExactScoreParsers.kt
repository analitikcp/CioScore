package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * v0.9.16 source-by-source DOM parsers.
 *
 * IMPORTANT: there is intentionally no provider-agnostic score parser here.
 * Each class knows the provider's own fixture/prediction markers and DOM shape.
 * Shared helpers only build/validate ScoreModel after a source-specific parser
 * has selected the fixture scope.
 */

private fun sourceTeam(raw: String): String = raw
    .replace(Regex("(?i)\\bimage\\b"), " ")
    .replace(Regex("(?i)\\b(?:correct score|predicted scoreline|our pick|prediction|predictions|tip|details|odds)\\b.*$"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':', '·')

private fun validTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.matches(Regex("(?i)^(home|away|draw|score|correct score|prediction|predictions|tip|odds|time|date|details|preview|football|image|vs|event)$"))) return false
    return true
}

private fun scorePair(raw: String): String? {
    val m = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)").find(raw) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null
    val a = m.groupValues[2].toIntOrNull() ?: return null
    return if (h in 0..20 && a in 0..20) "$h-$a" else null
}

private fun firstTwoTeams(scope: Element): List<String> {
    // DOM priority is deliberate: explicit home/away nodes are stronger than
    // arbitrary links. A generic first-two-links strategy can capture league,
    // tipster or navigation anchors and silently swap/poison fixture identity.
    val homeAway = listOf(
        scope.select("[data-home-team]").firstOrNull()?.text().orEmpty(),
        scope.select("[data-away-team]").firstOrNull()?.text().orEmpty(),
        scope.select("[class*=home-team], [class*=home_team], [class*=hometeam]").firstOrNull()?.text().orEmpty(),
        scope.select("[class*=away-team], [class*=away_team], [class*=awayteam]").firstOrNull()?.text().orEmpty()
    ).map(::sourceTeam).filter(::validTeam)
    if (homeAway.size >= 2) return homeAway.take(2)

    val teamNodes = scope.select("[class*=team], [class*=Team]")
        .map { sourceTeam(it.text()) }
        .filter(::validTeam)
        .distinct()
    if (teamNodes.size >= 2) return teamNodes.take(2)

    // Last resort is still fixture-local: only anchors inside the selected
    // prediction row/card are considered, never page-level navigation links.
    val links = scope.select("a[href]")
        .map { sourceTeam(it.text()) }
        .filter(::validTeam)
        .filterNot { it.contains(Regex("(?i)correct score|prediction|predictions|details|odds|tip")) }
        .distinct()
    return links.take(2)
}

private fun buildSourceModel(
    parser: BaseParser,
    source: String,
    homeRaw: String,
    awayRaw: String,
    score: String,
    scope: Element,
    competition: String = ""
): ScoreModel? {
    val home = sourceTeam(homeRaw)
    val away = sourceTeam(awayRaw)
    if (!validTeam(home) || !validTeam(away) || home.equals(away, true)) return null

    val base = parser.extractFixtureMetadata(scope)
    val meta = if (base.competitionName.isNotBlank() || competition.isBlank()) base
    else parser.mergeMetadata(base.matchDate, base.matchTime, competition, base.competitionCountry, base.rawDateTime)

    return ScoreModel(
        homeTeam = home,
        awayTeam = away,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = meta.matchTimestamp,
        matchDate = meta.matchDate,
        matchTime = meta.matchTime,
        competitionName = meta.competitionName,
        competitionCountry = meta.competitionCountry
    )
}

/** Forebet: rows expose Home/Away + Pred + Correct score as distinct columns. */
class ForebetExactScoreParser : BaseParser("Forebet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val rows = doc.select("table tr, tr.rcnt, div.rcnt, div[class*=rcnt]")
        for (row in rows) {
            val cells = row.select("td, th").map { clean(it.text()) }.filter { it.isNotBlank() }
            val text = clean(row.text())
            if (cells.size < 3 || !text.contains(Regex("(?i)correct\\s*score"))) continue
            val score = when {
                cells.any { it.matches(Regex("^\\d{1,2}\\s*[-:]\\s*\\d{1,2}$")) } ->
                    cells.first { it.matches(Regex("^\\d{1,2}\\s*[-:]\\s*\\d{1,2}$")) }.let(::scorePair)
                else -> scorePair(text.split(Regex("(?i)correct\\s*score"), limit = 2).last())
            } ?: continue
            val teams = firstTwoTeams(row)
            if (teams.size < 2) {
                val probable = cells.filter(::validTeam)
                if (probable.size >= 2) {
                    val item = buildSourceModel(this, "Forebet", probable[0], probable[1], score, row, extractNearestCompetition(row))
                    if (item != null) out.putIfAbsent(item.matchKey, item)
                }
                continue
            }
            val item = buildSourceModel(this, "Forebet", teams[0], teams[1], score, row, extractNearestCompetition(row))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** BetClan: prediction rows expose fixture links and a Full Time/score marker. */
class BetClanExactScoreParser : BaseParser("BetClan") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, li, [class*=match], [class*=fixture], [class*=prediction]")
            .filter { it.text().contains(Regex("(?i)(full\\s*time|correct\\s*score|prediction)")) }
            .sortedBy { it.text().length }
        for (scope in scopes) {
            val text = clean(scope.text())
            val score = Regex("(?i)(?:full\\s*time(?:\\s*result)?|correct\\s*score)\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})")
                .find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "BetClan", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** FootballPredictions.com: betting-tip table rows contain explicit Correct Score fields. */
class FootballPredictionsComExactScoreParser : BaseParser("FootballPredictions.com") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("table tr, article, li, [class*=match], [class*=fixture]")) {
            val text = clean(row.text())
            if (!text.contains(Regex("(?i)correct\\s*score"))) continue
            val m = Regex("(?i)correct\\s*score\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text) ?: continue
            val score = "${m.groupValues[1]}-${m.groupValues[2]}"
            val teams = firstTwoTeams(row)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "FootballPredictions.com", teams[0], teams[1], score, row, extractNearestCompetition(row))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** FutHead Predictions: event rows contain score + Time + Date + Details. */
class FutHeadPredictionsExactScoreParser : BaseParser("FutHead Predictions") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, li, div[class*=event], div[class*=match], [class*=prediction]")
            .filter { it.text().contains(Regex("(?i)\\bTime\\s*:|\\bDate\\s*:|\\bPredict\\b")) }
            .sortedBy { it.text().length }
        for (scope in scopes) {
            val text = clean(scope.text())
            val time = Regex("(?i)\\bTime\\s*:\s*(?:[01]?\\d|2[0-3]):[0-5]\\d").containsMatchIn(text)
            if (!time) continue
            val date = Regex("(?i)\\bDate\\s*:\s*\\d{2}\\.\\d{2}\\.\\d{2,4}").containsMatchIn(text)
            if (!date) continue
            val score = Regex("(?i)\\b(?:Predict|Score)\\b[^0-9]{0,20}(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
                ?: scorePair(text.substringBefore(Regex("(?i)\\bTime\\s*:")))
                ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "FutHead Predictions", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** SoccerPunter: prediction/competition tables expose Correct Score as a market label. */
class SoccerPunterExactScoreParser : BaseParser("SoccerPunter") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("tr, article, li, [class*=match], [class*=fixture], [class*=tip]") ) {
            val text = clean(row.text())
            if (!text.contains(Regex("(?i)correct\\s*score"))) continue
            val score = Regex("(?i)correct\\s*score\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = firstTwoTeams(row)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "SoccerPunter", teams[0], teams[1], score, row, extractNearestCompetition(row))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** Betshoot: tip cards/rows label the exact-score market explicitly. */
class BetshootExactScoreParser : BaseParser("Betshoot") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (scope in doc.select("article, li, tr, [class*=match], [class*=fixture], [class*=tip], [class*=prediction]")) {
            val text = clean(scope.text())
            if (!text.contains(Regex("(?i)correct\\s*score"))) continue
            val score = Regex("(?i)correct\\s*score\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "Betshoot", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** OLBG: tipster rows expose a market label and the selected score. */
class OLBGExactScoreParser : BaseParser("OLBG") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (scope in doc.select("article, li, tr, [class*=tip], [class*=selection], [class*=match]")) {
            val text = clean(scope.text())
            if (!text.contains(Regex("(?i)correct\\s*score"))) continue
            val score = Regex("(?i)correct\\s*score[^0-9]{0,80}(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "OLBG", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** BettingClosed: current pages expose the exact score beside the fixture. */
class BettingClosedExactScoreParser : BaseParser("BettingClosed") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (scope in doc.select("article, li, tr, [class*=match], [class*=fixture], [class*=prediction], main")) {
            val text = clean(scope.text())
            val marker = Regex("(?i)(?:correct\\s*score|exact\\s*score|score)\\s*[:\\-]?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                ?: continue
            val score = "${marker.groupValues[1]}-${marker.groupValues[2]}"
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "BettingClosed", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** Free Super Tips: the dedicated Correct Score page renders each tip as a
 * fixture card with an explicit score and an adjacent "Home vs Away" label. */
class FreeSuperTipsExactScoreParser : BaseParser("FreeSuperTips") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, li, [class*=tip], [class*=prediction], [class*=match], main")
            .filter { it.text().contains(Regex("(?i)correct\\s+score")) || it.text().contains(Regex("(?i)reason\\s+for\\s+tip")) }
            .sortedBy { it.text().length }
        for (scope in scopes) {
            val text = clean(scope.text())
            if (text.length > 5000) continue
            val vs = Regex("(?is)([^|]{2,90}?)\\s+vs\\s+([^|]{2,90}?)(?=\\s+Reason\\s+for\\s+tip|$)").find(text) ?: continue
            val score = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")
                .find(text.substringBefore(Regex("(?i)Reason\\s+for\\s+tip")))
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val links = scope.select("a[href]").map { clean(it.text()) }
                .filter { it.length in 2..90 && !it.contains(Regex("(?i)full preview|reason for tip|see all|correct score")) }
                .distinct()
            val teams = if (links.size >= 2) links.take(2) else listOf(vs.groupValues[1], vs.groupValues[2])
            val home = cleanProviderTeamNew(teams[0])
            val away = cleanProviderTeamNew(teams[1])
            if (!looksLikeProviderTeamNew(home) || !looksLikeProviderTeamNew(away)) continue
            val item = modelWithMetadataNew("FreeSuperTips", home, away, score, scope, extractNearestCompetition(scope)) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}
