package com.cio.skor.data

import com.cio.skor.data.parsers.Tip724ExactScoreParser
import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceParserV0916Test {
    @Test fun repositoryKeepsExactlyTwentyOneConfiguredSources() {
        assertEquals(21, ScraperRepository().sourceCount)
    }

    @Test fun tip724UsesFixtureScopedCorrectScoreDomAndRejectsNavigationText() {
        val html = """
            <table>
              <tr class="match-row">
                <td><a href="/match/sisaket-united-ratchaburi">Sisaket United</a></td>
                <td><a href="/match/sisaket-united-ratchaburi">Ratchaburi FC</a></td>
                <td>Thai League 1</td>
                <td>Correct Score</td>
                <td>1-1</td>
                <td><a href="/details">Details</a></td>
              </tr>
            </table>
        """
        val parsed = Tip724ExactScoreParser().parse(Jsoup.parse(html))
        assertEquals(1, parsed.size)
        assertEquals("Sisaket United", parsed.single().homeTeam)
        assertEquals("Ratchaburi FC", parsed.single().awayTeam)
        assertEquals("1-1", parsed.single().predictedScore)
    }

    @Test fun sourceSpecificParserNeverEmitsInvalidScore() {
        val html = """
            <div class="match-card">
              <a href="/match/a">Team Alpha</a>
              <a href="/match/a">Team Beta</a>
              <span>Correct Score</span><span>12-00</span>
            </div>
        """
        val parsed = Tip724ExactScoreParser().parse(Jsoup.parse(html))
        assertTrue(parsed.all { ScoreModel.hasRenderablePrediction(it.predictedScore) })
    }
}
