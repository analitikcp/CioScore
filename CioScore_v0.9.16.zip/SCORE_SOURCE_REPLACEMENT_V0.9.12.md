# CioScore 0.9.12 — Score Source Replacement

Replaced non-producing Forebet and FutHead Predictions integrations with Tip724 and AccurateTip.

The new providers publish explicit Correct Score values on their daily public listings.

Active score sources:
1. FP.com
2. PredictZ
3. WinDrawWin
4. DailySports
5. Sports Mole
6. BallPrediction
7. Tip724
8. Correct-Score.net
9. FootballScorePredictor
10. AccurateTip

UI source labels and source catalog were updated accordingly.
