# CioScore v0.9.16 — Source-by-source prediction chain

## What changed

- 21 prediction sources remain configured and visible in the match card.
- Provider-agnostic `GenericExactScoreParser` is not used by the 21-source repository.
- Each source is bound to its own parser class and its own DOM markers.
- FreeSuperTips replaces the duplicate FootballPredictions.com entry so the 21-source pool is domain-unique; it uses the dedicated correct-score page.
- Tip724 now has a provider-specific fallback to its public prediction-history table when the correct-score landing page is empty or changed.
- Parser output is sanitized at the source boundary: exact score format, non-empty distinct teams, and source ownership are required before global matching.
- Team extraction now prefers explicit home/away DOM nodes and only falls back to fixture-local team links; page navigation links are not used as teams.
- HTTP access uses browser-like document headers without attempting to bypass CAPTCHA, JavaScript challenges, or other access controls.
- Source URL fallback routing is explicit per provider; there is no generic HTML parser fallback.
- Diagnostics now retain the actual endpoint that returned the HTML (`fetchedUrl`).
- The UI source registry contains all 21 rows, even when a provider has no prediction for a specific fixture.

## Chain

`SOURCE URL -> provider-specific HTTP/fallback -> raw HTML -> provider-specific DOM scope -> exact score validation -> team validation -> fixture metadata -> global identity/İddaa matching -> UI`

## Important limitation

The build environment cannot perform the Android Gradle build because the Gradle distribution must be downloaded from `services.gradle.org`, which is unavailable in this environment. ZIP integrity and source-level changes were checked, but a successful Gradle compile is not claimed here.
