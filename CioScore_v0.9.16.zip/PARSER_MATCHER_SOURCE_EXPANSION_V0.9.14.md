# CioScore v0.9.14

- Version: 0.9.14 / versionCode 298
- Pipeline: v0.25.51-21-SOURCE-ALIAS-SCHEDULE-V6.2
- Source pool: 21 configured prediction providers.
- New v0.9.14 providers: BetClan, Statarea, FootballPredictions.com, BetMines, SoccerPunter, Betshoot, OLBG, BettingClosed.
- Exact-score success is counted only when a parser emits a score with both teams in the same fixture scope. HTTP 200 alone is not considered a successful prediction.
- Matcher fixes target the reported 2026-10-30 aliases: ISPE/Ispe FC, Hong Linh Ha Tinh/Hong Linh, Hoang Anh Gia Lai/Hoang Anh, Tanjong Pagar United/Tanjong Pagar, Albirex Niigata Singapore FC/Albirex Niigata S.
- Vietnam shortened-name bridges are country-scoped; they are not global fuzzy stemming.
- Existing providers are retained so the scan can compare old vs new sources before removing weak sources.
- Gradle build was not executed in this environment because external Gradle distribution/network access is unavailable; ZIP/static checks were performed.
