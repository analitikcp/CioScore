# CioScore v0.9.13 — Expanded exact-score source pool

Added after live web verification that the providers publish explicit exact-score forecasts:
- Vitibet
- Betimate
- FootyStats

Existing 10-source pool is preserved. New sources are additive for the first live scan; no existing source is deleted before source-level diagnostics show it is consistently inferior.

Validation references:
- Vitibet current football predictions page exposes a Correct Score section and exact-score tips.
- Betimate current predictions page exposes a Correct score column.
- FootyStats current Correct Score page exposes Predicted Scoreline values.

The app diagnostics should judge a source by the complete path HTTP -> parsed exact score -> fixture match -> UI, not HTTP 200 alone.
