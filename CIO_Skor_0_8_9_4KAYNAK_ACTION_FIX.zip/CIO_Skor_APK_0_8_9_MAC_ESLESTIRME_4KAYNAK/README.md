CIO Score 0.8.9 — 4 sources + stronger match grouping

Working source set:
- FP.com
- PredictZ
- WinDrawWin
- SoccerSeer

This package also includes the GitHub Actions workflow:
- .github/workflows/build-apk.yml
- manual Run workflow (workflow_dispatch)
- automatic build on push to main
- Java 17
- Gradle 9.5.1
- debug APK uploaded as a GitHub Actions artifact

The workflow is included because the project previously uploaded only the app source and GitHub showed no workflow runs.
