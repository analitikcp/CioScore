package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.Year
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * SoccerSeer Correct Score board.
 *
 * The current board is a server-rendered list/table:
 * Date/time | league | HOME | predicted score | AWAY | confidence.
 * Unlike the older parser, the score is NOT preceded by a "Prediction:" label.
 */
class SoccerSeerParser : BaseParser("SoccerSeer") {

    private val dateRe = Regex(
        """(?i)\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{1,2}):(\d{2})\b"""
    )
    private val scoreRe = Regex("""(?<!\d)([0-5])\s*[-:]\s*([0-5])(?!\d)""")
    private val month = mapOf(
        "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4,
        "may" to 5, "jun" to 6, "jul" to 7, "aug" to 8,
        "sep" to 9, "oct" to 10, "nov" to 11, "dec" to 12
    )

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val now = LocalDateTime.now()

        // Table rows are the primary target. Cards/articles are a fallback.
        val candidates = LinkedHashSet<Element>()
        doc.select("tr").forEach { candidates.add(it) }
        doc.select(
            "article, li, .match-card, .prediction-card, " +
            "[class*=match], [class*=fixture], [class*=prediction], [class*=game]"
        ).forEach { candidates.add(it) }

        for (el in candidates) {
            val raw = clean(el.text())
            if (raw.length !in 8..600) continue
            if (isFinished(raw)) continue

            val kickoff = parseKickoff(raw) ?: continue
            if (!kickoff.isAfter(now)) continue

            val scoreMatch = scoreRe.find(raw) ?: continue
            val predicted = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"

            val teams = extractTeams(el, raw, scoreMatch)
                ?: continue

            val home = team(teams.first)
            val away = team(teams.second)

            if (!valid(home, away)) continue
            if (isNoise(home) || isNoise(away)) continue

            val model = ScoreModel(home, away, predicted, source)
            out[model.matchKey] = model
        }

        return out.values.take(150)
    }

    private fun extractTeams(
        el: Element,
        raw: String,
        scoreMatch: MatchResult
    ): Pair<String, String>? {

        // 1) Best case: table cells have separate prediction fields.
        val cells = el.select("th, td")
            .map { clean(it.text()) }
            .filter { it.isNotBlank() }

        for (i in cells.indices) {
            if (!scoreRe.containsMatchIn(cells[i])) continue

            // Prediction cell may contain HOME 1-1 AWAY.
            val inCell = extractFromPredictionCell(cells[i], scoreMatch)
            if (inCell != null) return inCell

            // Or date | home | score | away | confidence.
            val before = cells.getOrNull(i - 1)
            val after = cells.getOrNull(i + 1)
            if (before != null && after != null &&
                likelyTeam(before) && likelyTeam(after)) {
                return before to after
            }
        }

        // 2) Look for explicit home/away elements.
        val homeSelectors = listOf(
            ".home", ".home-team", ".homeTeam", ".team-home", ".team1",
            "[class*=home-team]", "[class*=homeTeam]"
        )
        val awaySelectors = listOf(
            ".away", ".away-team", ".awayTeam", ".team-away", ".team2",
            "[class*=away-team]", "[class*=awayTeam]"
        )

        val home = homeSelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { likelyTeam(it) }
        val away = awaySelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { likelyTeam(it) }
        if (home != null && away != null) return home to away

        // 3) If the score is embedded in one text line:
        // remove date/time and confidence, then use the nearest separator.
        val before = raw.substring(0, scoreMatch.range.first)
            .replace(dateRe, " ")
            .replace(Regex("""\b\d{1,2}:\d{2}\b"""), " ")
            .replace(Regex("""\b\d{1,3}%\b"""), " ")
            .replace(Regex("""(?i)\b(?:date|conf\.?|confidence|prediction|pred)\b"""), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val after = raw.substring(scoreMatch.range.last + 1)
            .replace(Regex("""\b\d{1,3}%\b"""), " ")
            .replace(Regex("""(?i)\b(?:date|conf\.?|confidence|prediction|pred)\b.*$"""), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        for (sep in listOf(" v ", " vs ", " - ", " – ", " — ")) {
            val parts = before.split(sep, limit = 2)
            if (parts.size == 2) {
                val h = stripLeagueNoise(parts[1])
                val a = stripLeagueNoise(after)
                if (likelyTeam(h) && likelyTeam(a)) return h to a
            }
        }

        return null
    }

    private fun extractFromPredictionCell(cell: String, scoreMatch: MatchResult): Pair<String, String>? {
        val before = cell.substring(0, scoreMatch.range.first)
            .replace(Regex("""(?i)\b(?:prediction|pred|score|correct score)\b"""), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val after = cell.substring(scoreMatch.range.last + 1)
            .replace(Regex("""\b\d{1,3}%\b"""), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        // The current SoccerSeer board places the score between the two team names.
        if (likelyTeam(before) && likelyTeam(after)) return before to after

        for (sep in listOf(" v ", " vs ", " - ", " – ", " — ")) {
            val parts = cell.split(sep, limit = 2)
            if (parts.size == 2) {
                val h = stripLeagueNoise(parts[0])
                val a = stripLeagueNoise(parts[1])
                if (likelyTeam(h) && likelyTeam(a)) return h to a
            }
        }
        return null
    }

    private fun parseKickoff(text: String): LocalDateTime? {
        val m = dateRe.find(text) ?: return null
        val day = m.groupValues[1].toIntOrNull() ?: return null
        val mon = month[m.groupValues[2].lowercase(Locale.ENGLISH)] ?: return null
        val hour = m.groupValues[3].toIntOrNull() ?: return null
        val minute = m.groupValues[4].toIntOrNull() ?: return null

        val current = LocalDate.now()
        var year = current.year
        // Handle a board crossing New Year.
        if (current.monthValue == 12 && mon == 1) year++
        if (current.monthValue == 1 && mon == 12) year--

        return try {
            LocalDateTime.of(LocalDate.of(year, mon, day), LocalTime.of(hour, minute))
        } catch (_: Exception) {
            null
        }
    }

    private fun stripLeagueNoise(value: String): String =
        value.replace(Regex("""(?i)^(?:[A-Z][A-Za-z .&'-]+League|[A-Z][A-Za-z .&'-]+Cup)\s+"""), "")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', '|')

    private fun likelyTeam(value: String): Boolean {
        val s = stripLeagueNoise(value)
        if (s.length !in 2..70) return false
        if (s.matches(Regex("""^[0-9:%./+ -]+$"""))) return false
        if (dateRe.containsMatchIn(s)) return false
        if (scoreRe.containsMatchIn(s) && s.length < 12) return false
        return !isNoise(s)
    }

    private fun isNoise(value: String): Boolean {
        val v = value.trim()
        if (v.isEmpty()) return true
        val lower = v.lowercase(Locale.ENGLISH)
        return lower in setOf(
            "date", "conf", "confidence", "prediction", "pred", "score",
            "correct score", "leagues", "team search"
        ) || v.matches(Regex("""^[0-9:%./+ -]+$"""))
    }

    private fun isFinished(text: String): Boolean {
        val padded = " ${text.lowercase(Locale.ENGLISH)} "
        val markers = listOf(
            " full time ", " full-time ", " finished ", " final ",
            " ft ", " result:", " result ", " completed ",
            " match ended ", " ended "
        )
        return markers.any { padded.contains(it) }
    }
}
