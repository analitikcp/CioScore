package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * MightyTips Correct Score parser.
 * Uses the literal "Score:" label as the anchor and then walks upward
 * to the smallest DOM block containing that score.
 */
class MightyTipsParser : BaseParser("MightyTips") {

    private val scorePattern = Regex("Score\\s*:\\s*([0-5])\\s*[-:]\\s*([0-5])", RegexOption.IGNORE_CASE)

    override fun parse(doc: Document): List<ScoreModel> {
        val result = LinkedHashMap<String, ScoreModel>()

        for (label in doc.getElementsContainingOwnText("Score:")) {
            val score = scoreFrom(label) ?: continue
            val card = cardFor(label) ?: continue
            val teams = teamsFrom(card, label) ?: continue

            val home = cleanTeam(teams.first)
            val away = cleanTeam(teams.second)
            if (!isTeam(home) || !isTeam(away) || !valid(home, away)) continue

            val model = ScoreModel(home, away, score, source)
            result[model.matchKey] = model
            if (result.size >= 100) break
        }

        return result.values.toList()
    }

    private fun scoreFrom(label: Element): String? {
        var node: Element? = label
        repeat(7) {
            val text = clean(node?.text() ?: "")
            val match = scorePattern.find(text)
            if (match != null) {
                return "${match.groupValues[1]}-${match.groupValues[2]}"
            }
            node = node?.parent()
        }
        return null
    }

    private fun cardFor(label: Element): Element? {
        var node: Element? = label
        repeat(8) {
            node = node?.parent()
            val current = node ?: return@repeat
            val text = clean(current.text())
            if (text.length in 20..800 && scorePattern.containsMatchIn(text)) {
                return current
            }
        }
        return null
    }

    private fun teamsFrom(card: Element, label: Element): Pair<String, String>? {
        // 1) Team logo alt attributes are the cleanest signal when present.
        val alts = card.select("img[alt]")
            .map { cleanTeam(it.attr("alt")) }
            .map { it.replace(Regex("\\s+logo$", RegexOption.IGNORE_CASE), "").trim() }
            .filter { isTeam(it) }
            .distinct()

        if (alts.size >= 2) return alts[0] to alts[1]

        // 2) Explicit team elements.
        val homes = card.select("[class*=home-team], [class*=homeTeam], .home-team")
            .map { cleanTeam(it.text()) }
            .filter { isTeam(it) }
        val aways = card.select("[class*=away-team], [class*=awayTeam], .away-team")
            .map { cleanTeam(it.text()) }
            .filter { isTeam(it) }
        if (homes.isNotEmpty() && aways.isNotEmpty()) {
            return homes.first() to aways.first()
        }

        // 3) Headings/links in the card.
        val labels = card.select("h1,h2,h3,h4,h5,a")
            .map { cleanTeam(it.text()) }
            .filter { isTeam(it) }
            .distinct()
        if (labels.size >= 2) return labels[0] to labels[1]

        // 4) Last-resort visible text: HOME v AWAY or HOME - AWAY.
        val text = clean(card.text())
            .replace(scorePattern, " ")
            .replace(Regex("\\b\\d{1,2}:\\d{2}\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val vs = Regex("^(.{2,80}?)\\s+(?:v|vs)\\s+(.{2,80}?)(?:\\s+(?:Read Prediction|Score|MightyTips).*)?$", RegexOption.IGNORE_CASE)
            .find(text)
        if (vs != null) return vs.groupValues[1].trim() to vs.groupValues[2].trim()

        val dash = Regex("^(.{2,80}?)\\s+[—–-]\\s+(.{2,80}?)(?:\\s+(?:Read Prediction|Score|MightyTips).*)?$", RegexOption.IGNORE_CASE)
            .find(text)
        if (dash != null) return dash.groupValues[1].trim() to dash.groupValues[2].trim()

        return null
    }

    private fun cleanTeam(value: String): String {
        return clean(value)
            .replace(Regex("\\s+logo$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("(?i)\\b(?:score|read prediction|prediction|correct score|odds)\\b.*$"), "")
            .replace(Regex("\\b\\d{1,2}:\\d{2}\\b"), "")
            .trim(' ', '-', '–', '—', ':', '|')
    }

    private fun isTeam(value: String): Boolean {
        val s = cleanTeam(value)
        if (s.length !in 2..70) return false
        if (Regex("^[0-9 .:/-]+$").matches(s)) return false

        val blocked = listOf(
            "MightyTips", "Score", "Read Prediction", "Today", "Tomorrow",
            "Correct Score", "Prediction", "Odds", "Author"
        )
        if (blocked.any { s.equals(it, ignoreCase = true) }) return false

        val authorPattern = Regex(
            "^(Ryan Allan|Nemanja Lalic|Paulius Kundzelevicius|Aleksandar Krstic|Kate Richardson)$",
            RegexOption.IGNORE_CASE
        )
        return !authorPattern.matches(s)
    }
}
