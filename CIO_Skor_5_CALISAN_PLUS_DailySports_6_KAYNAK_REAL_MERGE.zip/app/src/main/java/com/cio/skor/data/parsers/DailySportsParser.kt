package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * DailySports-specific parser.
 * DailySports publishes a prediction card containing a literal
 * "Prediction Correct Score: X:Y" line. We locate that line first,
 * then walk up the DOM to the enclosing game card and extract the two
 * team names from image alt text / links.
 */
class DailySportsParser : BaseParser("DailySports") {
    private val predictionScore = Regex(
        "(?i)Prediction\\s+Correct\\s+Score\\s*:\\s*([0-5])\\s*[:\\-]\\s*([0-5])"
    )

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val markers = doc.getElementsContainingOwnText("Prediction Correct Score")
        for (marker in markers) {
            val markerText = clean(marker.text())
            val scoreMatch = predictionScore.find(markerText) ?: predictionScore.find(marker.parent()?.text() ?: "")
            val score = scoreMatch?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue

            val card = findGameCard(marker) ?: continue
            val teams = extractTeams(card)
            if (teams.size < 2) continue

            val home = cleanTeam(teams[0])
            val away = cleanTeam(teams[1])
            if (!valid(home, away)) continue

            val key = "${home.lowercase()}|${away.lowercase()}|$score"
            out.putIfAbsent(key, ScoreModel(home, away, score, source))
            if (out.size >= 300) break
        }

        return out.values.toList()
    }

    private fun findGameCard(start: Element): Element? {
        var node: Element? = start
        repeat(9) {
            node = node?.parent()
            val n = node ?: return null
            val text = clean(n.text())
            if (text.length in 30..1800 && extractTeams(n).size >= 2) return n
        }
        return null
    }

    private fun extractTeams(card: Element): List<String> {
        // DailySports renders team names in image alt attributes in the game card.
        val imageTeams = card.select("img[alt]")
            .map { it.attr("alt").trim() }
            .filter { looksLikeTeam(it) }
            .distinct()
        if (imageTeams.size >= 2) return imageTeams.take(2)

        // Fallback: team links inside the card.
        val linkTeams = card.select("a")
            .map { clean(it.text()) }
            .filter { looksLikeTeam(it) }
            .distinct()
        if (linkTeams.size >= 2) return linkTeams.take(2)

        return emptyList()
    }

    private fun looksLikeTeam(s: String): Boolean {
        if (s.length !in 2..70) return false
        if (s.matches(Regex("^[0-9 .:+-]+$"))) return false
        val bad = Regex(
            "(?i)^(game|prediction|correct score|time|today|tomorrow|show all|image|1x2|o/u|btts)$"
        )
        return !bad.matches(s)
    }

    private fun cleanTeam(s: String): String {
        return clean(s)
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '|')
    }
}
