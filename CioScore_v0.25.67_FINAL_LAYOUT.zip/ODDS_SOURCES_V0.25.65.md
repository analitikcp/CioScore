# CioScore v0.25.65 — Odds Sources

## AiScore

AiScore has been removed from the **main-screen odds pipeline** and from the main card. The main screen no longer fetches AiScore schedule/odds data and no longer labels opening/closing as AiScore.

## bwin waterfall

1. TipsterArea — restored legacy working source and first priority.
2. bwin Sports API — direct bookmaker fixtures/markets/prices endpoint.
3. SofaScore bookmaker feed — fallback only when the first two sources miss.

The app accepts only a row explicitly identified as `bwin`; no bookmaker substitution is performed.

## Bet365 waterfall

1. Odds Data API Bet365 PreMatch endpoint using the bookmaker fixture id (`FI`).
2. Odds Data API event odds/history using the matched event id.
3. Flashscore Bet365-labelled feed.
4. SofaScore Bet365-labelled feed.
5. GoalLineExpert Bet365 feed.
6. WinComparator Bet365 feed.
7. Local observed Bet365 cache.

Opening/closing values on the main card now come only from the Bet365 provider history bridge, not AiScore.

## Matching hardening

If `providerEventId` was not populated during scan preparation, the odds worker independently rematches the card by canonical home/away team names and kickoff time before calling the Bet365 FI endpoint.
