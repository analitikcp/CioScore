# CioScore v0.25.61 — 5 Odds Pipeline

## Target
Main card must independently populate:
1. Iddaa
2. bwin
3. Bet365 current
4. AiScore Bet365 opening
5. AiScore Bet365 closing

## Current Bet365
Bet365 current no longer depends on AiScore. Pipeline:
- Odds Data API `/v2/event/odds` when a configured provider token + matched fixture exists.
- If that returns no usable pre-match 1X2 line, direct public Bet365 pipeline:
  GoalLineExpert -> SofaScore -> Flashscore -> WinComparator.
- Only after those fail is the legacy AiScore+Flashscore verification fallback attempted.

Odds Data API documents soccer full-time 1X2 as market `1_1` and exposes `home_od`, `draw_od`, `away_od`; the API source is Bet365. See https://www.odds-data-api.com/docs/endpoints/event-odds.

## AiScore history
AiScore is kept independent and is used only for opening/closing history. The parser now tries:
- visible DOM tab + Bet365 text;
- raw HTML around Opening odds / Pre-match odds;
- bookmaker image/data/class attributes containing Bet365;
- raw HTML Bet365 markers.

No averaging or synthetic odds are generated.

## Runtime logs
Look for:
- `MAIN Bet365 API HIT`
- `MAIN Bet365 DIRECT HIT`
- `AiScore Bet365 HIT`
- `AiScore odds page reached but Bet365 1X2 parse failed`
- `Bet365 all sources missed`
