# CioScore v0.25.59 — Compact Main Screen

- Main header, scan button, search field and filter controls compacted to reduce vertical space.
- Diagnosis / HT-FT / MS-X controls placed in one compact horizontal row.
- Fixed bottom footer now contains two small buttons: İDDAA BÜLTENİ and CİO PANEL.
- Per-match İDDAA BÜLTENİNDE AÇ button removed.
- Per-match TAHMİN: MS 1 / MS X / MS 2 label removed.
- Odds order changed to: İddaa → bwin → Bet365 → AiScore Bet365 AÇILIŞ → AiScore Bet365 KAPANIŞ.
- Existing AiScore Bet365 history flow and Cio Panel URL preserved.
