package com.cio.skor.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent provider history keyed by the provider's event id, not team names. */
class ProviderOddsHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("provider_odds_history_v1", Context.MODE_PRIVATE)

    fun save(history: OddsDataApiService.FixtureOddsHistory) {
        val f = history.fixture
        val o = JSONObject().apply {
            put("eventId", f.eventId)
            put("bet365Id", f.bet365FixtureId)
            put("kickoff", f.kickoffEpochSec)
            put("home", f.homeTeam)
            put("away", f.awayTeam)
            put("league", f.leagueName)
            put("opening", history.opening?.toJson())
            put("closing", history.closing?.toJson())
            put("latest", history.latestPreMatch?.toJson())
            put("lines", JSONArray(history.lines.map { it.toJson() }))
        }
        prefs.edit().putString(f.eventId, o.toString()).apply()
    }

    fun load(eventId: String): OddsDataApiService.FixtureOddsHistory? {
        val raw = prefs.getString(eventId, null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            val fixture = OddsDataApiService.ProviderFixture(
                eventId = o.getString("eventId"),
                bet365FixtureId = o.getString("bet365Id"),
                kickoffEpochSec = o.getLong("kickoff"),
                homeTeam = o.getString("home"),
                awayTeam = o.getString("away"),
                leagueName = o.optString("league"),
                timeStatus = 0
            )
            OddsDataApiService.FixtureOddsHistory(
                fixture,
                o.optJSONObject("opening")?.toLine(),
                o.optJSONObject("closing")?.toLine(),
                o.optJSONObject("latest")?.toLine(),
                ArrayList<OddsDataApiService.OddsLine>().apply {
                    val a = o.optJSONArray("lines") ?: JSONArray()
                    for (i in 0 until a.length()) add(a.getJSONObject(i).toLine())
                }
            )
        }.getOrNull()
    }

    private fun OddsDataApiService.OddsLine.toJson() = JSONObject().apply {
        put("t", timestampSec); put("h", home); put("d", draw); put("a", away)
    }

    private fun JSONObject.toLine() = OddsDataApiService.OddsLine(
        timestampSec = optLong("t"),
        home = optString("h"),
        draw = optString("d"),
        away = optString("a")
    )
}
