package com.cio.skor.data

/** UI-safe representation of an AiScore scheduled/live football fixture. */
data class AiScoreMatch(
    val matchId: String,
    val leagueName: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchTime: String,
    val status: String = "SCHEDULED",
    val homeScore: Int? = null,
    val awayScore: Int? = null,
    val matchUrl: String? = null,
    val iddaaMatched: Boolean = false,
    val aiScoreMs1: String? = null,
    val aiScoreMsX: String? = null,
    val aiScoreMs2: String? = null,
    val providerEventId: String? = null,
    val bet365FixtureId: String? = null,
    // Keep the history object non-null at the model boundary. An empty object
    // represents "history not available" and avoids nullable/non-null mismatches
    // when the UI passes the match history to rendering helpers.
    val bet365: Bet365OpeningClosing = Bet365OpeningClosing()
)

data class Bet365OpeningClosing(
    val openingHome: String? = null,
    val openingDraw: String? = null,
    val openingAway: String? = null,
    val latestHome: String? = null,
    val latestDraw: String? = null,
    val latestAway: String? = null,
    val closingHome: String? = null,
    val closingDraw: String? = null,
    val closingAway: String? = null,
    val openingCapturedAt: Long = 0L,
    val latestCapturedAt: Long = 0L,
    val closingCapturedAt: Long = 0L
) {
    fun hasOpening(): Boolean = openingHome != null && openingDraw != null && openingAway != null
    fun hasLatest(): Boolean = latestHome != null && latestDraw != null && latestAway != null
    fun hasClosing(): Boolean = closingHome != null && closingDraw != null && closingAway != null
}
