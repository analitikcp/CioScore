package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.util.Locale

/**
 * Reads the Bet365 1X2 block from AiScore's match odds page.
 * AiScore exposes two tabs on the odds page: Opening odds and Pre-match odds.
 * We keep those two independently so the main card can show opening and
 * latest pre-match/closing without requiring an Odds Data API token.
 */
class AiScoreBet365HistoryService {
    data class Line(val ms1: String, val msX: String, val ms2: String)
    data class History(
        val opening: Line?,
        val closing: Line?,
        val current: Line?,
        val oddsUrl: String?
    )

    private val http = HttpClient()

    suspend fun fetch(matchUrl: String?, homeTeam: String, awayTeam: String): History? =
        withContext(Dispatchers.IO) {
            // The schedule parser can occasionally expose the fixture without a
            // canonical match URL. Fall back to AiScore's public live slug so the
            // match page can still reveal the canonical /match-.../odds URL.
            val sourceUrl = matchUrl?.takeIf { it.isNotBlank() }
                ?: "https://www.aiscore.com/live/football-${slug(homeTeam)}-vs-${slug(awayTeam)}"
            val oddsUrl = resolveOddsUrl(sourceUrl) ?: return@withContext null
            val (code, body) = http.getSource(oddsUrl, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) {
                Log.d(TAG, "AiScore odds miss code=$code $homeTeam - $awayTeam")
                return@withContext null
            }

            val document = Jsoup.parse(body, oddsUrl)
            val visible = document.text().replace(Regex("\\s+"), " ").trim()
            if (!containsTeam(visible, homeTeam) || !containsTeam(visible, awayTeam)) return@withContext null

            // AiScore's bookmaker logo can be rendered as an image/data attribute,
            // so Document.text() does not always contain the literal "Bet365".
            // Parse three independent representations: visible DOM, bookmaker
            // logo/attribute containers, and raw HTML around Bet365 markers.
            val opening = parseTab(document, visible, "Opening odds")
                ?: parseRawTab(body, "Opening odds")
            val prematch = parseTab(document, visible, "Pre-match odds")
                ?: parseRawTab(body, "Pre-match odds")
            val all = parseBet365Block(visible)
                .ifEmpty { parseBet365Dom(document) }
                .ifEmpty { parseRawBet365(body) }

            // If AiScore exposes both tabs but the bookmaker label is not attached
            // to the rendered text, the raw odds page still presents complete 1X2
            // triples. Prefer the tab-specific values, then the best complete
            // Bet365-labelled triple. Never synthesize/average prices.
            val open = opening ?: all.firstOrNull()
            val current = prematch ?: all.lastOrNull()
            val close = current ?: open
            if (open == null && current == null) {
                Log.d(TAG, "AiScore odds page reached but Bet365 1X2 parse failed $homeTeam - $awayTeam url=$oddsUrl")
                return@withContext null
            }

            Log.d(TAG, "AiScore Bet365 HIT $homeTeam - $awayTeam opening=${fmt(open)} closing=${fmt(close)} url=$oddsUrl")
            History(open, close, current ?: close, oddsUrl)
        }

    private fun resolveOddsUrl(matchUrl: String): String? {
        val normalized = matchUrl.trim()
        if (normalized.contains("/odds")) return normalized

        // A live page normally links to the canonical /match-.../.../odds page.
        val (code, body) = http.getSource(normalized, "https://www.aiscore.com/")
        if (code in 200..299 && !body.isNullOrBlank()) {
            val doc = Jsoup.parse(body, normalized)
            val link = doc.select("a[href*='/match-'][href*='/odds'], a[href*='/odds']")
                .mapNotNull { it.absUrl("href").ifBlank { it.attr("href") } }
                .firstOrNull { it.contains("/match-") && it.contains("/odds") }
            if (!link.isNullOrBlank()) return link

            // Some AiScore pages expose the canonical match URL in JSON/script text.
            val regex = Regex("https?://(?:www\\.|m\\.)?aiscore\\.com/match-[a-z0-9-]+/[a-z0-9]+/odds", RegexOption.IGNORE_CASE)
            regex.find(body)?.value?.let { return it }
        }

        // If the caller supplied a canonical /match-... URL but the odds link
        // was not present in the fetched HTML, normalize away non-odds tabs.
        val marker = normalized.indexOf("/match-")
        if (marker >= 0) {
            val base = normalized.substring(marker)
                .substringBefore("?")
                .trimEnd('/')
                .replace(Regex("/(h2h|prediction|lineups|stats|live)$", RegexOption.IGNORE_CASE), "")
            return if (base.endsWith("/odds")) "https://www.aiscore.com$base"
            else "https://www.aiscore.com$base/odds"
        }
        return null
    }

    private fun slug(value: String): String = value.lowercase(Locale.ROOT)
        .replace("&", " and ")
        .replace(Regex("[^a-z0-9]+"), "-")
        .trim('-')

    private fun parseTab(doc: org.jsoup.nodes.Document, visible: String, tabName: String): Line? {
        // Prefer a DOM block containing both the tab label and Bet365. If the
        // page is JS-hydrated and the values are embedded in script JSON, the
        // fallback scans the text around the tab marker.
        val candidates = doc.select("body *").asSequence()
            .filter { el ->
                val t = el.text().replace(Regex("\\s+"), " ").trim()
                t.contains(tabName, true) && t.contains("Bet365", true)
            }
            .sortedBy { it.text().length }
            .toList()
        for (el in candidates) {
            val line = parseBet365Block(el.text().replace(Regex("\\s+"), " ").trim()).firstOrNull()
            if (line != null) return line
        }

        val idx = visible.indexOf(tabName, ignoreCase = true)
        if (idx >= 0) {
            val window = visible.substring(idx, minOf(visible.length, idx + 2200))
            return parseBet365Block(window).firstOrNull()
        }
        return null
    }

    private fun parseBet365Block(text: String): List<Line> {
        val lower = text.lowercase(Locale.ROOT)
        val start = lower.indexOf("bet365")
        if (start < 0) return emptyList()
        val endCandidates = listOf(
            "1xbet", "bet-at-home", "bwin", "unibet", "betfair", "pinnacle"
        ).mapNotNull { marker -> lower.indexOf(marker, start + 6).takeIf { it > start } }
        val end = endCandidates.minOrNull() ?: minOf(text.length, start + 2400)
        val block = text.substring(start, end)
        val nums = Regex("(?<![0-9])([1-9][0-9]?\\.[0-9]{1,2})(?![0-9])")
            .findAll(block)
            .map { it.groupValues[1] }
            .filter { it.toDoubleOrNull()?.let { n -> n > 1.0 && n <= 50.0 } == true }
            .toList()
        if (nums.size < 3) return emptyList()
        return nums.chunked(3).mapNotNull { triple ->
            if (triple.size == 3) Line(triple[0], triple[1], triple[2]) else null
        }
    }

    private fun parseRawTab(body: String, tabName: String): Line? {
        val lower = body.lowercase(Locale.ROOT)
        val tab = lower.indexOf(tabName.lowercase(Locale.ROOT))
        if (tab < 0) return null
        val window = body.substring(tab, minOf(body.length, tab + 9000))
        return parseRawBet365(window).firstOrNull()
    }

    private fun parseBet365Dom(doc: org.jsoup.nodes.Document): List<Line> {
        val candidates = doc.select(
            "img[alt*=Bet365 i], img[title*=Bet365 i], [data-provider*=bet365 i], [data-bookmaker*=bet365 i], [class*=bet365 i]"
        )
        for (marker in candidates) {
            var current: org.jsoup.nodes.Element? = marker
            repeat(5) {
                current = current?.parent()
                val text = current?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
                val line = parseDecimalTriples(text).firstOrNull()
                if (line != null) return listOf(line)
            }
        }
        return emptyList()
    }

    private fun parseRawBet365(body: String): List<Line> {
        val lower = body.lowercase(Locale.ROOT)
        val out = mutableListOf<Line>()
        var from = 0
        while (true) {
            val idx = lower.indexOf("bet365", from)
            if (idx < 0) break
            val window = body.substring(idx, minOf(body.length, idx + 5000))
                .replace(Regex("<[^>]+>"), " ")
                .replace("&quot;", " ")
                .replace("&amp;", "&")
                .replace(Regex("\\s+"), " ")
            out += parseDecimalTriples(window)
            from = idx + 6
            if (out.size >= 8) break
        }
        return out.distinctBy { "${it.ms1}|${it.msX}|${it.ms2}" }
    }

    private fun parseDecimalTriples(text: String): List<Line> {
        val nums = Regex("(?<![0-9])([1-9][0-9]?\\.[0-9]{1,2})(?![0-9])")
            .findAll(text)
            .map { it.groupValues[1] }
            .filter { it.toDoubleOrNull()?.let { n -> n > 1.0 && n <= 50.0 } == true }
            .toList()
        if (nums.size < 3) return emptyList()
        return nums.windowed(3, 3).map { Line(it[0], it[1], it[2]) }
    }

    private fun containsTeam(text: String, wanted: String): Boolean {
        val t = normalize(text)
        val w = normalize(wanted)
        if (w.isBlank()) return false
        if (t.contains(w)) return true
        val tokens = w.split(' ').filter { it.length >= 4 }
        return tokens.isNotEmpty() && tokens.count { t.contains(it) } >= minOf(2, tokens.size)
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun fmt(line: Line?): String = line?.let { "${it.ms1}/${it.msX}/${it.ms2}" } ?: "-"

    companion object { private const val TAG = "CioAiScoreBet365History" }
}
