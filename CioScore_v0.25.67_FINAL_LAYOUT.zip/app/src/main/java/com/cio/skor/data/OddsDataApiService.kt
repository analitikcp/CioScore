package com.cio.skor.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Real Bet365 data bridge backed by Odds Data API.
 *
 * Odds Data API exposes an Events id and bet365_id (FI). We keep both and
 * fetch odds by event_id so the app never guesses a Bet365 page URL.
 */
class OddsDataApiService(context: Context) {
    companion object {
        private const val TAG = "CioOddsDataApi"
        private const val BASE_URL = "https://api.odds-data-api.com"
        private const val PREFS = "odds_data_api_v1"
        private const val TOKEN_KEY = "token"
        private const val SPORT_SOCCER = "1"
        private const val MARKET_1X2 = "1_1"
        private const val TIME_TOLERANCE_SECONDS = 20 * 60L
    }

    data class ProviderFixture(
        val eventId: String,
        val bet365FixtureId: String,
        val kickoffEpochSec: Long,
        val homeTeam: String,
        val awayTeam: String,
        val leagueName: String,
        val timeStatus: Int
    )

    data class OddsLine(
        val timestampSec: Long,
        val home: String,
        val draw: String,
        val away: String
    )

    data class FixtureOddsHistory(
        val fixture: ProviderFixture,
        val opening: OddsLine?,
        val closing: OddsLine?,
        val latestPreMatch: OddsLine?,
        val lines: List<OddsLine>
    )

    data class Result<T>(
        val value: T? = null,
        val error: String? = null
    )

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    fun getToken(): String = prefs.getString(TOKEN_KEY, "").orEmpty()

    fun setToken(token: String) {
        prefs.edit().putString(TOKEN_KEY, token.trim()).apply()
    }

    fun clearToken() {
        prefs.edit().remove(TOKEN_KEY).apply()
    }

    suspend fun findFixturesForDate(date: LocalDate): Result<List<ProviderFixture>> =
        withContext(Dispatchers.IO) {
            val token = getToken()
            if (token.isBlank()) return@withContext Result(error = "API token ayarlanmadı")

            val day = date.format(DateTimeFormatter.BASIC_ISO_DATE)
            val all = LinkedHashMap<String, ProviderFixture>()
            val endpoints = listOf("/v3/events/upcoming", "/v3/events/inplay", "/v3/events/ended")

            for (endpoint in endpoints) {
                var page = 1
                while (page <= 100) {
                    val response = getJson(endpoint) {
                        addQueryParameter("sport_id", SPORT_SOCCER)
                        if (endpoint != "/v3/events/inplay") addQueryParameter("day", day)
                        addQueryParameter("skip_esports", "true")
                        addQueryParameter("page", page.toString())
                        addQueryParameter("token", token)
                    }
                    val error = response.error
                    if (error != null) {
                        if (all.isEmpty()) return@withContext Result(error = error)
                        break
                    }
                    val json = response.value ?: break
                    if (json.optInt("success", 0) != 1) {
                        val apiError = json.optString("error").ifBlank { "API başarısız" }
                        if (all.isEmpty()) return@withContext Result(error = apiError)
                        break
                    }
                    val rows = json.optJSONArray("results") ?: JSONArray()
                    if (rows.length() == 0) break
                    for (i in 0 until rows.length()) {
                        parseFixture(rows.optJSONObject(i))?.let { all[it.eventId] = it }
                    }
                    val total = json.optJSONObject("pager")?.optInt("total", 0) ?: 0
                    if (rows.length() < 50 || page * 50 >= total) break
                    page++
                }
            }

            Result(all.values.toList())
        }

    fun matchFixture(
        homeTeam: String,
        awayTeam: String,
        kickoffEpochSec: Long,
        fixtures: List<ProviderFixture>
    ): ProviderFixture? =
        fixtures.asSequence()
            .filter {
                TeamAliasCanonicalizer.canonical(it.homeTeam) ==
                    TeamAliasCanonicalizer.canonical(homeTeam) &&
                TeamAliasCanonicalizer.canonical(it.awayTeam) ==
                    TeamAliasCanonicalizer.canonical(awayTeam)
            }
            .minByOrNull { kotlin.math.abs(it.kickoffEpochSec - kickoffEpochSec) }
            ?.takeIf {
                kotlin.math.abs(it.kickoffEpochSec - kickoffEpochSec) <=
                    TIME_TOLERANCE_SECONDS
            }

    /** Direct Bet365 pre-match endpoint keyed by the Bet365 fixture id (FI). */
    suspend fun fetchBet365Prematch(fixture: ProviderFixture): Result<OddsLine> =
        withContext(Dispatchers.IO) {
            val token = getToken()
            if (token.isBlank()) return@withContext Result(error = "API token ayarlanmadı")

            val response = getJson("/v4/bet365/prematch") {
                addQueryParameter("FI", fixture.bet365FixtureId)
                addQueryParameter("token", token)
            }
            val json = response.value ?: return@withContext Result(error = response.error ?: "Bet365 pre-match yanıtı boş")
            if (json.optInt("success", 0) != 1) {
                return@withContext Result(error = json.optString("error").ifBlank { "Bet365 pre-match başarısız" })
            }

            val results = json.optJSONObject("results") ?: return@withContext Result(error = "Bet365 pre-match sonucu yok")
            val main = results.optJSONObject("main") ?: return@withContext Result(error = "Bet365 main market yok")
            val sp = main.optJSONObject("sp") ?: return@withContext Result(error = "Bet365 main.sp yok")
            val fullTime = sp.optJSONObject("full_time_result") ?: return@withContext Result(error = "Bet365 full_time_result yok")
            val odds = fullTime.optJSONArray("odds") ?: return@withContext Result(error = "Bet365 1X2 odds yok")

            var home: String? = null
            var draw: String? = null
            var away: String? = null
            for (i in 0 until odds.length()) {
                val row = odds.optJSONObject(i) ?: continue
                val value = row.optString("odds").trim()
                if (value.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } != true) continue
                when (row.optString("header").trim().lowercase(Locale.US)) {
                    "1", "home" -> home = value
                    "x", "draw" -> draw = value
                    "2", "away" -> away = value
                }
            }
            if (home.isNullOrBlank() || draw.isNullOrBlank() || away.isNullOrBlank()) {
                return@withContext Result(error = "Bet365 full_time_result 1X2 eksik")
            }
            val ts = main.optLong("updated_at", System.currentTimeMillis() / 1000L)
            Result(OddsLine(ts, home!!, draw!!, away!!))
        }

    suspend fun fetchOddsHistory(fixture: ProviderFixture): Result<FixtureOddsHistory> =
        withContext(Dispatchers.IO) {
            val token = getToken()
            if (token.isBlank()) return@withContext Result(error = "API token ayarlanmadı")

            val response = getJson("/v2/event/odds") {
                addQueryParameter("event_id", fixture.eventId)
                addQueryParameter("odds_market", "1")
                addQueryParameter("token", token)
            }
            val json = response.value ?: return@withContext Result(error = response.error ?: "Odds API yanıtı boş")
            if (json.optInt("success", 0) != 1) {
                return@withContext Result(error = json.optString("error").ifBlank { "Odds API başarısız" })
            }
            val results = json.optJSONObject("results") ?: return@withContext Result(error = "Odds sonucu yok")
            val odds = results.optJSONObject("odds")?.optJSONArray(MARKET_1X2) ?: JSONArray()
            val lines = mutableListOf<OddsLine>()
            for (i in 0 until odds.length()) {
                val row = odds.optJSONObject(i) ?: continue
                val h = row.optString("home_od").trim()
                val d = row.optString("draw_od").trim()
                val a = row.optString("away_od").trim()
                val ts = row.optString("add_time").toLongOrNull() ?: continue
                if (h.isBlank() || d.isBlank() || a.isBlank()) continue
                lines += OddsLine(ts, h, d, a)
            }
            if (lines.isEmpty()) return@withContext Result(FixtureOddsHistory(fixture, null, null, null, emptyList()))

            val chronological = lines.sortedBy { it.timestampSec }
            val preMatch = chronological.filter { it.timestampSec <= fixture.kickoffEpochSec }
            val opening = preMatch.firstOrNull()
            val closing = preMatch.lastOrNull()
            val latest = preMatch.lastOrNull()

            Log.d(TAG, "fixture=${fixture.eventId} FI=${fixture.bet365FixtureId} lines=${chronological.size} opening=${opening?.timestampSec} closing=${closing?.timestampSec}")
            Result(FixtureOddsHistory(fixture, opening, closing, latest, chronological))
        }

    private fun parseFixture(row: JSONObject?): ProviderFixture? {
        if (row == null) return null
        val id = row.optString("id").trim()
        val fi = row.optString("bet365_id").trim()
        val time = row.optString("time").toLongOrNull() ?: return null
        val home = row.optJSONObject("home")?.optString("name").orEmpty().trim()
        val away = row.optJSONObject("away")?.optString("name").orEmpty().trim()
        if (id.isBlank() || fi.isBlank() || home.isBlank() || away.isBlank()) return null
        val league = row.optJSONObject("league")?.optString("name").orEmpty()
        return ProviderFixture(id, fi, time, home, away, league, row.optInt("time_status", 0))
    }

    private fun getJson(path: String, params: okhttp3.HttpUrl.Builder.() -> Unit): Result<JSONObject> {
        val urlBuilder = "$BASE_URL$path".toHttpUrl().newBuilder()
        params(urlBuilder)
        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("Accept", "application/json")
            .header("User-Agent", "CioScore/0.25.49")
            .build()
        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val apiError = runCatching { JSONObject(body).optString("error") }.getOrNull().orEmpty()
                    return Result(error = apiError.ifBlank { "HTTP ${response.code}" })
                }
                Result(value = JSONObject(body))
            }
        } catch (e: Exception) {
            Result(error = "${e.javaClass.simpleName}: ${e.localizedMessage ?: "network error"}")
        }
    }
}
