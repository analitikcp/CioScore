package com.cio.skor.data

import android.content.Context
import org.json.JSONObject
import java.util.Locale

/**
 * Local observation store for Bet365 1X2.
 *
 * We deliberately call these values "kaydedilen açılış" and "kapanış".
 * The app can only know the true market opening if it was running/capturing
 * from that point. At kickoff, the last pre-kickoff observation is frozen as
 * closing. Missing history is never fabricated.
 */
class Bet365OddsHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("bet365_odds_history_v1", Context.MODE_PRIVATE)

    fun record(homeTeam: String, awayTeam: String, matchTimestamp: Long, home: String, draw: String, away: String): Bet365OpeningClosing {
        val key = key(homeTeam, awayTeam, matchTimestamp)
        val now = System.currentTimeMillis()
        val current = read(key)
        val opening = if (current?.hasOpening() == true) current else Bet365OpeningClosing(
            openingHome = home, openingDraw = draw, openingAway = away,
            latestHome = home, latestDraw = draw, latestAway = away,
            openingCapturedAt = now, latestCapturedAt = now
        )
        val updated = opening.copy(
            latestHome = home,
            latestDraw = draw,
            latestAway = away,
            latestCapturedAt = now
        )
        write(key, updated)
        return updated
    }

    fun freezeClosing(homeTeam: String, awayTeam: String, matchTimestamp: Long): Bet365OpeningClosing? {
        val key = key(homeTeam, awayTeam, matchTimestamp)
        val current = read(key) ?: return null
        if (!current.hasLatest()) return current
        if (current.hasClosing()) return current
        val frozen = current.copy(
            closingHome = current.latestHome,
            closingDraw = current.latestDraw,
            closingAway = current.latestAway,
            closingCapturedAt = current.latestCapturedAt
        )
        write(key, frozen)
        return frozen
    }

    fun get(homeTeam: String, awayTeam: String, matchTimestamp: Long): Bet365OpeningClosing? =
        read(key(homeTeam, awayTeam, matchTimestamp))

    private fun key(homeTeam: String, awayTeam: String, matchTimestamp: Long): String =
        "${TeamAliasCanonicalizer.canonical(homeTeam)}::${TeamAliasCanonicalizer.canonical(awayTeam)}::$matchTimestamp"

    private fun read(key: String): Bet365OpeningClosing? {
        val raw = prefs.getString(key, null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            Bet365OpeningClosing(
                openingHome = o.optString("oh").ifBlank { null },
                openingDraw = o.optString("od").ifBlank { null },
                openingAway = o.optString("oa").ifBlank { null },
                latestHome = o.optString("lh").ifBlank { null },
                latestDraw = o.optString("ld").ifBlank { null },
                latestAway = o.optString("la").ifBlank { null },
                closingHome = o.optString("ch").ifBlank { null },
                closingDraw = o.optString("cd").ifBlank { null },
                closingAway = o.optString("ca").ifBlank { null },
                openingCapturedAt = o.optLong("ot", 0L),
                latestCapturedAt = o.optLong("lt", 0L),
                closingCapturedAt = o.optLong("ct", 0L)
            )
        }.getOrNull()
    }

    private fun write(key: String, value: Bet365OpeningClosing) {
        val o = JSONObject().apply {
            put("oh", value.openingHome ?: "")
            put("od", value.openingDraw ?: "")
            put("oa", value.openingAway ?: "")
            put("lh", value.latestHome ?: "")
            put("ld", value.latestDraw ?: "")
            put("la", value.latestAway ?: "")
            put("ch", value.closingHome ?: "")
            put("cd", value.closingDraw ?: "")
            put("ca", value.closingAway ?: "")
            put("ot", value.openingCapturedAt)
            put("lt", value.latestCapturedAt)
            put("ct", value.closingCapturedAt)
        }
        prefs.edit().putString(key, o.toString()).apply()
    }
}
