package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Direct bwin Sports API fallback.
 *
 * bwin documents a public fixtures endpoint that returns fixtures together with
 * markets, options and prices. We use it only for bwin 1X2 and never substitute
 * another bookmaker's price.
 */
class BwinSportsApiService {
    data class Odds(val ms1: String, val msX: String, val ms2: String)

    private data class CacheEntry(val expiresAt: Long, val fixtures: List<JSONObject>)

    private val http = HttpClient()
    private val cache = ConcurrentHashMap<String, CacheEntry>()

    suspend fun fetch(homeTeam: String, awayTeam: String): Odds? {
        val wantedHome = normalize(homeTeam)
        val wantedAway = normalize(awayTeam)
        if (wantedHome.isBlank() || wantedAway.isBlank()) return null

        val hosts = listOf(
            "https://sportsapi.bwin.com",
            "https://sportsapi.bwin.es",
            "https://sportsapi.bwin.pt"
        )
        val countries = listOf("tr", "gb", "de", "es", "pt")

        for (host in hosts) {
            for (country in countries) {
                val key = "$host|$country"
                val fixtures = loadFixtures(host, country, key)
                if (fixtures.isEmpty()) continue

                for (fixture in fixtures) {
                    val participants = fixture.optJSONArray("participants") ?: continue
                    val names = participantNames(participants)
                    val home = names.firstOrNull()
                    val away = names.drop(1).firstOrNull()
                    if (home == null || away == null) continue
                    if (!sameTeam(home, wantedHome) || !sameTeam(away, wantedAway)) continue

                    parseOneXTwo(fixture)?.let {
                        Log.d(TAG, "BWIN DIRECT API HIT $homeTeam - $awayTeam $it host=$host country=$country")
                        return it
                    }
                }
            }
        }
        Log.d(TAG, "BWIN DIRECT API MISS $homeTeam - $awayTeam")
        return null
    }

    private fun loadFixtures(host: String, country: String, key: String): List<JSONObject> {
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { it.expiresAt > now }?.let { return it.fixtures }

        val url = "$host/offer/api/4/$country/fixtures" +
            "?language=en&isInPlay=false&onlyMainMarkets=true&marketsFilterCriteria=Visible"
        val (code, body) = http.getSource(url, "$host/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()

        val root = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val fixtures = extractFixtures(root)
        if (fixtures.isNotEmpty()) {
            cache[key] = CacheEntry(now + CACHE_TTL_MS, fixtures)
        }
        return fixtures
    }

    private fun extractFixtures(root: JSONObject): List<JSONObject> {
        val direct = root.optJSONArray("items")
        if (direct != null) return directObjects(direct)
        val results = root.optJSONObject("results")
        val nested = results?.optJSONArray("items")
        if (nested != null) return directObjects(nested)
        return emptyList()
    }

    private fun directObjects(array: JSONArray): List<JSONObject> = buildList {
        for (i in 0 until array.length()) array.optJSONObject(i)?.let { add(it) }
    }

    private fun participantNames(participants: JSONArray): List<String> {
        val result = mutableListOf<String>()
        for (i in 0 until participants.length()) {
            val p = participants.optJSONObject(i) ?: continue
            val names = p.optJSONArray("name") ?: continue
            var chosen = ""
            for (j in 0 until names.length()) {
                val n = names.optJSONObject(j) ?: continue
                chosen = n.optString("text").trim().ifBlank { n.optString("shortText").trim() }
                if (chosen.isNotBlank()) break
            }
            if (chosen.isNotBlank()) result += chosen
        }
        return result
    }

    private fun parseOneXTwo(fixture: JSONObject): Odds? {
        val markets = fixture.optJSONArray("markets") ?: return null
        for (i in 0 until markets.length()) {
            val market = markets.optJSONObject(i) ?: continue
            if (!isResultMarket(market)) continue
            val options = market.optJSONArray("options") ?: continue
            var home: String? = null
            var draw: String? = null
            var away: String? = null

            for (j in 0 until options.length()) {
                val option = options.optJSONObject(j) ?: continue
                val name = optionName(option).lowercase(Locale.US)
                val odds = optionOdds(option) ?: continue
                when {
                    name == "draw" || name == "x" || name.contains("draw") -> draw = odds
                    name == "home" || name == "1" -> home = odds
                    name == "away" || name == "2" -> away = odds
                }
            }
            if (home != null && draw != null && away != null) return Odds(home, draw, away)
        }
        return null
    }

    private fun isResultMarket(market: JSONObject): Boolean {
        val hay = listOf(
            market.optString("marketType"),
            market.optString("happening"),
            market.optString("period"),
            marketName(market)
        ).joinToString(" ").lowercase(Locale.US)
        return hay.contains("match result") || hay.contains("full time result") ||
            hay.contains("1x2") || hay.contains("3 way") || hay.contains("3-way")
    }

    private fun marketName(market: JSONObject): String {
        val names = market.optJSONArray("name") ?: return ""
        for (i in 0 until names.length()) {
            val n = names.optJSONObject(i) ?: continue
            val value = n.optString("text").trim().ifBlank { n.optString("shortText").trim() }
            if (value.isNotBlank()) return value
        }
        return ""
    }

    private fun optionName(option: JSONObject): String {
        val names = option.optJSONArray("name") ?: return ""
        for (i in 0 until names.length()) {
            val n = names.optJSONObject(i) ?: continue
            val value = n.optString("text").trim().ifBlank { n.optString("shortText").trim() }
            if (value.isNotBlank()) return value
        }
        return ""
    }

    private fun optionOdds(option: JSONObject): String? {
        val prices = option.optJSONArray("price") ?: return null
        for (i in 0 until prices.length()) {
            val price = prices.optJSONObject(i) ?: continue
            val value = price.optString("odds").trim()
            val number = value.toDoubleOrNull() ?: continue
            if (number > 1.0 && number <= 1000.0) return String.format(Locale.US, "%.2f", number)
        }
        return null
    }

    private fun sameTeam(actual: String, wanted: String): Boolean {
        val a = normalize(actual)
        if (a == wanted) return true
        val at = a.split(' ').filter { it.length >= 3 }
        val wt = wanted.split(' ').filter { it.length >= 3 }
        if (at.isEmpty() || wt.isEmpty()) return false
        val overlap = wt.count { token -> at.any { it == token || it.contains(token) || token.contains(it) } }
        return overlap >= maxOf(1, kotlin.math.ceil(wt.size * 0.75).toInt())
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private const val TAG = "CioBwinSportsApi"
        private const val CACHE_TTL_MS = 2 * 60 * 1000L
    }
}
