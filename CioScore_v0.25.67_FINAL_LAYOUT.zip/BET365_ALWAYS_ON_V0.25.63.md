# Bet365 Always-On Main Card — v0.25.63

The main card treats Bet365 1X2 as a mandatory data field.

Waterfall, in order:
1. Odds Data API event odds (when a token and fixture match exist).
2. Independent Bet365-labelled public feed adapters (GoalLineExpert/SofaScore/Flashscore/WinComparator).
3. Existing AiScore + Flashscore verification fallback.
4. AiScore `/odds` page's Bet365-labelled current pre-match quote.
5. Previously observed local Bet365 quote, if available.

No odds are synthesized, averaged, or copied from another bookmaker. Every successful
quote is persisted locally so a transient network miss does not blank the card.
