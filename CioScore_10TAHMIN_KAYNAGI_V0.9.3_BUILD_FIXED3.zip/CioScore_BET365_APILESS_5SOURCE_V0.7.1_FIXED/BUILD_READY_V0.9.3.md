# CioScore V0.9.3 — Build Ready

This package is based on V0.9.3_BUILD_FIX.

## Confirmed source difference from V0.9.2
Only one source file differs:
`app/src/main/java/com/cio/skor/XCandidateActivity.kt`

V0.9.3 changes the adapter constructor seed from `emptyList()` to
`emptyList<MatchGroup>()`, removing the Kotlin type-inference ambiguity seen
at the ScoreAdapter construction site.

## CI workflow repair
The bundled GitHub Actions workflow contained stale hard-coded guards from an
older 0.25.x/4-source build. Those guards rejected the current 10-source tree
and current app metadata before Gradle compilation. The guards were aligned
with the actual source tree and current metadata; no application logic was
changed.

A full Gradle build could not be executed in this offline environment because
the Gradle 9.5.0 distribution is not locally cached.
