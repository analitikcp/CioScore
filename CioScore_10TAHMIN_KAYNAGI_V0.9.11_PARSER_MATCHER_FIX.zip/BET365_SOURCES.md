# CioScore Bet365 API'siz kaynak zinciri

WBookie ve OddsPapi bu sürümde kullanılmaz. Bet365 1X2 oranları aşağıdaki sırayla aranır:

1. **MoviOdds** — birincil kaynak; API anahtarı kullanılmaz.
2. **7M Sport** — ikinci kaynak; Bet365 1/X/2 satırı aranır.
3. **ChekiOdds** — üçüncü kaynak; tarih sayfasındaki Bet365 satırı aranır.
4. **SingleBet** — dördüncü kaynak; bookmaker bazlı Bet365 satırı aranır.
5. **SimplyOdds** — beşinci kaynak; açıkça Bet365 etiketli 1/X/2 fiyatları aranır.

Bir kaynak tam 1/X/2 üçlüsünü bulursa sonraki kaynaklar çağrılmaz.
