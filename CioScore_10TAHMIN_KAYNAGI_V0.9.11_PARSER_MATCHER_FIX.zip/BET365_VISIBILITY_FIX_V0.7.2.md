# Bet365 visibility compile fix V0.7.2

Fixed Kotlin visibility errors in the four API-less Bet365 fallback services.

The parser methods return `Map<String, Row>`. `Row` is now package-visible (`data class Row`) rather than private, so even if Gradle/Kotlin treats the parser as `internal`, the return type is not less visible than the function.

Files:
- MoviOddsBet365Service.kt
- SevenMSportBet365Service.kt
- SimplyOddsBet365Service.kt
- SingleBetBet365Service.kt

No bwin source was changed.
