# CioScore v0.25.67

- BUGÜNÜ TARA moved to the fixed bottom action bar.
- Bottom bar order: TARA | İDDAA BÜLTENİNE GİT | CİO PANEL.
- Search remains in the upper header.
- HT/FT button text is HT/FT.
- MS X button text is MS X.
- No other UI or odds-source changes.
