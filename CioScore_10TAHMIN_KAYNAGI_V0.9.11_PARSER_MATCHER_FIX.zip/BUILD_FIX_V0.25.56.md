# CioScore v0.25.56 — OddsDataApiService build fix

- Rewrote `matchFixture()` as a Kotlin expression-body function.
- Removed the block-body/return path that produced CI error `Missing return statement` at `OddsDataApiService.kt:140`.
- Preserved the same canonical team matching and kickoff tolerance behavior.
- Retained CP icon and Cio Panel.
