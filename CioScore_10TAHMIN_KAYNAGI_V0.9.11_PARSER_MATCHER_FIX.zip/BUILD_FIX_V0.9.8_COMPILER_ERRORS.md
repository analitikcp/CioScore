# CioScore 0.9.9 — Kotlin derleme zinciri düzeltmesi

Bu sürüm 0.9.8 CI derlemesinde devam eden Kotlin hatalarını düzeltir.

## Düzeltilenler
- `MainActivity.kt`: `officialMatches` kapsam dışı referansı `officialInBulletinWindow` olarak düzeltildi.
- `MainActivity.kt`: `withContext(Dispatchers.Default)` sonuçları açıkça `List<MatchGroup>` olarak tiplendirildi; Kotlin type-inference zinciri kırıldı.
- `MainActivity.kt`: resmi bülten kartı listesi açıkça `List<MatchGroup>` olarak tiplendirildi.
- `AdditionalExactScoreParsers.kt`: `FixtureMetadata` doğrudan `BaseParser.FixtureMetadata` olarak nitelendirildi; nested-type çözümleme belirsizliği kaldırıldı.
- Sürüm: 0.9.9 / versionCode 294.

## Derleme notu
Kaynak tarafındaki hatalar düzeltildi. Bu çalışma ortamında Gradle dağıtımı ağ/DNS nedeniyle indirilemediğinden burada gerçek APK derlemesi yapılamadı.
