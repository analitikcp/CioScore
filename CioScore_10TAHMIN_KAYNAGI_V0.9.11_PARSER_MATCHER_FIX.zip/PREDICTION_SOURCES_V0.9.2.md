# CioScore V0.9.2 — 10 exact-score sources

Replaced the six unreliable secondary prediction providers with six providers that publish explicit correct-score predictions in public HTML.

1. FP.com
2. PredictZ
3. WinDrawWin
4. DailySports
5. Sports Mole
6. BallPrediction
7. Forebet
8. Correct-Score.net
9. FootballScorePredictor
10. FutHead Predictions

## Parser rule
Each new provider has a dedicated parser. A score is accepted only when it is found in that provider's fixture/prediction structure; no shared broad prediction regex is used.

## Gender safety
Team identity continues to preserve the Women/W/(K) marker, so men's and women's fixtures cannot collapse into the same prediction bucket.

## Build note
The source tree was statically checked here. A full Gradle compile could not be executed because the environment cannot download Gradle 9.5.0 from services.gradle.org.
