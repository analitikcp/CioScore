# CioScore v0.9.7 — UI + Official Bulletin Baseline Fix

## UI
- Removed the top settings/gear action from the main screen.
- Removed the Settings item from the Daha Fazla sheet.
- Moved the scan action to the upper-right of the header.
- Scan button label is now simply `TARA`.
- Scan button is compact and visually aligned with the CioScore header.
- Search remains full-width below the status line.

## Official bulletin display fix
The scan diagnostic showed:
- official Iddaa feed HTTP 200
- 1160 raw events / 1160 parsed events
- 16 fixtures inside the current 06:00→06:00 bulletin window
- but the main UI could still be empty when none of those fixtures had a parsed provider prediction.

The old ScoreAdapter UI gate required at least one renderable score prediction. That made a valid official fixture invisible even though the official feed had the fixture and kickoff.

### Fix
- Official Iddaa fixtures are now the baseline display set for the current bulletin window.
- If a fixture already has one or more prediction-source records, the prediction-enriched card is kept.
- If no prediction source matched the fixture, an official-only card is created with the real teams, kickoff and Iddaa MS/HTFT data.
- No score is fabricated: prediction rows remain `—` until a source actually supplies a score.
- Past fixtures are still removed by the existing real-time kickoff gate.

## Diagnostic semantics
`predictionFixtureCount` now counts only UI fixtures that contain at least one parsed score prediction. Official-only bulletin cards are intentionally not counted as prediction fixtures.

## Version
- Version name: 0.9.7
- Version code: 292
