# BUILD FIX v0.25.57

Fixed CI Kotlin compilation errors reported in v0.25.56:
- MainActivity had two companion objects; Kotlin allows only one.
- HT/FT constants (TARGET_MATCH_QUERY, EXTRA_TARGET_HOME, EXTRA_TARGET_AWAY, EXTRA_TARGET_TIMESTAMP, REQUEST_HTFT) were in the second companion object and therefore conflicted/unavailable.
- Merged all constants into the single MainActivity companion object.
- HtFtOpenedMatchesActivity references now resolve through MainActivity.

Version: 0.25.57
Version code: 276

Static source checks passed. Full Gradle compile could not be executed in this environment because Gradle 9.5.0 is not cached and services.gradle.org is unreachable.
