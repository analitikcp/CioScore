# BWIN TipsterArea Primary V0.4

- TipsterArea is now the first bwin source.
- The app first loads one cached TipsterArea date index, then resolves the exact `/match/` fixture link from the anchor text/href.
- The same date index is shared across simultaneous match requests for 2 minutes and protected by a mutex to reduce 403/429/rate-limit failures.
- The detail page is parsed for the explicit `bwin` Standard 1X2 row.
- SofaScore, OddsSafari, and direct bwin API are fallbacks only after TipsterArea fails to produce a complete bwin 1X2 row.
- Bet365 remains outside TipsterArea and is not affected by this change.
- Logs now identify `MATCH HIT`, `INDEX MISS`, `DETAIL HIT`, `DETAIL MISS`, and the final bwin source.
