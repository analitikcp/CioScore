# CioScore bwin deep fix V0.3

The previous build relied on TipsterArea + SofaScore + an unauthenticated Bwin Sports API path. That chain can legitimately return no bwin row: TipsterArea does not publish bwin for every fixture, SofaScore's provider endpoints are internal/unstable, and the official Bwin Sports API requires commercial credentials.

This version adds `OddsSafariBwinService` as the no-key primary transport. It:

1. Opens OddsSafari's public football coupon.
2. Finds the exact event by both home and away team names.
3. Opens the event page.
4. Reads only the row explicitly labelled `Bwin`.
5. Takes the first three decimal values as 1/X/2.
6. Rejects incomplete/invalid rows and never substitutes the best/average odds.

Fallback order is now:

`OddsSafari Bwin -> TipsterArea bwin -> SofaScore bwin provider -> Bwin Sports API`

Bet365 code was not changed in this version.
