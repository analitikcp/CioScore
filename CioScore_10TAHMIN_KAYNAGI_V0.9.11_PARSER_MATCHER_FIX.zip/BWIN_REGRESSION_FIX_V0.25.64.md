# CioScore v0.25.64 — bwin regression repair

- Restored the old main-card bwin source path: TipsterArea.
- TipsterArea is fetched before the slower Bet365 waterfall.
- A valid bwin row is published immediately, so Bet365 timeouts cannot suppress bwin.
- Final merge keeps both bwin and Bet365 rows.
- UI/layout unchanged.

Current TipsterArea detail pages expose a Standard 1X2 bwin row, so this remains a real bookmaker-labelled source rather than a synthetic value.
