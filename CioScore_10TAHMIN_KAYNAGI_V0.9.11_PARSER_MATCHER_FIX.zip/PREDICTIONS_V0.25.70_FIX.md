# CioScore v0.25.70 — prediction feed fix

- Restores the four prediction sources as a first-class card feature.
- FP.com now uses its current public betting-tips page and has a fallback parser for the 2026 labelled Correct Score markup.
- PredictZ now uses the current `/us/picks/today/correct-score/` public page and has a fallback parser for `/picks/` cards.
- WinDrawWin and DailySports remain enabled.
- Prediction fetches use the browser-profile HTTP client rather than the old fast client to improve compatibility with public HTML/CDN responses.
- Every rendered match card keeps four prediction rows; missing source data is shown as `—`, never fabricated.
- Odds/UI architecture is otherwise unchanged.
