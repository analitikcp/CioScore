# CioScore v0.25.69 — Prediction Cards Restored

Restored the four core score-prediction sources on every match card:
- FP.com
- PredictZ
- WinDrawWin
- DailySports

Missing source data renders as `—`; no score is fabricated.

No changes to the current compact odds layout, bottom navigation, or Bet365/bwin source chain.
