# UI adjustment

Üstteki üç işlem butonu, alt sabit işlem çubuğundaki butonlarla aynı ölçü, aralık ve renk düzenine getirildi:
- TEŞHİS → teal (#00A896), beyaz yazı
- HT/FT → açık mint (#EAF7F4), teal yazı
- MS X → altın (#D4A017), beyaz yazı
- Buton yüksekliği: 50dp
- Butonlar arası boşluk: 5dp
- Yatay iç boşluk: 2dp
