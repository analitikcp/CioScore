# Bwin reliability pass v0.2

- Bwin source order is now SofaScore -> TipsterArea explicit `bwin` row -> direct Bwin feed.
- All three requests run in parallel so a slow TipsterArea page no longer delays the other sources.
- Direct Bwin parser now accepts common current/legacy JSON shapes (`items`, `fixtures`, `events`, nested data/results), participant names as strings/objects/arrays, and market/options naming variants.
- A bwin result is accepted only when all three 1X2 values are valid decimal odds.
- TipsterArea remains a real-bookmaker source; no synthetic/fabricated odds are introduced.
