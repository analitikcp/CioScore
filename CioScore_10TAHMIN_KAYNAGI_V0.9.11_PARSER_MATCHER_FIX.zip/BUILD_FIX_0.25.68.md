# v0.25.68 — Build Fix

Fixed the Kotlin compile error in MainActivity.kt caused by the removed `progressScan` view still being referenced by code.

Changes:
- Removed obsolete ProgressBar import.
- Removed obsolete `scanProgress` field.
- Removed obsolete `findViewById(R.id.progressScan)` lookup.
- Removed obsolete visibility update in `setScanningUi()`.
- No UI layout changes in this fix.
