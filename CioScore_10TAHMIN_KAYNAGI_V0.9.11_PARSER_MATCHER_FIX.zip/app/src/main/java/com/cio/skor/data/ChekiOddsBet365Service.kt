package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Secondary Bet365 source.
 *
 * ChekiOdds publishes bookmaker-supplied 1X2 prices on one date page. We load
 * that page once per date, build an in-memory fixture index, and never call the
 * site once per card.
 */
class ChekiOddsBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")

    internal data class Row(val home: String, val away: String, val odds: List<String>)
    internal data class DateIndex(
        val rows: List<Row>,
        val byFixtureKey: Map<String, Row>
    )
    private data class CachedPage(val expiresAt: Long, val html: String)

    private val http = HttpClient()
    private val zone = ZoneId.of("Europe/Istanbul")
    private val indexCache = ConcurrentHashMap<LocalDate, DateIndex>()
    private val pageCache = ConcurrentHashMap<LocalDate, CachedPage>()

    companion object {
        private const val CACHE_TTL_MS = 5 * 60 * 1000L
    }

    suspend fun preload(kickoffEpochMs: Collection<Long>) = withContext(Dispatchers.IO) {
        kickoffEpochMs.asSequence()
            .filter { it > 0L }
            .map { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
            .distinct()
            .forEach { ensureIndex(it) }
    }

    fun lookup(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        val date = Instant.ofEpochMilli(kickoffEpochMs).atZone(zone).toLocalDate()
        val index = indexCache[date] ?: return Result(reason = "ChekiOdds tarihi preload edilmedi")
        return lookup(index, homeTeam, awayTeam)
    }

    suspend fun fetch(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result =
        withContext(Dispatchers.IO) {
            val date = Instant.ofEpochMilli(kickoffEpochMs).atZone(zone).toLocalDate()
            val index = ensureIndex(date) ?: return@withContext Result(reason = "ChekiOdds tarih sayfası alınamadı")
            lookup(index, homeTeam, awayTeam)
        }

    private fun lookup(index: DateIndex, homeTeam: String, awayTeam: String): Result {
        val key = "${MatchMerger.canonicalTeamId(homeTeam)}||${MatchMerger.canonicalTeamId(awayTeam)}"
        index.byFixtureKey[key]?.let { return success(it.odds) }

        val best = index.rows.asSequence()
            .map { row -> row to score(homeTeam, awayTeam, row) }
            .filter { (_, s) -> s >= 0.84 }
            .maxByOrNull { (_, s) -> s }
            ?.first
        return if (best != null) success(best.odds)
        else Result(reason = "ChekiOdds'da Bet365 1X2 eşleşmesi bulunamadı")
    }

    private fun score(home: String, away: String, row: Row): Double {
        val hs = TeamAliasCanonicalizer.similarity(home, row.home)
        val `as` = TeamAliasCanonicalizer.similarity(away, row.away)
        if (MatchMerger.isSameTeam(home, row.home) && MatchMerger.isSameTeam(away, row.away)) return 1.0
        return (hs + `as`) / 2.0
    }

    private fun success(values: List<String>): Result =
        if (values.size == 3 && values.all(::validOdd)) {
            Result(SofaScoreService.BookmakerOdds("Bet365", values[0], values[1], values[2]), "ChekiOdds • Bet365 1X2")
        } else Result(reason = "ChekiOdds Bet365 oranları geçersiz")

    private suspend fun ensureIndex(date: LocalDate): DateIndex? {
        indexCache[date]?.let { return it }
        val now = System.currentTimeMillis()
        pageCache[date]?.takeIf { it.expiresAt > now }?.let { cached ->
            return parsePageIndex(cached.html)?.also { indexCache[date] = it }
        }

        val url = "https://chekiodds.com/compare-odds?date=${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}"
        val (code, body) = http.getSource(url, "https://chekiodds.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return null
        pageCache[date] = CachedPage(now + CACHE_TTL_MS, body)
        return parsePageIndex(body)?.also { indexCache[date] = it }
    }

    internal fun parsePageIndex(html: String): DateIndex? {
        val doc = Jsoup.parse(html, "https://chekiodds.com/")
        val headings = doc.select("h2")
        if (headings.isEmpty()) return null
        val rows = mutableListOf<Row>()
        for (h2 in headings) {
            val title = h2.text().trim()
            val parts = title.split(Regex("\\s+v\\s+"), limit = 2)
            if (parts.size != 2) continue
            val home = parts[0].trim()
            val away = parts[1].trim()
            if (home.isBlank() || away.isBlank()) continue

            val block = matchBlock(h2)
            if (block == null) continue
            val blockText = block.text()
            if (!blockText.contains("Bet365", true)) continue
            val odds = bet365OddsFromBlock(block) ?: continue
            rows += Row(home, away, odds)
        }
        if (rows.isEmpty()) return null

        val map = HashMap<String, Row>()
        rows.forEach { row ->
            map["${MatchMerger.canonicalTeamId(row.home)}||${MatchMerger.canonicalTeamId(row.away)}"] = row
        }
        return DateIndex(rows, map)
    }

    private fun matchBlock(h2: Element): Element? {
        var node: Element? = h2
        repeat(7) {
            node = node?.parent()
            val candidate = node ?: return@repeat
            if (candidate.select("h2").size == 1 && candidate.text().contains("Bet365", true)) {
                return candidate
            }
        }
        return null
    }

    private fun bet365OddsFromBlock(block: Element): List<String>? {
        // Prefer the explicit bookmaker table row. The visible headline can show
        // a best-price mix from different bookmakers, so it must never be used as
        // Bet365 data.
        val row = block.select("tr").firstOrNull { tr ->
            tr.text().contains("Bet365", true) && tr.select("td,th").size >= 4
        }
        if (row != null) {
            val cells = row.select("td,th")
            val values = cells.drop(1).asSequence()
                .flatMap { cell ->
                    Regex("(?<![A-Za-z])\\d{1,3}\\.\\d{1,3}(?![A-Za-z])")
                        .findAll(cell.text())
                        .map { it.value }
                }
                .filter(::validOdd)
                .take(3)
                .toList()
            if (values.size == 3) return values
        }


        // Fallback for card markup without a semantic table: use the explicit
        // 1 -> Bet365, X -> Bet365, 2 -> Bet365 sequence.
        val text = block.text()
        val m = Regex(
            "1\\s+(\\d{1,3}\\.\\d{1,3})\\s+Bet365\\s+X\\s+(\\d{1,3}\\.\\d{1,3})\\s+Bet365\\s+2\\s+(\\d{1,3}\\.\\d{1,3})\\s+Bet365",
            RegexOption.IGNORE_CASE
        ).find(text)
        if (m != null) {
            val values = listOf(m.groupValues[1], m.groupValues[2], m.groupValues[3])
            if (values.all(::validOdd)) return values
        }
        return null
    }

    private fun validOdd(value: String): Boolean =
        value.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true
}
