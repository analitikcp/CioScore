package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.util.concurrent.ConcurrentHashMap

/** API-key-free fallback. Accepts a row only when all three 1X2 prices are explicitly Bet365. */
class SimplyOddsBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")
    data class Row(val home:String,val away:String,val odds:SofaScoreService.BookmakerOdds)
    private val http=HttpClient(); private val rows=ConcurrentHashMap<String,Row>(); private var loadedAt=0L
    companion object { private const val TTL_MS=5*60*1000L }

    suspend fun preload()=withContext(Dispatchers.IO){
        if(System.currentTimeMillis()-loadedAt<TTL_MS&&rows.isNotEmpty())return@withContext
        val(code,body)=http.get("https://simplyodds.com/best-odds-today/","https://simplyodds.com/")
        if(code !in 200..299||body.isNullOrBlank())throw IllegalStateException("SimplyOdds HTTP $code")
        val parsed=parse(body); rows.clear();rows.putAll(parsed);loadedAt=System.currentTimeMillis()
        if(rows.isEmpty())throw IllegalStateException("SimplyOdds'ta tam Bet365 1X2 bulunamadı")
    }
    suspend fun fetch(home:String,away:String):Result=withContext(Dispatchers.IO){runCatching{preload()}.getOrElse{return@withContext Result(reason="SimplyOdds: ${it.message}")};lookup(home,away)}
    fun lookup(home:String,away:String):Result{
        rows[fixtureKey(home,away)]?.let{return Result(it.odds,"SimplyOdds • Bet365 1X2")}
        val best=rows.values.asSequence().map{it to((TeamAliasCanonicalizer.similarity(home,it.home)+TeamAliasCanonicalizer.similarity(away,it.away))/2.0)}.filter{it.second>=.84}.maxByOrNull{it.second}?.first
        return best?.let{Result(it.odds,"SimplyOdds • Bet365 1X2")}?:Result(reason="SimplyOdds'ta Bet365 1X2 eşleşmesi bulunamadı")
    }
    private fun parse(body:String):Map<String,Row>{
        val doc=Jsoup.parse(body);val out=HashMap<String,Row>()
        for(tr in doc.select("tr")){
            val cells=tr.select("td,th").map{it.text().trim()}; if(cells.size<4)continue
            val text=tr.text(); val odds=Regex("\\b\\d{1,3}\\.\\d{1,3}\\s+Bet365\\b",RegexOption.IGNORE_CASE).findAll(text).map{it.value.split(Regex("\\s+"))[0]}.toList()
            if(odds.size<3)continue
            val teamCell=cells.firstOrNull{it.contains(" v ",true)||it.contains(" vs ",true)||it.contains(" – ")}?:continue
            val p=teamCell.split(" v "," vs "," – "," - ",ignoreCase=true);if(p.size<2)continue
            val h=p[0].trim();val a=p[1].trim();val o=odds.take(3);if(o.all{validOdd(it)})out[fixtureKey(h,a)]=Row(h,a,SofaScoreService.BookmakerOdds("Bet365",o[0],o[1],o[2]))
        };return out
    }
    private fun validOdd(s:String)=s.toDoubleOrNull()?.let{it>1.0&&it<1000.0}==true
    private fun fixtureKey(h:String,a:String)="${MatchMerger.canonicalTeamId(h)}||${MatchMerger.canonicalTeamId(a)}"
}
