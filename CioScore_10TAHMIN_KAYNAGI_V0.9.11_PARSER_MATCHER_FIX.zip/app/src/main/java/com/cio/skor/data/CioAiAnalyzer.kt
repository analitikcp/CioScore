package com.cio.skor.data

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Cio AI v1: an on-device, explainable match-analysis engine.
 *
 * It does not claim to be a certainty engine. It combines the signals already
 * available in CioScore (source score predictions + 1X2 odds) and returns a
 * transparent probability-style summary. The class is deliberately isolated
 * so a remote LLM/API can replace or enrich it later without changing the UI.
 */
object CioAiAnalyzer {
    data class Input(
        val homeTeam: String,
        val awayTeam: String,
        val iddaa1: String?,
        val iddaaX: String?,
        val iddaa2: String?,
        val sourceScores: List<Pair<String, String>>,
        val bookmakerOdds: List<Triple<String, String, String>> = emptyList()
    )

    data class Result(
        val ms1: Int,
        val msX: Int,
        val ms2: Int,
        val confidence: Int,
        val primary: String,
        val secondary: String,
        val goalLean: String,
        val reasons: List<String>
    )

    fun analyze(input: Input): Result {
        val market = impliedProbabilities(input.iddaa1, input.iddaaX, input.iddaa2)
        var h = market.first
        var x = market.second
        var a = market.third

        val scores = input.sourceScores.mapNotNull { (_, value) -> parseScore(value) }
        if (scores.isNotEmpty()) {
            val homeWin = scores.count { it.first > it.second }.toDouble() / scores.size
            val draw = scores.count { it.first == it.second }.toDouble() / scores.size
            val awayWin = scores.count { it.first < it.second }.toDouble() / scores.size
            h = h * 0.55 + homeWin * 0.45
            x = x * 0.55 + draw * 0.45
            a = a * 0.55 + awayWin * 0.45
        }

        val bookmaker = averageBookmakerProbabilities(input.bookmakerOdds)
        if (bookmaker != null) {
            h = h * 0.75 + bookmaker.first * 0.25
            x = x * 0.75 + bookmaker.second * 0.25
            a = a * 0.75 + bookmaker.third * 0.25
        }

        val total = h + x + a
        h = h / total
        x = x / total
        a = a / total

        val sorted = listOf("1" to h, "X" to x, "2" to a).sortedByDescending { it.second }
        val primary = sorted.first().first
        val secondary = if (sorted[0].second - sorted[1].second < 0.14) {
            primary + sorted[1].first
        } else primary

        val sourceCount = scores.size
        val spread = sorted[0].second - sorted[2].second
        val confidence = (55 + sourceCount * 4 + spread * 55).toInt().coerceIn(52, 89)

        val goalAvg = if (scores.isNotEmpty()) scores.map { it.first + it.second }.average() else 2.45
        val goalLean = when {
            goalAvg >= 2.9 -> "2.5 ÜST eğilimi"
            goalAvg <= 2.1 -> "2.5 ALT eğilimi"
            else -> "2.5 sınırında dengeli"
        }

        val reasons = mutableListOf<String>()
        if (market.first + 0.03 > market.third) reasons += "İddaa 1X2 piyasasında ev sahibi tarafı önde."
        if (market.third + 0.03 > market.first) reasons += "İddaa 1X2 piyasasında deplasman tarafı önde."
        if (scores.isNotEmpty()) reasons += "${scores.size} skor kaynağı aynı maç için birlikte değerlendirildi."
        if (bookmaker != null) reasons += "Harici oranlar piyasa sinyalini çapraz kontrol etti."
        if (scores.count { it.first == it.second } >= max(1, scores.size / 3)) reasons += "Kaynak skorlarında beraberlik sinyali dikkat çekiyor."
        reasons += "Sonuç olasılık tabanlıdır; kesin maç sonucu garantisi değildir."

        return Result(
            ms1 = (h * 100).toInt(),
            msX = (x * 100).toInt(),
            ms2 = (a * 100).toInt(),
            confidence = confidence,
            primary = primary,
            secondary = secondary,
            goalLean = goalLean,
            reasons = reasons.distinct().take(5)
        )
    }

    private fun impliedProbabilities(a: String?, x: String?, b: String?): Triple<Double, Double, Double> {
        val values = listOf(a, x, b).map { it?.toDoubleOrNull() }
        if (values.any { it == null || it <= 1.0 }) return Triple(0.36, 0.30, 0.34)
        val inv = values.map { 1.0 / it!! }
        val sum = inv.sum()
        return Triple(inv[0] / sum, inv[1] / sum, inv[2] / sum)
    }

    private fun averageBookmakerProbabilities(rows: List<Triple<String, String, String>>): Triple<Double, Double, Double>? {
        val probs = rows.mapNotNull { row ->
            val v = listOf(row.first, row.second, row.third).map { it.toDoubleOrNull() }
            if (v.any { it == null || it <= 1.0 }) return@mapNotNull null
            val inv = v.map { 1.0 / it!! }
            val sum = inv.sum()
            Triple(inv[0] / sum, inv[1] / sum, inv[2] / sum)
        }
        if (probs.isEmpty()) return null
        return Triple(probs.map { it.first }.average(), probs.map { it.second }.average(), probs.map { it.third }.average())
    }

    private fun parseScore(value: String): Pair<Int, Int>? {
        val m = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(value.trim()) ?: return null
        return m.groupValues[1].toIntOrNull()?.let { h -> m.groupValues[2].toIntOrNull()?.let { a -> h to a } }
    }
}
