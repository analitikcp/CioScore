package com.cio.skor.data

/**
 * Single UI-facing registry for prediction-provider names.
 *
 * The repository owns which providers are actually fetched; this registry only
 * defines their stable display order/labels. Unknown providers are still
 * renderable, which prevents a new parser from silently disappearing from the
 * APK just because the adapter was not updated at the same time.
 */
object PredictionSourceCatalog {
    private val preferredOrder = listOf(
        "FP.com",
        "PredictZ",
        "WinDrawWin",
        "DailySports",
        "Sports Mole",
        "BallPrediction",
        "Forebet",
        "Correct-Score.net",
        "FootballScorePredictor",
        "FutHead Predictions"
    )

    private val labels = mapOf(
        "fp.com" to "Skor Analiz Filtre1",
        "predictz" to "Skor Analiz Filtre2",
        "windrawwin" to "Skor Analiz Filtre3",
        "dailysports" to "Skor Analiz Filtre4",
        "sports mole" to "Sports Mole",
        "ballprediction" to "BallPrediction",
        "forebet" to "Forebet",
        "correct-score.net" to "Correct-Score.net",
        "footballscorepredictor" to "FootballScorePredictor",
        "futhead predictions" to "FutHead Predictions"
    )

    fun orderOf(source: String): Int =
        preferredOrder.indexOfFirst { it.equals(source.trim(), ignoreCase = true) }
            .takeIf { it >= 0 } ?: preferredOrder.size

    fun displayLabel(source: String): String {
        labels[source.trim().lowercase()]?.let { return it }
        return "Skor Analiz • ${source.trim()}"
    }
}
