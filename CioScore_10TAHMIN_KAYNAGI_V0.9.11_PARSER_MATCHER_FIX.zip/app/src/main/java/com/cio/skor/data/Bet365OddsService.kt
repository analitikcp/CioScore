package com.cio.skor.data

/** API-key-free Bet365 pipeline: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds. */
class Bet365OddsService {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val source: String = "", val reason: String = "")
    private val movi = MoviOddsBet365Service()
    private val sevenM = SevenMSportBet365Service()
    private val cheki = ChekiOddsBet365Service()
    private val singleBet = SingleBetBet365Service()
    private val simplyOdds = SimplyOddsBet365Service()

    suspend fun preload(kickoffEpochMs: Collection<Long>) {
        runCatching { movi.preload() }
        runCatching { sevenM.preload() }
        runCatching { cheki.preload(kickoffEpochMs) }
        runCatching { singleBet.preload() }
        runCatching { simplyOdds.preload() }
    }

    fun lookup(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        movi.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        sevenM.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        cheki.lookup(homeTeam, awayTeam, kickoffEpochMs).let { if (it.odds != null) return Result(it.odds, it.reason) }
        singleBet.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        simplyOdds.lookup(homeTeam, awayTeam).let { if (it.odds != null) return Result(it.odds, it.reason) }
        return Result(reason = "MoviOdds + 7M Sport + ChekiOdds + SingleBet + SimplyOdds: Bet365 1X2 bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        val local = lookup(homeTeam, awayTeam, kickoffEpochMs)
        if (local.odds != null) return local
        val m = movi.fetch(homeTeam, awayTeam); if (m.odds != null) return Result(m.odds, m.reason)
        val s = sevenM.fetch(homeTeam, awayTeam); if (s.odds != null) return Result(s.odds, s.reason)
        val c = cheki.fetch(homeTeam, awayTeam, kickoffEpochMs); if (c.odds != null) return Result(c.odds, c.reason)
        val sb = singleBet.fetch(homeTeam, awayTeam); if (sb.odds != null) return Result(sb.odds, sb.reason)
        val so = simplyOdds.fetch(homeTeam, awayTeam); if (so.odds != null) return Result(so.odds, so.reason)
        return Result(reason = listOf(m.reason,s.reason,c.reason,sb.reason,so.reason).joinToString("; "))
    }
}
