package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.util.concurrent.ConcurrentHashMap

/** API-key-free Bet365 1X2 source. SingleBet publishes bookmaker rows in HTML. */
class SingleBetBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")
    data class Row(val home: String, val away: String, val odds: SofaScoreService.BookmakerOdds)
    private val http = HttpClient()
    private val rows = ConcurrentHashMap<String, Row>()
    private var loadedAt = 0L
    companion object { private const val TTL_MS = 5 * 60 * 1000L }

    suspend fun preload() = withContext(Dispatchers.IO) {
        if (System.currentTimeMillis() - loadedAt < TTL_MS && rows.isNotEmpty()) return@withContext
        val (code, body) = http.get("https://www.singlebet.net/odds/today/", "https://www.singlebet.net/")
        if (code !in 200..299 || body.isNullOrBlank()) throw IllegalStateException("SingleBet HTTP $code")
        val parsed = parse(body)
        rows.clear(); rows.putAll(parsed); loadedAt = System.currentTimeMillis()
        if (rows.isEmpty()) throw IllegalStateException("SingleBet Bet365 1X2 bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String): Result = withContext(Dispatchers.IO) {
        runCatching { preload() }.getOrElse { return@withContext Result(reason = "SingleBet: ${it.message}") }
        lookup(homeTeam, awayTeam)
    }

    fun lookup(homeTeam: String, awayTeam: String): Result {
        rows[fixtureKey(homeTeam, awayTeam)]?.let { return Result(it.odds, "SingleBet • Bet365 1X2") }
        val best = rows.values.asSequence().map { it to ((TeamAliasCanonicalizer.similarity(homeTeam,it.home)+TeamAliasCanonicalizer.similarity(awayTeam,it.away))/2.0) }
            .filter { it.second >= .84 }.maxByOrNull { it.second }?.first
        return best?.let { Result(it.odds, "SingleBet • Bet365 1X2") } ?: Result(reason="SingleBet'te Bet365 1X2 eşleşmesi bulunamadı")
    }

    private fun parse(body: String): Map<String, Row> {
        val doc = Jsoup.parse(body); val out = HashMap<String, Row>()
        for (table in doc.select("table")) {
            val headers = table.select("tr").firstOrNull()?.select("th,td")?.map { it.text().trim().lowercase() } ?: emptyList()
            for (tr in table.select("tr")) {
                val cells = tr.select("td,th").map { it.text().trim() }
                if (cells.size < 4 || !tr.text().contains("bet365", true)) continue
                val idx = cells.indexOfFirst { it.contains("bet365", true) }
                if (idx < 0) continue
                val nums = Regex("\\b\\d{1,3}\\.\\d{1,3}\\b").findAll(tr.text()).map { it.value }.toList()
                if (nums.size < 3) continue
                val teams = extractTeams(cells) ?: continue
                val odds = nums.takeLast(3); if (odds.all(::validOdd)) out[fixtureKey(teams.first,teams.second)] = Row(teams.first,teams.second,SofaScoreService.BookmakerOdds("Bet365",odds[0],odds[1],odds[2]))
            }
        }
        return out
    }

    private fun extractTeams(cells: List<String>): Pair<String,String>? {
        val candidates = cells.filter { it.contains(" v ",true) || it.contains(" vs ",true) || it.contains(" – ") }
        val s = candidates.firstOrNull() ?: cells.firstOrNull { !it.matches(Regex(".*\\d+.*")) } ?: return null
        val p = s.split(" v "," vs "," – "," - ",ignoreCase=true)
        return if (p.size >= 2) p[0].trim() to p[1].trim() else null
    }
    private fun validOdd(s:String)=s.toDoubleOrNull()?.let{it>1.0&&it<1000.0}==true
    private fun fixtureKey(h:String,a:String)="${MatchMerger.canonicalTeamId(h)}||${MatchMerger.canonicalTeamId(a)}"
}
