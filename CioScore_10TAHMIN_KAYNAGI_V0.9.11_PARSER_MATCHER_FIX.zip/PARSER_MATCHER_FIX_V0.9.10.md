# CioScore v0.9.10 — Parser / Fixture Matcher Fix

- Official-candidate recovery no longer treats an empty canonical-token prefilter as proof that a source is absent. The bounded official bulletin is now scored by the full identity gate.
- Fixture identity now explicitly uses: HOME + AWAY + competition/league + country + tournament context + nearby date + kickoff.
- Same calendar day + same kickoff + same competition/country + exact two-sided teams is accepted even when provider UTC timestamps disagree.
- Adjacent-date rollover is accepted only with the same displayed kickoff and timestamps within 12 hours.
- Tight timestamp-only recovery remains limited to 3 hours.
- Existing anti-collision team identity rules remain in force; one-sided fuzzy names cannot create a match.
- Version: 0.9.10.
