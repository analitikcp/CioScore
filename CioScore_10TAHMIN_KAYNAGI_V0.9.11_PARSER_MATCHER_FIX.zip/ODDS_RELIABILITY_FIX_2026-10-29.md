CioScore odds reliability patch 2026-10-29

Changes
- bwin: TipsterArea explicit bwin row is now the primary source; direct bwin and SofaScore remain fallbacks.
- TipsterArea fixture discovery now scores all /match/ links and tolerates team-name variants such as Gais/Gais Goteborg.
- Bet365: WBookie loader now retries supported language routes and the current board, accepting only pages that parse real Bet365 columns.
- WBookie fixture extraction now targets /soccer/match/ links and the Pick cell, avoiding the Compare link as an away-team false match.
- Bet365 and bwin logs now report HIT/MISS and the Bet365 source.

Important
No app can guarantee an external bookmaker feed 100% of the time: WBookie/TipsterArea can change, block, or delay their pages. Bet365 itself has no public developer API, so this build keeps the dedicated WBookie/ChekiOdds routes rather than pretending another bookmaker is Bet365.
