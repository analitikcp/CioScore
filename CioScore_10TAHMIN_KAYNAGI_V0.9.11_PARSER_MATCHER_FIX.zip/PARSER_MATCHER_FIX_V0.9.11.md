# CioScore v0.9.11 — Composite Schedule Identity Fix

- GlobalFixtureMatcher pipeline bumped to v0.25.48-COMPOSITE-SCHEDULE-IDENTITY-V5.9.
- Composite fixture identity is evaluated before provider date/epoch contradiction gates.
- Matching uses both teams + competition/tournament + competition country + same displayed day + same kickoff.
- Adjacent-day timezone rollover is accepted only when displayed kickoff matches and epoch delta is <= 12 hours.
- Team-name variants are allowed only when both home and away independently pass the identity engine.
- Tight timestamp-only fallback remains limited to <= 3 hours.
- Prevents DATE_MISMATCH from blocking otherwise identical fixtures when the complete schedule identity proves the same match.
