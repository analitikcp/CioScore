# CioScore V0.9.6 — 10 prediction source parser repair

## UI
- Removed the duplicate top-right Settings button from the main header.
- The same More menu remains available from the bottom navigation `Daha Fazla` item.

## Prediction source repairs
- Sports Mole: `/football/preview/` is treated as an index; linked preview articles are fetched and parsed for `We say:` exact-score predictions.
- BallPrediction: parser now reads the live `CS` table column and supports scores rendered as `1 2` as well as `1-2`.
- Forebet: parser now reads current listing rows containing date/time, teams and predicted score; HTTP fetch timeout was increased for this slower source.
- FootballScorePredictor: parser now handles separate predicted-home and predicted-away cells (`Home | 2 | 3 | Away`).
- FutHead Predictions: parser now reads the current event rows with two team links and the final correct-score value.

## Build/CI
- Updated the hard source-count lock from 4 to 10 sources.
- Removed the stale CI rule that rejected Forebet.
- Version bumped to 0.9.6 / versionCode 291.

## Verification note
The local environment does not contain the Gradle 9.5.0 distribution and has no network/DNS access to download it, so a full Android build could not be executed here. Source-level checks and XML/code edits were applied to the supplied project.
