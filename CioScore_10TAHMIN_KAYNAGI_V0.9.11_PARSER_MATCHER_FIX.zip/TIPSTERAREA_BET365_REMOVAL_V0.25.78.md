# TipsterArea Bet365 removal — v0.25.78

- TipsterArea is no longer allowed to provide Bet365 data anywhere in the app.
- Added a hard parser block for `bet365` / `bet 365` rows.
- Added a second UI/service-level guard so TipsterArea results containing Bet365 are discarded.
- Main-card Bet365 remains owned by the dedicated Bet365 provider/direct-feed layers.
- TipsterArea remains available for bwin and other explicitly requested bookmaker rows.
- bwin flow was not removed or replaced.
