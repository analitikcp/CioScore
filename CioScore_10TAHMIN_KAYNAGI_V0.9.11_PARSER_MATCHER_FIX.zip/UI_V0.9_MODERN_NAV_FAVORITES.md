# CioScore UI V0.9 — Modern Navigation + Favorites

- CP logo used in the main header.
- Top TEŞHİS / HT-FT / MSX buttons removed.
- Scan action moved to the left of the search field.
- Bottom navigation: Ana Sayfa / Favoriler / MSX / HT/FT / Daha Fazla.
- Teşhis, İddaa Bülteni and Cio Panel moved into Daha Fazla.
- Match cards have a persistent favorite star.
- Favorites are stored in SharedPreferences and survive app restarts.
- Favorite identity uses canonical team IDs + kickoff minute to keep fixtures distinct, including women/men team identity.
- Ten prediction source rows remain supported.
