package com.cio.skor.data

import com.cio.skor.data.parsers.BaseParser
import org.jsoup.Jsoup
import org.junit.Assert.*
import org.junit.Test

class MatcherAndParserRegressionTest {
    private val parser = object : BaseParser("TEST") {
        override fun parse(doc: org.jsoup.nodes.Document): List<ScoreModel> = emptyList()
    }

    @Test fun jsonLdFallbackSurvivesDomChange() {
        val html = javaClass.getResource("/fixtures/fpcom_fallback.html")!!.readText()
        val result = parser.fallbackParse(Jsoup.parse(html))
        assertEquals(1, result.size)
        assertEquals("B. Leverkusen", result.first().homeTeam)
        assertEquals("Bayern Munih", result.first().awayTeam)
        assertEquals("2-1", result.first().predictedScore)
    }

    @Test fun selectorFallbackSurvivesMarkupChange() {
        val html = javaClass.getResource("/fixtures/selector_fallback.html")!!.readText()
        val result = parser.fallbackParse(Jsoup.parse(html))
        assertEquals(1, result.size)
        assertEquals("Arsenal", result.first().homeTeam)
        assertEquals("Chelsea", result.first().awayTeam)
    }

    @Test fun countryAndLeagueFilterBlocksSameNameCollision() {
        val england = GlobalFixtureMatcher.Record("Arsenal", "Chelsea", "2-1", "FP.com", matchDate = "24.09.2026", matchTime = "19:30", competitionName = "Premier League", countryName = "England")
        val argentina = GlobalFixtureMatcher.Record("Arsenal Sarandi", "Chelsea", "1-0", "PredictZ", matchDate = "24.09.2026", matchTime = "19:30", competitionName = "Primera Nacional", countryName = "Argentina")
        assertFalse(GlobalFixtureMatcher.score(england, argentina).accepted)
    }

    @Test fun translatedNamesAndPublicationDriftStillMatch() {
        val iddaa = GlobalFixtureMatcher.Record("Bayer Leverkusen", "Bayern Munich", "", "IDDAA", sourceMatchId = "ID-1", matchDate = "24.09.2026", matchTime = "20:00", competitionName = "Bundesliga", countryName = "Germany", matchTimestamp = 1_000_000L)
        val source = GlobalFixtureMatcher.Record("B. Leverkusen", "Bayern Munih", "2-1", "FP.com", matchDate = "24.09.2026", matchTime = "20:25", competitionName = "Bundesliga", countryName = "Germany", matchTimestamp = 1_000_000L + 25 * 60_000L)
        val evidence = GlobalFixtureMatcher.score(iddaa, source)
        assertTrue(evidence.accepted)
        assertTrue(evidence.homeSimilarity >= 0.85)
        assertTrue(evidence.awaySimilarity >= 0.85)
    }
    @Test fun competitionCanonicalizerUnifiesProviderLabels() {
        assertEquals("TR_SUPER_LIG", CompetitionCanonicalizer.canonicalId("Trendyol Süper Lig"))
        assertEquals("TR_SUPER_LIG", CompetitionCanonicalizer.canonicalId("Turkey Super Lig"))
        assertEquals("EN_PREMIER_LEAGUE", CompetitionCanonicalizer.canonicalId("EPL"))
        assertEquals("EN_PREMIER_LEAGUE", CompetitionCanonicalizer.canonicalId("England Premier League"))
    }

    @Test fun midnightDriftAcrossUtcDateRolloverIsAccepted() {
        val a = GlobalFixtureMatcher.Record(
            "Bayer Leverkusen", "Bayern Munich", "", "IDDAA", sourceMatchId = "ID-2",
            matchDate = "24.09.2026", matchTime = "23:50",
            competitionName = "Bundesliga", countryName = "Germany"
        )
        val b = GlobalFixtureMatcher.Record(
            "B. Leverkusen", "Bayern Munih", "2-1", "FP.com",
            matchDate = "25.09.2026", matchTime = "00:10",
            competitionName = "German Bundesliga", countryName = "Germany"
        )
        val evidence = GlobalFixtureMatcher.score(a, b)
        assertTrue(evidence.accepted)
        assertTrue(evidence.timeScore > 0.9)
    }

    @Test fun bidirectionalGateRejectsOneStrongOneWeakTeam() {
        val a = GlobalFixtureMatcher.Record(
            "Arsenal", "Chelsea", "", "IDDAA", sourceMatchId = "ID-3",
            matchDate = "24.09.2026", matchTime = "20:00",
            competitionName = "Premier League", countryName = "England"
        )
        val b = GlobalFixtureMatcher.Record(
            "Arsenal", "Completely Different Club", "1-0", "FP.com",
            matchDate = "24.09.2026", matchTime = "20:00",
            competitionName = "EPL", countryName = "England"
        )
        assertFalse(GlobalFixtureMatcher.score(a, b).accepted)
    }

    @Test fun relaxedTimeLockRequiresSameBulletinDayOrMidnightWindow() {
        val official = GlobalFixtureMatcher.Record(
            "Bayer Leverkusen", "Bayern Munich", "", "IDDAA", sourceMatchId = "ID-4",
            matchDate = "24.09.2026", matchTime = "20:00",
            competitionName = "Bundesliga", countryName = "Germany", matchTimestamp = 2_000_000L
        )
        val sameDayNoTime = GlobalFixtureMatcher.Record(
            "B. Leverkusen", "Bayern Munih", "2-1", "FP.com",
            matchDate = "24.09.2026", matchTime = "--:--", competitionName = "", countryName = "Germany"
        )
        assertTrue(GlobalFixtureMatcher.score(official, sameDayNoTime).accepted)

        val differentDay = sameDayNoTime.copy(matchDate = "27.09.2026")
        assertFalse(GlobalFixtureMatcher.score(official, differentDay).accepted)
    }

}
