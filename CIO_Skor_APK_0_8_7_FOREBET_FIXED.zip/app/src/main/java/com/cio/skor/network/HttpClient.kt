package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val forebetUrls = listOf(
        "https://www.forebet.com/en/football-predictions?task=day",
        "https://www.forebet.com/en/football-tips-and-predictions-for-today/",
        "https://www.forebet.com/en/"
    )

    fun get(url: String): Pair<Int, String?> = request(
        url = url,
        userAgent = MOBILE_USER_AGENT,
        referer = null
    )

    /**
     * Forebet is fetched separately from the generic source requests.
     * The parser is intentionally not changed: this method only improves
     * the HTTP layer and tries the current Forebet day endpoint first.
     */
    fun getForebet(): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null

        for (url in forebetUrls) {
            try {
                val (code, body) = request(
                    url = url,
                    userAgent = DESKTOP_USER_AGENT,
                    referer = "https://www.forebet.com/en/"
                )
                lastCode = code
                lastBody = body

                if (code in 200..299 && !body.isNullOrBlank() && !looksBlocked(body)) {
                    return code to body
                }
            } catch (_: Exception) {
                // Try the next Forebet endpoint.
            }
        }

        return lastCode to lastBody
    }

    private fun request(url: String, userAgent: String, referer: String?): Pair<Int, String?> {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
            .header("Cache-Control", "no-cache")
            .header("Pragma", "no-cache")
            .header("Upgrade-Insecure-Requests", "1")

        if (!referer.isNullOrBlank()) builder.header("Referer", referer)

        client.newCall(builder.build()).execute().use { response ->
            return response.code to response.body?.string()
        }
    }

    private fun looksBlocked(body: String): Boolean {
        val s = body.lowercase()
        return s.contains("just a moment") ||
            s.contains("cf-chl-") ||
            s.contains("challenge-platform") ||
            s.contains("captcha") ||
            s.contains("access denied")
    }

    private companion object {
        const val MOBILE_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36 CIOScore/0.7"
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    }
}
