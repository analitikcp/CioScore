# CioScore v0.9.20 — Safe parser-regex fix

## Scope
Minimal, source-level parser fix based on the v0.9.19 diagnostic report.

### Fixed
- Removed parser regex forms that triggered `PatternSyntaxException` in the live Android diagnostic panel for:
  - Tip724
  - BetClan
  - BettingClosed
- Replaced score digit tokens such as `\d{1,2}` with explicit ASCII `[0-9]{1,2}` in parser modules.
- Replaced optional `[:\-]` forms with the equivalent `[:-]` character class where used by affected score markers.
- Added regression tests for Tip724, BetClan and BettingClosed score extraction.

### Not changed
- No fake/synthetic fixtures, scores, odds or predictions.
- No matcher thresholds or identity logic.
- No source list changes.
- No UI behavior changes.
- No fallback source invented.
- No parser output is fabricated when a source has no usable data.

## Diagnostic interpretation
The report also shows separate provider availability/DOM issues:
- HTTP -1 for SoccerPunter, Betshoot and OLBG is a fetch/network/provider-access problem, not a regex parse fix.
- HTTP 403 for some providers is provider-side blocking.
- DOM_CHANGED / DOM_CHANGED_OR_EMPTY means HTTP 200 was received but the current page did not yield usable rows.
- The large `SOURCE_ABSENT_FROM_PARSED_DATA` count is downstream of sources returning zero/rejected rows and should not be treated as 3,129 independent matcher failures.

## Validation
- ZIP contents were re-packed after source and test changes.
- Version files agree on `0.9.20`.
- No fake data was added.
- Full Gradle build/test could not be completed in this isolated environment because the wrapper requires a usable Gradle distribution/network access.
