# CioScore v0.9.17 — source score recovery

## Problem fixed
The v0.9.16 UI rendered all 21 source labels, but many cards had no score because an HTTP-200 provider page could still yield zero parsed rows. The pipeline treated that as DOM_CHANGED_OR_EMPTY and stopped.

## Changes
- Added provider-specific DOM recovery for PredictZ, Correct-Score.net, Forebet, Tip724 and BettingClosed.
- Added parser-empty fallback routing: configured fallback URLs are now tried even when the primary page returns HTTP 200 but produces zero score rows.
- PredictZ fallback page added.
- Forebet fallback page added.
- Correct-Score.net fallback page added.
- Expanded last-mile source backfill from the old 10-source set to all 21 configured providers.
- No generic score parser was reintroduced.
- The UI still renders all 21 source rows; a row gets a score only from a validated parsed ScoreModel.
