# CioScore v0.9.18 — Prediction/Fixture Identity Chain Fix

## P0 — Prediction identity preservation
- Added `ScoreModel.predictionId`.
- Prediction IDs are seeded once before metadata reconciliation.
- `GlobalFixtureMatcher.Record` carries the same `predictionId`.
- `buildPredictionFirstGroups()` resolves the original `ScoreModel` by `predictionId` only.
- Removed the old `findScoreModel()` fuzzy/team/score reverse lookup.

## P0 — Single fixture identity after matcher
- Added `UnifiedMatch.fixtureId`.
- Official fixtures use `IDDAA:<matchId>`.
- Non-official fixtures use one matcher-produced identity containing canonical teams and schedule metadata.
- `MatchGroup.fixtureId` carries the same identity to the UI layer.
- `coalesceDisplayGroups()` no longer recalculates fixture identity from team names/time; it only merges an already identical `fixtureId`.
- Official-only card detection also uses `fixtureId`, not a second home/away/time matcher.

## P0 — Remove last-mile fuzzy source attachment
- Removed `attachMissingPredictionSources()` entirely.
- No 18-hour home/away backfill remains after matcher output.
- A prediction rejected by the authoritative matcher is not silently attached to another card.

## P1 — Same-source score conflict safety
- If the same source emits multiple different renderable scores for the same matcher fixture, the source is marked as a conflict and no arbitrary score is selected by metadata richness.
- The same protection is applied during final fixture coalescing.

## Preserved
- Source-specific parsers.
- GlobalFixtureMatcher / Union-Find / componentsCompatible().
- Official İddaa enrichment model.
- 21 source rows in the UI.
- Score validation and upcoming-fixture UI gate.

## Build note
Gradle compilation could not be executed in the isolated environment because Gradle 9.5.0 attempts to download from services.gradle.org and DNS/network access is unavailable. Source-level consistency checks and ZIP integrity checks were performed.
