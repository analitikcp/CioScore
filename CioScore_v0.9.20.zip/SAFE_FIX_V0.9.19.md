# CioScore v0.9.19 — Safe diagnostic fix

## Scope
Minimal, non-functional diagnostic correction only.

- When a provider's primary page returns HTTP 200 but parses to zero rows and an explicitly configured provider fallback produces accepted rows, `SourceResult.fetchedUrl` now records that fallback endpoint.
- Parser-error results now retain the endpoint that was actually fetched.
- Timeout diagnostic labels now match the enclosing per-source timeout (32s normally, 52s for Sports Mole).
- No synthetic/fake fixtures, teams, scores, odds, or predictions were added.
- No matching thresholds, parser rules, source list, UI behavior, or score-selection behavior were changed.

## Validation
- ZIP contents were extracted and inspected.
- Version files agree on `0.9.19`.
- ZIP integrity and source-level structural checks were performed.
- Full Gradle build remains unavailable in this isolated environment because Gradle 9.5.0 requires network access to `services.gradle.org`.
