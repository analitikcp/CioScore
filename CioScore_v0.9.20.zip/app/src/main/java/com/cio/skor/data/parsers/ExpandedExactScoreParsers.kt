package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Expanded exact-score sources validated as public pages before being added to
 * the live pool. A prediction is emitted only when the provider's own score
 * marker and the two teams are found in the same small DOM scope.
 */

class VitibetExactScoreParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, li, [class*=match], [class*=fixture]")
            .filter { it.text().contains(Regex("(?i)\\bTip\\b")) }
            .sortedBy { it.text().length }
        for (el in scopes) {
            val text = clean(el.text())
            val score = Regex("(?i)\\bTip\\s*[:]?\\s*(\[0-9]{1,2})\\s*[-:]\\s*(\[0-9]{1,2})\\b").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = teamCells(el)
            if (teams.size < 2) continue
            add(out, "Vitibet", teams[0], teams[1], score, el, extractNearestCompetition(el), this)
        }
        return out.values.toList()
    }
}

class BetimateExactScoreParser : BaseParser("Betimate") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("tr, article, li, [class*=match], [class*=fixture]")) {
            val text = clean(row.text())
            if (!text.contains(Regex("(?i)correct\\s+score"))) continue
            val score = Regex("(?i)correct\\s+score\\s*[:]?\\s*(\[0-9]{1,2})\\s*[-:]\\s*(\[0-9]{1,2})")
                .find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val teams = teamCells(row)
            if (teams.size < 2) continue
            add(out, "Betimate", teams[0], teams[1], score, row, extractNearestCompetition(row), this)
        }
        return out.values.toList()
    }
}

class FootyStatsExactScoreParser : BaseParser("FootyStats") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, li, tr, [class*=match], [class*=fixture], [class*=prediction]")
            .filter { it.text().contains(Regex("(?i)Predicted\\s+Scoreline")) }
            .sortedBy { it.text().length }
        for (el in scopes) {
            val text = clean(el.text())
            val score = Regex("(?i)Predicted\\s+Scoreline\\s*[:]?\\s*(\[0-9]{1,2})\\s*[-:]\\s*(\[0-9]{1,2})")
                .find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
            val vs = Regex("(?is)(.+?)\\s+vs\\s+(.+?)(?=Predicted\\s+Scoreline)").find(text)
            val teams = if (vs != null) listOf(vs.groupValues[1], vs.groupValues[2]) else teamCells(el)
            if (teams.size < 2) continue
            add(out, "FootyStats", teams[0], teams[1], score, el, extractNearestCompetition(el), this)
        }
        return out.values.toList()
    }
}

private fun teamCells(el: Element): List<String> {
    val candidates = el.select("[class*=home], [class*=away], [class*=team], td, th, a[href*=match], a[href*=fixture]")
        .map { cleanExpandedTeam(it.text()) }
        .filter(::looksLikeExpandedTeam)
        .distinct()
    if (candidates.size >= 2) return candidates.take(2)

    val images = el.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("data-team")) }
        .map(::cleanExpandedTeam).filter(::looksLikeExpandedTeam).distinct()
    return images.take(2)
}

private fun add(
    out: LinkedHashMap<String, ScoreModel>,
    source: String,
    homeRaw: String,
    awayRaw: String,
    score: String,
    scope: Element,
    competition: String,
    parser: BaseParser
) {
    val home = cleanExpandedTeam(homeRaw)
    val away = cleanExpandedTeam(awayRaw)
    if (!looksLikeExpandedTeam(home) || !looksLikeExpandedTeam(away) || home.equals(away, true)) return
    val baseMetadata: BaseParser.FixtureMetadata = parser.extractFixtureMetadata(scope)
    val metadata: BaseParser.FixtureMetadata = if (
        baseMetadata.competitionName.isNotBlank() || competition.isBlank()
    ) {
        baseMetadata
    } else {
        parser.mergeMetadata(
            baseMetadata.matchDate,
            baseMetadata.matchTime,
            competition,
            baseMetadata.competitionCountry,
            baseMetadata.rawDateTime
        )
    }
    val model = ScoreModel(
        homeTeam = home,
        awayTeam = away,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = metadata.matchTimestamp,
        matchDate = metadata.matchDate,
        matchTime = metadata.matchTime,
        competitionName = metadata.competitionName,
        competitionCountry = metadata.competitionCountry
    )
    out.putIfAbsent(model.source + "|" + model.matchKey, model)
}

private fun cleanExpandedTeam(value: String): String = value
    .replace(Regex("(?i)\\b(?:predicted scoreline|correct score|second likely correct scoreline|odds|prediction|predictions|tip)\\b.*$"), " ")
    .replace(Regex("\\b(?:[01]?\[0-9]|2[0-3]):[0-5]\[0-9]\\b"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':', '·')

private fun looksLikeExpandedTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.contains(Regex("(?i)^(correct score|predicted scoreline|prediction|predictions|odds|tip|home|away|draw|score|preview|weather|prob\\.?)$"))) return false
    return true
}
