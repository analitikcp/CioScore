# CioScore v0.12.0

- Added CIO secondary analysis on every match card.
- Added model-derived MS 1 / X / 2 percentages from the five score sources.
- Added model-derived KG Var, Üst 2.5 and Alt 2.5 percentages.
- Added top 3 predicted correct scores with source-share percentages.
- Added a simple Low / Medium / High risk label based on source coverage, consensus and CioScore.
- HT/FT is explicitly shown as unavailable because the current five source models do not provide halftime predictions; no fake HT/FT values are generated.
- Existing Mackolik odds parser and general bulletin matching are preserved.
- Existing CioScore CP launcher logo is preserved.
- Version code: 120.
