# v0.21.14 – Source Parser Hardening

Applied requested parser fixes:
- Iddaa: safe nested `match`/`event` navigation and fallback top-level team fields.
- Bilyoner: odds normalized to two decimals with `Locale.US`.
- Nesine: trim all extracted text and layered CSS selectors + rendered HTML heuristic fallback.
- Misli: `totalPlayed` accepts JSON number or numeric string.
- `PopularBetItem` now carries `source` explicitly.
- Empty/invalid records are ignored instead of creating broken UI rows.
