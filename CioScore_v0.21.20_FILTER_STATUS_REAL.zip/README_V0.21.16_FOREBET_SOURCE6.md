# CioScore v0.21.16 — Forebet Source 6

## Change
Forebet is integrated as **Skor Analiz Filtre6**.

## Data collected
For each upcoming football fixture available on Forebet:
- Home team
- Away team
- Date/time when exposed
- **Correct Score** from Forebet's dedicated Correct Score field
- Competition when exposed

The parser intentionally does not scrape arbitrary score-like text from the row, preventing finished-match results and odds from being mistaken for predictions.

## Architecture
`ScraperRepository` now has six prediction sources. `GlobalFixtureMatcher` merges all six sources with the existing canonical team/fixture identity pipeline. Official Iddaa data remains an enrichment/identity anchor and is not counted as a prediction source.

## UI
`ScoreAdapter` displays Forebet as `Skor Analiz Filtre6`.
