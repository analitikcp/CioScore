# CioScore v0.21.17 — ScoreVoro + ProTipster + Consensus

- Filter 6: Forebet Correct Score
- Filter 7: ScoreVoro Correct Score
- Filter 8: ProTipster Correct Score
- Added `ConsensusScoreCalculator`: the most common exact score is shown only when it is a unique plurality backed by at least 2 sources.
- If there is no shared score, the UI shows `KONSENSÜS SKORU: YOK`.
- Empty source pages are treated as valid empty results; no fake predictions are generated.
- Existing source/fixture merge architecture is preserved.
