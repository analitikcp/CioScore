package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Forebet Correct Score parser.
 *
 * Forebet currently renders football prediction rows as div.rcnt blocks.
 * The Correct Score value is exposed in div.ex_sc.tabonly, while team names
 * are exposed as span.homeTeam / span.awayTeam. The selectors below also keep
 * conservative fallbacks so a small markup change does not silently create
 * garbage fixtures.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val rows = doc.select("div.rcnt")
        for (row in rows) {
            val home = firstNonBlank(
                row.select("span.homeTeam").text(),
                row.select(".homeTeam").text(),
                row.select("[class*=homeTeam]").text()
            )?.let(::team) ?: continue

            val away = firstNonBlank(
                row.select("span.awayTeam").text(),
                row.select(".awayTeam").text(),
                row.select("[class*=awayTeam]").text()
            )?.let(::team) ?: continue

            if (!valid(home, away)) continue

            // Correct Score is deliberately read from its dedicated field.
            // Never take an arbitrary score from the row because odds/results
            // can contain other score-like values.
            val correctScoreText = firstNonBlank(
                row.select("div.ex_sc.tabonly").text(),
                row.select(".ex_sc").text(),
                row.select("[class*=ex_sc]").text()
            ) ?: continue

            val predictedScore = score(correctScoreText) ?: continue

            // If a result is already present, do not accidentally treat the
            // finished score as a prediction. A row with FT/Finished markers
            // is skipped; the scan is intended for upcoming predictions.
            if (isFinished(row.text())) continue

            val dateTime = firstNonBlank(
                row.select("span.date_bah").text(),
                row.select(".date_bah").text()
            ).orEmpty()

            val (date, time, timestamp) = parseDateTime(dateTime)
            val competition = extractCompetition(row)

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = predictedScore,
                source = source,
                matchTimestamp = timestamp,
                matchDate = date,
                matchTime = time,
                competitionName = competition
            )

            out[model.matchKey] = model
            if (out.size >= 500) break
        }

        return out.values.toList()
    }

    private fun firstNonBlank(vararg values: String): String? =
        values.firstOrNull { it.isNotBlank() }?.trim()

    private fun isFinished(raw: String): Boolean {
        val t = " ${clean(raw).lowercase(Locale.ROOT)} "
        return listOf(
            " full time ", " full-time ", " finished ", " final ",
            " result:", " completed ", " match ended ", " ended "
        ).any { t.contains(it) }
    }

    private fun extractCompetition(row: Element): String {
        val direct = firstNonBlank(
            row.select(".shortTag").text(),
            row.select(".leagueName").text(),
            row.select("[class*=league]").text()
        )
        return clean(direct.orEmpty())
    }

    private fun parseDateTime(raw: String): Triple<String, String, Long> {
        val value = clean(raw)
        if (value.isBlank()) return Triple("", "--:--", 0L)

        val patterns = listOf("dd/MM/yyyy HH:mm", "d/M/yyyy HH:mm")
        for (pattern in patterns) {
            runCatching {
                val sdf = SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }
                val date = sdf.parse(value) ?: return@runCatching
                val dateText = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date)
                val timeText = SimpleDateFormat("HH:mm", Locale.US).format(date)
                return Triple(dateText, timeText, date.time)
            }
        }

        val time = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b").find(value)?.value ?: "--:--"
        return Triple(value, time, 0L)
    }
}
