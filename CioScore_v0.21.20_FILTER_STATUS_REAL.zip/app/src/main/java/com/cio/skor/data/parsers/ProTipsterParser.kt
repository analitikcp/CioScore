package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.util.Locale

/**
 * Parses ProTipster's public Correct Score tips page.
 * ProTipster can render an empty state when no active tips exist; that is a valid
 * empty result, not a parser error. Community/app-only tips are never fabricated.
 */
class ProTipsterParser : BaseParser("ProTipster") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val nodes = doc.select("article, li, div[class*=tip], div[class*=prediction], div[class*=match], div[class*=fixture]")
        for (node in nodes) {
            val text = clean(node.text())
            if (!text.contains("correct score", true)) continue
            val score = score(text) ?: continue
            val vs = Regex("(?i)([^|•\\n]{2,70}?)\\s+vs\\s+([^|•\\n]{2,70}?)(?=\\s+(?:Today|Tomorrow|Correct Score|\\d{1,2}:\\d{2})|$)").find(text)
            val home = vs?.groupValues?.getOrNull(1)?.let(::team) ?: continue
            val away = vs?.groupValues?.getOrNull(2)?.let(::team) ?: continue
            if (!valid(home, away)) continue
            val time = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b").find(text)?.value ?: "--:--"
            val model = ScoreModel(home, away, score, source, matchTime = time)
            out[model.matchKey] = model
            if (out.size >= 300) break
        }
        return out.values.toList()
    }
}
