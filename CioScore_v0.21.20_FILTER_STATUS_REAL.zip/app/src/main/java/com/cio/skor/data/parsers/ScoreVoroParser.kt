package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.util.Locale

/** Parses ScoreVoro's public Correct Score page. Only explicit exact-score tips are accepted. */
class ScoreVoroParser : BaseParser("ScoreVoro") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val candidates = doc.select("article, div[class*=tip], div[class*=match], div[class*=fixture], div[class*=card]")
        for (candidate in candidates) {
            val text = clean(candidate.text())
            if (!text.contains("Correct Score", ignoreCase = true)) continue
            val score = score(text) ?: continue
            val vs = Regex("(?i)([^|•\\n]{2,70}?)\\s+vs\\s+([^|•\\n]{2,70}?)(?=\\s+(?:Today|Tomorrow|Correct Score|\\d{1,2}:\\d{2})|$)").find(text)
            val home = vs?.groupValues?.getOrNull(1)?.let(::team) ?: continue
            val away = vs?.groupValues?.getOrNull(2)?.let(::team) ?: continue
            if (!valid(home, away)) continue
            val time = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b").find(text)?.value ?: "--:--"
            val probability = Regex("\\b(\\d{1,2})%\\b").find(text)?.groupValues?.get(1)
            val model = ScoreModel(home, away, score, source, matchTime = time)
            out[model.matchKey] = model
            if (out.size >= 300) break
        }
        return out.values.toList()
    }
}
