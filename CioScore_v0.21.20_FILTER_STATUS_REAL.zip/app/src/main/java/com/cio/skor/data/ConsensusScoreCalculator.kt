package com.cio.skor.data

/**
 * Returns a consensus only when one exact score is a unique plurality and is
 * backed by at least two independent sources. A tie or a single-source score
 * intentionally returns null.
 */
object ConsensusScoreCalculator {
    fun calculate(predictions: List<ScoreModel>): String? {
        val counts = predictions
            .filter { it.predictedScore.matches(Regex("\\d+-\\d+")) }
            .groupingBy { it.predictedScore.trim() }
            .eachCount()
        if (counts.isEmpty()) return null
        val sorted = counts.entries.sortedByDescending { it.value }
        val top = sorted.first()
        val second = sorted.getOrNull(1)?.value ?: 0
        return if (top.value >= 2 && top.value > second) top.key else null
    }
}
