# v0.21.20 — Filter Status Diagnostics

The main screen now shows, directly below BUGÜNÜ TARA:

`Filtre durumu: X/8 filtreden veri çekildi`

Each filter is listed as Filtre1 … Filtre8. A checkmark and parsed-score count means the parser actually produced data; an empty/failed status is kept visible so a missing prediction for one fixture is not confused with a dead source.
