# CioScore v0.21.15

## Türkiye En Çok Oynananlar kaldırıldı

Bu sürümde kullanıcı isteğiyle En Çok Oynananlar / Türkiye En Çok Oynananlar modülü projeden kaldırıldı.

- Ana ekrandaki `EN ÇOK OYNANANLAR` butonu kaldırıldı.
- `MainActivity` içindeki açılış listener kaldırıldı.
- `PopularBetsActivity` manifest kaydı kaldırıldı.
- Popüler bahis feature kaynakları kaldırıldı.
- Diğer maç/HT-Ft akışlarına dokunulmadı.
