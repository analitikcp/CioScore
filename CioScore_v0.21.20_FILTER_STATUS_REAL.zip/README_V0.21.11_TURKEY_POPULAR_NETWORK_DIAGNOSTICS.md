# CioScore v0.21.11 — Turkey Popular Bets Network Diagnostics

Bu sürüm `Türkiye En Çok Oynananlar` ekranındaki sessiz boş-liste davranışını teşhis edilebilir hale getirir.

## Değişiklikler
- Dört kaynak `supervisorScope + async/awaitAll` ile paralel taranır.
- Her kaynak için HTTP kodu, deneme sayısı, parser sonucu ve hata nedeni korunur.
- Sınırlı retry uygulanır; sınırsız/bot-engelini aşmaya yönelik davranış yoktur.
- User-Agent / Accept / Accept-Language başlıkları iyileştirildi.
- `usesCleartextTraffic=false` korunarak HTTPS dışı trafiğe izin verilmedi.
- Aynı fixture + aynı market birlikte konsolide edilir; farklı marketler birbirine karıştırılmaz.
- Dört kaynağın katkısı 0–100 Türkiye Trend Skoru'na dönüştürülür.
- UI artık "veri alınamadı" yerine hangi kaynağın HTTP/parse/empty hatası verdiğini gösterir.
- `ACCESS_NETWORK_STATE` izni eklendi.

## Önemli
Bu sürüm canlı sitelerin bot/WAF/Cloudflare korumalarını bypass etmeye çalışmaz. Bir site HTML'yi JavaScript ile oluşturuyorsa veya erişimi engelliyorsa ekrandaki kaynak teşhisi bunu açıkça gösterecektir. Bir sonraki aşama, teşhis edilen kaynağa özel resmi/uygun veri erişim yöntemini bağlamaktır.
