# CioScore v0.21.13 — Source-specific popular-bet parsers

Bu sürüm, v0.21.11'deki genel `data-*` selector yaklaşımını kaldırıp dört kaynağı ayrı parser katmanına taşır.

## Yapılanlar
- `PopularBetItem` ortak normalize edilmiş kayıt modeli eklendi.
- İddaa JSON parserı eklendi (`data -> match -> homeTeam/awayTeam`, `predictionName`, `playedCount`, `odds`).
- Bilyoner JSON parserı eklendi (`events -> homeName/awayName`, `marketValue`, `couponCount`, `ratio`).
- Misli JSON parserı eklendi (`data` veya `bets`, `homeTeamName/awayTeamName`, `outcomeName`, `totalPlayed`, `rate`).
- Nesine için rendered HTML/table heuristik parserı eklendi.
- Dört kaynak için görünür HTML fallback parserı eklendi; kırılgan CSS class adlarına bağımlılık azaltıldı.
- Misli URL'si `https://www.misli.com/iddaa/anlik-bahis` olarak düzeltildi.
- HTTP isteklerine kaynak URL'sine göre `Referer` eklendi.

## Bilinçli sınır
Verilen JSON alan adları kaynak sitelerin resmi dokümantasyonu olarak doğrulanmış değildir. Bu nedenle uygulama bu endpointleri uydurmuyor; mevcut sayfa yanıtını önce source-specific JSON parser ile, sonra görünür HTML heuristiği ile deniyor. SPA shell döner veya WAF 403/503 verirse sonraki adım gerçek tarayıcı-rendered fetcher veya yetkili/kararlı veri erişimidir.

## Bu sürümde henüz tamamlanmayan 7 maddeden kalanlar
- Room stale-data cache
- gerçek 3–5 dk memory cache
- Flow tabanlı reactive UI akışı
- tam WebView rendered fetcher
- 4 kaynağın canlı entegrasyonunun cihaz üzerinde doğrulanması
