package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.max

/**
 * Optional SofaScore enrichment layer. It never participates in CIO source
 * scoring; it only adds 1X2 odds and recent team form to an already merged match.
 * If SofaScore is unavailable, the core five-source scan remains usable.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)
    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String
    )

    private val http = HttpClient()
    private val bases = listOf(
        "https://www.sofascore.com/api/v1",
        "https://api.sofascore.com/api/v1"
    )

    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups

        val events = loadTodayEvents()
        if (events.isEmpty()) return@coroutineScope groups

        // IMPORTANT: SofaScore's bulk odds feed is much more reliable than
        // making one odds request per match. The public payload is keyed by
        // event id and normally exposes fractionalValue (e.g. 5/2), not
        // decimalValue. The old implementation therefore returned "—" for
        // every match even though the odds endpoint was reachable.
        val bulkOdds = loadTodayOdds()

        val out = groups.toMutableList()
        groups.chunked(8).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val event = events.firstOrNull {
                        MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                            MatchMerger.isSameTeam(it.away, group.awayTeam)
                    } ?: events
                        .map { it to (teamSimilarity(it.home, group.homeTeam) + teamSimilarity(it.away, group.awayTeam)) / 2.0 }
                        .filter { it.second >= 0.84 }
                        .maxByOrNull { it.second }
                        ?.first

                    if (event == null) {
                        group
                    } else {
                        val odds = bulkOdds[event.id] ?: loadOdds(event.id)
                        group.copy(odds = odds)
                    }
                }
            }.awaitAll()
            val offset = chunkIndex * 8
            results.forEachIndexed { index, value -> out[offset + index] = value }
        }
        out
    }

    suspend fun getLastFive(teamName: String): List<RecentMatch> = with(Dispatchers.IO) {
        val teamId = findTeamId(teamName) ?: return@with emptyList()
        for (base in bases) {
            val (code, body) = http.get("$base/team/$teamId/events/last/0", "https://www.sofascore.com/")
            if (code in 200..299 && !body.isNullOrBlank()) {
                val parsed = parseRecentMatches(JSONObject(body), teamId).take(5)
                if (parsed.isNotEmpty()) return@with parsed
            }
        }
        return@with emptyList()
    }

    private fun loadTodayEvents(): List<EventRef> {
        val date = LocalDate.now().toString()
        for (base in bases) {
            val (code, body) = http.get(
                "$base/sport/football/scheduled-events/$date",
                "https://www.sofascore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                val events = JSONObject(body).optJSONArray("events") ?: continue
                val parsed = buildList {
                    for (i in 0 until events.length()) {
                        val e = events.optJSONObject(i) ?: continue
                        val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                        val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                        val id = e.optLong("id", -1L)
                        if (id > 0 && home.isNotBlank() && away.isNotBlank()) add(EventRef(id, home, away))
                    }
                }
                if (parsed.isNotEmpty()) return parsed
            } catch (_: Exception) {
                // Try the alternate SofaScore host.
            }
        }
        return emptyList()
    }

    private fun loadTodayOdds(): Map<Long, Odds> {
        val date = LocalDate.now().toString()
        for (base in bases) {
            val url = "$base/sport/football/odds/1/$date"
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            try {
                val root = JSONObject(body)
                val oddsRoot = root.optJSONObject("odds") ?: continue
                val result = mutableMapOf<Long, Odds>()
                val keys = oddsRoot.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val eventId = key.toLongOrNull() ?: continue
                    val odds = parseChoiceSet(oddsRoot.optJSONObject(key)) ?: continue
                    result[eventId] = odds
                }
                if (result.isNotEmpty()) return result
            } catch (_: Exception) {
                // Try the alternate SofaScore host.
            }
        }
        return emptyMap()
    }

    private fun loadOdds(eventId: Long): Odds? {
        val paths = listOf(
            "/event/$eventId/odds/1/all",
            "/event/$eventId/odds/1",
            "/event/$eventId/odds"
        )
        for (base in bases) {
            for (path in paths) {
                val (code, body) = http.get("$base$path", "https://www.sofascore.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue
                try {
                    parseOdds(JSONObject(body))?.let { return it }
                } catch (_: Exception) {
                    // Keep trying known endpoint variants.
                }
            }
        }
        return null
    }

    private fun parseOdds(root: JSONObject): Odds? {
        fun walk(value: Any?): Odds? {
            when (value) {
                is JSONObject -> {
                    parseChoiceSet(value)?.let { return it }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = walk(value.opt(keys.next()))
                        if (found != null) return found
                    }
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) {
                        val found = walk(value.opt(i))
                        if (found != null) return found
                    }
                }
            }
            return null
        }
        return walk(root)
    }

    /** Parse SofaScore 1/X/2 choices. Supports decimalValue and fractionalValue. */
    private fun parseChoiceSet(value: JSONObject?): Odds? {
        if (value == null) return null
        val choices = value.optJSONArray("choices") ?: return null
        var one: String? = null
        var draw: String? = null
        var two: String? = null

        for (i in 0 until choices.length()) {
            val c = choices.optJSONObject(i) ?: continue
            val name = (
                c.optString("name").ifBlank {
                    c.optString("label").ifBlank { c.optString("selection") }
                }
            ).trim().uppercase()

            val number = when {
                c.has("decimalValue") -> c.optDouble("decimalValue", Double.NaN)
                c.has("decimal") -> c.optDouble("decimal", Double.NaN)
                else -> {
                    val fractional = c.optString("fractionalValue").trim()
                    fractionalToDecimal(fractional)
                }
            }
            if (!number.isFinite() || number <= 1.0 || number > 100.0) continue
            val formatted = String.format(java.util.Locale.US, "%.2f", number)
            when (name) {
                "1", "HOME", "H" -> one = formatted
                "X", "DRAW", "D" -> draw = formatted
                "2", "AWAY", "A" -> two = formatted
            }
        }
        return if (one != null && draw != null && two != null) Odds(one, draw, two) else null
    }

    private fun fractionalToDecimal(value: String): Double {
        if (value.isBlank()) return Double.NaN
        if (value.contains('/')) {
            val parts = value.split('/', limit = 2)
            val numerator = parts.getOrNull(0)?.toDoubleOrNull() ?: return Double.NaN
            val denominator = parts.getOrNull(1)?.toDoubleOrNull() ?: return Double.NaN
            if (denominator == 0.0) return Double.NaN
            return numerator / denominator + 1.0
        }
        return value.toDoubleOrNull() ?: Double.NaN
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$base/search/all?q=$query",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase()
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result)
        }
        return out.sortedByDescending { it.date }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null
    )
}
