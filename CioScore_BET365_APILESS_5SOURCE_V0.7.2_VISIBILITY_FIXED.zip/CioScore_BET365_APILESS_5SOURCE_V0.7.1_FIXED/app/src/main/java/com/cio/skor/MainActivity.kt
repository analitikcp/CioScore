package com.cio.skor

import kotlin.math.roundToInt
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.MatchSessionStore
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.DropReason
import com.cio.skor.data.UnmatchedDiagnosticItem
import com.cio.skor.data.UnmatchedReason
import com.cio.skor.data.PredictionCoverageStatus
import com.cio.skor.data.PredictionSourceCoverage
import com.cio.skor.data.SofaScoreService
import com.cio.skor.data.Bet365OddsService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    companion object {
        private const val CIO_PANEL_URL = "https://www.atlantikiddaa.com/panel"
        private const val IDDAA_BULLETIN_URL = "https://www.iddaa.com/program/futbol?msg=1"
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    // Bookmaker feeds are independent. bwin remains on its existing fast chain.
    // Bet365 order: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds.
    private val bet365Odds by lazy { Bet365OddsService() }
    private val sofaScoreOdds by lazy { SofaScoreService(applicationContext) }
    private val bwinSportsApi by lazy { com.cio.skor.data.BwinSportsApiService() }
    private val tipsterAreaOdds by lazy { com.cio.skor.data.TipsterAreaOddsService() }
    private val oddsSafariBwin by lazy { com.cio.skor.data.OddsSafariBwinService() }
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()
    private val totalCornerOdds by lazy { com.cio.skor.data.TotalCornerOddsService(applicationContext) }

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    // Odds are preloaded independently of RecyclerView visibility.
    // Four workers keep network concurrency bounded without forcing the user to scroll.
    private val oddsQueue = ArrayDeque<MatchGroup>()
    private val oddsQueuedKeys = mutableSetOf<String>()
    private var oddsActiveWorkers = 0
    private val oddsRetryCount = mutableMapOf<String, Int>()
    private val MAX_ODDS_WORKERS = 4

    private fun oddsKey(match: MatchGroup): String =
        "${MatchMerger.normalizeTeamName(match.homeTeam)}::${MatchMerger.normalizeTeamName(match.awayTeam)}::${match.displayDate.trim().lowercase()}::${TeamAliasCanonicalizer.canonical(match.homeTeam)}::${TeamAliasCanonicalizer.canonical(match.awayTeam)}"

    private fun enqueueOdds(match: MatchGroup) {
        val key = oddsKey(match)
        if (!oddsQueuedKeys.add(key)) return
        oddsQueue.addLast(match)
        processOddsQueue()
    }

    private fun enqueueOddsBatch(matches: List<MatchGroup>) {
        matches.forEach { match ->
            val key = oddsKey(match)
            if (oddsQueuedKeys.add(key)) oddsQueue.addLast(match)
        }
        processOddsQueue()
    }

    private fun processOddsQueue() {
        while (oddsActiveWorkers < MAX_ODDS_WORKERS && oddsQueue.isNotEmpty()) {
            val next = oddsQueue.removeFirst()
            oddsActiveWorkers++
            scope.launch {
                try {
                    processOneOdds(next)
                } finally {
                    oddsActiveWorkers--
                    processOddsQueue()
                }
            }
        }
    }

    private suspend fun processOneOdds(next: MatchGroup) = kotlinx.coroutines.coroutineScope {
        val key = oddsKey(next)

        val broadDeferred = async(Dispatchers.IO) {
            if (totalCornerOdds.getToken().isBlank()) emptyList()
            else runCatching {
                totalCornerOdds.fetchBookmakers(next.homeTeam, next.awayTeam, next.matchTimestamp / 1000L)
                    .value.orEmpty()
                    .mapNotNull { r ->
                        if (r.bookmaker.equals("Bet365", true)) return@mapNotNull null
                        val h = r.latestMs1; val d = r.latestMsX; val a = r.latestMs2
                        if (h == null || d == null || a == null) null
                        else SofaScoreService.BookmakerOdds(r.bookmaker, h, d, a)
                    }
            }.getOrDefault(emptyList())
        }

        val bwinDeferred = async(Dispatchers.IO) {
            // SOURCE ORDER IS DELIBERATE:
            // 1) TipsterArea — first and authoritative for this app's bwin row.
            // 2) SofaScore — fallback only when TipsterArea has no complete bwin row.
            // 3) OddsSafari — second public bookmaker fallback.
            // 4) Direct bwin Sports API — last fallback when credentials/feed permit.
            // Do NOT query all four in parallel: the old design could hammer
            // TipsterArea with several simultaneous date-page requests and cause
            // 403/429/rate-limit misses across an otherwise valid fixture set.
            val tipster = runCatching {
                tipsterAreaOdds.fetch(next.homeTeam, next.awayTeam, next.displayDate)
                    .firstOrNull { it.bookmaker.equals("bwin", true) }
            }.getOrNull()
            if (tipster != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=TipsterArea ${next.homeTeam} - ${next.awayTeam} ${tipster.ms1}/${tipster.msX}/${tipster.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", tipster.ms1, tipster.msX, tipster.ms2)
            }

            val sofa = runCatching { sofaScoreOdds.fetchBwinOnly(next.homeTeam, next.awayTeam) }.getOrNull()
            if (sofa != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=SofaScore ${next.homeTeam} - ${next.awayTeam} ${sofa.ms1}/${sofa.msX}/${sofa.ms2}")
                return@async sofa
            }

            val safari = runCatching { oddsSafariBwin.fetch(next.homeTeam, next.awayTeam, next.displayDate) }.getOrNull()
            if (safari != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=OddsSafari ${next.homeTeam} - ${next.awayTeam} ${safari.ms1}/${safari.msX}/${safari.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", safari.ms1, safari.msX, safari.ms2)
            }

            val direct = runCatching { bwinSportsApi.fetch(next.homeTeam, next.awayTeam) }.getOrNull()
            if (direct != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=BwinAPI ${next.homeTeam} - ${next.awayTeam} ${direct.ms1}/${direct.msX}/${direct.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", direct.ms1, direct.msX, direct.ms2)
            }
            null
        }

        val bet365Deferred = async(Dispatchers.IO) {
            // Five-source Bet365 chain: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds.
            val local = bet365Odds.lookup(next.homeTeam, next.awayTeam, next.matchTimestamp)
            if (local.odds != null) return@async local
            bet365Odds.fetch(next.homeTeam, next.awayTeam, next.matchTimestamp)
        }

        var broad: List<SofaScoreService.BookmakerOdds> = emptyList()
        var bwin: SofaScoreService.BookmakerOdds? = null
        var bet365: Bet365OddsService.Result = Bet365OddsService.Result()

        val broadPublish = launch {
            broad = broadDeferred.await()
            if (broad.isNotEmpty()) adapter.setExternalOdds(next, broad)
        }
        val bwinPublish = launch {
            bwin = bwinDeferred.await()
            if (bwin != null) adapter.setExternalOdds(next, listOf(bwin!!))
        }
        val bet365Publish = launch {
            bet365 = bet365Deferred.await()
            bet365.odds?.let { adapter.setExternalOdds(next, listOf(it)) }
            val bet365OddsRow = bet365.odds
            if (bet365OddsRow != null) {
                Log.d("CioScoreOdds", "BET365 HIT source=${bet365.source} ${next.homeTeam} - ${next.awayTeam} ${bet365OddsRow.ms1}/${bet365OddsRow.msX}/${bet365OddsRow.ms2}")
            } else {
                Log.w("CioScoreOdds", "BET365 MISS ${next.homeTeam} - ${next.awayTeam}: ${bet365.reason}")
            }
            if (bwin != null) {
                Log.d("CioScoreOdds", "BWIN HIT final ${next.homeTeam} - ${next.awayTeam} ${bwin!!.ms1}/${bwin!!.msX}/${bwin!!.ms2}")
            } else {
                Log.w("CioScoreOdds", "BWIN MISS ${next.homeTeam} - ${next.awayTeam}")
            }
        }
        broadPublish.join()
        bwinPublish.join()
        bet365Publish.join()

        oddsQueuedKeys.remove(key)
        if (bet365.odds == null && bwin == null && broad.isEmpty()) {
            val attempt = (oddsRetryCount[key] ?: 0) + 1
            oddsRetryCount[key] = attempt
            if (attempt <= 1) {
                delay(1500L)
                enqueueOdds(next)
            }
        } else {
            oddsRetryCount.remove(key)
        }
    }

    private fun validOdds(ms1: String, msX: String, ms2: String): Boolean =
        listOf(ms1, msX, ms2).all { it.toDoubleOrNull()?.let { value -> value > 1.0 && value <= 1000.0 } == true }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        val bottomSystemSpacer = findViewById<View>(R.id.bottomSystemSpacer)

        // STRONG BOTTOM-SAFE-AREA FIX
        // Android 15+/targetSdk 36 uses edge-to-edge. The navigation surface may
        // be transparent, so merely padding the RecyclerView can still leave the
        // final card visually underneath the system buttons. We reserve a real
        // layout area AFTER the RecyclerView. That area is never occupied by a
        // match card, so the last card can always be scrolled completely above
        // the navigation bar. Keep the RecyclerView padding as a secondary
        // safeguard for gesture-navigation devices.
        val baseRecyclerBottomPadding = recyclerView.paddingBottom
        val minimumBottomSafeArea = dp(24)
        ViewCompat.setOnApplyWindowInsetsListener(recyclerView) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                baseRecyclerBottomPadding + dp(16)
            )
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomSystemSpacer) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            val safeHeight = maxOf(minimumBottomSafeArea, navigationBottom + dp(24))
            view.layoutParams = view.layoutParams.apply { height = safeHeight }
            view.requestLayout()
            insets
        }
        ViewCompat.requestApplyInsets(recyclerView)
        ViewCompat.requestApplyInsets(bottomSystemSpacer)

        recyclerView.layoutManager = LinearLayoutManager(this)
        // 94+ official fixtures are valid. Disable change animations and keep
        // RecyclerView work predictable so a large bulletin cannot stall the UI.
        recyclerView.setHasFixedSize(false)
        recyclerView.itemAnimator = null
        recyclerView.setItemViewCacheSize(4)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            },
            onExternalOddsRequest = { match -> enqueueOdds(match) },
            onCioAiClick = { match, books ->
                val scoreRows = match.predictions
                    .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                    .map { "${it.source}|${it.predictedScore}" }
                val bookRows = books.map { "${it.bookmaker}|${it.ms1}|${it.msX}|${it.ms2}" }
                startActivity(Intent(this, CioAiActivity::class.java).apply {
                    putExtra(CioAiActivity.EXTRA_HOME, match.homeTeam)
                    putExtra(CioAiActivity.EXTRA_AWAY, match.awayTeam)
                    putExtra(CioAiActivity.EXTRA_1, match.iddaaMs1)
                    putExtra(CioAiActivity.EXTRA_X, match.iddaaMsX)
                    putExtra(CioAiActivity.EXTRA_2, match.iddaaMs2)
                    putStringArrayListExtra(CioAiActivity.EXTRA_SCORES, ArrayList(scoreRows))
                    putStringArrayListExtra(CioAiActivity.EXTRA_BOOKS, ArrayList(bookRows))
                })
            }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener { showDiagnostics() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        findViewById<Button>(R.id.btnXCandidates).setOnClickListener {
            if (allGroups.isEmpty()) {
                Toast.makeText(this, "Önce bugünün taramasını yap.", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, XCandidateActivity::class.java))
            }
        }
        findViewById<Button>(R.id.btnIddaaBulletin).setOnClickListener {
            val bulletinIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(IDDAA_BULLETIN_URL))
            runCatching {
                startActivity(bulletinIntent)
            }.onFailure {
                Toast.makeText(this, "İddaa bülteni açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btnCioPanel).setOnClickListener {
            val panelIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(CIO_PANEL_URL))
            runCatching {
                startActivity(panelIntent)
            }.onFailure {
                Toast.makeText(this, "Cio Panel açılamadı.", Toast.LENGTH_SHORT).show()
            }
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all configured score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all prediction sources before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, source ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Kaynaklar: $completed/${repo.sourceCount} — $source"
                            }
                        }
                    }
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    scanStatus.text = "Tüm tahmin kaynakları başarısız oldu."
                    Toast.makeText(this@MainActivity, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else ""

                // Keep all CPU-heavy reconciliation/diagnostic work off the Android main thread.
                // The previous version returned from the source fetch onto Dispatchers.Main and
                // then ran fixture coverage + identity diagnostics there, which could trigger an
                // ANR after the UI reported "4/4 successful".
                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı • Maçlar işleniyor…"
                val preparedGroups = withContext(Dispatchers.Default) {
                    val rawScores = results.sumOf { it.scores.size }

                // PREDICTION-FIRST HARD RULE: every parsed provider prediction is eligible
                // for the UI. Iddaa is enrichment only and is never a source gate.
                val parsedPredictionScores = results.flatMap { result: SourceResult -> result.scores }

                // KICKOFF CANONICALIZATION
                // Keep all renderable predictions through identity/official enrichment.
                // The past-match gate is intentionally applied AFTER GlobalFixtureMatcher
                // so an authoritative İddaa kickoff can correct a provider-side clock.
                // This is independent from the İddaa 06:00 bulletin window.
                val displayableScores = parsedPredictionScores.filter(::isDisplayable)
                val invalidScores = rawScores - displayableScores.size

                // Diagnostic only: count prediction records after the displayability filter.
                runCatching {
                    val diagnosticCounts = parsedPredictionScores.groupingBy { it.source }.eachCount()
                    com.cio.skor.data.PipelineDiagnostics.log(
                        sourceCounts = diagnosticCounts,
                        rawPredictions = parsedPredictionScores.size
                    )
                }

                // Iddaa is fetched only for optional enrichment. It MUST NOT gate, reject,
                // or shrink the provider prediction set, regardless of bulletin window.

                // Official Iddaa enrichment uses the FULL official football bulletin.
                // HT/FT availability is only a market property; it must NEVER restrict
                // the official fixture candidate pool used by GlobalFixtureMatcher.
                // The main scan tolerates a slower official response so the full bulletin
                // has time to arrive before matching.
                val officialResult = try {
                    withTimeoutOrNull(25_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) throw CancellationException("Scan superseded")

                // No official fixture pool is used as a gate. Provider predictions remain
                // displayable even when the official bulletin has no matching fixture.

                // Deduplicate only true provider duplicates. Team names + score + source
                // are NOT a sufficient identity: the same clubs can legitimately play more
                // than once in the bulletin. Prefer the provider's match ID; otherwise keep
                // kickoff/date/time/competition metadata in the fallback key.
                val dedupedScores: List<ScoreModel> = displayableScores.distinctBy { prediction ->
                    val home = MatchMerger.normalizeTeamName(prediction.homeTeam)
                    val away = MatchMerger.normalizeTeamName(prediction.awayTeam)
                    val source = prediction.source.trim().lowercase()
                    val providerId = prediction.sourceMatchId.trim()
                    if (providerId.isNotBlank()) {
                        "ID|$source|$providerId"
                    } else {
                        "META|$source|$home|$away|${prediction.predictedScore.trim()}|" +
                            "${prediction.matchTimestamp}|${prediction.matchDate.trim()}|" +
                            "${prediction.matchTime.trim()}|${prediction.competitionName.trim().lowercase()}"
                    }
                }

                // IMPORTANT: there is NO Iddaa prediction gate anymore.
                // We only load the official bulletin so it can optionally enrich
                // prediction cards with MS1/MSX/MS2 and HT/FT data.
                val officialInBulletinWindow = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    // Use the service's already merged official fixture pool. Reusing
                    // allParsedMatches here would re-introduce duplicate official records
                    // that the service intentionally collapsed before the identity graph.
                    officialResult.matches.filter { official ->
                        official.matchTimestamp >= officialResult.bulletinStartMillis &&
                            official.matchTimestamp < officialResult.bulletinEndMillis
                    }
                } else {
                    emptyList()
                }

                // METADATA RECONCILIATION: before clustering, fill only missing
                // date/time/league/country fields from an independently confirmed
                // fixture. Iddaa is the strongest anchor, but provider-to-provider
                // agreement is also allowed. This is NOT an Iddaa-only gate.
                val reconciledScores = withContext(Dispatchers.Default) {
                    GlobalFixtureMatcher.reconcileMetadata(
                        predictions = dedupedScores,
                        officialMatches = officialInBulletinWindow
                    )
                }

                // PREDICTION-FIRST DISPLAY: never let the official Iddaa bulletin
                // determine whether a provider prediction exists in the UI. The official
                // 06:00-06:00 window has already been applied inside IddaaMarketService
                // to the official feed only; it is deliberately NOT applied to predictions.
                // The previous implementation still routed every prediction through
                // GlobalFixtureMatcher before building cards; that collapsed the 117
                // provider records into only 4 unified fixtures in the APK.
                // Build the display fixture set directly from provider predictions.
                // Iddaa is consulted afterwards, only as optional enrichment.
                val allPreparedGroups = withContext(Dispatchers.Default) {
                    val rawGroups = buildPredictionFirstGroups(
                        predictions = reconciledScores,
                        officialMatches = officialInBulletinWindow
                    )
                    // FINAL FIXTURE-LEVEL COALESCE:
                    // The identity matcher is authoritative, but a provider can
                    // still emit the same fixture under different source IDs.
                    // Never let that provider-side duplication become two APK cards.
                    //
                    // IMPORTANT: do one final source backfill before the UI gate.
                    // Some providers publish only a date (no kickoff time), while
                    // another provider publishes the exact kickoff. Without this
                    // pass the same fixture could become separate one-source cards,
                    // making the four prediction rows appear empty even though the
                    // parser already has the real score. This pass only unions real
                    // parsed predictions; it never creates or guesses a score.
                    val coalesced = coalesceDisplayGroups(rawGroups)
                    attachMissingPredictionSources(coalesced, reconciledScores)
                }

                // REAL-TIME UPCOMING FIXTURE GATE
                // Use the actual moment at which the finished scan is about to be
                // rendered, not the 06:00 İddaa bulletin boundary. A kickoff at or
                // before this instant is already started/finished and is never shown.
                // Unknown kickoff is also excluded: without a trustworthy kickoff we
                // cannot prove that the prediction is still actionable.
                val reconciledKickoffCount = reconciledScores.count { it.matchTimestamp > 0L }
                val reconciledKickoffBySource = reconciledScores
                    .filter { it.matchTimestamp > 0L }
                    .groupingBy { it.source }.eachCount()
                Log.d("MetadataReconcile", "kickoff=$reconciledKickoffCount/${reconciledScores.size} bySource=$reconciledKickoffBySource")

                val renderNowMs = System.currentTimeMillis().coerceAtLeast(scanStartMs)
                val pastMatchGroups = allPreparedGroups.filter {
                    it.matchTimestamp > 0L && it.matchTimestamp <= renderNowMs
                }
                val missingKickoffGroups = allPreparedGroups.filter { it.matchTimestamp <= 0L }
                    val preparedGroups = allPreparedGroups.filter {
                        it.matchTimestamp > renderNowMs
                    }

                val iddaaMatchedForUi = preparedGroups.count {
                    it.iddaaMs1 != null || it.iddaaMsX != null || it.iddaaMs2 != null
                }
                val predictionNotInIddaaPredictions = preparedGroups
                    .filter { !it.isIddaaBulletinMatch }
                    .flatMap { it.predictions }
                val unmatchedOfficialDiagnostics = predictionNotInIddaaPredictions
                    .map { GlobalFixtureMatcher.diagnoseOfficialMismatch(it, officialInBulletinWindow) }
                val predictionNotInIddaaDetails = unmatchedOfficialDiagnostics.map { item ->
                    val source = predictionNotInIddaaPredictions.firstOrNull { p ->
                        p.homeTeam == item.predictionHome && p.awayTeam == item.predictionAway
                    }?.source ?: "?"
                    "${item.predictionHome} vs ${item.predictionAway} | $source | ${diagnosticReasonLabel(item.probableReason)}"
                }
                // IMPORTANT: the 06:00-06:00 rule belongs ONLY to the official İddaa
                // bulletin. Prediction providers and independent bookmaker odds
                // are never filtered by that window. This diagnostic list only records
                // predictions whose own timestamp falls outside the official bulletin;
                // it NEVER removes them from preparedGroups or the UI.
                val predictionOutsideBulletinDetails = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    dedupedScores.filter { prediction ->
                        val ts = prediction.matchTimestamp
                        ts > 0L && (
                            ts < officialResult.bulletinStartMillis ||
                                ts >= officialResult.bulletinEndMillis
                            )
                    }.map { prediction ->
                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | " +
                            "IDDAA_BULLETIN_WINDOW_DISJOINT"
                    }
                } else {
                    emptyList()
                }

                // BIDIRECTIONAL SOURCE COVERAGE DIAGNOSTIC:
                // The older diagnostic only asked "which provider predictions failed
                // to attach to Iddaa?". That cannot explain the much larger reverse
                // gap: official fixtures with no prediction card at all. Inspect every
                // official fixture against every parsed provider source without changing
                // the UI or matcher behavior.
                val coverageSourceNames = results.map { it.source }
                val coverageDetails = officialInBulletinWindow.flatMap { official ->
                    coverageSourceNames.map { source ->
                        val sourcePredictions = dedupedScores.filter { it.source == source }
                        GlobalFixtureMatcher.diagnoseOfficialCoverage(
                            official = official,
                            source = source,
                            predictions = sourcePredictions
                        )
                    }
                }
                val coverageMatchedBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.MATCHED }
                    .groupingBy { it.source }.eachCount()
                val coveragePresentButUnmatchedBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.SOURCE_PRESENT_BUT_UNMATCHED }
                    .groupingBy { it.source }.eachCount()
                val coverageAbsentBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.SOURCE_ABSENT_FROM_PARSED_DATA }
                    .groupingBy { it.source }.eachCount()
                val predictionSourceCoverage = PredictionSourceCoverage(
                    officialFixtureCount = officialInBulletinWindow.size,
                    sourceNames = coverageSourceNames,
                    matchedBySource = coverageMatchedBySource,
                    presentButUnmatchedBySource = coveragePresentButUnmatchedBySource,
                    absentBySource = coverageAbsentBySource,
                    details = coverageDetails
                )

                val metadataCompleteBySource = dedupedScores
                    .groupBy { it.source }
                    .mapValues { (_, items) ->
                        items.count { it.matchDate.isNotBlank() && it.matchTime != "--:--" && it.competitionName.isNotBlank() }
                    }
                val metadataPartialBySource = dedupedScores
                    .groupBy { it.source }
                    .mapValues { (_, items) ->
                        items.count { it.matchDate.isNotBlank() || it.matchTime != "--:--" || it.competitionName.isNotBlank() }
                    }
                val predictionNotInIddaaByReason = unmatchedOfficialDiagnostics
                    .groupingBy { it.probableReason.name }
                    .eachCount()
                val pastMatchDetails = pastMatchGroups.take(30).map { match ->
                    "${match.homeTeam} vs ${match.awayTeam} | ${match.displayDate} ${match.displayTime}"
                }

                ObservabilityBus.publish(
                    ScanTrace(
                        // Build parser health reports inline. This is diagnostic-only and
                        // never filters, rejects, or removes prediction matches.
                        parserReports = results.map { result ->
                            val status = when {
                                result.error == null && result.httpCode in 200..299 && result.scores.isNotEmpty() ->
                                    ParserStatus.HEALTHY
                                result.httpCode in 200..299 && result.scores.isEmpty() ->
                                    ParserStatus.DOM_CHANGED
                                else ->
                                    ParserStatus.FAILED
                            }
                            ParserHealthReport(
                                sourceName = result.source,
                                httpCode = result.httpCode,
                                rawHtmlBytes = result.rawHtmlBytes,
                                parsedCount = result.scores.size,
                                durationMs = result.durationMs,
                                status = status,
                                errorMessage = result.error
                            )
                        },
                        stageMetrics = linkedMapOf(
                            PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                            PipelineStage.PARSER to rawScores,
                            PipelineStage.NORMALIZATION to dedupedScores.size,
                            PipelineStage.IDENTITY to preparedGroups.size,
                            PipelineStage.CONFIDENCE to preparedGroups.count { it.predictions.size >= 2 },
                            PipelineStage.MERGE to preparedGroups.size,
                            PipelineStage.IDDAA_ENRICHMENT to iddaaMatchedForUi,
                            PipelineStage.UI to preparedGroups.size
                        ),
                        // Only genuinely invalid provider records are drops.
                        // A prediction missing from Iddaa is explicitly NOT a drop.
                        dropReasons = buildList {
                            if (invalidScores > 0) {
                                add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                            }
                        },
                        totalDurationMs = System.currentTimeMillis() - scanStartMs,
                        unmatchedOfficialDiagnostics = unmatchedOfficialDiagnostics,
                        officialFeedDiagnostics = officialResult?.let { result ->
                            com.cio.skor.data.OfficialFeedDiagnostics(
                                httpEvents = result.httpEvents,
                                httpMarketConfig = result.httpMarketConfig,
                                rawEventCount = result.rawEventCount,
                                parsedEventCount = result.parsedEventCount,
                                timestampedEventCount = result.timestampedEventCount,
                                bulletinEventCountBeforeMerge = result.bulletinEventCountBeforeMerge,
                                bulletinDate = result.bulletinDate,
                                bulletinWindow = result.bulletinWindow,
                                mergedFixtureCount = result.mergedFixtureCount,
                                marketMatches = result.marketMatches,
                                error = result.error,
                                dateDistribution = result.dateDistribution,
                                sampleFixtures = result.sampleFixtures
                            )
                        },
                        predictionFixtureCount = preparedGroups.size,
                        officialMatchedPredictionCount = iddaaMatchedForUi,
                        // Diagnostic-only: an official fixture is "official-only" when
                        // no parsed prediction source has a MATCHED coverage result.
                        // Do not synthesize or infer fixture counts from UI card counts.
                        officialOnlyFixtureCount = coverageDetails
                            .groupBy { "${it.officialHome}\u0000${it.officialAway}" }
                            .count { (_, items) ->
                                items.none { it.status == PredictionCoverageStatus.MATCHED }
                            },
                        // These two fields are enrichment diagnostics only. They do NOT
                        // represent dropped predictions.
                        predictionNotInIddaaCount = predictionNotInIddaaDetails.size,
                        predictionNotInIddaaDetails = predictionNotInIddaaDetails.toList(),
                        predictionNotInIddaaBySource = predictionNotInIddaaDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        predictionNotInIddaaByReason = predictionNotInIddaaByReason,
                        metadataCompleteBySource = metadataCompleteBySource,
                        metadataTotalBySource = dedupedScores.groupBy { it.source }.mapValues { it.value.size },
                        metadataPartialBySource = metadataPartialBySource,
                        predictionOutsideBulletinCount = predictionOutsideBulletinDetails.size,
                        predictionOutsideBulletinDetails = predictionOutsideBulletinDetails.toList(),
                        predictionOutsideBulletinBySource = predictionOutsideBulletinDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        pastMatchFilteredCount = pastMatchGroups.size,
                        pastMatchFilteredDetails = pastMatchDetails,
                        missingKickoffCount = missingKickoffGroups.size,
                        missingKickoffBySource = missingKickoffGroups
                            .flatMap { it.predictions }
                            .groupingBy { it.source }.eachCount(),
                        reconciledKickoffCount = reconciledKickoffCount,
                        reconciledKickoffBySource = reconciledKickoffBySource,
                        predictionSourceCoverage = predictionSourceCoverage
                    )
                )

                    preparedGroups
                }

                val enrichedGroups = preparedGroups

                // Bet365 PRELOAD: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds.
                runCatching {
                    bet365Odds.preload(enrichedGroups.map { it.matchTimestamp })
                }.onFailure {
                    Log.w("CioScoreOdds", "Bet365 kaynak preload uyarısı: ${it.message}")
                }

                allGroups = enrichedGroups
                MatchSessionStore.latestGroups = enrichedGroups
                // PRELOAD ODDS: network work starts for the whole result set as soon
                // as the scan finishes. RecyclerView visibility/scroll position no
                // longer controls when bookmaker requests begin.
                adapter.prepareOddsPreload(enrichedGroups)
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(enrichedGroups)
                enqueueOddsBatch(enrichedGroups)
                recyclerView.post {
                    recyclerView.visibility = View.VISIBLE
                    recyclerView.invalidate()
                }
                scanStatus.text = "${allGroups.size} maç • İddaa + Bet365(MoviOdds→7M Sport→ChekiOdds→SingleBet→SimplyOdds) + bwin • Teşhis: 🔍"
                focusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                scanStatus.text = "Tarama hatası: ${e.javaClass.simpleName.ifBlank { "Exception" }}"
                Toast.makeText(
                    this@MainActivity,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: (e.javaClass.simpleName.ifBlank { "Exception" })}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) setScanningUi(false)
            }
        }
    }


    /** Prediction-first UI grouping. Iddaa is enrichment only and never a gate. */
    private fun buildPredictionFirstGroups(
        predictions: List<ScoreModel>,
        officialMatches: List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>
    ): List<MatchGroup> {
        // IMPORTANT: never regroup predictions with a simple home||away key here.
        // That bypassed GlobalFixtureMatcher and caused multilingual names or
        // damaged home names to split an otherwise identical fixture into cards.
        // The matcher is now the single source of truth for provider clustering.
        val unified = GlobalFixtureMatcher.merge(predictions, officialMatches)

        fun findScoreModel(record: GlobalFixtureMatcher.Record): ScoreModel? =
            predictions.firstOrNull { p ->
                if (!p.source.equals(record.source, ignoreCase = true)) return@firstOrNull false
                if (record.sourceMatchId.isNotBlank() && p.sourceMatchId.isNotBlank() &&
                    p.sourceMatchId != record.sourceMatchId
                ) return@firstOrNull false
                if (p.predictedScore.trim() != record.predictedScore?.trim().orEmpty()) return@firstOrNull false

                // Do not require byte-for-byte team-name equality here. The four
                // providers routinely abbreviate/suffix the same club differently
                // (Utd/United, FC suffixes, accents, etc.). The global matcher has
                // already decided that this record belongs to the component, so use
                // the same canonical identity layer for the final lookup.
                MatchMerger.areMatchesSame(
                    p.homeTeam, p.awayTeam, record.homeTeam, record.awayTeam
                ) || (
                    MatchMerger.isSameTeam(p.homeTeam, record.homeTeam) &&
                        MatchMerger.isSameTeam(p.awayTeam, record.awayTeam)
                )
            }

        // GlobalFixtureMatcher already carries the best official anchor on each
        // unified component. Do not run a second full prediction × official scan
        // here: that duplicated the identity engine and could select a different
        // official fixture from the one used to form the component.


        // CRITICAL INVARIANT: Iddaa is enrichment only. Provider predictions
        // always create a card, while a successfully matched Iddaa fixture only
        // enriches that card with official names/odds/bulletin state.
        return unified.mapNotNull { match ->
            val cardPredictions = match.predictionRecords
                .mapNotNull(::findScoreModel)
                .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                .distinctBy { it.source.trim().lowercase() }
            if (cardPredictions.isEmpty()) return@mapNotNull null

            val primary = cardPredictions.first()
            val official = match.officialMatch
            MatchGroup(
                isIddaaBulletinMatch = official != null,
                homeTeam = official?.homeTeam ?: match.mainHomeTeam.ifBlank { primary.homeTeam },
                awayTeam = official?.awayTeam ?: match.mainAwayTeam.ifBlank { primary.awayTeam },
                predictions = cardPredictions,
                iddaaProgramUrl = official?.let { buildIddaaProgramUrl(it.matchDate) },
                iddaaMs1 = official?.ms1, iddaaMsX = official?.msX, iddaaMs2 = official?.ms2,
                htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                hasHtFt = official?.hasHtFt ?: false,
                matchTimestamp = official?.matchTimestamp?.takeIf { it > 0L }
                    ?: match.predictionRecords.maxOfOrNull { it.matchTimestamp }?.takeIf { it > 0L }
                    ?: primary.matchTimestamp,
                displayTime = official?.matchTime?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchTime.isNotBlank() && it.matchTime != "--:--" }?.matchTime
                    ?: primary.matchTime,
                displayDate = official?.matchDate?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchDate.isNotBlank() }?.matchDate
                    ?: primary.matchDate,
                homeTeamId = null, awayTeamId = null
            )
        }.sortedWith(
            compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                .thenBy { it.homeTeam.lowercase() }
                .thenBy { it.awayTeam.lowercase() }
        )
    }

    /**
     * Last-mile duplicate protection for the UI.
     * Identity = canonical HOME + canonical AWAY + resolved kickoff minute.
     * Predictions from duplicate groups are unioned by source; official Iddaa
     * enrichment is preserved whenever either copy has it.
     */
    /**
     * Final prediction-source union.
     *
     * The parsers are independent and their kickoff metadata is not equally
     * complete. A source with only a date can therefore miss the exact same
     * fixture during the last-mile kickoff-keyed coalesce. Attach that already-
     * parsed source prediction to the matching card using canonical teams plus
     * a conservative kickoff/date check. No prediction is synthesized here.
     */
    private fun attachMissingPredictionSources(
        groups: List<MatchGroup>,
        allPredictions: List<ScoreModel>
    ): List<MatchGroup> {
        if (groups.isEmpty() || allPredictions.isEmpty()) return groups

        val wantedSources = setOf("fp.com", "predictz", "windrawwin", "dailysports")
        val parsed = allPredictions.filter {
            it.source.trim().lowercase() in wantedSources &&
                ScoreModel.hasRenderablePrediction(it.predictedScore)
        }

        fun canonicalDisplayDate(epochMillis: Long, fallback: String): String {
            if (epochMillis <= 0L) return fallback.trim()
            return try {
                java.time.Instant.ofEpochMilli(epochMillis)
                    .atZone(java.time.ZoneId.of("Europe/Istanbul"))
                    .toLocalDate()
                    .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            } catch (_: Exception) {
                fallback.trim()
            }
        }

        fun sameFixture(group: MatchGroup, prediction: ScoreModel): Boolean {
            val teamsMatch =
                MatchMerger.isSameTeam(group.homeTeam, prediction.homeTeam) &&
                    MatchMerger.isSameTeam(group.awayTeam, prediction.awayTeam)
            if (!teamsMatch) return false

            val groupTs = group.matchTimestamp
            val predictionTs = prediction.matchTimestamp
            if (groupTs > 0L && predictionTs > 0L) {
                // Provider kickoff times can differ by timezone/rounding. Keep the
                // window deliberately tight so two fixtures of the same teams on
                // different days cannot be merged.
                return kotlin.math.abs(groupTs - predictionTs) <= 18L * 60L * 60L * 1000L
            }

            val groupDate = canonicalDisplayDate(groupTs, group.displayDate)
            val predictionDate = canonicalDisplayDate(
                predictionTs,
                prediction.matchDate
            )
            return groupDate.isNotBlank() && predictionDate.isNotBlank() &&
                groupDate == predictionDate
        }

        return groups.map { group ->
            val bySource = LinkedHashMap<String, ScoreModel>()
            group.predictions.forEach { prediction ->
                bySource[prediction.source.trim().lowercase()] = prediction
            }

            parsed.asSequence()
                .filter { prediction -> sameFixture(group, prediction) }
                .forEach { prediction ->
                    val sourceKey = prediction.source.trim().lowercase()
                    val old = bySource[sourceKey]
                    if (old == null ||
                        (old.sourceMatchId.isBlank() && prediction.sourceMatchId.isNotBlank())
                    ) {
                        bySource[sourceKey] = prediction
                    }
                }

            group.copy(predictions = bySource.values.toList())
        }
    }

    private fun coalesceDisplayGroups(groups: List<MatchGroup>): List<MatchGroup> {
        if (groups.size < 2) return groups

        data class FixtureKey(val home: String, val away: String, val kickoffMinute: Long)
        val merged = LinkedHashMap<FixtureKey, MatchGroup>()

        for (incoming in groups) {
            val home = TeamAliasCanonicalizer.identity(incoming.homeTeam).canonicalId
            val away = TeamAliasCanonicalizer.identity(incoming.awayTeam).canonicalId
            val kickoff = incoming.matchTimestamp

            // The GlobalFixtureMatcher is the authoritative reconciliation engine.
            // This last-mile pass is deliberately conservative: it may collapse only
            // groups that already have the same canonical HOME/AWAY identity AND the
            // same resolved kickoff minute. It must never invent a cross-kickoff merge.
            if (home.isBlank() || away.isBlank() || kickoff <= 0L) {
                val fallback = FixtureKey(
                    home + "#" + incoming.homeTeam.trim().lowercase(),
                    away + "#" + incoming.awayTeam.trim().lowercase(),
                    kickoff
                )
                merged.putIfAbsent(fallback, incoming)
                continue
            }

            val key = FixtureKey(home, away, kickoff / 60_000L)
            val existing = merged[key]
            if (existing == null) {
                merged[key] = incoming
                continue
            }

            val bySource = LinkedHashMap<String, ScoreModel>()
            fun addPredictions(list: List<ScoreModel>) {
                list.filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                    .forEach { prediction ->
                        val sourceKey = prediction.source.trim().lowercase()
                        val old = bySource[sourceKey]
                        if (old == null ||
                            (old.sourceMatchId.isBlank() && prediction.sourceMatchId.isNotBlank())
                        ) {
                            bySource[sourceKey] = prediction
                        }
                    }
            }
            addPredictions(existing.predictions)
            addPredictions(incoming.predictions)

            // Official metadata wins when both records represent the same exact
            // fixture. Because the key already contains the resolved kickoff minute,
            // no max()/min() timestamp heuristic is needed here.
            val preferred = if (incoming.isIddaaBulletinMatch && !existing.isIddaaBulletinMatch) {
                incoming
            } else {
                existing
            }
            val preferredTimestamp = when {
                preferred.isIddaaBulletinMatch && preferred.matchTimestamp > 0L -> preferred.matchTimestamp
                existing.isIddaaBulletinMatch && existing.matchTimestamp > 0L -> existing.matchTimestamp
                incoming.isIddaaBulletinMatch && incoming.matchTimestamp > 0L -> incoming.matchTimestamp
                else -> preferred.matchTimestamp.takeIf { it > 0L }
                    ?: existing.matchTimestamp.takeIf { it > 0L }
                    ?: incoming.matchTimestamp
            }

            merged[key] = preferred.copy(
                isIddaaBulletinMatch = existing.isIddaaBulletinMatch || incoming.isIddaaBulletinMatch,
                predictions = bySource.values.toList(),
                iddaaMs1 = preferred.iddaaMs1 ?: existing.iddaaMs1 ?: incoming.iddaaMs1,
                iddaaMsX = preferred.iddaaMsX ?: existing.iddaaMsX ?: incoming.iddaaMsX,
                iddaaMs2 = preferred.iddaaMs2 ?: existing.iddaaMs2 ?: incoming.iddaaMs2,
                htFtOdds = if (preferred.htFtOdds.isNotEmpty()) preferred.htFtOdds
                    else existing.htFtOdds.ifEmpty { incoming.htFtOdds },
                hasHtFt = existing.hasHtFt || incoming.hasHtFt,
                iddaaProgramUrl = preferred.iddaaProgramUrl ?: existing.iddaaProgramUrl ?: incoming.iddaaProgramUrl,
                matchTimestamp = preferredTimestamp,
                displayTime = preferred.displayTime.ifBlank { existing.displayTime.ifBlank { incoming.displayTime } },
                displayDate = preferred.displayDate.ifBlank { existing.displayDate.ifBlank { incoming.displayDate } }
            )
        }

        return merged.values.toList()
    }

    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    private fun dp(value: Int): Int =
        android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()


    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun diagnosticReportText(trace: ScanTrace): String {
        val sb = StringBuilder()
        sb.appendLine("SCAN DIAGNOSTIC PANEL [#${trace.scanId}]")
        sb.appendLine("MATCHER_CANONICAL_PIPELINE: ${GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}")
        sb.appendLine("BUILD_SIGNATURE: ${GlobalFixtureMatcher.BUILD_SIGNATURE}")
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        sb.appendLine("SÜRE: ${trace.totalDurationMs} ms | DURUM: $successful/${trace.parserReports.size} kaynak")
        sb.appendLine("PIPELINE TRACE")
        trace.stageMetrics.forEach { (stage, count) -> sb.appendLine("• ${stage.name} : $count") }
        sb.appendLine("MAÇ KÜMESİ / İDDAA ZENGİNLEŞTİRME")
        sb.appendLine("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        sb.appendLine("• İddaa ile zenginleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        sb.appendLine("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        sb.appendLine("• GEÇMİŞ MAÇ FİLTRESİ: ${trace.pastMatchFilteredCount} maç UI'dan çıkarıldı")
        if (trace.pastMatchFilteredDetails.isNotEmpty()) {
            trace.pastMatchFilteredDetails.take(10).forEach { sb.appendLine("   - $it | PAST_MATCH_FILTERED") }
        }
        sb.appendLine("• METADATA UZLAŞTIRMA: ${trace.reconciledKickoffCount} / ${trace.predictionFixtureCount} tahmin kickoff ile zenginleştirildi")
        if (trace.reconciledKickoffBySource.isNotEmpty()) {
            trace.reconciledKickoffBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        sb.appendLine("• KICKOFF EKSİK: ${trace.missingKickoffCount} maç UI'ya alınmadı")
        if (trace.missingKickoffBySource.isNotEmpty()) {
            trace.missingKickoffBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        sb.appendLine("• İddaa ile eşleşmeyen tahmin (ATILMADI): ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_NOT_IN_IDDAA KAYNAK DAĞILIMI:")
            trace.predictionNotInIddaaBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionNotInIddaaByReason.isNotEmpty()) {
            sb.appendLine("• EŞLEŞTİRME TEŞHİS DAĞILIMI:")
            trace.predictionNotInIddaaByReason.toSortedMap().forEach { (reason, count) ->
                sb.appendLine("   - $reason: $count")
            }
        }
        if (trace.metadataCompleteBySource.isNotEmpty()) {
            sb.appendLine("• KAYNAK METADATA SAĞLIĞI (tarih+saat+lig):")
            trace.metadataCompleteBySource.toSortedMap().forEach { (source, complete) ->
                val partial = trace.metadataPartialBySource[source] ?: 0
                val total = trace.metadataTotalBySource[source] ?: 0
                val missing = (total - complete).coerceAtLeast(0)
                sb.appendLine("   - $source: tam=$complete | kısmi=$partial | eksik=$missing | toplam=$total")
            }
        }
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            sb.appendLine("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        sb.appendLine("• İddaa dışında kalan tahmin (ATILMADI): ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_OUTSIDE_06_00 KAYNAK DAĞILIMI:")
            trace.predictionOutsideBulletinBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            sb.appendLine("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        trace.officialFeedDiagnostics?.let { f ->
            sb.appendLine("İDDAA RESMİ FEED TEŞHİSİ")
            sb.appendLine("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            sb.appendLine("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            sb.appendLine("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            sb.appendLine("• RAW EVENTS: ${f.rawEventCount}")
            sb.appendLine("• PARSED EVENTS: ${f.parsedEventCount}")
            sb.appendLine("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            sb.appendLine("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            sb.appendLine("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            sb.appendLine("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                sb.appendLine("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { sb.appendLine("   - $it") }
            }
            if (!f.error.isNullOrBlank()) sb.appendLine("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                sb.appendLine("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { sb.appendLine("   - $it") }
            }
        } ?: sb.appendLine("• İDDAA FEED SONUCU: alınamadı")
        trace.predictionSourceCoverage?.let { c ->
            sb.appendLine("İDDAA → TAHMİN KAYNAĞI KAPSAMA TEŞHİSİ")
            sb.appendLine("• Resmi fixture: ${c.officialFixtureCount} | Kaynak: ${c.sourceNames.size}")
            c.sourceNames.forEach { source ->
                sb.appendLine("   - $source: eşleşti=${c.matchedBySource[source] ?: 0} | kaynakta olup eşleşmedi=${c.presentButUnmatchedBySource[source] ?: 0} | parse edilen veride yok=${c.absentBySource[source] ?: 0}")
            }
            val reverseIssues = c.details.filter { it.status != PredictionCoverageStatus.MATCHED }
            sb.appendLine("• EŞLEŞMEYEN / EKSİK TERS KAPSAMA: ${reverseIssues.size}")
            reverseIssues.take(40).forEachIndexed { index, item ->
                sb.appendLine("   ${index + 1}. ${item.officialHome} vs ${item.officialAway} | ${item.source} | ${item.status.name} | ${item.reason} | SIM H=${String.format(java.util.Locale.US, "%.2f", item.homeSimilarity)} A=${String.format(java.util.Locale.US, "%.2f", item.awaySimilarity)}")
                if (item.bestPredictionHome.isNotBlank()) sb.appendLine("      EN YAKIN: ${item.bestPredictionHome} vs ${item.bestPredictionAway}")
            }
        }
        sb.appendLine("PARSER HEALTH")
        trace.parserReports.forEach { r ->
            sb.appendLine("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}")
        }
        sb.appendLine("DROPPED ITEMS")
        if (trace.dropReasons.isEmpty()) sb.appendLine("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            sb.appendLine("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        sb.appendLine("OFFICIAL NOT MATCHED DETAYLARI (${trace.unmatchedOfficialDiagnostics.size})")
        trace.unmatchedOfficialDiagnostics.forEachIndexed { index, item ->
            sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway}")
            if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway}")
            } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
            sb.appendLine("   TAHMİN CANONICAL: H=${item.homeCanonicalPrediction.ifBlank { "-" }} | A=${item.awayCanonicalPrediction.ifBlank { "-" }}")
            sb.appendLine("   İDDAA ADAY CANONICAL: H=${item.homeCanonicalOfficial.ifBlank { "-" }} | A=${item.awayCanonicalOfficial.ifBlank { "-" }}")
            sb.appendLine("   SIM: H=${"%.2f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.2f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.2f".format(java.util.Locale.US, item.combinedSimilarity)}")
            sb.appendLine("   TEŞHİS: ${diagnosticReasonLabel(item.probableReason)}")
        }
        return sb.toString()
    }

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SCAN DIAGNOSTIC PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyButton = Button(this).apply {
            text = "📋 KOPYALA"
            textSize = 11f
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("CioScore Scan Diagnostic", diagnosticReportText(trace)))
                Toast.makeText(this@MainActivity, "Teşhis raporu panoya kopyalandı.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(title)
        header.addView(copyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(header)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        fun addText(text: String, bold: Boolean = false, size: Float = 14f) {
            box.addView(TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 4, 0, 4)
            })
        }

        addText("MATCHER CANONICAL PIPELINE: ${com.cio.skor.data.GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}", true, 13f)
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        addText("SÜRE: ${trace.totalDurationMs} ms  •  DURUM: $successful/${trace.parserReports.size} kaynak", true)
        addText("PIPELINE TRACE", true, 16f)
        trace.stageMetrics.forEach { (stage, count) -> addText("• ${stage.name.padEnd(20)} : $count") }

        addText("MAÇ KÜMESİ / İDDAA ZENGİNLEŞTİRME", true, 16f)
        addText("• Skor tahminli benzersiz maç: ${trace.predictionFixtureCount}")
        addText("• İddaa ile zenginleşen tahminli maç: ${trace.officialMatchedPredictionCount}")
        addText("• İddaa-only maç: ${trace.officialOnlyFixtureCount}")
        addText("• İddaa ile eşleşmeyen tahmin (ATILMADI): ${trace.predictionNotInIddaaCount}")
        if (trace.predictionNotInIddaaDetails.isNotEmpty()) {
            addText("• İDDAA BÜLTENİNDE OLMAYAN ÖRNEKLER:")
            trace.predictionNotInIddaaDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        addText("• İddaa dışında kalan tahmin (ATILMADI): ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            addText("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { addText("   - $it", false, 12f) }
        }
        trace.officialFeedDiagnostics?.let { f ->
            addText("İDDAA RESMİ FEED TEŞHİSİ", true, 16f)
            addText("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            addText("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            addText("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            addText("• RAW EVENTS: ${f.rawEventCount}")
            addText("• PARSED EVENTS: ${f.parsedEventCount}")
            addText("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            addText("• BÜLTEN PENCERESİ İÇİNDE: ${f.bulletinEventCountBeforeMerge}")
            addText("• MERGE SONRASI RESMİ FİKSTÜR: ${f.mergedFixtureCount}")
            addText("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                addText("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { addText("   - $it", false, 12f) }
            }
            if (!f.error.isNullOrBlank()) addText("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                addText("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { addText("   - $it", false, 12f) }
            }
        } ?: addText("• İDDAA FEED SONUCU: alınamadı")
        trace.predictionSourceCoverage?.let { c ->
            addText("İDDAA → TAHMİN KAYNAĞI KAPSAMA TEŞHİSİ", true, 16f)
            addText("• Resmi fixture: ${c.officialFixtureCount} | Kaynak: ${c.sourceNames.size}")
            c.sourceNames.forEach { source ->
                addText("   - $source: eşleşti=${c.matchedBySource[source] ?: 0} | kaynakta olup eşleşmedi=${c.presentButUnmatchedBySource[source] ?: 0} | parse edilen veride yok=${c.absentBySource[source] ?: 0}", false, 12f)
            }
            val reverseIssues = c.details.filter { it.status != PredictionCoverageStatus.MATCHED }
            addText("• EŞLEŞMEYEN / EKSİK TERS KAPSAMA: ${reverseIssues.size}")
            reverseIssues.take(40).forEachIndexed { index, item ->
                addText("   ${index + 1}. ${item.officialHome} vs ${item.officialAway} | ${item.source} | ${item.status.name} | ${item.reason} | SIM H=${String.format(java.util.Locale.US, "%.2f", item.homeSimilarity)} A=${String.format(java.util.Locale.US, "%.2f", item.awaySimilarity)}", false, 11f)
                if (item.bestPredictionHome.isNotBlank()) addText("      EN YAKIN: ${item.bestPredictionHome} vs ${item.bestPredictionAway}", false, 11f)
            }
        }
        addText("PARSER HEALTH", true, 16f)
        trace.parserReports.forEach { r -> addText("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}") }
        addText("DROPPED ITEMS", true, 16f)
        if (trace.dropReasons.isEmpty()) addText("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            addText("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.show()
    }

    private fun diagnosticReasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.OFFICIAL_BULLETIN_ABSENT -> "⚫ OFFICIAL_BULLETIN_ABSENT"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "⚫ NO_OFFICIAL_CANDIDATE"
        UnmatchedReason.NAME_MISMATCH -> "🟠 NAME_MISMATCH"
        UnmatchedReason.DATE_MISMATCH -> "🔴 DATE_MISMATCH"
        UnmatchedReason.TIME_MISMATCH -> "🔴 TIME_MISMATCH"
        UnmatchedReason.COMPETITION_MISMATCH -> "🟣 COMPETITION_MISMATCH"
        UnmatchedReason.AMBIGUOUS_OFFICIAL_CANDIDATE -> "🟡 AMBIGUOUS_OFFICIAL_CANDIDATE"
        UnmatchedReason.METADATA_MISSING -> "🔵 METADATA_MISSING"
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "🟢 ALIAS_STEMMING_PROBLEM"
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        if (active) scanStatus.text = "${repo.sourceCount} kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!ScoreModel.hasRenderablePrediction(x.predictedScore)) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
