package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance

/** Robust cross-source team and fixture matching. */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()
    private val commonWords = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "cf", "sc", "ac", "rc", "club",
        "football", "soccer", "calcio", "de", "the", "and", "united", "utd"
    )

    private val aliases = mapOf(
        "jagielloniabialystok" to "jagiellonia",
        "kairatalmaty" to "kairat",
        "ferencvarosi" to "ferencvaros",
        "ferencvarosbudapest" to "ferencvaros",
        "jablonec97" to "jablonec",
        "rigafootballclub" to "riga",
        "rigafc" to "riga",
        "kiklaksvik" to "klaksvik",
        "agfaarhus" to "aarhus",
        "aarhusgf" to "aarhus",
        "fcthun" to "thun",
        "nkrĳeka" to "rijeka",
        "nkrijeka" to "rijeka",
        "partizanbelgrade" to "partizan",
        "interclubdescaldes" to "interescaldes",
        "interclubd_escaldes" to "interescaldes",
        "interdescaldes" to "interescaldes",
        "egnatiarogozhine" to "egnatia",
        "egnatiarogzhine" to "egnatia",
        "sinttruidense" to "sttruidense",
        "fcinter" to "interturku",
        "manchesterunited" to "manutd",
        "manchesterutd" to "manutd",
        "manutd" to "manutd",
        "manchestercity" to "mancity",
        "mancity" to "mancity",
        "tottenhamhotspur" to "tottenham",
        "psveindhoven" to "psv",
        "parissaintgermain" to "psg",
        "parissg" to "psg",
        "borussiadortmund" to "dortmund",
        "bayernmunich" to "bayern",
        "bayernmunchen" to "bayern"
    )

    fun normalizeTeamName(name: String): String {
        var s = name.lowercase()
            .replace("ç", "c").replace("ğ", "g").replace("ı", "i")
            .replace("ö", "o").replace("ş", "s").replace("ü", "u")
            .replace("á", "a").replace("à", "a").replace("ä", "a").replace("â", "a")
            .replace("é", "e").replace("è", "e").replace("ë", "e").replace("ê", "e")
            .replace("í", "i").replace("ì", "i").replace("ï", "i").replace("î", "i")
            .replace("ó", "o").replace("ò", "o").replace("õ", "o")
            .replace("ú", "u").replace("ù", "u").replace("û", "u")
            .replace("ý", "y").replace("ÿ", "y").replace("ñ", "n")
            .replace("š", "s").replace("ž", "z").replace("đ", "d")
            .replace("ð", "d").replace("þ", "th").replace("ß", "ss")
            .replace("æ", "ae").replace("œ", "oe").replace("ø", "o")

        s = s.replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = s.split(' ').filter { it.isNotBlank() && it !in commonWords }
        val compact = tokens.joinToString("")
        return aliases[compact] ?: compact
    }

    fun canonicalTeam(value: String): String = normalizeTeamName(value)

    fun isSameTeam(name1: String, name2: String): Boolean {
        val a = normalizeTeamName(name1)
        val b = normalizeTeamName(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        if (a.length >= 4 && (a.contains(b) || b.contains(a))) return true

        // Prefix/core comparison catches variants such as "jablonec97"/"jablonec".
        val shorter = if (a.length <= b.length) a else b
        val longer = if (a.length <= b.length) b else a
        if (shorter.length >= 5 && longer.startsWith(shorter)) return true

        val maxLength = maxOf(a.length, b.length)
        if (maxLength < 4) return false
        val distance = levenshtein.apply(a, b)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.75
    }

    fun key(home: String, away: String): String =
        normalizeTeamName(home) + "||" + normalizeTeamName(away)
}
