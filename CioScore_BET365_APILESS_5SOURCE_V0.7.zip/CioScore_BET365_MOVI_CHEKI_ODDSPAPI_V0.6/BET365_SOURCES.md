# CioScore Bet365 kaynak zinciri

WBookie bağlantısı ve WBookie servis dosyası kaldırıldı. Bet365 1X2 artık şu sırayla aranıyor:

1. **MoviOdds** — birincil kaynak. `GET /odds?sport=soccer&groups=40`, API anahtarı gerektirmez.
2. **ChekiOdds** — tarih sayfası üzerinden ikinci kaynak.
3. **OddsPapi** — üçüncü/fallback kaynak. API anahtarı gerekir.

## OddsPapi anahtarı

`app/build.gradle.kts` içindeki:

`buildConfigField("String", "ODDS_PAPI_API_KEY", "\"\"")`

satırına kendi OddsPapi anahtarını koy:

`buildConfigField("String", "ODDS_PAPI_API_KEY", "\"BURAYA_API_KEY\"")`

Anahtar boş bırakılırsa uygulama MoviOdds ve ChekiOdds ile çalışmaya devam eder; OddsPapi sadece devre dışı kalır.
