package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.util.concurrent.ConcurrentHashMap

/** API-key-free Bet365 1X2 fallback using 7M Sport's public odds HTML. */
class SevenMSportBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")
    private data class Row(val home: String, val away: String, val odds: SofaScoreService.BookmakerOdds)
    private val http = HttpClient()
    private val rows = ConcurrentHashMap<String, Row>()
    private var loadedAt = 0L

    companion object { private const val TTL_MS = 5 * 60 * 1000L }

    suspend fun preload() = withContext(Dispatchers.IO) {
        if (System.currentTimeMillis() - loadedAt < TTL_MS && rows.isNotEmpty()) return@withContext
        val urls = listOf(
            "https://live.7msport.com/default_odds_en.aspx?line=no",
            "https://live.7msport.com/default_odds_en.aspx"
        )
        var parsed = emptyMap<String, Row>()
        for (url in urls) {
            val (code, body) = http.get(url, "https://live.7msport.com/")
            if (code in 200..299 && !body.isNullOrBlank()) {
                parsed = parse(body)
                if (parsed.isNotEmpty()) break
            }
        }
        rows.clear(); rows.putAll(parsed); loadedAt = System.currentTimeMillis()
        if (rows.isEmpty()) throw IllegalStateException("7M Sport Bet365 1X2 bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String): Result = withContext(Dispatchers.IO) {
        runCatching { preload() }.getOrElse { return@withContext Result(reason = "7M Sport: ${it.message}") }
        lookup(homeTeam, awayTeam)
    }

    fun lookup(homeTeam: String, awayTeam: String): Result {
        val exact = rows[fixtureKey(homeTeam, awayTeam)]
        if (exact != null) return Result(exact.odds, "7M Sport • Bet365 1X2")
        val best = rows.values.asSequence()
            .map { it to ((TeamAliasCanonicalizer.similarity(homeTeam, it.home) + TeamAliasCanonicalizer.similarity(awayTeam, it.away)) / 2.0) }
            .filter { it.second >= 0.84 }.maxByOrNull { it.second }?.first
        return best?.let { Result(it.odds, "7M Sport • Bet365 1X2") }
            ?: Result(reason = "7M Sport'ta Bet365 1X2 eşleşmesi bulunamadı")
    }

    internal fun parse(body: String): Map<String, Row> {
        val doc = Jsoup.parse(body)
        val out = HashMap<String, Row>()
        for (tr in doc.select("tr")) {
            val text = tr.text()
            if (!text.contains("Bet365", true)) continue
            val cells = tr.select("td,th").map { it.text().trim() }.filter { it.isNotBlank() }
            if (cells.size < 4) continue
            val nums = Regex("\\b\\d{1,3}\\.\\d{1,3}\\b").findAll(text).map { it.value }.toList()
            if (nums.size < 3) continue
            val match = extractTeams(cells) ?: continue
            val odds = nums.takeLast(3)
            if (odds.all(::validOdd)) out[fixtureKey(match.first, match.second)] = Row(match.first, match.second, SofaScoreService.BookmakerOdds("Bet365", odds[0], odds[1], odds[2]))
        }
        return out
    }

    private fun extractTeams(cells: List<String>): Pair<String,String>? {
        val joined = cells.joinToString(" ")
        val parts = joined.split(" v ", " vs ", " - ", " – ", " — ", ignoreCase = true)
        if (parts.size >= 2) {
            val h = parts[0].replace(Regex("^.*?(?:\\d{1,2}:\\d{2})\\s+"), "").trim()
            val a = parts[1].replace(Regex("\\s+(?:Bet365|1xBet|SBOBET).*$", RegexOption.IGNORE_CASE), "").trim()
            if (h.isNotBlank() && a.isNotBlank()) return h to a
        }
        return null
    }

    private fun validOdd(s: String) = s.toDoubleOrNull()?.let { it > 1.0 && it < 1000.0 } == true
    private fun fixtureKey(home: String, away: String) = "${MatchMerger.canonicalTeamId(home)}||${MatchMerger.canonicalTeamId(away)}"
}
