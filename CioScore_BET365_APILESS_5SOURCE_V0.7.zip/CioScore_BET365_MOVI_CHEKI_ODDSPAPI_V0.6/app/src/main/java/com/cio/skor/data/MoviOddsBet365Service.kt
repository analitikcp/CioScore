package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Primary Bet365 source: MoviOdds.
 * GET /odds?sport=soccer&groups=40 exposes Bet365 Full Time Result (1X2)
 * without an API key.
 */
class MoviOddsBet365Service {
    data class Result(val odds: SofaScoreService.BookmakerOdds? = null, val reason: String = "")

    private data class Row(val home: String, val away: String, val odds: SofaScoreService.BookmakerOdds)
    private val http = HttpClient()
    private val rows = ConcurrentHashMap<String, Row>()
    private var loadedAt = 0L

    companion object { private const val TTL_MS = 2 * 60 * 1000L }

    suspend fun preload() = withContext(Dispatchers.IO) {
        if (System.currentTimeMillis() - loadedAt < TTL_MS && rows.isNotEmpty()) return@withContext
        val url = "https://moviodds.com/odds?sport=soccer&groups=40"
        val (code, body) = http.get(url, "https://moviodds.com/")
        if (code !in 200..299 || body.isNullOrBlank()) {
            throw IllegalStateException("MoviOdds HTTP $code")
        }
        val parsed = parse(body)
        rows.clear()
        rows.putAll(parsed)
        loadedAt = System.currentTimeMillis()
        if (rows.isEmpty()) throw IllegalStateException("MoviOdds 1X2 maç bulunamadı")
    }

    suspend fun fetch(homeTeam: String, awayTeam: String): Result = withContext(Dispatchers.IO) {
        runCatching { preload() }.getOrElse { return@withContext Result(reason = "MoviOdds: ${it.message}") }
        lookup(homeTeam, awayTeam)
    }

    fun lookup(homeTeam: String, awayTeam: String): Result {
        val exact = rows[fixtureKey(homeTeam, awayTeam)]
        if (exact != null) return Result(exact.odds, "MoviOdds • Bet365 1X2")
        val best = rows.values.asSequence()
            .map { it to ((TeamAliasCanonicalizer.similarity(homeTeam, it.home) + TeamAliasCanonicalizer.similarity(awayTeam, it.away)) / 2.0) }
            .filter { it.second >= 0.84 }
            .maxByOrNull { it.second }
            ?.first
        return best?.let { Result(it.odds, "MoviOdds • Bet365 1X2") }
            ?: Result(reason = "MoviOdds'da Bet365 1X2 eşleşmesi bulunamadı")
    }

    internal fun parse(body: String): Map<String, Row> {
        val root = JSONObject(body)
        val matches = root.optJSONArray("matches") ?: root.optJSONArray("fixtures") ?: return emptyMap()
        val out = HashMap<String, Row>()
        for (i in 0 until matches.length()) {
            val match = matches.optJSONObject(i) ?: continue
            val home = match.optString("home").trim()
            val away = match.optString("away").trim()
            if (home.isBlank() || away.isBlank()) continue
            val quotes = match.optJSONArray("quotes") ?: continue
            var h: String? = null
            var d: String? = null
            var a: String? = null
            for (j in 0 until quotes.length()) {
                val q = quotes.optJSONObject(j) ?: continue
                if (q.optString("group_id") != "40") continue
                val odd = q.optDouble("odds_dec", Double.NaN)
                if (!odd.isFinite() || odd <= 1.0 || odd > 1000.0) continue
                when (q.optString("label").trim()) {
                    home -> h = odd.toString()
                    "Draw", "X", "Tie" -> d = odd.toString()
                    away -> a = odd.toString()
                }
            }
            if (h != null && d != null && a != null) {
                val odds = SofaScoreService.BookmakerOdds("Bet365", h!!, d!!, a!!)
                out[fixtureKey(home, away)] = Row(home, away, odds)
            }
        }
        return out
    }

    private fun fixtureKey(home: String, away: String): String =
        "${MatchMerger.canonicalTeamId(home)}||${MatchMerger.canonicalTeamId(away)}"
}
