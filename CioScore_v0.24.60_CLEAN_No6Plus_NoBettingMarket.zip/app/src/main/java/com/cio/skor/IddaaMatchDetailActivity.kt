package com.cio.skor

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.cio.skor.data.IddaaMarketService
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Exact-match detail screen backed by the official Iddaa event feed.
 *
 * We intentionally do not fabricate a public iddaa.com /match/{id} URL: the current
 * public web program is a bulletin/search surface. The event id is still used as
 * the authoritative identity and this screen renders that exact official event.
 */
class IddaaMatchDetailActivity : AppCompatActivity() {
    private val service = IddaaMarketService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val matchId = intent.getStringExtra(EXTRA_MATCH_ID).orEmpty().trim()
        val home = intent.getStringExtra(EXTRA_HOME).orEmpty()
        val away = intent.getStringExtra(EXTRA_AWAY).orEmpty()
        val date = intent.getStringExtra(EXTRA_DATE).orEmpty()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        setContentView(root)

        val title = TextView(this).apply {
            text = "⚽ İDDAA MAÇ DETAYI"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF10233A.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, lp())

        val teams = TextView(this).apply {
            text = if (home.isNotBlank() && away.isNotBlank()) "$home  –  $away" else "Maç yükleniyor…"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF243B53.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        }
        root.addView(teams, lp())

        val info = TextView(this).apply {
            text = if (date.isNotBlank()) "İddaa resmi maç kimliği: $matchId\n$date" else "İddaa resmi maç kimliği: $matchId"
            textSize = 12f
            setTextColor(0xFF60758A.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(info, lp())

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val loading = TextView(this).apply {
            text = "Resmi İddaa verisi yükleniyor…"
            textSize = 15f
            setTextColor(0xFF52677D.toInt())
            gravity = Gravity.CENTER
        }
        body.addView(loading, lp())

        val bulletinButton = TextView(this).apply {
            text = "↗ RESMİ İDDAA BÜLTENİNİ AÇ"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF00796B.toInt())
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setOnClickListener {
                val url = "https://www.iddaa.com/program/futbol?date=${Uri.encode(date)}&searchTerm=${Uri.encode("$home $away")}" 
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
            }
        }
        root.addView(bulletinButton, lp().apply { topMargin = dp(8) })

        if (matchId.isBlank()) {
            loading.text = "Bu kartta resmi İddaa maç kimliği bulunamadı."
            return
        }

        lifecycleScope.launch {
            val match = runCatching { service.fetchMatchById(matchId) }.getOrNull()
            body.removeAllViews()
            if (match == null) {
                body.addView(TextView(this@IddaaMatchDetailActivity).apply {
                    text = "Bu maçın resmi İddaa verisi şu anda alınamadı.\n\nMaç kimliği: $matchId"
                    textSize = 15f
                    setTextColor(0xFFB42318.toInt())
                    gravity = Gravity.CENTER
                }, lp())
                return@launch
            }

            addLine(body, "🕐 Başlangıç", match.matchTime)
            addLine(body, "🏆 Lig", match.competitionName.ifBlank { "—" })
            addLine(body, "🆔 İddaa maç kimliği", match.matchId)

            val ms = listOfNotNull(
                match.ms1?.let { "MS 1  $it" },
                match.msX?.let { "MS X  $it" },
                match.ms2?.let { "MS 2  $it" }
            )
            if (ms.isNotEmpty()) addLine(body, "📊 Maç Sonucu", ms.joinToString("   |   "))

            if (match.htFtOdds.isNotEmpty()) {
                addLine(body, "⏱ HT/FT", match.htFtOdds.entries.joinToString("   |   ") { "${it.key} ${it.value}" })
            }

        }
    }

    private fun addLine(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        row.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF66788A.toInt())
        }, lp())
        row.addView(TextView(this).apply {
            text = value
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF152A3D.toInt())
            setPadding(0, dp(3), 0, 0)
        }, lp())
        parent.addView(row, lp().apply { bottomMargin = dp(8) })
    }

    private fun lp() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_MATCH_ID = "iddaa_match_id"
        const val EXTRA_HOME = "iddaa_home"
        const val EXTRA_AWAY = "iddaa_away"
        const val EXTRA_DATE = "iddaa_date"
    }
}
