package com.cio.skor.data

import android.content.Context
import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import java.text.Normalizer
import java.util.Locale

/**
 * API-free Bet365 fallback.
 *
 * GoalLineExpert's public football monitor is Bet365-first and publishes the
 * current/opening 1X2 prices for upcoming fixtures. We read only the public
 * HTML/text page; no CAPTCHA/JS challenge is bypassed.
 */
class GoalLineExpertBet365Service(context: Context? = null) {
    data class Odds(val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()
    private val prefs = context?.getSharedPreferences("bet365_cache", Context.MODE_PRIVATE)

    @Volatile private var cachedAtMs: Long = 0L
    @Volatile private var cachedText: String = ""

    private fun loadPage(): String {
        val now = System.currentTimeMillis()
        if (cachedText.isNotBlank() && now - cachedAtMs < CACHE_TTL_MS) return cachedText

        val urls = listOf(
            "https://goallineexpert.com/?page=dropping_odds",
            "https://goallineexpert.com/?lang=en&page=dropping_odds"
        )
        for (url in urls) {
            val (code, body) = http.getSource(url, "https://goallineexpert.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            val text = Jsoup.parse(body).body().text()
            if (text.isBlank()) continue
            cachedText = text
            cachedAtMs = now
            return text
        }
        return cachedText
    }

    fun fetch(homeTeam: String, awayTeam: String): Odds? {
        val text = loadPage()
        if (text.isNotBlank()) {
            parseMatch(text, homeTeam, awayTeam)?.also { odds ->
                save(homeTeam, awayTeam, odds)
                return odds
            }
        }
        return loadCached(homeTeam, awayTeam)
    }

    private fun parseMatch(page: String, wantedHome: String, wantedAway: String): Odds? {
        val compact = page.replace(Regex("\\s+"), " ").trim()
        val home = normalize(wantedHome)
        val away = normalize(wantedAway)
        if (home.isBlank() || away.isBlank()) return null

        // Prefer the explicit public match-card marker (📊). This keeps one
        // match isolated from its neighbours even when the page contains many
        // Bet365 rows.
        val markers = mutableListOf<Int>()
        var cursor = 0
        while (true) {
            val p = compact.indexOf("📊", cursor)
            if (p < 0) break
            markers += p
            cursor = p + 2
        }

        for (marker in markers) {
            val left = maxOf(0, marker - 220)
            val right = minOf(compact.length, marker + 1500)
            val block = compact.substring(left, right)
            if (!sameTeamPresent(block, home) || !sameTeamPresent(block, away)) continue
            if (!block.contains("Bet365", ignoreCase = true)) continue
            val oddsSection = block.substringAfter("1X2", "", ignoreCase = true)
                .substringBefore("Asian Handicap", "", ignoreCase = true)
                .substringBefore("Total Goals", "", ignoreCase = true)
            parseOneXTwo(oddsSection)?.let { return it }
        }

        // Marker-less fallback for localized/minified pages.
        var bet365Pos = 0
        while (true) {
            val p = compact.indexOf("Bet365", bet365Pos, ignoreCase = true)
            if (p < 0) break
            val left = maxOf(0, p - 260)
            val right = minOf(compact.length, p + 1000)
            val block = compact.substring(left, right)
            if (sameTeamPresent(block, home) && sameTeamPresent(block, away)) {
                val oddsSection = block.substringAfter("1X2", "", ignoreCase = true)
                    .substringBefore("Asian Handicap", "", ignoreCase = true)
                    .substringBefore("Total Goals", "", ignoreCase = true)
                parseOneXTwo(oddsSection)?.let { return it }
            }
            bet365Pos = p + 7
        }
        return null
    }

    private fun parseOneXTwo(section: String): Odds? {
        if (section.isBlank()) return null
        val home = parseSelection(section, "1") ?: return null
        val draw = parseSelection(section, "X") ?: return null
        val away = parseSelection(section, "2") ?: return null
        return Odds(home, draw, away)
    }

    /** First decimal is the current price; second decimal is opening price. */
    private fun parseSelection(section: String, label: String): String? {
        val re = Regex("(?:^|\\s)$label(?:▲|▼|=)?\\s*(\\d+(?:[.,]\\d+)?)(?:\\s+(\\d+(?:[.,]\\d+)?))?(?=\\s|$)")
        val m = re.find(section) ?: return null
        val value = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        if (value <= 1.0 || value > 100.0) return null
        return String.format(Locale.US, "%.2f", value)
    }

    private fun sameTeamPresent(block: String, wanted: String): Boolean {
        val n = normalize(block)
        if (n.contains(wanted)) return true
        // Provider suffixes/prefixes such as Women, FC, CF, Academical are
        // removed by normalize(), so a shorter official bulletin name can match.
        val tokens = wanted.chunked(4).filter { it.length >= 4 }
        return tokens.isNotEmpty() && tokens.count { n.contains(it) } >= minOf(2, tokens.size)
    }

    private fun normalize(value: String): String {
        val noAccent = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .lowercase(Locale.US)
        return noAccent
            .replace("ı", "i")
            .replace("&", " and ")
            .replace(Regex("\\b(k|w|f|women|woman|womens|female|fem|ladies|fc|cf|afc|sc|ac|as|sk|cd|ue)\\b"), " ")
            .replace(Regex("[^a-z0-9]+"), "")
    }

    private fun key(home: String, away: String): String = "${normalize(home)}::${normalize(away)}"

    private fun save(home: String, away: String, odds: Odds) {
        prefs?.edit()
            ?.putString(key(home, away), "${odds.ms1}|${odds.msX}|${odds.ms2}")
            ?.putLong("${key(home, away)}:time", System.currentTimeMillis())
            ?.apply()
    }

    private fun loadCached(home: String, away: String): Odds? {
        val p = prefs ?: return null
        val stamp = p.getLong("${key(home, away)}:time", 0L)
        if (stamp <= 0L || System.currentTimeMillis() - stamp > MAX_CACHE_AGE_MS) return null
        val raw = p.getString(key(home, away), null) ?: return null
        val parts = raw.split('|')
        if (parts.size != 3) return null
        return Odds(parts[0], parts[1], parts[2])
    }

    companion object {
        private const val CACHE_TTL_MS = 90_000L
        private const val MAX_CACHE_AGE_MS = 6 * 60 * 60 * 1000L
    }
}
