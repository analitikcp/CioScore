package com.cio.skor.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Global fixture identity engine.
 *
 * IMPORTANT: matching is done on ALL records before UI rendering.  There is no
 * greedy "find first existing card" step.  The official Iddaa event is an
 * anchor, while team identity + kickoff metadata are supporting evidence.
 */
object GlobalFixtureMatcher {
    private const val TEAM_FLOOR = 0.72
    private const val STRONG_TEAM = 0.90
    private const val MERGE_THRESHOLD = 0.84
    private const val OFFICIAL_THRESHOLD = 0.74
    private const val TIME_SOFT_WINDOW_MS = 90L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 18L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    )

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val idAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean
    )

    private class DSU(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)

        fun find(x: Int): Int {
            var n = x
            while (parent[n] != n) n = parent[n]
            val root = n
            var cur = x
            while (parent[cur] != cur) {
                val next = parent[cur]
                parent[cur] = root
                cur = next
            }
            return root
        }

        fun union(a: Int, b: Int) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) { val t = ra; ra = rb; rb = t }
            parent[rb] = ra
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)
        scraped.forEach { s ->
            records += Record(
                homeTeam = s.homeTeam,
                awayTeam = s.awayTeam,
                predictedScore = s.predictedScore,
                source = s.source,
                sourceMatchId = s.sourceMatchId,
                matchTimestamp = s.matchTimestamp,
                matchDate = s.matchDate,
                matchTime = s.matchTime
            )
        }
        officialMatches.forEach { o ->
            records += Record(
                homeTeam = o.homeTeam,
                awayTeam = o.awayTeam,
                source = "IDDAA",
                sourceMatchId = o.matchId,
                matchTimestamp = o.matchTimestamp,
                matchDate = o.matchDate,
                matchTime = o.matchTime,
                official = o
            )
        }
        if (records.isEmpty()) return emptyList()

        val dsu = DSU(records.size)

        // 1) Official Iddaa matchId is an absolute anchor inside the official feed.
        val officialIds = HashMap<String, Int>()
        records.indices.forEach { i ->
            val r = records[i]
            val id = r.sourceMatchId.trim()
            if (r.official != null && id.isNotBlank()) {
                officialIds[id]?.let { dsu.union(it, i) } ?: officialIds.put(id, i)
            }
        }

        // 2) Exact canonical fixture identity. This alone handles common cases such
        // as AEK Athens/AΕK Atina and LASK/LASK Linz after alias canonicalization.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { i ->
            exactBuckets.getOrPut(fixtureKey(records[i])) { mutableListOf() }.add(i)
        }
        exactBuckets.values.forEach { ids ->
            for (k in 1 until ids.size) dsu.union(ids[0], ids[k])
        }

        // 3) Fuzzy global pass. The previous implementation used a 3-character
        // home/away blocking key. That can silently prevent a valid cross-source
        // match from ever being compared. Here we use a broader first-letter block
        // only as a performance guard, while exact canonical buckets above remain
        // the fast path. With six sources the resulting candidate set is small.
        val candidateBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { i ->
            candidateBuckets.getOrPut(broadSignature(records[i])) { mutableListOf() }.add(i)
        }

        candidateBuckets.values.forEach { ids ->
            for (x in ids.indices) {
                for (y in x + 1 until ids.size) {
                    val i = ids[x]
                    val j = ids[y]
                    val a = records[i]
                    val b = records[j]

                    // Different IDs from the same provider must not be collapsed
                    // solely by fuzzy team names. Official Iddaa is handled separately.
                    if (sameSourceDifferentIds(a, b)) continue

                    if (score(a, b).accepted) dsu.union(i, j)
                }
            }
        }

        // 4) A second pass across DSU component representatives. This is deliberate:
        // if A matches B and B matches C, the whole connected component is one
        // fixture. We never let an arrival-order/greedy decision split it again.
        val roots = records.indices.map { dsu.find(it) }.distinct()
        for (x in roots.indices) {
            for (y in x + 1 until roots.size) {
                val ra = roots[x]
                val rb = roots[y]
                if (dsu.find(ra) != ra || dsu.find(rb) != rb) continue
                val a = records[ra]
                val b = records[rb]
                if (sameSourceDifferentIds(a, b)) continue
                if (score(a, b).accepted) dsu.union(ra, rb)
            }
        }

        val grouped = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { i ->
            grouped.getOrPut(dsu.find(i)) { mutableListOf() }.add(records[i])
        }

        return grouped.values.map(::buildUnified)
    }

    private fun fixtureKey(r: Record): String =
        "${TeamAliasCanonicalizer.canonical(r.homeTeam)}||${TeamAliasCanonicalizer.canonical(r.awayTeam)}"

    private fun broadSignature(r: Record): String {
        fun sig(value: String): String {
            val c = TeamAliasCanonicalizer.compact(value)
            if (c.isBlank()) return "#"
            // First and last character catches suffix/prefix changes while still
            // keeping the candidate list bounded for a daily football slate.
            return if (c.length == 1) c else "${c.first()}${c.last()}"
        }
        return "${sig(r.homeTeam)}|${sig(r.awayTeam)}"
    }

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, true)) return false
        val ia = a.sourceMatchId.trim()
        val ib = b.sourceMatchId.trim()
        return ia.isNotBlank() && ib.isNotBlank() && ia != ib
    }

    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() ||
            b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, false, 0.0, false)
        }

        val home = TeamAliasCanonicalizer.similarity(a.homeTeam, b.homeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.awayTeam, b.awayTeam)
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
            TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val teamScore = (home + away) / 2.0
        val idAnchor = sameComparableId(a, b)

        if (idAnchor) return MatchEvidence(home, away, teamScore, 1.0, true, 1.0, true)

        if (home < TEAM_FLOOR || away < TEAM_FLOOR) {
            return MatchEvidence(home, away, teamScore, timeScore(a, b), false, 0.0, false)
        }

        val time = timeScore(a, b)
        if (time < 0.0) return MatchEvidence(home, away, teamScore, time, false, 0.0, false)

        // Exact teams are trusted even if one source did not provide kickoff data.
        if (exactTeams) return MatchEvidence(home, away, 1.0, time, false, 0.96, true)

        var confidence = 0.70 * teamScore + 0.30 * time.coerceAtLeast(0.0)
        if (home >= STRONG_TEAM && away >= STRONG_TEAM) confidence += 0.06
        if (time >= 0.95) confidence += 0.04
        confidence = confidence.coerceIn(0.0, 0.99)

        val accepted = if (a.official != null || b.official != null) {
            teamScore >= OFFICIAL_THRESHOLD
        } else {
            confidence >= MERGE_THRESHOLD
        }
        return MatchEvidence(home, away, teamScore, time, false, confidence, accepted)
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val ia = a.sourceMatchId.trim()
        val ib = b.sourceMatchId.trim()
        if (ia.isBlank() || ib.isBlank() || ia != ib) return false
        return a.source.equals(b.source, true) || (a.official != null && b.official != null)
    }

    /** 1 = close kickoff, 0 = no usable time, -1 = hard contradiction. */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            if (delta <= TIME_SOFT_WINDOW_MS) {
                return 1.0 - delta.toDouble() / TIME_SOFT_WINDOW_MS * 0.10
            }
            return 0.90 - (delta - TIME_SOFT_WINDOW_MS).toDouble() /
                (TIME_HARD_WINDOW_MS - TIME_SOFT_WINDOW_MS) * 0.90
        }

        val da = parseDate(a.matchDate)
        val db = parseDate(b.matchDate)
        if (da != null && db != null) return if (da == db) 0.92 else -1.0
        return 0.0
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) {
            runCatching { return LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern)) }
        }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(display.first, display.second, officialMatch = official)
        result.officialMatchId = official?.matchId.orEmpty()

        // Exactly one visible prediction per source. The merge therefore produces
        // one card with up to five prediction filters, never one card per source.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { it.predictedScore != null }.forEach { r ->
            val key = r.source.trim().lowercase()
            val old = bySource[key]
            if (old == null || sourcePriority(r) > sourcePriority(old)) bySource[key] = r
        }
        bySource.values.forEach { r ->
            result.predictions += r.source to r.predictedScore.orEmpty()
        }

        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun chooseDisplay(
        group: List<Record>,
        official: IddaaMarketService.OpenedMarketMatch?
    ): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull {
            TeamAliasCanonicalizer.canonical(it.homeTeam).length +
                TeamAliasCanonicalizer.canonical(it.awayTeam).length
        } ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourcePriority(r: Record): Int {
        var p = 0
        if (r.matchTimestamp > 0L) p += 2
        if (r.predictedScore != null) p += 5
        if (r.sourceMatchId.isNotBlank()) p += 1
        return p
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        var total = 0.0
        var count = 0
        for (i in 0 until group.lastIndex) {
            for (j in i + 1..group.lastIndex) {
                val e = score(group[i], group[j])
                if (e.accepted) {
                    total += e.confidence
                    count++
                }
            }
        }
        return if (count == 0) 1.0 else total / count
    }
}
