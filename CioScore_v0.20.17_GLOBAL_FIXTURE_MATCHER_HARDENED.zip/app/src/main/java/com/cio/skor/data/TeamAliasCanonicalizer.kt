package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer

/**
 * Converts source-specific club names to a stable team identity.
 *
 * The important rule is: never delete arbitrary meaningful words globally.
 * For example LINZ and IFK are not generic stop-words. Only explicit aliases
 * or safe club-type edge tokens are removed.
 */
object TeamAliasCanonicalizer {
    private val removableEdgeTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio"
    )

    private val aliases = mapOf(
        "aek" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek athens" to "aek athens",
        "lask linz" to "lask",
        "lask" to "lask",
        "ifk mariehamn" to "ifk mariehamn",
        "mariehamn" to "ifk mariehamn",
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "man city" to "manchester city",
        "spurs" to "tottenham hotspur",
        "tottenham" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",
        "newcastle" to "newcastle united",
        "newcastle utd" to "newcastle united",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "cardiff" to "cardiff city",
        "stoke" to "stoke city",
        "norwich" to "norwich city",
        "coventry" to "coventry city",
        "leicester" to "leicester city",
        "swansea" to "swansea city",
        "birmingham" to "birmingham city",
        "hull" to "hull city",
        "lincoln" to "lincoln city"
    )

    fun canonical(name: String): String {
        if (name.isBlank()) return ""
        var value = name.trim().lowercase()
            .replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i')
            .replace('ö', 'o').replace('ş', 's').replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss").replace("æ", "ae").replace("œ", "oe")
            .replace("ø", "o").replace("ð", "d").replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        var tokens = value.split(' ').filter(String::isNotBlank).toMutableList()
        // Transliteration is token-aware: never replace a substring inside a real
        // club name (for example Panathinaikos must stay Panathinaikos).
        tokens = tokens.map {
            when (it) {
                "athina", "atina" -> "athens"
                else -> it
            }
        }.toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in removableEdgeTokens) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in removableEdgeTokens) tokens.removeAt(tokens.lastIndex)
        value = tokens.joinToString(" ")

        // Alias lookup is intentionally performed after all token normalization.
        // This makes AEK Atina, AEK Athina and AEK Athens converge to one identity.
        return aliases[value] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        return a.isNotBlank() && a == b
    }

    /** Similarity combines token overlap and edit distance, avoiding blind contains(). */
    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0

        val ta = a.split(' ').toSet()
        val tb = b.split(' ').toSet()
        val intersection = ta.intersect(tb).size.toDouble()
        val union = ta.union(tb).size.toDouble().coerceAtLeast(1.0)
        val jaccard = intersection / union

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        val max = maxOf(ca.length, cb.length)
        val edit = if (max == 0) 1.0 else 1.0 - levenshtein(ca, cb).toDouble() / max

        // Exact token overlap is valuable; edit distance handles transliteration/typos.
        return (0.60 * edit + 0.40 * jaccard).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean {
        if (exact(name1, name2)) return true
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.length < 3 || b.length < 3) return false
        return similarity(a, b) >= 0.90
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val replace = prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(replace, prev[j] + 1, cur[j - 1] + 1)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }
}
