package com.cio.skor.data

/**
 * Backward-compatible facade. New matching logic lives in GlobalFixtureMatcher.
 * Existing UI code can continue to call MatchMerger.key/normalizeTeamName/etc.
 */
object MatchMerger {
    fun normalizeTeamName(name: String): String = TeamAliasCanonicalizer.canonical(name)
    fun key(homeTeam: String, awayTeam: String): String =
        "${TeamAliasCanonicalizer.canonical(homeTeam)}||${TeamAliasCanonicalizer.canonical(awayTeam)}"
    fun isSameTeam(name1: String, name2: String): Boolean =
        TeamAliasCanonicalizer.isSameTeam(name1, name2)

    fun mergeMatches(
        scrapedList: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()
    ): List<GlobalFixtureMatcher.UnifiedMatch> = GlobalFixtureMatcher.merge(scrapedList, officialMatches)
}
