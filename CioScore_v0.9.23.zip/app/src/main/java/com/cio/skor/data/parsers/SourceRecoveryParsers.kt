package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * v0.9.17 last-mile DOM recovery.
 *
 * These are still provider-specific rules. They are intentionally not a generic
 * score parser: each branch is tied to the provider's own marker/link shape.
 * The normal parser remains the first pass; recovery only fills records the
 * provider page exposed but the primary selector missed.
 */
object SourceRecoveryParsers {
    fun parse(source: String, doc: Document): List<ScoreModel> = when (source) {
        "PredictZ" -> predictZ(doc)
        "Correct-Score.net" -> correctScoreNet(doc)
        else -> emptyList()
    }

    private fun predictZ(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val score = Regex("(?i)(?:correct\\s*score|predicted\\s*score|pick)[^0-9]{0,60}([0-5])\\s*[-:]\\s*([0-5])\\b")
        for (link in doc.select("a[href*=/picks/], a[href*=/predictions/], a[href*=/football/]") ) {
            val container = nearest(link) ?: continue
            val text = clean(container.text())
            val sm = score.find(text) ?: continue
            val teams = splitTeams(link.text()) ?: splitSlug(link.attr("href")) ?: continue
            val item = model("PredictZ", teams.first, teams.second, "${sm.groupValues[1]}-${sm.groupValues[2]}", container) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun correctScoreNet(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val score = Regex("(?i)correct\\s*score[^0-9]{0,40}([0-5])\\s*[-:]\\s*([0-5])\\b")
        for (link in doc.select("a[href*=/predictions/]") ) {
            val container = nearest(link) ?: continue
            val sm = score.find(clean(container.text())) ?: continue
            val teams = splitTeams(link.text()) ?: splitSlug(link.attr("href")) ?: continue
            val item = model("Correct-Score.net", teams.first, teams.second, "${sm.groupValues[1]}-${sm.groupValues[2]}", container) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun nearest(link: Element): Element? {
        var n: Element? = link
        repeat(7) {
            n = n?.parent()
            val e = n ?: return null
            val len = e.text().length
            if (len in 30..3000) return e
        }
        return null
    }

    private fun splitTeams(raw: String): Pair<String, String>? {
        val t = clean(raw)
        val m = Regex("(?i)^(.+?)\\s+(?:v|vs|versus)\\s+(.+)$").find(t) ?: return null
        val h = cleanTeam(m.groupValues[1]); val a = cleanTeam(m.groupValues[2])
        return if (looksTeam(h) && looksTeam(a)) h to a else null
    }

    private fun splitSlug(href: String): Pair<String, String>? {
        val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/').lowercase()
            .replace(Regex("-(?:prediction|predictions|tips?|correct-score|odds).*$"), "")
        val markers = listOf("-vs-", "-v-", "-versus-")
        for (m in markers) {
            val i = slug.indexOf(m)
            if (i <= 0) continue
            val h = cleanTeam(slug.substring(0, i).replace('-', ' '))
            val a = cleanTeam(slug.substring(i + m.length).replace('-', ' '))
            if (looksTeam(h) && looksTeam(a)) return h to a
        }
        return null
    }

    private fun model(source: String, home: String, away: String, score: String, scope: Element): ScoreModel? {
        val h = cleanTeam(home); val a = cleanTeam(away)
        if (!looksTeam(h) || !looksTeam(a) || h.equals(a, true)) return null
        val parser = object : BaseParser(source) { override fun parse(doc: Document): List<ScoreModel> = emptyList() }
        val meta = parser.extractFixtureMetadata(scope)
        return ScoreModel(h, a, score, source,
            sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
            matchTimestamp = meta.matchTimestamp, matchDate = meta.matchDate,
            matchTime = meta.matchTime, competitionName = meta.competitionName,
            competitionCountry = meta.competitionCountry)
    }

    private fun cleanTeam(raw: String): String = clean(raw)
        .replace(Regex("(?i)\\b(?:correct score|prediction|predictions|tips?|odds|details|view)\\b.*$"), " ")
        .replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')

    private fun looksTeam(value: String): Boolean {
        val v = cleanTeam(value)
        if (v.length !in 2..90) return false
        if (v.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        if (v.matches(Regex("(?i)^(correct score|prediction|predictions|tip|tips|odds|details|view|home|away|draw|score)$"))) return false
        return true
    }

    private fun clean(value: String): String = value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
}
