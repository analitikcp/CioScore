package com.cio.skor.data

import org.junit.Assert.assertEquals
import org.junit.Test

class SourceParserV0923Test {
    @Test fun repositoryKeepsExactlyTenActiveSources() {
        val repo = ScraperRepository()
        assertEquals(10, repo.sourceCount)
        assertEquals(
            listOf(
                "FP.com", "PredictZ", "WinDrawWin", "DailySports", "Sports Mole",
                "BallPrediction", "Correct-Score.net", "FootballScorePredictor",
                "AccurateTip", "FutHead Predictions"
            ),
            repo.sourceNames
        )
    }
}
