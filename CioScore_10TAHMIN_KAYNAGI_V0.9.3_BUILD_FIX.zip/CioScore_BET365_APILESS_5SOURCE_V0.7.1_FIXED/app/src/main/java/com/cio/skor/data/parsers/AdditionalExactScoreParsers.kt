package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Source-specific, API-free exact-score parsers.
 *
 * Each provider has a different public HTML layout. These parsers intentionally
 * do not share one broad prediction regex: a score is accepted only when it is
 * found in the provider's own fixture/prediction structure.
 */

private fun cleanProviderTeam(raw: String): String = raw
    .replace(Regex("(?i)\\bimage\\b"), " ")
    .replace(Regex("(?i)\\b(?:our pick|correct score|predicted score|prediction)\\b.*$"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':')

private fun looksLikeProviderTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.contains(Regex("(?i)^(time|date|details|predict|prediction|correct score|our pick|odds|score|home|away|draw|vs|x|1x2)$"))) return false
    return true
}

private fun scoreFrom(text: String): String? {
    val m = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)").find(text) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null
    val a = m.groupValues[2].toIntOrNull() ?: return null
    return if (h in 0..20 && a in 0..20) "$h-$a" else null
}

private fun model(source: String, home: String, away: String, score: String, scope: Element): ScoreModel? {
    val h = cleanProviderTeam(home)
    val a = cleanProviderTeam(away)
    if (!looksLikeProviderTeam(h) || !looksLikeProviderTeam(a) || h.equals(a, true)) return null
    return ScoreModel(
        homeTeam = h,
        awayTeam = a,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
    )
}

/** Sports Mole: preview articles use the explicit "We say: Home 2-1 Away" line. */
class SportsMoleExactScoreParser : BaseParser("Sports Mole") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val marker = Regex("(?i)we[ \\t]+say[ \\t]*:[ \\t]*(.+?)[ \\t]+(\\d{1,2})[ \\t]*-[ \\t]*(\\d{1,2})[ \\t]+(.+?)(?=[.!?]|$)")
        for (el in (doc.select("strong, b, p, h2, h3") + doc.select("article, .article, [class*=preview]")).distinct()) {
            val text = clean(el.text())
            if (text.length > 1200 || !text.contains(Regex("(?i)we say:"))) continue
            for (m in marker.findAll(text)) {
                val score = "${m.groupValues[2]}-${m.groupValues[3]}"
                val item = model("Sports Mole", m.groupValues[1], m.groupValues[4], score, el) ?: continue
                out.putIfAbsent(item.matchKey, item)
            }
        }
        return out.values.toList()
    }
}

/** Forebet: match/preview cards expose a Correct score field next to the fixture. */
class ForebetExactScoreParser : BaseParser("Forebet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, .match, [class*=match], [class*=fixture], article")
        for (el in scopes) {
            val text = clean(el.text())
            if (!text.contains(Regex("(?i)correct score"))) continue
            val score = scoreFrom(text) ?: continue
            val teams = teamCandidates(el)
            if (teams.size < 2) continue
            val item = model("Forebet", teams[0], teams[1], score, el) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun teamCandidates(el: Element): List<String> {
        val imgs = el.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("data-team")) }
            .map(::cleanProviderTeam).filter(::looksLikeProviderTeam).distinct()
        if (imgs.size >= 2) return imgs.take(2)
        return el.select("a, td, [class*=team], [class*=home], [class*=away]")
            .map { cleanProviderTeam(it.text()) }
            .filter(::looksLikeProviderTeam)
            .filterNot { it.matches(Regex("(?i)^(correct score|pred|score|preview|live)$")) }
            .distinct().take(2)
    }
}

/** Correct-Score.net: cards explicitly contain Home VS Away OUR PICK score. */
class CorrectScoreNetParser : BaseParser("Correct-Score.net") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val pattern = Regex("(?i)(.+?)\\s+VS\\s+(.+?)\\s+OUR[ \\t]*PICK[ \\t]*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})")
        for (el in doc.select("article, section, [class*=match], [class*=fixture], main")) {
            val text = clean(el.text())
            if (text.length > 4000 || !text.contains(Regex("(?i)our[ \\t]*pick"))) continue
            val m = pattern.find(text) ?: continue
            val item = model("Correct-Score.net", m.groupValues[1], m.groupValues[2], "${m.groupValues[3]}-${m.groupValues[4]}", el) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** BallPrediction: fixture pages/list cards expose a Correct score block. */
class BallPredictionExactScoreParser : BaseParser("BallPrediction") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("article, section, [class*=match], [class*=prediction], main")
        val headingPattern = Regex("(?i)^(.+?)\\s+vs\\s+(.+?)\\s+prediction(?:$|\\s)")
        for (el in scopes) {
            val text = clean(el.text())
            if (!text.contains(Regex("(?i)correct score"))) continue
            val scoreMatch = Regex("(?i)correct score[ \\t]*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text) ?: continue
            val h = headingPattern.find(text)?.groupValues?.get(1)
            val a = headingPattern.find(text)?.groupValues?.get(2)
            if (h.isNullOrBlank() || a.isNullOrBlank()) continue
            val item = model("BallPrediction", h, a, "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}", el) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** Football Score Predictor: prediction tables place home/predicted/away in the same row. */
class FootballScorePredictorParser : BaseParser("FootballScorePredictor") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("table tr")) {
            val cells = row.select("th, td").map { clean(it.text()) }.filter { it.isNotBlank() }
            if (cells.size < 3) continue
            val score = scoreFrom(cells.joinToString(" ")) ?: continue
            val scoreIndex = cells.indexOfFirst { scoreFrom(it) != null }
            val home = cells.firstOrNull().orEmpty()
            val away = cells.drop((scoreIndex + 1).coerceAtLeast(1)).firstOrNull { looksLikeProviderTeam(stripForm(it)) }.orEmpty()
            val cleanHome = stripForm(home)
            val cleanAway = stripForm(away)
            if (!looksLikeProviderTeam(cleanHome) || !looksLikeProviderTeam(cleanAway)) continue
            val item = model("FootballScorePredictor", cleanHome, cleanAway, score, row) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun stripForm(value: String): String = value
        .replace(Regex("(?:\\s+[WDL]){2,8}\\s*$", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s+"), " ").trim()
}

/** FutHead Predictions: correct-score table rows end with the predicted score. */
class FutHeadPredictionsParser : BaseParser("FutHead Predictions") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("table tr, [class*=event], [class*=match], article")) {
            val text = clean(row.text())
            val score = scoreFrom(text) ?: continue
            val cells = row.select("td, th").map { clean(it.text()) }.filter { it.isNotBlank() }
            val candidates = (cells + row.select("a").map { clean(it.text()) })
                .map { it.replace(Regex("(?:\\s+[WDL]){2,8}\\s*$", RegexOption.IGNORE_CASE), "").trim() }
                .filter(::looksLikeProviderTeam)
                .filterNot { it.equals("details", true) }
                .distinct()
            if (candidates.size < 2) continue
            val item = model("FutHead Predictions", candidates[0], candidates[1], score, row) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}
