package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * MatchOutlook daily football prediction parser.
 * The public daily page exposes fixtures as "Home vs Away" and, when a
 * correct-score prediction is published, a nearby "Result: H-A" label.
 * Non-score markets (Best Bet, Home win, Over/Under, etc.) are ignored.
 */
class MatchOutlookParser : BaseParser("MatchOutlook") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href]")) {
            val fixtureText = clean(link.text())
            if (!Regex("(?i)\\s+vs\\s+").containsMatchIn(fixtureText)) continue

            var current: Element? = link
            repeat(7) {
                val node = current ?: return@repeat
                val text = clean(node.text())
                val score = Regex("(?i)\\bResult\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b")
                    .find(text)
                    ?: Regex("(?i)\\bResult\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b")
                        .find(node.outerHtml())

                if (score != null) {
                    val homeAway = splitFixture(fixtureText) ?: return@repeat
                    val model = build(homeAway.first, homeAway.second, "${score.groupValues[1]}-${score.groupValues[2]}")
                    if (model != null) out[model.matchKey] = model
                    return@repeat
                }
                current = node.parent()
            }

            if (out.size >= 200) break
        }

        return out.values.toList()
    }

    private fun splitFixture(raw: String): Pair<String, String>? {
        val text = clean(raw)
        val match = Regex("(?i)^(.+?)\\s+vs\\s+(.+)$").find(text) ?: return null
        val home = match.groupValues[1].trim()
        val away = match.groupValues[2].trim()
        if (home.isBlank() || away.isBlank()) return null
        return home to away
    }

    private fun build(homeRaw: String, awayRaw: String, predictedScore: String): ScoreModel? {
        val home = team(homeRaw)
        val away = team(awayRaw)
        if (!valid(home, away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = predictedScore,
            source = source
        )
    }
}
