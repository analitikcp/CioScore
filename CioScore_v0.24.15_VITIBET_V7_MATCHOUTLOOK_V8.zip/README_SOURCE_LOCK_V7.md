# CioScore v0.24.15 — 6 Source Build

Sources:
1. FP.com
2. PredictZ
3. WinDrawWin
4. SoccerSeer
5. DailySports
6. Vitibet (Vitisport)

Removed completely:
- FootyStats

Protected:
- GlobalFixtureMatcher v0.24.8
- MatchMerger
- TeamAliasCanonicalizer
- Official İddaa fixture window / enrichment logic

Vitibet endpoint uses the legacy table view because it exposes fixture + correct-score fields in a deterministic row structure.
