package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Source-independent football team identity layer.
 *
 * v0.23.0 deliberately improves RECALL without weakening the fixture gates:
 * - accents / transliteration variants are canonicalized;
 * - four-digit foundation-year tokens are ignored;
 * - generic club-type tokens can occur anywhere in a provider name;
 * - known city/provider-name variants are resolved through explicit aliases;
 * - youth/reserve tiers are tracked so a U21 team cannot silently become a
 *   senior-team match;
 * - token-subset scoring is used only when the extra tokens are harmless
 *   metadata, never as a blanket "contains the same city" rule.
 *
 * The important safety rule is that canonicalization may make a REAL alias
 * stronger, but it must never turn two unrelated clubs into the same identity.
 */
object TeamAliasCanonicalizer {

    private val removableClubTokens = setOf(
        "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    private val youthOrReserveTokens = setOf(
        "u21", "u20", "u19", "u18", "u17", "u16", "ii", "iii", "reserve", "reserves", "b"
    )

    private val lowWeightTokens = setOf("city", "united", "club", "sport")

    private val comparisonEdgeNoise = setOf(
        "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    /**
     * Explicit, high-confidence aliases only. These are deliberately narrow:
     * city names are NOT globally deleted because that would create collisions
     * between unrelated clubs.
     */
    private val canonicalCache = ConcurrentHashMap<String, String>()
    private val identityCache = ConcurrentHashMap<String, TeamIdentity>()
    private val tierCache = ConcurrentHashMap<String, String>()
    private val similarityCache = ConcurrentHashMap<String, Double>()

    private val aliases = mapOf(
        // International country/national-team translations. These are
        // fixture-safe aliases: they normalize language only and do not
        // remove generic club tokens or create fuzzy city collisions.
        "israel" to "israel",
        "israil" to "israel",
        "avusturya" to "austria",
        "austria" to "austria",
        "almanya" to "germany",
        "germany" to "germany",
        "fransa" to "france",
        "france" to "france",
        "ispanya" to "spain",
        "spain" to "spain",
        "italya" to "italy",
        "italy" to "italy",
        "ingiltere" to "england",
        "england" to "england",
        "portekiz" to "portugal",
        "portugal" to "portugal",
        "hollanda" to "netherlands",
        "netherlands" to "netherlands",
        "belcika" to "belgium",
        "belgium" to "belgium",
        "isvicre" to "switzerland",
        "switzerland" to "switzerland",
        "hirvatistan" to "croatia",
        "croatia" to "croatia",
        "sirbistan" to "serbia",
        "serbia" to "serbia",
        "yunanistan" to "greece",
        "greece" to "greece",
        "polonya" to "poland",
        "poland" to "poland",
        "romanya" to "romania",
        "romania" to "romania",
        "cekya" to "czech republic",
        "czech republic" to "czech republic",
        "slovakya" to "slovakia",
        "slovakia" to "slovakia",
        "slovenya" to "slovenia",
        "slovenia" to "slovenia",
        "danimarka" to "denmark",
        "denmark" to "denmark",
        "isvec" to "sweden",
        "sweden" to "sweden",
        "norvec" to "norway",
        "norway" to "norway",
        "finlandiya" to "finland",
        "finland" to "finland",
        "irlanda" to "ireland",
        "ireland" to "ireland",
        "izlanda" to "iceland",
        "iceland" to "iceland",

        // National-team language aliases. These are exact country-name
        // translations, not fuzzy club aliases, so they are safe fixture
        // identity anchors when providers publish English and Iddaa publishes
        // Turkish names for the same national fixture.
        "armenia" to "armenia",
        "ermenistan" to "armenia",
        "latvia" to "latvia",
        "letonya" to "latvia",
        "georgia" to "georgia",
        "gurcistan" to "georgia",
        "northern ireland" to "northern ireland",
        "kuzey irlanda" to "northern ireland",
        "hungary" to "hungary",
        "macaristan" to "hungary",
        "ukraine" to "ukraine",
        "ukrayna" to "ukraine",
        "montenegro" to "montenegro",
        "karadag" to "montenegro",
        "cyprus" to "cyprus",
        "kibris" to "cyprus",
        "poland" to "poland",
        "polonya" to "poland",
        "bosnia and herzegovina" to "bosnia and herzegovina",
        "bosnia-herzegovina" to "bosnia and herzegovina",
        "bosnia herzegovina" to "bosnia and herzegovina",
        "bosnia hersek" to "bosnia and herzegovina",
        "bosna hersek" to "bosnia and herzegovina",
        "turkey" to "turkey",
        "turkiye" to "turkey",
        "türkiye" to "turkey",
        "italy" to "italy",
        "italya" to "italy",
        "belgium" to "belgium",
        "belcika" to "belgium",
        "sweden" to "sweden",
        "isvec" to "sweden",
        "romania" to "romania",
        "romanya" to "romania",
        "france" to "france",
        "fransa" to "france",
        "algeria" to "algeria",
        "cezayir" to "algeria",
        "zambia" to "zambia",
        "zambiya" to "zambia",
        "gambia" to "gambia",
        "gambiya" to "gambia",
        "somalia" to "somalia",
        "somali" to "somalia",
        "nigeria" to "nigeria",
        "nijerya" to "nigeria",
        "madagascar" to "madagascar",
        "madagaskar" to "madagascar",
        "morocco" to "morocco",
        "fas" to "morocco",
        "mali" to "mali",
        "cabo verde" to "cabo verde",
        "cape verde islands" to "cabo verde",
        "yesil burun adalari" to "cabo verde",
        "burkina faso" to "burkina faso",
        "benin" to "benin",
        "malawi" to "malawi",
        "malavi" to "malawi",
        "south sudan" to "south sudan",
        "guney sudan" to "south sudan",
        "rwanda" to "rwanda",
        "ruanda" to "rwanda",
        "liberia" to "liberia",
        "liberya" to "liberia",
        "ethiopia" to "ethiopia",
        "etiyopya" to "ethiopia",
        "tanzania" to "tanzania",
        "tanzanya" to "tanzania",
        "niger" to "niger",
        "nijer" to "niger",
        "sudan" to "sudan",

        // AEK
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",

        // LASK
        "lask" to "lask",
        "lask linz" to "lask",

        // Premier League shorthand
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "tottenham" to "tottenham hotspur",
        "spurs" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",

        // High-confidence official-bulletin/provider aliases observed in
        // cross-source fixture feeds. Keep these explicit rather than using
        // broad substring rules: the same city can contain multiple clubs.
        "atl madrid" to "atletico madrid",
        "atletico de madrid" to "atletico madrid",
        "atletico madrid" to "atletico madrid",
        "athletico madrid" to "atletico madrid",
        "fc lausanne sport" to "lausanne sport",
        "lausanne sport" to "lausanne sport",
        "lausanne" to "lausanne sport",
        "fc lausanne" to "lausanne sport",
        "lausanne sports" to "lausanne sport",
        "genclerbirligi" to "genclerbirligi",
        "genclerbirligi sk" to "genclerbirligi",

        // Escaldes provider contraction variants. Some feeds abbreviate
        // Spanish/Catalan "de" as "d", while the official bulletin keeps
        // the full connector. Keep this explicit so the connector is not
        // globally rewritten (which could create unrelated collisions).
        "inter club d escaldes" to "inter club de escaldes",
        "inter d escaldes" to "inter de escaldes",
        "inter club de escaldes" to "inter club de escaldes",
        "inter de escaldes" to "inter de escaldes",
        "estudiante merida" to "estudiantes merida",
        "estudiantes merida" to "estudiantes merida",

        // Official-bulletin alias: provider feeds may include the Spanish connector
        // "de" while the official feed omits it. This is a verified single-club
        // alias and is intentionally explicit; do not generalize by deleting
        // "de" globally because that could collapse unrelated club names.
        "estudiantes de rio cuarto" to "estudiantes rio cuarto",
        "estudiantes rio cuarto" to "estudiantes rio cuarto",

        // Bundesliga provider shorthands. These are explicit because a leading
        // single-letter "B." is otherwise indistinguishable from a reserve-tier
        // token. RB is a provider prefix, not a different Leipzig identity.
        "b leverkusen" to "bayer leverkusen",
        "bayer leverkusen" to "bayer leverkusen",
        "rb leipzig" to "leipzig",
        "r b leipzig" to "leipzig",
        "red bull leipzig" to "leipzig",

        // Sporting CP / Lisbon
        "sporting cp" to "sporting clube de portugal",
        "sporting lisbon" to "sporting clube de portugal",
        "sporting lisboa" to "sporting clube de portugal",
        "sporting clube de portugal" to "sporting clube de portugal",
        "sporting portugal" to "sporting clube de portugal",
        "sporting de portugal" to "sporting clube de portugal",

        // Verified diagnostic variants from v0.22.0.
        "dinamo tbilisi" to "dinamo tiflis",
        "dinamo tiflis" to "dinamo tiflis",
        "al riffa" to "al riffa",
        "al rifaa" to "al riffa",
        "al rifa" to "al riffa",

        // Provider variants for Levadia. Tallinna is retained globally;
        // only this explicit club alias collapses it to Levadia.
        "tallinna levadia" to "levadia",
        "levadia tallinna" to "levadia",
        "fci levadia" to "levadia",

        // Common provider abbreviation observed in the diagnostic feed.
        // Kept explicit rather than using broad substring matching.
        "udf" to "udf",
        "udfp" to "udf",
        "khuzestan k" to "khuzestan"
    )

    data class TeamIdentity(
        val canonicalId: String,
        val canonicalName: String,
        val compactName: String
    )

    private fun normalizedTokens(rawName: String): MutableList<String> {
        if (rawName.isBlank()) return mutableListOf()

        var value = rawName.trim().lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (value.isBlank()) return mutableListOf()

        return value.split(' ')
            .filter(String::isNotBlank)
            .map { token ->
                when (token) {
                    "athens", "atina", "athina" -> "athens"
                    // Transliteration variants. Keep this list deliberately small.
                    "tbilisi" -> "tiflis"
                    "rifaa", "rifa" -> "riffa"
                    else -> token
                }
            }
            .toMutableList()
    }

    // A leading single-letter provider abbreviation is NOT a reserve tier when
    // it is a verified senior-club shorthand. The generic "b" tier rule remains
    // active for genuine B/reserve teams elsewhere.
    private val seniorAbbreviationCanonicalNames = setOf("bayer leverkusen")

    private fun tierOf(rawName: String): String =
        tierCache[rawName] ?: run {
            val tokens = normalizedTokens(rawName)
            val canonicalName = canonical(rawName)
            val isVerifiedSeniorAbbreviation =
                tokens.firstOrNull() == "b" && canonicalName in seniorAbbreviationCanonicalNames
            val tier = if (isVerifiedSeniorAbbreviation) {
                ""
            } else {
                tokens.firstOrNull { it in youthOrReserveTokens }.orEmpty()
            }
            tierCache.putIfAbsent(rawName, tier)
            tier
        }

    /** Cached youth/reserve tier used by the fixture matcher. */
    fun tier(rawName: String): String = tierOf(rawName)

    private fun stripFoundationYears(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it.matches(Regex("(?:18|19|20)\\d{2}")) }.toMutableList()

    private fun stripClubTypeTokens(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it in removableClubTokens }.toMutableList()

    fun identity(rawName: String): TeamIdentity =
        identityCache[rawName] ?: run {
            val canonicalName = canonical(rawName)
            val value = TeamIdentity(
                canonicalId = canonicalName.replace(' ', '-'),
                canonicalName = canonicalName,
                compactName = canonicalName.replace(" ", "")
            )
            identityCache.putIfAbsent(rawName, value)
            identityCache[rawName] ?: value
        }

    fun canonical(name: String): String {
        canonicalCache[name]?.let { return it }
        var tokens = normalizedTokens(name)
        if (tokens.isEmpty()) {
            canonicalCache.putIfAbsent(name, "")
            return ""
        }

        // Foundation years are metadata, not club identity.
        tokens = stripFoundationYears(tokens)

        // Apply explicit aliases BEFORE removing tier/provider tokens. This is
        // required for verified shorthands such as "B. Leverkusen", where the
        // leading single-letter token would otherwise be mistaken for the generic
        // reserve-tier marker and disappear before alias resolution.
        val directAlias = aliases[tokens.joinToString(" ")]
        if (directAlias != null) {
            canonicalCache.putIfAbsent(name, directAlias)
            return canonicalCache[name] ?: directAlias
        }

        // Youth/reserve tier is handled separately by similarity(), so it does
        // not poison the core club-name comparison.
        tokens = tokens.filterNot { it in youthOrReserveTokens }.toMutableList()

        // Generic provider/club-type tokens are safe to remove anywhere.
        // Unlike city-prefix pruning, this cannot turn Manchester City into
        // Manchester United or otherwise erase a distinctive club word.
        tokens = stripClubTypeTokens(tokens)

        // Explicit aliases are applied AFTER generic cleanup. This is what turns
        // "Tallinna FC Levadia U21" into the same core as "FCI Levadia U21".
        var value = tokens.joinToString(" ").trim()
        if (value.isBlank()) return ""

        value = aliases[value] ?: value
        canonicalCache.putIfAbsent(name, value)
        return canonicalCache[name] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (tierOf(name1) != tierOf(name2)) return false
        return a == b
    }

    /**
     * High-recall but conservative team similarity.
     * Exact canonical aliases score 1.0. Youth/reserve tiers must agree.
     */
    /**
     * Canonical-only scoring entry point for GlobalFixtureMatcher. The raw names
     * are supplied solely to enforce youth/reserve tier isolation. All string
     * distance work is performed on canonical names.
     */
    fun similarityCanonical(
        canonical1: String,
        canonical2: String,
        rawName1: String = canonical1,
        rawName2: String = canonical2
    ): Double {
        if (canonical1.isBlank() || canonical2.isBlank()) return 0.0
        val tier1 = tierOf(rawName1)
        val tier2 = tierOf(rawName2)
        if (tier1 != tier2) return 0.0
        if (canonical1 == canonical2) return 1.0

        // Matcher hot path: the same team pairs are scored thousands of times
        // while building the identity graph and its diagnostics. Canonical names
        // plus the youth/reserve tier fully determine this result, so cache it.
        val left = canonical1 + "\u0000" + tier1
        val right = canonical2 + "\u0000" + tier2
        val key = if (left <= right) left + "\u0001" + right else right + "\u0001" + left
        similarityCache[key]?.let { return it }
        val result = similarityCanonicalCore(canonical1, canonical2)
        similarityCache.putIfAbsent(key, result)
        return similarityCache[key] ?: result
    }

    private fun similarityCanonicalCore(a: String, b: String): Double {
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        if (ca == cb) return 1.0

        val comparisonA = comparisonName(a)
        val comparisonB = comparisonName(b)
        if (comparisonA.isNotBlank() && comparisonA == comparisonB) return 0.98

        val tokenSubset = tokenSubsetSimilarity(a, b)
        val weighted = weightedTokenSimilarity(a, b)
        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        val raw = ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)
        return maxOf(raw, weighted, tokenSubset).coerceIn(0.0, 1.0)
    }

    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        return similarityCanonical(a, b, name1, name2)
    }

    private fun comparisonName(canonicalName: String): String {
        val tokens = canonicalName.split(' ').filter(String::isNotBlank).toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in comparisonEdgeNoise) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in comparisonEdgeNoise) tokens.removeAt(tokens.lastIndex)
        return tokens.joinToString(" ")
    }

    /**
     * Token-subset scoring is intentionally conservative. A shorter name may
     * match a longer name strongly only when the extra tokens are known harmless
     * metadata (for example a foundation year, already removed by canonical()).
     * Arbitrary club words such as "Welco" are NOT treated as metadata.
     */
    private fun tokenSubsetSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank).toSet()
        val bt = b.split(' ').filter(String::isNotBlank).toSet()
        if (at.isEmpty() || bt.isEmpty()) return 0.0
        if (at == bt) return 1.0

        // After canonicalization, a true subset is only promoted when the larger
        // side differs by no more than one low-information token. This avoids the
        // dangerous "Tartu JK Welco -> Tartu" false-positive pattern.
        val smaller = if (at.size <= bt.size) at else bt
        val larger = if (at.size <= bt.size) bt else at
        if (!larger.containsAll(smaller)) return 0.0

        val extras = larger - smaller
        if (extras.size == 1 && extras.first() in lowWeightTokens) return 0.94
        return 0.0
    }

    private fun weightedTokenSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank)
        val bt = b.split(' ').filter(String::isNotBlank)
        if (at.isEmpty() || bt.isEmpty()) return 0.0

        fun tokenWeight(token: String): Double = if (token in lowWeightTokens) 0.35 else 1.0

        fun bestAverage(from: List<String>, to: List<String>): Double {
            var weightedSum = 0.0
            var totalWeight = 0.0
            for (token in from) {
                val weight = tokenWeight(token)
                val best = to.maxOfOrNull { other ->
                    if (token == other) 1.0 else {
                        val maxLength = maxOf(token.length, other.length)
                        if (maxLength == 0) 1.0 else
                            1.0 - levenshtein(token, other).toDouble() / maxLength
                    }
                } ?: 0.0
                weightedSum += best.coerceIn(0.0, 1.0) * weight
                totalWeight += weight
            }
            return if (totalWeight == 0.0) 0.0 else weightedSum / totalWeight
        }

        return ((bestAverage(at, bt) + bestAverage(bt, at)) / 2.0).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        exact(name1, name2) || similarity(name1, name2) >= 0.80

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
