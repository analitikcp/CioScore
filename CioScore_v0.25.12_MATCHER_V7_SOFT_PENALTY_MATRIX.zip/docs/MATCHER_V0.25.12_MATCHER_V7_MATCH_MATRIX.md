# CioScore V7 — Match Matrix / Soft Context Penalty

## Amaç

- Country/league mismatch artık aday havuzunu hard-reject etmez.
- Explicit context conflict confidence içinde `0.10` soft penalty olarak temsil edilir.
- Gerçek home/away flip (`A-B` ↔ `B-A`) iki yönlü takım benzerliği `>= 0.80` ise hard-reject edilir.
- İddaa resmi fikstürleri ile benzersiz prediction fixture'lar arasında tam N×M matris hesaplanır.
- Diagnostic panel provider kayıtlarını değil unique fixture'ları raporlar.

## Matrix

Her benzersiz prediction fixture, resmi İddaa bulletin fixture'larının tamamıyla karşılaştırılır. Örneğin 53 prediction × 35 official = 1855 pair. Matrix UI'ı gate değildir; yalnızca teşhis/enrichment analizi üretir.

Durumlar:

- `MATCHED`: mevcut matcher resmi anchor ile eşleştirmiştir.
- `REVIEW_CANDIDATE`: takım benzerliği anlamlıdır (`>= 0.65`) fakat mevcut karar zinciri otomatik eşleştirmemiştir.
- `NO_CANDIDATE`: en iyi takım benzerliği `<= 0.30`.
- `REJECTED_BY_SCORE`: aday vardır fakat takım kanıtı zayıf kalmıştır.

## Güvenlik

Soft context yalnızca country/competition metadata'sını etkiler. Bilinen kickoff contradiction ve directional flip hard reject olarak korunur.
