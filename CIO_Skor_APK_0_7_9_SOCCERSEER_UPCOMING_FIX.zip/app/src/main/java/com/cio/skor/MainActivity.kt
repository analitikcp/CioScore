package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.*

class MainActivity:Activity(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private val repo=ScraperRepository()
    private lateinit var status:TextView
    private lateinit var list:RecyclerView
    private lateinit var adapter:ScoreAdapter
    override fun onCreate(b:Bundle?){super.onCreate(b);WindowCompat.setDecorFitsSystemWindows(window,false);buildUi();ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)){v,i->val top=i.getInsets(WindowInsetsCompat.Type.statusBars()).top;v.setPadding(0,top,0,0);i}}
    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;id=100;setBackgroundColor(Color.WHITE)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,8)}
        header.addView(TextView(this).apply{text="CIO SCORE";textSize=28f;setTextColor(Color.BLACK);setTypeface(typeface,1)})
        header.addView(TextView(this).apply{text="Skorun Merkezi • 15 kaynak";textSize=14f;setTextColor(Color.GRAY)})
        status=TextView(this).apply{text="Hazır";textSize=14f;setPadding(0,10,0,8)};header.addView(status)
        val button=Button(this).apply{text="BUGÜNÜ TARA";setOnClickListener{scan()}};header.addView(button)
        root.addView(header,LinearLayout.LayoutParams(-1,-2))
        list=RecyclerView(this).apply{layoutManager=LinearLayoutManager(this@MainActivity)};adapter=ScoreAdapter(emptyList());list.adapter=adapter;root.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun scan(){status.text="⏳ 0/15 kaynak taranıyor...";adapter.update(emptyList());scope.launch{
        val results=withContext(Dispatchers.IO){repo.fetchAll{n,name->runOnUiThread{status.text="⏳ $n/15 • $name"}}}
        val scores=results.flatMap{it.scores}
        adapter.update(scores)
        val good=results.count{it.scores.isNotEmpty()}
        status.text="✅ $good kaynak • ${scores.size} temiz skor"
    }}
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
