package com.cio.skor.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Production-oriented global fixture identity engine.
 *
 * Four identity layers are intentionally separated:
 * 1) TeamAliasCanonicalizer  -> stable source-independent team IDs
 * 2) Official Iddaa anchor   -> strongest fixture authority
 * 3) Union-Find clustering    -> global, non-greedy grouping
 * 4) Evidence/confidence      -> ID + date/time + team similarity validation
 *
 * Important invariant: a fuzzy pair can never create a cluster merely because
 * one side matches. Home AND away must agree. Official fixtures can relax the
 * name threshold only when the official record is the anchor and there is no
 * contradictory time information.
 */
object GlobalFixtureMatcher {

    const val CANONICAL_PIPELINE_VERSION = "v0.24.52-ANR"

    // Hard gates: a fuzzy fixture must have credible evidence on BOTH sides.
    // The combined gate prevents two mediocre team similarities from becoming a match.
    private const val TEAM_FUZZY_MIN = 0.72
    private const val MATCH_FUZZY_MIN = 0.78
    private const val AUTO_MERGE_CONFIDENCE = 0.84

    // Kickoff mismatch is a hard rejection. Twelve hours is intentionally wide
    // enough for timezone/date-rollover differences, but still blocks unrelated
    // fixtures from becoming candidates.
    private const val TIME_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 12L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    ) {
        // Identity is immutable for a record. Compute it once at construction
        // instead of normalizing the same provider name on every pair comparison.
        val homeIdentity: TeamAliasCanonicalizer.TeamIdentity = TeamAliasCanonicalizer.identity(homeTeam)
        val awayIdentity: TeamAliasCanonicalizer.TeamIdentity = TeamAliasCanonicalizer.identity(awayTeam)
        val homeCanonicalId: String get() = homeIdentity.canonicalId
        val awayCanonicalId: String get() = awayIdentity.canonicalId
        val fixtureKey: String get() = "$homeCanonicalId||$awayCanonicalId"
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        /**
         * The exact prediction records that produced [predictions].
         *
         * The UI must consume this identity-graph output instead of regrouping
         * raw predictions by canonical team key, otherwise two fixtures that
         * the matcher deliberately kept separate could be collapsed again.
         */
        val predictionRecords: MutableList<Record> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = "",
        var fixtureKey: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val competitionScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean,
        val homeCanonicalA: String = "",
        val homeCanonicalB: String = "",
        val awayCanonicalA: String = "",
        val awayCanonicalB: String = ""
    )

    private class UnionFind(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)
        private val members = Array(size) { mutableListOf(it) }

        fun find(value: Int): Int {
            var x = value
            while (parent[x] != x) x = parent[x]
            val root = x
            x = value
            while (parent[x] != x) {
                val next = parent[x]
                parent[x] = root
                x = next
            }
            return root
        }

        fun componentMembers(value: Int): List<Int> = members[find(value)]

        fun union(a: Int, b: Int) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) {
                val tmp = ra; ra = rb; rb = tmp
            }
            parent[rb] = ra
            members[ra].addAll(members[rb])
            members[rb].clear()
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)

        // All configured prediction sources: prediction records.
        scraped.forEach { s ->
            records += Record(
                homeTeam = s.homeTeam,
                awayTeam = s.awayTeam,
                predictedScore = s.predictedScore,
                source = s.source,
                sourceMatchId = s.sourceMatchId,
                matchTimestamp = s.matchTimestamp,
                matchDate = s.matchDate,
                matchTime = s.matchTime,
                competitionName = s.competitionName
            )
        }

        // Source 6: official Iddaa fixture/market records.
        officialMatches.forEach { o ->
            records += Record(
                homeTeam = o.homeTeam,
                awayTeam = o.awayTeam,
                source = "IDDAA",
                sourceMatchId = o.matchId,
                matchTimestamp = o.matchTimestamp,
                matchDate = o.matchDate,
                matchTime = o.matchTime,
                competitionName = o.competitionName,
                official = o
            )
        }

        if (records.isEmpty()) return emptyList()

        val uf = UnionFind(records.size)
        // Score/evidence is pure for a record pair. Cache it locally so the
        // component safety gate and later passes never recompute the same
        // canonicalization/Levenshtein work.
        val evidenceCache = HashMap<Long, MatchEvidence>(records.size * 8)
        fun cachedScore(aIndex: Int, bIndex: Int): MatchEvidence {
            val lo = minOf(aIndex, bIndex).toLong()
            val hi = maxOf(aIndex, bIndex).toLong()
            val key = (lo shl 32) xor (hi and 0xffffffffL)
            return evidenceCache[key] ?: score(records[aIndex], records[bIndex]).also { evidenceCache[key] = it }
        }

        // PASS 1 -----------------------------------------------------
        // Official anchor: same official ID is absolute identity inside
        // the official namespace. Never compare IDs from different providers.
        val officialIdIndex = HashMap<String, Int>()
        records.indices.forEach { index ->
            val record = records[index]
            if (record.official != null) {
                val id = record.sourceMatchId.trim()
                if (id.isNotBlank()) {
                    officialIdIndex[id]?.let { uf.union(it, index) } ?: run {
                        officialIdIndex[id] = index
                    }
                }
            }
        }

        // PASS 2 -----------------------------------------------------
        // Canonical fixture key is deterministic and does not depend on the
        // arrival order of sources. This is the main fix for AEK/LASK variants.
        // A component may only grow when EVERY record in the two components is
        // mutually compatible. This prevents transitive false fixtures such as
        // Orlando-Toronto + Miami-Nashville => Toronto-Nashville.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { index ->
            val key = records[index].fixtureKey
            if (key != "||") exactBuckets.getOrPut(key) { mutableListOf() }.add(index)
        }
        exactBuckets.values.forEach { bucket ->
            for (i in 1 until bucket.size) {
                // Exact team names are not enough to merge fixtures from different
                // dates/kickoffs. Reuse the same evidence gate so PASS 2 cannot
                // bypass the hard time/competition filters.
                if (cachedScore(bucket[0], bucket[i]).accepted &&
                    componentsCompatible(uf, bucket[0], bucket[i], ::cachedScore)) {
                    uf.union(bucket[0], bucket[i])
                }
            }
        }

        // PASS 3 -----------------------------------------------------
        // Official anchor matching first.
        val officialByFixtureKey = HashMap<String, MutableList<Int>>()
        val officialIndices = ArrayList<Int>(officialMatches.size)
        records.indices.forEach { index ->
            if (records[index].official != null) {
                officialIndices += index
                officialByFixtureKey.getOrPut(records[index].fixtureKey) { mutableListOf() }.add(index)
            }
        }
        // Official anchor matching first. A prediction source with no time/ID
        // can still attach to the official fixture because the official fixture
        // is today's authoritative roster. Team agreement is always two-sided.
        records.indices.forEach { i ->
            val candidate = records[i]
            if (candidate.official != null) return@forEach

            var bestIndex = -1
            var bestScore = -1.0

            // Most provider records already canonicalize to the exact official
            // HOME/AWAY identity. Search that tiny bucket first; only fall back
            // to the full official roster when canonical identity is unavailable
            // or the exact bucket is rejected by a hard time/competition gate.
            val exactCandidates = officialByFixtureKey[candidate.fixtureKey].orEmpty()
            for (j in exactCandidates) {
                val evidence = cachedScore(i, j)
                if (evidence.accepted && evidence.confidence > bestScore) {
                    bestScore = evidence.confidence
                    bestIndex = j
                }
            }

            // Preserve the old fallback behavior when an exact canonical pair
            // exists but every exact candidate is rejected by a hard evidence
            // gate. This keeps recall behavior unchanged while making the normal
            // path O(number of exact official duplicates) instead of O(all official).
            if (bestIndex < 0) {
                for (j in officialIndices) {
                    if (exactCandidates.contains(j)) continue
                    val evidence = cachedScore(i, j)
                    if (evidence.accepted && evidence.confidence > bestScore) {
                        bestScore = evidence.confidence
                        bestIndex = j
                    }
                }
            }
            if (bestIndex >= 0 &&
                componentsCompatible(uf, i, bestIndex, ::cachedScore)) {
                uf.union(i, bestIndex)
            }
        }

        // PASS 4 -----------------------------------------------------
        // Global fuzzy clustering among non-official records. No prefix block,
        // no greedy "first match wins". Pair decisions are evidence based.
        // IMPORTANT: Union-Find connectivity alone is NOT fixture identity.
        // Before any union we require the two entire components to be mutually
        // compatible. This blocks A-B + B-C from becoming a false A-C fixture.
        for (i in records.indices) {
            for (j in i + 1 until records.size) {
                val a = records[i]
                val b = records[j]
                if (sameSourceDifferentIds(a, b)) continue
                // Official fixtures are already handled by PASS 1/3. Keeping
                // them out of global fuzzy clustering prevents an official
                // record from acting as a bridge between unrelated predictions.
                if (a.official != null || b.official != null) continue

                val evidence = cachedScore(i, j)
                if (!evidence.accepted) continue

                // High-confidence fuzzy pairs may union globally. Exact canonical
                // fixtures were already unioned in PASS 2; official anchors were
                // handled in PASS 3.
                if (evidence.idAnchor ||
                    evidence.officialAnchor ||
                    evidence.confidence >= AUTO_MERGE_CONFIDENCE) {
                    if (componentsCompatible(uf, i, j, ::cachedScore)) {
                        uf.union(i, j)
                    }
                }
            }
        }

        // Build connected components.
        val grouped = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { index ->
            grouped.getOrPut(uf.find(index)) { mutableListOf() }.add(records[index])
        }

        return grouped.values.map(::buildUnified)
    }

    /**
     * Prevents transitive fixture pollution. A union is allowed only when every
     * record already in component A is compatible with every record already in
     * component B. Pairwise graph connectivity is not sufficient for a fixture:
     * A~B and B~C must NOT imply A~C.
     */
    private fun componentsCompatible(
        uf: UnionFind,
        aIndex: Int,
        bIndex: Int,
        scorer: (Int, Int) -> MatchEvidence
    ): Boolean {
        val rootA = uf.find(aIndex)
        val rootB = uf.find(bIndex)
        if (rootA == rootB) return true

        // Union-Find keeps component membership incrementally. The old code
        // rescanned ALL records to discover both components for every accepted
        // pair, turning a few hundred fixtures into a very expensive nested
        // hot path. We keep the exact same pairwise safety rule, but inspect only
        // the two actual components.
        val membersA = uf.componentMembers(rootA)
        val membersB = uf.componentMembers(rootB)
        for (a in membersA) {
            for (b in membersB) {
                if (!scorer(a, b).accepted) return false
            }
        }
        return true
    }

    /** Public for regression tests and diagnostics. */
    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() ||
            b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, 0.0, false, false, 0.0, false)
        }

        if (sameSourceDifferentIds(a, b)) {
            return MatchEvidence(0.0, 0.0, 0.0, -1.0, 0.0, false, false, 0.0, false)
        }

        // CANONICAL INTEGRATION GATE (v0.23.2): every team comparison MUST
        // pass through TeamAliasCanonicalizer before any similarity operation.
        // Raw provider names are retained only for diagnostics/display.
        val homeCanonicalA = a.homeIdentity.canonicalName
        val homeCanonicalB = b.homeIdentity.canonicalName
        val awayCanonicalA = a.awayIdentity.canonicalName
        val awayCanonicalB = b.awayIdentity.canonicalName

        val home = TeamAliasCanonicalizer.similarityCanonical(
            homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
        )
        val away = TeamAliasCanonicalizer.similarityCanonical(
            awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
        )
        val teamScore = (home + away) / 2.0
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
            TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val exactCanonicalTeams =
            homeCanonicalA.isNotBlank() && homeCanonicalA == homeCanonicalB &&
            awayCanonicalA.isNotBlank() && awayCanonicalA == awayCanonicalB &&
            home >= 0.99 && away >= 0.99
        val idAnchor = sameComparableId(a, b)
        val officialAnchor = a.official != null || b.official != null
        val time = timeScore(a, b)
        val competition = competitionScore(a.competitionName, b.competitionName)

        // The official Iddaa fixture is the authority for today's roster. Some
        // prediction providers publish a stale/wrong competition label (or a
        // timezone-shifted kickoff) while still naming the exact same two teams.
        // When the canonical HOME and AWAY identities are exact, do not let a
        // provider-side competition/time mismatch erase an otherwise certain
        // official fixture. This is deliberately limited to official-anchor
        // matching; non-official clustering keeps the strict contradiction gates.
        // Exact team identity is strong, but it must never override a hard
        // kickoff contradiction. Without this guard, the same teams appearing
        // in different fixtures (for example a league rematch) could be attached
        // to the wrong official event merely because the names are exact.
        if (officialAnchor && time >= 0.0 && (exactTeams || exactCanonicalTeams)) {
            val confidence = (
                0.92 +
                    0.04 * time.coerceAtLeast(0.0) +
                    0.04 * if (competition >= 0.0) competition else 0.0
            ).coerceIn(0.92, 0.99)
            return MatchEvidence(
                homeSimilarity = home,
                awaySimilarity = away,
                teamScore = 1.0,
                timeScore = time,
                competitionScore = competition,
                idAnchor = idAnchor,
                officialAnchor = true,
                confidence = confidence,
                accepted = true,
                homeCanonicalA = homeCanonicalA,
                homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA,
                awayCanonicalB = awayCanonicalB
            )
        }

        // If both sources explicitly identify the competition/tournament and those
        // identities conflict, reject fuzzy matches. Exact official team identity
        // was handled immediately above. Missing competition data is neutral.
        if (competition < 0.0) {
            return MatchEvidence(home, away, teamScore, time, competition, false, officialAnchor, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // Same official ID or same ID in the same source is the strongest anchor.
        if (idAnchor) {
            return MatchEvidence(home, away, teamScore, maxOf(0.0, time), competition, true, officialAnchor, 1.0, true)
        }

        // Official roster is authoritative for today's fixtures. Do not let a
        // provider timezone/date contradiction reject a strong two-sided name match.
        if (time < 0.0 && !officialAnchor) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (officialAnchor) {
            // A known kickoff contradiction is a hard rejection for every official
            // matching path, including fuzzy identity. Exact team names must never
            // override a different fixture date/time.
            if (time < 0.0) {
                return MatchEvidence(
                    home, away, teamScore, time, competition, false, true, 0.0, false,
                    homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB
                )
            }

            // Official matching must prove TEAM IDENTITY, not merely string
            // similarity. This prevents collisions such as:
            //   Minnesota United -> Manchester United
            //   Al Sailiya -> Al Quwa Al Jawiya
            //   Ostersunds -> Estrela (Braga)
            // while still accepting legitimate provider expansions such as:
            //   Bokelj -> FK Bokelj Kotor
            //   Otrant -> FK Otrant-Olympic Ulcinj
            //   Dallas -> FC Dallas
            val homeIdentity = teamIdentityEvidence(
                homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
            )
            val awayIdentity = teamIdentityEvidence(
                awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
            )
            val accepted = exactTeams || exactCanonicalTeams || (
                homeIdentity &&
                    awayIdentity &&
                    home >= 0.72 &&
                    away >= 0.72
            )
            if (!accepted) {
                return MatchEvidence(home, away, teamScore, time, competition, false, true, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
            }
            val confidence = (
                0.50 * teamScore +
                    0.20 * time.coerceAtLeast(0.0) +
                    0.15 * competition.coerceAtLeast(0.0) +
                    0.15
            ).coerceIn(0.0, 0.99)
            return MatchEvidence(home, away, teamScore, time, competition, false, true, confidence, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // Non-official fuzzy match: both sides must pass. A one-sided high score
        // is never sufficient.
        if (home < TEAM_FUZZY_MIN || away < TEAM_FUZZY_MIN || teamScore < MATCH_FUZZY_MIN) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (exactTeams) {
            return MatchEvidence(home, away, 1.0, time, competition, false, false, 0.99, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        val timeContribution = if (time > 0.0) time else 0.0
        var confidence = 0.60 * teamScore + 0.20 * timeContribution + 0.20 * competition.coerceAtLeast(0.0)
        if (home >= 0.97 && away >= 0.97) confidence += 0.04
        if (time >= 0.95) confidence += 0.04
        confidence = confidence.coerceIn(0.0, 0.99)

        return MatchEvidence(home, away, teamScore, time, competition, false, false, confidence, confidence >= AUTO_MERGE_CONFIDENCE, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
    }

    /**
     * Strong team-identity evidence for official fixture matching.
     *
     * Similarity alone is intentionally NOT identity. Common words such as
     * "al", "city", "united", "fc" and short fragments can make unrelated
     * clubs look deceptively close.
     *
     * We accept only:
     *  - exact canonical identity; or
     *  - a conservative token-subset expansion where the shorter canonical name
     *    is wholly contained in the longer one and contains a distinctive token
     *    (>= 5 chars). This covers source expansions like "Bokelj" ->
     *    "Bokelj Kotor" without making generic words an identity anchor.
     */
    private fun teamIdentityEvidence(
        canonicalA: String,
        canonicalB: String,
        rawA: String,
        rawB: String
    ): Boolean {
        if (canonicalA.isBlank() || canonicalB.isBlank()) return false
        if (TeamAliasCanonicalizer.exact(rawA, rawB)) return true
        if (canonicalA == canonicalB) return true

        val aTokens = canonicalA.split(' ').filter(String::isNotBlank).toSet()
        val bTokens = canonicalB.split(' ').filter(String::isNotBlank).toSet()
        if (aTokens.isEmpty() || bTokens.isEmpty()) return false

        val smaller = if (aTokens.size <= bTokens.size) aTokens else bTokens
        val larger = if (aTokens.size <= bTokens.size) bTokens else aTokens
        if (!larger.containsAll(smaller)) return false

        // Generic edge words are never allowed to establish identity.
        val generic = setOf(
            "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk",
            "afc", "ff", "cf", "sc", "ac", "as", "bsc", "rc", "sv",
            "bk", "pfc", "club", "city", "united"
        )
        val distinctive = smaller.filter { it.length >= 5 && it !in generic }
        return distinctive.isNotEmpty()
    }

    private fun competitionScore(a: String, b: String): Double {
        val ca = normalizeCompetition(a)
        val cb = normalizeCompetition(b)
        if (ca.isBlank() || cb.isBlank()) return 0.0
        if (ca == cb) return 1.0
        val compactA = ca.replace(" ", "")
        val compactB = cb.replace(" ", "")
        if (compactA == compactB) return 1.0
        val maxLen = maxOf(compactA.length, compactB.length)
        if (maxLen == 0) return 1.0
        val distance = levenshtein(compactA, compactB)
        val similarity = 1.0 - distance.toDouble() / maxLen
        return if (similarity >= 0.80) similarity else -1.0
    }

    private fun normalizeCompetition(value: String): String =
        value.lowercase()
            .replace("uefa ", "")
            .replace("official ", "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(replace, current[j - 1] + 1, previous[j] + 1)
            }
            val swap = previous; previous = current; current = swap
        }
        return previous[b.length]
    }

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, ignoreCase = true)) return false
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        return idA.isNotBlank() && idB.isNotBlank() && idA != idB
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        if (idA.isBlank() || idB.isBlank() || idA != idB) return false

        // IDs are only portable when both records explicitly belong to the same
        // provider namespace, or both are official records.
        return a.source.equals(b.source, ignoreCase = true) ||
            (a.official != null && b.official != null)
    }

    /**
     * Time evidence:
     *  1. exact/near kickoff -> positive score
     *  2. 3h is the soft tolerance requested for timezone drift
     *  3. >6h is a hard contradiction
     *  4. missing time -> neutral (0), not a penalty
     *  5. known different calendar dates -> contradiction unless timestamps are
     *     close enough to account for timezone rollover.
     */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            return (1.0 - (delta.toDouble() / TIME_HARD_WINDOW_MS)).coerceIn(0.0, 1.0)
        }

        val dateA = parseDate(a.matchDate)
        val dateB = parseDate(b.matchDate)
        if (dateA != null && dateB != null) {
            val days = abs(java.time.temporal.ChronoUnit.DAYS.between(dateA, dateB))
            return when {
                days == 0L -> 0.92
                // With no trustworthy timestamp we cannot safely explain a calendar-day
                // difference. Treat it as a hard contradiction rather than allowing
                // exact team names to bridge two different fixtures.
                else -> -1.0
            }
        }

        return 0.0
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) {
            val parsed = runCatching {
                LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(
            mainHomeTeam = display.first,
            mainAwayTeam = display.second,
            officialMatch = official,
            officialMatchId = official?.matchId.orEmpty(),
            fixtureKey = TeamAliasCanonicalizer.identity(display.first).canonicalId +
                "||" + TeamAliasCanonicalizer.identity(display.second).canonicalId
        )

        // One prediction per source. If the same provider emitted duplicates,
        // keep the record with the richest identity metadata.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { !it.predictedScore.isNullOrBlank() }.forEach { record ->
            val sourceKey = record.source.trim().lowercase()
            val old = bySource[sourceKey]
            if (old == null || sourcePriority(record) > sourcePriority(old)) {
                bySource[sourceKey] = record
            }
        }
        bySource.values.forEach { record ->
            result.predictions += record.source to record.predictedScore.orEmpty()
            result.predictionRecords += record
        }

        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun chooseDisplay(
        group: List<Record>,
        official: IddaaMarketService.OpenedMarketMatch?
    ): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull {
            TeamAliasCanonicalizer.canonical(it.homeTeam).length +
                TeamAliasCanonicalizer.canonical(it.awayTeam).length
        } ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourcePriority(record: Record): Int {
        var score = 0
        if (!record.predictedScore.isNullOrBlank()) score += 5
        if (record.matchTimestamp > 0L) score += 3
        if (record.matchDate.isNotBlank()) score += 1
        if (record.sourceMatchId.isNotBlank()) score += 1
        if (record.official != null) score += 10
        return score
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        val accepted = mutableListOf<Double>()
        for (i in 0 until group.lastIndex) {
            for (j in i + 1..group.lastIndex) {
                val evidence = score(group[i], group[j])
                if (evidence.accepted) accepted += evidence.confidence
            }
        }
        return if (accepted.isEmpty()) 1.0 else accepted.average().coerceIn(0.0, 1.0)
    }
}
