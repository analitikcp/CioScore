package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.cio.skor.data.IddaaMarketService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Shows official Iddaa fixtures that expose the 6+ Gol selection. */
class SixPlusGoalsActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = IddaaMarketService()
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        setContentView(root)
        load()
    }

    private fun load() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "⚽ 6+ GOL MAÇLARI"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        })
        root.addView(TextView(this).apply {
            text = "Resmi İddaa bülteninde Toplam Gol Sayısı marketinde 6+ Gol seçeneği bulunan maçlar"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        })
        val progress = ProgressBar(this)
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(48)))

        scope.launch {
            val result = withContext(Dispatchers.IO) { service.fetchToday() }
            progress.visibility = View.GONE
            // Result.matches is already restricted to the canonical
            // 06:00 -> next-day 06:00 bulletin window.
            val matches = result.matches
                .filter { it.hasTotalGoals6Plus }
                .sortedBy { it.matchTimestamp }
            if (matches.isEmpty()) {
                root.addView(TextView(this@SixPlusGoalsActivity).apply {
                    text = "Bu bültende 6+ Gol seçeneği bulunan maç bulunamadı."
                    textSize = 14f
                    gravity = Gravity.CENTER
                    setPadding(0, dp(24), 0, dp(24))
                })
                return@launch
            }
            root.addView(TextView(this@SixPlusGoalsActivity).apply {
                text = "${matches.size} maç bulundu"
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, 0, dp(8))
            })

            val scroll = ScrollView(this@SixPlusGoalsActivity)
            val list = LinearLayout(this@SixPlusGoalsActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            matches.forEach { match -> addMatch(list, match) }
            scroll.addView(list)
            root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        }
    }

    private fun addMatch(parent: LinearLayout, match: IddaaMarketService.OpenedMarketMatch) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }
        }
        card.addView(TextView(this).apply {
            text = "${match.matchTime}  •  ${match.competitionName.ifBlank { "İddaa" }}"
            textSize = 11f
        })
        card.addView(TextView(this).apply {
            text = "${match.homeTeam}  -  ${match.awayTeam}"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(4))
        })
        card.addView(TextView(this).apply {
            text = "6+ GOL" + (match.totalGoals6PlusOdd?.let { "   Oran: $it" } ?: "")
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        })
        parent.addView(card)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
