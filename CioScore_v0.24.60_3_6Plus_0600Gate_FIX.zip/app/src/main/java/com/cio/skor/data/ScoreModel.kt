package com.cio.skor.data

/**
 * One prediction coming from one external source. Optional fixture metadata is
 * deliberately nullable/defaulted so existing parsers remain source-compatible.
 */
data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String,
    val sourceMatchId: String = "",
    val matchTimestamp: Long = 0L,
    val matchDate: String = "",
    val matchTime: String = "--:--",
    val competitionName: String = ""
) {
    /** Stable canonical fixture key. This is not the only identity signal. */
    val matchKey: String
        get() = MatchMerger.key(homeTeam, awayTeam)

    companion object {
        /**
         * Single display contract for a score prediction.
         *
         * A fixture is allowed into the main UI only when this returns true.
         * Blank, partial, textual, or otherwise non-score prediction values are
         * deliberately rejected here rather than being handled differently by
         * the parser, merge layer, and RecyclerView.
         */
        private val RENDERABLE_SCORE = Regex("^(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})$")

        fun hasRenderablePrediction(score: String?): Boolean {
            val value = score?.trim().orEmpty()
            val match = RENDERABLE_SCORE.matchEntire(value) ?: return false
            val home = match.groupValues[1].toIntOrNull() ?: return false
            val away = match.groupValues[2].toIntOrNull() ?: return false
            return home in 0..20 && away in 0..20
        }
    }
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null,
    val durationMs: Long = 0L,
    val rawHtmlBytes: Int = 0
)
