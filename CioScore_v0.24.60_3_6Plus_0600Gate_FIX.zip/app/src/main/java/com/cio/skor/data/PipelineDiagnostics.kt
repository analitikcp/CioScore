package com.cio.skor.data

/**
 * Lightweight, non-invasive pipeline diagnostics.
 *
 * This class only reports counts/status; it does not alter filtering,
 * matching, gating, or scoring behavior.
 */
object PipelineDiagnostics {
    fun log(
        sourceCounts: Map<String, Int>,
        rawPredictions: Int,
        iddaaRaw: Int? = null,
        iddaaParsed: Int? = null,
        gateInput: Int? = null,
        gateOutput: Int? = null,
        matcherInput: Int? = null,
        matcherOutput: Int? = null,
        uiGroups: Int? = null
    ) {
        val lines = buildList {
            add("=== PIPELINE DIAGNOSTIC ===")
            sourceCounts.forEach { (source, count) ->
                add("$source = $count")
            }
            add("RAW PREDICTIONS = $rawPredictions")
            iddaaRaw?.let { add("IDDAA RAW = $it") }
            iddaaParsed?.let { add("IDDAA PARSED = $it") }
            gateInput?.let { add("GATE INPUT = $it") }
            gateOutput?.let { add("GATE OUTPUT = $it") }
            matcherInput?.let { add("MATCHER INPUT = $it") }
            matcherOutput?.let { add("MATCHER OUTPUT = $it") }
            uiGroups?.let { add("UI GROUPS = $it") }
            add("============================")
        }
        android.util.Log.i("PIPELINE_DIAG", lines.joinToString("\n"))
    }
}
