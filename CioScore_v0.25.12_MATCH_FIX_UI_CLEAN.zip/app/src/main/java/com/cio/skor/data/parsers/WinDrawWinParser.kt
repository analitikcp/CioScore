package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * WinDrawWin parser.
 *
 * The site exposes a "View <home> v <away> Tip" link for each match card and
 * the predicted correct score appears after the TIP section. We use that
 * relationship instead of scanning arbitrary scores from the whole card.
 */
class WinDrawWinParser : BaseParser("WinDrawWin") {

    override fun parse(doc: Document): List<ScoreModel> {
        val results = LinkedHashMap<String, ScoreModel>()

        // This is the most reliable anchor on the current WinDrawWin page.
        val tipLinks = doc.select("a[href]").filter { link ->
            val text = clean(link.text())
            text.matches(Regex("(?i)^View\\s+.+\\s+Tip$"))
        }

        for (link in tipLinks) {
            val match = extractMatchFromTipLink(link.text()) ?: continue
            val home = team(match.first)
            val away = team(match.second)
            if (!valid(home, away)) continue

            val score = findScoreNearTip(link) ?: continue

            val sourceMatchId = link.attr("href").trim()
            val key = if (sourceMatchId.isNotBlank()) {
                "ID|$sourceMatchId"
            } else {
                "${home.lowercase()}|${away.lowercase()}|$score"
            }
            val metadata = extractFixtureMetadata(findFixtureContainer(link) ?: link)
            results[key] = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName
            )

            if (results.size >= 50) break
        }

        return results.values.toList()
    }

    private fun extractMatchFromTipLink(value: String): Pair<String, String>? {
        val text = clean(value)
            .removePrefix("View ")
            .removeSuffix(" Tip")
            .trim()

        val separators = listOf(" v ", " vs ", " – ", " - ")
        for (separator in separators) {
            val index = text.indexOf(separator, ignoreCase = true)
            if (index <= 0) continue

            val home = text.substring(0, index).trim()
            val away = text.substring(index + separator.length).trim()
            if (home.isNotBlank() && away.isNotBlank()) {
                return Pair(home, away)
            }
        }

        return null
    }

    private fun findFixtureContainer(link: Element): Element? {
        var current: Element? = link
        repeat(8) {
            current = current?.parent()
            val node = current ?: return null
            val text = clean(node.text())
            if (text.length in 40..2200 &&
                text.contains(Regex("(?i)\\b(?:tip|prediction|correct score)\\b"))) {
                return node
            }
        }
        return null
    }

    private fun findScoreNearTip(link: Element): String? {
        // Walk up from the exact match link. Pick the smallest ancestor that
        // contains a TIP marker followed by a plausible score.
        var current: Element? = link
        repeat(10) {
            current = current?.parent()
            val node = current ?: return@repeat
            val text = clean(node.text())
            if (text.length > 2500) return@repeat

            val afterTip = Regex(
                "(?is)\\bTIP\\b.{0,350}?([0-5])\\s*[-:]\\s*([0-5])\\b"
            ).find(text)

            if (afterTip != null) {
                return "${afterTip.groupValues[1]}-${afterTip.groupValues[2]}"
            }
        }

        return null
    }
}
