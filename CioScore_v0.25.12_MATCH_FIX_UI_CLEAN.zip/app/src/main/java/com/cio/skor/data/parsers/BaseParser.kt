package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.format.DateTimeFormatter

abstract class BaseParser(protected val source: String) {

    protected data class FixtureMetadata(
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = ""
    )
    // Shared score extraction. Parsers may still use source-specific DOM logic
    // to locate the correct text, but score normalization lives in one place.
    protected val scoreRegex = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")

    protected fun extractStandardScore(rawText: String): Pair<Int, Int>? {
        val match = scoreRegex.find(rawText) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return home to away
    }

    /** Extract fixture metadata from the smallest source card/table row.
     *  Selectors are preferred; text fallbacks only accept dates and times in
     *  fixture context so prediction scores such as 1-0 are never treated as kickoff.
     */
    protected fun extractFixtureMetadata(element: Element): FixtureMetadata {
        var date = firstMetadataText(element,
            "time[datetime]", "[datetime]", "[class*=date]", "[class*=Date]",
            "[class*=match-date]", "[class*=fixture-date]"
        )
        var time = firstMetadataText(element,
            "[class*=kickoff]", "[class*=match-time]", "[class*=fixture-time]",
            "[class*=time]"
        )
        var competition = firstMetadataText(element,
            "[class*=competition]", "[class*=tournament]", "[class*=league]",
            "[class*=country]"
        )

        val dateMatch = Regex("\\b(\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[./-]\\d{1,2}[./-]\\d{4})\\b").find(element.text())
        if (date.isBlank() && dateMatch != null) date = normalizeDate(dateMatch.value)
        else if (date.isNotBlank()) date = normalizeDate(date)

        if (time.isBlank() || time == "--:--") {
            val text = element.text()
            val nearby = dateMatch?.let {
                text.substring(it.range.last + 1).take(100)
            }.orEmpty()
            val timeMatch = Regex("\\b(?:[01]\\d|2[0-3])[:.]([0-5]\\d)\\b").find(nearby)
            if (timeMatch != null) time = timeMatch.value.replace('.', ':')
        }
        time = normalizeTime(time)

        competition = clean(competition)
            .replace(Regex("(?i)^(league|competition|tournament|country)\\s*[:\\-]\\s*"), "")
            .trim()
        if (competition.length > 100) competition = ""

        return FixtureMetadata(date, time, competition)
    }

    private fun firstMetadataText(element: Element, vararg selectors: String): String {
        for (selector in selectors) {
            val e = element.select(selector).firstOrNull() ?: continue
            val datetime = e.attr("datetime").trim()
            if (datetime.isNotBlank()) return datetime
            val value = clean(e.text())
            if (value.isNotBlank()) return value
        }
        return ""
    }

    private fun normalizeDate(value: String): String {
        val v = value.trim().take(30)
        val patterns = listOf(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
        )
        for (pattern in patterns) {
            val d = runCatching { LocalDate.parse(v.substring(0, minOf(v.length, 10)), pattern) }.getOrNull()
            if (d != null) return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
        }
        return Regex("\\b(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})\\b").find(v)?.let {
            "%02d.%02d.%s".format(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3])
        } ?: ""
    }

    private fun normalizeTime(value: String): String {
        val m = Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(value) ?: return "--:--"
        return "%02d:%s".format(m.groupValues[1].toInt(), m.groupValues[2])
    }

    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    protected fun score(s: String): String? =
        extractStandardScore(s)?.let { (home, away) -> "$home-$away" }

    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
