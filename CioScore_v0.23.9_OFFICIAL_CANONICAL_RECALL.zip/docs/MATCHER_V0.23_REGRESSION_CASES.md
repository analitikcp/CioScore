# Matcher v0.23.0 regression cases

Expected high-confidence aliases:
- Como <-> Como 1907
- Dinamo Tbilisi <-> Dinamo Tiflis
- Al-Riffa <-> Al-Rifaa
- FCI Levadia U21 <-> Tallinna FC Levadia U21

Expected rejection / no forced alias:
- Philadelphia Union <-> CLB Viettel
- Tartu JK Welco <-> Tartu

Safety invariant: GlobalFixtureMatcher thresholds and 12-hour hard time gate are unchanged from v0.22.0.
