# v0.23.3 — Matcher Canonical Trace

The live matcher exposes canonical names and similarity evidence. `GlobalFixtureMatcher.score()` computes team similarity only through `TeamAliasCanonicalizer.canonical()` / `similarityCanonical()`. Diagnostic output includes RAW names, canonical names, H/A/combined scores, and the runtime pipeline version. The diagnostic panel has a one-tap clipboard copy button. Thresholds and the 12-hour hard gate are unchanged.
