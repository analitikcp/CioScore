# v0.23.2 Matcher Canonical Integration

GlobalFixtureMatcher.score() now explicitly obtains canonical team identities before any similarity calculation. Raw provider names are retained only for diagnostics.

Diagnostic output exposes canonical names and home/away/combined scores.

Hard gates are unchanged: team fuzzy 0.72, match fuzzy 0.78, official team 0.80, official match 0.82, hard time window 12h.
