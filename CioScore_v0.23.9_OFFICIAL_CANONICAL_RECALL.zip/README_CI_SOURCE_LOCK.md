# CioScore v0.23.5 — CI Source Lock

Bu paket GitHub Actions'ın eski `/tmp/cio_project` / ZIP tabanlı workflow'lara dönmesini engellemek için hazırlanmıştır.

## ÖNEMLİ
ZIP'i GitHub repository köküne çıkarırken **mevcut dosyaların üzerine yazılmasına izin verin**.

Bu paket bilinen eski workflow dosyalarını aynı adlarla güvenli, `workflow_dispatch`-only sürümlerle değiştirir:
- build-apk(1).yml
- build-apk-FINAL.yml
- build-apk-CIO-FINAL.yml

Otomatik push build'i yalnızca `build-apk.yml` tarafından yapılır.

Build öncesi `SOURCE LOCK` adımı:
- commit SHA
- workspace
- MainActivity importu
- GlobalFixtureMatcher package'ı
- canonicalizer çağrıları
- kaynak SHA256
- MainActivity 220–285 satırları

kontrol eder.

Eğer eski `/tmp/cio_project` veya ZIP build mantığı herhangi bir workflow'da kalmışsa Gradle başlamadan CI fail eder.
