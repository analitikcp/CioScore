package com.cio.skor.data

import java.util.UUID

data class DropReason(
    val stage: PipelineStage,
    val reasonCode: String,
    val count: Int,
    val details: List<String> = emptyList()
)

enum class PipelineStage {
    HTTP, PARSER, NORMALIZATION, IDENTITY, CONFIDENCE, MERGE, IDDAA_ENRICHMENT, UI
}

data class ParserHealthReport(
    val sourceName: String,
    val httpCode: Int,
    val rawHtmlBytes: Int,
    val parsedCount: Int,
    val durationMs: Long,
    val status: ParserStatus,
    val errorMessage: String? = null
)

enum class ParserStatus { HEALTHY, DEGRADED, FAILED, DOM_CHANGED }

data class UnmatchedDiagnosticItem(
    val predictionHome: String,
    val predictionAway: String,
    val bestOfficialHome: String?,
    val bestOfficialAway: String?,
    val homeSimilarity: Double,
    val awaySimilarity: Double,
    val homeCanonicalPrediction: String = "",
    val homeCanonicalOfficial: String = "",
    val awayCanonicalPrediction: String = "",
    val awayCanonicalOfficial: String = "",
    val combinedSimilarity: Double = 0.0,
    val dateDifferenceDays: Int = 0,
    val probableReason: UnmatchedReason
)

enum class UnmatchedReason {
    ALIAS_STEMMING_PROBLEM,
    DATE_WINDOW_MISMATCH,
    LOW_NAME_SIMILARITY,
    NO_OFFICIAL_CANDIDATE
}

data class ScanTrace(
    val scanId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val timestamp: Long = System.currentTimeMillis(),
    val parserReports: List<ParserHealthReport>,
    val stageMetrics: Map<PipelineStage, Int>,
    val dropReasons: List<DropReason>,
    val totalDurationMs: Long,
    val unmatchedOfficialDiagnostics: List<UnmatchedDiagnosticItem> = emptyList()
)
