package com.cio.skor.data

/**
 * Compatibility facade. The old greedy merger is gone; all six sources now
 * enter GlobalFixtureMatcher as one global identity graph.
 */
object MatchMerger {
    fun normalizeTeamName(name: String): String = TeamAliasCanonicalizer.canonical(name)

    fun canonicalTeamId(name: String): String = TeamAliasCanonicalizer.identity(name).canonicalId

    fun key(homeTeam: String, awayTeam: String): String =
        "${canonicalTeamId(homeTeam)}||${canonicalTeamId(awayTeam)}"

    fun isSameTeam(name1: String, name2: String): Boolean =
        TeamAliasCanonicalizer.isSameTeam(name1, name2)

    fun areMatchesSame(
        match1Home: String,
        match1Away: String,
        match2Home: String,
        match2Away: String
    ): Boolean {
        val home = TeamAliasCanonicalizer.similarity(match1Home, match2Home)
        val away = TeamAliasCanonicalizer.similarity(match1Away, match2Away)
        return home >= 0.72 && away >= 0.72 && ((home + away) / 2.0) >= 0.78
    }

    fun calculateSimilarity(s1: String, s2: String): Double =
        TeamAliasCanonicalizer.similarity(s1, s2)

    fun mergeMatches(
        scrapedList: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()
    ): List<GlobalFixtureMatcher.UnifiedMatch> =
        GlobalFixtureMatcher.merge(scrapedList, officialMatches)
}
