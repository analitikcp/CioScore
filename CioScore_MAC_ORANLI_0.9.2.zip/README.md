CioScore 0.9.1

Bu sürümde maç kartlarındaki MS 1 / MS X / MS 2 oranlarının veri akışı düzeltildi.
SofaScore günlük 1X2 odds akışı kullanılır; fractionalValue değerleri decimal orana dönüştürülür.
SofaScore host fallback'i ve event bazlı yedek endpointler bulunur.
