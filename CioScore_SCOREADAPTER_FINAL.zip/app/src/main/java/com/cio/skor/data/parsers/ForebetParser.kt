package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser.
 * Keeps the proven Forebet DOM selectors and adds tolerant extraction because
 * Forebet can wrap score/team values in different nested elements.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Forebet's normal match rows.
        val blocks = LinkedHashSet<Element>()
        blocks.addAll(doc.select("div.rcnt"))

        for (block in blocks) {
            addBlock(block, out)
            if (out.size >= 100) break
        }

        // Fallback: start from every home-team node and climb to a row
        // containing both teams and a score.
        if (out.isEmpty()) {
            val homes = doc.select(
                "span.homeTeam, [class*=homeTeam], [class*=hometeam], [class*=home_team]"
            )
            for (home in homes) {
                var p: Element? = home
                repeat(9) {
                    val current = p ?: return@repeat
                    val away = current.select(
                        "span.awayTeam, [class*=awayTeam], [class*=awayteam], [class*=away_team]"
                    ).firstOrNull()
                    if (away != null) {
                        addBlock(current, out)
                        if (out.size >= 100) return out.values.toList()
                    }
                    p = current.parent()
                }
            }
        }

        return out.values.toList()
    }

    private fun addBlock(block: Element, out: LinkedHashMap<String, ScoreModel>) {
        val home = extractTeam(block, true) ?: return
        val away = extractTeam(block, false) ?: return

        val cleanHome = cleanForebetTeam(home)
        val cleanAway = cleanForebetTeam(away)
        if (!valid(cleanHome, cleanAway)) return

        val predicted = extractCorrectScore(block)
            ?: extractPredictedScore(block)
            ?: return

        val model = ScoreModel(cleanHome, cleanAway, predicted, source)
        out[model.matchKey] = model
    }

    private fun extractTeam(block: Element, home: Boolean): String? {
        val selectors = if (home) {
            listOf("span.homeTeam", "a .homeTeam", "[class*=homeTeam]", "[class*=hometeam]", "[class*=home_team]")
        } else {
            listOf("span.awayTeam", "a .awayTeam", "[class*=awayTeam]", "[class*=awayteam]", "[class*=away_team]")
        }

        for (selector in selectors) {
            val el = block.select(selector).firstOrNull() ?: continue
            val text = el.text().replace('\u00A0', ' ').trim()
            if (text.isNotBlank()) return text
            val alt = el.attr("title").ifBlank { el.attr("aria-label") }.trim()
            if (alt.isNotBlank()) return alt
        }
        return null
    }

    private fun extractCorrectScore(block: Element): String? {
        // Known Forebet selector first.
        val candidates = block.select(
            "div.ex_sc.tabonly, div.ex_sc, [class*=ex_sc], [class*=correct-score], [class*=correct_score]"
        )
        for (el in candidates) {
            score(el.text())?.let { return it }
            score(el.attr("data-score"))?.let { return it }
            score(el.attr("title"))?.let { return it }
        }

        // Current rows visibly contain a plain "2 - 1" after the prediction.
        // Search the row text but ignore dates, odds and other numbers by taking
        // the score nearest to the Correct score label when available.
        val text = normalize(block.text())
        val label = Regex("(?i)correct\\s*score[^0-9]{0,30}([0-5])\\s*[-:]\\s*([0-5])").find(text)
        if (label != null) return "${label.groupValues[1]}-${label.groupValues[2]}"

        // Last fallback: a score-shaped token in the row.
        return score(text)
    }

    private fun extractPredictedScore(block: Element): String? {
        for (el in block.select("span.forepr, [class*=forepr], [class*=predicted], [class*=prediction]")) {
            score(el.text())?.let { return it }
            score(el.attr("title"))?.let { return it }
            score(el.attr("data-score"))?.let { return it }
        }
        return null
    }

    private fun normalize(value: String): String =
        value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()

    private fun cleanForebetTeam(value: String): String = normalize(value)
        .trim(' ', '-', '–', '—', ':', '|')
}
