package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/**
 * Six-source repository. The five working sources and DailySports are kept
 * intact; Forebet alone gets URL fallback/diagnostics.
 */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                val result = try {
                    if (source.name == "Forebet") {
                        fetchForebet()
                    } else {
                        val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                        val (code, html) = http.get(source.url, referer)
                        if (code in 200..299 && !html.isNullOrBlank()) {
                            SourceResult(source.name, code, source.parser.parse(Jsoup.parse(html, source.url)), null)
                        } else {
                            SourceResult(source.name, code, emptyList(), "HTTP_$code")
                        }
                    }
                } catch (e: Exception) {
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }

                onProgress(index + 1, source.name)
                result
            }
        }.awaitAll()
    }

    private fun fetchForebet(): SourceResult {
        val urls = listOf(
            "https://www.forebet.com/en/football-tips-and-predictions-for-today",
            "https://www.forebet.com/en/football-predictions",
            "https://www.forebet.com/index.php/en/football-tips-and-predictions-for-today"
        )

        var lastCode = -1
        var lastError = "NO_RESPONSE"

        for (url in urls) {
            val (code, html) = http.get(url, "https://www.forebet.com/")
            lastCode = code

            if (code !in 200..299 || html.isNullOrBlank()) {
                lastError = "HTTP_${code}_HTML_${html?.length ?: 0}"
                continue
            }

            val lower = html.lowercase()
            if (lower.contains("cf-chl") || lower.contains("just a moment") ||
                lower.contains("cloudflare") || lower.contains("access denied")) {
                lastError = "BOT_PAGE_HTTP_${code}_HTML_${html.length}"
                continue
            }

            val doc = Jsoup.parse(html, url)
            val scores = ForebetParser().parse(doc)
            if (scores.isNotEmpty()) {
                return SourceResult("Forebet", code, scores, null)
            }

            lastError = "PARSER_0_HTTP_${code}_HTML_${html.length}_RCNT_${doc.select("div.rcnt").size}"
        }

        return SourceResult("Forebet", lastCode, emptyList(), lastError)
    }
}
