package com.cio.skor.ui

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchScore

class ScoreAdapter : RecyclerView.Adapter<ScoreAdapter.ScoreViewHolder>() {

    private var items: List<MatchScore> = emptyList()

    private val sourceDisplayNames = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5",
        "forebet" to "cio6"
    )

    fun submitList(newList: List<MatchScore>) {
        items = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ScoreViewHolder {
        val context = parent.context

        val cardView = CardView(context).apply {
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                val marginHoriz = dp(context, 8)
                val marginVert = dp(context, 6)
                setMargins(marginHoriz, marginVert, marginHoriz, marginVert)
            }

            radius = dp(context, 12).toFloat()
            cardElevation = dp(context, 3).toFloat()

            val padding = dp(context, 10)
            setContentPadding(padding, padding, padding, padding)

            clipChildren = false
            clipToPadding = false
        }

        val mainLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            clipChildren = false
            clipToPadding = false
        }

        cardView.addView(mainLayout)
        return ScoreViewHolder(cardView, mainLayout)
    }

    override fun onBindViewHolder(
        holder: ScoreViewHolder,
        position: Int
    ) {
        val match = items[position]
        val context = holder.itemView.context
        val container = holder.mainLayout

        container.removeAllViews()

        val tvTeams = TextView(context).apply {
            text = "⚽ ${match.homeTeam} - ${match.awayTeam}"
            textSize = 14f
            setTextColor(Color.BLACK)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(context, 6))

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        container.addView(tvTeams)

        val tvConsensus = TextView(context).apply {
            text = "🔥 KONSENSÜS ➔ ${match.consensusScore} (${match.consensusCount})"
            textSize = 13f
            setTextColor(Color.parseColor("#E53935"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, 0, 0, dp(context, 8))

            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        container.addView(tvConsensus)

        match.sourceScores.forEach { (sourceName, score) ->
            val originalSource = sourceName.trim().lowercase()

            val displayName = sourceDisplayNames[originalSource]
                ?: sourceDisplayNames.entries
                    .firstOrNull { originalSource.contains(it.key) }
                    ?.value
                ?: sourceName

            val rowLayout = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, dp(context, 2), 0, dp(context, 2))
                }
                clipChildren = false
                clipToPadding = false
            }

            val tvSource = TextView(context).apply {
                text = "🎯 $displayName"
                textSize = 12f
                setTextColor(Color.DKGRAY)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val tvScore = TextView(context).apply {
                text = "➔ $score"
                textSize = 12f
                setTextColor(Color.BLACK)
                maxLines = 1
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            rowLayout.addView(tvSource)
            rowLayout.addView(tvScore)
            container.addView(rowLayout)
        }

        holder.itemView.layoutParams =
            (holder.itemView.layoutParams
                ?: RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )).apply {
                    height = ViewGroup.LayoutParams.WRAP_CONTENT
                }
    }

    override fun getItemCount(): Int = items.size

    class ScoreViewHolder(
        itemView: CardView,
        val mainLayout: LinearLayout
    ) : RecyclerView.ViewHolder(itemView)

    private fun dp(context: Context, value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
    }
}
