package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance
import java.text.Normalizer as JavaNormalizer

/**
 * Central place for team-name normalization and cross-source fixture merging.
 * All six sources are merged only AFTER their raw ScoreModel records are collected.
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    private val removableSuffixes = setOf("fc", "fk", "sk", "cd", "nk", "afc", "club")

    /**
     * Standardize a team name before any comparison:
     * lowercase -> transliterate accents/Turkish chars -> remove punctuation ->
     * remove common club suffix tokens -> collapse whitespace.
     */
    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        // Handle the remaining Latin accented characters consistently.
        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        value = value
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = value.split(' ')
            .filter { it.isNotBlank() && it !in removableSuffixes }

        return tokens.joinToString(" ").trim()
    }

    private fun compact(value: String): String =
        normalizeTeamName(value).replace(" ", "")

    /** Levenshtein based fuzzy comparison, with containment and 70% threshold. */
    /** Stable identity key after the same normalization used by matching. */
    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    fun isSameTeam(name1: String, name2: String): Boolean {
        val norm1 = compact(name1)
        val norm2 = compact(name2)

        if (norm1.isBlank() || norm2.isBlank()) return false
        if (norm1 == norm2) return true
        if (norm1.contains(norm2) || norm2.contains(norm1)) return true

        val maxLength = maxOf(norm1.length, norm2.length)
        if (maxLength == 0) return true

        val distance = levenshtein.apply(norm1, norm2)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.70
    }

    data class UnifiedMatch(
        val mainHomeTeam: String,
        val mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf()
    )

    /**
     * Merge ALL raw source predictions into one fixture group when both
     * home and away teams match fuzzily. Source name is never part of identity.
     */
    fun mergeMatches(scrapedList: List<ScoreModel>): List<UnifiedMatch> {
        val unifiedMatches = mutableListOf<UnifiedMatch>()

        for (scraped in scrapedList) {
            val existingMatch = unifiedMatches.find { unified ->
                isSameTeam(unified.mainHomeTeam, scraped.homeTeam) &&
                    isSameTeam(unified.mainAwayTeam, scraped.awayTeam)
            }

            if (existingMatch != null) {
                // Keep one prediction per source inside the unified fixture.
                val sourceExists = existingMatch.predictions.any {
                    it.first.trim().equals(scraped.source.trim(), ignoreCase = true)
                }
                if (!sourceExists) {
                    existingMatch.predictions.add(scraped.source to scraped.predictedScore)
                }
            } else {
                unifiedMatches.add(
                    UnifiedMatch(
                        mainHomeTeam = scraped.homeTeam,
                        mainAwayTeam = scraped.awayTeam,
                        predictions = mutableListOf(scraped.source to scraped.predictedScore)
                    )
                )
            }
        }

        return unifiedMatches
    }
}
