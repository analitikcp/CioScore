# CIO Score 0.8.7 - 6 Kaynak - Match Merge FIX

Bu sürümde 6 kaynaktan gelen skorlar önce tek ham havuzda toplanır, ardından ev/deplasman takım adları normalize edilerek aynı maç tek kayda birleştirilir.

- Ev/deplasman sırası korunur.
- FC/FK/CF/SC/NK gibi yaygın kulüp ekleri normalize edilir.
- Mevcut feed'de görülen Kairat Almaty/Kairat, Ferencvarosi/Ferencvaros, Jablonec 97/Jablonec, FC Twente/Twente, Riga FC/Riga, KI Klaksvik/Klaksvik, AGF Aarhus/Aarhus, FC Thun/Thun, NK Rijeka/Rijeka, Partizan Belgrade/Partizan ve Inter Club d'Escaldes/Inter Escaldes varyantları birleştirilir.
- Aynı kaynağın aynı maç için tekrarlanan kayıtları tek tahmine düşürülür.
- `groups.size` artık birleştirilmiş farklı maç sayısını gösterir.

Çalışan diğer kaynaklara dokunulmamıştır; değişiklik esas olarak maç birleştirme/normalizasyon katmanındadır.
