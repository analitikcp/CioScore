package com.cio.skor.data

import android.content.Context
import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import java.text.Normalizer
import java.util.Locale

/** API-free Bet365 fallback using WinComparator's public prediction pages. */
class WinComparatorBet365Service(context: Context? = null) {
    data class Odds(val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()
    private val prefs = context?.getSharedPreferences("bet365_cache", Context.MODE_PRIVATE)

    @Volatile private var indexAtMs = 0L
    @Volatile private var indexHtml = ""

    fun fetch(homeTeam: String, awayTeam: String): Odds? {
        val eventUrl = findEventUrl(homeTeam, awayTeam) ?: return loadCached(homeTeam, awayTeam)
        val (code, body) = http.getSource(eventUrl, "https://www.wincomparator.com/predictions/football/")
        if (code !in 200..299 || body.isNullOrBlank()) return loadCached(homeTeam, awayTeam)
        val odds = parseEvent(body) ?: return loadCached(homeTeam, awayTeam)
        save(homeTeam, awayTeam, odds)
        return odds
    }

    private fun findEventUrl(homeTeam: String, awayTeam: String): String? {
        val now = System.currentTimeMillis()
        if (indexHtml.isBlank() || now - indexAtMs > INDEX_TTL_MS) {
            val urls = listOf(
                "https://www.wincomparator.com/predictions/football/",
                "https://www.wincomparator.com/de/tipps/fussball/morgen/"
            )
            for (url in urls) {
                val (code, body) = http.getSource(url, "https://www.wincomparator.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue
                indexHtml = body
                indexAtMs = now
                break
            }
        }
        if (indexHtml.isBlank()) return null

        val doc = Jsoup.parse(indexHtml)
        val wantedHome = normalize(homeTeam)
        val wantedAway = normalize(awayTeam)
        val anchors = doc.select("a[href]")
        for (a in anchors) {
            val text = normalize(a.text())
            if (!containsTeam(text, wantedHome) || !containsTeam(text, wantedAway)) continue
            val href = a.attr("abs:href").ifBlank { a.attr("href") }
            if (href.contains("/predictions/", true) && href.contains("-")) return href
        }
        return null
    }

    private fun parseEvent(body: String): Odds? {
        val doc = Jsoup.parse(body)
        // First try the actual 1X2 result table. WinComparator pages label it
        // "... 1x2 Results" and include a bookmaker row with Bet365.
        val tables = doc.select("table")
        for (table in tables) {
            val text = table.text()
            if (!text.contains("Bet365", true)) continue
            if (!text.contains("Bookmaker", true) && !text.contains("1x2", true)) continue
            val row = table.select("tr").firstOrNull { it.text().contains("Bet365", true) } ?: continue
            val values = Regex("(?<![A-Za-z])\\d+(?:[.,]\\d+)?").findAll(row.text())
                .map { it.value.replace(',', '.') }
                .mapNotNull { it.toDoubleOrNull() }
                .filter { it > 1.0 && it <= 1000.0 }
                .toList()
            if (values.size >= 3) return Odds(fmt(values[0]), fmt(values[1]), fmt(values[2]))
        }

        // Text fallback: isolate the first 1X2 section and locate the Bet365
        // row before the next market heading.
        val text = doc.body().text().replace(Regex("\\s+"), " ")
        val start = text.indexOf("1x2 Results", ignoreCase = true)
        if (start >= 0) {
            val end = listOf(
                text.indexOf("Under/Over", start + 5, ignoreCase = true),
                text.indexOf("Both Teams To Score", start + 5, ignoreCase = true),
                text.length
            ).filter { it >= 0 }.minOrNull() ?: text.length
            val section = text.substring(start, end)
            val bet = section.indexOf("Bet365", ignoreCase = true)
            if (bet >= 0) {
                val tail = section.substring(bet)
                val values = Regex("(?<![A-Za-z])\\d+(?:[.,]\\d+)?")
                    .findAll(tail)
                    .map { it.value.replace(',', '.') }
                    .mapNotNull { it.toDoubleOrNull() }
                    .filter { it > 1.0 && it <= 1000.0 }
                    .take(3)
                    .toList()
                if (values.size == 3) return Odds(fmt(values[0]), fmt(values[1]), fmt(values[2]))
            }
        }
        return null
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)

    private fun containsTeam(text: String, wanted: String): Boolean {
        if (wanted.isBlank()) return false
        if (text.contains(wanted)) return true
        val chunks = wanted.chunked(4).filter { it.length >= 4 }
        return chunks.size >= 2 && chunks.count { text.contains(it) } >= 2
    }

    private fun normalize(value: String): String {
        val noAccent = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace("\\p{M}".toRegex(), "")
            .lowercase(Locale.US)
        return noAccent
            .replace("ı", "i")
            .replace("&", " and ")
            .replace(Regex("\\b(k|w|f|women|woman|womens|female|fem|ladies|fc|cf|afc|sc|ac|as|sk|cd|ue)\\b"), " ")
            .replace(Regex("[^a-z0-9]+"), "")
    }

    private fun key(home: String, away: String): String = "${normalize(home)}::${normalize(away)}"

    private fun save(home: String, away: String, odds: Odds) {
        prefs?.edit()
            ?.putString(key(home, away), "${odds.ms1}|${odds.msX}|${odds.ms2}")
            ?.putLong("${key(home, away)}:time", System.currentTimeMillis())
            ?.apply()
    }

    private fun loadCached(home: String, away: String): Odds? {
        val p = prefs ?: return null
        val stamp = p.getLong("${key(home, away)}:time", 0L)
        if (stamp <= 0L || System.currentTimeMillis() - stamp > MAX_CACHE_AGE_MS) return null
        val parts = (p.getString(key(home, away), null) ?: return null).split('|')
        if (parts.size != 3) return null
        return Odds(parts[0], parts[1], parts[2])
    }

    companion object {
        private const val INDEX_TTL_MS = 120_000L
        private const val MAX_CACHE_AGE_MS = 6 * 60 * 60 * 1000L
    }
}
