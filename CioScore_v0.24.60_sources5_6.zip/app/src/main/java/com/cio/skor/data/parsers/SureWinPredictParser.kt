package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** SureWinPredict correct-score parser. */
class SureWinPredictParser : BaseParser("SureWinPredict") {

    override fun parse(doc: Document): List<ScoreModel> {
        val results = LinkedHashMap<String, ScoreModel>()
        val elements = doc.select(".prediction-item, .match-card, tr")

        for (element in elements) {
            try {
                val home = firstText(
                    element,
                    ".home-team", ".team-home", ".home", "[class*=home-team]", "[class*=team-home]"
                ) ?: continue
                val away = firstText(
                    element,
                    ".away-team", ".team-away", ".away", "[class*=away-team]", "[class*=team-away]"
                ) ?: continue

                val cleanHome = team(home)
                val cleanAway = team(away)
                if (!valid(cleanHome, cleanAway)) continue

                val predictedScore = extractPrediction(element) ?: continue
                if (!ScoreModel.hasRenderablePrediction(predictedScore)) continue

                val sourceMatchId = element.select("a[href]")
                    .map { it.attr("href").trim() }
                    .firstOrNull { it.isNotBlank() }
                    .orEmpty()

                val model = ScoreModel(
                    homeTeam = cleanHome,
                    awayTeam = cleanAway,
                    predictedScore = predictedScore,
                    source = source,
                    sourceMatchId = sourceMatchId,
                    matchTime = extractTime(element)
                )

                val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
                results[key] = model
                if (results.size >= 50) break
            } catch (_: Exception) {
                // Ignore malformed cards/rows and continue with the next match.
            }
        }

        return results.values.toList()
    }

    private fun extractPrediction(element: Element): String? {
        val explicit = firstText(
            element,
            ".correct-score",
            ".prediction-tip",
            ".predicted-score",
            "[class*=correct-score]",
            "[class*=prediction-tip]",
            "[class*=predicted-score]"
        )
        score(explicit.orEmpty())?.let { return it }

        val text = clean(element.text())
        val labelled = Regex(
            "(?i)(?:correct\\s*score|predicted\\s*score|prediction|tip)\\D{0,50}(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})"
        ).find(text)
        if (labelled != null) {
            return score("${labelled.groupValues[1]}-${labelled.groupValues[2]}")
        }

        // Safe final fallback: accept a score only when the element contains
        // one score-like token and the team names have already been identified.
        val matches = Regex("(?<!\\d)\\d{1,2}\\s*[-:]\\s*\\d{1,2}(?!\\d)")
            .findAll(text)
            .map { it.value }
            .toList()
        return if (matches.size == 1) score(matches.first()) else null
    }

    private fun extractTime(element: Element): String {
        val value = firstText(
            element,
            ".time", ".match-time", ".date", ".match-date", "[class*=time]", "[class*=date]"
        )
        return value ?: "--:--"
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.select(selector).firstOrNull()?.text()?.let(::clean)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }
}
