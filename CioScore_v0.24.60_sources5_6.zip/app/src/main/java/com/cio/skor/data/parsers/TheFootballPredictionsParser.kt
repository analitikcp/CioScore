package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * TheFootballPredictions correct-score parser.
 *
 * The site layout can expose matches as table rows or match cards. We keep the
 * extraction deliberately conservative: a row must contain identifiable home
 * and away teams plus an actual score-like prediction.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    override fun parse(doc: Document): List<ScoreModel> {
        val results = LinkedHashMap<String, ScoreModel>()
        val rows = doc.select("table.table_content tr, .match-row, .match-card, tr")

        for (row in rows) {
            val cells = row.select("td")
            if (cells.size < 2) continue

            try {
                val match = extractTeams(row, cells) ?: continue
                val home = team(match.first)
                val away = team(match.second)
                if (!valid(home, away)) continue

                val predictedScore = extractPrediction(row, cells) ?: continue
                if (!ScoreModel.hasRenderablePrediction(predictedScore)) continue

                val sourceMatchId = row.select("a[href]")
                    .map { it.attr("href").trim() }
                    .firstOrNull { it.isNotBlank() }
                    .orEmpty()

                val model = ScoreModel(
                    homeTeam = home,
                    awayTeam = away,
                    predictedScore = predictedScore,
                    source = source,
                    sourceMatchId = sourceMatchId,
                    matchTime = cells.firstOrNull()?.text()?.trim() ?: "--:--"
                )

                val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
                results[key] = model
                if (results.size >= 50) break
            } catch (_: Exception) {
                // Ignore malformed rows and continue parsing the page.
            }
        }

        return results.values.toList()
    }

    private fun extractTeams(row: Element, cells: List<Element>): Pair<String, String>? {
        // Prefer explicit team elements when the site exposes them.
        val home = firstText(row, ".home-team", ".team-home", ".home", "[class*=home-team]")
        val away = firstText(row, ".away-team", ".team-away", ".away", "[class*=away-team]")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // Otherwise use a cell containing an explicit vs/v separator.
        val visible = cells.map { clean(it.text()) }.firstOrNull {
            Regex("(?i)\\S.+\\s+(?:vs\\.?|v|versus)\\s+.+\\S").matches(it)
        }
        if (visible != null) {
            val match = Regex("(?i)^(.+?)\\s+(?:vs\\.?|v|versus)\\s+(.+)$").find(visible)
            if (match != null) return match.groupValues[1] to match.groupValues[2]
        }

        // Last fallback: adjacent cells that look like team names. Never use a
        // numeric prediction cell as a team name.
        for (i in 0 until cells.size - 1) {
            val a = clean(cells[i].text())
            val b = clean(cells[i + 1].text())
            if (looksLikeTeam(a) && looksLikeTeam(b)) return a to b
        }
        return null
    }

    private fun extractPrediction(row: Element, cells: List<Element>): String? {
        val explicit = firstText(
            row,
            ".correct-score",
            ".prediction-tip",
            ".predicted-score",
            "[class*=correct-score]",
            "[class*=prediction]"
        )
        score(explicit.orEmpty())?.let { return it }

        // The original source description places date/time, teams and
        // prediction in consecutive cells. Prefer the third cell when present.
        for (index in listOf(2, 3, 1, 0)) {
            if (index !in cells.indices) continue
            score(cells[index].text())?.let { return it }
        }

        // Only accept an explicitly labelled score from the row text.
        val text = clean(row.text())
        val labelled = Regex(
            "(?i)(?:correct\\s*score|predicted\\s*score|prediction|tip)\\D{0,40}(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})"
        ).find(text)
        return labelled?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }?.let(::score)
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.select(selector).firstOrNull()?.text()?.let(::clean)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun looksLikeTeam(value: String): Boolean {
        val v = team(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:/-]+$"))) return false
        return !v.contains(Regex("(?i)correct\\s*score|prediction|odds|probability|date|time"))
    }
}
