package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Direct bwin.com football 1X2 reader.
 *
 * We intentionally use the public football page/event HTML instead of the
 * partner Sports API because the latter requires an affiliate AccessId and
 * AccessIdToken. The bwin football page currently renders Result 1X2 as
 * 1 / X / 2 decimal prices in the server response.
 */
class BwinOddsService {
    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    private val http = HttpClient()
    private val listingUrls = listOf(
        "https://www.bwin.com/en/sports/football-4/betting",
        "https://www.bwin.com/en/sports/football-4",
        "https://www.bwin.com/en/sports/football-4/today",
        "https://www.bwin.com/en/sports/football-4/tomorrow",
        "https://www.bwin.com/en/sports/football-4/after-2-days",
        "https://www.bwin.com/en/sports/football-4/after-3-days",
        // Bwin publishes different event inventories by country/locale.
        // The SK Kladno - Banik Ostrava event, for example, is currently
        // exposed by the German/Austrian Bwin web surface even when the
        // English coupon exposes a different Banik fixture.
        "https://www.bwin.com/de-at/sports/football-4/betting",
        "https://www.bwin.com/de-at/sports/football-4",
        "https://www.bwin.com/de-at/sports/football-4/today",
        "https://www.bwin.com/de-at/sports/football-4/tomorrow",
        "https://www.bwin.com/de-at/sports/football-4/after-2-days",
        "https://www.bwin.com/de-at/sports/football-4/after-3-days",
        "https://www.bwin.com/es/sports/football-4/betting",
        "https://www.bwin.com/fr/sports/football-4/betting",
        "https://www.bwin.com/it/sports/football-4/betting"
    )

    suspend fun fetchOdds(homeTeam: String, awayTeam: String): BookmakerOdds? =
        withContext(Dispatchers.IO) {
            val home = normalize(homeTeam)
            val away = normalize(awayTeam)
            if (home.isBlank() || away.isBlank()) return@withContext null

            for (url in listingUrls) {
                val (code, body) = http.get(url, "https://www.bwin.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue

                val href = findEventHref(body, home, away)
                if (href != null) {
                    val eventUrl = absoluteUrl(href, url)
                    val (eventCode, eventBody) = http.get(eventUrl, "https://www.bwin.com/")
                    if (eventCode in 200..299 && !eventBody.isNullOrBlank()) {
                        parseEventOdds(eventBody, home, away)?.let {
                            Log.d(TAG, "BWIN DIRECT $homeTeam - $awayTeam = ${it.ms1}/${it.msX}/${it.ms2}")
                            return@withContext it
                        }
                    }
                }

                // Fallback: some regional/listing variants expose the prices
                // immediately after the event link. Parse that local segment.
                parseListingOdds(body, home, away)?.let {
                    Log.d(TAG, "BWIN LISTING $homeTeam - $awayTeam = ${it.ms1}/${it.msX}/${it.ms2}")
                    return@withContext it
                }
            }

            Log.d(TAG, "BWIN DIRECT MISS $homeTeam - $awayTeam")
            null
        }

    private fun findEventHref(html: String, home: String, away: String): String? {
        // Bwin currently renders the coupon through nested React/SSR markup.
        // The team names are not guaranteed to be the direct text child of the
        // <a>, so matching only <a>...</a> misses real events. Scan every
        // /sports/events href and use its slug as the primary identity key.
        val hrefRegex = Regex(
            "(?:href|url)\\s*=\\s*[\"']([^\"']*/sports/events/[^\"']+)[\"']",
            setOf(RegexOption.IGNORE_CASE)
        )
        for (m in hrefRegex.findAll(html)) {
            val href = m.groupValues[1]
            val hrefNorm = normalize(href)
            if (hrefNorm.contains(home) && hrefNorm.contains(away)) {
                Log.d(TAG, "BWIN EVENT HREF MATCH $home - $away -> $href")
                return href
            }
        }

        // Fallback for markup where the href is followed by escaped JSON or
        // where only the visible event block contains the names.
        val anchor = Regex(
            "<a[^>]+href=[\"']([^\"']*/sports/events/[^\"']+)[\"'][^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        for (match in anchor.findAll(html)) {
            val href = match.groupValues[1]
            val text = clean(match.groupValues[2])
            val n = normalize(text)
            val hrefNorm = normalize(href)
            if ((n.contains(home) && n.contains(away)) ||
                (hrefNorm.contains(home) && hrefNorm.contains(away))) return href
        }
        return null
    }

    private fun parseListingOdds(html: String, home: String, away: String): BookmakerOdds? {
        val hrefRegex = Regex(
            "(?:href|url)\\s*=\\s*[\"']([^\"']*/sports/events/[^\"']+)[\"']",
            setOf(RegexOption.IGNORE_CASE)
        )
        for (match in hrefRegex.findAll(html)) {
            val href = match.groupValues[1]
            val hrefNorm = normalize(href)
            if (!hrefNorm.contains(home) || !hrefNorm.contains(away)) continue
            val start = match.range.first
            val segment = clean(html.substring(start, minOf(html.length, start + 20000)))
            parseThreeWay(segment)?.let {
                Log.d(TAG, "BWIN LISTING HREF $home - $away -> $href = ${it.first}/${it.second}/${it.third}")
                return BookmakerOdds("Bwin", it.first, it.second, it.third)
            }
        }
        return null
    }

    private fun parseEventOdds(html: String, home: String, away: String): BookmakerOdds? {
        val cleanText = clean(html)
        val normalizedText = normalize(cleanText)
        if (!normalizedText.contains(home) || !normalizedText.contains(away)) return null

        // Current Bwin event pages render the main market as:
        //   [home] 5.00  X  4.00  [away] 1.50
        // and repeat the block. Anchor the extraction to the team names so
        // we do not accidentally consume a later BTTS/handicap market.
        val number = "([0-9]{1,3}(?:[.,][0-9]{1,3})?)"
        val homeRaw = Regex.escape(cleanTextToken(home))
        val awayRaw = Regex.escape(cleanTextToken(away))
        val teamPattern = Regex(
            "(?is)$homeRaw\\s+$number\\s+X\\s+$number\\s+$awayRaw\\s+$number"
        )
        teamPattern.find(cleanText)?.let { m ->
            val values = m.groupValues.drop(1).map { it.replace(',', '.') }
            if (values.size >= 3) return BookmakerOdds("Bwin", values[0], values[1], values[2])
        }

        // Some Bwin locales place the labels "1", "X", "2" around the
        // prices. Once the correct event page is known, accept either layout.
        val loose = Regex(
            "(?is)$homeRaw\\s+(?:1\\s*)?$number\\s+(?:X\\s*)?$number\\s+(?:2\\s*)?$number\\s+$awayRaw"
        )
        loose.find(cleanText)?.let { m ->
            val values = m.groupValues.drop(1).map { it.replace(',', '.') }
            if (values.size >= 3) return BookmakerOdds("Bwin", values[0], values[1], values[2])
        }

        // Fallback for pages whose markup inserts labels between team and
        // price; constrain the scan to a short window around the first home
        // team occurrence.
        val homeIndex = normalizedText.indexOf(home)
        if (homeIndex >= 0) {
            val start = maxOf(0, homeIndex - 120)
            val end = minOf(cleanText.length, homeIndex + 900)
            parseThreeWay(cleanText.substring(start, end))?.let {
                return BookmakerOdds("Bwin", it.first, it.second, it.third)
            }
        }
        return null
    }

    private fun parseThreeWay(text: String): Triple<String, String, String>? {
        val number = "([0-9]{1,3}(?:[.,][0-9]{1,3})?)"
        val patterns = listOf(
            Regex("\\b1\\s+$number\\s+X\\s+$number\\s+2\\s+$number\\b", RegexOption.IGNORE_CASE),
            Regex("$number\\s+X\\s+$number(?:\\s+[^0-9]{1,80})?$number", RegexOption.IGNORE_CASE)
        )
        for (pattern in patterns) {
            val m = pattern.find(text) ?: continue
            val values = m.groupValues.drop(1).map { it.replace(',', '.') }
            if (values.size >= 3) return Triple(values[0], values[1], values[2])
        }
        return null
    }

    private fun absoluteUrl(href: String, listingUrl: String): String {
        if (href.startsWith("http://") || href.startsWith("https://")) return href
        val origin = Regex("^(https?://[^/]+)").find(listingUrl)?.groupValues?.get(1)
            ?: "https://www.bwin.com"
        return if (href.startsWith("/")) "$origin$href" else "$origin/$href"
    }


    private fun cleanTextToken(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun clean(value: String): String = value
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun normalize(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace('ı', 'i')
        .replace('ş', 's')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("[^a-z0-9]"), "")

    companion object {
        private const val TAG = "BwinOddsService"
    }
}
