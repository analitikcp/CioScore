package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext

class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()
    
    val sources = listOf(
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions/correct-score", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/correct-scores/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/correct-score/", WinDrawWinParser()),
        Source("FootballPredictionsNet", "https://footballpredictions.net/correct-score-predictions", FootballPredictionsNetParser()),
        Source("FootballPredictionsCom", "https://footballpredictions.com/correct-score-predictions/", FPComParser()),
        Source("SoccerSeer", "https://soccerseer.com/correct-score-predictions/", SoccerSeerParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = withContext(Dispatchers.IO) {
        var completed = 0
        val tasks = sources.map { s ->
            async {
                try {
                    val (code, html) = http.get(s.url)
                    val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        s.parser.parse(Jsoup.parse(html, s.url))
                    } else emptyList()
                    synchronized(this@ScraperRepository) {
                        completed++
                        onProgress(completed, s.name)
                    }
                    SourceResult(s.name, code, scores, null)
                } catch (e: Exception) {
                    synchronized(this@ScraperRepository) {
                        completed++
                        onProgress(completed, s.name)
                    }
                    SourceResult(s.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }
        tasks.awaitAll()
    }
}