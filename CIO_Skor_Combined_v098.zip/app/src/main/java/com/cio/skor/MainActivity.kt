package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.webkit.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.SourceResult
import com.cio.skor.data.parsers.DailySportsParser
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.*
import org.jsoup.Jsoup
import java.text.Normalizer
import kotlin.coroutines.resume

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE • BİRLEŞTİRİLMİŞ SÜRÜM"
            textSize = 24f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "TÜM KAYNAKLARI TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ Taranıyor (0/${repo.sourceCount})..."
        adapter.update(emptyList())

        scope.launch {
            val results = repo.fetchAll { completed, lastSource ->
                runOnUiThread {
                    status.text = "⏳ Taranıyor ($completed/${repo.sourceCount}) • $lastSource"
                }
            }.toMutableList()

            // Check if DailySports returned 0 scores via HTTP, fallback to WebView
            val dsIndex = results.indexOfFirst { it.source == "DailySports" }
            if (dsIndex != -1 && results[dsIndex].scores.isEmpty()) {
                status.text = "🌐 DailySports WebView ile yükleniyor..."
                val webResult = loadDailySportsWithWebView()
                results[dsIndex] = webResult
            }

            showResults(results)
        }
    }

    private suspend fun loadDailySportsWithWebView(): SourceResult =
        suspendCancellableCoroutine { cont ->
            runOnUiThread {
                val web = WebView(this@MainActivity)
                val root = findViewById<LinearLayout>(100)
                root.addView(web, LinearLayout.LayoutParams(2, 2))

                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.settings.databaseEnabled = true
                web.settings.loadsImagesAutomatically = false
                web.settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
                web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
                web.webChromeClient = WebChromeClient()

                val targetUrl = "https://dailysports.net/mathematical-predictions/correct-score/"
                var finished = false

                fun cleanup() {
                    try { root.removeView(web) } catch (_: Exception) {}
                    try { web.stopLoading(); web.destroy() } catch (_: Exception) {}
                }

                fun finish(html: String?, reason: String) {
                    if (finished) return
                    finished = true
                    val raw = html.orEmpty()
                    val scores = if (raw.isNotBlank()) {
                        DailySportsParser().parse(Jsoup.parse(raw, targetUrl))
                    } else emptyList()
                    cleanup()
                    if (cont.isActive) {
                        cont.resume(
                            SourceResult(
                                "DailySports",
                                if (scores.isNotEmpty()) 200 else 0,
                                scores,
                                if (scores.isEmpty()) reason else null
                            )
                        )
                    }
                }

                fun readDom(reason: String) {
                    if (finished) return
                    web.evaluateJavascript("document.documentElement.outerHTML") { value ->
                        val html = try {
                            org.json.JSONTokener(value).nextValue() as? String
                        } catch (_: Exception) { null }
                        finish(html, reason)
                    }
                }

                web.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        view.postDelayed({ readDom("WebView 0 skor") }, 2500L)
                        view.postDelayed({ readDom("WebView 0 skor") }, 6000L)
                    }

                    override fun onReceivedError(
                        view: WebView,
                        request: WebResourceRequest,
                        error: WebResourceError
                    ) {
                        if (request.isForMainFrame) {
                            view.postDelayed({ readDom("WebView hata ${error.errorCode}: ${error.description.orEmpty()}") }, 500L)
                        }
                    }

                    override fun onReceivedHttpError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        errorResponse: WebResourceResponse?
                    ) {
                        super.onReceivedHttpError(view, request, errorResponse)
                    }
                }

                web.postDelayed({
                    readDom("WebView zaman aşımı / skor 0")
                }, 12000L)

                web.loadUrl(targetUrl)
            }
        }

    private fun showResults(results: List<SourceResult>) {
        val scores = results.flatMap { it.scores }
            .filter(::isDisplayable)
            .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }
        val goodSources = results.filter { it.scores.any(::isDisplayable) }.map { it.source }
        val groups = groupMatches(scores)
        adapter.update(groups)
        val diagnostics = results.joinToString("
") { r ->
            val state = if (r.scores.any(::isDisplayable)) "OK" else "0 skor"
            "${r.source}: HTTP ${r.httpCode}, ${r.scores.count(::isDisplayable)} skor ($state)"
        }
        status.text = "✅ ${goodSources.size}/${repo.sourceCount} kaynak • ${scores.size} temiz skor
⚽ ${groups.size} farklı maç

$diagnostics"
    }

    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        val groups = LinkedHashMap<String, MutableList<ScoreModel>>()

        for (score in scores) {
            val key = "${canonicalTeam(score.homeTeam)}|${canonicalTeam(score.awayTeam)}"
            groups.getOrPut(key) { mutableListOf() }.add(score)
        }

        return groups.values.map { list ->
            val ordered = list.distinctBy { it.source }
            MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    private fun canonicalTeam(value: String): String {
        var s = value.trim().lowercase()
        s = s.replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")

        val suffixes = listOf("footballclub", "soccerclub", "club", "fc", "fk", "cf", "sc", "afc")
        var changed = true
        while (changed) {
            changed = false
            for (suffix in suffixes) {
                if (s.endsWith(suffix) && s.length > suffix.length + 2) {
                    s = s.removeSuffix(suffix)
                    changed = true
                    break
                }
            }
        }
        return s
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}