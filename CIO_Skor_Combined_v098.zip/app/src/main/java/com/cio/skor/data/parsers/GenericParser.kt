package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class GenericParser(sourceName: String) : BaseParser(sourceName) {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val selectors = listOf(
            "article", "li", "tr", "section", "div[class*=match]", "div[class*=fixture]",
            "div[class*=prediction]", "div[class*=game]", "div[class*=event]", "div[class*=tip]"
        )
        for (el in doc.select(selectors.joinToString(","))) {
            val raw = clean(el.text())
            if (raw.length !in 8..700) continue
            val sc = score(raw) ?: continue
            val match = Regex("(?i)(.{2,60})\\s+(?:v|vs\\.?|versus|[-–—])\\s+(.{2,60})").find(raw) ?: continue
            val a = team(match.groupValues[1])
            val b = team(match.groupValues[2])
            if (valid(a, b)) {
                val key = "${a.lowercase()}|${b.lowercase()}|$sc"
                out.putIfAbsent(key, ScoreModel(a, b, sc, source))
            }
            if (out.size >= 100) break
        }
        return out.values.toList()
    }
}