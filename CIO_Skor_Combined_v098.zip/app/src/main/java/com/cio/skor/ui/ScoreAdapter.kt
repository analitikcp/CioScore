package com.cio.skor.ui

import android.graphics.Color
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel

data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(private var items: List<MatchGroup>) : RecyclerView.Adapter<ScoreAdapter.VH>() {
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    fun update(v: List<MatchGroup>) {
        items = v
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(TextView(parent.context).apply {
            setPadding(24, 18, 24, 18)
            textSize = 15f
            setTextColor(Color.DKGRAY)
        })

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = items[position]
        val sb = StringBuilder()
        sb.append("⚽ ${match.homeTeam} - ${match.awayTeam}\n")

        val scoreCounts = match.predictions
            .groupingBy { it.predictedScore }
            .eachCount()
            .entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })

        for (p in match.predictions) {
            sb.append("🎯 ${p.source} → ${p.predictedScore}\n")
        }

        val consensus = scoreCounts.firstOrNull()
        if (consensus != null && match.predictions.size > 1) {
            sb.append("🔥 KONSENSÜS → ${consensus.key} (${consensus.value}/${match.predictions.size})")
        }

        holder.tv.text = sb.toString().trimEnd()
    }
}