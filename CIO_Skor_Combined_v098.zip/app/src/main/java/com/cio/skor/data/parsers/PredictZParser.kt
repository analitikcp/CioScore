package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class PredictZParser : BaseParser("PredictZ") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val rows = doc.select("div.ptgame, tr.ptgame, div[class*=match], tr[class*=match]")
        for (row in rows) {
            val text = clean(row.text())
            val sc = score(text) ?: continue
            val match = Regex("(?i)(.{2,50})\\s+(?:v|vs)\\s+(.{2,50})").find(text)
            if (match != null) {
                val h = team(match.groupValues[1])
                val a = team(match.groupValues[2])
                if (valid(h, a)) {
                    val key = "${h.lowercase()}|${a.lowercase()}|$sc"
                    out.putIfAbsent(key, ScoreModel(h, a, sc, source))
                }
            }
        }
        return out.values.toList()
    }
}