package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class FootballPredictionsNetParser : BaseParser("FootballPredictionsNet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val items = doc.select("div[class*=prediction], div[class*=match], article")
        for (item in items) {
            val text = clean(item.text())
            val sc = score(text) ?: continue
            val match = Regex("(?i)(.{2,50})\\s+(?:v|vs)\\s+(.{2,50})").find(text)
            if (match != null) {
                val h = team(match.groupValues[1])
                val a = team(match.groupValues[2])
                if (valid(h, a)) {
                    val key = "${h.lowercase()}|${a.lowercase()}|$sc"
                    out.putIfAbsent(key, ScoreModel(h, a, sc, source))
                }
            }
        }
        return out.values.toList()
    }
}