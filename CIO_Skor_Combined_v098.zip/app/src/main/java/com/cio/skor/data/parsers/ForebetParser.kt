package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class ForebetParser : BaseParser("Forebet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val rows = doc.select("div.tr_ba, tr.tr_ba, div[class*=predict], tr[class*=predict]")
        for (row in rows) {
            val text = clean(row.text())
            val sc = score(text) ?: continue
            val teams = row.select("a.homeTeam, a.awayTeam, span.homeTeam, span.awayTeam, .teamHome, .teamAway")
            if (teams.size >= 2) {
                val h = team(teams[0].text())
                val a = team(teams[1].text())
                if (valid(h, a)) {
                    val key = "${h.lowercase()}|${a.lowercase()}|$sc"
                    out.putIfAbsent(key, ScoreModel(h, a, sc, source))
                }
            }
        }
        return out.values.toList()
    }
}