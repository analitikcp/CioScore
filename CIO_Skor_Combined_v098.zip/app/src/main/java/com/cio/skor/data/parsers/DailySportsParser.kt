package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class DailySportsParser : BaseParser("DailySports") {
    private val scoreRegex = Regex("(?i)(?:prediction|correct\\s*score|score)[^0-9]{0,30}([0-5])\\s*[:\\-]\\s*([0-5])")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val elements = doc.select("div, article, li, section")

        for (el in elements) {
            val text = clean(el.text())
            val scoreMatch = scoreRegex.find(text) ?: continue
            val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"

            val teams = extractTeams(el)
            if (teams.size < 2) continue

            val home = cleanTeam(teams[0])
            val away = cleanTeam(teams[1])

            if (!valid(home, away)) continue

            val key = "${home.lowercase()}|${away.lowercase()}|$score"
            out.putIfAbsent(key, ScoreModel(home, away, score, source))
            if (out.size >= 300) break
        }

        return out.values.toList()
    }

    private fun extractTeams(card: Element): List<String> {
        val vsMatch = Regex("(?i)(.{2,40})\\s+(?:vs|v|-)\\s+(.{2,40})").find(card.text())
        if (vsMatch != null) {
            val t1 = cleanTeam(vsMatch.groupValues[1])
            val t2 = cleanTeam(vsMatch.groupValues[2])
            if (looksLikeTeam(t1) && looksLikeTeam(t2)) return listOf(t1, t2)
        }

        val imageTeams = card.select("img[alt]")
            .map { it.attr("alt").trim() }
            .filter { looksLikeTeam(it) }
            .distinct()
        if (imageTeams.size >= 2) return imageTeams.take(2)

        val textTeams = card.select("h2, h3, h4, a, span")
            .map { clean(it.text()) }
            .filter { looksLikeTeam(it) }
            .distinct()
        if (textTeams.size >= 2) return textTeams.take(2)

        return emptyList()
    }

    private fun looksLikeTeam(s: String): Boolean {
        if (s.length !in 2..50) return false
        if (s.matches(Regex("^[0-9 .:+-]+$"))) return false
        val bad = Regex("(?i)^(game|prediction|correct score|time|today|tomorrow|1x2|o/u|btts|score)$")
        return !bad.matches(s)
    }

    private fun cleanTeam(s: String): String {
        return clean(s)
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '|')
    }
}