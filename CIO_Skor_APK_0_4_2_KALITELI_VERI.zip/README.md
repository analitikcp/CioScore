# CIO Skor 0.4.2

16 kaynaklı gerçek HTTP/HTML tarama, temiz skor ayrıştırma ve ortak skor birleştirme ekranı.
