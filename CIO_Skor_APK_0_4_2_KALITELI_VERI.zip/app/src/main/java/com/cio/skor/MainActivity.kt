package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.net.HttpURLConnection
import java.net.URL
import java.util.LinkedHashMap
import java.util.LinkedHashSet
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Prediction(val home: String, val away: String, val score: String)
private data class Result(
    val name: String,
    val code: Int,
    val predictions: List<Prediction>,
    val error: String? = null
)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button
    private lateinit var statusText: TextView
    private lateinit var consensusBox: LinearLayout

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    private val scorePattern = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
    private val teamSeparator = Regex("(?i)\\s+(?:v|vs|versus)\\s+|\\s+-\\s+")
    private val labelPattern = Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|exact\\s*score|scoreline|best)\\s*[:→-]?\\s*([0-5])\\s*[-:]\\s*([0-5])")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        window.decorView.postDelayed({ scanAll() }, 450)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 11, 16))
            setPadding(18, 18, 18, 12)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 8)
        }
        root.addView(sub)

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 16f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(Color.rgb(42, 120, 68), 10)
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 54))

        statusText = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 7, 0, 7)
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInitialRows()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        consensusBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(18, 35, 24))
            setPadding(12, 10, 12, 10)
        }
        val title = TextView(this).apply {
            text = "📊 SKOR BİRLEŞTİRME"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        consensusBox.addView(title)
        consensusBox.addView(TextView(this).apply {
            text = "Tarama tamamlandığında ortak skorlar burada oluşacak."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 4, 0, 0)
        })
        resultBox.addView(consensusBox)
        sources.forEachIndexed { index, s -> resultBox.addView(row("${index + 1}. ${s.name}", "⏳ Henüz taranmadı")) }
    }

    private fun scanAll() {
        scanButton.isEnabled = false
        scanButton.text = "⏳  16 KAYNAK TARANIYOR..."
        scanButton.background = rounded(Color.rgb(50, 58, 66), 10)
        statusText.text = "🌐 Kaynaklar paralel taranıyor..."
        showInitialRows()

        val rows = HashMap<String, TextView>()
        for (i in 1 until resultBox.childCount) {
            val box = resultBox.getChildAt(i) as LinearLayout
            rows[sources[i - 1].name] = box.getChildAt(1) as TextView
        }

        val results = LinkedHashMap<String, Result>()
        val done = AtomicInteger(0)
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                runOnUiThread {
                    results[source.name] = result
                    rows[source.name]?.let { detail ->
                        detail.text = formatResult(result)
                        detail.setTextColor(when {
                            result.predictions.isNotEmpty() -> Color.rgb(75, 235, 135)
                            result.code in 400..599 -> Color.rgb(255, 95, 95)
                            else -> Color.rgb(255, 195, 75)
                        })
                    }
                    val n = done.incrementAndGet()
                    statusText.text = "📊 Tarama: $n/${sources.size} tamamlandı"
                    if (n == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                        scanButton.background = rounded(Color.rgb(40, 125, 68), 10)
                        statusText.text = "✅ 16 kaynak taraması tamamlandı"
                        renderConsensus(results.values.toList())
                    }
                }
            }
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 9, 12, 9)
            setBackgroundColor(Color.rgb(24, 31, 39))
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 4, 0, 0)
        }
        box.addView(t)
        box.addView(d)
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 2, 0, 2) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 18000
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                setRequestProperty("Referer", source.url)
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code • erişilemedi")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "HTTP $code • boş HTML")
            val predictions = parseSource(source.name, html)
            if (predictions.isEmpty()) Result(source.name, code, emptyList(), null)
            else Result(source.name, code, predictions)
        } catch (e: javax.net.ssl.SSLHandshakeException) {
            Result(source.name, -1, emptyList(), "SSL sertifika doğrulaması başarısız")
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), "${e.javaClass.simpleName} • ${e.message ?: "bağlantı hatası"}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseSource(sourceName: String, html: String): List<Prediction> {
        val doc = Jsoup.parse(html)
        val found = LinkedHashMap<String, Prediction>()
        val elements = doc.select("tr, article, li, .match, .fixture, .game, .event, [class*=prediction], [class*=fixture], [class*=match], [class*=game], [class*=score]")

        for (el in elements) {
            val text = clean(el.text())
            if (text.length < 8 || text.length > 900) continue
            val p = parseElement(sourceName, el, text) ?: continue
            val key = normalize(p.home) + "|" + normalize(p.away) + "|" + p.score
            if (p.home.length >= 2 && p.away.length >= 2 && !isNoise(p.home) && !isNoise(p.away)) {
                found[key] = p
            }
            if (found.size >= 20) break
        }

        if (found.isEmpty()) {
            val blocks = doc.select("main, body").flatMap { it.children() }
            for (el in blocks) {
                val text = clean(el.text())
                val p = parseLooseText(text)
                if (p != null) {
                    val key = normalize(p.home) + "|" + normalize(p.away) + "|" + p.score
                    found[key] = p
                }
                if (found.size >= 12) break
            }
        }
        return found.values.take(12)
    }

    private fun parseElement(sourceName: String, el: Element, text: String): Prediction? {
        val cells = el.select("th, td").map { clean(it.text()) }.filter { it.isNotBlank() }
        if (cells.size >= 2) {
            val labeled = cells.firstNotNullOfOrNull { scoreFromLabel(it) }
            val score = labeled ?: chooseScore(cells, sourceName)
            if (score != null) {
                val teamPair = cells.firstNotNullOfOrNull { extractTeams(it) }
                    ?: extractTeams(text)
                if (teamPair != null) return Prediction(teamPair.first, teamPair.second, score)
            }
        }

        val labeled = scoreFromLabel(text)
        val score = labeled ?: chooseScore(scoreOccurrences(text), sourceName)
        if (score != null) {
            val pair = extractTeamsAroundScore(text, score)
            if (pair != null) return Prediction(pair.first, pair.second, score)
        }
        return null
    }

    private fun chooseScore(text: String, sourceName: String): String? {
        val scores = scoreOccurrences(text)
        if (scores.isEmpty()) return null
        return when (sourceName) {
            "Forebet" -> scores.getOrNull(1) ?: scores.first()
            else -> scores.firstOrNull { it != "0-0" } ?: scores.first()
        }
    }

    private fun scoreOccurrences(text: String): List<String> {
        val out = mutableListOf<String>()
        val m = scorePattern.matcher(text)
        while (m.find() && out.size < 10) out.add("${m.group(1)}-${m.group(2)}")
        return out
    }

    private fun scoreFromLabel(text: String): String? = labelPattern.find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun extractTeams(text: String): Pair<String, String>? {
        val cleaned = clean(text)
        val parts = teamSeparator.split(cleaned, limit = 2)
        if (parts.size == 2) {
            val home = sanitizeTeam(parts[0])
            val away = sanitizeTeam(parts[1])
            if (home.length >= 2 && away.length >= 2 && !isNoise(home) && !isNoise(away)) return home to away
        }
        return null
    }

    private fun extractTeamsAroundScore(text: String, score: String): Pair<String, String>? {
        val normalized = clean(text)
        val idx = normalized.indexOf(score)
        if (idx < 0) return extractTeams(normalized)
        val before = normalized.substring(0, idx)
        val after = normalized.substring(idx + score.length)
        val beforeParts = teamSeparator.split(before, limit = 2)
        if (beforeParts.size == 2) {
            val h = sanitizeTeam(beforeParts[0])
            val a = sanitizeTeam(after.substringBefore("Correct").substringBefore("Predicted"))
            if (h.length >= 2 && a.length >= 2) return h to a
        }
        val m = Regex("(?i)(.{2,70})\\s+(?:v|vs|versus)\\s+(.{2,70})").find(normalized)
        if (m != null) {
            val h = sanitizeTeam(m.groupValues[1])
            val a = sanitizeTeam(m.groupValues[2])
            if (h.length >= 2 && a.length >= 2) return h to a
        }
        return null
    }

    private fun parseLooseText(text: String): Prediction? {
        val score = scoreFromLabel(text) ?: scoreOccurrences(text).firstOrNull() ?: return null
        val pair = extractTeamsAroundScore(text, score) ?: return null
        return Prediction(pair.first, pair.second, score)
    }

    private fun sanitizeTeam(s: String): String {
        var x = s
            .replace(Regex("\\b\\d{1,2}[/:]\\d{2}\\b"), " ")
            .replace(Regex("\\b\\d{1,3}%\\b"), " ")
            .replace(Regex("\\b(?:Correct Score|Predicted Scoreline|Predicted Score|MATCH PREVIEW|Analysis|Odds|Preview)\\b.*$", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '|', '→')
        return x.take(90)
    }

    private fun isNoise(s: String): Boolean {
        val x = s.lowercase()
        val noise = listOf("correct score", "predicted", "odds", "analysis", "preview", "results", "prob", "avg goals", "prediction")
        return noise.any { x.contains(it) } || x.matches(Regex("[0-9 .%:+-]+"))
    }

    private fun normalize(s: String): String = s.lowercase()
        .replace("fc", " ")
        .replace("cf", " ")
        .replace("afc", " ")
        .replace(Regex("[^a-z0-9ğüşıöç]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    private fun formatResult(r: Result): String {
        if (r.error != null) return "❌ ${r.error}"
        if (r.predictions.isEmpty()) return "⚠️ HTTP ${r.code} • HTML geldi, temiz skor parserı 0 maç"
        return "✅ HTTP ${r.code} • ${r.predictions.size} maç\n" +
            r.predictions.joinToString("\n") { "⚽ ${it.home} - ${it.away} → ${it.score}" }
    }

    private fun renderConsensus(results: Collection<Result>) {
        consensusBox.removeAllViews()
        consensusBox.addView(TextView(this).apply {
            text = "📊 SKOR BİRLEŞTİRME"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })

        val groups = LinkedHashMap<String, MutableMap<String, MutableList<String>>>()
        for (r in results) {
            for (p in r.predictions) {
                val key = normalize(p.home) + "|" + normalize(p.away)
                val scoreMap = groups.getOrPut(key) { LinkedHashMap() }
                scoreMap.getOrPut(p.score) { mutableListOf() }.add(r.name)
            }
        }

        val ranked = groups.entries
            .map { (key, scores) ->
                val best = scores.entries.maxByOrNull { it.value.size } ?: return@map null
                Triple(key, best.key, best.value)
            }
            .filterNotNull()
            .filter { it.third.size >= 2 }
            .sortedByDescending { it.third.size }
            .take(12)

        if (ranked.isEmpty()) {
            consensusBox.addView(TextView(this).apply {
                text = "ℹ️ En az 2 kaynağın aynı maçı yakaladığı ortak skor henüz oluşmadı."
                setTextColor(Color.LTGRAY)
                textSize = 13f
                setPadding(0, 5, 0, 0)
            })
            return
        }

        ranked.forEach { item ->
            val score = item.second
            val sourcesText = item.third.joinToString(", ")
            val display = "🎯 ${score}  • ${item.third.size} kaynak\n   ${sourcesText}"
            consensusBox.addView(TextView(this).apply {
                text = display
                textSize = 14f
                setTextColor(Color.rgb(95, 240, 150))
                setPadding(0, 7, 0, 0)
            })
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
