CIO Score 0.8.14 — Forebet recovery based on the known 5-source baseline.

FP.com, PredictZ, WinDrawWin and SoccerSeer are preserved. Forebet is hardened
with a desktop browser request, retry user-agents, and a parser fallback for
both the current rcnt/homeTeam/awayTeam layout and the older meta[itemprop=name]
layout. No merge-engine changes are included in this build.
