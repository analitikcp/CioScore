package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun get(url: String): Pair<Int, String?> {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.7")
            .header("Cache-Control", "no-cache")
            .build()
        client.newCall(request).execute().use { response ->
            return response.code to response.body?.string()
        }
    }

    fun getForebet(url: String): Pair<Int, String?> {
        val userAgents = listOf(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )
        var lastCode = -1
        var lastBody: String? = null
        for (ua in userAgents) {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", ua)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.7")
                .header("Referer", "https://www.forebet.com/")
                .header("Cache-Control", "no-cache")
                .build()
            client.newCall(request).execute().use { response ->
                lastCode = response.code
                lastBody = response.body?.string()
                if (response.code in 200..299 && !lastBody.isNullOrBlank()) {
                    return response.code to lastBody
                }
            }
        }
        return lastCode to lastBody
    }
}
