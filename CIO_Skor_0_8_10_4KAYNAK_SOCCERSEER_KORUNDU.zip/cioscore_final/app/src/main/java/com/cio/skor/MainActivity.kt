package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * Stronger cross-source fixture matching.
     *
     * IMPORTANT: SoccerSeer parser is intentionally kept exactly as the
     * previously working 0.8.7 parser. Only this grouping layer changes.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        data class Bucket(
            val homeTeam: String,
            val awayTeam: String,
            val predictions: MutableList<ScoreModel>
        )

        val buckets = mutableListOf<Bucket>()

        for (score in scores) {
            var bestIndex = -1
            var bestScore = 0.0

            for (i in buckets.indices) {
                val bucket = buckets[i]
                val pairScore = fixtureSimilarity(
                    score.homeTeam,
                    score.awayTeam,
                    bucket.homeTeam,
                    bucket.awayTeam
                )
                if (pairScore > bestScore) {
                    bestScore = pairScore
                    bestIndex = i
                }
            }

            if (bestIndex >= 0 && bestScore >= 0.86) {
                buckets[bestIndex].predictions.add(score)
            } else {
                buckets += Bucket(
                    homeTeam = score.homeTeam,
                    awayTeam = score.awayTeam,
                    predictions = mutableListOf(score)
                )
            }
        }

        return buckets.map { bucket ->
            val ordered = bucket.predictions.distinctBy { it.source }
            MatchGroup(
                homeTeam = bucket.homeTeam,
                awayTeam = bucket.awayTeam,
                predictions = ordered
            )
        }
    }

    private fun fixtureSimilarity(
        homeA: String,
        awayA: String,
        homeB: String,
        awayB: String
    ): Double {
        val home = teamSimilarity(homeA, homeB)
        val away = teamSimilarity(awayA, awayB)

        // Home/away order is intentional. Reversed fixtures are never merged.
        if (home < 0.72 || away < 0.72) return 0.0
        return (home + away) / 2.0
    }

    private fun teamSimilarity(a: String, b: String): Double {
        val ca = canonicalTeam(a)
        val cb = canonicalTeam(b)
        if (ca == cb) return 1.0
        if (ca.isBlank() || cb.isBlank()) return 0.0

        val ta = teamTokens(a)
        val tb = teamTokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0

        val tokenScore = tokenSetSimilarity(ta, tb)
        val editScore = normalizedEditSimilarity(ca, cb)
        return maxOf(editScore, tokenScore)
    }

    private fun tokenSetSimilarity(a: Set<String>, b: Set<String>): Double {
        val matches = a.sumOf { tokenA ->
            b.maxOfOrNull { tokenB ->
                normalizedEditSimilarity(tokenA, tokenB)
            }?.takeIf { it >= 0.78 } ?: 0.0
        }
        val denominator = maxOf(a.size, b.size).toDouble()
        return if (denominator == 0.0) 0.0 else matches / denominator
    }

    private fun normalizedEditSimilarity(a: String, b: String): Double {
        if (a == b) return 1.0
        val maxLen = maxOf(a.length, b.length)
        if (maxLen == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / maxLen.toDouble()
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(
                    cur[j] + 1,
                    prev[j + 1] + 1,
                    prev[j] + cost
                )
            }
            for (j in prev.indices) prev[j] = cur[j]
        }
        return prev[b.length]
    }

    private fun teamTokens(value: String): Set<String> {
        var s = value.lowercase()
            .replace('ı', 'i')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ş', 's')
            .replace('ö', 'o')
            .replace('ç', 'c')

        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("(?i)\\b(?:u|under)\\s*\\d{1,2}\\b"), "")
            .replace(Regex("(?i)^\\d+[.]?\\s+"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

        val ignored = setOf(
            "fc", "fk", "cf", "sc", "afc", "club", "football", "soccer",
            "nk", "of", "the", "de", "da", "do", "del", "la", "el"
        )

        return s.split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in ignored }
            .toSet()
    }

    private fun canonicalTeam(value: String): String {
        val tokens = teamTokens(value)
        if (tokens.isNotEmpty()) return tokens.sorted().joinToString("")
        return value.lowercase().replace(Regex("[^a-z0-9]+"), "")
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
