# CIO Score 0.8.10

## 4 working sources
- FP.com
- PredictZ
- WinDrawWin
- SoccerSeer

## Important
This release starts from the 0.8.7 build where SoccerSeer was returning scores. The SoccerSeer parser was intentionally left unchanged. Only the match-grouping layer was strengthened so the four sources can be shown under the same fixture.
