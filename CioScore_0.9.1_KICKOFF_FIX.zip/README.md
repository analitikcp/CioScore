# CioScore 0.9.1

CioScore merges five correct-score sources into a single fixture and adds optional SofaScore enrichment.

Active CIO sources: FP.com, PredictZ, WinDrawWin, SoccerSeer, DailySports.

SofaScore enrichment: kickoff time, league, 1X2 odds, recent home/away form and H2H summary when available. SofaScore is not a prediction source.

The UI also shows a heuristic CIO confidence score based on source consensus and available enrichment. It is informational only and is not a guarantee of match outcome.


0.9.1 fixes the kickoff delivery path: Europe/Istanbul time, adjacent UTC calendar-day lookup, robust SofaScore fixture matching, and a visible version marker in the scan status.
