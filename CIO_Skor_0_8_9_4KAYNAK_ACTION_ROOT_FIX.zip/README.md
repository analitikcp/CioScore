CIO Score 0.8.9

Stronger cross-source fixture matching with the four intended working sources preserved.

Working source set:
- FP.com
- PredictZ
- WinDrawWin
- SoccerSeer

Important fix in 0.8.9:
- Restored SoccerSeer parsing. The date/time regex had double-escaped digit tokens, so SoccerSeer returned zero matches even though the source was still listed.
- SoccerSeer now recognizes rows such as "26 Aug 22:00 Real Madrid 1-0 Real Sociedad".
- Matching improvements remain: accent/diacritic normalization, common club suffix/prefix removal, token-aware similarity, edit-distance fallback, home/away order preservation, one prediction per source per grouped match, and unmatched SoccerSeer matches remain visible.

Build note:
- This ZIP is packed with the Android project at the ZIP root (no extra outer project folder).
- Includes .github/workflows/build-apk.yml so GitHub Actions can detect the workflow immediately.
