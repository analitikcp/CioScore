package com.cio.skor.data

import android.util.Log
import com.cio.skor.data.SofaScoreService.MatchGroupData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Flashscore 1X2 background enrichment.
 *
 * v0.10.0 goals:
 * - fail fast: each network operation has a hard upper bound,
 * - max four concurrent odds requests,
 * - fuzzy/normalized team matching,
 * - flexible 1X2 parsing without relying on one fragile JSON path,
 * - odds are emitted one-by-one as soon as they are found.
 */
class FlashscoreOddsService {
    data class Odds(val home: String, val draw: String, val away: String)

    private data class FlashEvent(
        val id: String,
        val home: String,
        val away: String
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .callTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    private val semaphore = Semaphore(4)

    suspend fun enrich(
        groups: List<MatchGroupData>,
        onProgress: (completed: Int, found: Int, total: Int) -> Unit = { _, _, _ -> },
        onItem: (group: MatchGroupData) -> Unit = {}
    ): List<MatchGroupData> = supervisorScope {
        if (groups.isEmpty()) return@supervisorScope groups

        val events = withTimeoutOrNull(4_800L) { loadTodayEvents() }.orEmpty()
        Log.d(TAG, "EVENT_INDEX size=${events.size}")

        if (events.isEmpty()) {
            onProgress(groups.size, 0, groups.size)
            return@supervisorScope groups
        }

        var completed = 0
        var found = 0
        val lock = Any()

        groups.map { group ->
            async(Dispatchers.IO) {
                try {
                    semaphore.withPermit {
                        val result = withTimeoutOrNull(4_800L) {
                            val event = resolveEvent(group.homeTeam, group.awayTeam, events)
                            val odds = event?.let { loadOdds(it.id) }

                            if (odds != null) {
                                Log.d(
                                    TAG,
                                    "ODDS_OK ${group.homeTeam} - ${group.awayTeam}: ${odds.home}/${odds.draw}/${odds.away}"
                                )
                                group.copy(
                                    odds = SofaScoreService.Odds(odds.home, odds.draw, odds.away)
                                )
                            } else {
                                if (event == null) {
                                    Log.d(TAG, "MATCH_NOT_FOUND ${group.homeTeam} - ${group.awayTeam}")
                                } else {
                                    Log.d(TAG, "ODDS_EMPTY event=${event.id} ${group.homeTeam} - ${group.awayTeam}")
                                }
                                group
                            }
                        } ?: run {
                            Log.w(TAG, "MATCH_TIMEOUT ${group.homeTeam} - ${group.awayTeam}")
                            group
                        }

                        if (result.odds != null) onItem(result)

                        val progress = synchronized(lock) {
                            completed += 1
                            if (result.odds != null) found += 1
                            Triple(completed, found, groups.size)
                        }
                        onProgress(progress.first, progress.second, progress.third)
                        result
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "ENRICH_FAIL ${group.homeTeam} - ${group.awayTeam}: ${e.javaClass.simpleName}")
                    val progress = synchronized(lock) {
                        completed += 1
                        Triple(completed, found, groups.size)
                    }
                    onProgress(progress.first, progress.second, progress.third)
                    group
                }
            }
        }.awaitAll()
    }

    private fun loadTodayEvents(): List<FlashEvent> {
        val feeds = listOf(
            "https://www.flashscore.com/x/feed/f_1_0_3_en-gb_1",
            "https://www.flashscore.com/x/feed/f_1_0_3_en_1",
            "https://d.flashscore.com/x/feed/f_1_0_3_en_1"
        )

        for (url in feeds) {
            val body = get(url, "https://www.flashscore.com/football/") ?: continue
            val parsed = parseFeed(body)
            Log.d(TAG, "FEED url=$url parsed=${parsed.size}")
            if (parsed.isNotEmpty()) return parsed
        }
        return emptyList()
    }

    private fun parseFeed(raw: String): List<FlashEvent> {
        if (!raw.contains('÷')) return emptyList()

        val out = LinkedHashMap<String, FlashEvent>()
        for (section in raw.split('~')) {
            val fields = HashMap<String, String>()
            for (part in section.split('¬')) {
                val at = part.indexOf('÷')
                if (at <= 0) continue
                fields[part.substring(0, at)] = part.substring(at + 1)
            }

            val id = fields["AA"].orEmpty().trim()
            val home = fields["AE"].orEmpty().trim()
            val away = fields["AF"].orEmpty().trim()
            if (id.isNotBlank() && home.isNotBlank() && away.isNotBlank()) {
                out[id] = FlashEvent(id, home, away)
            }
        }
        return out.values.toList()
    }

    private fun resolveEvent(home: String, away: String, events: List<FlashEvent>): FlashEvent? {
        val best = events.asSequence()
            .map { it to teamPairScore(home, away, it.home, it.away) }
            .maxByOrNull { it.second }
            ?: return null

        Log.d(
            TAG,
            "MATCH_SCORE ${home} - ${away} => ${best.first.home} - ${best.first.away} score=${String.format(Locale.US, "%.3f", best.second)}"
        )
        return best.first.takeIf { best.second >= 0.66 }
    }

    private fun loadOdds(eventId: String): Odds? {
        val urls = listOf(
            "https://global.ds.lsapp.eu/odds/pq_graphql?_hash=oce&eventId=$eventId&projectId=2&geoIpCode=TR",
            "https://46.ds.lsapp.eu/pq_graphql?_hash=ope&eventId=$eventId&projectId=46&geoIpCode=TR"
        )

        for (url in urls) {
            val body = get(url, "https://www.flashscore.com/") ?: continue
            parseOddsResponse(body)?.let { return it }
        }
        return null
    }

    /**
     * Parser order is intentionally conservative:
     * 1) labelled 1/X/2 outcomes,
     * 2) explicit 1/X/2 object keys,
     * 3) legacy/known three-way arrays,
     * 4) short market-context regex fallback.
     *
     * We never take the first three decimal numbers from the whole response,
     * because that can silently display unrelated prices as 1X2 odds.
     */
    private fun parseOddsResponse(raw: String): Odds? {
        try {
            val trimmed = raw.trim()
            val json: Any? = when {
                trimmed.startsWith("{") -> JSONObject(trimmed)
                trimmed.startsWith("[") -> JSONArray(trimmed)
                else -> null
            }

            if (json != null) {
                findLabelledSelections(json)?.let { return it }
                findKeyedOneXTwo(json)?.let { return it }
                findThreeWayOdds(json)?.let { return it }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ODDS_JSON_PARSE ${e.javaClass.simpleName}")
        }

        return findContextualOdds(raw)
    }

    private fun findLabelledSelections(value: Any?): Odds? {
        when (value) {
            is JSONObject -> {
                val arrays = sequenceOf("selections", "outcomes", "participants", "odds")
                    .mapNotNull { key -> value.optJSONArray(key) }
                    .toList()

                for (arr in arrays) {
                    val mapped = HashMap<String, Double>()
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val label = firstString(item, "name", "label", "title", "participantName", "selectionName", "outcome")
                            ?.trim()
                            ?.lowercase(Locale.US)
                            .orEmpty()
                        val price = firstNumber(item, "odds", "value", "price", "decimal", "oddsValue")
                            ?: continue

                        when {
                            label == "1" || label == "home" || label.contains("home win") -> mapped["1"] = price
                            label == "x" || label == "draw" || label.contains("draw") -> mapped["x"] = price
                            label == "2" || label == "away" || label.contains("away win") -> mapped["2"] = price
                        }
                    }
                    buildOdds(mapped["1"], mapped["x"], mapped["2"])?.let { return it }
                }

                val keys = value.keys()
                while (keys.hasNext()) {
                    findLabelledSelections(value.opt(keys.next()))?.let { return it }
                }
            }

            is JSONArray -> {
                for (i in 0 until value.length()) {
                    findLabelledSelections(value.opt(i))?.let { return it }
                }
            }
        }
        return null
    }

    private fun findKeyedOneXTwo(value: Any?): Odds? {
        when (value) {
            is JSONObject -> {
                val home = numberFromKeys(value, "1", "home", "homeOdds", "home_odds")
                val draw = numberFromKeys(value, "x", "X", "draw", "drawOdds", "draw_odds")
                val away = numberFromKeys(value, "2", "away", "awayOdds", "away_odds")
                buildOdds(home, draw, away)?.let { return it }

                val keys = value.keys()
                while (keys.hasNext()) {
                    findKeyedOneXTwo(value.opt(keys.next()))?.let { return it }
                }
            }

            is JSONArray -> {
                for (i in 0 until value.length()) {
                    findKeyedOneXTwo(value.opt(i))?.let { return it }
                }
            }
        }
        return null
    }

    private fun findThreeWayOdds(value: Any?): Odds? {
        when (value) {
            is JSONObject -> {
                val descriptor = listOf(
                    value.optString("bettingScope", ""),
                    value.optString("bettingType", ""),
                    value.optString("marketName", ""),
                    value.optString("name", ""),
                    value.optString("title", "")
                ).joinToString(" ").lowercase(Locale.US)

                val looksLikeOneXTwo = descriptor.isBlank() ||
                    descriptor.contains("1x2") ||
                    descriptor.contains("match result") ||
                    descriptor.contains("full time") ||
                    descriptor.contains("moneyline") ||
                    descriptor.contains("full_time")

                val arr = value.optJSONArray("odds")
                if (looksLikeOneXTwo && arr != null && arr.length() == 3) {
                    val nums = mutableListOf<Double>()
                    for (i in 0 until 3) {
                        extractNumber(arr.opt(i))?.let { nums += it }
                    }
                    if (nums.size == 3) buildOdds(nums[0], nums[1], nums[2])?.let { return it }
                }

                val keys = value.keys()
                while (keys.hasNext()) {
                    findThreeWayOdds(value.opt(keys.next()))?.let { return it }
                }
            }

            is JSONArray -> {
                for (i in 0 until value.length()) {
                    findThreeWayOdds(value.opt(i))?.let { return it }
                }
            }
        }
        return null
    }

    private fun findContextualOdds(raw: String): Odds? {
        val lower = raw.lowercase(Locale.US)
        val markers = listOf("1x2", "match result", "full time", "full_time", "moneyline")
        for (marker in markers) {
            var start = lower.indexOf(marker)
            while (start >= 0) {
                val end = minOf(raw.length, start + 1800)
                val window = raw.substring(start, end)
                val decimals = Regex("(?<![A-Za-z0-9])([1-9]\\d{0,2}[.,]\\d{1,3})(?![A-Za-z0-9])")
                    .findAll(window)
                    .mapNotNull { it.groupValues[1].replace(',', '.').toDoubleOrNull() }
                    .filter(::isPlausibleOdd)
                    .distinct()
                    .take(6)
                    .toList()

                if (decimals.size == 3) {
                    buildOdds(decimals[0], decimals[1], decimals[2])?.let { return it }
                }
                start = lower.indexOf(marker, start + marker.length)
            }
        }
        return null
    }

    private fun get(url: String, referer: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
            .header("Accept", "*/*")
            .header("Accept-Language", "en-GB,en;q=0.9,tr;q=0.8")
            .header("Referer", referer)
            .header("Origin", "https://www.flashscore.com")
            .header("X-Requested-With", "XMLHttpRequest")
            .header("x-fsign", "SW9D1eZo")
            .header("x-geoip", "1")
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string()
                Log.d(TAG, "HTTP ${response.code} ${request.url.host}${request.url.encodedPath} bytes=${body?.length ?: 0}")
                if (!response.isSuccessful) null else body
            }
        } catch (e: Exception) {
            Log.w(TAG, "HTTP_FAIL ${request.url.host}: ${e.javaClass.simpleName}")
            null
        }
    }

    private fun teamPairScore(wantedHome: String, wantedAway: String, actualHome: String, actualAway: String): Double {
        val direct = (teamScore(wantedHome, actualHome) + teamScore(wantedAway, actualAway)) / 2.0
        val reversed = (teamScore(wantedHome, actualAway) + teamScore(wantedAway, actualHome)) / 2.0
        return maxOf(direct, reversed - 0.15)
    }

    private fun teamScore(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0

        val aa = normalizeTeamName(a)
        val bb = normalizeTeamName(b)
        if (aa.isBlank() || bb.isBlank()) return 0.0
        if (aa == bb) return 1.0
        if (aa.contains(bb) || bb.contains(aa)) return 0.96

        val aTokens = normalizeTeamTokens(a)
        val bTokens = normalizeTeamTokens(b)
        val union = (aTokens union bTokens).size
        val jaccard = if (union == 0) 0.0 else (aTokens intersect bTokens).size.toDouble() / union.toDouble()

        val edit = normalizedLevenshtein(aa, bb)
        return maxOf(edit, jaccard)
    }

    private fun normalizeTeamName(name: String): String {
        return normalizeTeamTokens(name).joinToString("")
    }

    private fun normalizeTeamTokens(name: String): Set<String> {
        val ascii = Normalizer.normalize(name.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace('ı', 'i')
            .replace('ş', 's')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ö', 'o')
            .replace('ç', 'c')

        return ascii
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it !in TEAM_STOP_WORDS }
            .toSet()
    }

    private fun normalizedLevenshtein(a: String, b: String): Double {
        val maxLen = maxOf(a.length, b.length)
        if (maxLen == 0) return 1.0
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return 1.0 - prev[b.length].toDouble() / maxLen.toDouble()
    }

    private fun firstString(obj: JSONObject, vararg keys: String): String? {
        for (key in keys) {
            if (!obj.has(key)) continue
            val value = obj.opt(key)
            if (value is String && value.isNotBlank()) return value
        }
        return null
    }

    private fun firstNumber(obj: JSONObject, vararg keys: String): Double? {
        for (key in keys) {
            if (!obj.has(key)) continue
            extractNumber(obj.opt(key))?.let { return it }
        }
        return null
    }

    private fun numberFromKeys(obj: JSONObject, vararg keys: String): Double? {
        for (key in keys) {
            if (!obj.has(key)) continue
            extractNumber(obj.opt(key))?.let { return it }
        }
        return null
    }

    private fun extractNumber(value: Any?): Double? = when (value) {
        is Number -> value.toDouble()
        is String -> value.replace(',', '.').toDoubleOrNull()
        is JSONObject -> firstNumber(value, "value", "odds", "price", "decimal", "oddsValue")
        else -> null
    }

    private fun buildOdds(home: Double?, draw: Double?, away: Double?): Odds? {
        if (home == null || draw == null || away == null) return null
        if (!isPlausibleOdd(home) || !isPlausibleOdd(draw) || !isPlausibleOdd(away)) return null
        return Odds(format(home), format(draw), format(away))
    }

    private fun isPlausibleOdd(value: Double): Boolean = value > 1.0 && value < 100.0

    private fun format(value: Double): String = String.format(Locale.US, "%.2f", value)

    companion object {
        private const val TAG = "Flashscore"

        private val TEAM_STOP_WORDS = setOf(
            "fc", "cf", "sc", "sk", "fk", "ac", "afc", "calcio", "club",
            "football", "soccer", "team", "u19", "u20", "u21", "u23",
            "under19", "under20", "under21", "under23"
        )
    }
}
