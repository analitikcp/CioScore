package com.cio.skor.data

import java.text.Normalizer

/**
 * Cross-source fixture merger.  All raw predictions are collected first;
 * only then are team names canonicalized and fixtures grouped.
 */
object MatchMerger {

    /**
     * Tek ve merkezi takım adı normalizasyonu.
     * Tüm karşılaştırmalar bundan geçer; farklı parser'lar kendi normalizasyonunu kullanmaz.
     */
    fun normalizeTeamName(name: String): String {
        var s = name.lowercase()

        // Türkçe ve yaygın Avrupa karakterlerini ASCII karşılığına çevir.
        s = s
            .replace("ç", "c")
            .replace("ğ", "g")
            .replace("ı", "i")
            .replace("ö", "o")
            .replace("ş", "s")
            .replace("ü", "u")
            .replace("á", "a").replace("à", "a").replace("ä", "a")
            .replace("é", "e").replace("è", "e").replace("ë", "e")
            .replace("í", "i").replace("ì", "i").replace("ï", "i")
            .replace("ó", "o").replace("ò", "o").replace("ö", "o")
            .replace("ú", "u").replace("ù", "u")
            .replace("ý", "y")
            .replace("ñ", "n")
            .replace("š", "s").replace("ž", "z")
            .replace("đ", "d").replace("ð", "d")
            .replace("þ", "th").replace("ß", "ss")
            .replace("æ", "ae").replace("œ", "oe").replace("ø", "o")

        // Noktalama/özel karakterleri kaldır, boşlukları standartlaştır.
        s = s
            .replace(Regex("[^a-z0-9 ]"), "")
            .replace(Regex("\\b(fc|fk|sk|cd|nk|afc)\\b"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")

        // Kaynaklarda görülen, takım adının parçası olmayan ek kelimeler.
        val removable = setOf(
            "cf", "sc", "ac", "rc", "bv", "ks", "ss", "sv", "if", "bk",
            "mk", "as", "us", "ud"
        )
        s = s.split(' ').filter { it.isNotBlank() && it !in removable }.joinToString(" ")

        // Kaynaklar arası gerçek isim varyantları.
        val aliases = mapOf(
            "jagiellonia bialystok" to "jagiellonia",
            "kairat almaty" to "kairat",
            "ferencvarosi" to "ferencvaros",
            "ferencvaros budapest" to "ferencvaros",
            "jablonec 97" to "jablonec",
            "fc twente" to "twente",
            "twente enschede" to "twente",
            "riga football club" to "riga",
            "riga fc" to "riga",
            "ki klaksvik" to "klaksvik",
            "agf aarhus" to "aarhus",
            "aarhus gf" to "aarhus",
            "fc thun" to "thun",
            "nk rijeka" to "rijeka",
            "partizan belgrade" to "partizan",
            "inter club d escaldes" to "inter escaldes",
            "inter club descaldes" to "inter escaldes",
            "inter d escaldes" to "inter escaldes",
            "qarabag fk" to "qarabag",
            "egnatia rogozhine" to "egnatia",
            "egnatia rogzhine" to "egnatia",
            "omonia nicosia" to "omonia nicosia",
            "sint truidense" to "st truidense",
            "fc inter" to "inter turku",
            "inter turku" to "inter turku",
            "manchester united" to "manutd",
            "manchester utd" to "manutd",
            "man utd" to "manutd",
            "manchester city" to "mancity",
            "man city" to "mancity",
            "tottenham hotspur" to "tottenham",
            "psv eindhoven" to "psv",
            "paris saint germain" to "psg",
            "paris sg" to "psg",
            "borussia dortmund" to "dortmund",
            "bayern munich" to "bayern",
            "bayern munchen" to "bayern",
            "lillestrom" to "lillestrom",
            "st truidense" to "st truidense"
        )

        return aliases[s] ?: s.replace(" ", "")
    }

    // Geriye dönük uyumluluk.
    fun canonicalTeam(value: String): String = normalizeTeamName(value)

    fun key(home: String, away: String): String =
        normalizeTeamName(home) + "||" + normalizeTeamName(away)
}
