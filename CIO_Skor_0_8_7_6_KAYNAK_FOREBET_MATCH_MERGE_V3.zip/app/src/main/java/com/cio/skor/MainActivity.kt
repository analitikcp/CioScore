package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * Same match = same normalized home + normalized away team.
     * We deliberately keep home/away order so a reversed fixture is not merged.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        // IMPORTANT: all raw predictions are collected before grouping.
        // Group key is canonical HOME + canonical AWAY; source is not part
        // of the key, so predictions from different sources become one match.
        val grouped = LinkedHashMap<String, MutableList<ScoreModel>>()

        for (score in scores) {
            val key = MatchMerger.key(score.homeTeam, score.awayTeam)
            grouped.getOrPut(key) { mutableListOf() }.add(score)
        }

        return grouped.values.mapNotNull { raw ->
            val ordered = raw.distinctBy { canonicalSource(it.source) }
            if (ordered.isEmpty()) null
            else MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    private fun matchKey(home: String, away: String): String = MatchMerger.key(home, away)

    private fun canonicalSource(value: String): String =
        value.trim().lowercase().replace(Regex("\\s+"), " ")

    private fun sameTeam(a: String, b: String): Boolean =
        canonicalTeam(a) == canonicalTeam(b)

    /**
     * Cross-source team-name normalization.
     *
     * The important part is that we do NOT use fuzzy matching here. Fuzzy
     * matching can incorrectly merge different clubs. Instead we normalize
     * accents/punctuation/common prefixes/suffixes and keep a small alias table
     * for the variants actually seen in the six-source feed.
     */
    private fun canonicalTeam(value: String): String = MatchMerger.canonicalTeam(value)

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
