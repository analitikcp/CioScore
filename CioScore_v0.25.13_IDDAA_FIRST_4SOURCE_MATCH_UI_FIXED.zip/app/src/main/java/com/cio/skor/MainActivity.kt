package com.cio.skor

import kotlin.math.roundToInt
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.DropReason
import com.cio.skor.data.UnmatchedDiagnosticItem
import com.cio.skor.data.UnmatchedReason
import com.cio.skor.data.MatchMatrixRow
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore by lazy { SofaScoreService(applicationContext) }
    private val oddsPanelService by lazy { com.cio.skor.data.OddsPanelService(applicationContext) }
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private lateinit var iddaaBulletinButton: Button
    private lateinit var otherMatchesButton: Button
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    // Bookmaker odds use the existing, known-good SofaScoreService path.
    // Requests are serialized so a bulletin with many matches does not fire
    // dozens of network lookups at once.
    private val oddsQueue = ArrayDeque<Pair<String, String>>()
    private val oddsQueuedKeys = mutableSetOf<String>()
    private var oddsQueueRunning = false
    private val oddsRetryCount = mutableMapOf<String, Int>()

    private fun oddsKey(home: String, away: String): String =
        "${MatchMerger.normalizeTeamName(home)}::${MatchMerger.normalizeTeamName(away)}"

    private fun enqueueOdds(home: String, away: String) {
        val key = oddsKey(home, away)
        if (!oddsQueuedKeys.add(key)) return
        oddsQueue.addLast(home to away)
        processNextOdds()
    }

    private fun processNextOdds() {
        if (oddsQueueRunning || oddsQueue.isEmpty()) return
        val next = oddsQueue.removeFirst()
        val key = oddsKey(next.first, next.second)
        oddsQueueRunning = true

        scope.launch {
            val rows = runCatching {
                withContext(Dispatchers.IO) {
                    sofaScore.fetchBookmakerOdds(next.first, next.second)
                }
            }.getOrDefault(emptyList())

            adapter.setExternalOdds(next.first, next.second, rows)
            oddsQueuedKeys.remove(key)
            oddsQueueRunning = false

            // A transient CDN/DNS/HTTP miss must not leave the card at "...".
            // Retry a failed Bet365 lookup twice with a short backoff; after the
            // fallback sources are exhausted we stop rather than creating a loop.
            if (rows.isEmpty()) {
                val attempt = (oddsRetryCount[key] ?: 0) + 1
                oddsRetryCount[key] = attempt
                if (attempt <= 2) {
                    scope.launch {
                        delay(2500L)
                        enqueueOdds(next.first, next.second)
                    }
                }
            } else {
                oddsRetryCount.remove(key)
            }
            processNextOdds()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        val bottomSystemSpacer = findViewById<View>(R.id.bottomSystemSpacer)

        // STRONG BOTTOM-SAFE-AREA FIX
        // Android 15+/targetSdk 36 uses edge-to-edge. The navigation surface may
        // be transparent, so merely padding the RecyclerView can still leave the
        // final card visually underneath the system buttons. We reserve a real
        // layout area AFTER the RecyclerView. That area is never occupied by a
        // match card, so the last card can always be scrolled completely above
        // the navigation bar. Keep the RecyclerView padding as a secondary
        // safeguard for gesture-navigation devices.
        val baseRecyclerBottomPadding = recyclerView.paddingBottom
        val minimumBottomSafeArea = dp(104)
        ViewCompat.setOnApplyWindowInsetsListener(recyclerView) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                baseRecyclerBottomPadding + dp(16)
            )
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomSystemSpacer) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            val safeHeight = maxOf(minimumBottomSafeArea, navigationBottom + dp(24))
            view.layoutParams = view.layoutParams.apply { height = safeHeight }
            view.requestLayout()
            insets
        }
        ViewCompat.requestApplyInsets(recyclerView)
        ViewCompat.requestApplyInsets(bottomSystemSpacer)

        recyclerView.layoutManager = LinearLayoutManager(this)
        // 94+ official fixtures are valid. Disable change animations and keep
        // RecyclerView work predictable so a large bulletin cannot stall the UI.
        recyclerView.setHasFixedSize(false)
        recyclerView.itemAnimator = null
        recyclerView.setItemViewCacheSize(4)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            },
            onExternalOddsRequest = { home, away -> enqueueOdds(home, away) },
            onOddsClick = { match -> showOddsPanel(match) }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        iddaaBulletinButton = findViewById(R.id.btnIddaaBulletin)
        otherMatchesButton = findViewById(R.id.btnOtherMatches)
        iddaaBulletinButton.setOnClickListener {
            adapter.setBulletinFilter(ScoreAdapter.BulletinFilter.IDDAA_BULLETIN)
            updateBulletinFilterButtons()
        }
        otherMatchesButton.setOnClickListener {
            adapter.setBulletinFilter(ScoreAdapter.BulletinFilter.OTHER_MATCHES)
            updateBulletinFilterButtons()
        }
        updateBulletinFilterButtons()
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnDiagnostics).setOnClickListener { showDiagnostics() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun updateBulletinFilterButtons() {
        val iddaaSelected = adapter.getBulletinFilter() == ScoreAdapter.BulletinFilter.IDDAA_BULLETIN
        val iddaaCount = allGroups.count { it.isIddaaBulletinMatch }
        val otherCount = allGroups.size - iddaaCount
        // İki satırlı etiket: buton genişliği daraldığında ellipsis yerine
        // kategori adı + adet birlikte görünür.
        iddaaBulletinButton.text = "İDDAA BÜLTENİ\n$iddaaCount MAÇ"
        otherMatchesButton.text = "DİĞER MAÇLAR\n$otherCount MAÇ"
        iddaaBulletinButton.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (iddaaSelected) android.graphics.Color.rgb(0, 121, 107) else android.graphics.Color.rgb(100, 116, 139)
        )
        otherMatchesButton.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (!iddaaSelected) android.graphics.Color.rgb(0, 121, 107) else android.graphics.Color.rgb(100, 116, 139)
        )
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all configured score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all prediction sources before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { completed, source ->
                        runOnUiThread {
                            if (runId == scanGeneration) {
                                scanStatus.text = "Kaynaklar: $completed/${repo.sourceCount} — $source"
                            }
                        }
                    }
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    scanStatus.text = "Tüm tahmin kaynakları başarısız oldu."
                    Toast.makeText(this@MainActivity, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                scanStatus.text = "Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else ""

                val rawScores = results.sumOf { it.scores.size }

                // PREDICTION-FIRST HARD RULE: every parsed provider prediction is eligible
                // for the UI. Iddaa is enrichment only and is never a source gate.
                val parsedPredictionScores = results.flatMap { result: SourceResult -> result.scores }
                val displayableScores = parsedPredictionScores.filter(::isDisplayable)
                val invalidScores = rawScores - displayableScores.size

                // Diagnostic only: count prediction records after the displayability filter.
                runCatching {
                    val diagnosticCounts = parsedPredictionScores.groupingBy { it.source }.eachCount()
                    com.cio.skor.data.PipelineDiagnostics.log(
                        sourceCounts = diagnosticCounts,
                        rawPredictions = parsedPredictionScores.size
                    )
                }

                // Iddaa is fetched only for optional enrichment. It MUST NOT gate, reject,
                // or shrink the provider prediction set, regardless of bulletin window.

                // Official Iddaa enrichment uses the FULL official football bulletin.
                // HT/FT availability is only a market property; it must NEVER restrict
                // the official fixture candidate pool used by GlobalFixtureMatcher.
                // The main scan tolerates a slower official response so the full bulletin
                // has time to arrive before matching.
                val officialResult = try {
                    withTimeoutOrNull(25_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) return@launch

                // No official fixture pool is used as a gate. Provider predictions remain
                // displayable even when the official bulletin has no matching fixture.

                // Deduplicate only true provider duplicates. Team names + score + source
                // are NOT a sufficient identity: the same clubs can legitimately play more
                // than once in the bulletin. Prefer the provider's match ID; otherwise keep
                // kickoff/date/time/competition metadata in the fallback key.
                val dedupedScores: List<ScoreModel> = displayableScores.distinctBy { prediction ->
                    val home = MatchMerger.normalizeTeamName(prediction.homeTeam)
                    val away = MatchMerger.normalizeTeamName(prediction.awayTeam)
                    val source = prediction.source.trim().lowercase()
                    val providerId = prediction.sourceMatchId.trim()
                    if (providerId.isNotBlank()) {
                        "ID|$source|$providerId"
                    } else {
                        "META|$source|$home|$away|${prediction.predictedScore.trim()}|" +
                            "${prediction.matchTimestamp}|${prediction.matchDate.trim()}|" +
                            "${prediction.matchTime.trim()}|${prediction.competitionName.trim().lowercase()}"
                    }
                }

                // IMPORTANT: there is NO Iddaa prediction gate anymore.
                // We only load the official bulletin so it can optionally enrich
                // prediction cards with MS1/MSX/MS2 and HT/FT data.
                // V8: matcher sees the full unique official feed. The old 06:00-06:00
                // boundary is UI/reporting metadata only. Each prediction/official pair
                // is then reduced by GlobalFixtureMatcher's prediction-relative -12h/+48h
                // soft candidate window and its stricter <=24h time evidence.
                val officialBulletinMatches = officialResult?.matches.orEmpty()
                val officialMatcherMatches = officialResult?.allParsedMatches.orEmpty()

                // V8.3: IDDAA-FIRST DISPLAY. The official bulletin is the master
                // fixture universe. Every official fixture survives into the UI;
                // the four prediction providers are attached independently.
                val preparedGroups = withContext(Dispatchers.Default) {
                    buildPredictionFirstGroups(
                        predictions = dedupedScores,
                        // V8: use the full merged official fixture universe for matching.
                        // The 06:00-06:00 boundary is applied only to the bulletin filter
                        // flag inside MatchGroup; it is never an enrichment gate.
                        officialMatches = officialMatcherMatches,
                        iddaaBulletinStartMillis = officialResult?.bulletinStartMillis ?: 0L,
                        iddaaBulletinEndMillis = officialResult?.bulletinEndMillis ?: 0L
                    )
                }

                val iddaaMatchedForUi = preparedGroups.count { it.isIddaaBulletinMatch }
                val officialOnlyForUi = preparedGroups.count {
                    it.isIddaaBulletinMatch && it.predictions.none { p -> ScoreModel.hasRenderablePrediction(p.predictedScore) }
                }
                val matchMatrix = withContext(Dispatchers.Default) {
                    buildMatchMatrixReport(preparedGroups, officialMatcherMatches)
                }
                val predictionNotInIddaaDetails = preparedGroups
                    .filter { it.iddaaMs1 == null && it.iddaaMsX == null && it.iddaaMs2 == null }
                    .flatMap { group ->
                        group.predictions.map { prediction ->
                            "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | IDDAA=fixture-yok"
                        }
                    }
                // IMPORTANT: the 06:00-06:00 rule belongs ONLY to the official İddaa
                // bulletin. Prediction providers and SofaScore/Flashscore-derived odds
                // are never filtered by that window. This diagnostic list only records
                // predictions whose own timestamp falls outside the official bulletin;
                // it NEVER removes them from preparedGroups or the UI.
                val predictionOutsideBulletinDetails = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    dedupedScores.filter { prediction ->
                        val ts = prediction.matchTimestamp
                        ts > 0L && (
                            ts < officialResult.bulletinStartMillis ||
                                ts >= officialResult.bulletinEndMillis
                            )
                    }.map { prediction ->
                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | " +
                            "IDDAA_BULLETIN_WINDOW_DISJOINT"
                    }
                } else {
                    emptyList()
                }

                ObservabilityBus.publish(
                    ScanTrace(
                        // Build parser health reports inline. This is diagnostic-only and
                        // never filters, rejects, or removes prediction matches.
                        parserReports = results.map { result ->
                            val status = result.parserStatus
                            ParserHealthReport(
                                sourceName = result.source,
                                httpCode = result.httpCode,
                                rawHtmlBytes = result.rawHtmlBytes,
                                parsedCount = result.scores.size,
                                durationMs = result.durationMs,
                                status = status,
                                errorMessage = result.error
                            )
                        },
                        stageMetrics = linkedMapOf(
                            PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                            PipelineStage.PARSER to rawScores,
                            PipelineStage.NORMALIZATION to dedupedScores.size,
                            PipelineStage.IDENTITY to preparedGroups.size,
                            PipelineStage.CONFIDENCE to preparedGroups.count { group ->
                                group.predictions.map { it.source.trim().lowercase() }.distinct().size >= 2
                            },
                            PipelineStage.MERGE to preparedGroups.size,
                            PipelineStage.IDDAA_ENRICHMENT to iddaaMatchedForUi,
                            PipelineStage.UI to preparedGroups.size
                        ),
                        // Only genuinely invalid provider records are drops.
                        // A prediction missing from Iddaa is explicitly NOT a drop.
                        dropReasons = buildList {
                            if (invalidScores > 0) {
                                add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                            }
                        },
                        totalDurationMs = System.currentTimeMillis() - scanStartMs,
                        unmatchedOfficialDiagnostics = emptyList(),
                        officialFeedDiagnostics = officialResult?.let { result ->
                            com.cio.skor.data.OfficialFeedDiagnostics(
                                httpEvents = result.httpEvents,
                                httpMarketConfig = result.httpMarketConfig,
                                rawEventCount = result.rawEventCount,
                                parsedEventCount = result.parsedEventCount,
                                timestampedEventCount = result.timestampedEventCount,
                                bulletinEventCountBeforeMerge = result.bulletinEventCountBeforeMerge,
                                bulletinDate = result.bulletinDate,
                                bulletinWindow = result.bulletinWindow,
                                matchingCandidateWindow = "PREDICTION-RELATIVE -12h → +48h (06:00 UI boundary disabled for matcher)",
                                matchingCandidateFixtureCount = result.allParsedMatches.size,
                                mergedFixtureCount = result.mergedFixtureCount,
                                marketMatches = result.marketMatches,
                                error = result.error,
                                dateDistribution = result.dateDistribution,
                                sampleFixtures = result.sampleFixtures
                            )
                        },
                        predictionFixtureCount = preparedGroups.size,
                        officialMatchedPredictionCount = iddaaMatchedForUi,
                        officialOnlyFixtureCount = officialOnlyForUi,
                        // These two fields are enrichment diagnostics only. They do NOT
                        // represent dropped predictions.
                        predictionNotInIddaaCount = predictionNotInIddaaDetails.size,
                        predictionNotInIddaaDetails = predictionNotInIddaaDetails.toList(),
                        predictionNotInIddaaBySource = predictionNotInIddaaDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        predictionOutsideBulletinCount = predictionOutsideBulletinDetails.size,
                        predictionOutsideBulletinDetails = predictionOutsideBulletinDetails.toList(),
                        predictionOutsideBulletinBySource = predictionOutsideBulletinDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        highConfidenceConsensusFixtureCount = preparedGroups.count { group ->
                            group.predictions.asSequence()
                                .map { prediction -> prediction.source.trim().lowercase() }
                                .filter { source -> source.isNotBlank() }
                                .distinct()
                                .count() >= 2
                        },
                        matchMatrixPredictionCount = matchMatrix.predictionCount,
                        matchMatrixOfficialCount = matchMatrix.officialCount,
                        matchMatrixCombinationCount = matchMatrix.combinationCount,
                        matchMatrixMatchedCount = matchMatrix.matchedCount,
                        matchMatrixReviewCount = matchMatrix.reviewCount,
                        matchMatrixNoCandidateCount = matchMatrix.noCandidateCount,
                        matchMatrixLowConfidenceCount = matchMatrix.lowConfidenceCount,
                        matchMatrixTimeLe2hCount = matchMatrix.timeLe2hCount,
                        matchMatrixTime2to6hCount = matchMatrix.time2to6hCount,
                        matchMatrixTime6to12hCount = matchMatrix.time6to12hCount,
                        matchMatrixTime12to24hCount = matchMatrix.time12to24hCount,
                        matchMatrixOvernightRolloverCount = matchMatrix.overnightRolloverCount,
                        matchMatrixTimeOver24hCount = matchMatrix.timeOver24hCount,
                        matchMatrixRows = matchMatrix.rows
                    )
                )

                allGroups = preparedGroups
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(preparedGroups)
                recyclerView.post {
                    recyclerView.visibility = View.VISIBLE
                    recyclerView.invalidate()
                }
                scanStatus.text = "${allGroups.size} maç • Teşhis: 🔍"
                updateBulletinFilterButtons()
                focusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                scanStatus.text = "Tarama hatası: ${e.javaClass.simpleName}"
                Toast.makeText(
                    this@MainActivity,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) setScanningUi(false)
            }
        }
    }


    private data class MatchMatrixReport(
        val predictionCount: Int,
        val officialCount: Int,
        val combinationCount: Int,
        val matchedCount: Int,
        val reviewCount: Int,
        val noCandidateCount: Int,
        val lowConfidenceCount: Int,
        val timeLe2hCount: Int,
        val time2to6hCount: Int,
        val time6to12hCount: Int,
        val time12to24hCount: Int,
        val overnightRolloverCount: Int,
        val timeOver24hCount: Int,
        val rows: List<MatchMatrixRow>
    )

    /**
     * V8 diagnostic: evaluates each unique prediction only against official fixtures
     * inside the prediction-relative soft candidate window (-12h/+48h). The matrix
     * never gates the UI; it explains why an enrichment was or was not possible.
     */
    private fun buildMatchMatrixReport(
        groups: List<MatchGroup>,
        officialMatches: List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>
    ): MatchMatrixReport {
        val officialRecords = officialMatches.map { official ->
            GlobalFixtureMatcher.Record(
                homeTeam = official.homeTeam,
                awayTeam = official.awayTeam,
                source = "IDDAA",
                sourceMatchId = official.matchId,
                matchTimestamp = official.matchTimestamp,
                matchDate = official.matchDate,
                matchTime = official.matchTime,
                competitionName = official.competitionName,
                countryName = official.countryName,
                official = official
            )
        }

        var matched = 0
        var review = 0
        var noCandidate = 0
        var lowConfidence = 0
        var timeLe2h = 0
        var time2to6h = 0
        var time6to12h = 0
        var time12to24h = 0
        var overnightRollover = 0
        var timeOver24h = 0
        val rows = ArrayList<MatchMatrixRow>(groups.size)

        groups.forEach { group ->
            val predictionRecords = group.predictions.map { p ->
                GlobalFixtureMatcher.Record(
                    homeTeam = p.homeTeam,
                    awayTeam = p.awayTeam,
                    predictedScore = p.predictedScore,
                    source = p.source,
                    sourceMatchId = p.sourceMatchId,
                    matchTimestamp = p.matchTimestamp,
                    matchDate = p.matchDate,
                    matchTime = p.matchTime,
                    competitionName = p.competitionName,
                    countryName = p.countryName
                )
            }

            val cells = predictionRecords.flatMap { prediction ->
                officialRecords.asSequence()
                    .filter { official -> GlobalFixtureMatcher.isWithinSoftCandidateWindow(prediction, official) }
                    .map { official ->
                        val evidence = GlobalFixtureMatcher.score(prediction, official)
                        when {
                            evidence.timeScore >= 0.999 -> timeLe2h++
                            evidence.timeScore >= 0.85 -> time2to6h++
                            evidence.timeScore >= 0.70 -> time6to12h++
                            evidence.timeScore >= 0.40 -> time12to24h++
                            else -> timeOver24h++
                        }
                        val pt = prediction.matchTimestamp
                        val ot = official.matchTimestamp
                        if (pt > 0L && ot > 0L) {
                            val pdt = java.time.Instant.ofEpochMilli(pt).atZone(java.time.ZoneId.of("Europe/Istanbul")).toLocalDate()
                            val odt = java.time.Instant.ofEpochMilli(ot).atZone(java.time.ZoneId.of("Europe/Istanbul")).toLocalDate()
                            if (pdt != odt && kotlin.math.abs(java.time.Duration.between(java.time.Instant.ofEpochMilli(pt), java.time.Instant.ofEpochMilli(ot)).toHours()) <= 6L) {
                                overnightRollover++
                            }
                        }
                        Triple(prediction, official, evidence)
                    }
                    .toList()
            }
            val best = cells.maxWithOrNull(
                compareBy<Triple<GlobalFixtureMatcher.Record, GlobalFixtureMatcher.Record, GlobalFixtureMatcher.MatchEvidence>> { it.third.accepted }
                    .thenBy { it.third.confidence }
                    .thenBy { it.third.teamScore }
                    .thenBy { it.third.timeScore }
            )
            val bestEvidence = best?.third
            val bestOfficial = best?.second

            val teamCandidate = (bestEvidence?.teamScore ?: 0.0) > 0.30
            val strongCandidate = (bestEvidence?.teamScore ?: 0.0) >= 0.65
            val acceptedMatch = bestEvidence?.accepted == true && (bestEvidence.confidence >= 0.80)
            val status = when {
                acceptedMatch -> "MATCHED"
                !teamCandidate -> "NO_CANDIDATE"
                strongCandidate -> "REVIEW_CANDIDATE"
                else -> "REJECTED_BY_SCORE"
            }

            when (status) {
                "MATCHED" -> matched++
                "REVIEW_CANDIDATE" -> review++
                "NO_CANDIDATE" -> noCandidate++
                else -> lowConfidence++
            }

            val reason = when {
                bestEvidence == null -> "NO_OFFICIAL_CANDIDATE"
                bestEvidence.timeScore < 0.0 -> "TIME_CONTRADICTION_OR_DIRECTIONAL_REJECT"
                bestEvidence.countryScore in 0.0..0.20 && bestEvidence.teamScore >= 0.90 -> "COUNTRY_PENALTY"
                bestEvidence.competitionScore in 0.0..0.20 && bestEvidence.teamScore >= 0.90 -> "LEAGUE_PENALTY"
                bestEvidence.teamScore <= 0.30 -> "LOW_TEAM_SIMILARITY"
                bestEvidence.timeScore in 0.0..0.89 -> "TIME_WINDOW_OR_TIMEZONE"
                else -> "LOW_FINAL_CONFIDENCE"
            }

            rows += MatchMatrixRow(
                predictionHome = group.homeTeam,
                predictionAway = group.awayTeam,
                status = status,
                bestOfficialHome = bestOfficial?.homeTeam,
                bestOfficialAway = bestOfficial?.awayTeam,
                bestTeamScore = bestEvidence?.teamScore ?: 0.0,
                bestConfidence = bestEvidence?.confidence ?: 0.0,
                bestTimeScore = bestEvidence?.timeScore ?: 0.0,
                bestCountryScore = bestEvidence?.countryScore ?: 0.0,
                bestCompetitionScore = bestEvidence?.competitionScore ?: 0.0,
                acceptedCandidate = bestEvidence?.accepted == true,
                reason = reason
            )
        }

        val candidateOfficialCount = officialRecords.count { official ->
            groups.any { group ->
                group.predictions.any { prediction ->
                    GlobalFixtureMatcher.isWithinSoftCandidateWindow(
                        GlobalFixtureMatcher.Record(
                            homeTeam = prediction.homeTeam,
                            awayTeam = prediction.awayTeam,
                            predictedScore = prediction.predictedScore,
                            source = prediction.source,
                            sourceMatchId = prediction.sourceMatchId,
                            matchTimestamp = prediction.matchTimestamp,
                            matchDate = prediction.matchDate,
                            matchTime = prediction.matchTime,
                            competitionName = prediction.competitionName,
                            countryName = prediction.countryName
                        ),
                        official
                    )
                }
            }
        }

        return MatchMatrixReport(
            predictionCount = groups.size,
            officialCount = candidateOfficialCount,
            combinationCount = timeLe2h + time2to6h + time6to12h + time12to24h + timeOver24h,
            matchedCount = matched,
            reviewCount = review,
            noCandidateCount = noCandidate,
            lowConfidenceCount = lowConfidence,
            timeLe2hCount = timeLe2h,
            time2to6hCount = time2to6h,
            time6to12hCount = time6to12h,
            time12to24hCount = time12to24h,
            overnightRolloverCount = overnightRollover,
            timeOver24hCount = timeOver24h,
            rows = rows
        )
    }

    /** Iddaa-first UI grouping. Every official bulletin fixture survives; predictions are optional. */
    private fun buildPredictionFirstGroups(
        predictions: List<ScoreModel>,
        officialMatches: List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>,
        iddaaBulletinStartMillis: Long = 0L,
        iddaaBulletinEndMillis: Long = 0L
    ): List<MatchGroup> {
        // IMPORTANT: never regroup predictions with a simple home||away key here.
        // That bypassed GlobalFixtureMatcher and caused multilingual names or
        // damaged home names to split an otherwise identical fixture into cards.
        // The matcher is now the single source of truth for provider clustering.
        val unified = GlobalFixtureMatcher.merge(predictions, officialMatches)

        fun findScoreModel(record: GlobalFixtureMatcher.Record): ScoreModel? =
            predictions.firstOrNull { p ->
                p.source.equals(record.source, ignoreCase = true) &&
                    (record.sourceMatchId.isBlank() || p.sourceMatchId == record.sourceMatchId) &&
                    p.homeTeam == record.homeTeam &&
                    p.awayTeam == record.awayTeam &&
                    p.predictedScore == record.predictedScore
            }

        // GlobalFixtureMatcher already carries the best official anchor on each
        // unified component. Do not run a second full prediction × official scan
        // here: that duplicated the identity engine and could select a different
        // official fixture from the one used to form the component.


        // V8.3 INVARIANT: Iddaa is the master fixture list. Every official
        // fixture creates a card; predictions are optional child records.
        // A fixture with 0/4 provider predictions must remain visible.
        return unified.map { match ->
            val cardPredictions = match.predictionRecords
                .mapNotNull(::findScoreModel)
                .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                .distinctBy { it.source.trim().lowercase() }

            val primary = cardPredictions.firstOrNull()
            val official = match.officialMatch
            val officialInCurrentBulletin = official?.let { fixture ->
                val ts = fixture.matchTimestamp
                val start = iddaaBulletinStartMillis
                val end = iddaaBulletinEndMillis
                ts > 0L && start > 0L && end > start && ts >= start && ts < end
            } == true
            MatchGroup(
                isIddaaBulletinMatch = officialInCurrentBulletin,
                homeTeam = official?.homeTeam ?: match.mainHomeTeam.ifBlank { primary?.homeTeam.orEmpty() },
                awayTeam = official?.awayTeam ?: match.mainAwayTeam.ifBlank { primary?.awayTeam.orEmpty() },
                predictions = cardPredictions,
                iddaaProgramUrl = official?.let { buildIddaaProgramUrl(it.matchDate) },
                iddaaMs1 = official?.ms1, iddaaMsX = official?.msX, iddaaMs2 = official?.ms2,
                htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                hasHtFt = official?.hasHtFt ?: false,
                matchTimestamp = official?.matchTimestamp?.takeIf { it > 0L }
                    ?: match.predictionRecords.maxOfOrNull { it.matchTimestamp }?.takeIf { it > 0L }
                    ?: primary?.matchTimestamp ?: 0L,
                displayTime = official?.matchTime?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchTime.isNotBlank() && it.matchTime != "--:--" }?.matchTime
                    ?: primary?.matchTime ?: "--:--",
                displayDate = official?.matchDate?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchDate.isNotBlank() }?.matchDate
                    ?: primary?.matchDate.orEmpty(),
                homeTeamId = null, awayTeamId = null
            )
        }.sortedWith(
            compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                .thenBy { it.homeTeam.lowercase() }
                .thenBy { it.awayTeam.lowercase() }
        )
    }

    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    /**
     * First-ZIP style odds panel, now embedded in every match card via the
     * ORANLAR button. It is intentionally independent from the main-card
     * odds queue: opening one panel only requests that single fixture.
     */
    private fun showOddsPanel(match: MatchGroup) {
        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        fun label(text: String, size: Float = 13f, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF101828.toInt())
                if (bold) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(4), 0, dp(4))
            }

        fun addRow(row: com.cio.skor.data.OddsPanelService.OddsRow) {
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (row.primary) 0xFFF0FDF4.toInt() else 0xFFF8FAFC.toInt())
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(1), if (row.primary) 0xFFBBE7CA.toInt() else 0xFFE4E7EC.toInt())
                }
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            }
            container.addView(TextView(this).apply {
                text = if (row.primary) "★ ${row.bookmaker}" else row.bookmaker
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f)
            })
            listOf(row.ms1, row.msX, row.ms2).forEach { value ->
                container.addView(TextView(this).apply {
                    text = value
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setTextColor(0xFF155EEF.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
            }
            root.addView(container)
        }

        root.addView(label("ORANLAR", 20f, true))
        root.addView(label("${match.homeTeam}  -  ${match.awayTeam}", 13f, true))
        root.addView(label("MS1 / MSX / MS2", 11f))

        oddsPanelService.iddaaRow(match.iddaaMs1, match.iddaaMsX, match.iddaaMs2)?.let(::addRow)

        val loading = label("Yurtdışı oranlar yükleniyor…", 12f)
        root.addView(loading)
        dialog.setContentView(root)
        dialog.show()

        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val bet365 = runCatching {
                    oddsPanelService.fetchBet365(match.homeTeam, match.awayTeam)
                }.getOrNull()
                val tipster = runCatching {
                    oddsPanelService.fetchTipsterArea(
                        match.homeTeam,
                        match.awayTeam,
                        match.displayDate
                    )
                }.getOrDefault(emptyList())
                bet365 to tipster
            }

            if (!dialog.isShowing) return@launch
            root.removeView(loading)

            val bet365 = result.first
            val tipster = result.second
            if (bet365 != null) {
                addRow(bet365)
                root.addView(label("Kaynak: Bet365 fallback zinciri", 10f))
            } else {
                root.addView(label("Bet365 oranı bu maç için bulunamadı.", 12f))
            }

            if (tipster.isNotEmpty()) {
                tipster.forEach(::addRow)
                root.addView(label("Kaynak: TipsterArea · Standard 1X2", 10f))
            } else {
                root.addView(label("TipsterArea oranları bu maç için bulunamadı.", 12f))
            }
        }
    }

    private fun dp(value: Int): Int =
        android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    companion object {
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun diagnosticReportText(trace: ScanTrace): String {
        val sb = StringBuilder()
        sb.appendLine("SCAN DIAGNOSTIC PANEL [#${trace.scanId}]")
        sb.appendLine("MATCHER_CANONICAL_PIPELINE: ${GlobalFixtureMatcher.CANONICAL_PIPELINE_VERSION}")
        val successful = trace.parserReports.count { it.status == ParserStatus.HEALTHY || it.status == ParserStatus.DEGRADED }
        sb.appendLine("SÜRE: ${trace.totalDurationMs} ms | DURUM: $successful/${trace.parserReports.size} kaynak")
        sb.appendLine("PIPELINE TRACE")
        trace.stageMetrics.forEach { (stage, count) -> sb.appendLine("• ${stage.name} : $count") }
        sb.appendLine("MAÇ KÜMESİ / İDDAA MATCH MATRIX V8")
        sb.appendLine("• Benzersiz tahmin maçı : ${trace.matchMatrixPredictionCount}")
        sb.appendLine("• İddaa soft-candidate fikstürü : ${trace.matchMatrixOfficialCount}")
        sb.appendLine("• SOFT CANDIDATE PAIR   : ${trace.matchMatrixCombinationCount}")
        sb.appendLine("• İddaa ile eşleşen     : ${trace.matchMatrixMatchedCount} (MATCHED)")
        sb.appendLine("• İddaa adayı bulunan   : ${trace.matchMatrixReviewCount} (REVIEW / CANDIDATE)")
        sb.appendLine("• İddaa adayı yok       : ${trace.matchMatrixNoCandidateCount} (NO_CANDIDATE)")
        sb.appendLine("• Güven düşük / elenen  : ${trace.matchMatrixLowConfidenceCount} (REJECTED_BY_SCORE)")
        sb.appendLine("SOFT CANDIDATE WINDOW")
        sb.appendLine("• Prediction relative : -12 saat → +48 saat")
        sb.appendLine("TIME DIAGNOSTICS")
        sb.appendLine("• ≤2h                : ${trace.matchMatrixTimeLe2hCount}")
        sb.appendLine("• 2–6h               : ${trace.matchMatrixTime2to6hCount}")
        sb.appendLine("• 6–12h              : ${trace.matchMatrixTime6to12hCount}")
        sb.appendLine("• 12–24h             : ${trace.matchMatrixTime12to24hCount}")
        sb.appendLine("• Overnight rollover : ${trace.matchMatrixOvernightRolloverCount}")
        sb.appendLine("• >24h rejected      : ${trace.matchMatrixTimeOver24hCount}")
        sb.appendLine("MATRIX BREAKDOWN")
        trace.matchMatrixRows.forEachIndexed { index, row ->
            val candidate = if (row.bestOfficialHome != null && row.bestOfficialAway != null) {
                "${row.bestOfficialHome} vs ${row.bestOfficialAway}"
            } else "yok"
            sb.appendLine("${index + 1}. [${row.status}] ${row.predictionHome} vs ${row.predictionAway}")
            sb.appendLine("   ADAY: $candidate | TEAM=${"%.2f".format(java.util.Locale.US, row.bestTeamScore)} | CONF=${"%.2f".format(java.util.Locale.US, row.bestConfidence)} | TIME=${"%.2f".format(java.util.Locale.US, row.bestTimeScore)} | CTX=${"%.2f".format(java.util.Locale.US, row.bestCountryScore)} | LEAGUE=${"%.2f".format(java.util.Locale.US, row.bestCompetitionScore)} | ${row.reason}")
        }
        sb.appendLine("• İddaa dışında kalan tahmin (ATILMADI): ${trace.predictionOutsideBulletinCount}")
        if (trace.predictionOutsideBulletinBySource.isNotEmpty()) {
            sb.appendLine("• PREDICTION_OUTSIDE_06_00 KAYNAK DAĞILIMI:")
            trace.predictionOutsideBulletinBySource.toSortedMap().forEach { (source, count) ->
                sb.appendLine("   - $source: $count")
            }
        }
        if (trace.predictionOutsideBulletinDetails.isNotEmpty()) {
            sb.appendLine("• 06:00 DIŞI ÖRNEKLER:")
            trace.predictionOutsideBulletinDetails.take(12).forEach { sb.appendLine("   - $it") }
        }
        trace.officialFeedDiagnostics?.let { f ->
            sb.appendLine("İDDAA RESMİ FEED TEŞHİSİ")
            sb.appendLine("• BÜLTEN TARİHİ: ${f.bulletinDate}")
            sb.appendLine("• BÜLTEN PENCERESİ: ${f.bulletinWindow}")
            sb.appendLine("• HTTP events: ${f.httpEvents} | market-config: ${f.httpMarketConfig}")
            sb.appendLine("• RAW EVENTS: ${f.rawEventCount}")
            sb.appendLine("• PARSED EVENTS: ${f.parsedEventCount}")
            sb.appendLine("• TIMESTAMP GEÇERLİ: ${f.timestampedEventCount}")
            sb.appendLine("• BÜLTEN PENCERESİ İÇİNDE (UI): ${f.bulletinEventCountBeforeMerge}")
            sb.appendLine("• MERGE SONRASI BÜLTEN FİKSTÜRÜ: ${f.mergedFixtureCount}")
            sb.appendLine("• MATCHER RESMİ FİKSTÜR HAVUZU: ${f.matchingCandidateFixtureCount}")
            sb.appendLine("• MATCHER ADAY PENCERESİ: ${f.matchingCandidateWindow}")
            sb.appendLine("• HT/FT AÇIK: ${f.marketMatches}")
            if (f.dateDistribution.isNotEmpty()) {
                sb.appendLine("• RAW TARİH DAĞILIMI:")
                f.dateDistribution.forEach { sb.appendLine("   - $it") }
            }
            if (!f.error.isNullOrBlank()) sb.appendLine("• HATA: ${f.error}")
            if (f.sampleFixtures.isNotEmpty()) {
                sb.appendLine("• ÖRNEK RESMİ FİKSTÜRLER:")
                f.sampleFixtures.forEach { sb.appendLine("   - $it") }
            }
        } ?: sb.appendLine("• İDDAA FEED SONUCU: alınamadı")
        sb.appendLine("PARSER HEALTH")
        trace.parserReports.forEach { r ->
            sb.appendLine("• ${r.sourceName}: ${r.status} | HTTP ${r.httpCode} | ${r.parsedCount} skor | ${r.durationMs} ms${if (r.errorMessage != null) " | ${r.errorMessage}" else ""}")
        }
        sb.appendLine("DROPPED ITEMS")
        if (trace.dropReasons.isEmpty()) sb.appendLine("• Yok")
        trace.dropReasons.forEach { d ->
            val detail = if (d.details.isEmpty()) "" else " [${d.details.joinToString(", ")}]"
            sb.appendLine("• [${d.stage}] ${d.reasonCode}: ${d.count}$detail")
        }
        sb.appendLine("OFFICIAL NOT MATCHED DETAYLARI (${trace.unmatchedOfficialDiagnostics.size})")
        trace.unmatchedOfficialDiagnostics.forEachIndexed { index, item ->
            sb.appendLine("${index + 1}. ${item.predictionHome} vs ${item.predictionAway}")
            if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                sb.appendLine("   ADAY: ${item.bestOfficialHome} vs ${item.bestOfficialAway}")
            } else sb.appendLine("   ADAY: Resmi bültende aday bulunamadı")
            sb.appendLine("   TAHMİN CANONICAL: H=${item.homeCanonicalPrediction.ifBlank { "-" }} | A=${item.awayCanonicalPrediction.ifBlank { "-" }}")
            sb.appendLine("   İDDAA ADAY CANONICAL: H=${item.homeCanonicalOfficial.ifBlank { "-" }} | A=${item.awayCanonicalOfficial.ifBlank { "-" }}")
            sb.appendLine("   SIM: H=${"%.2f".format(java.util.Locale.US, item.homeSimilarity)} | A=${"%.2f".format(java.util.Locale.US, item.awaySimilarity)} | COMBINED=${"%.2f".format(java.util.Locale.US, item.combinedSimilarity)}")
            sb.appendLine("   TEŞHİS: ${diagnosticReasonLabel(item.probableReason)}")
        }
        return sb.toString()
    }

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SCAN DIAGNOSTIC PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyButton = Button(this).apply {
            text = "📋 KOPYALA"
            textSize = 11f
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("CioScore Scan Diagnostic", diagnosticReportText(trace)))
                Toast.makeText(this@MainActivity, "Teşhis raporu panoya kopyalandı.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(title)
        header.addView(copyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(header)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        // V8.2: render the same canonical diagnostic report used by the copy action.
        // The previous UI rebuilt an older V6-style panel here, so even a V8 matcher
        // could hide the 53 x N matrix and still look like the old diagnostic screen.
        box.addView(TextView(this).apply {
            text = diagnosticReportText(trace)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, 4, 0, 4)
        })

        scroll.addView(box)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.show()
    }

    private fun diagnosticReasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "🟡 ALIAS_STEMMING_PROBLEM"
        UnmatchedReason.DATE_WINDOW_MISMATCH -> "🔴 DATE_WINDOW_MISMATCH"
        UnmatchedReason.LOW_NAME_SIMILARITY -> "🟠 LOW_NAME_SIMILARITY"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "⚫ NO_OFFICIAL_CANDIDATE"
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
        if (active) scanStatus.text = "${repo.sourceCount} kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!ScoreModel.hasRenderablePrediction(x.predictedScore)) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
