# CioScore Match UI Usability Fix — v0.25.13

## Changes

### 1. Two bulletin filter buttons
- Kept the two buttons side-by-side with equal width.
- Increased the filter row height from 52dp to 58dp.
- Removed the single-line/ellipsis behavior.
- Labels now use two lines: category name + match count.
- Reduced text size to 11sp and removed extra horizontal padding so the labels remain readable on narrow screens.

### 2. Match search / pairing usability
- Single-team searches now rank exact/canonical team matches ahead of partial text matches.
- Pair searches are supported with `Home - Away`, `Home vs Away`, `Home v Away`, and `Home × Away` formats.
- Pair search validates both home and away sides together, so similarly named teams are less likely to appear as the primary result.
- Existing `GlobalFixtureMatcher` remains the source of truth for provider-to-official fixture identity; this UI change does not bypass or replace the official Iddaa matching architecture.
