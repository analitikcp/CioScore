# Betfair Odds Adapter

v0.24.91 replaces the experimental Bwin panel adapter with an independent Betfair adapter.

- Main-card Iddaa + Bet365 flow is unchanged.
- The ORANLAR panel owns the Betfair lookup independently.
- Betfair uses the existing Flashscore odds transport and filters only the Betfair 1X2 row.
- Regions attempted: GB, IE, DE.
- Only full-time 1X2 (MS1/MSX/MS2) is rendered.
- Failure is isolated: if Betfair is unavailable, Iddaa and Bet365 remain unaffected.
