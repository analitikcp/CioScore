package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Independent Betfair 1X2 adapter for the ORANLAR panel. */
class BetfairOddsService {
    data class Odds(val ms1: String, val msX: String, val ms2: String)
    data class LookupResult(
        val odds: Odds?,
        val source: String?,
        val attemptedSources: List<String>,
        val errors: List<String>
    )

    private val flashscore = FlashscoreOddsService()

    suspend fun fetch(homeTeam: String, awayTeam: String): Odds? =
        fetchWithTrace(homeTeam, awayTeam).odds

    suspend fun fetchWithTrace(homeTeam: String, awayTeam: String): LookupResult = withContext(Dispatchers.IO) {
        val attempted = listOf("Flashscore/Betfair")
        val rows = runCatching {
            flashscore.fetchBookmakerOddsFor(
                homeTeam = homeTeam,
                awayTeam = awayTeam,
                bookmakerNames = setOf("betfair"),
                regions = listOf("GB", "IE", "DE")
            )
        }.getOrElse {
            return@withContext LookupResult(null, "Flashscore/Betfair", attempted,
                listOf("${it.javaClass.simpleName}: ${it.message.orEmpty()}"))
        }
        val row = rows.firstOrNull()
        if (row != null) LookupResult(Odds(row.ms1, row.msX, row.ms2), "Flashscore/${row.bookmaker}", attempted, emptyList())
        else LookupResult(null, "Flashscore/Betfair", attempted, listOf("complete 1X2 not found"))
    }
}
