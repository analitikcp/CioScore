package com.cio.skor.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Isolated Bet365 Direct Feed layer.
 *
 * This class is deliberately NOT part of Bet365MotorV2. It talks to one
 * dedicated bookmaker feed (OddsPapi), resolves the fixture once, then reads
 * the real Bet365 1X2 row from bookmakerOdds.bet365.
 *
 * No other bookmaker is renamed to Bet365 and a failed direct feed never
 * deletes bwin/other rows already published by the UI.
 */
class Bet365DirectFeedService(context: Context) {
    companion object {
        private const val TAG = "CioBet365DirectFeed"
        private const val BASE_URL = "https://api.oddspapi.io/v4"
        private const val PREFS = "bet365_direct_feed_v1"
        private const val KEY = "api_key"
        private const val SOCCER_ID = 10
        private const val MARKET_1X2 = "101"
        private const val HOME = "101"
        private const val DRAW = "102"
        private const val AWAY = "103"
        private const val TOLERANCE_SEC = 30 * 60L
    }

    data class Fixture(
        val id: String,
        val kickoffEpochSec: Long,
        val homeTeam: String,
        val awayTeam: String
    )

    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: String = "DIRECT_FEED",
        val reason: String = ""
    )

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    fun getApiKey(): String = prefs.getString(KEY, "").orEmpty()

    fun setApiKey(value: String) {
        prefs.edit().putString(KEY, value.trim()).apply()
    }

    fun clearApiKey() {
        prefs.edit().remove(KEY).apply()
    }

    /** Load only the fixture metadata needed to map the bulletin to OddsPapi. */
    suspend fun findFixturesForDate(date: LocalDate): List<Fixture> = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isBlank()) return@withContext emptyList()

        val from = date.atStartOfDay(ZoneOffset.UTC).toInstant().toString()
        val to = date.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant().toString()
        val json = getJson("/fixtures") {
            addQueryParameter("apiKey", key)
            addQueryParameter("sportId", SOCCER_ID.toString())
            addQueryParameter("from", from)
            addQueryParameter("to", to)
            addQueryParameter("statusId", "0")
            addQueryParameter("hasOdds", "true")
            addQueryParameter("bookmakers", "bet365")
            addQueryParameter("language", "en")
        } ?: return@withContext emptyList()

        val rows = when {
            json is JSONArray -> json
            json is JSONObject -> json.optJSONArray("results") ?: json.optJSONArray("fixtures") ?: JSONArray()
            else -> JSONArray()
        }
        val out = ArrayList<Fixture>(rows.length())
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            val id = row.optString("fixtureId").trim()
            val home = row.optString("participant1Name").trim()
            val away = row.optString("participant2Name").trim()
            val kickoff = parseEpoch(row.optString("startTime"))
            if (id.isNotBlank() && home.isNotBlank() && away.isNotBlank() && kickoff > 0) {
                out += Fixture(id, kickoff, home, away)
            }
        }
        out
    }

    fun matchFixture(
        homeTeam: String,
        awayTeam: String,
        kickoffEpochSec: Long,
        fixtures: List<Fixture>
    ): Fixture? {
        val home = TeamAliasCanonicalizer.canonical(homeTeam)
        val away = TeamAliasCanonicalizer.canonical(awayTeam)
        return fixtures.asSequence()
            .filter {
                TeamAliasCanonicalizer.canonical(it.homeTeam) == home &&
                    TeamAliasCanonicalizer.canonical(it.awayTeam) == away
            }
            .minByOrNull { kotlin.math.abs(it.kickoffEpochSec - kickoffEpochSec) }
            ?.takeIf { kotlin.math.abs(it.kickoffEpochSec - kickoffEpochSec) <= TOLERANCE_SEC }
    }

    /** Fetch only the real Bet365 bookmaker node for one mapped fixture. */
    suspend fun fetchBet3651X2(fixture: Fixture): Result = withContext(Dispatchers.IO) {
        val key = getApiKey()
        if (key.isBlank()) return@withContext Result(reason = "OddsPapi API key ayarlanmadı")

        val json = getJson("/odds") {
            addQueryParameter("apiKey", key)
            addQueryParameter("fixtureId", fixture.id)
            addQueryParameter("bookmakers", "bet365")
            addQueryParameter("language", "en")
            addQueryParameter("verbosity", "3")
        } ?: return@withContext Result(reason = "OddsPapi yanıtı alınamadı")

        val books = json.optJSONObject("bookmakerOdds")
            ?: return@withContext Result(reason = "bookmakerOdds yok")
        val bet365 = books.optJSONObject("bet365")
            ?: return@withContext Result(reason = "Gerçek bet365 satırı yok")
        if (bet365.optBoolean("suspended", false) || !bet365.optBoolean("bookmakerIsActive", true)) {
            return@withContext Result(reason = "Bet365 marketi askıda/pasif")
        }

        val markets = bet365.optJSONObject("markets")
            ?: return@withContext Result(reason = "Bet365 market listesi yok")
        val market = markets.optJSONObject(MARKET_1X2)
            ?: return@withContext Result(reason = "Bet365 1X2 marketi yok")
        val outcomes = market.optJSONObject("outcomes")
            ?: return@withContext Result(reason = "Bet365 1X2 outcomes yok")

        val home = price(outcomes.optJSONObject(HOME))
        val draw = price(outcomes.optJSONObject(DRAW))
        val away = price(outcomes.optJSONObject(AWAY))
        if (!valid(home) || !valid(draw) || !valid(away)) {
            return@withContext Result(reason = "Bet365 gerçek 1X2 üçlüsü eksik")
        }

        Log.d(TAG, "DIRECT HIT ${fixture.homeTeam} - ${fixture.awayTeam}: $home/$draw/$away")
        Result(SofaScoreService.BookmakerOdds("Bet365", home!!, draw!!, away!!), reason = "OddsPapi bookmakerOdds.bet365 / market 101")
    }

    private fun price(outcome: JSONObject?): String? {
        val player = outcome?.optJSONObject("players")?.optJSONObject("0") ?: return null
        if (!player.optBoolean("active", false)) return null
        val number = player.optDouble("price", Double.NaN)
        if (!number.isFinite()) return null
        return number.toString()
    }

    private fun valid(value: String?): Boolean =
        value?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true

    private fun parseEpoch(value: String): Long = runCatching { Instant.parse(value).epochSecond }.getOrDefault(0L)

    private fun getJson(path: String, build: okhttp3.HttpUrl.Builder.() -> Unit): Any? = runCatching {
        val url = (BASE_URL + path).toHttpUrl().newBuilder().apply(build).build()
        val request = Request.Builder().url(url).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.w(TAG, "HTTP ${response.code} $path")
                return@runCatching null
            }
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) return@runCatching null
            if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body)
        }
    }.getOrElse {
        Log.w(TAG, "${path}: ${it.javaClass.simpleName}: ${it.message}")
        null
    }
}
