package com.cio.skor

import android.content.Context
import android.util.Log
import com.cio.skor.data.Bet365OddsService
import com.cio.skor.data.BwinSportsApiService
import com.cio.skor.data.IddaaMarketService
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.OddsSafariBwinService
import com.cio.skor.data.SofaScoreService
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.TipsterAreaOddsService
import com.cio.skor.data.TotalCornerOddsService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivityOddsCoordinator(
    context: Context,
    private val adapter: ScoreAdapter
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val bet365Odds by lazy { Bet365OddsService() }
    private val sofaScoreOdds by lazy { SofaScoreService(context.applicationContext) }
    private val bwinSportsApi by lazy { BwinSportsApiService() }
    private val tipsterAreaOdds by lazy { TipsterAreaOddsService() }
    private val oddsSafariBwin by lazy { OddsSafariBwinService() }
    private val totalCornerOdds by lazy { TotalCornerOddsService(context.applicationContext) }
    private val oddsQueue = ArrayDeque<MatchGroup>()
    private val oddsQueuedKeys = mutableSetOf<String>()
    private var oddsActiveWorkers = 0
    private val oddsRetryCount = mutableMapOf<String, Int>()
    private val maxOddsWorkers = 4

    private fun oddsKey(match: MatchGroup): String =
        match.fixtureId.trim().takeIf { it.isNotEmpty() }
            ?: "${MatchMerger.normalizeTeamName(match.homeTeam)}::${MatchMerger.normalizeTeamName(match.awayTeam)}::${match.displayDate.trim().lowercase()}::${TeamAliasCanonicalizer.canonical(match.homeTeam)}::${TeamAliasCanonicalizer.canonical(match.awayTeam)}"

    fun enqueueOdds(match: MatchGroup) {
        val key = oddsKey(match)
        if (!oddsQueuedKeys.add(key)) return
        oddsQueue.addLast(match)
        processOddsQueue()
    }

    fun enqueueOddsBatch(matches: List<MatchGroup>) {
        matches.forEach { match ->
            val key = oddsKey(match)
            if (oddsQueuedKeys.add(key)) oddsQueue.addLast(match)
        }
        processOddsQueue()
    }

    private fun processOddsQueue() {
        while (oddsActiveWorkers < maxOddsWorkers && oddsQueue.isNotEmpty()) {
            val next = oddsQueue.removeFirst()
            oddsActiveWorkers++
            scope.launch {
                try {
                    processOneOdds(next)
                } finally {
                    oddsActiveWorkers--
                    processOddsQueue()
                }
            }
        }
    }

    private suspend fun processOneOdds(next: MatchGroup) = kotlinx.coroutines.coroutineScope {
        val key = oddsKey(next)

        val broadDeferred = async(Dispatchers.IO) {
            if (totalCornerOdds.getToken().isBlank()) emptyList()
            else runCatching {
                totalCornerOdds.fetchBookmakers(next.homeTeam, next.awayTeam, next.matchTimestamp / 1000L)
                    .value.orEmpty()
                    .mapNotNull { r ->
                        if (r.bookmaker.equals("Bet365", true)) return@mapNotNull null
                        val h = r.latestMs1; val d = r.latestMsX; val a = r.latestMs2
                        if (h == null || d == null || a == null) null
                        else SofaScoreService.BookmakerOdds(r.bookmaker, h, d, a, source = "TotalCorner")
                    }
            }.getOrDefault(emptyList())
        }

        val bwinDeferred = async(Dispatchers.IO) {
            // SOURCE ORDER IS DELIBERATE:
            // 1) TipsterArea — first and authoritative for this app's bwin row.
            // 2) SofaScore — fallback only when TipsterArea has no complete bwin row.
            // 3) OddsSafari — second public bookmaker fallback.
            // 4) Direct bwin Sports API — last fallback when credentials/feed permit.
            // Do NOT query all four in parallel: the old design could hammer
            // TipsterArea with several simultaneous date-page requests and cause
            // 403/429/rate-limit misses across an otherwise valid fixture set.
            val tipster = runCatching {
                tipsterAreaOdds.fetch(next.homeTeam, next.awayTeam, next.displayDate)
                    .firstOrNull { it.bookmaker.equals("bwin", true) }
            }.getOrNull()
            if (tipster != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=TipsterArea ${next.homeTeam} - ${next.awayTeam} ${tipster.ms1}/${tipster.msX}/${tipster.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", tipster.ms1, tipster.msX, tipster.ms2, source = "bwin-chain")
            }

            val sofa = runCatching { sofaScoreOdds.fetchBwinOnly(next.homeTeam, next.awayTeam) }.getOrNull()
            if (sofa != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=SofaScore ${next.homeTeam} - ${next.awayTeam} ${sofa.ms1}/${sofa.msX}/${sofa.ms2}")
                return@async sofa.copy(source = "bwin-chain")
            }

            val safari = runCatching { oddsSafariBwin.fetch(next.homeTeam, next.awayTeam, next.displayDate) }.getOrNull()
            if (safari != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=OddsSafari ${next.homeTeam} - ${next.awayTeam} ${safari.ms1}/${safari.msX}/${safari.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", safari.ms1, safari.msX, safari.ms2, source = "bwin-chain")
            }

            val direct = runCatching { bwinSportsApi.fetch(next.homeTeam, next.awayTeam) }.getOrNull()
            if (direct != null) {
                Log.d("CioScoreOdds", "BWIN HIT source=BwinAPI ${next.homeTeam} - ${next.awayTeam} ${direct.ms1}/${direct.msX}/${direct.ms2}")
                return@async SofaScoreService.BookmakerOdds("bwin", direct.ms1, direct.msX, direct.ms2, source = "bwin-chain")
            }
            null
        }

        val bet365Deferred = async(Dispatchers.IO) {
            // Five-source Bet365 chain: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds.
            val local = bet365Odds.lookup(next.homeTeam, next.awayTeam, next.matchTimestamp)
            if (local.odds != null) return@async local
            bet365Odds.fetch(next.homeTeam, next.awayTeam, next.matchTimestamp)
        }

        var broad: List<SofaScoreService.BookmakerOdds> = emptyList()
        var bwin: SofaScoreService.BookmakerOdds? = null
        var bet365: Bet365OddsService.Result = Bet365OddsService.Result()

        val broadPublish = launch {
            broad = broadDeferred.await()
            if (broad.isNotEmpty()) adapter.setExternalOdds(next, broad)
        }
        val bwinPublish = launch {
            bwin = bwinDeferred.await()
            if (bwin != null) adapter.setExternalOdds(next, listOf(bwin!!))
        }
        val bet365Publish = launch {
            bet365 = bet365Deferred.await()
            bet365.odds?.let { adapter.setExternalOdds(next, listOf(it.copy(source = "Bet365-chain"))) }
            val bet365OddsRow = bet365.odds
            if (bet365OddsRow != null) {
                Log.d("CioScoreOdds", "BET365 HIT source=${bet365.source} ${next.homeTeam} - ${next.awayTeam} ${bet365OddsRow.ms1}/${bet365OddsRow.msX}/${bet365OddsRow.ms2}")
            } else {
                Log.w("CioScoreOdds", "BET365 MISS ${next.homeTeam} - ${next.awayTeam}: ${bet365.reason}")
            }
            if (bwin != null) {
                Log.d("CioScoreOdds", "BWIN HIT final ${next.homeTeam} - ${next.awayTeam} ${bwin!!.ms1}/${bwin!!.msX}/${bwin!!.ms2}")
            } else {
                Log.w("CioScoreOdds", "BWIN MISS ${next.homeTeam} - ${next.awayTeam}")
            }
        }
        broadPublish.join()
        bwinPublish.join()
        bet365Publish.join()

        oddsQueuedKeys.remove(key)
        if (bet365.odds == null && bwin == null && broad.isEmpty()) {
            val attempt = (oddsRetryCount[key] ?: 0) + 1
            oddsRetryCount[key] = attempt
            if (attempt <= 1) {
                delay(1500L)
                enqueueOdds(next)
            }
        } else {
            oddsRetryCount.remove(key)
        }
    }

    private fun validOdds(ms1: String, msX: String, ms2: String): Boolean =
        listOf(ms1, msX, ms2).all { it.toDoubleOrNull()?.let { value -> value > 1.0 && value <= 1000.0 } == true }


    fun preloadBet365(matches: List<MatchGroup>) {
        runCatching { bet365Odds.preload(matches.map { it.matchTimestamp }) }
            .onFailure { Log.w("CioScoreOdds", "Bet365 kaynak preload uyarısı: ${it.message}") }
    }

    fun cancel() { scope.cancel() }
}
