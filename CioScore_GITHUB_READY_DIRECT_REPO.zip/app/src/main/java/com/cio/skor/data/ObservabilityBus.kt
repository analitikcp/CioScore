package com.cio.skor.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-local observability bus. Keeps the latest completed scan diagnostic. */
object ObservabilityBus {
    private val _lastTrace = MutableStateFlow<ScanTrace?>(null)
    val lastTrace: StateFlow<ScanTrace?> = _lastTrace.asStateFlow()

    fun publish(trace: ScanTrace) {
        _lastTrace.value = trace
    }

    fun clear() {
        _lastTrace.value = null
    }
}
