package com.cio.skor.data

import java.security.MessageDigest
import java.util.Locale

/** Stable, source-independent fixture identity key generator. */
object FixtureIdentityEngine {
    fun generateFixtureKey(
        canonicalHome: String,
        canonicalAway: String,
        isoDate: String,
        canonicalCompetition: String
    ): String {
        val rawIdentity = listOf(canonicalHome, canonicalAway, isoDate, canonicalCompetition)
            .joinToString("|") { it.trim().lowercase(Locale.ROOT) }
        return sha256(rawIdentity)
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
