plugins {
    id("com.android.application")
}

android {
    namespace = "com.cio.skor"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.cio.skor"
        minSdk = 26
        targetSdk = 36
        versionCode = 53
        versionName = "0.5.3"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.webkit:webkit:1.15.0")
    implementation("org.jsoup:jsoup:1.18.3")
}
