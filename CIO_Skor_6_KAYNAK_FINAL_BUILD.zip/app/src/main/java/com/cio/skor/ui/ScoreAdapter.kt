package com.cio.skor.ui

import android.graphics.Color
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

/** One row per unified match; supports real-time team/match filtering. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(initialList: List<MatchGroup> = emptyList()) : RecyclerView.Adapter<ScoreAdapter.VH>() {
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    // Keep the complete result set separate from what is currently displayed.
    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    // Backward-compatible name used by MainActivity.
    fun update(v: List<MatchGroup>) = submitList(v)

    /** Real-time filtering by home team, away team, or the full match text. */
    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)
        displayedList = if (q.isEmpty()) {
            fullList
        } else {
            fullList.filter { match ->
                val home = MatchMerger.normalizeTeamName(match.homeTeam)
                val away = MatchMerger.normalizeTeamName(match.awayTeam)
                val full = MatchMerger.normalizeTeamName("${match.homeTeam} ${match.awayTeam}")
                home.contains(q) ||
                    away.contains(q) ||
                    full.contains(q) ||
                    MatchMerger.isSameTeam(home, q) ||
                    MatchMerger.isSameTeam(away, q)
            }
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(TextView(parent.context).apply {
            setPadding(24, 18, 24, 18)
            textSize = 15f
            setTextColor(Color.DKGRAY)
        })

    override fun getItemCount() = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = displayedList[position]
        val sb = StringBuilder()
        sb.append("⚽ ${match.homeTeam} - ${match.awayTeam}\n")

        val scoreCounts = match.predictions
            .groupingBy { it.predictedScore }
            .eachCount()
            .entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })

        for (prediction in match.predictions) {
            sb.append("🎯 ${prediction.source} → ${prediction.predictedScore}\n")
        }

        val consensus = scoreCounts.firstOrNull()
        if (consensus != null && match.predictions.size > 1) {
            sb.append("🔥 KONSENSÜS → ${consensus.key} (${consensus.value}/${match.predictions.size})")
        }

        holder.tv.text = sb.toString().trimEnd()
    }
}
