package com.cio.skor.data

/**
 * CioScore: 0-100. Uses only data already present in each MatchGroup:
 * 5 CIO score predictions + Mackolik MS 1X2 odds.
 *
 * Weighting:
 * - 35% exact-score consensus
 * - 25% 1X2 outcome consensus
 * - 20% market confidence (normalized implied probability)
 * - 10% CIO/market direction agreement
 * - 10% prediction stability (penalizes fragmented source opinions)
 */
object CioScoreEngine {
    data class Result(
        val score: Int,
        val confidence: String,
        val exactConsensus: Int,
        val outcomeConsensus: Int,
        val marketConfidence: Int,
        val directionAgreement: Int
    )

    fun calculate(predictions: List<ScoreModel>, odds: SofaScoreService.Odds?): Result {
        if (predictions.isEmpty()) return Result(0, "Düşük", 0, 0, 0, 0)

        val n = predictions.size.toDouble()
        val exactMax = predictions.groupingBy { it.predictedScore.trim() }.eachCount().values.maxOrNull() ?: 0
        val exact = exactMax / n

        val outcomes = predictions.mapNotNull { outcome(it.predictedScore) }
        val outcomeMax = outcomes.groupingBy { it }.eachCount().values.maxOrNull() ?: 0
        val outcome = if (outcomes.isEmpty()) 0.0 else outcomeMax / outcomes.size.toDouble()

        val market = odds?.let { marketProbabilities(it) }
        val marketConfidence = market?.maxOrNull() ?: 0.0
        val cioDirection = outcomes.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        val marketDirection = market?.let { listOf("1", "X", "2")[it.indices.maxByOrNull { i -> it[i] } ?: 0] }
        val agreement = if (cioDirection != null && marketDirection != null) {
            if (cioDirection == marketDirection) 1.0 else 0.0
        } else 0.0

        // Source stability rewards agreement and penalizes a scattered prediction set.
        // It is intentionally separate from exact consensus so one duplicated score
        // cannot make a match look exceptionally strong when the remaining sources disagree.
        val stability = ((exact + outcome) / 2.0).coerceIn(0.0, 1.0)

        val raw = 35.0 * exact + 25.0 * outcome + 20.0 * marketConfidence +
            10.0 * agreement + 10.0 * stability
        val score = raw.coerceIn(0.0, 100.0).toInt()

        val confidence = when {
            score >= 80 -> "Yüksek"
            score >= 65 -> "Orta-Yüksek"
            score >= 50 -> "Orta"
            else -> "Düşük"
        }

        return Result(
            score = score,
            confidence = confidence,
            exactConsensus = (exact * 100).toInt(),
            outcomeConsensus = (outcome * 100).toInt(),
            marketConfidence = (marketConfidence * 100).toInt(),
            directionAgreement = (agreement * 100).toInt()
        )
    }

    private fun marketProbabilities(odds: SofaScoreService.Odds): List<Double>? {
        val values = listOf(odds.home.toDoubleOrNull(), odds.draw.toDoubleOrNull(), odds.away.toDoubleOrNull())
        if (values.any { value -> value == null || value <= 1.0 }) return null
        val raw = values.map { value -> 1.0 / (value ?: return null) }
        val total = raw.sum()
        if (total <= 0.0) return null
        return raw.map { it / total }
    }

    /** Returns 1, X or 2 from a predicted final score. */
    private fun outcome(score: String): String? {
        val m = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = m.groupValues[1].toIntOrNull() ?: return null
        val away = m.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }
}
