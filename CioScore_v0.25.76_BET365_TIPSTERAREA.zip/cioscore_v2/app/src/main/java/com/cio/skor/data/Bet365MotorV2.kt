package com.cio.skor.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * Bet365 Motoru v2
 *
 * Every attempt is recorded with its own provenance. A Bet365 price is never
 * copied from another bookmaker and a source is never reported as successful
 * unless a complete 1X2 triple is present.
 */
class Bet365MotorV2(context: Context) {
    enum class Source { API, TIPSTERAREA, TOTALCORNER, FLASHSCORE, SOFA, AISCORE, CACHE, NONE }

    data class Attempt(
        val source: Source,
        val ok: Boolean,
        val reason: String
    )

    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: Source = Source.NONE,
        val attempts: List<Attempt> = emptyList(),
        val history: OddsDataApiService.FixtureOddsHistory? = null
    )

    private val api = OddsDataApiService(context)
    private val sofa = SofaScoreService(context)
    private val flashscore = FlashscoreOddsService()
    private val aiScore = AiScoreOddsService()
    private val historyStore = Bet365OddsHistoryStore(context)
    private val providerHistory = ProviderOddsHistoryStore(context)
    private val totalCorner = TotalCornerOddsService(context)

    suspend fun resolve(
        homeTeam: String,
        awayTeam: String,
        kickoffEpochSec: Long,
        displayDate: String,
        providerFixtures: List<OddsDataApiService.ProviderFixture>,
        tipsterAreaOdds: List<TipsterAreaOddsService.Odds>? = null
    ): Result = withContext(Dispatchers.IO) {
        coroutineScope {
            // Cache is checked first only as a fast fallback; live providers are
            // queried in parallel so one slow source cannot serialize the chain.
            val cache = historyStore.get(homeTeam, awayTeam, kickoffEpochSec)
            val cacheFresh = cache?.latestCapturedAt?.let { System.currentTimeMillis() - it <= MAX_CACHE_AGE_MS } == true

            data class Live(val source: Source, val odds: SofaScoreService.BookmakerOdds?, val reason: String, val history: OddsDataApiService.FixtureOddsHistory? = null)

            val apiDeferred = async(Dispatchers.IO) {
                if (api.getToken().isBlank()) return@async Live(Source.API, null, "API token ayarlanmadı")
                val fixture = api.matchFixture(homeTeam, awayTeam, kickoffEpochSec, providerFixtures)
                    ?: return@async Live(Source.API, null, "Bet365 fixture eşleşmedi (takım/saat)")
                val direct = api.fetchBet365Prematch(fixture)
                if (direct.value != null && valid(direct.value.home, direct.value.draw, direct.value.away)) {
                    return@async Live(Source.API, SofaScoreService.BookmakerOdds("Bet365", direct.value.home, direct.value.draw, direct.value.away), "FI direct 1X2")
                }
                val hist = api.fetchOddsHistory(fixture)
                val h = hist.value
                val line = h?.latestPreMatch ?: h?.closing
                if (line != null && valid(line.home, line.draw, line.away)) {
                    return@async Live(Source.API, SofaScoreService.BookmakerOdds("Bet365", line.home, line.draw, line.away), "event history 1X2", h)
                }
                Live(Source.API, null, (direct.error ?: "FI 1X2 eksik") + if (hist.error != null) "; history: ${short(hist.error)}" else "; history 1X2 yok", h)
            }

            val tipsterDeferred = async(Dispatchers.IO) {
                val rows = tipsterAreaOdds ?: runCatching {
                    TipsterAreaOddsService().fetch(homeTeam, awayTeam, displayDate)
                }.getOrDefault(emptyList())
                val row = rows.firstOrNull { it.bookmaker.equals("Bet365", true) && valid(it.ms1, it.msX, it.ms2) }
                if (row != null) Live(Source.TIPSTERAREA, SofaScoreService.BookmakerOdds("Bet365", row.ms1, row.msX, row.ms2), "TipsterArea Bet365 1X2")
                else Live(Source.TIPSTERAREA, null, "TipsterArea Bet365 satırı bulunamadı")
            }

            val totalCornerDeferred = async(Dispatchers.IO) {
                if (totalCorner.getToken().isBlank()) Live(Source.TOTALCORNER, null, "TotalCorner token ayarlanmadı")
                else {
                    val row = runCatching {
                        totalCorner.fetchBookmakers(homeTeam, awayTeam, kickoffEpochSec).value.orEmpty()
                            .firstOrNull { it.bookmaker.contains("bet365", true) && it.latestComplete() }
                    }.getOrNull()
                    if (row != null) Live(Source.TOTALCORNER, SofaScoreService.BookmakerOdds("Bet365", row.latestMs1!!, row.latestMsX!!, row.latestMs2!!), "TotalCorner Bet365 1X2")
                    else Live(Source.TOTALCORNER, null, "Bet365 satırı bulunamadı")
                }
            }

            val flashDeferred = async(Dispatchers.IO) {
                val row = runCatching { flashscore.fetchBookmakerOdds(homeTeam, awayTeam).firstOrNull { valid(it.ms1, it.msX, it.ms2) } }.getOrNull()
                if (row != null) Live(Source.FLASHSCORE, SofaScoreService.BookmakerOdds("Bet365", row.ms1, row.msX, row.ms2), "Flashscore Bet365 1X2")
                else Live(Source.FLASHSCORE, null, "Bet365 1X2 satırı yok")
            }

            val sofaDeferred = async(Dispatchers.IO) {
                val row = runCatching { sofa.fetchBet365FromSofaScoreOnly(homeTeam, awayTeam) }.getOrNull()
                if (row != null && valid(row.ms1, row.msX, row.ms2)) Live(Source.SOFA, row, "SofaScore Bet365 provider 1X2")
                else Live(Source.SOFA, null, "Bet365 provider veya tam 1X2 bulunamadı")
            }

            val aiDeferred = async(Dispatchers.IO) {
                val row = runCatching { aiScore.fetch(homeTeam, awayTeam, displayDate) }.getOrNull()
                if (row != null && valid(row.ms1, row.msX, row.ms2)) Live(Source.AISCORE, SofaScoreService.BookmakerOdds("Bet365", row.ms1, row.msX, row.ms2), "AiScore explicit Bet365 1X2")
                else Live(Source.AISCORE, null, "Kimlik/tarih/Bet365 1X2 doğrulaması başarısız")
            }

            val lives = awaitAll(apiDeferred, tipsterDeferred, totalCornerDeferred, flashDeferred, sofaDeferred, aiDeferred)
                .filterIsInstance<Live>()
            val priority = listOf(Source.API, Source.TIPSTERAREA, Source.TOTALCORNER, Source.FLASHSCORE, Source.SOFA, Source.AISCORE)
            val attempts = lives.sortedBy { priority.indexOf(it.source) }.map { Attempt(it.source, it.odds != null, it.reason) }.toMutableList()
            val winner = priority.asSequence().mapNotNull { source -> lives.firstOrNull { it.source == source && it.odds != null } }.firstOrNull()

            if (winner?.odds != null) {
                winner.history?.let { providerHistory.save(it) }
                historyStore.record(homeTeam, awayTeam, kickoffEpochSec, winner.odds.ms1, winner.odds.msX, winner.odds.ms2)
                return@coroutineScope Result(winner.odds, winner.source, attempts, winner.history)
            }

            if (cache?.hasLatest() == true && cacheFresh && valid(cache.latestHome, cache.latestDraw, cache.latestAway)) {
                attempts += Attempt(Source.CACHE, true, "Son doğrulanmış Bet365 gözlemi")
                return@coroutineScope Result(
                    SofaScoreService.BookmakerOdds("Bet365", cache.latestHome!!, cache.latestDraw!!, cache.latestAway!!),
                    Source.CACHE,
                    attempts,
                    null
                )
            }
            attempts += Attempt(Source.CACHE, false, if (cache?.hasLatest() == true) "Yerel kayıt eski veya 1X2 eksik" else "Kullanılabilir yerel Bet365 kaydı yok")
            Result(null, Source.NONE, attempts, lives.firstOrNull { it.history != null }?.history)
        }
    }

    private fun valid(a: String?, x: String?, b: String?): Boolean =
        a?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true &&
            x?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true &&
            b?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true

    private fun short(value: String?): String = value?.replace(Regex("\\s+"), " ")?.trim()?.take(100).orEmpty().ifBlank { "bilinmeyen hata" }

    companion object {
        private const val TAG = "CioBet365MotorV2"
        private const val MAX_CACHE_AGE_MS = 12 * 60 * 60 * 1000L
    }
}
