# CioScore v0.25.76 — Bet365 TipsterArea source

- TipsterArea now parses the explicit `Bet365` bookmaker row from its Standard 1X2 table.
- Bet365 Motor v2 adds `TIPSTERAREA` as an independent real-Bet365 source.
- Only a row explicitly identified as Bet365 with a complete valid 1X2 triple is accepted.
- TipsterArea bwin data remains a separate bwin path; no bookmaker relabeling is performed.
- Bet365 diagnostics now show `TA` / `TipsterArea`.
- Existing API / TotalCorner / Flashscore / SofaScore / AiScore / verified-cache paths remain intact.
- Existing independent odds publishing remains intact: Bet365 and bwin updates merge by bookmaker and do not erase one another.

Build note: Gradle wrapper could not download Gradle 9.5 in the offline build environment, so a local APK build could not be completed here.
