# CioScore v0.15.1

Current architecture:
- 5 CIO prediction sources (CIO1-CIO5)
- MatchMerger with normalized/fuzzy team matching
- Mackolik 1X2 odds enrichment
- SofaScore team last-five match enrichment
- CioScore engine: CIO consensus + margin-cleaned market probability
- Main UI intentionally hides diagnostic source counters and ranking/filter buttons

Football-Data is not part of this version.
