package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** MightyTips Correct Score parser.
 *  Targets the live Correct Score cards where the page exposes:
 *  date/time -> home -> away -> Score: x-y -> author.
 */
class MightyTipsParser : BaseParser("MightyTips") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Do not depend on a particular CSS class: the site changes card classes.
        // Find the smallest useful DOM blocks that contain the literal Score: label.
        val candidates = doc.select("article, li, section, div")
            .filter { el ->
                val t = clean(el.text())
                t.length in 15..900 &&
                    Regex("(?i)\\bScore\\s*:\\s*[0-5]\\s*[-:]\\s*[0-5]\\b").containsMatchIn(t)
            }
            .sortedBy { it.text().length }

        for (card in candidates) {
            val score = Regex("(?i)\\bScore\\s*:\\s*([0-5])\\s*[-:]\\s*([0-5])\\b")
                .find(clean(card.text()))
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
                ?: continue

            val teams = extractTeams(card) ?: continue
            val home = cleanTeam(teams.first)
            val away = cleanTeam(teams.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(home, away, score, source)
            out[model.matchKey] = model
            if (out.size >= 100) break
        }

        return out.values.toList()
    }

    private fun extractTeams(card: Element): Pair<String, String>? {
        // Strongest signal on MightyTips: team logo alt text, e.g. "Rapid Wien logo".
        val alts = card.select("img[alt]")
            .map { cleanTeam(it.attr("alt")) }
            .filter { isTeamLike(it) }
            .map { it.replace(Regex("(?i)\\s+logo$"), "").trim() }
            .filter { isTeamLike(it) }
            .distinct()
        if (alts.size >= 2) return alts[0] to alts[1]

        // Next signal: links/headings containing the two team names.
        val labels = card.select("h1,h2,h3,h4,h5,a,[class*=team],[class*=home],[class*=away]")
            .map { clean(it.text()) }
            .filter { isTeamLike(it) }
            .filterNot { it.equals("Read Prediction", true) }
            .distinct()
        if (labels.size >= 2) {
            // Prefer adjacent labels that occur before the Score label.
            return labels[0] to labels[1]
        }

        // Final fallback: parse the visible "Home — Away Score: x-y" sequence.
        val text = clean(card.text())
        val beforeScore = text.substringBefore(Regex("(?i)\\bScore\\s*:"))
            .replace(Regex("\\b\\d{1,2}\\s*:\\s*\\d{2}\\b"), " ")
            .replace(Regex("\\b\\d{1,2}\\s*[./-]\\s*\\d{1,2}\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val dash = Regex("(?s)^.*?([A-Za-zÀ-ž0-9&.'’()]+(?:\\s+[A-Za-zÀ-ž0-9&.'’()]+){0,7})\\s*[—–]\\s*([A-Za-zÀ-ž0-9&.'’()]+(?:\\s+[A-Za-zÀ-ž0-9&.'’()]+){0,7})\\s*$")
            .find(beforeScore)
        if (dash != null) return dash.groupValues[1] to dash.groupValues[2]

        return null
    }

    private fun isTeamLike(value: String): Boolean {
        val s = cleanTeam(value).replace(Regex("(?i)\\s+logo$"), "").trim()
        if (s.length !in 2..70) return false
        if (Regex("^[0-9 .:/-]+$").matches(s)) return false
        val bad = listOf(
            "MightyTips", "Score", "Read Prediction", "Today", "Tomorrow",
            "All Football Tips", "Correct Score", "Prediction", "Image", "Icon", "Author"
        )
        if (bad.any { s.equals(it, true) }) return false
        if (Regex("(?i)^(paulius kundzelevicius|nemanja lalic|nikola lalic|aleksandar krstic|kate richardson|ryan allan)$").matches(s)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\s+logo$"), "")
        .replace(Regex("(?i)\\b(score|read prediction|prediction|correct score|odds)\\b.*$"), "")
        .replace(Regex("\\b\\d{1,2}\\s*:\\s*\\d{2}\\b"), "")
        .trim(' ', '-', '–', '—', ':', '|')
}
