# CIO Score 0.8.5 — MightyTips parser fix

PredictZ, FP.com and WinDrawWin are kept unchanged.
MightyTips parser is rewritten to target the live Correct Score cards and the literal `Score: x-y` field, using logo alt text / team links / visible Home — Away fallback.

Target: https://www.mightytips.com/football-predictions/correct-score/
