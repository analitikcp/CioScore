package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** SureWinPredict daily correct-score page parser. */
class SureWinPredictParser : BaseParser("SureWinPredict") {

    private val matchPath = Regex("/match/([^/?#]+-vs-[^/?#]+?)(?:-\\d+-\\d+)?/(\\d{4}-\\d{2}-\\d{2})", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href*='/match/']")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val match = matchPath.find(href) ?: continue
            val fixtureSlug = match.groupValues[1]
            val date = match.groupValues[2]
            val pair = splitFixture(fixtureSlug) ?: continue

            // Do not use parent().parent().parent(): that can span multiple
            // fixtures and make a score from another card appear as this one.
            val contextNode = findTightFixtureContext(link) ?: continue
            val context = contextNode.text().replace('\u00A0', ' ')
            val scorePair = extractStandardScore(context) ?: continue
            val predictedScore = "${scorePair.first}-${scorePair.second}"
            val time = timeRegex.find(context)?.value ?: "--:--"

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val sourceId = href.substringAfter("/match/").substringBefore('/').trim()
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = predictedScore,
                source = source,
                sourceMatchId = sourceId,
                matchDate = date,
                matchTime = time
            )
            out["ID|$sourceId"] = model
        }

        return out.values.toList()
    }

    /** Accept a score only when it belongs to the smallest fixture container. */
    private fun findTightFixtureContext(link: Element): Element? {
        var current: Element? = link
        repeat(10) {
            current = current?.parent()
            val node = current ?: return null
            val text = node.text().replace('\u00A0', ' ').trim()
            if (text.length > 700) return@repeat

            val scores = scoreRegex.findAll(text).toList()
            if (scores.size == 1) return node
        }
        return null
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val marker = "-vs-"
        val idx = slug.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(slug.substring(0, idx))
        val away = slugWords(slug.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
