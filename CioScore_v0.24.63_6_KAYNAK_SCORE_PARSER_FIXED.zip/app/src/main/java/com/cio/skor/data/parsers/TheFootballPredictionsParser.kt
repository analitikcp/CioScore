package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * The Football Predictions exact-score list parser.
 *
 * IMPORTANT: never scan a broad ancestor for the score. The site uses nested
 * div/card markup in some responses, and a broad ancestor can contain several
 * fixtures. In that case the first score found may belong to another match.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    private val fixtureHref = Regex("/([^/?#]+-vs-[^/?#]+-prediction[^/?#]*)", RegexOption.IGNORE_CASE)
    private val dateInSlug = Regex("date-(\\d{2}-\\d{2}-\\d{4})", RegexOption.IGNORE_CASE)
    private val gameId = Regex("game-id-([A-Za-z0-9_-]+)", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href]")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            if (!fixtureHref.containsMatchIn(href)) continue
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            val pair = splitFixture(slug) ?: continue

            val contextNode = findTightFixtureContext(link) ?: continue
            val context = contextNode.text().replace('\u00A0', ' ')
            val score = extractStandardScore(context) ?: continue
            val time = timeRegex.find(context)?.value ?: "--:--"
            val date = dateInSlug.find(slug)?.groupValues?.get(1)?.let(::toIsoDate).orEmpty()
            val id = gameId.find(slug)?.groupValues?.get(1).orEmpty()

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = "${score.first}-${score.second}",
                source = source,
                sourceMatchId = id,
                matchDate = date,
                matchTime = time
            )
            val key = if (id.isNotBlank()) "ID|$id" else model.matchKey
            out[key] = model
        }
        return out.values.toList()
    }

    /**
     * Select the smallest useful fixture container. We only accept a container
     * that contains exactly one football score; this prevents a league/card
     * ancestor containing several fixtures from leaking another match's score.
     */
    private fun findTightFixtureContext(link: Element): Element? {
        var current: Element? = link
        repeat(10) {
            current = current?.parent()
            val node = current ?: return null
            val text = node.text().replace('\u00A0', ' ').trim()
            if (text.length > 700) return@repeat

            val scores = scoreRegex.findAll(text).toList()
            if (scores.size == 1) return node
        }
        return null
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val base = slug.replace(Regex("-prediction.*$", RegexOption.IGNORE_CASE), "")
        val marker = "-vs-"
        val idx = base.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(base.substring(0, idx))
        val away = slugWords(base.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun toIsoDate(value: String): String {
        val parts = value.split('-')
        return if (parts.size == 3) "${parts[2]}-${parts[1]}-${parts[0]}" else ""
    }
}
