package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

abstract class BaseParser(protected val source: String) {
    // Shared score extraction. Parsers may still use source-specific DOM logic
    // to locate the correct text, but score normalization lives in one place.
    protected val scoreRegex = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")

    protected fun extractStandardScore(rawText: String): Pair<Int, Int>? {
        val match = scoreRegex.find(rawText) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return home to away
    }

    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    protected fun score(s: String): String? =
        extractStandardScore(s)?.let { (home, away) -> "$home-$away" }

    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }


    protected data class ScheduleMeta(
        val date: String = "",
        val time: String = "--:--",
        val competition: String = ""
    )

    /** Best-effort extraction of schedule metadata from a provider card. */
    protected fun extractScheduleMeta(card: Element, doc: Document? = null): ScheduleMeta {
        val text = clean(card.text())
        val time = Regex("\\b([01]\\d|2[0-3]):[0-5]\\d\\b").find(text)?.value ?: "--:--"
        val date = extractDate(text).ifBlank {
            doc?.let { extractDate(clean(it.select("h1,title").firstOrNull()?.text().orEmpty())) }.orEmpty()
        }
        val competition = extractCompetitionHeading(card, doc)
        return ScheduleMeta(date, time, competition)
    }

    private fun extractDate(text: String): String {
        val patterns = listOf(
            Regex("\\b(\\d{1,2})[./-](\\d{1,2})[./-](\\d{4})\\b") to "dd.MM.yyyy",
            Regex("\\b(\\d{4})-(\\d{1,2})-(\\d{1,2})\\b") to "yyyy-MM-dd",
            Regex("(?i)\\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\s+(\\d{1,2}),?\\s+(\\d{4})\\b") to "MMM d, yyyy"
        )
        for ((regex, pattern) in patterns) {
            val m = regex.find(text) ?: continue
            val value = m.value.replace(Regex("\\s+"), " ").trim()
            runCatching {
                val normalized = when (pattern) {
                    "dd.MM.yyyy" -> value.replace('-', '.').replace('/', '.')
                    else -> value
                }
                val parsed = LocalDate.parse(
                    normalized,
                    DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH)
                )
                return parsed.toString()
            }
        }
        return ""
    }

    private fun isCompetitionCandidate(value: String): Boolean {
        val v = value.lowercase(Locale.ROOT)
        if (v.matches(Regex("(?i)^(today|tomorrow|yesterday|prediction|predictions|results?|football|soccer)$"))) return false
        if (v.contains("correct score") || v.contains("prediction today") || v.contains("prediction tomorrow")) return false
        if (v.matches(Regex(".*\\b(?:\\d{1,2}:\\d{2}|\\d{1,2}[./-]\\d{1,2}[./-]\\d{4})\\b.*"))) return false
        return true
    }

    private fun extractCompetitionHeading(card: Element, doc: Document?): String {
        var node: Element? = card
        repeat(8) {
            val parent = node?.parent() ?: return@repeat
            val headings = parent.select("h1,h2,h3,h4,h5,h6")
            headings.asReversed().forEach { h ->
                val value = clean(h.text())
                if (value.length in 3..120 && isCompetitionCandidate(value)) {
                    return value
                }
            }
            var sibling = parent.previousElementSibling()
            repeat(6) {
                if (sibling == null) return@repeat
                val value = clean(sibling!!.text())
                if (value.length in 3..120 && isCompetitionCandidate(value)) {
                    return value
                }
                sibling = sibling!!.previousElementSibling()
            }
            node = parent
        }
        return ""
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
