# CIO Score 0.8.8 - 5 Kaynak - Match Merge

Bu sürümde 5 kaynaktan gelen skorlar önce tek ham havuzda toplanır, ardından ev/deplasman takım adları normalize edilerek aynı maç tek kayda birleştirilir.

Aktif kaynaklar: FP.com, PredictZ, WinDrawWin, SoccerSeer ve DailySports.

## 0.8.13 Saat / ScoreModel güncellemesi
Başlama saati ScoreModel ve MatchGroup veri modeline taşındı. Kaynak parser'ları saat bilgisini doğrudan doldurur; MatchMerger timestamp'e göre sıralar; SofaScore yalnızca eksik zamanı zenginleştirir; ScoreAdapter saat bilgisini item_score.xml içindeki tvMatchTime alanında gösterir.
