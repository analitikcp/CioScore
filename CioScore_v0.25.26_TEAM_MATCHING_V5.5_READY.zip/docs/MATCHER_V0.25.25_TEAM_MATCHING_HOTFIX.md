# CioScore v0.25.25 — Team-matching hotfix

## Problems addressed

1. The diagnostic panel could select an unrelated official fixture even when both team similarities were zero. V5.3 filters official mismatch candidates to genuine two-sided team candidates; when none exists, it reports `NO_OFFICIAL_CANDIDATE`.
2. The supplied trace identifies verified aliases that were missing from V5.2. These are included in `TeamAliasCanonicalizer` in V5.3.
3. Exact fixtures crossing local midnight could be rejected because the provider and Turkish bulletin recorded adjacent calendar dates. V5.4 allows this only when both team identities are exact, the dates differ by exactly one day, and source timestamps differ by at most 12 hours.
4. If a parser omits competition country, the matcher now attempts to recover country context from its competition name before constructing the record identity.

## Expected behavior for the supplied diagnostic examples

- `Kopenhag – Odense` vs `FC Copenhagen – Odense BK`: canonical team IDs should agree.
- `U. Chile – Everton DV` vs expanded official names: explicit aliases should resolve both sides.
- `Bhayangkara Surabaya United – PSM Makassar`, `Beşiktaş – Başakşehir`, and `Çaykur Rizespor – Trabzonspor`: provider variants should converge to the same canonical identities.
- `Viimsi – Flora II` vs `Viimsi JK – Tallinna FC Flora U21`: the reserve side is normalized only for Flora Tallinn and stays distinct from senior Flora.
- `Kauno Žalgiris` and `Žalgiris Vilnius`: must remain distinct; contextual Lithuanian identity resolves a bare `Žalgiris` to Vilnius only when competition country is available.
- `Coritiba – Grêmio`, `Flamengo – Atlético Mineiro`, and `Juventude – Náutico`: different dates are not automatically merged. The one-day rollover exception needs exact teams and real timestamps within 12 hours; it does not waive true date/time conflicts.
- `Nea Salamina – Paphos` and `AEK Larnaca – Omonia Nicosia`: an unrelated official match such as `FC Fard – Havadar` must never be shown as their best candidate.

## Verification status

Static source checks are performed before packaging. The Android Kotlin build could not be completed in this environment because the Gradle 9.5.0 distribution was not cached and the environment could not resolve `services.gradle.org`; this package must still be compiled by CI/Android Studio before installing it as a verified APK.


## v0.25.26 / V5.5 build identity hotfix
- versionCode: 255
- versionName: 0.25.26
- BUILD_SIGNATURE: CIO-REAL-GENERIC-V5.5
- CANONICAL_PIPELINE_VERSION: v0.25.26-OFFICIAL-ANCHOR-COMPONENT-BRIDGE-V5.5
- Purpose: make the corrected matcher build unmistakably distinguishable from the V5.1 APK observed on the device.
- Matching behavior retained: two-sided team identity is required; unrelated official candidates are not accepted as fallback diagnostics.
