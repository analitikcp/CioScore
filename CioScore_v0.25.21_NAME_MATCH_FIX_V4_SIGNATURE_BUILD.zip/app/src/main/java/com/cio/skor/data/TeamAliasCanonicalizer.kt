package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Source-independent football team identity layer.
 *
 * v0.23.0 deliberately improves RECALL without weakening the fixture gates:
 * - accents / transliteration variants are canonicalized;
 * - four-digit foundation-year tokens are ignored;
 * - generic club-type tokens can occur anywhere in a provider name;
 * - known city/provider-name variants are resolved through explicit aliases;
 * - youth/reserve tiers are tracked so a U21 team cannot silently become a
 *   senior-team match;
 * - token-subset scoring is used only when the extra tokens are harmless
 *   metadata, never as a blanket "contains the same city" rule.
 *
 * The important safety rule is that canonicalization may make a REAL alias
 * stronger, but it must never turn two unrelated clubs into the same identity.
 */
object TeamAliasCanonicalizer {

    private val removableClubTokens = setOf(
        "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    private val youthOrReserveTokens = setOf(
        "u21", "u20", "u19", "u18", "u17", "u16", "ii", "iii", "reserve", "reserves", "b"
    )

    private val lowWeightTokens = setOf("city", "united", "club", "sport")

    private val comparisonEdgeNoise = setOf(
        "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    /**
     * Explicit, high-confidence aliases only. These are deliberately narrow:
     * city names are NOT globally deleted because that would create collisions
     * between unrelated clubs.
     */
    /**
     * İngilizce ülke/takım isimlerini Türkçe standart isimlere dönüştüren sözlük.
     * TeamAliasCanonicalizer içerisinde kullanılır.
     */
    val countryAliases = mapOf(
        // English -> Turkish canonical country names
        "Armenia" to "Ermenistan",
        "Latvia" to "Letonya",
        "Georgia" to "Gürcistan",
        "Northern Ireland" to "Kuzey İrlanda",
        "Hungary" to "Macaristan",
        "Ukraine" to "Ukrayna",
        "Montenegro" to "Karadağ",
        "Cyprus" to "Kıbrıs",
        "Cyprus Republic" to "Kıbrıs",
        "Republic of Cyprus" to "Kıbrıs",
        "Poland" to "Polonya",
        "Bosnia and Herzegovina" to "Bosna Hersek",
        "Turkey" to "Türkiye",
        "Germany" to "Almanya",
        "Spain" to "İspanya",
        "England" to "İngiltere",
        "Italy" to "İtalya",
        "France" to "Fransa",
        "Netherlands" to "Hollanda",
        "Belgium" to "Belçika",
        "Portugal" to "Portekiz",
        "Austria" to "Avusturya",
        "Switzerland" to "İsviçre",
        "Denmark" to "Danimarka",
        "Sweden" to "İsveç",
        "Norway" to "Norveç",
        "Finland" to "Finlandiya",
        "Romania" to "Romanya",
        "Croatia" to "Hırvatistan",
        "Serbia" to "Sırbistan",
        "Greece" to "Yunanistan",
        "Scotland" to "İskoçya",
        "Wales" to "Galler",
        "Ireland" to "İrlanda",
        "Albania" to "Arnavutluk",
        "Slovenia" to "Slovenya",
        "Slovakia" to "Slovakya",
        "Czech Republic" to "Çekya",
        "Czechia" to "Çekya",
        "Bulgaria" to "Bulgaristan",
        "Iceland" to "İzlanda",
        "Moldova" to "Moldova",
        "Kosovo" to "Kosova",
        "North Macedonia" to "Kuzey Makedonya",
        "Macedonia" to "Kuzey Makedonya",
        "Russia" to "Rusya",
        "Belarus" to "Belarus",
        "Lithuania" to "Litvanya",
        "Estonia" to "Estonya",
        "Malta" to "Malta",
        "Luxembourg" to "Lüksemburg",
        "Israel" to "İsrail",
        "Azerbaijan" to "Azerbaycan",
        "Kazakhstan" to "Kazakistan",
        "Armenia" to "Ermenistan",

        // Africa / Americas / Asia / Oceania
        "Algeria" to "Cezayir",
        "Zambia" to "Zambiya",
        "Gambia" to "Gambiya",
        "Somalia" to "Somali",
        "Nigeria" to "Nijerya",
        "Madagascar" to "Madagaskar",
        "Morocco" to "Fas",
        "Cape Verde" to "Yeşil Burun Adaları",
        "Cape Verde Islands" to "Yeşil Burun Adaları",
        "Malawi" to "Malavi",
        "South Sudan" to "Güney Sudan",
        "Rwanda" to "Ruanda",
        "Liberia" to "Liberya",
        "Ethiopia" to "Etiyopya",
        "Tanzania" to "Tanzanya",
        "Niger" to "Nijer",
        "South Africa" to "Güney Afrika",
        "Ghana" to "Gana",
        "Senegal" to "Senegal",
        "Tunisia" to "Tunus",
        "Egypt" to "Mısır",
        "Brazil" to "Brezilya",
        "Argentina" to "Arjantin",
        "Chile" to "Şili",
        "Colombia" to "Kolombiya",
        "Mexico" to "Meksika",
        "Canada" to "Kanada",
        "United States" to "Amerika Birleşik Devletleri",
        "USA" to "Amerika Birleşik Devletleri",
        "South Korea" to "Güney Kore",
        "Korea" to "Güney Kore",
        "Japan" to "Japonya",
        "China" to "Çin",
        "India" to "Hindistan",
        "Australia" to "Avustralya",

        // v0.25.21 V4 diagnostic aliases: explicit, high-confidence
        // English/Turkish national-team names observed in matcher diagnostics.
        "Mozambique" to "Mozambik",
        "Mauritania" to "Moritanya",
        "Faroe Islands" to "Faroe Adaları",
        "Guinea-Bissau" to "Gine Bissau",
        "Guinea Bissau" to "Gine Bissau",

        // Turkish spellings -> themselves/canonical form
        "Türkiye" to "Türkiye",
        "Turkiye" to "Türkiye",
        "Almanya" to "Almanya",
        "İspanya" to "İspanya",
        "Ingiltere" to "İngiltere",
        "İngiltere" to "İngiltere",
        "İtalya" to "İtalya",
        "Fransa" to "Fransa",
        "Hollanda" to "Hollanda",
        "Belçika" to "Belçika",
        "Portekiz" to "Portekiz",
        "Avusturya" to "Avusturya",
        "İsviçre" to "İsviçre",
        "Danimarka" to "Danimarka",
        "İsveç" to "İsveç",
        "Norveç" to "Norveç",
        "Finlandiya" to "Finlandiya",
        "Romanya" to "Romanya",
        "Hırvatistan" to "Hırvatistan",
        "Sırbistan" to "Sırbistan",
        "Yunanistan" to "Yunanistan",
        "İskoçya" to "İskoçya",
        "Galler" to "Galler",
        "İrlanda" to "İrlanda",
        "Çekya" to "Çekya",
        "Kuzey Makedonya" to "Kuzey Makedonya",
        "Kosova" to "Kosova",
        "Rusya" to "Rusya",
        "Litvanya" to "Litvanya",
        "Estonya" to "Estonya",
        "İsrail" to "İsrail",
        "Azerbaycan" to "Azerbaycan",
        "Kazakistan" to "Kazakistan",
        "Cezayir" to "Cezayir",
        "Zambiya" to "Zambiya",
        "Gambiya" to "Gambiya",
        "Somali" to "Somali",
        "Nijerya" to "Nijerya",
        "Madagaskar" to "Madagaskar",
        "Fas" to "Fas",
        "Yeşil Burun Adaları" to "Yeşil Burun Adaları",
        "Malavi" to "Malavi",
        "Güney Sudan" to "Güney Sudan",
        "Ruanda" to "Ruanda",
        "Liberya" to "Liberya",
        "Etiyopya" to "Etiyopya",
        "Tanzanya" to "Tanzanya",
        "Nijer" to "Nijer",
        "Güney Afrika" to "Güney Afrika",
        "Gana" to "Gana",
        "Tunus" to "Tunus",
        "Mısır" to "Mısır",
        "Brezilya" to "Brezilya",
        "Arjantin" to "Arjantin",
        "Şili" to "Şili",
        "Kolombiya" to "Kolombiya",
        "Meksika" to "Meksika",
        "Kanada" to "Kanada",
        "Amerika Birleşik Devletleri" to "Amerika Birleşik Devletleri",
        "Güney Kore" to "Güney Kore",
        "Japonya" to "Japonya",
        "Çin" to "Çin",
        "Hindistan" to "Hindistan",
        "Avustralya" to "Avustralya",
        "Kıbrıs" to "Kıbrıs",
        "Kıbrıs Rum Kesimi" to "Kıbrıs",
        "Kibris Rum Kesimi" to "Kıbrıs",
        "Bosna Hersek" to "Bosna Hersek",
        "Kuzey İrlanda" to "Kuzey İrlanda",
        "Ermenistan" to "Ermenistan",
        "Letonya" to "Letonya",
        "Gürcistan" to "Gürcistan",
        "Macaristan" to "Macaristan",
        "Ukrayna" to "Ukrayna",
        "Karadağ" to "Karadağ",
        "Polonya" to "Polonya"
    )


    /**
     * Takım adını alıp eşleşme varsa Türkçe karşılığını, yoksa kendisini döndürür.
     */
    /**
     * Language-independent country identity used by both team and competition
     * matching. Returns a stable ASCII id so English/Turkish labels cannot split
     * the same fixture into different buckets.
     */
    private fun normalizeCountryKey(raw: String): String =
        JavaNormalizer.normalize(
            raw.trim().lowercase(Locale.ROOT)
                .replace("ı", "i")
                .replace("ğ", "g")
                .replace("ü", "u")
                .replace("ş", "s")
                .replace("ö", "o")
                .replace("ç", "c"),
            JavaNormalizer.Form.NFD
        )
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** One country dictionary shared by parsers, competition matching and fixture clustering. */
    private val countryCanonicalLookup: Map<String, String> by lazy {
        countryAliases.entries.associate {
            normalizeCountryKey(it.key) to normalizeCountryKey(it.value)
        }
    }

    fun canonicalCountry(raw: String): String {
        if (raw.isBlank()) return ""
        val value = normalizeCountryKey(raw)
        countryCanonicalLookup[value]?.let { return it }

        // Competition labels can contain the country, e.g.
        // "Germany Bundesliga" / "Almanya Bundesliga". Prefer the longest
        // known country phrase so a shorter country cannot win accidentally.
        return countryCanonicalLookup.entries
            .sortedByDescending { it.key.length }
            .firstOrNull { entry ->
                val key = entry.key
                value == key ||
                    value.startsWith("$key ") ||
                    value.endsWith(" $key") ||
                    value.contains(" $key ")
            }
            ?.value
            .orEmpty()
    }


    /**
     * Single source of truth for competition/league identity.
     * Every parser and the global matcher must use this method instead of
     * maintaining local league alias maps.
     */
    /**
     * Explicit provider-safe competition identities. Do not leave league
     * equivalence to fuzzy team matching: these aliases are deterministic.
     */
    private val competitionCanonicalMap = mapOf(
        // England
        "eng 1" to "england_premier_league",
        "england premier league" to "england_premier_league",
        "england - premier league" to "england_premier_league",
        "english premier league" to "england_premier_league",
        "premier league" to "england_premier_league",
        "epl" to "england_premier_league",

        // Türkiye
        "tr 1" to "turkey_super_lig",
        "turkey 1" to "turkey_super_lig",
        "super lig" to "turkey_super_lig",
        "turkiye super ligi" to "turkey_super_lig",
        "turkey super lig" to "turkey_super_lig",
        "trendyol super lig" to "turkey_super_lig",
        "super league turkey" to "turkey_super_lig",

        // Germany
        "ger 1" to "germany_bundesliga",
        "germany 1" to "germany_bundesliga",
        "bundesliga" to "germany_bundesliga",
        "germany bundesliga" to "germany_bundesliga",
        "german bundesliga" to "germany_bundesliga",

        // Spain
        "esp 1" to "spain_la_liga",
        "spain 1" to "spain_la_liga",
        "la liga" to "spain_la_liga",
        "laliga" to "spain_la_liga",
        "spanish la liga" to "spain_la_liga",
        "spain la liga" to "spain_la_liga",

        // Italy
        "ita 1" to "italy_serie_a",
        "italy 1" to "italy_serie_a",
        "serie a" to "italy_serie_a",
        "italian serie a" to "italy_serie_a",
        "italy serie a" to "italy_serie_a",

        // France
        "fra 1" to "france_ligue_1",
        "ligue 1" to "france_ligue_1",
        "french ligue 1" to "france_ligue_1",
        "france ligue 1" to "france_ligue_1",

        // Netherlands / Portugal
        "ned 1" to "netherlands_eredivisie",
        "eredivisie" to "netherlands_eredivisie",
        "dutch eredivisie" to "netherlands_eredivisie",
        "netherlands eredivisie" to "netherlands_eredivisie",
        "por 1" to "portugal_primeira_liga",
        "primeira liga" to "portugal_primeira_liga",
        "portuguese primeira liga" to "portugal_primeira_liga",
        "portugal primeira liga" to "portugal_primeira_liga",

        // UEFA / FIFA competitions
        "milletler ligi" to "nations_league",
        "uefa nations league" to "nations_league",
        "nations league" to "nations_league",
        "dunya kupasi" to "world_cup",
        "world cup" to "world_cup",
        "dunya kupasi elemeleri" to "world_cup_qualifiers",
        "world cup qualifiers" to "world_cup_qualifiers",
        "avrupa sampiyonasi" to "european_championship",
        "european championship" to "european_championship",
        "avrupa sampiyonasi elemeleri" to "european_championship_qualifiers",
        "european championship qualifiers" to "european_championship_qualifiers",
        "avrupa ligi" to "europa_league",
        "uefa europa league" to "europa_league",
        "europa league" to "europa_league",
        "sampiyonlar ligi" to "champions_league",
        "uefa champions league" to "champions_league",
        "champions league" to "champions_league",
        "konferans ligi" to "conference_league",
        "uefa conference league" to "conference_league",
        "conference league" to "conference_league",

        // Friendlies
        "dostluk maci" to "friendly_international",
        "dostluk maclari" to "friendly_international",
        "international friendly" to "friendly_international",
        "friendly international" to "friendly_international",
        "friendly" to "friendly_international"
    )

    fun canonicalCompetition(raw: String): String {
        if (raw.isBlank()) return ""

        var value = normalizeCountryKey(raw)
            .replace(Regex("^(league|competition|tournament|country)\\s*[:\\-]\\s*"), "")
            .replace(Regex("\\s+correct\\s+score\\s+tips?$"), "")
            .replace(Regex("\\s+tips?$"), "")
            .replace(Regex("^(uefa|fifa)\\s+"), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        // The prefix is stripped above for lookup, so retain both prefixed and
        // unprefixed aliases by checking the normalized value directly.
        return competitionCanonicalMap[value]
            ?: competitionCanonicalMap[normalizeCountryKey(raw)]
            ?: value
    }

    fun normalizeTeamName(teamName: String): String {
        val trimmedName = teamName.trim()
        return countryAliases[trimmedName]
            ?: countryAliases.entries.firstOrNull { it.key.equals(trimmedName, ignoreCase = true) }?.value
            ?: trimmedName
    }

    private val canonicalCache = ConcurrentHashMap<String, String>()
    private val identityCache = ConcurrentHashMap<String, TeamIdentity>()
    private val tierCache = ConcurrentHashMap<String, String>()
    private val similarityCache = ConcurrentHashMap<String, Double>()

    private val aliases = mapOf(
        // AEK
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",

        // v0.25.21 V4 diagnostic aliases. Keep these explicit rather than
        // globally stripping words such as "town", "county" or "harriers",
        // because those tokens can be meaningful club identity.
        "boston utd" to "boston united",
        "boston united" to "boston united",
        "ebbsfleet utd" to "ebbsfleet united",
        "ebbsfleet united" to "ebbsfleet united",
        "halifax" to "halifax town",
        "halifax town" to "halifax town",
        "yeovil" to "yeovil town",
        "yeovil town" to "yeovil town",
        "harrogate" to "harrogate town",
        "harrogate town" to "harrogate town",
        "brackley" to "brackley town",
        "brackley town" to "brackley town",
        "kidderminster" to "kidderminster harriers",
        "kidderminster harriers" to "kidderminster harriers",
        "cardiff metropolitan" to "cardiff metropolitan university",
        "cardiff metropolitan university" to "cardiff metropolitan university",
        "haverfordwest" to "haverfordwest county",
        "haverfordwest county" to "haverfordwest county",
        "deportivo pereira" to "deportivo pereira",
        "cs deportivo pereira" to "deportivo pereira",
        "santa fe" to "santa fe",
        "independiente santa fe" to "santa fe",
        "gine bissau" to "guinea bissau",
        "guinea bissau" to "guinea bissau",

        // LASK
        "lask" to "lask",
        "lask linz" to "lask",

        // Premier League shorthand
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "tottenham" to "tottenham hotspur",
        "spurs" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",

        // High-confidence official-bulletin/provider aliases observed in
        // cross-source fixture feeds. Keep these explicit rather than using
        // broad substring rules: the same city can contain multiple clubs.
        "atl madrid" to "atletico madrid",
        "atletico de madrid" to "atletico madrid",
        "atletico madrid" to "atletico madrid",
        "athletico madrid" to "atletico madrid",
        "fc lausanne sport" to "lausanne sport",
        "lausanne sport" to "lausanne sport",
        "lausanne" to "lausanne sport",
        "fc lausanne" to "lausanne sport",
        "lausanne sports" to "lausanne sport",
        "genclerbirligi" to "genclerbirligi",
        "genclerbirligi sk" to "genclerbirligi",

        // Escaldes provider contraction variants. Some feeds abbreviate
        // Spanish/Catalan "de" as "d", while the official bulletin keeps
        // the full connector. Keep this explicit so the connector is not
        // globally rewritten (which could create unrelated collisions).
        "inter club d escaldes" to "inter club de escaldes",
        "inter d escaldes" to "inter de escaldes",
        "inter club de escaldes" to "inter club de escaldes",
        "inter de escaldes" to "inter de escaldes",
        "estudiante merida" to "estudiantes merida",
        "estudiantes merida" to "estudiantes merida",

        // Official-bulletin alias: provider feeds may include the Spanish connector
        // "de" while the official feed omits it. This is a verified single-club
        // alias and is intentionally explicit; do not generalize by deleting
        // "de" globally because that could collapse unrelated club names.
        "estudiantes de rio cuarto" to "estudiantes rio cuarto",
        "estudiantes rio cuarto" to "estudiantes rio cuarto",

        // Bundesliga provider shorthands. These are explicit because a leading
        // single-letter "B." is otherwise indistinguishable from a reserve-tier
        // token. RB is a provider prefix, not a different Leipzig identity.
        "b leverkusen" to "bayer leverkusen",
        "bayer leverkusen" to "bayer leverkusen",
        "rb leipzig" to "leipzig",
        "r b leipzig" to "leipzig",
        "red bull leipzig" to "leipzig",
        "leverkusen" to "bayer leverkusen",

        // Bayern / Inter provider naming variants. Do not map bare "inter"
        // globally: that can collide with Inter Miami/Inter Turku/etc.
        "bayern munich" to "bayern munchen",
        "bayern munchen" to "bayern munchen",
        "bayern munih" to "bayern munchen",
        "internazionale" to "inter milan",
        "inter milan" to "inter milan",
        "inter milano" to "inter milan",

        // Sporting CP / Lisbon
        "sporting cp" to "sporting clube de portugal",
        "sporting lisbon" to "sporting clube de portugal",
        "sporting lisboa" to "sporting clube de portugal",
        "sporting clube de portugal" to "sporting clube de portugal",
        "sporting portugal" to "sporting clube de portugal",
        "sporting de portugal" to "sporting clube de portugal",

        // Verified diagnostic variants from v0.22.0.
        "dinamo tbilisi" to "dinamo tiflis",
        "dinamo tiflis" to "dinamo tiflis",
        "al riffa" to "al riffa",
        "al rifaa" to "al riffa",
        "al rifa" to "al riffa",

        // Provider variants for Levadia. Tallinna is retained globally;
        // only this explicit club alias collapses it to Levadia.
        "tallinna levadia" to "levadia",
        "levadia tallinna" to "levadia",
        "fci levadia" to "levadia",

        // Common provider abbreviation observed in the diagnostic feed.
        // Kept explicit rather than using broad substring matching.
        "udf" to "udf",
        "udfp" to "udf",
        "khuzestan k" to "khuzestan"
    )

    data class TeamIdentity(
        val canonicalId: String,
        val canonicalName: String,
        val compactName: String
    )

    private fun normalizedTokens(rawName: String): MutableList<String> {
        if (rawName.isBlank()) return mutableListOf()

        var value = rawName.trim().lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (value.isBlank()) return mutableListOf()

        return value.split(' ')
            .filter(String::isNotBlank)
            .map { token ->
                when (token) {
                    "athens", "atina", "athina" -> "athens"
                    // Transliteration variants. Keep this list deliberately small.
                    "tbilisi" -> "tiflis"
                    "rifaa", "rifa" -> "riffa"
                    else -> token
                }
            }
            .toMutableList()
    }

    // A leading single-letter provider abbreviation is NOT a reserve tier when
    // it is a verified senior-club shorthand. The generic "b" tier rule remains
    // active for genuine B/reserve teams elsewhere.
    private val seniorAbbreviationCanonicalNames = setOf("bayer leverkusen")

    private fun tierOf(rawName: String): String =
        tierCache[rawName] ?: run {
            val tokens = normalizedTokens(rawName)
            val canonicalName = canonical(rawName)
            val isVerifiedSeniorAbbreviation =
                tokens.firstOrNull() == "b" && canonicalName in seniorAbbreviationCanonicalNames
            val tier = if (isVerifiedSeniorAbbreviation) {
                ""
            } else {
                tokens.firstOrNull { it in youthOrReserveTokens }.orEmpty()
            }
            tierCache.putIfAbsent(rawName, tier)
            tier
        }

    /** Cached youth/reserve tier used by the fixture matcher. */
    fun tier(rawName: String): String = tierOf(rawName)

    private fun stripFoundationYears(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it.matches(Regex("(?:18|19|20)\\d{2}")) }.toMutableList()

    private fun stripClubTypeTokens(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it in removableClubTokens }.toMutableList()

    fun identity(rawName: String): TeamIdentity =
        identityCache[rawName] ?: run {
            val canonicalName = canonical(rawName)
            val value = TeamIdentity(
                canonicalId = canonicalName.replace(' ', '-'),
                canonicalName = canonicalName,
                compactName = canonicalName.replace(" ", "")
            )
            identityCache.putIfAbsent(rawName, value)
            identityCache[rawName] ?: value
        }

    fun canonical(name: String): String {
        canonicalCache[name]?.let { return it }

        // First resolve the explicit English -> Turkish country/team mapping.
        // This makes English provider names and Turkish İddaa names converge
        // before generic token normalization.
        val countryNormalizedName = normalizeTeamName(name)
        var tokens = normalizedTokens(countryNormalizedName)
        if (tokens.isEmpty()) {
            canonicalCache.putIfAbsent(name, "")
            return ""
        }

        // Foundation years are metadata, not club identity.
        tokens = stripFoundationYears(tokens)

        // Apply explicit aliases BEFORE removing tier/provider tokens. This is
        // required for verified shorthands such as "B. Leverkusen", where the
        // leading single-letter token would otherwise be mistaken for the generic
        // reserve-tier marker and disappear before alias resolution.
        val normalizedName = tokens.joinToString(" ")
        val directAlias = aliases[normalizedName]
        if (directAlias != null) {
            canonicalCache.putIfAbsent(name, directAlias)
            return canonicalCache[name] ?: directAlias
        }

        // Youth/reserve tier is handled separately by similarity(), so it does
        // not poison the core club-name comparison.
        tokens = tokens.filterNot { it in youthOrReserveTokens }.toMutableList()

        // Generic provider/club-type tokens are safe to remove anywhere.
        // Unlike city-prefix pruning, this cannot turn Manchester City into
        // Manchester United or otherwise erase a distinctive club word.
        tokens = stripClubTypeTokens(tokens)

        // Explicit aliases are applied AFTER generic cleanup. This is what turns
        // "Tallinna FC Levadia U21" into the same core as "FCI Levadia U21".
        var value = tokens.joinToString(" ").trim()
        if (value.isBlank()) return ""

        value = aliases[value] ?: value
        canonicalCache.putIfAbsent(name, value)
        return canonicalCache[name] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (tierOf(name1) != tierOf(name2)) return false
        return a == b
    }

    /**
     * High-recall but conservative team similarity.
     * Exact canonical aliases score 1.0. Youth/reserve tiers must agree.
     */
    /**
     * Canonical-only scoring entry point for GlobalFixtureMatcher. The raw names
     * are supplied solely to enforce youth/reserve tier isolation. All string
     * distance work is performed on canonical names.
     */
    fun similarityCanonical(
        canonical1: String,
        canonical2: String,
        rawName1: String = canonical1,
        rawName2: String = canonical2
    ): Double {
        if (canonical1.isBlank() || canonical2.isBlank()) return 0.0
        val tier1 = tierOf(rawName1)
        val tier2 = tierOf(rawName2)
        if (tier1 != tier2) return 0.0
        if (canonical1 == canonical2) return 1.0

        // Matcher hot path: the same team pairs are scored thousands of times
        // while building the identity graph and its diagnostics. Canonical names
        // plus the youth/reserve tier fully determine this result, so cache it.
        val left = canonical1 + "\u0000" + tier1
        val right = canonical2 + "\u0000" + tier2
        val key = if (left <= right) left + "\u0001" + right else right + "\u0001" + left
        similarityCache[key]?.let { return it }
        val result = similarityCanonicalCore(canonical1, canonical2)
        similarityCache.putIfAbsent(key, result)
        return similarityCache[key] ?: result
    }

    private fun similarityCanonicalCore(a: String, b: String): Double {
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        if (ca == cb) return 1.0

        val comparisonA = comparisonName(a)
        val comparisonB = comparisonName(b)
        if (comparisonA.isNotBlank() && comparisonA == comparisonB) return 0.98

        val tokenSubset = tokenSubsetSimilarity(a, b)
        val weighted = weightedTokenSimilarity(a, b)
        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        val raw = ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)
        return maxOf(raw, weighted, tokenSubset).coerceIn(0.0, 1.0)
    }

    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        return similarityCanonical(a, b, name1, name2)
    }

    private fun comparisonName(canonicalName: String): String {
        val tokens = canonicalName.split(' ').filter(String::isNotBlank).toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in comparisonEdgeNoise) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in comparisonEdgeNoise) tokens.removeAt(tokens.lastIndex)
        return tokens.joinToString(" ")
    }

    /**
     * Token-subset scoring is intentionally conservative. A shorter name may
     * match a longer name strongly only when the extra tokens are known harmless
     * metadata (for example a foundation year, already removed by canonical()).
     * Arbitrary club words such as "Welco" are NOT treated as metadata.
     */
    private fun tokenSubsetSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank).toSet()
        val bt = b.split(' ').filter(String::isNotBlank).toSet()
        if (at.isEmpty() || bt.isEmpty()) return 0.0
        if (at == bt) return 1.0

        // After canonicalization, a true subset is only promoted when the larger
        // side differs by no more than one low-information token. This avoids the
        // dangerous "Tartu JK Welco -> Tartu" false-positive pattern.
        val smaller = if (at.size <= bt.size) at else bt
        val larger = if (at.size <= bt.size) bt else at
        if (!larger.containsAll(smaller)) return 0.0

        val extras = larger - smaller
        if (extras.size == 1 && extras.first() in lowWeightTokens) return 0.94
        return 0.0
    }

    private fun weightedTokenSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank)
        val bt = b.split(' ').filter(String::isNotBlank)
        if (at.isEmpty() || bt.isEmpty()) return 0.0

        fun tokenWeight(token: String): Double = if (token in lowWeightTokens) 0.35 else 1.0

        fun bestAverage(from: List<String>, to: List<String>): Double {
            var weightedSum = 0.0
            var totalWeight = 0.0
            for (token in from) {
                val weight = tokenWeight(token)
                val best = to.maxOfOrNull { other ->
                    if (token == other) 1.0 else {
                        val maxLength = maxOf(token.length, other.length)
                        if (maxLength == 0) 1.0 else
                            1.0 - levenshtein(token, other).toDouble() / maxLength
                    }
                } ?: 0.0
                weightedSum += best.coerceIn(0.0, 1.0) * weight
                totalWeight += weight
            }
            return if (totalWeight == 0.0) 0.0 else weightedSum / totalWeight
        }

        return ((bestAverage(at, bt) + bestAverage(bt, at)) / 2.0).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        exact(name1, name2) || similarity(name1, name2) >= 0.80

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
