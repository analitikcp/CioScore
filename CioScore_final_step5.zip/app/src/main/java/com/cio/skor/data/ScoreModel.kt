package com.cio.skor.data

data class ScoreModel(
    val id: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchTime: String = "",
    val prediction: String = "",
    val source: String = "",
    // Oran Alanları
    val oddsMs1: String = "-",
    val oddsMsX: String = "-",
    val oddsMs2: String = "-"
) {
    /** Backward-compatible alias used by existing parsers/UI. */
    val predictedScore: String
        get() = prediction

    /** Backward-compatible constructor used by the existing parsers. */
    constructor(
        homeTeam: String,
        awayTeam: String,
        predictedScore: String,
        source: String
    ) : this(
        id = "${homeTeam}_${awayTeam}".hashCode().toString(),
        homeTeam = homeTeam,
        awayTeam = awayTeam,
        prediction = predictedScore,
        source = source
    )
}
