package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

class FlashscoreParser : BaseParser("Flashscore") {

    override fun parse(doc: Document): List<ScoreModel> = parseOddsHtml(doc.outerHtml())

    fun parseOddsHtml(htmlContent: String): List<ScoreModel> {
        val matches = mutableListOf<ScoreModel>()
        val doc = Jsoup.parse(htmlContent)

        val rows = doc.select(".event__match")

        for (row in rows) {
            val home = row.select(".event__participant--home").text()
            val away = row.select(".event__participant--away").text()

            val odds = row.select(".odds__value")
            val ms1 = odds.getOrNull(0)?.text()?.takeIf { it.isNotBlank() } ?: "-"
            val msX = odds.getOrNull(1)?.text()?.takeIf { it.isNotBlank() } ?: "-"
            val ms2 = odds.getOrNull(2)?.text()?.takeIf { it.isNotBlank() } ?: "-"

            if (home.isNotEmpty() && away.isNotEmpty()) {
                matches.add(
                    ScoreModel(
                        id = "${home}_${away}".hashCode().toString(),
                        homeTeam = home,
                        awayTeam = away,
                        source = "Flashscore",
                        oddsMs1 = ms1,
                        oddsMsX = msX,
                        oddsMs2 = ms2
                    )
                )
            }
        }
        return matches
    }
}
