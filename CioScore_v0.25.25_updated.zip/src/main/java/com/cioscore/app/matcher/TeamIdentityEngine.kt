package com.cioscore.app.matcher

object TeamIdentityEngine {
    private val canonicalMap = map.of(
        "fenerbahce" to "Fenerbahçe",
        "galatasaray" to "Galatasaray",
        "besiktas" to "Beşiktaş",
        "trabzonspor" to "Trabzonspor"
    )

    fun getCanonicalName(name: String): String {
        val normalized = name.lowercase().trim()
        return canonicalMap[normalized] ?: name
    }
}
