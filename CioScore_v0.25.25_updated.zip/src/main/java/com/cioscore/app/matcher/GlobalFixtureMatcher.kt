package com.cioscore.app.matcher

import java.text.Normalizer
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max

data class TeamMatchQuery(
    val homeTeam: String,
    val awayTeam: String,
    val matchDateTime: LocalDateTime? = null
)

data class TargetMatch(
    val id: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchDateTime: LocalDateTime? = null
)

data class MatchResult(
    val targetMatch: TargetMatch,
    val confidenceScore: Double
)

class GlobalFixtureMatcher(
    private val similarityThreshold: Double = 0.78,
    private val maxTimeDifferenceMinutes: Long = 180
) {

    /**
     * Verilen sorgu maçını hedef maç listesi içerisinde en yüksek benzerlik skoruyla eşleştirir.
     */
    fun findBestMatch(query: TeamMatchQuery, candidates: List<TargetMatch>): MatchResult? {
        val normalizedQueryHome = normalizeTeamName(query.homeTeam)
        val normalizedQueryAway = normalizeTeamName(query.awayTeam)

        var bestMatch: TargetMatch? = null
        var highestScore = 0.0

        for (candidate in candidates) {
            // Tarih kontrolü (varsa)
            if (query.matchDateTime != null && candidate.matchDateTime != null) {
                val diffMinutes = Math.abs(ChronoUnit.MINUTES.between(query.matchDateTime, candidate.matchDateTime))
                if (diffMinutes > maxTimeDifferenceMinutes) {
                    continue // Zaman toleransı dışındakileri atla
                }
            }

            val candidateHome = normalizeTeamName(candidate.homeTeam)
            val candidateAway = normalizeTeamName(candidate.awayTeam)

            // Düz Eşleşme Skoru (Home-Home, Away-Away)
            val directHomeScore = calculateSimilarity(normalizedQueryHome, candidateHome)
            val directAwayScore = calculateSimilarity(normalizedQueryAway, candidateAway)
            val directTotalScore = (directHomeScore + directAwayScore) / 2.0

            // Çapraz Eşleşme Skoru (Ters yazılmış ev sahibi / deplasman durumları için)
            val crossHomeScore = calculateSimilarity(normalizedQueryHome, candidateAway)
            val crossAwayScore = calculateSimilarity(normalizedQueryAway, candidateHome)
            val crossTotalScore = ((crossHomeScore + crossAwayScore) / 2.0) * 0.9 // Çapraz eşleşmeye hafif ceza

            val currentBestScore = max(directTotalScore, crossTotalScore)

            if (currentBestScore > highestScore) {
                highestScore = currentBestScore
                bestMatch = candidate
            }
        }

        return if (bestMatch != null && highestScore >= similarityThreshold) {
            MatchResult(bestMatch, highestScore)
        } else {
            null
        }
    }

    /**
     * Takım adlarını temizleme ve standartlaştırma işlemi
     */
    fun normalizeTeamName(name: String): String {
        var clean = name.lowercase()
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        clean = Normalizer.normalize(clean, Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")

        // Ek ifadelerin ve gereksiz kısaltmaların temizlenmesi
        clean = clean.replace(Regex("\\b(fc|cf|fk|sk|sck|u19|u21|reserves|res|b takimi|women|bayanlar)\\b"), "")
            .replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        return clean
    }

    /**
     * Levenshtein Distance temelli benzerlik oranı hesaplayıcı (0.0 - 1.0 arası)
     */
    private fun calculateSimilarity(s1: String, s2: String): Double {
        if (s1 == s2) return 1.0
        if (s1.isEmpty() || s2.isEmpty()) return 0.0

        // İsimlerden biri diğerini tam olarak içeriyorsa yüksek taban skor ver
        if (s1.contains(s2) || s2.contains(s1)) {
            val minLen = Math.min(s1.length, s2.length).toDouble()
            val maxLen = Math.max(s1.length, s2.length).toDouble()
            return max(0.85, minLen / maxLen)
        }

        val distance = levenshteinDistance(s1, s2)
        val maxLength = max(s1.length, s2.length)
        return 1.0 - (distance.toDouble() / maxLength.toDouble())
    }

    private fun levenshteinDistance(lhs: CharSequence, rhs: CharSequence): Int {
        val lhsLen = lhs.length
        val rhsLen = rhs.length
        var cost = IntArray(lhsLen + 1) { it }
        var newCost = IntArray(lhsLen + 1) { 0 }

        for (j in 1..rhsLen) {
            newCost[0] = j
            for (i in 1..lhsLen) {
                val match = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                val costReplace = cost[i - 1] + match
                val costInsert = cost[i] + 1
                val costDelete = newCost[i - 1] + 1
                newCost[i] = minOf(costInsert, costDelete, costReplace)
            }
            val swap = cost
            cost = newCost
            newCost = swap
        }
        return cost[lhsLen]
    }
}
