package com.cio.skor

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.SofaScoreService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LastMatchesActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_last_matches)

        val teamName = intent.getStringExtra(EXTRA_TEAM_NAME).orEmpty().ifBlank { "Takım" }
        val teamId = intent.getLongExtra(EXTRA_TEAM_ID, -1L)
        val title = findViewById<TextView>(R.id.tvTeamName)
        val status = findViewById<TextView>(R.id.tvHistoryStatus)
        val recycler = findViewById<RecyclerView>(R.id.rvLastMatches)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }

        title.text = teamName
        recycler.layoutManager = LinearLayoutManager(this)
        status.text = "Son 5 maç yükleniyor…"

        scope.launch {
            val matches = withContext(Dispatchers.IO) {
                runCatching { SofaScoreService().getLastFiveByTeamId(teamId) }.getOrDefault(emptyList())
            }

            if (isFinishing || isDestroyed) return@launch

            recycler.adapter = LastMatchesAdapter(matches)
            status.text = if (matches.isEmpty()) {
                "Son 5 maç verisi alınamadı."
            } else {
                "Gerçek maç sonuçları"
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TEAM_NAME = "TEAM_NAME"
        const val EXTRA_TEAM_ID = "TEAM_ID"
    }
}

private class LastMatchesAdapter(
    private val matches: List<SofaScoreService.RecentMatch>
) : RecyclerView.Adapter<LastMatchesAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val opponent: TextView = view.findViewById(R.id.tvMatchOpponent)
        val meta: TextView = view.findViewById(R.id.tvMatchMeta)
        val result: TextView = view.findViewById(R.id.tvResult)
        val score: TextView = view.findViewById(R.id.tvScore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_last_match, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = matches[position]
        holder.opponent.text = match.opponent
        holder.meta.text = buildString {
            if (match.date.isNotBlank()) append(match.date).append(" • ")
            append(if (match.isHome) "EV" else "DEP")
            if (match.league.isNotBlank()) append(" • ").append(match.league)
        }
        holder.score.text = match.score.replace("-", " - ")

        val (letter, color) = when (match.result) {
            "G" -> "G" to Color.rgb(16, 185, 129)
            "B" -> "B" to Color.rgb(100, 116, 139)
            "M" -> "M" to Color.rgb(239, 68, 68)
            else -> "?" to Color.rgb(148, 163, 184)
        }

        holder.result.text = letter
        holder.result.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
    }

    override fun getItemCount(): Int = matches.size
}
