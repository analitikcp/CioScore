# CIO Skor — 9 Kaynak İzole Test

Bu paket yalnızca dokuz bağımsız tahmin kaynağını test eder:

1. MightyTips
2. FootyStats
3. GoalVertex
4. NerdyTips
5. Vitibet
6. HuhSports
7. FootballAnt
8. DailySports
9. Statarea

Uygulama başlığında 9 kaynak gösterir. Tarama sonrasında her kaynağın HTTP kodu ve çıkardığı skor sayısı ayrı ayrı gösterilir.

Bu paket diğer projelerdeki parserları içermez ve bağımsız ağ/HTML test paketi olarak hazırlanmıştır.
