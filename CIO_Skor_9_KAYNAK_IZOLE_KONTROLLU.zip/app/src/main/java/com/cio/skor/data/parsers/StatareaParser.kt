package com.cio.skor.data.parsers

class StatareaParser : SitePredictionParser("Statarea")
