package com.cio.skor.data.parsers

class FootyStatsParser : SitePredictionParser("FootyStats")
