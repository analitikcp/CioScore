package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/** Exactly nine sources. This project is an isolated test harness. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)
    private val http = HttpClient()

    private val sources = listOf(
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/", MightyTipsParser()),
        Source("FootyStats", "https://footystats.org/predictions/correct-score", FootyStatsParser()),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions", GoalVertexParser()),
        Source("NerdyTips", "https://nerdytips.com/correct-score-predictions-today", NerdyTipsParser()),
        Source("Vitibet", "https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal", VitibetParser()),
        Source("HuhSports", "https://www.huhsports.com/predictions", HuhSportsParser()),
        Source("FootballAnt", "https://www.footballant.com/prediction/correct-score-predictions", FootballAntParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        Source("Statarea", "https://www.statarea.com/predictions", StatareaParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = http.get(source.url)
                    val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else emptyList()
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
