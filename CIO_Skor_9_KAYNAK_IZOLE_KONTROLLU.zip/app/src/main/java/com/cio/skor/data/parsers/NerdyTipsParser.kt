package com.cio.skor.data.parsers

class NerdyTipsParser : SitePredictionParser("NerdyTips")
