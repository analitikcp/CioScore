package com.cio.skor.data.parsers

class MightyTipsParser : SitePredictionParser("MightyTips")
