package com.cio.skor.data.parsers

class HuhSportsParser : SitePredictionParser("HuhSports")
