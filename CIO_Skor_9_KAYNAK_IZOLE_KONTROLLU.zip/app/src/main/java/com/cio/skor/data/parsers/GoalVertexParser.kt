package com.cio.skor.data.parsers

class GoalVertexParser : SitePredictionParser("GoalVertex")
