package com.cio.skor.data.parsers

class FootballAntParser : SitePredictionParser("FootballAnt")
