package com.cio.skor.data.parsers

class DailySportsParser : SitePredictionParser("DailySports")
