package com.cio.skor.data.parsers

class VitibetParser : SitePredictionParser("Vitibet")
