package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Vitibet TODAY-only parser (trial).
 *
 * The source URL is the Vitibet home page, whose football section is explicitly
 * labelled with the current date (e.g. "Football tips 20.09.2026").  We do
 * NOT scrape the historical/multi-day quicktips table.  We only consume the
 * match-detail anchors exposed by today's football-tips section.
 *
 * This is intentionally isolated: matcher, aliases, Iddaa gate and UI are not
 * changed by this trial.
 */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val pageDate = extractPageDate(doc)

        // Home page -> today's football tips. Match-detail links carry the
        // complete visible fixture text, e.g.
        // "19:30 SC Paderborn 07 1 : 2 1899 Hoffenheim 2".
        // This avoids traversing hidden date tabs / old quicktips tables.
        for (link in doc.select("a[href*='match-detail']")) {
            parseTodayAnchor(link, pageDate)?.let { out[it.matchKey] = it }
        }

        return out.values.toList()
    }

    private fun parseTodayAnchor(link: Element, pageDate: String): ScoreModel? {
        val text = clean(link.text())
        if (text.isBlank()) return null

        // Only rows with a concrete correct-score prediction are useful to the
        // score pipeline. Live/unknown rows such as "? : ?" are ignored.
        val timeMatch = Regex("(?i)^(\\d{1,2}:\\d{2})\\s+(.+)$").find(text) ?: return null
        val time = timeMatch.groupValues[1]
        val rest = timeMatch.groupValues[2].trim()

        val scoreMatch = Regex("(?<!\\d)(\\d{1,2})\\s*:\\s*(\\d{1,2})(?!\\d)").find(rest)
            ?: return null
        val home = cleanTeam(rest.substring(0, scoreMatch.range.first))
        var away = cleanTeam(rest.substring(scoreMatch.range.last + 1))

        // The homepage appends the 1/X/2 prediction after the away team.
        // Remove only the terminal market token(s), never text from the team.
        away = away
            .replace(Regex("\\s+(?:1X|X2|12|10|02|1|X|2)\\s*$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("(?i)\\s+(?:LIVE|FT)\\s+.*$"), "")
            .trim()

        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null

        val fixtureId = Regex("(?i)[?&]fixture_id=(\\d+)")
            .find(link.attr("href"))?.groupValues?.getOrNull(1).orEmpty()

        val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            sourceMatchId = fixtureId,
            matchDate = pageDate,
            matchTime = time
        )
    }

    private fun extractPageDate(doc: Document): String {
        // Prefer the explicit heading used by Vitibet's home page:
        // "Football tips 20.09.2026" / "Futbol tahminleri 20.09.2026".
        val text = clean(doc.body()?.text().orEmpty())
        val m = Regex("(?i)(?:Football tips|Futbol tahminleri)\\s+(\\d{1,2}\\.\\d{1,2}\\.\\d{4})")
            .find(text)
        return m?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..70) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction|score|1|0|2)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|Odds|Status)\\b.*$"), "")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', ':', '|')
}
