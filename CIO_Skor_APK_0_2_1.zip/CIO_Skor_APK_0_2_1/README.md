# CIO Skor 0.2.1

16 kaynaklı doğru skor tarama prototipi. Uygulama kaynak sayfalarını WebView ile açar, sayfa metnini okur ve görünen skor formatlarını kaynak bazında raporlar. Skor bulunmayan veya erişilemeyen kaynaklar açıkça işaretlenir; skor uydurulmaz.
