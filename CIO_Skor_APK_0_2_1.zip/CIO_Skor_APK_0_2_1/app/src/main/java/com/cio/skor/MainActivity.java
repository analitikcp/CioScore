package com.cio.skor;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private static class Source { String name, url; Source(String n, String u){name=n;url=u;} }
    private final List<Source> sources = new ArrayList<>();
    private LinearLayout results;
    private TextView summary;
    private Button scan;
    private ProgressBar progress;
    private WebView web;
    private Handler handler = new Handler(Looper.getMainLooper());
    private int index = 0;
    private boolean running = false;
    private Runnable timeout;

    private final Pattern scorePattern = Pattern.compile("(?<!\\d)([0-9]{1,2})\\s*[-–:]\\s*([0-9]{1,2})(?!\\d)");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildSources();
        buildUi();
        setupWebView();
    }

    private void buildSources() {
        sources.add(new Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"));
        sources.add(new Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"));
        sources.add(new Source("Forebet", "https://www.forebet.com/en/football-predictions/"));
        sources.add(new Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"));
        sources.add(new Source("WinDrawWin", "https://www.windrawwin.com/football-predictions/correct-score/"));
        sources.add(new Source("BettingTipsToday", "https://www.bettingtipstoday.com/correct-score-predictions/"));
        sources.add(new Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"));
        sources.add(new Source("MightyTips", "https://www.mightytips.com/football-predictions/"));
        sources.add(new Source("FootyStats", "https://footystats.org/predictions"));
        sources.add(new Source("GoalVertex", "https://www.goalvertex.com/football-predictions/"));
        sources.add(new Source("NerdyTips", "https://nerdytips.com/football-predictions"));
        sources.add(new Source("Vitibet", "https://www.vitibet.com/index.php?cl=football-predictions"));
        sources.add(new Source("HuhSports", "https://www.huhsports.com/tr/predictions"));
        sources.add(new Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"));
        sources.add(new Source("DailySports", "https://dailysports.net/stat/"));
        sources.add(new Source("Statarea", "https://www.statarea.com/predictions"));
    }

    private int dp(float n){ return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView tv(String text, float sp, int color){
        TextView t = new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(color); t.setPadding(dp(12),dp(8),dp(12),dp(8)); return t;
    }

    private void buildUi(){
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(8,11,16));
        TextView title = tv("⚽ CIO SKOR", 28, Color.WHITE); title.setTypeface(null, 1); title.setPadding(dp(16),dp(18),dp(16),0);
        TextView sub = tv("16 kaynak • gerçek skor taraması", 18, Color.LTGRAY); sub.setPadding(dp(16),0,dp(16),dp(10));
        scan = new Button(this); scan.setText("🔄  BUGÜNÜ TARA"); scan.setTextSize(18); scan.setOnClickListener(v -> startScan());
        summary = tv("Hazır. Tara butonuna bas.", 14, Color.LTGRAY);
        progress = new ProgressBar(this); progress.setVisibility(View.GONE); progress.setPadding(dp(16),dp(4),dp(16),dp(4));
        ScrollView sv = new ScrollView(this); results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); results.setPadding(dp(10),dp(4),dp(10),dp(20)); sv.addView(results);
        root.addView(title); root.addView(sub); root.addView(scan); root.addView(progress); root.addView(summary); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        web = new WebView(this); LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(1,1); wp.gravity = Gravity.END; root.addView(web, wp);
        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled") private void setupWebView(){
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setLoadsImagesAutomatically(false); s.setBlockNetworkImage(true); s.setUserAgentString("Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 Chrome/151.0.0.0 Mobile Safari/537.36");
        CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView v, String url){
                if(!running) return;
                handler.postDelayed(() -> extract(), 2500);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e){ if(r.isForMainFrame()) finishCurrent("🔴 erişim hatası"); }
        });
    }

    private void startScan(){
        if(running) return; running=true; index=0; results.removeAllViews(); scan.setEnabled(false); progress.setVisibility(View.VISIBLE); summary.setText("Tarama başlıyor…"); scanNext();
    }

    private void scanNext(){
        if(index>=sources.size()){ running=false; scan.setEnabled(true); progress.setVisibility(View.GONE); summary.setText("Tarama tamamlandı • " + sources.size() + " kaynak kontrol edildi"); return; }
        Source src=sources.get(index); addCard(src.name,"🟡 taranıyor…",Color.LTGRAY); summary.setText("Kaynak " + (index+1) + "/" + sources.size() + " • " + src.name); web.stopLoading();
        timeout=()->finishCurrent("🟠 zaman aşımı / sayfa okunamadı"); handler.postDelayed(timeout,14000); web.loadUrl(src.url);
    }

    private void extract(){
        web.evaluateJavascript("(function(){return document.body?document.body.innerText:''})()", value -> {
            if(!running) return;
            if(timeout!=null) handler.removeCallbacks(timeout);
            String text=unquote(value);
            String cleaned=text.replace('\\u00a0',' ').replaceAll("[ \\t]+"," ");
            Matcher m=scorePattern.matcher(cleaned); List<String> scores=new ArrayList<>();
            while(m.find() && scores.size()<18){ String sc=m.group(1)+"-"+m.group(2); if(!scores.contains(sc)) scores.add(sc); }
            if(scores.isEmpty()) finishCurrent("🟠 sayfa açıldı, skor bulunamadı");
            else finishCurrent("🟢 " + scores.size() + " skor bulundu: " + String.join("  •  ", scores));
        });
    }

    private String unquote(String s){
        if(s==null) return ""; String x=s; if(x.startsWith("\"")&&x.endsWith("\"")) x=x.substring(1,x.length()-1); x=x.replace("\\n","\\n").replace("\\\"","\"").replace("\\/","/").replace("\\u003C","<").replace("\\u003E",">"); return x;
    }

    private void addCard(String name,String status,int color){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setBackgroundColor(Color.rgb(25,31,41)); card.setPadding(dp(8),dp(5),dp(8),dp(5));
        TextView a=tv("⚽ "+name,16,Color.WHITE); a.setTypeface(null,1); TextView b=tv(status,13,color); card.addView(a); card.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); results.addView(card,lp);
    }

    private void finishCurrent(String status){
        if(!running) return; if(timeout!=null) handler.removeCallbacks(timeout); if(index < results.getChildCount()){
            View v=results.getChildAt(index); if(v instanceof LinearLayout){ LinearLayout c=(LinearLayout)v; if(c.getChildCount()>1){ TextView t=(TextView)c.getChildAt(1); t.setText(status); t.setTextColor(status.startsWith("🟢")?Color.rgb(90,220,110):Color.LTGRAY); } }
        }
        index++; handler.postDelayed(this::scanNext,350);
    }

    @Override protected void onDestroy(){ running=false; if(timeout!=null)handler.removeCallbacks(timeout); if(web!=null)web.destroy(); super.onDestroy(); }
}
