package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer
import java.util.Locale

/**
 * Source-independent football team identity layer.
 *
 * v0.23.0 deliberately improves RECALL without weakening the fixture gates:
 * - accents / transliteration variants are canonicalized;
 * - four-digit foundation-year tokens are ignored;
 * - generic club-type tokens can occur anywhere in a provider name;
 * - known city/provider-name variants are resolved through explicit aliases;
 * - youth/reserve tiers are tracked so a U21 team cannot silently become a
 *   senior-team match;
 * - token-subset scoring is used only when the extra tokens are harmless
 *   metadata, never as a blanket "contains the same city" rule.
 *
 * The important safety rule is that canonicalization may make a REAL alias
 * stronger, but it must never turn two unrelated clubs into the same identity.
 */
object TeamAliasCanonicalizer {

    private val removableClubTokens = setOf(
        "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    private val youthOrReserveTokens = setOf(
        "u21", "u20", "u19", "u18", "u17", "u16", "ii", "iii", "reserve", "reserves", "b"
    )

    private val lowWeightTokens = setOf("city", "united", "club")

    private val comparisonEdgeNoise = setOf(
        "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio"
    )

    /**
     * Explicit, high-confidence aliases only. These are deliberately narrow:
     * city names are NOT globally deleted because that would create collisions
     * between unrelated clubs.
     */
    private val aliases = mapOf(
        // AEK
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",

        // LASK
        "lask" to "lask",
        "lask linz" to "lask",

        // Premier League shorthand
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "tottenham" to "tottenham hotspur",
        "spurs" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",

        // Sporting CP / Lisbon
        "sporting cp" to "sporting clube de portugal",
        "sporting lisbon" to "sporting clube de portugal",
        "sporting lisboa" to "sporting clube de portugal",
        "sporting clube de portugal" to "sporting clube de portugal",
        "sporting portugal" to "sporting clube de portugal",
        "sporting de portugal" to "sporting clube de portugal",

        // Verified diagnostic variants from v0.22.0.
        "dinamo tbilisi" to "dinamo tiflis",
        "dinamo tiflis" to "dinamo tiflis",
        "al riffa" to "al riffa",
        "al rifaa" to "al riffa",
        "al rifa" to "al riffa",

        // Provider variants for Levadia. Tallinna is retained globally;
        // only this explicit club alias collapses it to Levadia.
        "tallinna levadia" to "levadia",
        "levadia tallinna" to "levadia",
        "fci levadia" to "levadia",

        // Common provider abbreviation observed in the diagnostic feed.
        // Kept explicit rather than using broad substring matching.
        "udf" to "udf",
        "udfp" to "udf",
        "khuzestan k" to "khuzestan"
    )

    data class TeamIdentity(
        val canonicalId: String,
        val canonicalName: String,
        val compactName: String
    )

    private fun normalizedTokens(rawName: String): MutableList<String> {
        if (rawName.isBlank()) return mutableListOf()

        var value = rawName.trim().lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (value.isBlank()) return mutableListOf()

        return value.split(' ')
            .filter(String::isNotBlank)
            .map { token ->
                when (token) {
                    "athens", "atina", "athina" -> "athens"
                    // Transliteration variants. Keep this list deliberately small.
                    "tbilisi" -> "tiflis"
                    "rifaa", "rifa" -> "riffa"
                    else -> token
                }
            }
            .toMutableList()
    }

    private fun tierOf(rawName: String): String {
        val tokens = normalizedTokens(rawName)
        return tokens.firstOrNull { it in youthOrReserveTokens }.orEmpty()
    }

    private fun stripFoundationYears(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it.matches(Regex("(?:18|19|20)\\d{2}")) }.toMutableList()

    private fun stripClubTypeTokens(tokens: MutableList<String>): MutableList<String> =
        tokens.filterNot { it in removableClubTokens }.toMutableList()

    fun identity(rawName: String): TeamIdentity {
        val canonicalName = canonical(rawName)
        return TeamIdentity(
            canonicalId = canonicalName.replace(' ', '-'),
            canonicalName = canonicalName,
            compactName = canonicalName.replace(" ", "")
        )
    }

    fun canonical(name: String): String {
        var tokens = normalizedTokens(name)
        if (tokens.isEmpty()) return ""

        // Foundation years are metadata, not club identity.
        tokens = stripFoundationYears(tokens)

        // Youth/reserve tier is handled separately by similarity(), so it does
        // not poison the core club-name comparison.
        tokens = tokens.filterNot { it in youthOrReserveTokens }.toMutableList()

        // Generic provider/club-type tokens are safe to remove anywhere.
        // Unlike city-prefix pruning, this cannot turn Manchester City into
        // Manchester United or otherwise erase a distinctive club word.
        tokens = stripClubTypeTokens(tokens)

        // Explicit aliases are applied AFTER generic cleanup. This is what turns
        // "Tallinna FC Levadia U21" into the same core as "FCI Levadia U21".
        var value = tokens.joinToString(" ").trim()
        if (value.isBlank()) return ""

        value = aliases[value] ?: value
        return value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (tierOf(name1) != tierOf(name2)) return false
        return a == b
    }

    /**
     * High-recall but conservative team similarity.
     * Exact canonical aliases score 1.0. Youth/reserve tiers must agree.
     */
    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return 0.0
        if (tierOf(name1) != tierOf(name2)) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        if (ca == cb) return 1.0

        val comparisonA = comparisonName(a)
        val comparisonB = comparisonName(b)
        if (comparisonA.isNotBlank() && comparisonA == comparisonB) return 0.98

        val tokenSubset = tokenSubsetSimilarity(a, b)
        val weighted = weightedTokenSimilarity(a, b)
        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        val raw = ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)

        return maxOf(raw, weighted, tokenSubset).coerceIn(0.0, 1.0)
    }

    private fun comparisonName(canonicalName: String): String {
        val tokens = canonicalName.split(' ').filter(String::isNotBlank).toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in comparisonEdgeNoise) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in comparisonEdgeNoise) tokens.removeAt(tokens.lastIndex)
        return tokens.joinToString(" ")
    }

    /**
     * Token-subset scoring is intentionally conservative. A shorter name may
     * match a longer name strongly only when the extra tokens are known harmless
     * metadata (for example a foundation year, already removed by canonical()).
     * Arbitrary club words such as "Welco" are NOT treated as metadata.
     */
    private fun tokenSubsetSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank).toSet()
        val bt = b.split(' ').filter(String::isNotBlank).toSet()
        if (at.isEmpty() || bt.isEmpty()) return 0.0
        if (at == bt) return 1.0

        // After canonicalization, a true subset is only promoted when the larger
        // side differs by no more than one low-information token. This avoids the
        // dangerous "Tartu JK Welco -> Tartu" false-positive pattern.
        val smaller = if (at.size <= bt.size) at else bt
        val larger = if (at.size <= bt.size) bt else at
        if (!larger.containsAll(smaller)) return 0.0

        val extras = larger - smaller
        if (extras.size == 1 && extras.first() in lowWeightTokens) return 0.94
        return 0.0
    }

    private fun weightedTokenSimilarity(a: String, b: String): Double {
        val at = a.split(' ').filter(String::isNotBlank)
        val bt = b.split(' ').filter(String::isNotBlank)
        if (at.isEmpty() || bt.isEmpty()) return 0.0

        fun tokenWeight(token: String): Double = if (token in lowWeightTokens) 0.35 else 1.0

        fun bestAverage(from: List<String>, to: List<String>): Double {
            var weightedSum = 0.0
            var totalWeight = 0.0
            for (token in from) {
                val weight = tokenWeight(token)
                val best = to.maxOfOrNull { other ->
                    if (token == other) 1.0 else {
                        val maxLength = maxOf(token.length, other.length)
                        if (maxLength == 0) 1.0 else
                            1.0 - levenshtein(token, other).toDouble() / maxLength
                    }
                } ?: 0.0
                weightedSum += best.coerceIn(0.0, 1.0) * weight
                totalWeight += weight
            }
            return if (totalWeight == 0.0) 0.0 else weightedSum / totalWeight
        }

        return ((bestAverage(at, bt) + bestAverage(bt, at)) / 2.0).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        exact(name1, name2) || similarity(name1, name2) >= 0.80

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
