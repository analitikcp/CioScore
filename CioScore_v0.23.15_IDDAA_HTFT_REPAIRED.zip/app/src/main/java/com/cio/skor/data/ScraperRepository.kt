package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger
import org.jsoup.Jsoup

/** Five score-prediction sources; official iddaa.com is merged as source 6 by MainActivity. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)
    data class SourceDiagnostic(val sourceName: String, val count: Int, val isSuccess: Boolean, val errorMessage: String? = null, val httpCode: Int = -1)
    data class ScraperScanReport(val diagnostics: List<SourceDiagnostic>, val totalRawMatches: Int)

    @Volatile var lastScanReport: ScraperScanReport = ScraperScanReport(emptyList(), 0)
        private set

    private val http = HttpClient()
    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = fetchAllWithReport(onProgress).first

    suspend fun fetchAllWithReport(onProgress: (Int, String) -> Unit = { _, _ -> }): Pair<List<SourceResult>, ScraperScanReport> = coroutineScope {
        val completed = AtomicInteger(0)
        val results = sources.map { source ->
            async(Dispatchers.IO) {
                val result = fetchSource(source)
                onProgress(completed.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()
        val report = ScraperScanReport(
            diagnostics = results.map { r -> SourceDiagnostic(r.source, r.scores.size, r.error == null && r.scores.isNotEmpty(), r.error, r.httpCode) },
            totalRawMatches = results.sumOf { it.scores.size }
        )
        lastScanReport = report
        results to report
    }

    private suspend fun fetchSource(source: Source): SourceResult {
        return try {
            val referer = when (source.name) {
                "DailySports" -> "https://dailysports.net/"
                "PredictZ" -> "https://www.predictz.com/"
                "WinDrawWin" -> "https://www.windrawwin.com/"
                "SoccerSeer" -> "https://soccerseer.com/"
                else -> "https://footballpredictions.com/"
            }
            // Keep the previously working request as primary. If it fails, use the
            // resilient retrying client. This change must never turn a network-path
            // difference into a total zero-data scan.
            var (code, html) = withTimeout(20_000L) { withContext(Dispatchers.IO) { http.getFast(source.url, referer) } }
            if (code !in 200..299 || html.isNullOrBlank()) {
                val fallback = withTimeout(45_000L) { withContext(Dispatchers.IO) { http.get(source.url, referer) } }
                code = fallback.first
                html = fallback.second
            }
            if (code !in 200..299 || html.isNullOrBlank()) return SourceResult(source.name, code, emptyList(), "HTTP_$code")
            try {
                val parsed = source.parser.parse(Jsoup.parse(html, source.url))
                if (parsed.isEmpty()) SourceResult(source.name, code, emptyList(), "ZERO_MATCHES_AFTER_PARSE")
                else SourceResult(source.name, code, parsed, null)
            } catch (e: Exception) {
                SourceResult(source.name, code, emptyList(), "PARSE_${e.javaClass.simpleName}:${e.message ?: "error"}")
            }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { SourceResult(source.name, -1, emptyList(), "NETWORK_${e.javaClass.simpleName}:${e.message ?: "error"}") }
    }
}
