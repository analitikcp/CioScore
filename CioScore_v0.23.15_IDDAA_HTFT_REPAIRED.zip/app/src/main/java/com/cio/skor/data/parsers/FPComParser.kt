package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.MatchMerger
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** FP.com Correct Score parser. */
class FPComParser : BaseParser("FP.com") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (row in doc.select("table tr")) {
            val cells = row.select("th, td")
            if (cells.size < 2) continue

            val score = extractScore(cells[1]) ?: continue
            val teams = extractTeams(cells[0]) ?: continue

            val home = cleanTeamName(teams.first)
            val away = cleanTeamName(teams.second)
            if (!isRealTeam(home) || !isRealTeam(away)) continue

            val model = ScoreModel(home, away, score, source)
            out[model.matchKey] = model
        }
        if (out.isEmpty()) {
            genericScoreElements(doc).forEach { el ->
                val found = scoreAt(el.text()) ?: return@forEach
                val pair = genericTeams(el, el.text(), found.first) ?: return@forEach
                val h = team(pair.first); val a = team(pair.second)
                if (!valid(h, a)) return@forEach
                val model = ScoreModel(h, a, found.second, source)
                out[model.matchKey] = model
            }
        }
        return out.values.toList()
    }

    private fun extractScore(cell: Element): String? {
        val text = cell.text().replace('\u00A0', ' ').trim()
        val m = Regex("^\\s*([0-5])\\s*[-:]\\s*([0-5])\\s*$").matchEntire(text)
            ?: Regex("\\b([0-5])\\s*[-:]\\s*([0-5])\\b").find(text)
            ?: return null
        return "${m.groupValues[1]}-${m.groupValues[2]}"
    }

    private fun extractTeams(cell: Element): Pair<String, String>? {
        // FP.com currently renders the match as one link containing both teams
        // plus date/time. The link URL contains the fixture slug, which is the
        // safest way to split the two team names.
        val link = cell.select("a[href]").firstOrNull()
        if (link != null) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/')
                .substringAfterLast('/')
                .lowercase()

            val pair = splitSlug(slug)
            if (pair != null) return pair

            // Some versions use the visible text with an explicit v/vs separator.
            val visible = stripDate(link.text())
            val visiblePair = splitVisible(visible)
            if (visiblePair != null) return visiblePair
        }

        // Fallback: any explicit home/away elements.
        val home = firstText(cell, ".home-team", ".homeTeam", ".team-home", "[class*=home-team]")
        val away = firstText(cell, ".away-team", ".awayTeam", ".team-away", "[class*=away-team]")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        return splitVisible(stripDate(cell.text()))
    }

    private fun splitSlug(slug: String): Pair<String, String>? {
        val cleaned = slug
            .replace(Regex("-(?:prediction|tips?|correct-score|odds).*$"), "")

        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = cleaned.indexOf(marker)
            if (idx > 0) {
                val home = slugWords(cleaned.substring(0, idx))
                val away = slugWords(cleaned.substring(idx + marker.length))
                if (isRealTeam(home) && isRealTeam(away)) return home to away
            }
        }
        return null
    }

    private fun splitVisible(text: String): Pair<String, String>? {
        val cleaned = text.replace(Regex("\\s+"), " ").trim()
        val m = Regex("(?i)^(.+?)\\s+(?:v|vs|versus)\\s+(.+)$").find(cleaned)
            ?: return null
        val home = m.groupValues[1].trim()
        val away = m.groupValues[2].trim()
        if (isRealTeam(home) && isRealTeam(away)) return home to away
        return null
    }

    private fun stripDate(text: String): String {
        return text
            .replace(Regex("\\b\\d{1,2}/\\d{1,2}/\\d{4}\\b.*$"), "")
            .replace(Regex("\\b\\d{1,2}-\\d{1,2}-\\d{4}\\b.*$"), "")
            .trim()
    }

    private fun slugWords(value: String): String {
        return value.replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(' ')
            .joinToString(" ") { word ->
                if (word.isBlank()) word else word.replaceFirstChar { it.uppercase() }
            }
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.select(selector).firstOrNull()?.text()?.let(::cleanTeamName)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun cleanTeamName(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .replace(Regex("(?i)\\b(correct\\s*score|odds|probability|prediction|tip)\\b.*$"), "")
        .trim(' ', '-', '–', '—', ':', '|')

    private fun isRealTeam(value: String): Boolean {
        val v = cleanTeamName(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:/-]+$"))) return false
        if (v.contains(Regex("(?i)correct\\s*score|probability|odds|prediction|betting tips|read more"))) return false
        return true
    }
}
