CioScore v0.9.14

- Source pool: 21 configured sources.
- Added experimental exact-score candidates: BetClan, Statarea, BettingClosed, FreeSuperTips, SoccerPunter, Betshoot, OLBG, Soccervital.
- Experimental candidate parser is conservative: no exact score in a valid fixture DOM scope => no score emitted.
- Matcher pipeline: v0.25.51-COMPOSITE-METADATA-ALIAS-V6.2.
- Official-anchor metadata recovery now accepts proven two-sided canonical identity when provider kickoff/competition metadata is missing; explicit date/time contradictions remain protected.
- Controlled metadata recovery accepts exact canonical home+away identity as an alternative to fingerprint >=0.95.
- Added aliases for I.S.P.E / Ispe FC, Hong Linh Ha Tinh, Hoang Anh Gia Lai, Tanjong Pagar United and Albirex Niigata Singapore FC variants observed in the 2026-10-30 scan.
- Version: 0.9.14 / versionCode 298.
