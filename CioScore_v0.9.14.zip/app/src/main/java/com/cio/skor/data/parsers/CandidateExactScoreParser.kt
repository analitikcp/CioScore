package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Conservative experimental parser for newly added public exact-score sources.
 * It intentionally only emits a prediction when a single DOM scope contains
 * both team names and an explicit scoreline. If the site markup does not match,
 * the source is reported as empty rather than fabricating a fixture.
 */
class CandidateExactScoreParser(sourceName: String) : BaseParser(sourceName) {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = mutableListOf<ScoreModel>()
        val scopes = doc.select("tr, li, article, .match, .fixture, .game, .prediction, [class*=match], [class*=fixture], [class*=prediction]")
        for (scope in scopes) {
            val score = extractStandardScore(scope.text()) ?: continue
            val teams = extractTeams(scope) ?: continue
            val meta = extractFixtureMetadata(scope)
            val competition = meta.competitionName.ifBlank { extractNearestCompetition(scope) }
            out += ScoreModel(
                homeTeam = teams.first,
                awayTeam = teams.second,
                predictedScore = "${score.first}-${score.second}",
                source = source,
                sourceMatchId = scope.attr("data-id").ifBlank { scope.attr("id") },
                matchTimestamp = meta.matchTimestamp,
                matchDate = meta.matchDate,
                matchTime = meta.matchTime,
                competitionName = competition,
                competitionCountry = meta.competitionCountry
            )
        }
        return out.distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.predictedScore}|${it.matchDate}|${it.matchTime}" }
    }

    private fun extractTeams(scope: Element): Pair<String, String>? {
        val candidates = scope.select("a, [class*=team], [class*=home], [class*=away], [data-home], [data-away]")
            .map { clean(it.attr("data-home").ifBlank { it.attr("data-away").ifBlank { it.text() } }) }
            .filter { it.length in 2..70 }
            .filterNot { extractStandardScore(it) != null }
            .filterNot { it.matches(Regex("(?i)^(tip|prediction|correct score|odds|1|x|2|home|away)$")) }
            .distinct()
        if (candidates.size >= 2) return candidates[0] to candidates[1]

        val text = clean(scope.text())
        val dash = Regex("^(.{2,60}?)\\s+(?:-|–|—|vs\\.?|v\\.?|\\bvs\\b)\\s+(.{2,60}?)(?:\\s+\\d{1,2}\\s*[-:]\\s*\\d{1,2}|$)", RegexOption.IGNORE_CASE)
            .find(text)
        if (dash != null) {
            val h = team(dash.groupValues[1]); val a = team(dash.groupValues[2])
            if (valid(h, a)) return h to a
        }
        return null
    }
}
