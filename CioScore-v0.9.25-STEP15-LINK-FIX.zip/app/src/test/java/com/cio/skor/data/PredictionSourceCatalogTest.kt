package com.cio.skor.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class PredictionSourceCatalogTest {
    @Test
    fun allDisplayedSourcesHaveStableLabelsAndUrls() {
        val sources = listOf(
            "FP.com", "PredictZ", "WinDrawWin", "DailySports",
            "BallPrediction", "Correct-Score.net", "FootballScorePredictor",
            "AccurateTip"
        )

        sources.forEach { source ->
            assertEquals(source, PredictionSourceCatalog.displayLabel(source))
            val url = PredictionSourceCatalog.url(source)
            assertNotNull(url)
            check(url.startsWith("https://"))
        }
    }

    @Test
    fun sourceUrlLookupIsCaseInsensitive() {
        assertEquals(
            PredictionSourceCatalog.url("FP.com"),
            PredictionSourceCatalog.url("fp.COM")
        )
    }
}
