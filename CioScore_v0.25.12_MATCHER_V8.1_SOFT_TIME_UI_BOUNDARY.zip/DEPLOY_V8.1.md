# V8.1 deployment note

This package contains the actual repository-root source tree. The important V8.1 change is that `MainActivity` now passes `IddaaMarketService.Result.allParsedMatches` (the complete merged official fixture universe) into `GlobalFixtureMatcher.merge()`. The 06:00-06:00 bulletin boundary is used only to set `MatchGroup.isIddaaBulletinMatch` for the UI filter.

`IddaaMarketService.allParsedMatches` is merged/deduplicated before it reaches the matcher.

The diagnostic matrix also classifies MATCHED from accepted matcher evidence/confidence rather than from the 06:00 bulletin flag.

After extracting this ZIP, its contents must replace the repository root files; uploading the ZIP itself as a GitHub file does not replace the Kotlin source tree.
