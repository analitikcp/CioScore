package com.cio.skor.data

import java.util.UUID

data class DropReason(
    val stage: PipelineStage,
    val reasonCode: String,
    val count: Int,
    val details: List<String> = emptyList()
)

enum class PipelineStage {
    HTTP, PARSER, NORMALIZATION, IDENTITY, CONFIDENCE, MERGE, IDDAA_ENRICHMENT, UI
}

data class ParserHealthReport(
    val sourceName: String,
    val httpCode: Int,
    val rawHtmlBytes: Int,
    val parsedCount: Int,
    val durationMs: Long,
    val status: ParserStatus,
    val errorMessage: String? = null
)

enum class ParserStatus { HEALTHY, DEGRADED, FAILED, DOM_CHANGED }

data class UnmatchedDiagnosticItem(
    val predictionHome: String,
    val predictionAway: String,
    val bestOfficialHome: String?,
    val bestOfficialAway: String?,
    val homeSimilarity: Double,
    val awaySimilarity: Double,
    val homeCanonicalPrediction: String = "",
    val homeCanonicalOfficial: String = "",
    val awayCanonicalPrediction: String = "",
    val awayCanonicalOfficial: String = "",
    val combinedSimilarity: Double = 0.0,
    val dateDifferenceDays: Int = 0,
    val probableReason: UnmatchedReason
)

enum class UnmatchedReason {
    ALIAS_STEMMING_PROBLEM,
    DATE_WINDOW_MISMATCH,
    LOW_NAME_SIMILARITY,
    NO_OFFICIAL_CANDIDATE
}

data class OfficialFeedDiagnostics(
    val httpEvents: Int,
    val httpMarketConfig: Int,
    val rawEventCount: Int,
    val parsedEventCount: Int,
    val timestampedEventCount: Int,
    val bulletinEventCountBeforeMerge: Int,
    val mergedFixtureCount: Int,
    val bulletinDate: String = "",
    val bulletinWindow: String = "",
    val matchingCandidateWindow: String = "",
    val matchingCandidateFixtureCount: Int = 0,
    val marketMatches: Int,
    val error: String? = null,
    val dateDistribution: List<String> = emptyList(),
    val sampleFixtures: List<String> = emptyList()
)


data class MatchMatrixRow(
    val predictionHome: String,
    val predictionAway: String,
    val status: String,
    val bestOfficialHome: String? = null,
    val bestOfficialAway: String? = null,
    val bestTeamScore: Double = 0.0,
    val bestConfidence: Double = 0.0,
    val bestTimeScore: Double = 0.0,
    val bestCountryScore: Double = 0.0,
    val bestCompetitionScore: Double = 0.0,
    val acceptedCandidate: Boolean = false,
    val reason: String = ""
)

data class ScanTrace(
    val scanId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val timestamp: Long = System.currentTimeMillis(),
    val parserReports: List<ParserHealthReport>,
    val stageMetrics: Map<PipelineStage, Int>,
    val dropReasons: List<DropReason>,
    val totalDurationMs: Long,
    val unmatchedOfficialDiagnostics: List<UnmatchedDiagnosticItem> = emptyList(),
    val officialFeedDiagnostics: OfficialFeedDiagnostics? = null,
    val predictionFixtureCount: Int = 0,
    val officialMatchedPredictionCount: Int = 0,
    val officialOnlyFixtureCount: Int = 0,
    val predictionNotInIddaaCount: Int = 0,
    val predictionNotInIddaaDetails: List<String> = emptyList(),
    val predictionNotInIddaaBySource: Map<String, Int> = emptyMap(),
    val predictionOutsideBulletinCount: Int = 0,
    val predictionOutsideBulletinBySource: Map<String, Int> = emptyMap(),
    val predictionOutsideBulletinDetails: List<String> = emptyList(),
    val highConfidenceConsensusFixtureCount: Int = 0,
    val matchMatrixPredictionCount: Int = 0,
    val matchMatrixOfficialCount: Int = 0,
    val matchMatrixCombinationCount: Int = 0,
    val matchMatrixMatchedCount: Int = 0,
    val matchMatrixReviewCount: Int = 0,
    val matchMatrixNoCandidateCount: Int = 0,
    val matchMatrixLowConfidenceCount: Int = 0,
    val matchMatrixTimeLe2hCount: Int = 0,
    val matchMatrixTime2to6hCount: Int = 0,
    val matchMatrixTime6to12hCount: Int = 0,
    val matchMatrixTime12to24hCount: Int = 0,
    val matchMatrixOvernightRolloverCount: Int = 0,
    val matchMatrixTimeOver24hCount: Int = 0,
    val matchMatrixRows: List<MatchMatrixRow> = emptyList()
)
