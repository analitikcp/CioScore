# CioScore Matcher V8 — Soft Candidate Window + Time Evidence

- 06:00→06:00 is no longer a matcher candidate gate.
- UI/reporting keeps the official 06:00 bulletin boundary.
- Matcher candidate window is prediction-relative: `prediction - 12h` → `prediction + 48h`.
- Time evidence: ≤2h=1.00, 2–6h=0.85, 6–12h=0.70, 12–24h=0.40, >24h=0.00.
- A calendar-day rollover is not penalized separately; absolute timestamp distance is authoritative.
- For gaps >12h, MATCH requires bidirectional team identity ≥0.90 and meaningful country/league support.
- Home/away directional flips remain hard rejects.
- Final confidence weights: Home 40%, Away 40%, Time 10%, Context 10%.
- Diagnostic matrix counts only prediction-relative soft-window pairs and reports time buckets plus overnight rollovers.
