package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser.
 *
 * Forebet exposes each fixture as a .rcnt match block. The home/away names
 * live in .homeTeam / .awayTeam and the correct-score value is exposed in
 * .ex_sc.tabonly. We deliberately do not scan the whole page for arbitrary
 * score-looking numbers because the same block also contains probabilities,
 * odds and (for finished/live games) the actual final score.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val blocks = doc.select("div.rcnt")
            .ifEmpty { doc.select("div.rcnt[class*=tr_]") }

        for (block in blocks) {
            val home = firstTeam(block, ".homeTeam") ?: continue
            val away = firstTeam(block, ".awayTeam") ?: continue

            val cleanHome = cleanForebetTeam(home)
            val cleanAway = cleanForebetTeam(away)
            if (!valid(cleanHome, cleanAway)) continue

            // Correct score is the primary target.
            val predictedScore = extractCorrectScore(block)
                ?: extractPredictedScore(block)
                ?: continue

            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        return out.values.toList()
    }

    private fun firstTeam(block: Element, selector: String): String? {
        val element = block.select(selector).firstOrNull() ?: return null

        // Prefer the visible team span. If the current DOM wraps it differently,
        // the complete element text is still a safe fallback because this is
        // scoped to the team element only.
        val value = element.select("span").firstOrNull()?.text()
            ?.takeIf { it.isNotBlank() }
            ?: element.text()

        return value.replace('\u00A0', ' ').trim().takeIf { it.isNotBlank() }
    }

    private fun extractCorrectScore(block: Element): String? {
        // Current Forebet markup uses div.ex_sc.tabonly for the Correct score.
        val elements = block.select(
            "div.ex_sc.tabonly, div.ex_sc, [class*=ex_sc]"
        )

        for (element in elements) {
            val score = exactScore(element.text())
            if (score != null) return score
        }

        return null
    }

    private fun extractPredictedScore(block: Element): String? {
        // Fallback only: span.forepr is the Pred column. It is not preferred
        // when a Correct score element is available.
        val elements = block.select("span.forepr")
        for (element in elements) {
            val score = exactScore(element.text())
            if (score != null) return score
        }
        return null
    }

    private fun exactScore(value: String): String? {
        val text = value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

        val match = Regex("^([0-5])\\s*[-:]\\s*([0-5])$").matchEntire(text)
            ?: return null

        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun cleanForebetTeam(value: String): String {
        return value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', '|')
    }
}
