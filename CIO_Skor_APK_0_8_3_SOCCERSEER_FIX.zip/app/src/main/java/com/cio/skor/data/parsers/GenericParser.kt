package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

class GenericParser(sourceName: String) : BaseParser(sourceName) {
    override fun parse(doc: Document): List<ScoreModel> {
        val out=LinkedHashSet<String>()
        for(el in doc.select("article,li,tr,section,[class*=match],[class*=fixture],[class*=prediction],[class*=game]")){
            val raw=clean(el.text()); if(raw.length !in 10..500)continue
            val s=Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|prediction|pred|tip)[^0-9]{0,90}([0-5])\\s*[-:]\\s*([0-5])").find(raw)?.let{"${it.groupValues[1]}-${it.groupValues[2]}"} ?: continue
            val m=Regex("(?i)(.{2,70})\\s+(?:v|vs|[-–—])\\s+(.{2,70})").find(raw) ?: continue
            val a=team(m.groupValues[1]); val b=team(m.groupValues[2]); if(valid(a,b))out.add("$a|$b|$s")
            if(out.size>=30)break
        }
        return out.map{val p=it.split("|");ScoreModel(p[0],p[1],p[2],source)}
    }
}
