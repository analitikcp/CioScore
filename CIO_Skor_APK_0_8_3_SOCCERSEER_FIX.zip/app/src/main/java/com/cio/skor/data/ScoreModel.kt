package com.cio.skor.data

data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String
) {
    val matchKey: String get() = "${normalize(homeTeam)}|${normalize(awayTeam)}"
    private fun normalize(s: String) = s.lowercase().replace(Regex("[^a-z0-9ğüşöçıİĞÜŞÖÇ]"), "")
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null
)
