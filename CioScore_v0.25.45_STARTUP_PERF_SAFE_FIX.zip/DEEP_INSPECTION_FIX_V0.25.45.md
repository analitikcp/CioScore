# CioScore v0.25.45 — Startup / Scan Performance Safe Fix

## Observed symptom
The app reached `Kaynaklar: 4/4 başarılı` and could remain on `TARANIYOR...` long enough for Android to report that CioScore was not responding.

## Root cause
The v0.25.44 fix correctly moved the heavy post-fetch pipeline off `Dispatchers.Main`, but the remaining reconciliation and diagnostic passes still performed a large number of repeated prediction × official fixture comparisons before the first usable result was returned to the UI. The deep reverse-coverage diagnostics were especially expensive because they repeatedly rebuilt matcher records.

## v0.25.45 safe changes
1. Pre-index official fixtures by canonical HOME/AWAY identity during metadata reconciliation. Exact identity narrows the normal candidate set; if a hard gate rejects the exact candidates, the previous full-roster fallback remains.
2. Reuse prebuilt official metadata models instead of constructing a new model for every candidate pair.
3. Diagnostic mismatch/coverage scans use exact canonical candidate pools first and preserve full-roster fallback when no accepted exact candidate exists.
4. Render the prepared match cards before deep diagnostics and yield to the Android main looper. The UI can therefore display matches and remain responsive while diagnostics finish on a background dispatcher.

## Safety invariants
- No fake scores or odds.
- No fixture synthesis.
- No change to prediction-source eligibility.
- No change to AiScore/Flashscore Bet365 verification.
- No change to Iddaa enrichment rules.
- No change to kickoff/past-match filtering.
- No network-access bypass.
- Exact candidate indexing is a performance prefilter only; rejected exact candidates still use the old full-roster fallback.
