package com.cio.skor.data

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Production-oriented global fixture identity engine.
 *
 * Four identity layers are intentionally separated:
 * 1) TeamAliasCanonicalizer  -> stable source-independent team IDs
 * 2) Official Iddaa anchor   -> strongest fixture authority
 * 3) Union-Find clustering    -> global, non-greedy grouping
 * 4) Evidence/confidence      -> ID + date/time + team similarity validation
 *
 * Important invariant: a fuzzy pair can never create a cluster merely because
 * one side matches. Home AND away must agree. Official fixtures can relax the
 * name threshold only when the official record is the anchor and there is no
 * contradictory time information.
 */
object GlobalFixtureMatcher {

    const val BUILD_SIGNATURE = "CIO-REAL-GENERIC-V5.7"

    const val CANONICAL_PIPELINE_VERSION = "v0.25.35-TEAM-IDENTITY-TIER-SAFE-V5.7"

    // Hard gates: a fuzzy fixture must have credible evidence on BOTH sides.
    // The combined gate prevents two mediocre team similarities from becoming a match.
    private const val TEAM_FUZZY_MIN = 0.72
    private const val MATCH_FUZZY_MIN = 0.78
    private const val AUTO_MERGE_CONFIDENCE = 0.84

    // Kickoff mismatch is a hard rejection. Twelve hours is intentionally wide
    // enough for timezone/date-rollover differences, but still blocks unrelated
    // fixtures from becoming candidates.
    private const val TIME_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 12L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val competitionCountry: String = "",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    ) {
        // Identity is immutable for a record. Compute it once at construction
        // instead of normalizing the same provider name on every pair comparison.
        val homeIdentity: TeamAliasCanonicalizer.TeamIdentity =
            TeamAliasCanonicalizer.identityForProvider(source, competitionCountry, homeTeam)
        val awayIdentity: TeamAliasCanonicalizer.TeamIdentity =
            TeamAliasCanonicalizer.identityForProvider(source, competitionCountry, awayTeam)
        val homeCanonicalId: String get() = homeIdentity.canonicalId
        val awayCanonicalId: String get() = awayIdentity.canonicalId
        val fixtureKey: String get() = "$homeCanonicalId||$awayCanonicalId"
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        /**
         * The exact prediction records that produced [predictions].
         *
         * The UI must consume this identity-graph output instead of regrouping
         * raw predictions by canonical team key, otherwise two fixtures that
         * the matcher deliberately kept separate could be collapsed again.
         */
        val predictionRecords: MutableList<Record> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = "",
        var fixtureKey: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val competitionScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean,
        val homeCanonicalA: String = "",
        val homeCanonicalB: String = "",
        val awayCanonicalA: String = "",
        val awayCanonicalB: String = ""
    )

    private class UnionFind(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)
        private val members = Array(size) { mutableListOf(it) }

        fun find(value: Int): Int {
            var x = value
            while (parent[x] != x) x = parent[x]
            val root = x
            x = value
            while (parent[x] != x) {
                val next = parent[x]
                parent[x] = root
                x = next
            }
            return root
        }

        fun componentMembers(value: Int): List<Int> = members[find(value)]

        fun union(a: Int, b: Int) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) {
                val tmp = ra; ra = rb; rb = tmp
            }
            parent[rb] = ra
            members[ra].addAll(members[rb])
            members[rb].clear()
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    /**
     * Reconcile sparse provider metadata before fixture clustering.
     *
     * Several providers publish a perfectly valid team+prediction card but omit
     * kickoff/league on the individual card. We do not throw those cards away.
     * Instead, we borrow missing metadata only after an independent fixture
     * candidate is confirmed by both teams plus any available date/time/league/
     * country evidence. Official Iddaa is the strongest metadata anchor; when it
     * cannot identify the fixture, a richer prediction from another source may
     * supply the missing fields.
     */
    fun reconcileMetadata(
        predictions: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<ScoreModel> {
        if (predictions.isEmpty()) return predictions

        // PERFORMANCE / SAFE FIX v0.25.45:
        // Build the official candidate models once and index them by the same
        // generic HOME||AWAY identity used by metadata reconciliation. The old
        // implementation rebuilt a ScoreModel for every prediction × official
        // pair on up to three passes. With a large daily bulletin this created
        // tens of thousands of unnecessary canonicalization operations before
        // the UI could render. Exact identity is only a candidate prefilter;
        // when an exact bucket is rejected by a hard metadata gate we still
        // fall back to the full official roster, so matching recall is unchanged.
        val officialModels = officialMatches.map { official ->
            ScoreModel(
                homeTeam = official.homeTeam,
                awayTeam = official.awayTeam,
                predictedScore = "",
                source = "IDDAA",
                sourceMatchId = official.matchId,
                matchTimestamp = official.matchTimestamp,
                matchDate = official.matchDate,
                matchTime = official.matchTime,
                competitionName = official.competitionName,
                competitionCountry = countryFromCompetition(official.competitionName)
            )
        }
        fun genericFixtureKey(home: String, away: String): String =
            "${TeamAliasCanonicalizer.identity(home).canonicalId}||${TeamAliasCanonicalizer.identity(away).canonicalId}"
        val officialByGenericFixture = officialModels.groupBy {
            genericFixtureKey(it.homeTeam, it.awayTeam)
        }

        var current = predictions

        for (pass in 0 until 3) {
            var changed = false
            val richPredictions = current.filter { hasAnyFixtureMetadata(it) }

            current = current.map { prediction ->
                // IMPORTANT: even a provider record with complete metadata must be
                // checked against the official bulletin. Some providers publish a
                // complete but stale kickoff (e.g. 19:45/07:00) for the exact same
                // country fixture that İddaa lists at 22:00. The old early return
                // skipped that correction and the UI then removed the card as past.
                data class MetadataCandidate(val rank: Double, val model: ScoreModel, val official: Boolean)

                // V5.1: explicit controlled recovery for completely sparse
                // provider cards. This is independent of canonical-ID equality
                // and therefore handles Utd/United-style variants without adding
                // aliases. The guard requires a unique official candidate and
                // two-sided fingerprint identity >= 0.95.
                val recovered = controlledOfficialMetadataRecovery(prediction, officialMatches)
                if (recovered != null) {
                    if (recovered != prediction) changed = true
                    return@map recovered
                }

                val exactOfficialModels = officialByGenericFixture[
                    genericFixtureKey(prediction.homeTeam, prediction.awayTeam)
                ].orEmpty()
                val officialPool = if (exactOfficialModels.isNotEmpty()) {
                    exactOfficialModels
                } else {
                    officialModels
                }
                val officialCandidate = officialPool
                    .asSequence()
                    .mapNotNull { candidate ->
                        val rank = metadataCandidateRank(prediction, candidate, official = true)
                        if (rank < 0.0) null else MetadataCandidate(rank, candidate, true)
                    }
                    .sortedByDescending { it.rank }
                    .toList()

                // If the exact identity bucket exists but every candidate is
                // rejected by a hard gate, preserve the previous full-roster
                // fallback behavior. This is intentionally a recall-preserving
                // optimization, not a new matching rule.
                val finalOfficialCandidate = if (officialCandidate.isNotEmpty() || exactOfficialModels.isEmpty()) {
                    officialCandidate
                } else {
                    officialModels
                        .asSequence()
                        .filterNot { candidate -> exactOfficialModels.contains(candidate) }
                        .mapNotNull { candidate ->
                            val rank = metadataCandidateRank(prediction, candidate, official = true)
                            if (rank < 0.0) null else MetadataCandidate(rank, candidate, true)
                        }
                        .sortedByDescending { it.rank }
                        .toList()
                }

                val peerCandidates = richPredictions
                    .asSequence()
                    .filter { it.source != prediction.source }
                    .mapNotNull { candidate ->
                        val rank = metadataCandidateRank(prediction, candidate, official = false)
                        if (rank < 0.0) null else MetadataCandidate(rank, candidate, false)
                    }
                    .sortedByDescending { it.rank }
                    .toList()

                val candidates = (finalOfficialCandidate + peerCandidates).sortedByDescending { it.rank }

                // If the official bulletin contains the exact same HOME+AWAY
                // identity, it is the authoritative schedule even when a provider
                // exposes a stale kickoff. Do not let a richer-but-wrong peer
                // metadata record keep the prediction at the old time and make the
                // fixture disappear behind the past-match filter.
                val predictionHomeId = TeamAliasCanonicalizer.identity(prediction.homeTeam).canonicalId
                val predictionAwayId = TeamAliasCanonicalizer.identity(prediction.awayTeam).canonicalId
                val exactOfficial = finalOfficialCandidate
                    .filter { candidate ->
                        val officialHomeId = TeamAliasCanonicalizer.identity(candidate.model.homeTeam).canonicalId
                        val officialAwayId = TeamAliasCanonicalizer.identity(candidate.model.awayTeam).canonicalId
                        if (predictionHomeId.isBlank() || predictionAwayId.isBlank()) return@filter false
                        if (predictionHomeId != officialHomeId || predictionAwayId != officialAwayId) return@filter false

                        // The official bulletin owns kickoff. A provider may carry
                        // the wrong clock, but it must still refer to the same
                        // calendar fixture. If provider date is absent, the exact
                        // canonical pair is sufficient because the official list
                        // is already restricted to the active bulletin window.
                        val pDate = parseDate(prediction.matchDate)
                        val oDate = parseDate(candidate.model.matchDate)
                        pDate == null || oDate == null || pDate == oDate
                    }
                    .maxByOrNull { it.rank }
                val best = exactOfficial ?: candidates.firstOrNull()
                val second = if (exactOfficial != null) {
                    candidates.firstOrNull { it !== exactOfficial }
                } else {
                    candidates.getOrNull(1)
                }

                // Never borrow metadata from an ambiguous fixture. A clear score
                // margin is required for non-exact candidates. An exact official
                // HOME+AWAY anchor is not ambiguous: Iddaa owns its schedule.
                if (best == null ||
                    (exactOfficial == null && second != null && best.rank - second.rank < 0.08)) {
                    prediction
                } else {
                    // Official Iddaa is authoritative for kickoff/date/competition.
                    // A provider may publish the same fixture two hours earlier/later
                    // because of source timezone conventions. Once both teams, date,
                    // and competition identify the same official fixture, replace the
                    // provider schedule with the official schedule instead of merely
                    // filling blanks. This is the missing piece that caused cards such
                    // as Armenia/Armenia? English vs Ermenistan/Letonya to remain split.
                    val merged = copyReconciledFixtureMetadata(
                        prediction = prediction,
                        anchor = best.model,
                        authoritative = best.official
                    )
                    if (merged != prediction) changed = true
                    merged
                }
            }

            if (!changed) break
        }

        return current
    }

    private fun hasAnyFixtureMetadata(p: ScoreModel): Boolean =
        p.matchTimestamp > 0L || p.matchDate.isNotBlank() ||
            (p.matchTime.isNotBlank() && p.matchTime != "--:--") ||
            p.competitionName.isNotBlank() || p.competitionCountry.isNotBlank()

    private fun hasCompleteFixtureMetadata(p: ScoreModel): Boolean =
        p.matchTimestamp > 0L && p.matchDate.isNotBlank() &&
            p.matchTime.isNotBlank() && p.matchTime != "--:--" &&
            p.competitionName.isNotBlank()

    /**
     * V5.1 controlled metadata recovery:
     * recover a completely metadata-less prediction from one official fixture
     * only when both team identities are fingerprint-strong, the candidate is
     * unique, and no explicit country/competition contradiction exists.
     *
     * This is deliberately stricter than generic fuzzy matching and never
     * guesses a kickoff from a non-official source.
     */
    private fun controlledOfficialMetadataRecovery(
        prediction: ScoreModel,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): ScoreModel? {
        val metadataMissing = prediction.matchDate.isBlank() &&
            (prediction.matchTime.isBlank() || prediction.matchTime == "--:--") &&
            prediction.competitionName.isBlank() &&
            prediction.matchTimestamp <= 0L
        if (!metadataMissing) return null

        data class Candidate(
            val official: IddaaMarketService.OpenedMarketMatch,
            val home: Double,
            val away: Double
        )

        val candidates = officialMatches.mapNotNull { official ->
            val home = TeamAliasCanonicalizer.similarity(prediction.homeTeam, official.homeTeam)
            val away = TeamAliasCanonicalizer.similarity(prediction.awayTeam, official.awayTeam)
            val homeFp = fingerprintIdentityScore(prediction.homeTeam, official.homeTeam)
            val awayFp = fingerprintIdentityScore(prediction.awayTeam, official.awayTeam)
            val contradictory = fingerprintIdentityContradiction(prediction.homeTeam, official.homeTeam) ||
                fingerprintIdentityContradiction(prediction.awayTeam, official.awayTeam)
            val country = countryScore(
                prediction.competitionCountry,
                countryFromCompetition(official.competitionName),
                prediction.competitionName,
                official.competitionName
            )
            if (country < 0.0 || contradictory) return@mapNotNull null
            if (homeFp < 0.95 || awayFp < 0.95) return@mapNotNull null
            if (((homeFp + awayFp) / 2.0) < 0.95) return@mapNotNull null
            Candidate(official, home, away)
        }.sortedByDescending { (it.home + it.away) / 2.0 }

        if (candidates.size != 1) return null
        val only = candidates.first()
        val combined = (only.home + only.away) / 2.0
        if (combined < 0.95) return null

        val official = only.official
        return prediction.copy(
            matchTimestamp = official.matchTimestamp,
            matchDate = official.matchDate,
            matchTime = official.matchTime,
            competitionName = official.competitionName,
            competitionCountry = countryFromCompetition(official.competitionName)
        )
    }

    private fun fingerprintIdentityScore(rawA: String, rawB: String): Double {
        if (rawA.isBlank() || rawB.isBlank()) return 0.0
        val fpA = TeamFingerprintExtractor.createFingerprint(rawA)
        val fpB = TeamFingerprintExtractor.createFingerprint(rawB)
        val score = FingerprintMatcher.calculateSimilarity(fpA, fpB)
        return if (score.isContradiction) score.finalScore else score.finalScore
    }

    private fun fingerprintIdentityContradiction(rawA: String, rawB: String): Boolean {
        if (rawA.isBlank() || rawB.isBlank()) return true
        val fpA = TeamFingerprintExtractor.createFingerprint(rawA)
        val fpB = TeamFingerprintExtractor.createFingerprint(rawB)
        return FingerprintMatcher.calculateSimilarity(fpA, fpB).isContradiction
    }

    private fun metadataCandidateRank(a: ScoreModel, b: ScoreModel, official: Boolean): Double {
        val home = TeamAliasCanonicalizer.similarity(a.homeTeam, b.homeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.awayTeam, b.awayTeam)
        val team = (home + away) / 2.0
        if (home < 0.68 || away < 0.68 || team < 0.76) return -1.0

        // Explicit contradictions are never repaired by a name similarity.
        if (a.matchDate.isNotBlank() && b.matchDate.isNotBlank()) {
            val da = parseDate(a.matchDate); val db = parseDate(b.matchDate)
            if (da != null && db != null && da != db) {
                // Allow only a strict midnight/time-zone rollover for an exact
                // official HOME+AWAY pair; date-only or stale fixtures stay rejected.
                val exactOfficialPair = official &&
                    TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
                    TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
                if (!exactOfficialPair || !isAdjacentDateTimezoneShift(
                        a.matchDate, b.matchDate, a.matchTimestamp, b.matchTimestamp
                    )) return -1.0
            }
        }
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            val exactOfficialTeams = official &&
                TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
                TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
            // Iddaa owns the authoritative kickoff. A prediction provider can
            // expose a stale/incorrect clock (for example 07:00) while the
            // official bulletin says 21:45 for the exact same fixture.
            // Keep the hard rejection for ordinary candidates, but let an
            // exact two-sided official anchor reconcile the provider clock.
            if (delta > TIME_HARD_WINDOW_MS && !exactOfficialTeams) return -1.0
        }
        if (a.competitionName.isNotBlank() && b.competitionName.isNotBlank() &&
            competitionScore(a.competitionName, b.competitionName) < 0.0) return -1.0

        val country = countryScore(a.competitionCountry, b.competitionCountry, a.competitionName, b.competitionName)
        if (country < 0.0) return -1.0

        val dateAgree = if (a.matchDate.isNotBlank() && b.matchDate.isNotBlank()) 1.0 else 0.0
        val timeAgree = if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            when {
                delta <= 15L * 60L * 1000L -> 1.0
                delta <= TIME_SOFT_WINDOW_MS -> 0.70
                else -> 0.25
            }
        } else 0.0
        val competitionAgree = if (a.competitionName.isNotBlank() && b.competitionName.isNotBlank())
            competitionScore(a.competitionName, b.competitionName).coerceAtLeast(0.0) else 0.0
        val countryAgree = country.coerceAtLeast(0.0)
        val richness = listOf(
            b.matchTimestamp > 0L,
            b.matchDate.isNotBlank(),
            b.matchTime.isNotBlank() && b.matchTime != "--:--",
            b.competitionName.isNotBlank(),
            b.competitionCountry.isNotBlank()
        ).count { it } / 5.0

        // Metadata carries more weight than names when it is actually present.
        var rank = 0.56 * team + 0.16 * dateAgree + 0.16 * timeAgree +
            0.08 * competitionAgree + 0.04 * countryAgree + 0.06 * richness
        if (official) rank += 0.08

        // If the provider has no metadata at all, only a strong two-sided
        // identity may borrow an official schedule. The previous 0.84/0.84
        // gate was too strict for DailySports/WinDrawWin, where country/club
        // names can differ materially from the official Turkish bulletin even
        // though both sides still identify the same fixture. Keep the relaxed
        // threshold ONLY for the authoritative Iddaa anchor path; peer-provider
        // reconciliation remains strict. The caller also requires a clear best
        // candidate margin, so this cannot simply pick an arbitrary fuzzy fixture.
        val providerMetadataMissing = !hasAnyFixtureMetadata(a)
        if (providerMetadataMissing) {
            if (official) {
                if (home < 0.76 || away < 0.76 || team < 0.82) return -1.0
            } else {
                if (home < 0.84 || away < 0.84 || team < 0.88) return -1.0
            }
        }

        return rank
    }

    private fun copyReconciledFixtureMetadata(
        prediction: ScoreModel,
        anchor: ScoreModel,
        authoritative: Boolean
    ): ScoreModel {
        // Iddaa is authoritative: once the fixture identity is proven, its
        // date/time/competition replace provider-side schedule values. This is
        // intentionally NOT done for peer providers, where we only fill blanks.
        val date = if (authoritative && anchor.matchDate.isNotBlank()) anchor.matchDate
            else prediction.matchDate.ifBlank { anchor.matchDate }
        val time = if (authoritative && anchor.matchTime.isNotBlank() && anchor.matchTime != "--:--") anchor.matchTime
            else if (prediction.matchTime.isBlank() || prediction.matchTime == "--:--") anchor.matchTime
            else prediction.matchTime
        val competition = if (authoritative && anchor.competitionName.isNotBlank()) anchor.competitionName
            else prediction.competitionName.ifBlank { anchor.competitionName }
        val country = if (authoritative && anchor.competitionCountry.isNotBlank()) anchor.competitionCountry
            else prediction.competitionCountry.ifBlank { anchor.competitionCountry.ifBlank { countryFromCompetition(competition) } }
        val timestamp = if (authoritative && anchor.matchTimestamp > 0L) anchor.matchTimestamp
            else if (prediction.matchTimestamp > 0L) prediction.matchTimestamp
            else if (date.isNotBlank() && time.isNotBlank() && time != "--:--") KickoffNormalizer.toEpochMillis(date, time)
            else anchor.matchTimestamp

        if (date == prediction.matchDate && time == prediction.matchTime &&
            competition == prediction.competitionName && country == prediction.competitionCountry &&
            timestamp == prediction.matchTimestamp) return prediction

        return prediction.copy(
            matchTimestamp = timestamp,
            matchDate = date,
            matchTime = time,
            competitionName = competition,
            competitionCountry = country
        )
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)

        // All configured prediction sources: prediction records.
        scraped.forEach { s ->
            records += Record(
                homeTeam = s.homeTeam,
                awayTeam = s.awayTeam,
                predictedScore = s.predictedScore,
                source = s.source,
                sourceMatchId = s.sourceMatchId,
                matchTimestamp = s.matchTimestamp,
                matchDate = s.matchDate,
                matchTime = s.matchTime,
                competitionName = s.competitionName,
                competitionCountry = s.competitionCountry.ifBlank {
                    countryFromCompetition(s.competitionName)
                }
            )
        }

        // Source 6: official Iddaa fixture/market records.
        officialMatches.forEach { o ->
            records += Record(
                homeTeam = o.homeTeam,
                awayTeam = o.awayTeam,
                source = "IDDAA",
                sourceMatchId = o.matchId,
                matchTimestamp = o.matchTimestamp,
                matchDate = o.matchDate,
                matchTime = o.matchTime,
                competitionName = o.competitionName,
                competitionCountry = countryFromCompetition(o.competitionName),
                official = o
            )
        }

        if (records.isEmpty()) return emptyList()

        val uf = UnionFind(records.size)
        // Score/evidence is pure for a record pair. Cache it locally so the
        // component safety gate and later passes never recompute the same
        // canonicalization/Levenshtein work.
        val evidenceCache = HashMap<Long, MatchEvidence>(records.size * 8)
        fun cachedScore(aIndex: Int, bIndex: Int): MatchEvidence {
            val lo = minOf(aIndex, bIndex).toLong()
            val hi = maxOf(aIndex, bIndex).toLong()
            val key = (lo shl 32) xor (hi and 0xffffffffL)
            return evidenceCache[key] ?: score(records[aIndex], records[bIndex]).also { evidenceCache[key] = it }
        }

        // PASS 1 -----------------------------------------------------
        // Official anchor: same official ID is absolute identity inside
        // the official namespace. Never compare IDs from different providers.
        val officialIdIndex = HashMap<String, Int>()
        records.indices.forEach { index ->
            val record = records[index]
            if (record.official != null) {
                val id = record.sourceMatchId.trim()
                if (id.isNotBlank()) {
                    officialIdIndex[id]?.let { uf.union(it, index) } ?: run {
                        officialIdIndex[id] = index
                    }
                }
            }
        }

        // PASS 2 -----------------------------------------------------
        // Canonical fixture key is deterministic and does not depend on the
        // arrival order of sources. This is the main fix for AEK/LASK variants.
        // A component may only grow when EVERY record in the two components is
        // mutually compatible. This prevents transitive false fixtures such as
        // Orlando-Toronto + Miami-Nashville => Toronto-Nashville.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { index ->
            val key = records[index].fixtureKey
            if (key != "||") exactBuckets.getOrPut(key) { mutableListOf() }.add(index)
        }
        exactBuckets.values.forEach { bucket ->
            for (i in 1 until bucket.size) {
                // Exact team names are not enough to merge fixtures from different
                // dates/kickoffs. Reuse the same evidence gate so PASS 2 cannot
                // bypass the hard time/competition filters.
                if (cachedScore(bucket[0], bucket[i]).accepted &&
                    componentsCompatible(uf, bucket[0], bucket[i], ::cachedScore)) {
                    uf.union(bucket[0], bucket[i])
                }
            }
        }

        // PASS 3 -----------------------------------------------------
        // Official anchor matching first.
        val officialByFixtureKey = HashMap<String, MutableList<Int>>()
        val officialIndices = ArrayList<Int>(officialMatches.size)
        records.indices.forEach { index ->
            if (records[index].official != null) {
                officialIndices += index
                officialByFixtureKey.getOrPut(records[index].fixtureKey) { mutableListOf() }.add(index)
            }
        }
        // Official anchor matching first. A prediction source with no time/ID
        // can still attach to the official fixture because the official fixture
        // is today's authoritative roster. Team agreement is always two-sided.
        records.indices.forEach { i ->
            val candidate = records[i]
            if (candidate.official != null) return@forEach

            var bestIndex = -1
            var bestScore = -1.0
            var secondBestScore = -1.0

            // Most provider records already canonicalize to the exact official
            // HOME/AWAY identity. Search that tiny bucket first; only fall back
            // to the full official roster when canonical identity is unavailable
            // or the exact bucket is rejected by a hard time/competition gate.
            val exactCandidates = officialByFixtureKey[candidate.fixtureKey].orEmpty()
            for (j in exactCandidates) {
                val evidence = cachedScore(i, j)
                if (evidence.accepted && evidence.confidence > bestScore) {
                    secondBestScore = bestScore
                    bestScore = evidence.confidence
                    bestIndex = j
                } else if (evidence.accepted && evidence.confidence > secondBestScore) {
                    secondBestScore = evidence.confidence
                }
            }

            // Preserve the old fallback behavior when an exact canonical pair
            // exists but every exact candidate is rejected by a hard evidence
            // gate. This keeps recall behavior unchanged while making the normal
            // path O(number of exact official duplicates) instead of O(all official).
            if (bestIndex < 0) {
                for (j in officialIndices) {
                    if (exactCandidates.contains(j)) continue
                    val evidence = cachedScore(i, j)
                    if (evidence.accepted && evidence.confidence > bestScore) {
                        secondBestScore = bestScore
                        bestScore = evidence.confidence
                        bestIndex = j
                    } else if (evidence.accepted && evidence.confidence > secondBestScore) {
                        secondBestScore = evidence.confidence
                    }
                }
            }
            if (bestIndex >= 0 &&
                (componentsCompatible(uf, i, bestIndex, ::cachedScore) ||
                    officialAnchorComponentBridgeCompatible(records, uf, i, bestIndex, ::cachedScore))) {
                uf.union(i, bestIndex)

                // Learn only from a verified official anchor with strong
                // two-sided identity and a clear candidate margin. Rejected or
                // ambiguous Wuxi-style matches never reach this block.
                val officialRecord = records[bestIndex]
                val official = officialRecord.official
                if (official != null) {
                    val margin = if (secondBestScore < 0.0) 1.0 else bestScore - secondBestScore
                    val country = TeamAliasCanonicalizer.canonicalCountry(
                        candidate.competitionCountry.ifBlank { countryFromCompetition(candidate.competitionName) }
                    )
                    val evidence = cachedScore(i, bestIndex)
                    AutoAliasCache.tryLearnAlias(
                        provider = candidate.source,
                        country = country,
                        providerTeamName = candidate.homeTeam,
                        officialIddaaName = official.homeTeam,
                        homeSim = evidence.homeSimilarity,
                        awaySim = evidence.awaySimilarity,
                        isSameOfficialFixture = true,
                        marginToSecondBest = margin
                    )
                    AutoAliasCache.tryLearnAlias(
                        provider = candidate.source,
                        country = country,
                        providerTeamName = candidate.awayTeam,
                        officialIddaaName = official.awayTeam,
                        homeSim = evidence.awaySimilarity,
                        awaySim = evidence.homeSimilarity,
                        isSameOfficialFixture = true,
                        marginToSecondBest = margin
                    )
                }
            }
        }

        // PASS 4 -----------------------------------------------------
        // Global fuzzy clustering among non-official records. No prefix block,
        // no greedy "first match wins". Pair decisions are evidence based.
        // IMPORTANT: Union-Find connectivity alone is NOT fixture identity.
        // Before any union we require the two entire components to be mutually
        // compatible. This blocks A-B + B-C from becoming a false A-C fixture.
        for (i in records.indices) {
            for (j in i + 1 until records.size) {
                val a = records[i]
                val b = records[j]
                if (sameSourceDifferentIds(a, b)) continue
                // Official fixtures are already handled by PASS 1/3. Keeping
                // them out of global fuzzy clustering prevents an official
                // record from acting as a bridge between unrelated predictions.
                if (a.official != null || b.official != null) continue

                val evidence = cachedScore(i, j)
                if (!evidence.accepted) continue

                // High-confidence fuzzy pairs may union globally. Exact canonical
                // fixtures were already unioned in PASS 2; official anchors were
                // handled in PASS 3.
                if (evidence.idAnchor ||
                    evidence.officialAnchor ||
                    evidence.confidence >= AUTO_MERGE_CONFIDENCE) {
                    if (componentsCompatible(uf, i, j, ::cachedScore)) {
                        uf.union(i, j)
                    }
                }
            }
        }

        // PASS 5 -----------------------------------------------------
        // Exact-official recovery. Some providers publish a stale kickoff or a
        // different competition label even though their HOME/AWAY names are an
        // exact canonical identity of one official fixture. The normal evidence
        // scorer intentionally rejects explicit metadata contradictions; that is
        // correct for fuzzy matching, but it can leave the same real fixture in
        // a second component. Before building UI groups, recover ONLY when there
        // is a UNIQUE official fixture with the exact canonical HOME/AWAY pair,
        // the provider date is equal to the official date (or missing), and the
        // provider has no reserve/youth tier contradiction. Kickoff/competition
        // differences are then treated as provider metadata, while identity and
        // calendar date remain hard safety gates.
        val exactOfficialByFixtureKey = HashMap<String, MutableList<Int>>()
        officialIndices.forEach { index ->
            exactOfficialByFixtureKey
                .getOrPut(records[index].fixtureKey) { mutableListOf() }
                .add(index)
        }

        records.indices.forEach { providerIndex ->
            val provider = records[providerIndex]
            if (provider.official != null) return@forEach

            // Already attached to an official component; no recovery needed.
            if (uf.componentMembers(providerIndex).any { records[it].official != null }) return@forEach

            val candidates = exactOfficialByFixtureKey[provider.fixtureKey].orEmpty()
            if (candidates.size != 1) return@forEach
            val officialIndex = candidates.first()
            val official = records[officialIndex]

            if (!exactOfficialRecoveryCompatible(provider, official)) return@forEach

            // Do not bridge an existing provider component through a merely
            // canonical-looking record. Every existing member must preserve the
            // same exact HOME/AWAY identity and calendar date.
            val members = uf.componentMembers(providerIndex)
            val componentSafe = members.all { memberIndex ->
                val member = records[memberIndex]
                member.homeCanonicalId == official.homeCanonicalId &&
                    member.awayCanonicalId == official.awayCanonicalId &&
                    exactCalendarDateCompatible(member, official)
            }
            if (componentSafe) uf.union(providerIndex, officialIndex)
        }

        // Build connected components.
        val grouped = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { index ->
            grouped.getOrPut(uf.find(index)) { mutableListOf() }.add(records[index])
        }

        return grouped.values.map(::buildUnified)
    }

    private fun exactCalendarDateCompatible(a: Record, b: Record): Boolean {
        val da = parseDate(a.matchDate)
        val db = parseDate(b.matchDate)
        if (da == null || db == null) return true
        return da == db
    }

    private fun exactOfficialRecoveryCompatible(provider: Record, official: Record): Boolean {
        if (provider.homeCanonicalId.isBlank() || provider.awayCanonicalId.isBlank()) return false
        if (provider.homeCanonicalId != official.homeCanonicalId ||
            provider.awayCanonicalId != official.awayCanonicalId) return false
        if (TeamAliasCanonicalizer.tier(provider.homeTeam) != TeamAliasCanonicalizer.tier(official.homeTeam)) return false
        if (TeamAliasCanonicalizer.tier(provider.awayTeam) != TeamAliasCanonicalizer.tier(official.awayTeam)) return false
        return exactCalendarDateCompatible(provider, official)
    }

    /**
     * Prevents transitive fixture pollution. A union is allowed only when every
     * record already in component A is compatible with every record already in
     * component B. Pairwise graph connectivity is not sufficient for a fixture:
     * A~B and B~C must NOT imply A~C.
     */
    private fun componentsCompatible(
        uf: UnionFind,
        aIndex: Int,
        bIndex: Int,
        scorer: (Int, Int) -> MatchEvidence
    ): Boolean {
        val rootA = uf.find(aIndex)
        val rootB = uf.find(bIndex)
        if (rootA == rootB) return true

        // Union-Find keeps component membership incrementally. The old code
        // rescanned ALL records to discover both components for every accepted
        // pair, turning a few hundred fixtures into a very expensive nested
        // hot path. We keep the exact same pairwise safety rule, but inspect only
        // the two actual components.
        val membersA = uf.componentMembers(rootA)
        val membersB = uf.componentMembers(rootB)
        for (a in membersA) {
            for (b in membersB) {
                if (!scorer(a, b).accepted) return false
            }
        }
        return true
    }


    /**
     * Official-anchor bridge for an already-built provider component.
     *
     * Normal component compatibility intentionally requires every provider
     * record in component A to be pairwise compatible with every record in
     * component B. That is the right default for fuzzy clustering, but an
     * authoritative Iddaa fixture is a stronger identity anchor: provider
     * variants may disagree with one another on spelling/metadata while each
     * independently identifies the same official fixture.
     *
     * This bridge is deliberately narrow:
     *  - exactly one side must be an official component;
     *  - the official component must represent one official matchId;
     *  - every provider record must independently pass the existing scorer
     *    against that official anchor;
     *  - every provider record must also have two-sided strong identity evidence
     *    (exact canonical identity or fingerprint >= 0.95 with no contradiction).
     *
     * We never compare/merge unrelated provider components merely because one
     * member looks similar. The official fixture remains the single authority.
     */
    private fun officialAnchorComponentBridgeCompatible(
        records: List<Record>,
        uf: UnionFind,
        aIndex: Int,
        bIndex: Int,
        scorer: (Int, Int) -> MatchEvidence
    ): Boolean {
        val rootA = uf.find(aIndex)
        val rootB = uf.find(bIndex)
        if (rootA == rootB) return true

        val membersA = uf.componentMembers(rootA)
        val membersB = uf.componentMembers(rootB)
        val officialA = membersA.filter { records[it].official != null }
        val officialB = membersB.filter { records[it].official != null }

        // The bridge is only for provider-component -> single official anchor.
        if (officialA.isNotEmpty() == officialB.isNotEmpty()) return false

        val officialMembers = if (officialA.isNotEmpty()) officialA else officialB
        val providerMembers = if (officialA.isNotEmpty()) membersB else membersA
        if (officialMembers.isEmpty() || providerMembers.isEmpty()) return false

        val officialIds = officialMembers
            .mapNotNull { records[it].official?.matchId?.takeIf(String::isNotBlank) }
            .distinct()
        if (officialIds.size > 1) return false

        val anchorIndex = officialMembers.first()
        val anchor = records[anchorIndex]

        // All official records in this component must describe the same fixture
        // before the bridge is allowed to operate. If IDs are unavailable, fall
        // back to the canonical home/away fixture key.
        if (officialIds.isEmpty()) {
            val keys = officialMembers.map { records[it].fixtureKey }.distinct()
            if (keys.size != 1 || keys.first() == "||") return false
        }

        for (providerIndex in providerMembers) {
            val provider = records[providerIndex]
            val evidence = scorer(providerIndex, anchorIndex)
            if (!evidence.accepted || !evidence.officialAnchor) return false

            val homeExact =
                provider.homeIdentity.canonicalId.isNotBlank() &&
                    provider.homeIdentity.canonicalId == anchor.homeIdentity.canonicalId &&
                    evidence.homeSimilarity >= 0.99
            val awayExact =
                provider.awayIdentity.canonicalId.isNotBlank() &&
                    provider.awayIdentity.canonicalId == anchor.awayIdentity.canonicalId &&
                    evidence.awaySimilarity >= 0.99

            val homeFp = fingerprintIdentityScore(provider.homeTeam, anchor.homeTeam)
            val awayFp = fingerprintIdentityScore(provider.awayTeam, anchor.awayTeam)
            val contradiction =
                fingerprintIdentityContradiction(provider.homeTeam, anchor.homeTeam) ||
                    fingerprintIdentityContradiction(provider.awayTeam, anchor.awayTeam)

            val strongFingerprint =
                !contradiction && homeFp >= 0.95 && awayFp >= 0.95

            if (!((homeExact && awayExact) || strongFingerprint)) return false
        }

        return true
    }

    /** Public for regression tests and diagnostics. */
    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() ||
            b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, 0.0, false, false, 0.0, false)
        }

        if (sameSourceDifferentIds(a, b)) {
            return MatchEvidence(0.0, 0.0, 0.0, -1.0, 0.0, false, false, 0.0, false)
        }

        // CANONICAL INTEGRATION GATE (v0.23.2): every team comparison MUST
        // pass through TeamAliasCanonicalizer before any similarity operation.
        // Raw provider names are retained only for diagnostics/display.
        val homeCanonicalA = a.homeIdentity.canonicalName
        val homeCanonicalB = b.homeIdentity.canonicalName
        val awayCanonicalA = a.awayIdentity.canonicalName
        val awayCanonicalB = b.awayIdentity.canonicalName

        val home = TeamAliasCanonicalizer.similarityCanonical(
            homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
        )
        val away = TeamAliasCanonicalizer.similarityCanonical(
            awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
        )
        val teamScore = (home + away) / 2.0
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
            TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val exactAway = TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val exactHome = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam)
        val exactCanonicalTeams =
            homeCanonicalA.isNotBlank() && homeCanonicalA == homeCanonicalB &&
            awayCanonicalA.isNotBlank() && awayCanonicalA == awayCanonicalB &&
            home >= 0.99 && away >= 0.99
        val idAnchor = sameComparableId(a, b)
        val officialAnchor = a.official != null || b.official != null
        val time = timeScore(a, b)
        val competition = competitionScore(a.competitionName, b.competitionName)
        val country = countryScore(a.competitionCountry, b.competitionCountry, a.competitionName, b.competitionName)
        val exactOfficialTeams = officialAnchor && (exactTeams || exactCanonicalTeams)
        val metadataAgreement = metadataAgreement(
            a, b, country,
            allowOfficialExactTeamTimeMismatch = exactOfficialTeams
        )

        // Explicit metadata contradictions are hard fixture evidence. Missing
        // metadata is neutral, but when both records publish the same dimension
        // we never merge a different date/kickoff/competition/country fixture.
        if (metadataAgreement < 0.0) {
            return MatchEvidence(home, away, teamScore, time, competition, false, officialAnchor, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // The official Iddaa fixture is the authority for today's roster. Some
        // prediction providers publish a stale/wrong competition label (or a
        // timezone-shifted kickoff) while still naming the exact same two teams.
        // When the canonical HOME and AWAY identities are exact, do not let a
        // provider-side competition/time mismatch erase an otherwise certain
        // official fixture. This is deliberately limited to official-anchor
        // matching; non-official clustering keeps the strict contradiction gates.
        // An exact two-sided official anchor may repair a provider kickoff
        // when the provider clock is stale/wrong. Calendar-date contradictions
        // remain hard rejects above; this rule is only for the same fixture.
        if (officialAnchor && (exactTeams || exactCanonicalTeams)) {
            val confidence = (
                0.94 +
                    0.03 * time.coerceAtLeast(0.0) +
                    0.03 * if (competition >= 0.0) competition else 0.0
            ).coerceIn(0.94, 0.99)
            return MatchEvidence(
                homeSimilarity = home,
                awaySimilarity = away,
                teamScore = 1.0,
                timeScore = time,
                competitionScore = competition,
                idAnchor = idAnchor,
                officialAnchor = true,
                confidence = confidence,
                accepted = true,
                homeCanonicalA = homeCanonicalA,
                homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA,
                awayCanonicalB = awayCanonicalB
            )
        }

        // OFFICIAL-ANCHOR FALLBACK WHEN PROVIDER METADATA IS MISSING:
        // Prediction parsers may publish only team + score and omit reliable
        // date/time/competition fields. In that situation
        // the previous matcher returned time=0.0 / competition=0.0 and then
        // required the full schedule gate, so valid Iddaa fixtures were silently
        // classified as "fixture-yok". The official Iddaa record already owns
        // the authoritative date/time/competition. If the provider has NO
        // schedule metadata at all, use the official fixture as the schedule
        // anchor and require strong team identity instead.
        //
        // This is deliberately narrower than generic fuzzy clustering: it is
        // only available against an official Iddaa record, and the non-official
        // side must prove at least one exact canonical team plus strong identity
        // on the other side. Thus language pairs such as Israel/İsrail work while
        // arbitrary same-city collisions do not.
        val providerScheduleMissing =
            a.matchTimestamp <= 0L && b.matchTimestamp > 0L &&
                a.matchDate.isBlank() &&
                (a.matchTime.isBlank() || a.matchTime == "--:--") &&
                a.competitionName.isBlank()
        val reverseProviderScheduleMissing =
            b.matchTimestamp <= 0L && a.matchTimestamp > 0L &&
                b.matchDate.isBlank() &&
                (b.matchTime.isBlank() || b.matchTime == "--:--") &&
                b.competitionName.isBlank()
        val oneSidedCanonicalAnchor =
            (homeCanonicalA == homeCanonicalB && home >= 0.99) ||
                (awayCanonicalA == awayCanonicalB && away >= 0.99)
        val otherSideIdentity =
            teamIdentityEvidence(homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam) &&
                teamIdentityEvidence(awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam)
        if (officialAnchor &&
            (providerScheduleMissing || reverseProviderScheduleMissing) &&
            oneSidedCanonicalAnchor && otherSideIdentity) {
            return MatchEvidence(
                home, away, 1.0, 1.0,
                if (competition >= 0.0) competition else 0.0,
                idAnchor = false, officialAnchor = true,
                confidence = 0.95, accepted = true,
                homeCanonicalA = homeCanonicalA, homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA, awayCanonicalB = awayCanonicalB
            )
        }

        // SCHEDULE + COMPETITION + ONE-SIDE TEAM ANCHOR:
        // Date + kickoff + competition are the hard fixture gates. Once those
        // three pieces are identical, a clear team identity on EITHER side is
        // enough to survive a language/name variant on the other side.
        //
        // Examples:
        //   Austria - Israel  <->  Avusturya - İsrail
        //   Manchester United - Arsenal <-> Man Utd - Arsenal
        //
        // The anchor may be an exact canonical identity or a very strong
        // canonical similarity (>= 0.97). This is intentionally NOT a fuzzy
        // schedule-free merge: without the exact date/time/competition gate it
        // cannot fire.
        val scheduleAndCompetition = sameExplicitSchedule(a, b) && competition >= 0.80
        val strongHomeAnchor = exactHome || home >= 0.97
        val strongAwayAnchor = exactAway || away >= 0.97
        if (scheduleAndCompetition && (strongHomeAnchor || strongAwayAnchor)) {
            return MatchEvidence(
                home, away, 1.0, 1.0, competition, idAnchor, false, 0.97, true,
                homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB
            )
        }

        // If both sources explicitly identify the competition/tournament and those
        // identities conflict, reject fuzzy matches. Exact official team identity
        // was handled immediately above. Missing competition data is neutral.
        if (competition < 0.0) {
            return MatchEvidence(home, away, teamScore, time, competition, false, officialAnchor, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // SMART DUPLICATE PREVENTION (V3): when both sides resolve to the exact
        // same canonical team identities, do not let missing/partial metadata or
        // a harmless timezone drift create a second card. The 12-hour hard gate
        // above still protects against a genuinely different calendar fixture.
        // Explicit competition contradictions remain a hard gate, so a cup match
        // cannot silently merge with a league match involving the same teams.
        if (!officialAnchor && exactCanonicalTeams && time >= 0.0) {
            return MatchEvidence(
                homeSimilarity = home,
                awaySimilarity = away,
                teamScore = 1.0,
                timeScore = time,
                competitionScore = competition,
                idAnchor = idAnchor,
                officialAnchor = false,
                confidence = 0.98,
                accepted = true,
                homeCanonicalA = homeCanonicalA,
                homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA,
                awayCanonicalB = awayCanonicalB
            )
        }

        // Same official ID or same ID in the same source is the strongest anchor.
        if (idAnchor) {
            return MatchEvidence(home, away, teamScore, maxOf(0.0, time), competition, true, officialAnchor, 1.0, true)
        }

        // Official roster is authoritative for today's fixtures. Do not let a
        // provider timezone/date contradiction reject a strong two-sided name match.
        if (time < 0.0 && !officialAnchor) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (officialAnchor) {
            // A known kickoff contradiction is a hard rejection for every official
            // matching path, including fuzzy identity. Exact team names must never
            // override a different fixture date/time.
            if (time < 0.0) {
                return MatchEvidence(
                    home, away, teamScore, time, competition, false, true, 0.0, false,
                    homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB
                )
            }

            // Official matching must prove TEAM IDENTITY, not merely string
            // similarity. This prevents collisions such as:
            //   Minnesota United -> Manchester United
            //   Al Sailiya -> Al Quwa Al Jawiya
            //   Ostersunds -> Estrela (Braga)
            // while still accepting legitimate provider expansions such as:
            //   Bokelj -> FK Bokelj Kotor
            //   Otrant -> FK Otrant-Olympic Ulcinj
            //   Dallas -> FC Dallas
            val homeIdentity = teamIdentityEvidence(
                homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
            )
            val awayIdentity = teamIdentityEvidence(
                awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
            )
            val homeFingerprint = fingerprintIdentityScore(a.homeTeam, b.homeTeam)
            val awayFingerprint = fingerprintIdentityScore(a.awayTeam, b.awayTeam)
            val fingerprintContradiction =
                fingerprintIdentityContradiction(a.homeTeam, b.homeTeam) ||
                    fingerprintIdentityContradiction(a.awayTeam, b.awayTeam)
            val fingerprintBridge =
                !fingerprintContradiction &&
                    homeFingerprint >= 0.95 &&
                    awayFingerprint >= 0.95 &&
                    ((homeFingerprint + awayFingerprint) / 2.0) >= 0.95
            val accepted = exactTeams || exactCanonicalTeams || fingerprintBridge || (
                homeIdentity &&
                    awayIdentity &&
                    home >= 0.72 &&
                    away >= 0.72
            )
            if (!accepted) {
                return MatchEvidence(home, away, teamScore, time, competition, false, true, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
            }
            val confidence = (
                0.50 * teamScore +
                    0.20 * time.coerceAtLeast(0.0) +
                    0.15 * competition.coerceAtLeast(0.0) +
                    0.15
            ).coerceIn(0.0, 0.99)
            return MatchEvidence(home, away, teamScore, time, competition, false, true, confidence, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // Non-official fuzzy match: both sides must pass. A one-sided high score
        // is never sufficient.
        if (home < TEAM_FUZZY_MIN || away < TEAM_FUZZY_MIN || teamScore < MATCH_FUZZY_MIN) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (exactTeams) {
            val exactConfidence = if (metadataAgreement > 0.0) 0.995 else 0.99
            return MatchEvidence(home, away, 1.0, time, competition, false, false, exactConfidence, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        val timeContribution = if (time > 0.0) time else 0.0
        val countryContribution = country.coerceAtLeast(0.0)
        var confidence = 0.52 * teamScore + 0.18 * timeContribution + 0.15 * competition.coerceAtLeast(0.0) + 0.10 * countryContribution + 0.05 * metadataAgreement.coerceAtLeast(0.0)
        if (home >= 0.97 && away >= 0.97) confidence += 0.04
        if (time >= 0.95) confidence += 0.04
        confidence = confidence.coerceIn(0.0, 0.99)

        return MatchEvidence(home, away, teamScore, time, competition, false, false, confidence, confidence >= AUTO_MERGE_CONFIDENCE, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
    }

    /**
     * Strong team-identity evidence for official fixture matching.
     *
     * Similarity alone is intentionally NOT identity. Common words such as
     * "al", "city", "united", "fc" and short fragments can make unrelated
     * clubs look deceptively close.
     *
     * We accept only:
     *  - exact canonical identity; or
     *  - a conservative token-subset expansion where the shorter canonical name
     *    is wholly contained in the longer one and contains a distinctive token
     *    (>= 5 chars). This covers source expansions like "Bokelj" ->
     *    "Bokelj Kotor" without making generic words an identity anchor.
     */
    private fun teamIdentityEvidence(
        canonicalA: String,
        canonicalB: String,
        rawA: String,
        rawB: String
    ): Boolean {
        if (canonicalA.isBlank() || canonicalB.isBlank()) return false
        if (TeamAliasCanonicalizer.exact(rawA, rawB)) return true
        if (canonicalA == canonicalB) return true

        // V5.1 fingerprint bridge: generic identity evidence may establish an
        // official anchor when the fingerprint itself is >= 0.95 and does not
        // report a descriptor/tier contradiction. This is the bridge that lets
        // CS Deportivo Pereira <-> Deportivo Pereira and Independiente Santa Fe
        // <-> Santa Fe pass without hardcoded aliases.
        val fpA = TeamFingerprintExtractor.createFingerprint(rawA)
        val fpB = TeamFingerprintExtractor.createFingerprint(rawB)
        val fp = FingerprintMatcher.calculateSimilarity(fpA, fpB)
        if (!fp.isContradiction && fp.finalScore >= 0.95) return true

        val aTokens = canonicalA.split(' ').filter(String::isNotBlank).toSet()
        val bTokens = canonicalB.split(' ').filter(String::isNotBlank).toSet()
        if (aTokens.isEmpty() || bTokens.isEmpty()) return false

        val smaller = if (aTokens.size <= bTokens.size) aTokens else bTokens
        val larger = if (aTokens.size <= bTokens.size) bTokens else aTokens
        if (!larger.containsAll(smaller)) return false

        // Generic edge words are never allowed to establish identity.
        val generic = setOf(
            "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk",
            "afc", "ff", "cf", "sc", "ac", "as", "bsc", "rc", "sv",
            "bk", "pfc", "club", "city", "united"
        )
        val distinctive = smaller.filter { it.length >= 5 && it !in generic }
        return distinctive.isNotEmpty()
    }

    private fun competitionScore(a: String, b: String): Double {
        val ca = normalizeCompetition(a)
        val cb = normalizeCompetition(b)
        if (ca.isBlank() || cb.isBlank()) return 0.0
        if (ca == cb) return 1.0
        val compactA = ca.replace(" ", "")
        val compactB = cb.replace(" ", "")
        if (compactA == compactB) return 1.0
        val maxLen = maxOf(compactA.length, compactB.length)
        if (maxLen == 0) return 1.0
        val distance = levenshtein(compactA, compactB)
        val similarity = 1.0 - distance.toDouble() / maxLen
        return if (similarity >= 0.80) similarity else -1.0
    }

    private fun normalizeCompetition(value: String): String =
        TeamAliasCanonicalizer.canonicalCompetition(value)

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(replace, current[j - 1] + 1, previous[j] + 1)
            }
            val swap = previous; previous = current; current = swap
        }
        return previous[b.length]
    }

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, ignoreCase = true)) return false
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        return idA.isNotBlank() && idB.isNotBlank() && idA != idB
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        if (idA.isBlank() || idB.isBlank() || idA != idB) return false

        // IDs are only portable when both records explicitly belong to the same
        // provider namespace, or both are official records.
        return a.source.equals(b.source, ignoreCase = true) ||
            (a.official != null && b.official != null)
    }

    /**
     * Time evidence:
     *  1. exact/near kickoff -> positive score
     *  2. 3h is the soft tolerance requested for timezone drift
     *  3. >6h is a hard contradiction
     *  4. missing time -> neutral (0), not a penalty
     *  5. known different calendar dates -> contradiction unless timestamps are
     *     close enough to account for timezone rollover.
     */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            return (1.0 - (delta.toDouble() / TIME_HARD_WINDOW_MS)).coerceIn(0.0, 1.0)
        }

        val dateA = parseDate(a.matchDate)
        val dateB = parseDate(b.matchDate)
        if (dateA != null && dateB != null) {
            val days = abs(java.time.temporal.ChronoUnit.DAYS.between(dateA, dateB))
            return when {
                days == 0L -> 0.92
                // With no trustworthy timestamp we cannot safely explain a calendar-day
                // difference. Treat it as a hard contradiction rather than allowing
                // exact team names to bridge two different fixtures.
                else -> -1.0
            }
        }

        return 0.0
    }

    /**
     * Strict fixture schedule gate used by the one-sided away-team fallback.
     * Both date and kickoff must be present and equal (or timestamps must be
     * within 15 minutes), otherwise the fallback is deliberately disabled.
     */
    private fun sameExplicitSchedule(a: Record, b: Record): Boolean {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            return abs(a.matchTimestamp - b.matchTimestamp) <= 15L * 60L * 1000L
        }
        val dateA = parseDate(a.matchDate) ?: return false
        val dateB = parseDate(b.matchDate) ?: return false
        if (dateA != dateB) return false
        val timeA = parseTime(a.matchTime) ?: return false
        val timeB = parseTime(b.matchTime) ?: return false
        return timeA == timeB
    }

    /** Compare country/region context conservatively; blank is neutral. */
    private fun countryScore(a: String, b: String, competitionA: String = "", competitionB: String = ""): Double {
        val ca = countryFromCompetition(a.ifBlank { competitionA })
        val cb = countryFromCompetition(b.ifBlank { competitionB })
        if (ca.isBlank() || cb.isBlank()) return 0.0
        return if (ca == cb) 1.0 else -1.0
    }

    /**
     * Country identity is language-independent and uses the same canonical
     * vocabulary as TeamAliasCanonicalizer.  The longest phrases are checked
     * first so "nigeria" can never be mistaken for "niger".
     *
     * This is deliberately an exact country-context layer: it does not fuzzy
     * match arbitrary words and therefore cannot merge unrelated competitions.
     */
    private fun countryFromCompetition(value: String): String =
        TeamAliasCanonicalizer.canonicalCountry(value)


    /**
     * Strict midnight/time-zone rollover exception. Callers must already prove
     * both HOME and AWAY identities; this helper never establishes team identity.
     */
    private fun isAdjacentDateTimezoneShift(
        dateA: String,
        dateB: String,
        timestampA: Long,
        timestampB: Long
    ): Boolean {
        if (timestampA <= 0L || timestampB <= 0L) return false
        val dayA = parseDate(dateA) ?: return false
        val dayB = parseDate(dateB) ?: return false
        if (kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(dayA, dayB)) != 1L) return false
        return abs(timestampA - timestampB) <= TIME_HARD_WINDOW_MS
    }

    /**
     * Metadata agreement is positive when date/time/competition/country evidence
     * agrees, negative only when two explicit values contradict. Missing values are
     * neutral so a richer source can supply the missing kickoff later.
     */
    private fun metadataAgreement(
        a: Record,
        b: Record,
        country: Double,
        allowOfficialExactTeamTimeMismatch: Boolean = false
    ): Double {
        var evidence = 0.0
        var known = 0
        if (a.matchDate.isNotBlank() && b.matchDate.isNotBlank()) {
            known++
            val da = parseDate(a.matchDate); val db = parseDate(b.matchDate)
            if (da != null && db != null) {
                if (da == db) {
                    evidence += 0.35
                } else {
                    // Exact two-sided Iddaa anchors may cross local midnight only
                    // when the dates are adjacent and real timestamps are within 12h.
                    val boundaryShift = allowOfficialExactTeamTimeMismatch &&
                        isAdjacentDateTimezoneShift(a.matchDate, b.matchDate,
                            a.matchTimestamp, b.matchTimestamp)
                    if (!boundaryShift) return -1.0
                    evidence += 0.15
                }
            }
        }
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            known++
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta <= 15L * 60L * 1000L) evidence += 0.35
            else if (delta <= TIME_SOFT_WINDOW_MS) evidence += 0.20
            else {
                // Provider timestamps are frequently synthesized from partial
                // metadata and may use a different timezone/anchor. Never turn
                // that alone into a hard fixture contradiction. A hard kickoff
                // rejection is only justified when BOTH records expose an
                // explicit human-readable kickoff time.
                val explicitKickoff = a.matchTime.isNotBlank() &&
                    a.matchTime != "--:--" && b.matchTime.isNotBlank() &&
                    b.matchTime != "--:--"
                if (explicitKickoff && delta > TIME_HARD_WINDOW_MS &&
                    !allowOfficialExactTeamTimeMismatch) return -1.0
            }
        }
        if (a.competitionName.isNotBlank() && b.competitionName.isNotBlank()) {
            known++
            if (competitionScore(a.competitionName, b.competitionName) < 0.0) return -1.0
            evidence += 0.20
        }
        if (country < 0.0) return -1.0
        if (country > 0.0) { known++; evidence += 0.10 }
        return if (known == 0) 0.0 else evidence.coerceIn(0.0, 1.0)
    }

    private fun parseTime(value: String): LocalTime? {
        val v = value.trim()
        if (v.isBlank() || v == "--:--") return null
        return runCatching { LocalTime.parse(v, DateTimeFormatter.ofPattern("HH:mm")) }.getOrNull()
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) {
            val parsed = runCatching {
                LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    /**
     * Reverse-direction diagnostic: for one official fixture, inspect one provider
     * source and determine whether the fixture is actually present in the parsed
     * provider data, present but rejected by identity/metadata gates, or absent.
     * This is diagnostic-only and never changes merge behavior.
     */
    fun diagnoseOfficialCoverage(
        official: IddaaMarketService.OpenedMarketMatch,
        source: String,
        predictions: List<ScoreModel>
    ): PredictionSourceCoverageItem {
        if (predictions.isEmpty()) {
            return PredictionSourceCoverageItem(
                officialHome = official.homeTeam,
                officialAway = official.awayTeam,
                source = source,
                status = PredictionCoverageStatus.SOURCE_ABSENT_FROM_PARSED_DATA,
                reason = "NO_PARSED_PREDICTION"
            )
        }

        val o = Record(
            homeTeam = official.homeTeam,
            awayTeam = official.awayTeam,
            source = "IDDAA",
            sourceMatchId = official.matchId,
            matchTimestamp = official.matchTimestamp,
            matchDate = official.matchDate,
            matchTime = official.matchTime,
            competitionName = official.competitionName,
            competitionCountry = countryFromCompetition(official.competitionName),
            official = official
        )

        fun genericFixtureKey(home: String, away: String): String =
            "${TeamAliasCanonicalizer.identity(home).canonicalId}||${TeamAliasCanonicalizer.identity(away).canonicalId}"

        fun rankPredictions(pool: List<ScoreModel>): List<Triple<ScoreModel, MatchEvidence, Double>> =
            pool.map { prediction ->
                val p = Record(
                    homeTeam = prediction.homeTeam,
                    awayTeam = prediction.awayTeam,
                    predictedScore = prediction.predictedScore,
                    source = prediction.source,
                    sourceMatchId = prediction.sourceMatchId,
                    matchTimestamp = prediction.matchTimestamp,
                    matchDate = prediction.matchDate,
                    matchTime = prediction.matchTime,
                    competitionName = prediction.competitionName,
                    competitionCountry = prediction.competitionCountry.ifBlank {
                        countryFromCompetition(prediction.competitionName)
                    }
                )
                val evidence = score(p, o)
                val combined = (evidence.homeSimilarity + evidence.awaySimilarity) / 2.0
                Triple(prediction, evidence, combined)
            }.sortedWith(
                compareByDescending<Triple<ScoreModel, MatchEvidence, Double>> { it.third }
                    .thenByDescending { it.second.homeSimilarity + it.second.awaySimilarity }
                    .thenByDescending { it.second.timeScore }
            )

        // Exact canonical fixture identity is a safe diagnostic prefilter. If it
        // produces no accepted candidate, retain the previous full-roster fallback
        // so diagnostics never hide a fuzzy cross-language match.
        val exactPool = predictions.filter {
            genericFixtureKey(it.homeTeam, it.awayTeam) == genericFixtureKey(official.homeTeam, official.awayTeam)
        }
        val rankedExact = if (exactPool.isNotEmpty()) rankPredictions(exactPool) else emptyList()
        val ranked = if (rankedExact.any { it.second.accepted }) rankedExact else rankPredictions(predictions)

        val best = ranked.first()
        val prediction = best.first
        val evidence = best.second
        val combined = best.third
        val plausiblePresence =
            evidence.homeSimilarity >= 0.55 &&
            evidence.awaySimilarity >= 0.55 &&
            combined >= 0.60

        val status = when {
            evidence.accepted -> PredictionCoverageStatus.MATCHED
            plausiblePresence -> PredictionCoverageStatus.SOURCE_PRESENT_BUT_UNMATCHED
            else -> PredictionCoverageStatus.SOURCE_ABSENT_FROM_PARSED_DATA
        }

        val reason = when {
            evidence.accepted -> "MATCHED_BY_IDENTITY_PIPELINE"
            evidence.homeSimilarity < 0.55 || evidence.awaySimilarity < 0.55 -> "NO_CREDIBLE_TWO_SIDED_NAME_CANDIDATE"
            prediction.matchDate.isNotBlank() && official.matchDate.isNotBlank() &&
                parseDate(prediction.matchDate) != null && parseDate(official.matchDate) != null &&
                parseDate(prediction.matchDate) != parseDate(official.matchDate) -> "DATE_MISMATCH"
            prediction.matchTimestamp > 0L && official.matchTimestamp > 0L &&
                abs(prediction.matchTimestamp - official.matchTimestamp) > TIME_HARD_WINDOW_MS -> "TIME_MISMATCH"
            prediction.competitionName.isNotBlank() && official.competitionName.isNotBlank() &&
                competitionScore(prediction.competitionName, official.competitionName) < 0.0 -> "COMPETITION_MISMATCH"
            else -> "IDENTITY_OR_METADATA_GATE_REJECTED"
        }

        return PredictionSourceCoverageItem(
            officialHome = official.homeTeam,
            officialAway = official.awayTeam,
            source = source,
            status = status,
            bestPredictionHome = prediction.homeTeam,
            bestPredictionAway = prediction.awayTeam,
            homeSimilarity = evidence.homeSimilarity,
            awaySimilarity = evidence.awaySimilarity,
            combinedSimilarity = combined,
            reason = reason
        )
    }

    /**
     * Explain why a provider prediction did not attach to the official bulletin.
     * This is diagnostic-only: it never changes merge behavior.
     */
    private data class DiagnosticCandidateCompat(
        val official: IddaaMarketService.OpenedMarketMatch,
        val evidence: MatchEvidence,
        val combined: Double
    )

    fun diagnoseOfficialMismatch(
        prediction: ScoreModel,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): UnmatchedDiagnosticItem {
        if (officialMatches.isEmpty()) {
            return UnmatchedDiagnosticItem(
                predictionHome = prediction.homeTeam, predictionAway = prediction.awayTeam,
                bestOfficialHome = null, bestOfficialAway = null,
                homeSimilarity = 0.0, awaySimilarity = 0.0, combinedSimilarity = 0.0,
                probableReason = UnmatchedReason.OFFICIAL_BULLETIN_ABSENT
            )
        }

        val p = Record(
            homeTeam = prediction.homeTeam, awayTeam = prediction.awayTeam,
            predictedScore = prediction.predictedScore, source = prediction.source,
            sourceMatchId = prediction.sourceMatchId, matchTimestamp = prediction.matchTimestamp,
            matchDate = prediction.matchDate, matchTime = prediction.matchTime,
            competitionName = prediction.competitionName,
            competitionCountry = prediction.competitionCountry.ifBlank {
                countryFromCompetition(prediction.competitionName)
            }
        )


        fun rankOfficials(pool: List<IddaaMarketService.OpenedMarketMatch>): List<DiagnosticCandidateCompat> =
            pool.map { official ->
                val o = Record(
                    homeTeam = official.homeTeam, awayTeam = official.awayTeam, source = "IDDAA",
                    sourceMatchId = official.matchId, matchTimestamp = official.matchTimestamp,
                    matchDate = official.matchDate, matchTime = official.matchTime,
                    competitionName = official.competitionName,
                    competitionCountry = countryFromCompetition(official.competitionName),
                    official = official
                )
                val e = score(p, o)
                DiagnosticCandidateCompat(official, e, (e.homeSimilarity + e.awaySimilarity) / 2.0)
            }.sortedWith(
                compareByDescending<DiagnosticCandidateCompat> { it.combined }
                    .thenByDescending { it.evidence.homeSimilarity + it.evidence.awaySimilarity }
                    .thenByDescending { it.evidence.timeScore }
                    .thenByDescending { it.evidence.competitionScore }
            )

        val exactOfficialPool = officialMatches.filter { official ->
            TeamAliasCanonicalizer.identity(official.homeTeam).canonicalId == TeamAliasCanonicalizer.identity(prediction.homeTeam).canonicalId &&
                TeamAliasCanonicalizer.identity(official.awayTeam).canonicalId == TeamAliasCanonicalizer.identity(prediction.awayTeam).canonicalId
        }
        val rankedExact = if (exactOfficialPool.isNotEmpty()) rankOfficials(exactOfficialPool) else emptyList()
        val allRanked = if (rankedExact.any { it.evidence.accepted }) rankedExact else rankOfficials(officialMatches)

        val bestName = allRanked.first()
        val genuineCandidates = allRanked.filter {
            it.evidence.homeSimilarity >= TEAM_FUZZY_MIN &&
                it.evidence.awaySimilarity >= TEAM_FUZZY_MIN &&
                it.combined >= MATCH_FUZZY_MIN
        }

        // IMPORTANT: "NO_OFFICIAL_CANDIDATE" previously meant two very different
        // things: (a) the fixture is genuinely absent from the official bulletin,
        // or (b) the bulletin contains the fixture but one/both team names could
        // not be reconciled. Split those cases here without changing merge logic.
        if (genuineCandidates.isEmpty()) {
            val oneSidedOrWeakName = bestName.evidence.homeSimilarity < TEAM_FUZZY_MIN ||
                bestName.evidence.awaySimilarity < TEAM_FUZZY_MIN ||
                bestName.combined < MATCH_FUZZY_MIN

            val reason = if (oneSidedOrWeakName) {
                // A clearly plausible two-sided name candidate does not exist.
                // If even the best candidate is weak on at least one side, the
                // official bulletin does not contain a safely identifiable match.
                // Keep NAME_MISMATCH for cases where one side is strong enough to
                // prove that the bulletin is related but the opposite side fails.
                val strongHome = bestName.evidence.homeSimilarity >= TEAM_FUZZY_MIN
                val strongAway = bestName.evidence.awaySimilarity >= TEAM_FUZZY_MIN
                if (strongHome.xor(strongAway) || bestName.combined >= 0.55) {
                    UnmatchedReason.NAME_MISMATCH
                } else {
                    UnmatchedReason.OFFICIAL_BULLETIN_ABSENT
                }
            } else {
                UnmatchedReason.OFFICIAL_BULLETIN_ABSENT
            }

            return diagnosticItem(
                prediction = prediction,
                candidate = bestName,
                reason = reason,
                canonicalPrediction = p
            )
        }

        val best = genuineCandidates.first()
        val second = genuineCandidates.getOrNull(1)
        val e = best.evidence

        // Metadata diagnosis is intentionally performed from the raw official
        // candidate, not from the accepted/rejected score. This preserves the
        // actual failure reason when a hard metadata gate rejects an otherwise
        // very strong two-sided team match.
        val pDate = parseDate(prediction.matchDate)
        val oDate = parseDate(best.official.matchDate)
        if (pDate != null && oDate != null && pDate != oDate) {
            return diagnosticItem(
                prediction, best, UnmatchedReason.DATE_MISMATCH, p
            )
        }

        val pTime = parseTime(prediction.matchTime)
        val oTime = parseTime(best.official.matchTime)
        if (pTime != null && oTime != null && prediction.matchTimestamp > 0L &&
            best.official.matchTimestamp > 0L &&
            abs(prediction.matchTimestamp - best.official.matchTimestamp) > TIME_HARD_WINDOW_MS &&
            !(TeamAliasCanonicalizer.exact(prediction.homeTeam, best.official.homeTeam) &&
                TeamAliasCanonicalizer.exact(prediction.awayTeam, best.official.awayTeam))
        ) {
            return diagnosticItem(
                prediction, best, UnmatchedReason.TIME_MISMATCH, p
            )
        }

        if (prediction.competitionName.isNotBlank() && best.official.competitionName.isNotBlank() &&
            competitionScore(prediction.competitionName, best.official.competitionName) < 0.0
        ) {
            return diagnosticItem(
                prediction, best, UnmatchedReason.COMPETITION_MISMATCH, p
            )
        }

        val metadataMissing = prediction.matchDate.isBlank() &&
            (prediction.matchTime.isBlank() || prediction.matchTime == "--:--") &&
            prediction.competitionName.isBlank()
        val reason = when {
            second != null && abs(best.combined - second.combined) < 0.03 ->
                UnmatchedReason.AMBIGUOUS_OFFICIAL_CANDIDATE
            metadataMissing && best.combined >= 0.90 ->
                UnmatchedReason.METADATA_MISSING
            e.homeSimilarity < TEAM_FUZZY_MIN || e.awaySimilarity < TEAM_FUZZY_MIN ->
                UnmatchedReason.NAME_MISMATCH
            e.homeSimilarity >= 0.99 && e.awaySimilarity >= 0.99 ->
                UnmatchedReason.METADATA_MISSING
            !e.accepted -> UnmatchedReason.ALIAS_STEMMING_PROBLEM
            else -> UnmatchedReason.ALIAS_STEMMING_PROBLEM
        }

        return diagnosticItem(prediction, best, reason, p)
    }

    private fun diagnosticItem(
        prediction: ScoreModel,
        candidate: DiagnosticCandidateCompat,
        reason: UnmatchedReason,
        canonicalPrediction: Record
    ): UnmatchedDiagnosticItem {
        val c = candidate
        return UnmatchedDiagnosticItem(
            predictionHome = prediction.homeTeam,
            predictionAway = prediction.awayTeam,
            bestOfficialHome = c.official.homeTeam,
            bestOfficialAway = c.official.awayTeam,
            homeSimilarity = c.evidence.homeSimilarity,
            awaySimilarity = c.evidence.awaySimilarity,
            homeCanonicalPrediction = canonicalPrediction.homeCanonicalId,
            homeCanonicalOfficial = TeamAliasCanonicalizer.identity(c.official.homeTeam).canonicalId,
            awayCanonicalPrediction = canonicalPrediction.awayCanonicalId,
            awayCanonicalOfficial = TeamAliasCanonicalizer.identity(c.official.awayTeam).canonicalId,
            combinedSimilarity = c.combined,
            dateDifferenceDays = runCatching {
                val a = parseDate(prediction.matchDate)
                val b = parseDate(c.official.matchDate)
                if (a != null && b != null) kotlin.math.abs(java.time.temporal.ChronoUnit.DAYS.between(a, b)).toInt() else 0
            }.getOrDefault(0),
            probableReason = reason
        )
    }


    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(
            mainHomeTeam = display.first,
            mainAwayTeam = display.second,
            officialMatch = official,
            officialMatchId = official?.matchId.orEmpty(),
            fixtureKey = TeamAliasCanonicalizer.identity(display.first).canonicalId +
                "||" + TeamAliasCanonicalizer.identity(display.second).canonicalId
        )

        // One prediction per source. If the same provider emitted duplicates,
        // keep the record with the richest identity metadata.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { !it.predictedScore.isNullOrBlank() }.forEach { record ->
            val sourceKey = record.source.trim().lowercase()
            val old = bySource[sourceKey]
            if (old == null || sourcePriority(record) > sourcePriority(old)) {
                bySource[sourceKey] = record
            }
        }
        bySource.values.forEach { record ->
            result.predictions += record.source to record.predictedScore.orEmpty()
            result.predictionRecords += record
        }

        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun chooseDisplay(
        group: List<Record>,
        official: IddaaMarketService.OpenedMarketMatch?
    ): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull {
            TeamAliasCanonicalizer.canonical(it.homeTeam).length +
                TeamAliasCanonicalizer.canonical(it.awayTeam).length
        } ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourcePriority(record: Record): Int {
        var score = 0
        if (!record.predictedScore.isNullOrBlank()) score += 5
        if (record.matchTimestamp > 0L) score += 3
        if (record.matchDate.isNotBlank()) score += 1
        if (record.sourceMatchId.isNotBlank()) score += 1
        if (record.official != null) score += 10
        return score
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        val accepted = mutableListOf<Double>()
        for (i in 0 until group.lastIndex) {
            for (j in i + 1..group.lastIndex) {
                val evidence = score(group[i], group[j])
                if (evidence.accepted) accepted += evidence.confidence
            }
        }
        return if (accepted.isEmpty()) 1.0 else accepted.average().coerceIn(0.0, 1.0)
    }
}
