# CioScore v0.25.44 — Deep inspection / minimal safe ANR fix

## Observed symptom
The app reached `Kaynaklar: 4/4 başarılı` and then Android reported `CioScore yanıt vermiyor`.

## Root cause
`MainActivity.scan()` returned from the repository fetch onto `Dispatchers.Main`, then performed the expensive post-fetch work on the Android UI thread: prediction flattening/deduplication, official-fixture reconciliation, `GlobalFixtureMatcher` grouping, bidirectional coverage diagnostics, and `ScanTrace` construction. This can monopolize the main looper long enough to trigger an ANR.

## Minimal safe fix
The entire post-fetch computation is now wrapped in `withContext(Dispatchers.Default)`. Only the final `allGroups` assignment, RecyclerView submission, status text, and focus operation remain on the main thread.

## Safety invariants
- No fake scores or odds.
- No fixture synthesis.
- No change to prediction-source eligibility.
- No change to AiScore/Flashscore Bet365 verification.
- No change to Iddaa enrichment rules.
- No change to kickoff/past-match rules.
- No network access-control bypass added.

## Verification
Kotlin parser check reports no syntax/expecting errors in `MainActivity.kt`. Full Android Gradle build was not possible in this environment because Gradle 9.5.0 cannot be downloaded from `services.gradle.org` due DNS/network restrictions.
