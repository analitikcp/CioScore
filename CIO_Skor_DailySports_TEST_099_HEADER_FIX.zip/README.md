CIO Score 0.9.9 DailySports test.
Fix: replaced OkHttp Request.Builder.header() calls with addHeader() to avoid the reported unresolved reference at HttpClient.kt:23.
No other source parsers are included.
