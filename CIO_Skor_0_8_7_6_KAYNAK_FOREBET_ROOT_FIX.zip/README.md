CIO SCORE 0.8.7 - 6 KAYNAK - FOREBET DEFINITIVE FIX

Only Forebet was changed from the previous 6-source build.

Root cause found: ForebetParser used an invalid/fragile Jsoup CSS selector:
[class~=(^|\\s)rcnt(\\s|$)]
This could throw a selector parse exception before parsing the already-correct div.rcnt rows, causing Forebet to return 0.

Fix: removed that selector. The proven div.rcnt selector remains and the existing score/team fallbacks remain intact.
Other 5 working sources and DailySports are untouched.
