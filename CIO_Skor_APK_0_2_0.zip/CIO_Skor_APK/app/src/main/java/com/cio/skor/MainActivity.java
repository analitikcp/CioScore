package com.cio.skor;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    static class Source {
        final String name, url;
        Source(String name, String url) { this.name = name; this.url = url; }
    }

    static class Finding {
        String source, context, score;
        Finding(String source, String context, String score) {
            this.source = source; this.context = context; this.score = score;
        }
    }

    private final List<Source> sources = Arrays.asList(
        new Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        new Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        new Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        new Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        new Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/all-games/all-stakes/"),
        new Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        new Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        new Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        new Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        new Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        new Source("NerdyTips", "https://nerdytips.com/"),
        new Source("Vitibet", "https://www.vitibet.com/"),
        new Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        new Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        new Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        new Source("Statarea", "https://www.statarea.com/tips")
    );

    private LinearLayout results;
    private TextView status;
    private ProgressBar progress;
    private WebView scanner;
    private int sourceIndex = 0;
    private final List<Finding> findings = new ArrayList<>();
    private final Handler handler = new Handler();
    private boolean scanning = false;

    private final Pattern scorePattern = Pattern.compile("(?<!\\d)([0-9]{1,2})\\s*[-–:]\\s*([0-9]{1,2})(?!\\d)");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private TextView tv(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(18, 14, 18, 14);
        return t;
    }

    private void showHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 24, 22, 18);
        root.setBackgroundColor(Color.rgb(11,15,20));

        TextView title = tv("⚽ CIO SKOR", 28, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView sub = tv("16 kaynak • otomatik doğru skor taraması", 15, Color.LTGRAY);
        root.addView(sub);

        Button scan = new Button(this);
        scan.setText("🔄  BUGÜNÜ TARA");
        scan.setTextSize(17);
        scan.setOnClickListener(v -> startScan());
        root.addView(scan);

        status = tv("Hazır. Tarama başlatmak için butona bas.", 14, Color.LTGRAY);
        root.addView(status);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(sources.size());
        progress.setProgress(0);
        root.addView(progress, new LinearLayout.LayoutParams(-1, 12));

        ScrollView sv = new ScrollView(this);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setPadding(0, 12, 0, 0);
        sv.addView(results);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        scanner = new WebView(this);
        configureWebView(scanner);
        scanner.setVisibility(View.GONE);
        root.addView(scanner, new LinearLayout.LayoutParams(1,1));

        setContentView(root);
    }

    private void configureWebView(WebView w) {
        w.setWebViewClient(new WebViewClient());
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(false);
        s.setBlockNetworkImage(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36"
        );
    }

    private void startScan() {
        if (scanning) return;
        scanning = true;
        findings.clear();
        results.removeAllViews();
        sourceIndex = 0;
        progress.setProgress(0);
        status.setText("Tarama başlıyor...");
        scanNext();
    }

    private void scanNext() {
        if (sourceIndex >= sources.size()) {
            scanning = false;
            status.setText("✅ Tarama tamamlandı • " + findings.size() + " skor adayı bulundu");
            renderSummary();
            return;
        }

        final int idx = sourceIndex++;
        final Source src = sources.get(idx);
        status.setText("🌐 " + (idx + 1) + "/" + sources.size() + "  " + src.name + " okunuyor...");
        progress.setProgress(idx);

        scanner.stopLoading();
        scanner.loadUrl(src.url);

        // Sitelerin JS/anti-bot katmanlarının yüklenmesi için kontrollü bekleme.
        handler.postDelayed(() -> extractCurrentPage(src, 0), 5000);
    }

    private void extractCurrentPage(Source src, int retry) {
        if (!scanning) return;

        String js =
            "(function(){" +
            "return document.body ? document.body.innerText : '';" +
            "})()";

        scanner.evaluateJavascript(js, value -> {
            String text = decodeJsString(value);
            if (text.length() < 80 && retry < 2) {
                handler.postDelayed(() -> extractCurrentPage(src, retry + 1), 3000);
                return;
            }

            List<Finding> parsed = parseText(src.name, text);
            findings.addAll(parsed);

            TextView card = tv(
                sourceStatus(src.name, parsed, text),
                14,
                parsed.isEmpty() ? Color.rgb(255,190,90) : Color.WHITE
            );
            card.setBackgroundColor(Color.rgb(22,29,38));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 5, 0, 5);
            results.addView(card, lp);

            progress.setProgress(idx + 1);
            handler.postDelayed(this::scanNext, 400);
        });
    }

    private String decodeJsString(String value) {
        if (value == null) return "";
        String s = value;
        if (s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length()-1);
        return s.replace("\\n","\n").replace("\\r","\r").replace("\\t","\t")
                .replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private List<Finding> parseText(String source, String text) {
        List<Finding> out = new ArrayList<>();
        String[] lines = text.split("\\n");
        for (int i=0; i<lines.length && out.size()<25; i++) {
            String line = clean(lines[i]);
            if (line.length() < 3) continue;
            Matcher m = scorePattern.matcher(line);
            if (!m.find()) continue;

            String score = m.group(1) + "-" + m.group(2);
            String context = line.replace(m.group(0), " ").replaceAll("\\s+", " ").trim();

            if (context.length() < 4 && i > 0) {
                context = clean(lines[i-1]);
            }
            if (context.length() < 4 && i+1 < lines.length) {
                context = clean(lines[i+1]);
            }

            // Bariz tarih/saat/odds satırlarını at.
            if (looksLikeNoise(context)) continue;

            out.add(new Finding(source, context, score));
        }
        return out;
    }

    private String clean(String s) {
        return s.replace('\u00a0',' ').replaceAll("\\s+", " ").trim();
    }

    private boolean looksLikeNoise(String s) {
        String x = s.toLowerCase(Locale.ROOT);
        if (x.matches(".*\\b(19|20)\\d\\d[-/.]\\d\\d[-/.]\\d\\d\\b.*")) return true;
        if (x.matches(".*\\b\\d{1,2}:\\d{2}\\b.*") && s.length() < 35) return true;
        return x.matches("^(odds|oran|probability|probability:|chance|%|today|tomorrow).*$");
    }

    private String sourceStatus(String name, List<Finding> parsed, String raw) {
        if (parsed.isEmpty()) {
            if (raw.length() < 80) return "⚠️ " + name + " → sayfa okunamadı / boş cevap";
            return "⚠️ " + name + " → sayfa okundu fakat skor formatı bulunamadı";
        }
        StringBuilder b = new StringBuilder();
        b.append("✅ ").append(name).append(" → ").append(parsed.size()).append(" skor adayı");
        int n = Math.min(4, parsed.size());
        for (int i=0; i<n; i++) {
            Finding f = parsed.get(i);
            b.append("\n   ").append(f.score).append("  •  ").append(shorten(f.context, 72));
        }
        return b.toString();
    }

    private String shorten(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n-1) + "…";
    }

    private void renderSummary() {
        if (findings.isEmpty()) {
            TextView t = tv("❌ Hiçbir kaynak okunabilir skor döndürmedi.\nKaynakların WebView/anti-bot yapısını ayrı ayrı test etmemiz gerekiyor.", 15, Color.WHITE);
            results.addView(t);
            return;
        }

        TextView h = tv("🔥 TOPLAM SKOR KONSENSÜSÜ (ilk tarama)", 18, Color.WHITE);
        h.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        results.addView(h);

        Map<String,Integer> counts = new HashMap<>();
        for (Finding f : findings) counts.put(f.score, counts.getOrDefault(f.score,0)+1);

        List<Map.Entry<String,Integer>> list = new ArrayList<>(counts.entrySet());
        list.sort((a,b) -> Integer.compare(b.getValue(), a.getValue()));

        for (int i=0; i<Math.min(8,list.size()); i++) {
            Map.Entry<String,Integer> e = list.get(i);
            double pct = 100.0 * e.getValue() / findings.size();
            TextView t = tv(
                (i+1) + ". " + e.getKey() + " → " + e.getValue() +
                " kaynak adayı (" + String.format(Locale.US,"%.1f",pct) + "%)",
                15, Color.WHITE
            );
            results.addView(t);
        }

        TextView note = tv(
            "ℹ️ Bu ilk APK sürümü kaynak sayfalarını otomatik okuyup skor adaylarını çıkarır. " +
            "Takım eşleştirmesi kaynak bazında ayrıca doğrulanmadan skorlar aynı maça aitmiş gibi gösterilmez.",
            13, Color.LTGRAY
        );
        results.addView(note);
    }

    private void openSource(Source source) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        Button back = new Button(this);
        back.setText("← Kaynaklara dön");
        back.setOnClickListener(v -> showHome());
        box.addView(back, new LinearLayout.LayoutParams(-1, 58));

        WebView w = new WebView(this);
        configureWebView(w);
        box.addView(w, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(box);
        w.loadUrl(source.url);
    }

    @Override protected void onDestroy() {
        if (scanner != null) scanner.destroy();
        super.onDestroy();
    }
}
