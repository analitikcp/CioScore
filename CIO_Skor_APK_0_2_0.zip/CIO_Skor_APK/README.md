# CIO Skor APK 0.2.0

Bu sürümde:
- 16 kaynak korunur.
- BUGÜNÜ TARA her kaynağı sırayla WebView ile açar.
- JavaScript yüklendikten sonra sayfa metnini okur.
- 0-0, 1-2 gibi skor adaylarını çıkarır.
- Her kaynak için okunabildi / okunamadı durumunu gösterir.
- Bulunan skorlar için ilk konsensüs sayımını gösterir.
- API anahtarı ve Telegram bağımlılığı yoktur.
- Kaynakların anti-bot/JS yapıları nedeniyle okunamayanlar uydurulmaz.

Not: Takım eşleştirmesi kaynaklar arasında doğrulanmadan skorlar aynı maça ait kabul edilmez. Bu, yanlış konsensüs üretmemek için bilinçli bir güvenlik kuralıdır.
