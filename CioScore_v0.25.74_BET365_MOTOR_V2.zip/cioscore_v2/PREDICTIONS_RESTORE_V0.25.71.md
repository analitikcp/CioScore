# CioScore v0.25.71 — FOUR PREDICTIONS RESTORED

The four real prediction providers remain first-class card data: FP.com, PredictZ, WinDrawWin, DailySports.

A final source-union pass attaches already-parsed predictions to the correct fixture when provider kickoff metadata differs. It never invents a score. The card always renders four fixed source rows; missing source data is shown as `—`.

No AiScore data is used. No Bet365/bwin odds logic is changed.
