# Bet365 Motoru v2 — CioScore 0.25.74

## Amaç
Bet365 1X2 oranını yalnızca bir değer olarak değil, kaynağı ve teşhis durumu ile birlikte taşır.

## Kaynak sırası
1. API — Odds Data API: FI direct, ardından event odds history
2. Flashscore — doğrudan Bet365 satırı
3. Sofa — yalnızca SofaScore Bet365 provider endpoint'i
4. AiScore — açık Bet365 1X2 bloğu + takım/tarih doğrulaması
5. Cache — son doğrulanmış yerel Bet365 gözlemi; 12 saatten eski kayıt kullanılmaz

## UI
Her maç kartındaki Bet365 satırının altında:
- `Kaynak: API / Flashscore / Sofa / AiScore / Cache`
- `API ✓ / FS ✓ / Sofa ... / AI ... / Cache ...` durum özeti
- hiçbir kaynak başarılı değilse her kaynak için kısa hata nedeni

## Veri bütünlüğü
- Başka bookmaker oranı Bet365'e kopyalanmaz.
- Tam 1X2 olmadan kaynak başarılı sayılmaz.
- Cache yalnızca aynı takım + aynı kickoff anahtarıyla ve taze kayıtla kullanılır.
- API token/fixture eşleşme hatası kart üzerinde teşhis edilir.
