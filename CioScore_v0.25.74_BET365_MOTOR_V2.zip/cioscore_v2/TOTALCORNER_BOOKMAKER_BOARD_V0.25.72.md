# CioScore v0.25.72 — Multi-Bookmaker Odds Board

## Problem addressed
Bet365 and bwin could disappear because the app depended on brittle public/web feeds and a strict single-source display path.

## New source
Added `TotalCornerOddsService` as an independent football bookmaker board.

It uses TotalCorner's documented API endpoints:
- `/v1/match/schedule` for fixture discovery
- `/v1/match/bookmaker_odds/{match_id}` for bookmaker-specific odds

The feed preserves bookmaker identity and opening/closing/current 1X2 prices. It does not average, synthesize, or copy odds between bookmakers.

## Coverage target
The board can return Bet365, bwin, Pinnacle, William Hill, 1xBet, Betfair, Betsson, Interwetten and other bookmakers exposed by the provider.

## Waterfall
1. TotalCorner multi-bookmaker board when a TotalCorner token is configured.
2. Existing bwin TipsterArea parser.
3. Existing bwin Sports API.
4. Existing SofaScore bwin fallback.
5. Existing Bet365 chain remains independent: Odds Data API -> Flashscore -> SofaScore -> GoalLineExpert -> WinComparator -> local observation cache.

## UI
The existing API-token dialog now accepts both:
- Odds Data API token — Bet365 FI/history.
- TotalCorner API token — Bet365 + bwin + broad bookmaker board.

Main match cards keep Bet365/bwin and additionally expose major reference books (Pinnacle, William Hill, 1xBet, Betfair, Betsson, Interwetten) when returned by the board.

## Important limitation
No third-party service can guarantee 100% bookmaker coverage without a commercial feed and valid credentials. Bet365 has no public developer API; aggregator/API access is the reliable programmatic route. TotalCorner requires VIP membership/token for its API.
