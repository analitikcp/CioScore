package com.cio.skor.data

import android.content.Context

/**
 * Independent odds-panel pipeline.
 *
 * The main card odds and this panel deliberately have separate call paths.
 * The panel exposes official Iddaa, Bet365, and the independent TipsterArea
 * Standard 1X2 rows. New bureaus can be added here without changing
 * ScoreAdapter or the official prediction/verification pipeline.
 */
class OddsPanelService(context: Context) {
    data class OddsRow(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String,
        val primary: Boolean = false
    )

    private val aiScoreOdds = AiScoreOddsService()
    private val flashscoreOdds = FlashscoreOddsService()
    private val tipsterArea = TipsterAreaOddsService()

    suspend fun fetchTipsterArea(homeTeam: String, awayTeam: String, matchDate: String): List<OddsRow> =
        tipsterArea.fetch(homeTeam, awayTeam, matchDate).map {
            OddsRow(it.bookmaker, it.ms1, it.msX, it.ms2)
        }

    /**
     * AiScore is an independent Bet365 observation. It is never compared with
     * Flashscore and never rejected because Flashscore disagrees or is absent.
     */
    suspend fun fetchBet365FromAiScore(
        homeTeam: String,
        awayTeam: String,
        matchDate: String? = null
    ): OddsRow? = runCatching {
        aiScoreOdds.fetch(homeTeam, awayTeam, matchDate)
    }.getOrNull()?.let {
        OddsRow("Bet365 · AiScore", it.ms1, it.msX, it.ms2, primary = true)
    }

    /**
     * Flashscore is an independent Bet365 observation. It is never compared
     * with AiScore and never rejected because AiScore disagrees or is absent.
     */
    suspend fun fetchBet365FromFlashscore(
        homeTeam: String,
        awayTeam: String
    ): OddsRow? = runCatching {
        flashscoreOdds.fetchBookmakerOdds(homeTeam, awayTeam)
            .firstOrNull { it.bookmaker.contains("Bet365", ignoreCase = true) }
    }.getOrNull()?.let {
        OddsRow("Bet365 · Flashscore", it.ms1, it.msX, it.ms2)
    }

    /**
     * Backward-compatible single-source entry point. This intentionally uses
     * AiScore only; it is NOT a dual-source verification gate. New callers
     * should prefer fetchBet365FromAiScore/fetchBet365FromFlashscore so the
     * origin remains visible in the UI and analysis.
     */
    suspend fun fetchBet365(homeTeam: String, awayTeam: String, matchDate: String? = null): OddsRow? =
        fetchBet365FromAiScore(homeTeam, awayTeam, matchDate)

    fun iddaaRow(ms1: String?, msX: String?, ms2: String?): OddsRow? {
        if (ms1 == null && msX == null && ms2 == null) return null
        return OddsRow(
            bookmaker = "İddaa.com",
            ms1 = ms1 ?: "-",
            msX = msX ?: "-",
            ms2 = ms2 ?: "-"
        )
    }
}
