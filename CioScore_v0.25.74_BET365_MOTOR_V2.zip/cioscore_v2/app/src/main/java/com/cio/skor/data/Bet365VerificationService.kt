package com.cio.skor.data

/**
 * Legacy compatibility API.
 *
 * There is intentionally NO AiScore+Flashscore verification gate anymore.
 * Bet365 observations are source-specific. This legacy method returns the
 * AiScore observation only and keeps its provenance explicit.
 */
@Deprecated("Bet365 sources are independent; use AiScoreOddsService or FlashscoreOddsService")
class Bet365VerificationService {
    private val aiScore = AiScoreOddsService()

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        expectedDate: String? = null
    ): SofaScoreService.BookmakerOdds? =
        aiScore.fetch(homeTeam, awayTeam, expectedDate)?.let {
            SofaScoreService.BookmakerOdds(
                bookmaker = "Bet365 · AiScore",
                ms1 = it.ms1,
                msX = it.msX,
                ms2 = it.ms2
            )
        }
}
