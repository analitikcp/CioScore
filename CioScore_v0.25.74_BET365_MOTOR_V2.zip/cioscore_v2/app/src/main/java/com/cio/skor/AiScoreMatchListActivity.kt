package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.cio.skor.data.AiScoreMatch
import com.cio.skor.data.AiScoreRepository
import com.cio.skor.data.OddsDataApiService
import com.cio.skor.data.ProviderOddsHistoryStore
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.TeamAliasCanonicalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/**
 * AiScore-style match flow. It is intentionally a separate screen: the
 * existing CioScore prediction/Iddaa pipeline remains untouched.
 */
class AiScoreMatchListActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repository = AiScoreRepository()
    private lateinit var oddsApi: OddsDataApiService
    private lateinit var history: ProviderOddsHistoryStore
    private lateinit var listRoot: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private var matches: List<AiScoreMatch> = emptyList()
    private var officialPairs: List<AiScoreRepository.OfficialFixtureLite> = emptyList()
    private var providerFixtures: List<OddsDataApiService.ProviderFixture> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        oddsApi = OddsDataApiService(this)
        history = ProviderOddsHistoryStore(this)
        val homes = intent.getStringArrayListExtra(EXTRA_OFFICIAL_HOMES).orEmpty()
        val aways = intent.getStringArrayListExtra(EXTRA_OFFICIAL_AWAYS).orEmpty()
        officialPairs = homes.zip(aways).map { AiScoreRepository.OfficialFixtureLite(it.first, it.second) }
        setContentView(buildContent())
        load()
    }

    private fun buildContent(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF11161B.toInt())
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
            setBackgroundColor(0xFF20262D.toInt())
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(TextView(this).apply {
            text = "‹"
            textSize = 34f
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { finish() }
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        })
        titleRow.addView(TextView(this).apply {
            text = "AiScore Maç Listesi"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val apiButton = Button(this).apply {
            text = if (oddsApi.getToken().isBlank()) "API" else "✓ API"
            textSize = 11f
            setOnClickListener { showApiTokenDialog() }
            setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF374151.toInt())
        }
        titleRow.addView(apiButton, LinearLayout.LayoutParams(dp(58), dp(42)))
        val refresh = Button(this).apply {
            text = "↻"
            textSize = 18f
            setOnClickListener { load() }
            setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF374151.toInt())
        }
        titleRow.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(42)))
        header.addView(titleRow)
        header.addView(TextView(this).apply {
            text = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy, EEEE", Locale("tr", "TR")))
            textSize = 12f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "AiScore fikstürü • Bet365 1X2 • İddaa çapraz eşleşmesi"
            textSize = 11f
            setTextColor(0xFF94A3B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })
        root.addView(header)

        status = TextView(this).apply {
            text = "Maçlar yükleniyor…"
            textSize = 12f
            setTextColor(0xFFCBD5E1.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        root.addView(status)
        progress = ProgressBar(this).apply { isIndeterminate = true }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        val scroll = ScrollView(this).apply { isFillViewport = true }
        listRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(110))
        }
        scroll.addView(listRoot)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun load() {
        progress.visibility = View.VISIBLE
        status.text = if (oddsApi.getToken().isBlank()) {
            "AiScore fikstürü alınıyor • Odds Data API tokenı ayarlanmadı"
        } else {
            "AiScore + gerçek Bet365 fixture ID eşlemesi alınıyor…"
        }
        listRoot.removeAllViews()
        scope.launch {
            val loaded = withContext(Dispatchers.IO) { repository.fetchToday(officialPairs) }
            matches = loaded
            val providerResult = if (oddsApi.getToken().isBlank()) {
                null
            } else {
                oddsApi.findFixturesForDate(LocalDate.now())
            }
            providerFixtures = providerResult?.value.orEmpty()
            val mapped = loaded.map { match ->
                val kickoff = kickoffTimestamp(match.matchTime) / 1000L
                val provider = withContext(Dispatchers.Default) {
                    oddsApi.matchFixture(match.homeTeam, match.awayTeam, kickoff, providerFixtures)
                }
                match.copy(
                    providerEventId = provider?.eventId,
                    bet365FixtureId = provider?.bet365FixtureId
                )
            }
            matches = mapped
            progress.visibility = View.GONE
            if (loaded.isEmpty()) {
                status.text = "AiScore maç listesi alınamadı."
                listRoot.addView(message("AiScore sayfası erişilemez veya sayfa yapısı değişmiş olabilir."))
                return@launch
            }
            val matchedCount = mapped.count { it.providerEventId != null }
            status.text = if (oddsApi.getToken().isBlank()) {
                "${mapped.size} maç • API tokenı yok • Ayarlar için API butonuna basın"
            } else if (providerFixtures.isEmpty()) {
                "${mapped.size} maç • Odds Data API fixture listesi boş veya erişilemedi"
            } else {
                "${mapped.size} maç • $matchedCount fixture-ID eşleşti • Bet365 opening/closing API"
            }
            render(mapped)
        }
    }

    private fun render(items: List<AiScoreMatch>) {
        listRoot.removeAllViews()
        var lastLeague = ""
        items.forEach { match ->
            val league = match.leagueName.ifBlank { "AiScore" }
            if (league != lastLeague) {
                lastLeague = league
                listRoot.addView(TextView(this).apply {
                    text = "⚽ $league"
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFFFFC107.toInt())
                    setPadding(dp(8), dp(10), dp(8), dp(5))
                })
            }
            listRoot.addView(matchCard(match))
        }
    }

    private fun matchCard(match: AiScoreMatch): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xFF192027.toInt())
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(5)
            }
            setOnClickListener { showOdds(match) }
        }

        card.addView(TextView(this).apply {
            text = match.matchTime
            textSize = 12f
            setTextColor(0xFF9CA3AF.toInt())
            gravity = Gravity.TOP
            layoutParams = LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.WRAP_CONTENT)
        })

        val teams = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        teams.addView(teamText(match.homeTeam, true))
        teams.addView(teamText(match.awayTeam, false))
        if (match.iddaaMatched) teams.addView(TextView(this).apply {
            text = "✓ İDDAA eşleşti"
            textSize = 9f
            setTextColor(0xFF34D399.toInt())
        })
        card.addView(teams)

        val cached = match.providerEventId?.let { history.load(it) }
        val odds = TextView(this).apply {
            text = cached?.latestPreMatch?.let { "${it.home}\n${it.draw}\n${it.away}" } ?: "-\n-\n-"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(if (cached != null) 0xFF34D399.toInt() else 0xFFCBD5E1.toInt())
            tag = match.matchId
            layoutParams = LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        card.addView(odds)
        card.tag = match.matchId
        card.setOnLongClickListener {
            showOdds(match)
            true
        }
        return card
    }

    private fun teamText(name: String, bold: Boolean): TextView = TextView(this).apply {
        text = name
        textSize = 14f
        setTextColor(0xFFF1F5F9.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }


    private fun showOdds(match: AiScoreMatch) {
        val sheet = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(0xFFF8FAFC.toInt())
        }
        fun label(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(0xFF101828.toInt())
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
        root.addView(label("ORAN ANALİZİ", 20f, true))
        root.addView(label("${match.homeTeam}  -  ${match.awayTeam}", 14f, true))
        val fixture = match.providerEventId?.let { eventId ->
            providerFixtures.firstOrNull { it.eventId == eventId }
        }
        if (fixture == null) {
            root.addView(label("Odds Data API: bu maç için fixture-ID eşleşmesi bulunamadı.", 12f))
            root.addView(label("Takım adı + kickoff eşleşmesi güvenli olmadığı için oran çekilmedi.", 10f))
            sheet.setContentView(root)
            sheet.show()
            return
        }
        root.addView(label("Bet365 • FI ${fixture.bet365FixtureId} • Event ${fixture.eventId}", 11f))
        val loading = label("Gerçek Bet365 odds history yükleniyor…", 12f)
        root.addView(loading)
        sheet.setContentView(root)
        sheet.show()
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching { oddsApi.fetchOddsHistory(fixture) }.getOrNull()
            }
            if (!sheet.isShowing) return@launch
            root.removeView(loading)
            val historyResult = result?.value
            if (historyResult != null) {
                history.save(historyResult)
                val lineCount = historyResult.lines.size
                root.addView(label("Gerçek veri • $lineCount tarihsel 1X2 değişimi", 10f))
                addProviderOddsTable(root, historyResult)
            } else {
                root.addView(label("Bet365 history alınamadı: ${result?.error ?: "bilinmeyen hata"}", 12f))
            }
            root.addView(label("Açılış = sağlayıcının Bet365 history içindeki ilk pre-match kaydı. Kapanış = kickoff'tan önceki son kayıt. Son = aynı pre-match kapanış kaydı. Fixture ID ile saklanır; takım adına göre odds aranmaz.", 10f))
        }
    }


    private fun addProviderOddsTable(root: LinearLayout, h: OddsDataApiService.FixtureOddsHistory) {
        fun cell(text: String, weight: Float, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF344054.toInt())
            if (bold) setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        val table = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(cell("", 1.5f)); header.addView(cell("1", 1f, true)); header.addView(cell("X", 1f, true)); header.addView(cell("2", 1f, true))
        table.addView(header)
        fun row(title: String, line: OddsDataApiService.OddsLine?, tint: Int) {
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                background = GradientDrawable().apply { setColor(0xFFFFFFFF.toInt()); cornerRadius = dp(8).toFloat(); setStroke(dp(1), 0xFFE4E7EC.toInt()) }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(5) }
            }
            r.addView(cell(title, 1.5f, true).apply { setTextColor(tint) })
            r.addView(cell(line?.home ?: "-", 1f)); r.addView(cell(line?.draw ?: "-", 1f)); r.addView(cell(line?.away ?: "-", 1f))
            table.addView(r)
        }
        row("Açılış", h.opening, 0xFF2563EB.toInt())
        row("Kapanış", h.closing, 0xFF16A34A.toInt())
        root.addView(table)
        val times = listOfNotNull(
            h.opening?.let { "Açılış: ${formatEpoch(it.timestampSec)}" },
            h.closing?.let { "Kapanış: ${formatEpoch(it.timestampSec)}" }
        ).joinToString("  •  ")
        root.addView(TextView(this).apply { text = times; textSize = 10f; setTextColor(0xFF667085.toInt()); setPadding(0, dp(3), 0, dp(8)) })
    }

    private fun formatEpoch(epochSec: Long): String = Instant.ofEpochSecond(epochSec)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("dd.MM HH:mm:ss", Locale("tr", "TR")))


    private fun kickoffTimestamp(time: String): Long {
        val parts = time.split(':')
        if (parts.size != 2) return System.currentTimeMillis()
        val now = ZonedDateTime.now()
        return now.withHour(parts[0].toIntOrNull() ?: now.hour)
            .withMinute(parts[1].toIntOrNull() ?: now.minute)
            .withSecond(0).withNano(0)
            .toInstant().toEpochMilli()
    }

    private fun showApiTokenDialog() {
        val totalCorner = com.cio.skor.data.TotalCornerOddsService(applicationContext)
        val input = android.widget.EditText(this).apply {
            hint = "Odds Data API token (Bet365)"
            setSingleLine(true)
            setText(oddsApi.getToken())
        }
        val totalCornerInput = android.widget.EditText(this).apply {
            hint = "TotalCorner API token (Bet365 + Bwin + diğer bürolar)"
            setSingleLine(true)
            setText(totalCorner.getToken())
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
            addView(totalCornerInput)
            addView(TextView(this@AiScoreMatchListActivity).apply {
                text = "Odds Data API: Bet365 FI/history. TotalCorner: Bet365 + bwin + Pinnacle, William Hill, 1xBet, Betfair ve diğer bürolar; açılış/kapanış oranları."
                textSize = 10f
                setTextColor(0xFF667085.toInt())
                setPadding(0, dp(8), 0, 0)
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Gerçek Bet365 veri sağlayıcısı")
            .setMessage("Odds Data API tokenını girin. Uygulama event ID + Bet365 FI üzerinden gerçek odds history çekecek.")
            .setView(box)
            .setNegativeButton("İptal", null)
            .setNeutralButton("Tokenları Sil") { _, _ ->
                oddsApi.clearToken()
                totalCorner.clearToken()
                load()
            }
            .setPositiveButton("Kaydet") { _, _ ->
                oddsApi.setToken(input.text.toString())
                totalCorner.setToken(totalCornerInput.text.toString())
                load()
            }
            .show()
    }

    private fun message(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFFCBD5E1.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(40), dp(20), dp(40))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_OFFICIAL_HOMES = "AISCORE_OFFICIAL_HOMES"
        const val EXTRA_OFFICIAL_AWAYS = "AISCORE_OFFICIAL_AWAYS"
    }
}
