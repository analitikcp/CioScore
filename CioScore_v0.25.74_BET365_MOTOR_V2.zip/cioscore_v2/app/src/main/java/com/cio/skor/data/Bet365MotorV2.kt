package com.cio.skor.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Bet365 Motoru v2
 *
 * Every attempt is recorded with its own provenance. A Bet365 price is never
 * copied from another bookmaker and a source is never reported as successful
 * unless a complete 1X2 triple is present.
 */
class Bet365MotorV2(context: Context) {
    enum class Source { API, FLASHSCORE, SOFA, AISCORE, CACHE, NONE }

    data class Attempt(
        val source: Source,
        val ok: Boolean,
        val reason: String
    )

    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: Source = Source.NONE,
        val attempts: List<Attempt> = emptyList(),
        val history: OddsDataApiService.FixtureOddsHistory? = null
    )

    private val api = OddsDataApiService(context)
    private val sofa = SofaScoreService(context)
    private val flashscore = FlashscoreOddsService()
    private val aiScore = AiScoreOddsService()
    private val historyStore = Bet365OddsHistoryStore(context)
    private val providerHistory = ProviderOddsHistoryStore(context)

    suspend fun resolve(
        homeTeam: String,
        awayTeam: String,
        kickoffEpochSec: Long,
        displayDate: String,
        providerFixtures: List<OddsDataApiService.ProviderFixture>
    ): Result = withContext(Dispatchers.IO) {
        val attempts = mutableListOf<Attempt>()
        var history: OddsDataApiService.FixtureOddsHistory? = null

        fun hit(source: Source, odds: SofaScoreService.BookmakerOdds, reason: String): Result {
            attempts += Attempt(source, true, reason)
            history?.let { providerHistory.save(it) }
            history?.let { h ->
                Log.d(TAG, "HIT source=$source $homeTeam - $awayTeam odds=${odds.ms1}/${odds.msX}/${odds.ms2}")
            }
            historyStore.record(homeTeam, awayTeam, kickoffEpochSec, odds.ms1, odds.msX, odds.ms2)
            return Result(odds, source, attempts.toList(), history)
        }

        // 1) Odds Data API — direct FI first, then event history.
        run {
            if (api.getToken().isBlank()) {
                attempts += Attempt(Source.API, false, "API token ayarlanmadı")
            } else {
                val fixture = api.matchFixture(homeTeam, awayTeam, kickoffEpochSec, providerFixtures)
                if (fixture == null) {
                    attempts += Attempt(Source.API, false, "Bet365 fixture eşleşmedi (takım/saat)")
                } else {
                    val direct = api.fetchBet365Prematch(fixture)
                    if (direct.value != null && valid(direct.value.home, direct.value.draw, direct.value.away)) {
                        return@withContext hit(Source.API, SofaScoreService.BookmakerOdds("Bet365", direct.value.home, direct.value.draw, direct.value.away), "FI direct 1X2")
                    }
                    val directReason = direct.error ?: "FI 1X2 eksik"

                    val histResult = api.fetchOddsHistory(fixture)
                    history = histResult.value ?: providerHistory.load(fixture.eventId)
                    if (history != null) {
                        val line = history?.latestPreMatch ?: history?.closing
                        if (line != null && valid(line.home, line.draw, line.away)) {
                            return@withContext hit(Source.API, SofaScoreService.BookmakerOdds("Bet365", line.home, line.draw, line.away), "event history 1X2")
                        }
                    }
                    attempts += Attempt(Source.API, false, directReason + if (histResult.error != null) "; history: ${short(histResult.error)}" else "; history 1X2 yok")
                }
            }
        }

        // 2) Flashscore — direct Bet365 catalogue only.
        runCatching {
            flashscore.fetchBookmakerOdds(homeTeam, awayTeam)
                .firstOrNull { valid(it.ms1, it.msX, it.ms2) }
        }.onSuccess { row ->
            if (row != null) return@withContext hit(
                Source.FLASHSCORE,
                SofaScoreService.BookmakerOdds("Bet365", row.ms1, row.msX, row.ms2),
                "Flashscore Bet365 1X2"
            )
            attempts += Attempt(Source.FLASHSCORE, false, "Maç bulunduysa bile Bet365 1X2 satırı yok")
        }.onFailure { attempts += Attempt(Source.FLASHSCORE, false, "İstek/parse hatası: ${short(it.message)}") }

        // 3) SofaScore — deliberately call only the SofaScore provider path.
        runCatching {
            sofa.fetchBet365FromSofaScoreOnly(homeTeam, awayTeam)
        }.onSuccess { row ->
            if (row != null && valid(row.ms1, row.msX, row.ms2)) {
                return@withContext hit(Source.SOFA, row, "SofaScore Bet365 provider 1X2")
            }
            attempts += Attempt(Source.SOFA, false, "Bet365 provider veya tam 1X2 bulunamadı")
        }.onFailure { attempts += Attempt(Source.SOFA, false, "İstek/parse hatası: ${short(it.message)}") }

        // 4) AiScore — explicit Bet365 block only.
        runCatching {
            aiScore.fetch(homeTeam, awayTeam, displayDate)
        }.onSuccess { row ->
            if (row != null && valid(row.ms1, row.msX, row.ms2)) {
                return@withContext hit(Source.AISCORE, SofaScoreService.BookmakerOdds("Bet365", row.ms1, row.msX, row.ms2), "AiScore explicit Bet365 1X2")
            }
            attempts += Attempt(Source.AISCORE, false, "Kimlik/tarih/Bet365 1X2 doğrulaması başarısız")
        }.onFailure { attempts += Attempt(Source.AISCORE, false, "İstek/parse hatası: ${short(it.message)}") }

        // 5) Local cache — last real Bet365 observation only, age/identity checked by store.
        val cached = historyStore.get(homeTeam, awayTeam, kickoffEpochSec)
        val cacheFresh = cached?.latestCapturedAt?.let { System.currentTimeMillis() - it <= MAX_CACHE_AGE_MS } == true
        if (cached?.hasLatest() == true && cacheFresh && valid(cached.latestHome, cached.latestDraw, cached.latestAway)) {
            return@withContext hit(
                Source.CACHE,
                SofaScoreService.BookmakerOdds("Bet365", cached.latestHome!!, cached.latestDraw!!, cached.latestAway!!),
                "Son doğrulanmış Bet365 gözlemi"
            )
        }
        attempts += Attempt(
            Source.CACHE,
            false,
            if (cached?.hasLatest() == true) "Yerel kayıt eski veya 1X2 eksik" else "Kullanılabilir yerel Bet365 kaydı yok"
        )

        Result(null, Source.NONE, attempts, history)
    }

    private fun valid(a: String?, x: String?, b: String?): Boolean =
        a?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true &&
            x?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true &&
            b?.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true

    private fun short(value: String?): String = value?.replace(Regex("\\s+"), " ")?.trim()?.take(100).orEmpty().ifBlank { "bilinmeyen hata" }

    companion object {
        private const val TAG = "CioBet365MotorV2"
        private const val MAX_CACHE_AGE_MS = 12 * 60 * 60 * 1000L
    }
}
