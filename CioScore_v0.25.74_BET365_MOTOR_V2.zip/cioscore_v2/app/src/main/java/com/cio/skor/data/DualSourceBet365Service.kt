package com.cio.skor.data

/**
 * Legacy compatibility wrapper.
 *
 * IMPORTANT: AiScore and Flashscore are independent Bet365 data sources now.
 * This class is retained only for source compatibility with older callers; it
 * no longer compares the two feeds, applies a tolerance gate, or synthesizes
 * one price from both. The returned observation is from the requested primary
 * source only.
 */
@Deprecated("Use AiScoreOddsService and FlashscoreOddsService independently")
class DualSourceBet365Service {
    data class Odds(
        val ms1: String,
        val msX: String,
        val ms2: String,
        val source: String
    )

    private val aiScore = AiScoreOddsService()

    suspend fun fetch(homeTeam: String, awayTeam: String, expectedDate: String? = null): Odds? =
        aiScore.fetch(homeTeam, awayTeam, expectedDate)?.let {
            Odds(it.ms1, it.msX, it.ms2, source = "AiScore")
        }
}
