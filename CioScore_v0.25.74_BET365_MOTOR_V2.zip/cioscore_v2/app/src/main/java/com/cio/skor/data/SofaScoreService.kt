package com.cio.skor.data


import android.content.Context
import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.max

/**
 * Bet365 odds enrichment layer.
 *
 * The official score pipeline does not depend on bookmaker odds. For each card
 * we try several independent public sources and return only a complete Bet365
 * 1X2 row.
 */
class SofaScoreService(private val appContext: Context? = null) {
    data class Odds(val home: String, val draw: String, val away: String)

    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String,
        val league: String = "",
        val timestamp: Long = 0L
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String,
        val homeTeamId: Long?,
        val awayTeamId: Long?
    )

    private data class Provider(
        val id: Long,
        val name: String,
        val slug: String,
        val weight: Int = 0
    )

    private val http = HttpClient()
    private val flashscore = FlashscoreOddsService()
    private val goalLineExpert = GoalLineExpertBet365Service(appContext)
    private val winComparator = WinComparatorBet365Service(appContext)
    private val base = "https://api.sofascore.com/api/v1"

    /** Fetch Bet365 strictly from SofaScore provider data; no Flashscore/other fallback. */
    suspend fun fetchBet365FromSofaScoreOnly(homeTeam: String, awayTeam: String): BookmakerOdds? =
        withContext(Dispatchers.IO) {
            val events = loadNearbyEvents()
            val event = events.firstOrNull {
                oddsTeamsSame(it.home, homeTeam) && oddsTeamsSame(it.away, awayTeam)
            } ?: searchEventFallback(homeTeam, awayTeam)
                ?: return@withContext null

            val providers = loadProviders()
                .filter { it.name.contains("bet365", true) || it.slug.contains("bet365", true) }
                .distinctBy { it.id }
                .ifEmpty { listOf(Provider(1L, "Bet365", "bet365", 1000)) }

            coroutineScope {
                providers.take(4).map { provider ->
                    async(Dispatchers.IO) {
                        loadProviderOdds(event.id, provider.id)?.let { odds ->
                            BookmakerOdds("Bet365", odds.home, odds.draw, odds.away)
                        }
                    }
                }.awaitAll().filterNotNull().firstOrNull { isCompleteBet365(it) }
            }
        }

    /** Fetch one complete Bet365 1X2 row using layered public sources. */
    suspend fun fetchBookmakerOdds(homeTeam: String, awayTeam: String): List<BookmakerOdds> =
        withContext(Dispatchers.IO) {
            // Bet365-only pipeline. No Bwin/other bookmaker rows are allowed into
            // the card. We use several independent public sources and accept the
            // first complete Bet365 1X2 row.
            val errors = mutableListOf<String>()

            // 1) Fast public HTML fallback first.  GoalLineExpert publishes
            // Bet365 1X2 directly in server-rendered HTML; using it before
            // the heavyweight provider/event discovery prevents the card from
            // sitting on "..." while SofaScore/Flashscore enumerate feeds.
            runCatching { goalLineExpert.fetch(homeTeam, awayTeam) }
                .onFailure { errors += "GoalLineExpert:${it.javaClass.simpleName}" }
                .getOrNull()?.let { odds ->
                    Log.d("CioScoreOdds", "Bet365 HIT source=GoalLineExpert-FIRST match=$homeTeam - $awayTeam odds=${odds.ms1}/${odds.msX}/${odds.ms2}")
                    return@withContext listOf(BookmakerOdds("Bet365", odds.ms1, odds.msX, odds.ms2))
                }

            // 2) Existing SofaScore provider path.
            runCatching {
                val events = loadNearbyEvents()
                val event = events.firstOrNull {
                    oddsTeamsSame(it.home, homeTeam) && oddsTeamsSame(it.away, awayTeam)
                } ?: searchEventFallback(homeTeam, awayTeam)

                if (event != null) {
                    val bet365Providers = loadProviders()
                        .filter { it.name.contains("bet365", true) || it.slug.contains("bet365", true) }
                        .distinctBy { it.id }
                        .ifEmpty { listOf(Provider(1L, "Bet365", "bet365", 1000)) }

                    val fetched = coroutineScope {
                        bet365Providers.take(4).map { provider ->
                            async(Dispatchers.IO) {
                                loadProviderOdds(event.id, provider.id)?.let { odds ->
                                    BookmakerOdds("Bet365", odds.home, odds.draw, odds.away)
                                }
                            }
                        }.awaitAll().filterNotNull()
                    }
                    fetched.firstOrNull { isCompleteBet365(it) }?.let {
                        Log.d("CioScoreOdds", "Bet365 HIT source=SofaScore match=$homeTeam - $awayTeam odds=${it.ms1}/${it.msX}/${it.ms2}")
                        return@withContext listOf(it)
                    }
                }
            }.onFailure { errors += "SofaScore:${it.javaClass.simpleName}" }

            // 2) Existing Flashscore feed. This remains an independent direct
            // Bet365 source and is deliberately kept intact.
            runCatching {
                flashscore.fetchBookmakerOdds(homeTeam, awayTeam)
                    .map { BookmakerOdds("Bet365", it.ms1, it.msX, it.ms2) }
                    .firstOrNull { isCompleteBet365(it) }
            }.onFailure { errors += "Flashscore:${it.javaClass.simpleName}" }
                .getOrNull()?.let {
                    Log.d("CioScoreOdds", "Bet365 HIT source=Flashscore match=$homeTeam - $awayTeam odds=${it.ms1}/${it.msX}/${it.ms2}")
                    return@withContext listOf(it)
                }

            // 4) WinComparator public sitemap -> match page -> explicit Bet365 row.
            runCatching { winComparator.fetch(homeTeam, awayTeam) }
                .onFailure { errors += "WinComparator:${it.javaClass.simpleName}" }
                .getOrNull()?.let { odds ->
                    Log.d("CioScoreOdds", "Bet365 HIT source=WinComparator match=$homeTeam - $awayTeam odds=${odds.ms1}/${odds.msX}/${odds.ms2}")
                    return@withContext listOf(BookmakerOdds("Bet365", odds.ms1, odds.msX, odds.ms2))
                }

            if (errors.isNotEmpty()) Log.d("CioScoreOdds", "Bet365 all sources missed $homeTeam - $awayTeam: ${errors.joinToString()}")
            emptyList()
        }

    private fun isCompleteBet365(row: BookmakerOdds): Boolean =
        row.ms1.toDoubleOrNull()?.let { it > 1.0 } == true &&
            row.msX.toDoubleOrNull()?.let { it > 1.0 } == true &&
            row.ms2.toDoubleOrNull()?.let { it > 1.0 } == true

    private fun normalizeBookmaker(name: String): String =
        name.lowercase()
            .replace("★", "")
            .replace(Regex("[^a-z0-9]"), "")
            .replace("usa", "")

    /** Legacy helper retained for callers that only need a single 1X2 set. */
    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups
        val out = groups.toMutableList()
        groups.chunked(8).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val rows = fetchBookmakerOdds(group.homeTeam, group.awayTeam)
                    val first = rows.firstOrNull()
                    if (first == null) group else group.copy(
                        odds = Odds(first.ms1, first.msX, first.ms2)
                    )
                }
            }.awaitAll()
            val start = chunkIndex * 8
            results.forEachIndexed { index, value -> out[start + index] = value }
        }
        out
    }

    suspend fun enrichTeamIds(groups: List<MatchGroupData>): List<MatchGroupData> = withContext(Dispatchers.IO) {
        if (groups.isEmpty()) return@withContext groups
        val events = runCatching { loadNearbyEvents() }.getOrDefault(emptyList())
        if (events.isEmpty()) return@withContext groups
        groups.map { group ->
            runCatching {
                val event = events.firstOrNull {
                    MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                        MatchMerger.isSameTeam(it.away, group.awayTeam)
                }
                if (event == null) group else group.copy(
                    homeTeamId = event.homeTeamId,
                    awayTeamId = event.awayTeamId
                )
            }.getOrDefault(group)
        }
    }

    suspend fun resolveTeamId(teamName: String): Long? = withContext(Dispatchers.IO) {
        if (teamName.isBlank()) return@withContext null
        findTeamId(teamName)
    }

    /**
     * Return the team's latest finished fixtures. SofaScore exposes history in
     * pages, so one page is not enough for a reliable "last matches" panel.
     * We read a few pages, merge by event id/date/opponent/score, then keep the
     * newest 10 finished matches.
     */
    suspend fun getLastTenByTeamId(teamId: Long): List<RecentMatch> = withContext(Dispatchers.IO) {
        if (teamId <= 0L) return@withContext emptyList()

        val all = LinkedHashMap<String, RecentMatch>()
        for (page in 0..3) {
            val bodies = listOf(
                "$base/team/$teamId/events/last/$page",
                "https://www.sofascore.com/api/v1/team/$teamId/events/last/$page"
            )
            var parsed = emptyList<RecentMatch>()
            for (url in bodies) {
                val (code, body) = http.get(url, "https://www.sofascore.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue
                parsed = runCatching { parseRecentMatches(JSONObject(body), teamId) }
                    .getOrDefault(emptyList())
                if (parsed.isNotEmpty()) break
            }
            if (parsed.isEmpty()) break
            parsed.forEach { match ->
                val key = if (match.timestamp > 0L) {
                    "${match.timestamp}|${MatchMerger.normalizeTeamName(match.opponent)}|${match.score}"
                } else {
                    "${match.date}|${MatchMerger.normalizeTeamName(match.opponent)}|${match.score}"
                }
                all[key] = match
            }
            if (all.size >= 12) break
        }
        all.values
            .sortedByDescending { it.timestamp }
            .take(10)
    }

    private fun loadProviders(): List<Provider> {
        // SofaScore returns regional wrapper providers. Each wrapper may contain
        // an `oddsFrom` / `fallbackProvider` object whose id is the actual
        // provider id accepted by /event/{id}/odds/{providerId}/... .
        // We merge several regions so international books are not lost merely
        // because the Turkish catalogue happens to be returned first.
        val regions = listOf("INT", "US", "GB", "TR", "DE", "FR")
        val all = mutableListOf<Provider>()
        for (region in regions) {
            val url = "$base/odds/providers/$region/web"
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseProviders(body)?.let { all += it }
        }

        // Bet365's international odds-source id is stable and is the primary
        // fallback. Other providers are discovered from the live catalogue.
        if (all.none { it.id == 1L }) {
            all.add(Provider(1L, "Bet365", "bet365", 1000))
        }
        return all
            .distinctBy { it.id }
            .sortedByDescending { it.weight }
    }

    private fun parseProviders(body: String): List<Provider>? {
        return runCatching {
            val root = body.trim()
            val array = if (root.startsWith("[")) {
                JSONArray(root)
            } else {
                val obj = JSONObject(root)
                obj.optJSONArray("providers")
                    ?: obj.optJSONArray("data")
                    ?: obj.optJSONArray("items")
                    ?: return@runCatching emptyList()
            }
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue

                    // Common current shape:
                    // { provider:{...}, fallbackProvider:{id:1,name:"bet365"}, ... }
                    val wrapper = item.optJSONObject("provider")
                    val fallback = item.optJSONObject("fallbackProvider")
                    val oddsFrom = wrapper?.optJSONObject("oddsFrom")
                    val liveOddsFrom = wrapper?.optJSONObject("liveOddsFrom")

                    val candidates = listOfNotNull(
                        fallback,
                        oddsFrom,
                        liveOddsFrom,
                        wrapper,
                        item
                    )
                    val source = candidates.firstOrNull { it.optLong("id", -1L) > 0L } ?: continue
                    val id = source.optLong("id", -1L)
                    val name = source.optString("name").trim()
                        .ifBlank { wrapper?.optString("name")?.trim().orEmpty() }
                        .ifBlank { item.optString("name").trim() }
                    val slug = source.optString("slug").trim()
                        .ifBlank { wrapper?.optString("slug")?.trim().orEmpty() }
                    val weight = item.optInt("weight", wrapper?.optInt("weight", 0) ?: 0)
                    if (id > 0L && name.isNotBlank()) {
                        add(Provider(id, name, slug, weight))
                    }
                }
            }
        }.getOrNull()
    }

    private fun loadProviderOdds(eventId: Long, providerId: Long): Odds? {
        val paths = listOf(
            "$base/event/$eventId/odds/$providerId/featured",
            "$base/event/$eventId/odds/$providerId/all"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseOdds(JSONObject(body))?.let { return it }
        }
        return null
    }

    /**
     * Odds lookup identity is intentionally provider-local. SofaScore commonly
     * labels the same official fixture as `Barcelona W`, `Barcelona (W)` or
     * `Barcelona`, while the Iddaa side may use `(K)`. Spain lower divisions
     * also commonly add/remove the `UE` club prefix. The global matcher remains
     * untouched; this only prevents an otherwise valid odds lookup from dying
     * before the provider request is made.
     */
    private fun oddsTeamKey(value: String): String =
        MatchMerger.normalizeTeamName(value)
            .lowercase()
            .replace("'", "")
            .split(Regex("\\s+"))
            .filterNot { it in setOf(
                "k", "w", "f", "women", "woman", "womens", "female", "fem",
                "ladies", "ue", "fc", "cf", "afc", "sc", "ac", "as", "sk", "cd"
            ) }
            .joinToString("")

    private fun oddsTeamsSame(actual: String, wanted: String): Boolean {
        if (MatchMerger.isSameTeam(actual, wanted)) return true
        val a = oddsTeamKey(actual)
        val b = oddsTeamKey(wanted)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        // Allow harmless provider suffixes/prefixes, but only when the shorter
        // identity is substantial enough to avoid broad city-name collisions.
        return (a.length >= 7 && b.length >= 7) && (a.contains(b) || b.contains(a))
    }

    private fun loadNearbyEvents(): List<EventRef> {
        val today = LocalDate.now(KickoffNormalizer.ZONE)
        val dates = listOf(today.minusDays(1), today, today.plusDays(1), today.plusDays(2))
        return dates.flatMap { date -> loadEventsForDate(date) }.distinctBy { it.id }
    }

    private fun searchEventFallback(homeTeam: String, awayTeam: String): EventRef? {
        val query = java.net.URLEncoder.encode("$homeTeam $awayTeam", Charsets.UTF_8.name())
        val urls = listOf(
            "$base/search/events/?q=$query&page=0",
            "$base/search/events?q=$query&page=0"
        )
        for (url in urls) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            runCatching {
                val results = JSONObject(body).optJSONArray("results") ?: return@runCatching null
                for (i in 0 until results.length()) {
                    val item = results.optJSONObject(i) ?: continue
                    val event = item.optJSONObject("event") ?: item.optJSONObject("entity") ?: item
                    val home = event.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = event.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = event.optLong("id", -1L)
                    if (id > 0 && oddsTeamsSame(home, homeTeam) && oddsTeamsSame(away, awayTeam)) {
                        val homeId = event.optJSONObject("homeTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                        val awayId = event.optJSONObject("awayTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                        return EventRef(id, home, away, homeId, awayId)
                    }
                }
                null
            }.getOrNull()?.let { return it }
        }
        return null
    }

    private fun loadEventsForDate(date: LocalDate): List<EventRef> {
        val (code, body) = http.get(
            "$base/sport/football/scheduled-events/$date",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    val homeId = e.optJSONObject("homeTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                    val awayId = e.optJSONObject("awayTeam")?.optLong("id", -1L)?.let { if (it > 0) it else null }
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) {
                        add(EventRef(id, home, away, homeId, awayId))
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseOdds(root: JSONObject): Odds? {
        fun readChoices(value: JSONObject): Odds? {
            val choices = value.optJSONArray("choices") ?: return null
            var one: String? = null
            var draw: String? = null
            var two: String? = null
            for (i in 0 until choices.length()) {
                val c = choices.optJSONObject(i) ?: continue
                val name = c.optString("name").trim().uppercase()
                val decimal = c.opt("decimalValue")?.toString()?.toDoubleOrNull()
                    ?: fractionalToDecimal(c.optString("fractionalValue"))
                if (decimal == null || decimal <= 1.0 || decimal > 100.0) continue
                val formatted = String.format(java.util.Locale.US, "%.2f", decimal)
                when (name) {
                    "1", "HOME" -> one = formatted
                    "X", "DRAW" -> draw = formatted
                    "2", "AWAY" -> two = formatted
                }
            }
            return if (one != null && draw != null && two != null) Odds(one!!, draw!!, two!!) else null
        }

        // Prefer the featured full-time 1X2 market. Current SofaScore responses
        // have used both `default` and `fullTime`, so inspect every featured
        // market object instead of relying on one fixed key.
        root.optJSONObject("featured")?.let { featured ->
            val keys = featured.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val market = featured.optJSONObject(key) ?: continue
                val marketId = market.optInt("marketId", -1)
                val marketName = market.optString("marketName").lowercase()
                if (marketId == 1 || marketName.contains("full time") || key.equals("default", true) || key.equals("fullTime", true)) {
                    readChoices(market)?.let { return it }
                }
            }
        }
        root.optJSONObject("odds")?.let { nested ->
            parseOdds(nested)?.let { return it }
        }
        root.optJSONArray("markets")?.let { markets ->
            for (i in 0 until markets.length()) {
                val market = markets.optJSONObject(i) ?: continue
                val marketId = market.optInt("marketId", -1)
                val name = market.optString("marketName").lowercase()
                if (marketId == 1 || name.contains("full time") || name == "1x2") {
                    readChoices(market)?.let { return it }
                }
            }
        }
        return null
    }

    private fun fractionalToDecimal(value: String): Double? {
        val parts = value.trim().split('/')
        if (parts.size != 2) return null
        val numerator = parts[0].toDoubleOrNull() ?: return null
        val denominator = parts[1].toDoubleOrNull() ?: return null
        if (denominator == 0.0) return null
        return 1.0 + numerator / denominator
    }

    private fun findTeamId(teamName: String): Long? {
        val cleanQuery = teamName
            .replace(Regex("\\s+"), " ")
            .trim()
            .removeSuffix(" GO")
            .removeSuffix(" CE")
        val queries = listOf(teamName.trim(), cleanQuery).distinct().filter { it.isNotBlank() }

        var bestId: Long? = null
        var bestScore = -1.0
        for (q in queries) {
            val encoded = java.net.URLEncoder.encode(q, Charsets.UTF_8.name())
            val urls = listOf(
                "$base/search/all?q=$encoded",
                "https://www.sofascore.com/api/v1/search/all?q=$encoded"
            )
            for (url in urls) {
                val (code, body) = http.get(url, "https://www.sofascore.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue
                runCatching {
                    val results = JSONObject(body).optJSONArray("results") ?: return@runCatching
                    for (i in 0 until results.length()) {
                        val item = results.optJSONObject(i) ?: continue
                        val entityType = item.optString("type").lowercase()
                        if (entityType.isNotBlank() && entityType != "team") continue
                        val entity = item.optJSONObject("entity") ?: continue
                        val id = entity.optLong("id", -1L)
                        val name = entity.optString("name").trim()
                        if (id <= 0 || name.isBlank()) continue
                        val score = when {
                            MatchMerger.isSameTeam(name, teamName) -> 1.0
                            MatchMerger.isSameTeam(name, cleanQuery) -> 0.99
                            else -> teamSimilarity(name, teamName)
                        }
                        if (score > bestScore) {
                            bestScore = score
                            bestId = id
                        }
                    }
                }
                if (bestScore >= 0.99) return bestId
            }
        }
        return bestId?.takeIf { bestScore >= 0.78 }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(KickoffNormalizer.ZONE).toLocalDate().toString()
            } else ""
            val league = e.optJSONObject("tournament")?.optString("name").orEmpty()
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result, league, timestamp)
        }
        return out.sortedByDescending { it.timestamp }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null,
        val homeTeamId: Long? = null,
        val awayTeamId: Long? = null
    )
}
