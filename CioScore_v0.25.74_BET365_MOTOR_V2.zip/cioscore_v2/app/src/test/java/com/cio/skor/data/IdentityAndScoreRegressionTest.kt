package com.cio.skor.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityAndScoreRegressionTest {
    @Test fun teamAliasesResolveKnownVariants() {
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Man Utd") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("VfL Bochum", "Bochum") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("FSV Mainz 05", "Mainz") >= 0.80)
    }

    @Test fun seniorAndYouthTeamsDoNotCollapse() {
        assertFalse(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Manchester United U21") >= 0.95)
    }

    @Test fun renderableScoreContractRejectsTextualAndPartialValues() {
        assertTrue(ScoreModel.hasRenderablePrediction("1-0"))
        assertTrue(ScoreModel.hasRenderablePrediction(" 2 : 2 "))
        assertFalse(ScoreModel.hasRenderablePrediction("Home win"))
        assertFalse(ScoreModel.hasRenderablePrediction("1-"))
        assertFalse(ScoreModel.hasRenderablePrediction("TBD"))
    }
    @Test fun fourPredictionProvidersCollapseIntoOneFixtureWithFourPredictions() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", kickoff),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", kickoff),
            ScoreModel("Manchester United", "Liverpool FC", "2:0", "WinDrawWin", "wdw-1", kickoff),
            ScoreModel("Man United", "Liverpool", "1-0", "DailySports", "ds-1", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("All four prediction providers must form one fixture", unified.size == 1)
        assertTrue("The unified fixture must retain all four prediction sources", unified.single().predictions.size == 4)
        assertTrue(unified.single().predictions.map { it.first }.toSet().containsAll(
            setOf("FP.com", "PredictZ", "WinDrawWin", "DailySports")
        ))
    }

    @Test fun sameTeamsOnDifferentDatesRemainSeparateFixtures() {
        val dayOne = 1_800_000_000_000L
        val dayTwo = dayOne + 24L * 60L * 60L * 1000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", dayOne),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", dayTwo)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Different fixture dates must not collapse", unified.size == 2)
    }

    @Test fun predictionRemainsVisibleWhenNoIddaaFixtureExists() {
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "FP.com", "fp-1", 1_800_000_000_000L),
            ScoreModel("Arsenal", "Chelsea", "1-0", "PredictZ", "pz-1", 1_800_000_000_000L)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Prediction-first data must survive without an Iddaa match", unified.size == 1)
        assertTrue(unified.single().predictions.size == 2)
        assertTrue(unified.single().officialMatch == null)
    }

}

class IndependentBet365SourceRegressionTest {
    @org.junit.Test
    fun aiScoreAndFlashscore_are_independent_sources_not_a_verification_gate() {
        val ai = AiScoreOddsService.Odds("2.10", "3.20", "3.40")
        val flash = FlashscoreOddsService.BookmakerOdds("Bet365", "2.35", "3.05", "3.10")

        // Deliberately disagreeing prices must remain valid as two observations.
        org.junit.Assert.assertNotEquals(ai.ms1, flash.ms1)
        org.junit.Assert.assertEquals("AiScore", ai.source)
        org.junit.Assert.assertEquals("Bet365", flash.bookmaker)
    }
}
