# CioScore v0.25.73 — Bet365 display fix

## Root cause
The current Odds Data API response format changed in September 2026. The Bet365 pre-match endpoint now returns `results` as an array and labels 1X2 selections with `name` (`1`, `Draw`, `2`). The app expected an object and the old `header` field, so valid Bet365 responses were parsed as missing and the UI remained `...`.

## Fixes
- Accept both current and legacy `results` response shapes.
- Parse Bet365 1X2 selection labels from `name`, with `header` retained as compatibility fallback.
- Preload provider fixtures for yesterday/today/tomorrow so post-midnight fixtures can receive FI-based Bet365 odds.
- Add AiScore as an independent final public Bet365 fallback before local cache.
- No odds are synthesized, averaged, or copied from another bookmaker.
