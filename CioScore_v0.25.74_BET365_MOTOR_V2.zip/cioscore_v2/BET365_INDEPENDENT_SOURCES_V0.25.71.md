# CioScore v0.25.71 — Bet365 Independent Sources

AiScore and Flashscore are independent Bet365 data sources. They are not a
verification pair and their prices are never compared, averaged, or mutually
required.

- AiScore can provide a Bet365 observation even when Flashscore is unavailable.
- Flashscore can provide a Bet365 observation even when AiScore is unavailable.
- If both are present and disagree, both observations remain valid and are
  preserved separately for analysis.
- Provenance is explicit: `Bet365 · AiScore` and `Bet365 · Flashscore`.
- TotalCorner remains an independent broad bookmaker source and may expose a
  third Bet365 observation.
- The legacy dual-source classes are deprecated compatibility wrappers only;
  they no longer implement a dual-source verification gate.
