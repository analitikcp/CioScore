package com.cio.skor.ui

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SofaScoreService

/** One card per unified match; score-analysis sources are displayed as fixed filter labels. */
data class MatchGroup(
    /** True only when this prediction group was successfully matched to an official İddaa bulletin fixture. */
    val isIddaaBulletinMatch: Boolean = false,
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    // Resmi İddaa 1X2 oranları; external odds alanı kullanılmaz.
    val iddaaMs1: String? = null,
    val iddaaMsX: String? = null,
    val iddaaMs2: String? = null,
    val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
    val hasHtFt: Boolean = false,
    /** Verified public Iddaa bulletin URL for this fixture's bulletin day. */
    val iddaaProgramUrl: String? = null,
    val homeTeamId: Long? = null,
    val awayTeamId: Long? = null,
    val matchTimestamp: Long = 0L,
    val displayTime: String = "--:--",
    val displayDate: String = ""
)

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String, Long?) -> Unit = { _, _ -> },
    private val onHtFtClick: (String, String) -> Unit = { _, _ -> },
    private val onExternalOddsRequest: (String, String) -> Unit = { _, _ -> },
    private val onOddsClick: (MatchGroup) -> Unit = {}
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private fun hasRenderablePrediction(match: MatchGroup): Boolean =
        match.predictions.any { ScoreModel.hasRenderablePrediction(it.predictedScore) }

    enum class BulletinFilter {
        IDDAA_BULLETIN,
        OTHER_MATCHES
    }

    private var fullList: List<MatchGroup> = initialList.filter(::hasRenderablePrediction)
    private var displayedList: List<MatchGroup> = fullList
    private var currentQuery = ""
    private var bulletinFilter = BulletinFilter.IDDAA_BULLETIN

    fun setBulletinFilter(filter: BulletinFilter) {
        bulletinFilter = filter
        refreshDisplayed()
    }

    fun getBulletinFilter(): BulletinFilter = bulletinFilter

    private val externalOddsCache =
        mutableMapOf<String, List<SofaScoreService.BookmakerOdds>>()
    private val externalOddsLoading = mutableSetOf<String>()

    private fun oddsKey(home: String, away: String): String =
        "${MatchMerger.normalizeTeamName(home)}::${MatchMerger.normalizeTeamName(away)}"

    fun setExternalOdds(
        homeTeam: String,
        awayTeam: String,
        rows: List<SofaScoreService.BookmakerOdds>
    ) {
        val key = oddsKey(homeTeam, awayTeam)
        externalOddsCache[key] = rows.filter { it.bookmaker.contains("Bet365", true) }
        externalOddsLoading.remove(key)
        val index = displayedList.indexOfFirst {
            oddsKey(it.homeTeam, it.awayTeam) == key
        }
        if (index >= 0) notifyItemChanged(index)
    }

    // Large official bulletins can contain dozens of cards. Rendering every
    // dynamically-built card in one main-thread frame can trigger an Android
    // ANR even though RecyclerView recycles holders. Keep the full list intact
    // but publish it to RecyclerView in small main-thread batches.
    private val mainHandler = Handler(Looper.getMainLooper())
    private var renderGeneration = 0
    private val renderBatchSize = 12
    private var pendingRender: Runnable? = null

    fun submitList(newList: List<MatchGroup>) {
        // Hard UI safety gate: cards without a real prediction never enter the
        // adapter, so the fallback text "TAHMİN YOK" cannot become a visible card.
        fullList = newList.filter(::hasRenderablePrediction)
        refreshDisplayed()
    }


    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        val categoryList = when (bulletinFilter) {
            BulletinFilter.IDDAA_BULLETIN -> fullList.filter { it.isIddaaBulletinMatch }
            BulletinFilter.OTHER_MATCHES -> fullList.filter { !it.isIddaaBulletinMatch }
        }
        val list = if (q.isEmpty()) categoryList else categoryList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        renderIncrementally(list)
    }

    private fun renderIncrementally(target: List<MatchGroup>) {
        pendingRender?.let(mainHandler::removeCallbacks)
        pendingRender = null
        val generation = ++renderGeneration

        if (target.isEmpty()) {
            displayedList = emptyList()
            notifyDataSetChanged()
            return
        }

        displayedList = target.take(renderBatchSize)
        notifyDataSetChanged()

        var shown = displayedList.size
        if (shown >= target.size) return

        val step = object : Runnable {
            override fun run() {
                if (generation != renderGeneration) return
                val next = (shown + renderBatchSize).coerceAtMost(target.size)
                displayedList = target.subList(0, next)
                shown = next
                notifyDataSetChanged()
                if (shown < target.size) {
                    mainHandler.postDelayed(this, 16L)
                } else {
                    pendingRender = null
                }
            }
        }
        pendingRender = step
        mainHandler.postDelayed(step, 16L)
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    /** Focus the main list on one exact fixture using canonical team identity. */
    fun focusOnMatch(homeTeam: String, awayTeam: String? = null) {
        // HT/FT official names and main-card names can differ slightly
        // (e.g. city/suffix/language variants). Use the same canonical
        // identity layer as the global fixture engine instead of requiring
        // literal canonical IDs to be identical.
        val candidates = fullList.filter { match ->
            val sameHome = MatchMerger.isSameTeam(match.homeTeam, homeTeam)
            val sameAway = awayTeam.isNullOrBlank() ||
                MatchMerger.isSameTeam(match.awayTeam, awayTeam)
            sameHome && sameAway
        }

        val focused = if (candidates.isNotEmpty()) {
            candidates
        } else {
            // Safe fallback: if the away name was rendered differently by a
            // source, locate the home side rather than leaving the screen empty.
            fullList.filter { MatchMerger.isSameTeam(it.homeTeam, homeTeam) }
        }
        renderIncrementally(focused)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val ctx = parent.context

        // Kart: yükseklik kesinlikle WRAP_CONTENT.
        val card = LinearLayout(ctx).apply {

            orientation = LinearLayout.VERTICAL

            layoutParams =
                RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val horizontal = dp(ctx, 8)
                    val vertical = dp(ctx, 6)
                    setMargins(
                        horizontal,
                        vertical,
                        horizontal,
                        vertical
                    )
                }

            val padding = dp(ctx, 10)
            setPadding(
                padding,
                padding,
                padding,
                padding
            )

            background =
                GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(ctx, 14).toFloat()
                    setStroke(
                        dp(ctx, 1),
                        0xFFE7EAF0.toInt()
                    )
                }

            elevation = dp(ctx, 3).toFloat()

            clipChildren = false
            clipToPadding = false
        }

        return VH(card)
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.card.removeAllViews()
        holder.card.isClickable = true
        holder.card.isFocusable = true
        holder.card.setOnClickListener {
            // Card click opens the home team history as a reliable fallback.
            onTeamClick(match.homeTeam, match.homeTeamId)
        }

        // ------------------------------------------------
        // MAÇ TARİHİ + BAŞLAMA SAATİ
        // İddaa eşleşmiş olsa da olmasa da kart kendi maç tarih/saatini gösterir.
        // 06:00 bülten kuralı burada uygulanmaz; yalnızca gösterim bilgisidir.
        // ------------------------------------------------
        val displayDate = match.displayDate.trim().ifBlank {
            if (match.matchTimestamp > 0L) {
                runCatching {
                    Instant.ofEpochMilli(match.matchTimestamp)
                        .atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                }.getOrDefault("")
            } else ""
        }
        val displayTime = match.displayTime.trim().ifBlank { "--:--" }
        holder.card.addView(TextView(ctx).apply {
            text = when {
                displayDate.isNotBlank() && displayTime != "--:--" -> "📅 $displayDate   •   🕐 $displayTime"
                displayDate.isNotBlank() -> "📅 $displayDate"
                else -> "🕐 $displayTime"
            }
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 5) }
        })

        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam, match.homeTeamId) }
                isClickable = true
                isFocusable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam, match.awayTeamId) }
                isClickable = true
                isFocusable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.card.addView(teams)

        // ------------------------------------------------
        // BAĞIMSIZ ORANLAR PANELİ — ilk ZIP mantığı
        // Bilerek ana kart oranlarının ÜSTÜNDE tutulur; kullanıcı her
        // maçta ORANLAR butonunu doğrudan görebilir. Panel ayrı çağrı
        // zinciri kullanır ve ana kart oranlarını etkilemez.
        // ------------------------------------------------
        val oddsButton = TextView(ctx).apply {
            // Mavi dolgu kaldırıldı: ORANLAR işlevi korunuyor, görsel olarak
            // ana kartın geri kalanına uyumlu sade bir metin/aksiyon haline geliyor.
            text = "📊 ORANLAR"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF344054.toInt())
            background = null
            setPadding(dp(ctx, 8), dp(ctx, 4), dp(ctx, 8), dp(ctx, 4))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(ctx, 6)
                bottomMargin = dp(ctx, 4)
            }
            isClickable = true
            isFocusable = true
            contentDescription = "${match.homeTeam} - ${match.awayTeam} oranlarını aç"
            setOnClickListener { onOddsClick(match) }
        }
        holder.card.addView(oddsButton)

        // ------------------------------------------------
        // ORANLAR — doğrudan maç kartında.
        // Veri kaynağı eski çalışan SofaScoreService.fetchBookmakerOdds()
        // zinciridir; burada yalnızca sonuç kart içine taşınır.
        // ------------------------------------------------
        val oddsTable = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), 0)
        }

        fun oddsCell(value: String, weight: Float, bold: Boolean = false): TextView =
            TextView(ctx).apply {
                text = value
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (bold) 0xFF155EEF.toInt() else 0xFF344054.toInt())
                if (bold) setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, weight
                )
                setPadding(dp(ctx, 2), dp(ctx, 5), dp(ctx, 2), dp(ctx, 5))
            }

        fun addOddsRow(name: String, ms1: String, msX: String, ms2: String, primary: Boolean) {
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(if (primary) 0xFFF0FDF4.toInt() else 0xFFF8FAFC.toInt())
                    cornerRadius = dp(ctx, 8).toFloat()
                    setStroke(dp(ctx, 1), if (primary) 0xFFBBE7CA.toInt() else 0xFFE4E7EC.toInt())
                }
                setPadding(dp(ctx, 4), 0, dp(ctx, 4), 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(ctx, 4) }
            }
            row.addView(oddsCell(name, 1.35f, false))
            row.addView(oddsCell(ms1, 1f, true))
            row.addView(oddsCell(msX, 1f, true))
            row.addView(oddsCell(ms2, 1f, true))
            oddsTable.addView(row)
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(oddsCell("", 1.35f))
        header.addView(oddsCell("MS1", 1f))
        header.addView(oddsCell("MSX", 1f))
        header.addView(oddsCell("MS2", 1f))
        oddsTable.addView(header)

        addOddsRow(
            "🇹🇷 İddaa",
            match.iddaaMs1 ?: "-",
            match.iddaaMsX ?: "-",
            match.iddaaMs2 ?: "-",
            false
        )

        val key = oddsKey(match.homeTeam, match.awayTeam)
        val cachedBet365 = externalOddsCache[key].orEmpty()
            .firstOrNull()

        if (cachedBet365 != null) {
            addOddsRow(
                "🌍 Bet365",
                cachedBet365.ms1,
                cachedBet365.msX,
                cachedBet365.ms2,
                true
            )
        } else {
            addOddsRow("🌍 Bet365", "…", "…", "…", true)
            if (externalOddsLoading.add(key)) {
                onExternalOddsRequest(match.homeTeam, match.awayTeam)
            }
        }

        holder.card.addView(oddsTable)

        // ------------------------------------------------
        // RESMİ IDDAA BÜLTENİ LİNKİ
        // İddaa'nın resmi programı herkese açık bülten URL'sidir.
        // Resmi event ID -> web detay URL eşlemesi güvenilir biçimde
        // doğrulanmadığı için sahte/yanlış bir maç URL'si üretmiyoruz.
        // Bunun yerine kullanıcıyı resmi futbol bültenine götürüyoruz.
        // ------------------------------------------------
        val iddaaButton = TextView(ctx).apply {
            text = "↗ İDDAA BÜLTENİNDE AÇ"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF00796B.toInt())
            background = GradientDrawable().apply {
                setColor(0xFFEAF7F4.toInt())
                cornerRadius = dp(ctx, 10).toFloat()
                setStroke(dp(ctx, 1), 0xFFB7E4DB.toInt())
            }
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = dp(ctx, 8)
                bottomMargin = dp(ctx, 2)
            }
            isClickable = true
            isFocusable = true
            contentDescription = "${match.homeTeam} - ${match.awayTeam} maçını resmi İddaa bülteninde aç"
            setOnClickListener {
                val intent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.iddaa.com/program/futbol?msg=1")
                )
                runCatching { ctx.startActivity(intent) }
            }
        }
        holder.card.addView(iddaaButton)

        // ------------------------------------------------
        // SADE TAHMİN — yalnızca MS 1 / MS X / MS 2
        // Yalnızca sonuç tahmini gösterilir: MS 1 / MS X / MS 2.
        // ------------------------------------------------
        val outcomeCounts = match.predictions
            .mapNotNull { predictionOutcome(it.predictedScore) }
            .groupingBy { it }
            .eachCount()
        val analysisOutcome = outcomeCounts
            .maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            ?.key

        val predictionRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 7) }
        }

        // A card without a renderable prediction is filtered before binding.
        // Never render a "TAHMİN YOK" fallback; that text masked upstream data loss.
        if (analysisOutcome != null) {
            predictionRow.addView(TextView(ctx).apply {
                text = "TAHMİN: ${when (analysisOutcome) {
                    "1" -> "MS 1"
                    "X" -> "MS X"
                    "2" -> "MS 2"
                    else -> ""
                }}"
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(0xFF00796B.toInt())
            })
            holder.card.addView(predictionRow)
        }

        // ------------------------------------------------
        // HT/FT AÇIK BUTONU — oranlar ana kartta gösterilmez.
        // Kullanıcı butona basınca ayrı HT/FT ekranında resmi 9
        // kombinasyon açılır.
        // ------------------------------------------------
        if (match.hasHtFt || match.htFtOdds.isNotEmpty()) {
            val htFtButton = TextView(ctx).apply {
                text = "⚡ HT/FT AÇIK"
                textSize = 11f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                background = GradientDrawable().apply {
                    setColor(0xFF00796B.toInt())
                    cornerRadius = dp(ctx, 10).toFloat()
                }
                setPadding(dp(ctx, 14), dp(ctx, 7), dp(ctx, 14), dp(ctx, 7))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    topMargin = dp(ctx, 7)
                    bottomMargin = dp(ctx, 2)
                }
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    onHtFtClick(match.homeTeam, match.awayTeam)
                }
            }
            holder.card.addView(htFtButton)
        }

        // ------------------------------------------------
        // SKOR ANALİZ FİLTRELERİ
        // ------------------------------------------------
        // Her kaynak ekranda sabit ve kullanıcı dostu isimle görünür.
        // Kaynak adı/URL kullanıcı arayüzüne sızmaz.
        val sourceOrder = listOf(
            "fp.com" to "Skor Analiz Filtre1",
            "predictz" to "Skor Analiz Filtre2",
            "windrawwin" to "Skor Analiz Filtre3",
            "dailysports" to "Skor Analiz Filtre4",
        )
        val orderedPredictions = sourceOrder.mapNotNull { (sourceKey, label) ->
            match.predictions.firstOrNull { prediction ->
                prediction.source.trim().lowercase().contains(sourceKey)
            }?.let { prediction -> label to prediction.predictedScore }
        }

        if (orderedPredictions.isNotEmpty()) {
            holder.card.addView(View(ctx).apply {
                setBackgroundColor(0xFFE5E7EB.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 1)
                ).apply {
                    topMargin = dp(ctx, 8)
                    bottomMargin = dp(ctx, 3)
                }
            })

            orderedPredictions.forEach { (label, score) ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = dp(ctx, 2)
                        bottomMargin = dp(ctx, 2)
                    }
                }

                row.addView(TextView(ctx).apply {
                    text = label
                    textSize = 11f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })

                row.addView(TextView(ctx).apply {
                    text = "→ $score"
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    gravity = Gravity.END
                })

                holder.card.addView(row)
            }
        }

    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 13f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun predictionOutcome(score: String): String? {
        if (!ScoreModel.hasRenderablePrediction(score)) return null
        val match = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
