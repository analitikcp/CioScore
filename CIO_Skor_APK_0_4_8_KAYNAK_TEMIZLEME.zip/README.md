# CIO Score 0.4.8

16 kaynakli Android skor tarama uygulamasi. 0.4.7 calisan tarama altyapisindan ilerler; kaynak bazli cikti temizleme/parser katmani eklenmistir.

Bu surum:
- FP.com, FootballPredictions.net, Forebet, PredictZ ve WinDrawWin icin ayri parsing kurallari kullanir.
- Diger kaynaklarda Correct Score / Predicted Score / Scoreline etiketlerini onceliklendirir.
- Tarih, saat, oran, yuzde, Avg Goals, Best Leagues, Results vb. gürültüyü filtreler.
- HTTP/SSL erisim hatalarini skor olarak kabul etmez.
