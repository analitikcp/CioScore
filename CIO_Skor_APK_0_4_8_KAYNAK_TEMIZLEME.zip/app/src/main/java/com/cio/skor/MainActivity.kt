package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Result(val name: String, val code: Int, val matches: List<String>, val error: String? = null)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button
    private lateinit var statusText: TextView

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/all-games/all-stakes/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    private val scorePattern = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        // Uygulama açılır açılmaz gerçek taramayı başlat.
        window.decorView.postDelayed({ scanAll() }, 500)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 11, 16))
            setPadding(22, 24, 22, 16)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 12)
        }
        root.addView(sub)

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 17f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(Color.rgb(55, 65, 75), 12)
            setPadding(12, 0, 12, 0)
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 58))

        statusText = TextView(this).apply {
            text = "Hazır • tarama otomatik başlayacak"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 8)
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInitialRows()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        sources.forEachIndexed { index, s ->
            resultBox.addView(row("${index + 1}. ${s.name}", "⏳ Bekliyor..."))
        }
    }

    private fun scanAll() {
        scanButton.isEnabled = false
        scanButton.text = "⏳  16 KAYNAK TARANIYOR..."
        scanButton.background = rounded(Color.rgb(40, 48, 56), 12)
        statusText.text = "🌐 16 kaynak paralel taranıyor..."
        resultBox.removeAllViews()

        val rows = HashMap<String, TextView>()
        sources.forEachIndexed { index, source ->
            val r = row("${index + 1}. ${source.name}", "⏳ Bağlanıyor...")
            rows[source.name] = r.getChildAt(1) as TextView
            resultBox.addView(r)
        }

        val done = AtomicInteger(0)
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                runOnUiThread {
                    rows[source.name]?.let { detail ->
                        detail.text = formatResult(result)
                        detail.setTextColor(when {
                            result.matches.isNotEmpty() -> Color.rgb(75, 225, 135)
                            result.code in 400..599 -> Color.rgb(255, 95, 95)
                            else -> Color.rgb(255, 195, 75)
                        })
                    }
                    val n = done.incrementAndGet()
                    statusText.text = "📊 Tarama: $n/${sources.size} tamamlandı"
                    if (n == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                        scanButton.background = rounded(Color.rgb(40, 115, 65), 12)
                        statusText.text = "✅ 16 kaynak taraması tamamlandı"
                    }
                }
            }
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(24, 31, 39))
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 5, 0, 0)
        }
        box.addView(t)
        box.addView(d)
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 3, 0, 3) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        currentSource.set(source.name)
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 18000
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code • erişilemedi")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "HTTP $code • boş HTML")
            val matches = extractMatches(html)
            Result(source.name, code, matches)
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), "${e.javaClass.simpleName} • ${e.message ?: "bağlantı hatası"}")
        } finally {
            connection?.disconnect()
            currentSource.remove()
        }
    }

    private fun extractMatches(html: String): List<String> {
        val doc = Jsoup.parse(html)
        val found = LinkedHashSet<String>()

        when (currentSourceName) {
            "FP.com" -> parseFpCom(doc, found)
            "FootballPredictions.net" -> parseFpNet(doc, found)
            "Forebet" -> parseForebet(doc, found)
            "PredictZ" -> parsePredictZ(doc, found)
            "WinDrawWin" -> parseWinDrawWin(doc, found)
            "BettingTipsToday" -> parseLabeledScoreCards(doc, found)
            "SoccerSeer" -> parseLabeledScoreCards(doc, found)
            "MightyTips" -> parseLabeledScoreCards(doc, found)
            "FootyStats" -> parseLabeledScoreCards(doc, found)
            "GoalVertex" -> parseLabeledScoreCards(doc, found)
            "NerdyTips" -> parseLabeledScoreCards(doc, found)
            "Vitibet" -> parseLabeledScoreCards(doc, found)
            "HuhSports" -> parseLabeledScoreCards(doc, found)
            "FootballAnt" -> parseLabeledScoreCards(doc, found)
            "DailySports" -> parseLabeledScoreCards(doc, found)
            "Statarea" -> parseStatarea(doc, found)
            else -> parseGeneric(doc, found)
        }

        return found.take(12)
    }

    // fetchAndParse() çağrısı sırasında hangi kaynak işlendiğini taşımak için ThreadLocal kullanıyoruz.
    private val currentSource = ThreadLocal<String?>()
    private val currentSourceName: String
        get() = currentSource.get() ?: ""

    private fun parseFpCom(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // FP.com sayfası Match | Correct Score Tip | Odds | Probability tablosu kullanıyor.
        for (tr in doc.select("table tr")) {
            val cells = tr.select("th,td")
            if (cells.size < 2) continue
            val row = cells.joinToString(" ") { it.text() }.replace(Regex("\\s+"), " ").trim()
            val score = findBestScore(row) ?: continue
            val teamPart = row.substringBefore(score).trim()
            val clean = cleanTeamPair(teamPart)
            if (clean != null) found.add("$clean → $score")
            if (found.size >= 12) return
        }
        parseLabeledScoreCards(doc, found)
    }

    private fun parseFpNet(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // FP.net kartlarında tarih/saatten hemen önce takım adları, sonrasında skor bulunuyor.
        for (el in doc.select("article,li,tr,a,[class*=match],[class*=fixture],[class*=prediction]")) {
            val raw = normalize(el.text())
            if (raw.length !in 8..350) continue
            val date = Regex("\\b20\\d{2}-\\d{2}-\\d{2}(?:\\s+\\d{2}:\\d{2}:\\d{2})?").find(raw)
            val score = findLastScore(raw) ?: continue
            val beforeDate = date?.let { raw.substring(0, it.range.first) } ?: raw.substringBefore(score)
            val clean = cleanTeamPair(beforeDate)
            if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            if (found.size >= 12) return
        }
    }

    private fun parseForebet(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // Forebet kartlarında takım adları ve Pred/score alanları aynı kartta bulunur.
        for (el in doc.select("div,article,tr,li")) {
            val raw = normalize(el.text())
            if (raw.length !in 8..300) continue
            if (!Regex("\\b(?:Pred|Prediction|Correct Score|Score)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) continue
            val score = findBestScore(raw) ?: continue
            val clean = cleanTeamPair(raw.substringBefore(score))
            if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            if (found.size >= 12) return
        }
    }

    private fun parsePredictZ(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // PredictZ'de "Team A v Team B" ve ardından "X-Y Correct Score Odds" bulunur.
        val text = normalize(doc.text())
        val rx = Regex("([^|]{2,90}?)\\s+v\\s+([^|]{2,90}?)\\s+(?:Analysis|Correct Score Odds|Correct Score)", RegexOption.IGNORE_CASE)
        for (m in rx.findAll(text)) {
            val pair = cleanTeamPair("${m.groupValues[1]} - ${m.groupValues[2]}") ?: continue
            val after = text.substring(m.range.last + 1, minOf(text.length, m.range.last + 180))
            val score = findBestScore(after) ?: continue
            found.add("$pair → $score")
            if (found.size >= 12) return
        }
        // Daha güvenli fallback: başlığı ve Correct Score Odds bloğunu birlikte ara.
        for (el in doc.select("article,div,li,tr")) {
            val raw = normalize(el.text())
            if (!raw.contains("Correct Score", true)) continue
            val pair = Regex("([A-Za-zÀ-ÿ0-9.'’&() ]{2,60})\\s+v\\s+([A-Za-zÀ-ÿ0-9.'’&() ]{2,60})", RegexOption.IGNORE_CASE).find(raw)
            val score = findBestScore(raw) ?: continue
            if (pair != null) {
                val clean = cleanTeamPair("${pair.groupValues[1]} - ${pair.groupValues[2]}")
                if (clean != null) found.add("$clean → $score")
            }
            if (found.size >= 12) return
        }
    }

    private fun parseWinDrawWin(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // WDW sonuç/lig tablolarındaki geçmiş skorları alma. Sadece prediction/tips kartlarını hedefle.
        for (el in doc.select("article,li,tr,div[class*=prediction],div[class*=tip],div[class*=match]")) {
            val raw = normalize(el.text())
            if (raw.length !in 8..280) continue
            if (Regex("\\b(?:prediction|predicted|tips?|correct score|today)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) {
                val score = findBestScore(raw) ?: continue
                val clean = cleanTeamPair(raw.substringBefore(score))
                if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            }
            if (found.size >= 12) return
        }
    }

    private fun parseStatarea(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // Statarea'da "X - Y" biçimli maç satırlarını ve tahmin skorunu aynı kartta ara.
        for (el in doc.select("tr,article,li,div[class*=match],div[class*=game],div[class*=tip]")) {
            val raw = normalize(el.text())
            if (raw.length !in 8..300) continue
            val score = findBestScore(raw) ?: continue
            val clean = cleanTeamPair(raw.substringBefore(score))
            if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            if (found.size >= 12) return
        }
    }

    private fun parseLabeledScoreCards(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        // Kaynaklarda Correct Score / Predicted Score / Scoreline etiketini içeren kartları tercih et.
        val selectors = "article,li,tr,div[class*=match],div[class*=fixture],div[class*=prediction],div[class*=score],div[class*=event],a"
        for (el in doc.select(selectors)) {
            val raw = normalize(el.text())
            if (raw.length !in 8..360) continue
            if (!Regex("\\b(?:correct score|predicted score|predicted scoreline|prediction score|scoreline|exact score|predicted)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) continue
            val score = findBestScore(raw) ?: continue
            val clean = cleanTeamPair(extractTeamRegion(raw, score))
            if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            if (found.size >= 12) return
        }
        // Etiket yoksa yalnızca takım ayırıcılarını içeren kısa kartları dene.
        if (found.isEmpty()) {
            for (el in doc.select("article,li,tr,div[class*=match],div[class*=fixture],a")) {
                val raw = normalize(el.text())
                if (raw.length !in 8..180) continue
                val score = findBestScore(raw) ?: continue
                val clean = cleanTeamPair(extractTeamRegion(raw, score))
                if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
                if (found.size >= 12) return
            }
        }
    }

    private fun parseGeneric(doc: org.jsoup.nodes.Document, found: LinkedHashSet<String>) {
        for (el in doc.select("tr,article,li,a,[class*=match],[class*=fixture],[class*=prediction],[class*=score]")) {
            val raw = normalize(el.text())
            if (raw.length !in 8..250) continue
            val score = findBestScore(raw) ?: continue
            val clean = cleanTeamPair(extractTeamRegion(raw, score))
            if (clean != null && !looksLikeNoise(clean)) found.add("$clean → $score")
            if (found.size >= 12) return
        }
    }

    private fun findBestScore(text: String): String? {
        val candidates = scorePattern.findAll(text).map { "${it.groupValues[1]}-${it.groupValues[2]}" }.toList()
        if (candidates.isEmpty()) return null
        // En yakın skor etiketi olan veya son tahmin skorunu tercih et.
        val preferred = Regex("(?:correct score|predicted score|scoreline|exact score|prediction)\\D{0,80}([0-5])\\s*[-:]\\s*([0-5])", RegexOption.IGNORE_CASE).find(text)
        return preferred?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: candidates.last()
    }

    private fun findLastScore(text: String): String? = scorePattern.findAll(text).lastOrNull()?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun extractTeamRegion(raw: String, score: String): String {
        var t = raw.substringBefore(score)
        t = t.replace(Regex("\\b20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}(?:[ ,T]+\\d{1,2}:\\d{2}(?::\\d{2})?)?\\b"), " ")
        t = t.replace(Regex("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b"), " ")
        t = t.replace(Regex("\\b\\d+(?:\\.\\d+)?%\\b"), " ")
        return t
    }

    private fun cleanTeamPair(raw: String): String? {
        var t = normalize(raw)
        t = t.replace(Regex("\\b(?:correct score|predicted score|predicted scoreline|prediction score|scoreline|exact score|prediction|predictions|preview|analysis|odds|avg\\.? goals?|best|likely|second likely|other likely outcomes|home|away|draw)\\b.*$", RegexOption.IGNORE_CASE), " ")
        t = t.replace(Regex("\\b20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}(?:[ ,T]+\\d{1,2}:\\d{2}(?::\\d{2})?)?\\b"), " ")
        t = t.replace(Regex("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b"), " ")
        t = t.replace(Regex("\\b\\d+(?:\\.\\d+)?%\\b"), " ")
        t = t.replace(Regex("\\b(?:19|20)\\d{2}\\b"), " ")
        t = t.replace(Regex("\\b\\d+(?:\\.\\d+)?\\b"), " ")
        t = t.replace(Regex("[|→»]+"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', '–', '—', ':', ',', ';', '.')

        val parts = t.split(Regex("\\s+(?:vs?\\.?|versus|v\\.)\\s+|\\s+[–—-]\\s+|\\s+@\\s+|\\s+→\\s+"), limit = 2)
        if (parts.size == 2) {
            val a = cleanTeamName(parts[0])
            val b = cleanTeamName(parts[1])
            if (a != null && b != null) return "$a - $b".take(100)
        }

        // Birçok kart takım adlarını yan yana verir; kalan metin kısa ve harf ağırlıklıysa kabul et.
        val fallback = cleanTeamName(t)
        return fallback?.take(100)
    }

    private fun cleanTeamName(s: String): String? {
        var t = normalize(s)
        t = t.replace(Regex("^[^A-Za-zÀ-ÿ0-9]+|[^A-Za-zÀ-ÿ0-9)]+$"), "")
        if (t.length < 2 || t.length > 90) return null
        val lower = t.lowercase()
        val bad = listOf("preview", "analysis", "correct score", "prediction", "odds", "avg goals", "best leagues", "results", "http", "www.")
        if (bad.any { lower.contains(it) }) return null
        if (t.count { it.isLetter() } < 3) return null
        return t
    }

    private fun normalize(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    private fun looksLikeNoise(text: String): Boolean {
        val lower = text.lowercase()
        if (text.length < 4) return true
        val bad = listOf("http", "www.", "sslhandshake", "trust anchor", "avg goals", "likely correct", "best leagues", "results", "prediction odds")
        if (bad.any { lower.contains(it) }) return true
        val digits = text.count { it.isDigit() }
        return digits > text.length / 3
    }

    private fun formatResult(r: Result): String {
        if (r.error != null) return "❌ ${r.error}"
        if (r.matches.isEmpty()) return "⚠️ HTTP ${r.code} • HTML geldi, parser 0 maç"
        return "✅ HTTP ${r.code} • ${r.matches.joinToString("\n")}" 
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
