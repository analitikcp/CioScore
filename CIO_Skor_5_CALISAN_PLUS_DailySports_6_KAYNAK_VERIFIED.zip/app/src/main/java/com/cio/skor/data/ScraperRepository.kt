package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    // Five-source working base + the independently verified DailySports parser.
    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips", FootballPredictionsNetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    // DailySports has a browser-rendered fallback in MainActivity when HTTP parsing yields 0.
                    if (source.name == "DailySports") {
                        onProgress(index + 1, source.name)
                        val (code, html) = http.get(source.url)
                        val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                            source.parser.parse(Jsoup.parse(html, source.url))
                        } else emptyList()
                        SourceResult(source.name, code, scores, null)
                    } else {
                        val (code, html) = http.get(source.url)
                        val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                            source.parser.parse(Jsoup.parse(html, source.url))
                        } else emptyList()
                        onProgress(index + 1, source.name)
                        SourceResult(source.name, code, scores, null)
                    }
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
