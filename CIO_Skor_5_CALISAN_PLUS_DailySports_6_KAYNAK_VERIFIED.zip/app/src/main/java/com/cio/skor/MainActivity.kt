package com.cio.skor

import android.app.Activity
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import android.webkit.WebResourceRequest
import android.webkit.WebChromeClient
import android.webkit.ConsoleMessage
import android.util.Log
import com.cio.skor.data.SourceResult
import kotlinx.coroutines.isActive
import kotlin.coroutines.resume
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE • 6 KAYNAK"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread { status.text = "⏳ $n/${repo.sourceCount} • $name" }
                }
            }.toMutableList()

            val ds = results.firstOrNull { it.source == "DailySports" }
            if (ds != null && ds.scores.none(::isDisplayable)) {
                status.text = "🌐 DailySports web sayfası açılıyor…"
                val webResult = loadDailySportsWithWebView()
                val idx = results.indexOfFirst { it.source == "DailySports" }
                if (idx >= 0) results[idx] = webResult
            }

            showResults(results)
        }
    }

    private suspend fun loadDailySportsWithWebView(): SourceResult =
        kotlin.coroutines.suspendCoroutine { cont ->
            runOnUiThread {
                val web = WebView(this@MainActivity)
                val root = findViewById<LinearLayout>(100)
                root.addView(web, LinearLayout.LayoutParams(2, 2))

                web.settings.javaScriptEnabled = true
                web.settings.domStorageEnabled = true
                web.settings.databaseEnabled = true
                web.settings.loadsImagesAutomatically = false
                web.settings.userAgentString =
                    "Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
                web.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                        Log.d("DailySportsJS", consoleMessage.message())
                        return true
                    }
                }

                val targetUrl = "https://dailysports.net/mathematical-predictions/correct-score/"
                var finished = false

                fun cleanup() {
                    try { root.removeView(web) } catch (_: Exception) {}
                    try { web.stopLoading(); web.destroy() } catch (_: Exception) {}
                }

                fun finish(scores: List<ScoreModel>, reason: String, httpCode: Int = 200) {
                    if (finished) return
                    finished = true
                    cleanup()
                    Log.d("DailySportsWebView", "result scores=${scores.size} reason=$reason")
                    runOnUiThread { status.text = "🌐 DailySports: ${scores.size} skor bulundu ($reason)" }
                    cont.resume(SourceResult("DailySports", httpCode, scores, if (scores.isEmpty()) reason else null))
                }

                fun parseJson(value: String?, reason: String) {
                    if (finished) return
                    val raw = try { org.json.JSONTokener(value ?: "null").nextValue() as? String } catch (_: Exception) { null }
                    if (raw.isNullOrBlank()) { finish(emptyList(), reason); return }
                    try {
                        val arr = org.json.JSONArray(raw)
                        val scores = ArrayList<ScoreModel>()
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            val home = o.optString("home").trim()
                            val away = o.optString("away").trim()
                            val score = o.optString("score").trim()
                            if (home.isNotBlank() && away.isNotBlank() && score.matches(Regex("[0-5]-[0-5]"))) {
                                scores.add(ScoreModel(home, away, score, "DailySports"))
                            }
                        }
                        finish(scores.distinctBy { "${it.homeTeam}|${it.awayTeam}|${it.predictedScore}" }, reason)
                    } catch (e: Exception) {
                        Log.e("DailySportsWebView", "JSON parse failed", e)
                        finish(emptyList(), "JSON parse error: ${e.javaClass.simpleName}")
                    }
                }

                val js = """
                    (function(){
                      const out=[]; const seen=new Set();
                      const scoreRe=/Prediction\s+Correct\s+Score\s*:\s*([0-5])\s*[:\-]\s*([0-5])/i;
                      const all=[...document.querySelectorAll('body *')];
                      for(const el of all){
                        const t=(el.innerText||'').replace(/\s+/g,' ').trim();
                        if(!/Prediction\s+Correct\s+Score/i.test(t)) continue;
                        const m=t.match(scoreRe); if(!m) continue;
                        let card=el;
                        for(let n=0;n<10 && card;n++,card=card.parentElement){
                          const imgs=[...card.querySelectorAll('img[alt]')].map(x=>(x.getAttribute('alt')||'').trim()).filter(x=>x.length>=2);
                          const links=[...card.querySelectorAll('a')].map(x=>(x.innerText||'').replace(/\s+/g,' ').trim()).filter(x=>x.length>=2);
                          const teams=[...new Set(imgs.concat(links))].filter(x=>!/^image$/i.test(x) && !/^(game|prediction|correct score|today|tomorrow|show all)$/i.test(x));
                          if(teams.length>=2){
                            const home=teams[0], away=teams[1], score=m[1]+'-'+m[2];
                            const key=home+'|'+away+'|'+score;
                            if(!seen.has(key)){seen.add(key);out.push({home,away,score});}
                            break;
                          }
                        }
                      }
                      return JSON.stringify(out.slice(0,500));
                    })();
                """.trimIndent()

                fun readRenderedDom(reason: String) {
                    if (finished) return
                    web.evaluateJavascript(js) { value -> parseJson(value, reason) }
                }

                web.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        Log.d("DailySportsWebView", "pageFinished url=$url title=${view.title.orEmpty()}")
                        view.postDelayed({ readRenderedDom("DOM 2.5s") }, 2500L)
                        view.postDelayed({ readRenderedDom("DOM 6s") }, 6000L)
                    }
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u=request.url.toString()
                        if (u.contains("api", true) || u.contains("json", true) || u.contains("stat", true)) {
                            Log.d("DailySportsNET", "WEBVIEW REQUEST $u")
                        }
                        return super.shouldInterceptRequest(view, request)
                    }
                    override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                        if (request.isForMainFrame) Log.e("DailySportsWebView", "HTTP ${errorResponse.statusCode} ${errorResponse.reasonPhrase}")
                    }
                    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                        if (request.isForMainFrame) {
                            Log.e("DailySportsWebView", "main frame error ${error.errorCode}: ${error.description}")
                            view.postDelayed({ readRenderedDom("WebView hata ${error.errorCode}") }, 500L)
                        }
                    }
                }

                web.postDelayed({ readRenderedDom("WebView timeout") }, 12000L)
                web.loadUrl(targetUrl)
            }
        }

    private fun showResults(results: List<SourceResult>) {
        val scores = results.flatMap { it.scores }
            .filter(::isDisplayable)
            .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }
        val goodSources = results.filter { it.scores.any(::isDisplayable) }.map { it.source }
        val groups = groupMatches(scores)
        adapter.update(groups)
        val diagnostics = results.joinToString("\n") { r ->
            val state = if (r.scores.any(::isDisplayable)) "OK" else "0 skor"
            "${r.source}: HTTP ${r.httpCode}, ${r.scores.count(::isDisplayable)} skor ($state)"
        }
        status.text = "✅ ${goodSources.size}/${repo.sourceCount} kaynak • ${scores.size} temiz skor\n⚽ ${groups.size} farklı maç\n\n$diagnostics"
    }

    /**
     * Same match = same normalized home + normalized away team.
     * We deliberately keep home/away order so a reversed fixture is not merged.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        val groups = LinkedHashMap<String, MutableList<ScoreModel>>()

        for (score in scores) {
            val key = "${canonicalTeam(score.homeTeam)}|${canonicalTeam(score.awayTeam)}"
            groups.getOrPut(key) { mutableListOf() }.add(score)
        }

        return groups.values.map { list ->
            val ordered = list.distinctBy { it.source }
            MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    /** Normalize accents, punctuation and common club suffixes for cross-source matching. */
    private fun canonicalTeam(value: String): String {
        var s = value.trim().lowercase()
        s = s.replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")

        // Common suffixes that differ between prediction sites.
        val suffixes = listOf("footballclub", "soccerclub", "club", "fc", "fk", "cf", "sc", "afc")
        var changed = true
        while (changed) {
            changed = false
            for (suffix in suffixes) {
                if (s.endsWith(suffix) && s.length > suffix.length + 2) {
                    s = s.removeSuffix(suffix)
                    changed = true
                    break
                }
            }
        }
        return s
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
