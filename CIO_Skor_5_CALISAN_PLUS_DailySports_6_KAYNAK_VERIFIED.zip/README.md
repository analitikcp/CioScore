CIO Score 0.10.2 - 5 working sources + independently verified DailySports.

Base: user-provided CIO_Skor_APK_0_8_7_SOCCERSEER_OLD_WORKING_PARSER(1).zip.
DailySports code: user-tested isolated build that returned 51 scores, merged without adding the other 9 sources.
Sources: FP.com, FootballPredictions.net, PredictZ, WinDrawWin, SoccerSeer, DailySports.
