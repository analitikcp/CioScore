package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Official Iddaa sportsbook feed.
 *
 * Source: official Iddaa football program and its first-party sportsbook feed.
 * Program page: https://www.iddaa.com/program/futbol
 * The official events feed returns event-level markets in JSON; market-config
 * maps (t, st) to official market metadata. HT/FT is identified from the
 * 9 official outcome labels and normalized to 1/1..2/2. No third-party odds
 * source is used.
 */
class IddaaMarketService {
    data class OpenedMarketMatch(
        val matchId: String,
        val homeTeam: String,
        val awayTeam: String,
        val matchTimestamp: Long = 0L,
        val matchTime: String = "--:--",
        val matchDate: String = "",
        val ms1: String? = null,
        val msX: String? = null,
        val ms2: String? = null,
        val hasHtFt: Boolean = false,
        val htFtOdds: LinkedHashMap<String, String> = linkedMapOf()
    ) {
        val hasMatchResult: Boolean get() = ms1 != null || msX != null || ms2 != null
    }

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val marketMatches: Int,
        val httpEvents: Int,
        val httpMarketConfig: Int,
        val error: String? = null
    )

    private data class MarketConfig(
        val name: String,
        val normalizedName: String
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private companion object {
        const val PROGRAM = "https://www.iddaa.com/program/futbol"
        const val BASE = "https://sportsbookv2.iddaa.com/sportsbook"
        // First-party JSON feed used by the official iddaa.com football program.
        // MS 1/X/2 and HT/FT are both official Iddaa markets; no third-party odds source is used.
        const val EVENTS = "$BASE/events?st=1&type=0&version=0"
        const val CONFIG = "$BASE/get_market_config"
        val REQUIRED_HTFT = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
    }

    /** Same official feed used by both the main screen and Opened Markets. */
    suspend fun fetchOpenedMarkets(): Result = fetchToday()

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(30_000L) {
            try {
                val zone = ZoneId.of("Europe/Istanbul")
                val today = LocalDate.now(zone)
                val programUrl = "$PROGRAM?date=${today.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))}"

                // The visible program page and this endpoint are first-party Iddaa data.
                // We use the JSON feed behind the page instead of scraping the HTML table.
                val eventsResponse = get(EVENTS, programUrl)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, -1, 0, "İddaa resmi program verisi alınamadı")
                val configResponse = get(CONFIG, programUrl)
                    ?: return@withTimeoutOrNull Result(emptyList(), 0, 0, eventsResponse.code, -1, "İddaa market config verisi alınamadı")

                val configs = parseMarketConfig(configResponse)
                val parsed = parseEvents(eventsResponse, configs)
                val todayMatches = parsed
                    .filter { pair ->
                        pair.first <= 0L || Instant.ofEpochMilli(pair.first).atZone(zone).toLocalDate() == today
                    }
                    .map { it.second }
                    .sortedBy { it.matchTimestamp.takeIf { ts -> ts > 0L } ?: Long.MAX_VALUE }

                val marketMatches = todayMatches.count { it.hasHtFt }
                Result(
                    matches = todayMatches,
                    scanned = todayMatches.size,
                    marketMatches = marketMatches,
                    httpEvents = eventsResponse.code,
                    httpMarketConfig = configResponse.code
                )
            } catch (e: Exception) {
                Result(emptyList(), 0, 0, -1, -1, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, 0, -1, -1, "İddaa resmi veri taraması zaman aşımına uğradı")
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun get(url: String, refererUrl: String = PROGRAM): HttpResult? = runCatching {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json, text/plain, */*")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Origin", "https://www.iddaa.com")
            .header("Referer", refererUrl)
            .build()
        client.newCall(request).execute().use { response ->
            HttpResult(response.code, response.body?.string().orEmpty())
        }
    }.getOrNull()

    private fun parseMarketConfig(response: HttpResult): Map<String, MarketConfig> {
        val root = JSONObject(response.body)
        val data = root.optJSONObject("data") ?: return emptyMap()
        val markets = data.optJSONObject("m") ?: return emptyMap()
        val out = HashMap<String, MarketConfig>()
        val keys = markets.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val item = markets.optJSONObject(key) ?: continue
            val name = item.optString("n", "Unknown Market")
            out[key] = MarketConfig(name, normalize(name))
        }
        return out
    }

    private fun parseEvents(
        response: HttpResult,
        configs: Map<String, MarketConfig>
    ): List<Pair<Long, OpenedMarketMatch>> {
        val root = JSONObject(response.body)
        val events = root.optJSONObject("data")?.optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Pair<Long, OpenedMarketMatch>>(events.length())

        for (index in 0 until events.length()) {
            val event = events.optJSONObject(index) ?: continue
            val id = event.optString("i", "")
            val home = event.optString("hn", "").trim()
            val away = event.optString("an", "").trim()
            if (id.isBlank() || home.isBlank() || away.isBlank()) continue

            val timestamp = readTimestampMillis(event)
            val zone = ZoneId.of("Europe/Istanbul")
            val matchTime = readDisplayTime(event, timestamp)
            val matchDate = if (timestamp > 0L) {
                Instant.ofEpochMilli(timestamp).atZone(zone)
                    .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            } else ""

            var ms1: String? = null
            var msX: String? = null
            var ms2: String? = null
            val htFt = linkedMapOf<String, String>()
            val markets = event.optJSONArray("m")

            if (markets == null) {
                // Keep the official fixture even when no market payload is returned.
                // This preserves the official start time for the main card.
                out += timestamp to OpenedMarketMatch(
                    matchId = id,
                    homeTeam = home,
                    awayTeam = away,
                    matchTimestamp = timestamp,
                    matchTime = matchTime,
                    matchDate = matchDate
                )
                continue
            }

            for (mIndex in 0 until markets.length()) {
                val market = markets.optJSONObject(mIndex) ?: continue
                val t = market.optInt("t", -1)
                val st = market.optInt("st", -1)
                // Market type is determined from the official market-config entry.
                // This is critical because both "İlk Yarı Sonucu" and "Maç Sonucu"
                // use the same 1/X/2 outcome labels. Never select a 3-way market
                // merely because it has 1/X/2 outcomes; that was the source of the
                // first-half-odds leak into the MS columns.
                val marketConfig = configs["${t}_${st}"]
                val configName = marketConfig?.normalizedName.orEmpty()
                val outcomes = readOutcomes(market.opt("o"))
                if (outcomes.isEmpty()) continue

                // IMPORTANT: do not depend on the market-config name. The official
                // feed's outcome labels are the most stable source of truth.
                val htCandidate = linkedMapOf<String, String>()
                var one = false
                var draw = false
                var two = false

                for (outcome in outcomes) {
                    val rawLabel = outcome.first
                    val odd = outcome.second ?: continue
                    if (odd <= 1.0) continue

                    normalizeHtFt(rawLabel)?.let { htCandidate[it] = formatOdd(odd) }
                    when (normalizeOutcome(rawLabel)) {
                        "1" -> one = true
                        "x" -> draw = true
                        "2" -> two = true
                    }
                }

                // A full 9-cell 1/1..2/2 grid is unambiguous HT/FT.
                if (REQUIRED_HTFT.all { htCandidate.containsKey(it) }) {
                    REQUIRED_HTFT.forEach { htFt[it] = htCandidate.getValue(it) }
                    continue
                }

                // Accept HT/FT only when the official market-config identifies it.
                // Do NOT use the mere presence of an outcome shape as a fallback:
                // that can confuse other markets with the same labels.
                if (isHtFt(configName)) {
                    htCandidate.forEach { (k, v) -> htFt[k] = v }
                    if (htFt.isNotEmpty()) continue
                }

                // MS1/MSX/MS2 MUST come from the official "Maç Sonucu" market.
                // Do NOT fall back to any 1/X/2-shaped market: the first-half
                // market has the exact same outcome labels.
                if (isMatchResult(configName)) {
                    for (outcome in outcomes) {
                        val odd = outcome.second ?: continue
                        if (odd <= 1.0) continue
                        when (normalizeOutcome(outcome.first)) {
                            "1" -> ms1 = formatOdd(odd)
                            "x" -> msX = formatOdd(odd)
                            "2" -> ms2 = formatOdd(odd)
                        }
                    }
                }
            }

            // Keep every official fixture in the result so the main cards can
            // always receive the official start time, even if a market is closed.
            out += timestamp to OpenedMarketMatch(
                matchId = id,
                homeTeam = home,
                awayTeam = away,
                matchTimestamp = timestamp,
                matchTime = matchTime,
                matchDate = matchDate,
                ms1 = ms1,
                msX = msX,
                ms2 = ms2,
                hasHtFt = htFt.isNotEmpty(),
                htFtOdds = htFt
            )
        }
        return out
    }

    /**
     * Reads the official event start time defensively. The feed has appeared with
     * epoch seconds, epoch milliseconds and ISO/date strings across deployments.
     * We normalize everything to epoch milliseconds before the UI sees it.
     */
    private fun readTimestampMillis(event: JSONObject): Long {
        // Official event feeds have used d/ed/eventDate across deployments.
        // Read the direct event fields first, then inspect nested date objects so
        // the UI does not silently fall back to --:-- when eventDate is structured.
        val keys = listOf("d", "ed", "eventDate", "startDate", "date", "startTime", "dt", "kickoff")
        return readTimestampFromObject(event, keys, 0)
    }

    private fun readTimestampFromObject(obj: JSONObject, keys: List<String>, depth: Int): Long {
        if (depth > 3) return 0L

        for (key in keys) {
            if (!obj.has(key)) continue
            val raw = obj.opt(key)
            when (raw) {
                is Number -> {
                    val n = raw.toLong()
                    if (n > 0L) return if (n < 100_000_000_000L) n * 1000L else n
                }
                is String -> {
                    val value = raw.trim()
                    value.toLongOrNull()?.let { n ->
                        if (n > 0L) return if (n < 100_000_000_000L) n * 1000L else n
                    }
                    if (value.isNotBlank()) parseDateString(value)?.let { return it }
                }
                is JSONObject -> {
                    readTimestampFromObject(raw, keys, depth + 1).takeIf { it > 0L }?.let { return it }
                }
            }
        }

        val iterator = obj.keys()
        while (iterator.hasNext()) {
            val key = iterator.next()
            val value = obj.opt(key)
            if (value is JSONObject && (key.contains("date", true) || key.contains("time", true) || key == "e")) {
                readTimestampFromObject(value, keys, depth + 1).takeIf { it > 0L }?.let { return it }
            }
        }
        return 0L
    }

    /**
     * Returns the official kickoff text even when a deployment exposes a
     * preformatted time instead of an epoch value. This is only a fallback;
     * numeric event field d remains authoritative.
     */
    private fun readDisplayTime(event: JSONObject, timestamp: Long): String {
        if (timestamp > 0L) {
            return Instant.ofEpochMilli(timestamp)
                .atZone(ZoneId.of("Europe/Istanbul"))
                .format(DateTimeFormatter.ofPattern("HH:mm"))
        }
        val candidates = listOf("time", "matchTime", "startTimeText", "kickoff", "t")
        for (key in candidates) {
            val value = event.optString(key, "").trim()
            if (Regex("^\\d{1,2}:\\d{2}$").matches(value)) {
                val parts = value.split(":")
                return parts[0].padStart(2, '0') + ":" + parts[1]
            }
        }
        return "--:--"
    }

    private fun parseDateString(raw: String): Long? {
        val value = raw.trim()
        val candidates = listOf(
            java.time.format.DateTimeFormatter.ISO_INSTANT,
            java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME
        )
        for (formatter in candidates) {
            try {
                return if (formatter == java.time.format.DateTimeFormatter.ISO_INSTANT) {
                    Instant.parse(value).toEpochMilli()
                } else {
                    java.time.OffsetDateTime.parse(value, formatter).toInstant().toEpochMilli()
                }
            } catch (_: Exception) { }
        }
        val localFormats = listOf(
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
            java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
            java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")
        )
        for (formatter in localFormats) {
            try {
                return java.time.LocalDateTime.parse(value, formatter)
                    .atZone(ZoneId.of("Europe/Istanbul")).toInstant().toEpochMilli()
            } catch (_: Exception) { }
        }
        return null
    }

    private fun readOutcomes(raw: Any?): List<Pair<String, Double?>> {
        val result = ArrayList<Pair<String, Double?>>()
        when (raw) {
            is org.json.JSONArray -> {
                for (i in 0 until raw.length()) {
                    val o = raw.optJSONObject(i) ?: continue
                    result += o.optString("n", "") to readOdd(o.opt("odd"))
                }
            }
            is org.json.JSONObject -> {
                val keys = raw.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val value = raw.opt(key)
                    if (value is org.json.JSONObject) {
                        result += (value.optString("n", key)) to readOdd(value.opt("odd"))
                    } else {
                        result += key to readOdd(value)
                    }
                }
            }
        }
        return result
    }

    private fun readOdd(raw: Any?): Double? = when (raw) {
        is Number -> raw.toDouble()
        is String -> raw.replace(',', '.').toDoubleOrNull()
        else -> null
    }

    private fun isMatchResult(name: String): Boolean {
        if (name.isBlank()) return false
        if (name.contains("ilk yari") || name.contains("ikinci yari")) return false
        if (name.contains("handikap") || name.contains("korner")) return false
        return name == "mac sonucu" ||
            name == "match result" ||
            name.contains("mac sonucu") &&
            !name.contains("ve karsilikli gol") &&
            !name.contains("ve alt/ust")
    }

    private fun isHtFt(name: String): Boolean =
        name.contains("ilk yari / mac sonucu") ||
            name.contains("ilk yari/mac sonucu") ||
            name.contains("ilk yari mac sonucu") ||
            name.contains("first half / match result") ||
            name.contains("half time / full time")

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('&', ' ')
        v = Normalizer.normalize(v, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        v = v.replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ç', 'c').replace('ö', 'o').replace('ü', 'u')
        return v.replace(Regex("\\s+"), " ").trim()
    }

    private fun normalizeOutcome(value: String): String =
        value.trim().lowercase(Locale.ROOT)
            .replace("0", "x")
            .replace("beraberlik", "x")
            .replace("draw", "x")

    private fun normalizeHtFt(value: String): String? {
        val v = value.trim().uppercase(Locale.ROOT)
            .replace("0", "X")
            .replace('-', '/')
            .replace(" ", "")
        return if (v.matches(Regex("^[1X2]/[1X2]$"))) v else null
    }

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    fun findForTeamPair(
        matches: List<OpenedMarketMatch>,
        homeTeam: String,
        awayTeam: String
    ): OpenedMarketMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) && MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
