plugins { id("com.android.application") }

android {
    namespace = "com.cio.skor"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.cio.skor"
        minSdk = 26
        targetSdk = 36
        versionCode = 142
        versionName = "0.20.0"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.recyclerview:recyclerview:1.4.0")
    implementation("androidx.cardview:cardview:1.0.0")
    implementation("org.jsoup:jsoup:1.18.3")
    implementation("org.apache.commons:commons-text:1.10.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}
