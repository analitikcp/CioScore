package com.cio.skor.data

import java.time.ZoneId

/**
 * Default timezone used only when a provider gives a date/time without an
 * explicit UTC offset. Explicit ISO offsets always win over this fallback.
 */
enum class SourceTimeZone(val zoneId: ZoneId) {
    EUROPE_ISTANBUL(ZoneId.of("Europe/Istanbul")),
    EUROPE_LONDON(ZoneId.of("Europe/London")),
    UTC(ZoneId.of("UTC")),
    EUROPE_BERLIN(ZoneId.of("Europe/Berlin"))
}
