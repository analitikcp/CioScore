package com.cio.skor.data

import java.time.Instant
import java.time.ZonedDateTime
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Single canonical kickoff clock for the app.
 *
 * All provider/official fixture timestamps used by the matcher and UI are
 * interpreted/displayed in Europe/Istanbul. Epoch timestamps remain absolute;
 * only local date/time values without an explicit offset are assigned this zone.
 */
object KickoffNormalizer {
    val ZONE: ZoneId = ZoneId.of("Europe/Istanbul")
    val ISTANBUL_ZONE: ZoneId = ZONE
    private val DATE_OUT = DateTimeFormatter.ofPattern("dd.MM.yyyy")
    private val TIME_OUT = DateTimeFormatter.ofPattern("HH:mm")
    private val DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")


    /**
     * Offset-first kickoff normalization. If [rawDateTimeStr] contains an ISO
     * offset/Z, that offset is authoritative. Otherwise the date+time is
     * interpreted in [sourceTimeZone] and converted to an absolute Instant.
     */
    fun normalizeToIstanbulInstant(
        rawDateTimeStr: String?,
        rawDate: String?,
        rawTime: String?,
        sourceTimeZone: SourceTimeZone
    ): Instant? {
        val raw = rawDateTimeStr?.trim().orEmpty()
        if (raw.isNotBlank()) {
            runCatching { return OffsetDateTime.parse(raw).toInstant() }.getOrNull()
            runCatching { return ZonedDateTime.parse(raw).toInstant() }.getOrNull()
            runCatching { return Instant.parse(raw) }.getOrNull()
        }

        val date = rawDate?.let(::parseDate) ?: return null
        val time = rawTime?.let(::parseTime) ?: return null
        return LocalDateTime.of(date, time).atZone(sourceTimeZone.zoneId).toInstant()
    }

    fun normalizeToIstanbulDisplay(
        rawDateTimeStr: String?,
        rawDate: String?,
        rawTime: String?,
        sourceTimeZone: SourceTimeZone
    ): Triple<Long, String, String> {
        val instant = normalizeToIstanbulInstant(rawDateTimeStr, rawDate, rawTime, sourceTimeZone)
            ?: return Triple(0L, normalizeDate(rawDate.orEmpty()), normalizeTime(rawTime.orEmpty()))
        val local = instant.atZone(ISTANBUL_ZONE)
        return Triple(
            instant.toEpochMilli(),
            local.toLocalDate().format(DATE_OUT),
            local.toLocalTime().format(TIME_OUT)
        )
    }

    fun toEpochMillis(date: String, time: String): Long {
        val d = parseDate(date) ?: return 0L
        val t = parseTime(time) ?: return 0L
        return LocalDateTime.of(d, t).atZone(ZONE).toInstant().toEpochMilli()
    }

    fun normalizeDate(value: String): String {
        val v = value.trim()
        if (v.isBlank()) return ""
        val direct = listOf(
            "yyyy-MM-dd", "yyyy/MM/dd", "dd.MM.yyyy", "dd/MM/yyyy", "dd-MM-yyyy"
        )
        for (pattern in direct) {
            val parsed = runCatching {
                LocalDate.parse(v.take(10), DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed.format(DATE_OUT)
        }
        return ""
    }

    fun normalizeTime(value: String): String {
        val m = Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").find(value) ?: return "--:--"
        return "%02d:%s".format(m.groupValues[1].toInt(), m.groupValues[2])
    }

    fun fromEpochMillis(timestamp: Long): Pair<String, String> {
        if (timestamp <= 0L) return "" to "--:--"
        val local = Instant.ofEpochMilli(timestamp).atZone(ZONE)
        return local.toLocalDate().format(DATE_OUT) to local.toLocalTime().format(TIME_OUT)
    }

    fun displayDate(timestamp: Long, fallback: String = ""): String =
        if (timestamp > 0L) fromEpochMillis(timestamp).first else normalizeDate(fallback)

    fun displayTime(timestamp: Long, fallback: String = "--:--"): String =
        if (timestamp > 0L) fromEpochMillis(timestamp).second else normalizeTime(fallback)

    fun isPast(timestamp: Long, nowMillis: Long = System.currentTimeMillis()): Boolean =
        timestamp > 0L && timestamp <= nowMillis

    fun isUpcoming(timestamp: Long, nowMillis: Long = System.currentTimeMillis()): Boolean =
        timestamp > nowMillis

    fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy", "yyyy/MM/dd")
        for (pattern in patterns) {
            runCatching { LocalDate.parse(v.take(10), DateTimeFormatter.ofPattern(pattern)) }
                .getOrNull()?.let { return it }
        }
        return null
    }

    fun parseTime(value: String): LocalTime? {
        val v = normalizeTime(value)
        if (v == "--:--") return null
        return runCatching { LocalTime.parse(v, TIME_OUT) }.getOrNull()
    }

    /** Parse a local date/time string in the app's canonical zone. */
    fun parseLocalDateTime(value: String): Long {
        val text = value.trim()
        if (text.isBlank()) return 0L
        val formatters = listOf(
            DATE_TIME,
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")
        )
        for (formatter in formatters) {
            runCatching {
                return LocalDateTime.parse(text, formatter).atZone(ZONE).toInstant().toEpochMilli()
            }
        }
        return 0L
    }
}
