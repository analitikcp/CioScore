package com.cio.skor.data

import java.util.concurrent.ConcurrentHashMap

/**
 * Verified alias cache. It is intentionally an in-process cache for V5.0;
 * persistence can be added later without changing the learning gate.
 * Nothing is learned from rejected/ambiguous fixtures.
 */
data class AliasCacheKey(
    val provider: String,
    val country: String,
    val rawTeamName: String
)

object AutoAliasCache {
    private val cache = ConcurrentHashMap<AliasCacheKey, String>()

    fun getLearnedAlias(provider: String, country: String, rawTeamName: String): String? =
        cache[AliasCacheKey(provider.lowercase().trim(), country.lowercase().trim(), rawTeamName.lowercase().trim())]

    fun tryLearnAlias(
        provider: String,
        country: String,
        providerTeamName: String,
        officialIddaaName: String,
        homeSim: Double,
        awaySim: Double,
        isSameOfficialFixture: Boolean,
        marginToSecondBest: Double
    ) {
        if (!isSameOfficialFixture) return
        if (homeSim < 0.90 || awaySim < 0.90) return
        if (marginToSecondBest < 0.20) return
        if (providerTeamName.isBlank() || officialIddaaName.isBlank()) return

        val key = AliasCacheKey(provider.lowercase().trim(), country.lowercase().trim(), providerTeamName.lowercase().trim())
        cache[key] = officialIddaaName.trim()
    }

    fun clear() = cache.clear()
}
