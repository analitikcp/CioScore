package com.cio.skor.data

import java.text.Normalizer
import java.util.Locale

data class TeamFingerprint(
    val raw: String,
    val normalized: String,
    val coreTokens: Set<String>,
    val descriptorTokens: Set<String>,
    val metadataTokens: Set<String>,
    val tier: String,
    val compactCore: String
)

/**
 * Generic team identity extraction.  Safe metadata is removable; descriptors
 * remain visible so City/United/Real/Atletico etc. can distinguish clubs.
 */
object TeamFingerprintExtractor {
    private val SAFE_METADATA_TOKENS = setOf(
        "fc", "fci", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "pfc", "club", "calcio", "cs", "sd", "ud", "ca"
    )

    private val DESCRIPTOR_TOKENS = setOf(
        "united", "city", "real", "atletico", "sporting", "deportivo", "independiente",
        "town", "county", "rovers", "athletic", "central", "nacional", "inter", "international", "university"
    )

    private val ABBREVIATIONS = mapOf(
        "utd" to "united",
        "athl" to "athletic",
        "ath" to "athletic",
        "st" to "saint",
        "sp" to "sporting",
        "dep" to "deportivo",
        "ind" to "independiente",
        "atlet" to "atletico"
    )

    private val TIER_TOKENS = setOf("u21", "u20", "u19", "u18", "u17", "u16", "ii", "iii", "reserve", "reserves", "b")

    fun createFingerprint(rawName: String?): TeamFingerprint {
        if (rawName.isNullOrBlank()) return TeamFingerprint("", "", emptySet(), emptySet(), emptySet(), "", "")
        val normalized = normalize(rawName)
        val metadata = linkedSetOf<String>()
        val descriptors = linkedSetOf<String>()
        val cores = linkedSetOf<String>()
        var tier = ""

        normalized.split(' ').filter(String::isNotBlank).forEach { rawToken ->
            val token = ABBREVIATIONS[rawToken] ?: rawToken
            when {
                token in TIER_TOKENS -> if (tier.isBlank()) tier = token
                token in SAFE_METADATA_TOKENS -> metadata += token
                token in DESCRIPTOR_TOKENS -> descriptors += token
                else -> cores += token
            }
        }

        // A descriptor-only club (rare, e.g. "Real") still needs an identity.
        if (cores.isEmpty() && descriptors.isNotEmpty()) cores += descriptors

        return TeamFingerprint(
            raw = rawName,
            normalized = normalized,
            coreTokens = cores,
            descriptorTokens = descriptors,
            metadataTokens = metadata,
            tier = tier,
            compactCore = cores.sorted().joinToString("-")
        )
    }

    private fun normalize(input: String): String {
        val temp = Normalizer.normalize(input, Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .lowercase(Locale.ROOT)
            .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
            .replace("ş", "s").replace("ö", "o").replace("ç", "c")
            .replace("ß", "ss").replace("æ", "ae").replace("œ", "oe")
            .replace("ø", "o").replace("ð", "d").replace("þ", "th")
        return temp.replace(Regex("[^a-z0-9\\s]"), " ")
            .replace(Regex("\\s+"), " ").trim()
    }
}
