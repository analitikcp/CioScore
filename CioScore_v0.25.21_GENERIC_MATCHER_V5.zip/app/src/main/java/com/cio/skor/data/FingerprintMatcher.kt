package com.cio.skor.data

/** Conservative multi-signal comparison used by TeamAliasCanonicalizer. */
object FingerprintMatcher {
    data class MatchScore(
        val finalScore: Double,
        val isCoreMatch: Boolean,
        val isContradiction: Boolean
    )

    fun calculateSimilarity(fp1: TeamFingerprint, fp2: TeamFingerprint): MatchScore {
        if (fp1.normalized == fp2.normalized && fp1.tier == fp2.tier) {
            return MatchScore(1.0, true, false)
        }
        if (fp1.tier != fp2.tier) return MatchScore(0.0, false, true)

        val intersection = fp1.coreTokens.intersect(fp2.coreTokens).size
        val union = fp1.coreTokens.union(fp2.coreTokens).size
        if (intersection == 0 || union == 0) return MatchScore(0.0, false, true)

        val coreSim = intersection.toDouble() / union.toDouble()
        val sharedDescriptors = fp1.descriptorTokens.intersect(fp2.descriptorTokens)
        val bothHaveDescriptors = fp1.descriptorTokens.isNotEmpty() && fp2.descriptorTokens.isNotEmpty()

        // Same core but conflicting identity descriptors is a hard contradiction.
        if (bothHaveDescriptors && sharedDescriptors.isEmpty()) {
            return MatchScore(0.20, true, true)
        }

        val finalScore = when {
            sharedDescriptors.isNotEmpty() -> coreSim * 0.70 + 0.30
            fp1.coreTokens == fp2.coreTokens -> 0.95
            else -> coreSim
        }
        return MatchScore(finalScore.coerceIn(0.0, 1.0), true, false)
    }
}
