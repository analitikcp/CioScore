package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.concurrent.TimeUnit

/**
 * Mackolik Iddaa Programi: tek HTTP istegi, gercek TR satirlari uzerinden parse.
 *
 * Gercek satir ornegi:
 * Cagliari - Lecce | 12221 | 1.86 | 2.84 | 3.50 | ...
 *
 * Parser, body icindeki rastgele decimal sayilari degil;
 * 1) takim hucresini, 2) 5 haneli MS kodunu, 3) kodun hemen sonraki 3 orani okur.
 */
class MackolikOddsService {
    companion object {
        private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"
        private val CODE = Regex("(?<![0-9])\\d{5}(?![0-9])")
        private val ODDS = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    data class MackolikMatch(
        val homeTeam: String,
        val awayTeam: String,
        val odds: SofaScoreService.Odds
    )

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val rowCount: Int,
        val parsedRows: Int,
        val matches: List<MackolikMatch>,
        val sample: String = "-",
        val error: String? = null
    )

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(16_000L) {
            try {
                val request = Request.Builder()
                    .url(PROGRAM_URL)
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                            "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                    )
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                    .header("Referer", "https://arsiv2.mackolik.com/")
                    .build()

                client.newCall(request).execute().use { response ->
                    val html = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withTimeoutOrNull Result(
                            response.code, html.length, 0, 0, emptyList(), error = "HTTP ${response.code}"
                        )
                    }
                    if (html.isBlank()) {
                        return@withTimeoutOrNull Result(
                            response.code, 0, 0, 0, emptyList(), error = "HTML BOS"
                        )
                    }

                    val doc = Jsoup.parse(html, PROGRAM_URL)
                    val rows = doc.select("tr")
                    val parsed = LinkedHashMap<String, MackolikMatch>()
                    var parsedRows = 0
                    var sample = "-"

                    for (row in rows) {
                        val item = parseMatchRow(row) ?: continue
                        parsedRows++
                        parsed[MatchMerger.key(item.homeTeam, item.awayTeam)] = item
                        if (sample == "-") {
                            sample = "${item.homeTeam} - ${item.awayTeam}: " +
                                "${item.odds.home} / ${item.odds.draw} / ${item.odds.away}"
                        }
                    }

                    Result(
                        httpCode = response.code,
                        htmlLength = html.length,
                        rowCount = rows.size,
                        parsedRows = parsedRows,
                        matches = parsed.values.toList(),
                        sample = sample
                    )
                }
            } catch (e: Exception) {
                Result(
                    httpCode = -1,
                    htmlLength = 0,
                    rowCount = 0,
                    parsedRows = 0,
                    matches = emptyList(),
                    error = "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}"
                )
            }
        } ?: Result(
            httpCode = -1,
            htmlLength = 0,
            rowCount = 0,
            parsedRows = 0,
            matches = emptyList(),
            error = "Mackolik zaman asimi"
        )
    }

    /**
     * AYNI mantık tek-maç testinde doğrulandı:
     * 1) TR'nin tamamını oku
     * 2) 5 haneli MS kodunu bul
     * 3) koddan sonraki ilk 3 oranı MS1/X/MS2 kabul et
     * 4) koddan ÖNCEKİ bölümden "Ev - Deplasman" takım çiftini çıkar
     *
     * Böylece takım hücresinin DOM'daki konumuna güvenmiyoruz.
     * Tek-maç testinin çalıştığı algoritma doğrudan tüm satırlara uygulanıyor.
     */
    private fun parseMatchRow(row: Element): MackolikMatch? {
        val text = row.text().replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        // Tek maç testindeki ile aynı kod tespiti.
        val codeMatch = CODE.find(text) ?: return null

        // Koddan sonraki ilk üç ondalık sayı = MS1 / X / MS2.
        val afterCode = text.substring(codeMatch.range.last + 1)
        val odds = ODDS.findAll(afterCode)
            .map { it.value.replace(',', '.') }
            .take(3)
            .toList()
        if (odds.size != 3) return null

        // Koddan önceki bölümde saat + takım çifti bulunur.
        // Örn: "19:30 Cagliari - Lecce"
        val beforeCode = text.substring(0, codeMatch.range.first)
            .replace(Regex("^.*?\\b\\d{1,2}:\\d{2}\\s+"), "")
            .trim()

        val pair = extractTeamPair(beforeCode) ?: return null
        if (!validTeam(pair.first) || !validTeam(pair.second)) return null

        return MackolikMatch(
            homeTeam = pair.first,
            awayTeam = pair.second,
            odds = SofaScoreService.Odds(odds[0], odds[1], odds[2])
        )
    }

    private fun extractTeamPair(value: String): Pair<String, String>? {
        var text = value.replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        // Bazı satırlarda saat temizlenmeden kalabilir.
        text = text.replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "").trim()

        // Maç adı ayıracı olarak son " - " kullanılır.
        val dash = text.lastIndexOf(" - ")
        if (dash <= 0 || dash >= text.length - 3) return null

        val home = cleanTeam(text.substring(0, dash))
        val away = cleanTeam(text.substring(dash + 3))

        if (home.length !in 2..80 || away.length !in 2..80) return null
        if (home.count { it.isLetter() } < 2 || away.count { it.isLetter() } < 2) return null

        return home to away
    }

    private fun cleanTeam(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim(' ', '|', '•')
        .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
        .replace(Regex("\\s+\\d{5}$"), "")
        .trim()

    private fun validTeam(value: String): Boolean {
        if (value.length !in 2..80) return false
        if (value.count { it.isLetter() } < 2) return false

        val bad = setOf("Iddaa", "Programi", "MS", "Kod", "Lig", "Tumu", "Futbol", "Basketbol")
        return bad.none { value.equals(it, ignoreCase = true) }
    }

    fun findForTeamPair(
        matches: List<MackolikMatch>,
        homeTeam: String,
        awayTeam: String
    ): MackolikMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) &&
            MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
