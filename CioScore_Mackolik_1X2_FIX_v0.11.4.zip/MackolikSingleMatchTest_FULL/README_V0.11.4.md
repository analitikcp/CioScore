# v0.11.4 — Mackolik single-match parser generalized

The single-match test that successfully found Cagliari-Lecce is now the exact parsing algorithm used for every `<tr>` in the Mackolik bulletin.

Flow per row:
1. Read complete row text.
2. Find the 5-digit MS market code.
3. Take the first three decimal odds after that code as MS1/X/MS2.
4. Take the text before the code, remove the kickoff time, and split the final ` - ` into home/away teams.
5. Store every parsed fixture and fuzzy-match it against the app's 5-source fixture list.

Important fix from v0.11.3: the parser no longer requires the team pair to be inside a single `td` cell. The single-match test never made that assumption, so the all-match parser must not make it either.
