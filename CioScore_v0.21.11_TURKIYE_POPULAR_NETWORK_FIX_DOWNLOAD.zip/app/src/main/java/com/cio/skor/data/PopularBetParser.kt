package com.cio.skor.data

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

interface PopularBetParser {
    val sourceName: String
    val pageUrl: String
    fun fetch(): SourceFetchResult

    fun parseHtml(body: String): List<PopularBetModel> {
        val doc = Jsoup.parse(body, pageUrl)
        val result = mutableListOf<PopularBetModel>()
        val candidates = doc.select("[data-home-team][data-away-team], [data-hometeam][data-awayteam], [data-home][data-away]")
        for (el in candidates) {
            val home = attrAny(el, "data-home-team", "data-hometeam", "data-home")
            val away = attrAny(el, "data-away-team", "data-awayteam", "data-away")
            if (home.isBlank() || away.isBlank()) continue
            val text = el.text().replace(Regex("\\s+"), " ").trim()
            result += PopularBetModel(
                sourceName = sourceName,
                rawHomeTeam = home,
                rawAwayTeam = away,
                matchCode = attrAny(el, "data-match-code", "data-code", "data-event-code"),
                prediction = attrAny(el, "data-market", "data-bet", "data-prediction").ifBlank { guessMarket(text) },
                ratioOrCount = attrAny(el, "data-percentage", "data-ratio", "data-count", "data-played-count").ifBlank { guessRatio(text) },
                odds = attrAny(el, "data-odds", "data-odd", "data-rate").ifBlank { guessOdds(text) }
            )
        }
        return result.distinctBy { "${it.rawHomeTeam}|${it.rawAwayTeam}|${canonicalMarket(it.prediction)}|${it.sourceName}" }
    }

    fun fetchFromPage(): SourceFetchResult {
        val http = PopularBetHttpClient.get(pageUrl)
        if (!http.isSuccess) {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.HTTP, http.code, http.attempts, http.error)
        }
        val records = runCatching { parseHtml(http.body.orEmpty()) }.getOrElse {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.PARSE, http.code, http.attempts, it.message)
        }
        if (records.isEmpty()) {
            return SourceFetchResult.failure(sourceName, pageUrl, SourceFailure.EMPTY, http.code, http.attempts, "HTTP başarılı fakat mevcut parser veri çıkaramadı")
        }
        return SourceFetchResult.success(sourceName, pageUrl, records, http.code, http.attempts)
    }

    fun attrAny(el: Element, vararg names: String): String =
        names.asSequence().map { el.attr(it).trim() }.firstOrNull { it.isNotBlank() } ?: ""

    fun guessMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        val patterns = listOf("MS 1", "MS X", "MS 2", "MAÇ SONUCU", "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KG VAR", "KG YOK")
        return patterns.firstOrNull { upper.contains(it) } ?: ""
    }

    fun guessRatio(text: String): String = Regex("(?:%\\s?\\d{1,3}|\\d[\\d.]*\\s*(?:Kişi|oynama))", RegexOption.IGNORE_CASE)
        .find(text)?.value?.trim() ?: ""

    fun guessOdds(text: String): String = Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)")
        .find(text)?.value ?: ""

    fun canonicalMarket(value: String): String = value.lowercase(Locale("tr", "TR"))
        .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
        .replace("ş", "s").replace("ö", "o").replace("ç", "c")
        .replace(Regex("\\s+"), " ").trim()
}

enum class SourceFailure { HTTP, PARSE, EMPTY, EXCEPTION }

data class SourceFetchResult(
    val sourceName: String,
    val url: String,
    val records: List<PopularBetModel>,
    val failure: SourceFailure? = null,
    val httpCode: Int = 0,
    val attempts: Int = 0,
    val errorMessage: String? = null
) {
    val ok: Boolean get() = failure == null && records.isNotEmpty()
    companion object {
        fun success(source: String, url: String, records: List<PopularBetModel>, code: Int, attempts: Int) =
            SourceFetchResult(source, url, records, null, code, attempts, null)
        fun failure(source: String, url: String, reason: SourceFailure, code: Int, attempts: Int, message: String?) =
            SourceFetchResult(source, url, emptyList(), reason, code, attempts, message)
    }
}

class IddaaPopularParser : PopularBetParser {
    override val sourceName = "İddaa"
    override val pageUrl = "https://www.iddaa.com/populer-bahisler/futbol"
    override fun fetch(): SourceFetchResult = fetchFromPage()
}

class NesinePopularParser : PopularBetParser {
    override val sourceName = "Nesine"
    override val pageUrl = "https://www.nesine.com/iddaa/dakika-bahis"
    override fun fetch(): SourceFetchResult = fetchFromPage()
}

class MisliPopularParser : PopularBetParser {
    override val sourceName = "Misli"
    override val pageUrl = "https://www.misli.com/iddaa/en-cok-oynanan-tum-maclar"
    override fun fetch(): SourceFetchResult = fetchFromPage()
}

class BilyonerPopularParser : PopularBetParser {
    override val sourceName = "Bilyoner"
    override val pageUrl = "https://www.bilyoner.com/iddaa/populer-bahisler"
    override fun fetch(): SourceFetchResult = fetchFromPage()
}
