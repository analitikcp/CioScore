CIO Score 0.5.6
- 0.5.5 tabanından düzeltme
- Status bar inset ile başlık konum düzeltmesi
- Skor önce ham karttan, takım alanı normalize edilmiş karttan ayrıştırılır
- 16 kaynak tarama korunur
