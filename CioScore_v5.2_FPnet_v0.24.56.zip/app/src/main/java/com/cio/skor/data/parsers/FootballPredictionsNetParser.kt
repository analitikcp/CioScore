package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * FootballPredictions.net (FP.net) correct-score parser.
 *
 * FP.net publishes fixture pages under /en/<home>-v-<away>-predictions-betting-tips
 * and exposes a semantic "Correct Score Prediction" section.  The listing page
 * can change its card/table markup, so this parser intentionally anchors on the
 * semantic label and the fixture URL rather than one CSS class.
 */
class FootballPredictionsNetParser : BaseParser("FP.net") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Prefer links to actual FP.net match pages. A match URL gives us a much
        // stronger team identity than arbitrary visible text on a prediction card.
        for (link in doc.select("a[href]")) {
            val href = decode(link.attr("href"))
            if (!isMatchHref(href)) continue

            val pair = splitFixtureSlug(href) ?: continue
            val container = predictionContainer(link) ?: continue
            val context = clean(container.text())
            if (!containsCorrectScoreAnchor(context)) continue

            val score = extractCorrectScore(container) ?: continue
            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val sourceMatchId = stableHrefId(href)
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId
            )
            out["ID|$sourceMatchId"] = model
            if (out.size >= 60) break
        }

        // Fallback for markup where the fixture link is not inside the same card
        // as the semantic anchor. We only accept links + nearby text that contain
        // the explicit Correct Score Prediction label, avoiding numeric noise.
        if (out.isEmpty()) {
            val anchors = doc.getElementsContainingOwnText("Correct Score Prediction")
            for (anchor in anchors) {
                val container = predictionContainer(anchor) ?: continue
                val context = clean(container.text())
                val score = extractCorrectScore(container) ?: continue
                val link = container.select("a[href]")
                    .firstOrNull { isMatchHref(it.attr("href")) }
                    ?: continue
                val pair = splitFixtureSlug(link.attr("href")) ?: continue
                val home = team(pair.first)
                val away = team(pair.second)
                if (!valid(home, away)) continue
                val sourceMatchId = stableHrefId(link.attr("href"))
                out["ID|$sourceMatchId"] = ScoreModel(
                    homeTeam = home,
                    awayTeam = away,
                    predictedScore = score,
                    source = source,
                    sourceMatchId = sourceMatchId
                )
                if (out.size >= 60) break
            }
        }

        return out.values.toList()
    }

    private fun containsCorrectScoreAnchor(text: String): Boolean =
        Regex("(?i)correct\\s+score(?:\\s+prediction)?(?:\\s+(?:tips?|pick))?").containsMatchIn(text)

    private fun extractCorrectScore(element: Element): String? {
        val text = clean(element.text())
        val match = Regex(
            "(?is)correct\\s+score(?:\\s+prediction)?(?:\\s+(?:tips?|pick))?.{0,800}?\\b(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
        ).find(text) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home !in 0..20 || away !in 0..20) return null
        return "$home-$away"
    }

    private fun predictionContainer(element: Element): Element? {
        // Walk upward only a bounded number of levels. This keeps the parser
        // local to a match card and prevents one page-level score from attaching
        // to multiple fixtures.
        var current: Element? = element
        repeat(7) {
            val candidate = current ?: return@repeat
            val text = clean(candidate.text())
            if (containsCorrectScoreAnchor(text) && text.length <= 12000) return candidate
            current = candidate.parent()
        }
        return null
    }

    private fun isMatchHref(href: String): Boolean {
        val normalized = decode(href).lowercase()
        val isAbsoluteFpNet = normalized.contains("footballpredictions.net")
        val isRelativeFpNet = normalized.startsWith("/")
        if (!isAbsoluteFpNet && !isRelativeFpNet) return false
        return normalized.contains("-v-") || normalized.contains("-vs-") || normalized.contains("-versus-")
    }

    private fun splitFixtureSlug(href: String): Pair<String, String>? {
        val slug = decode(href)
            .substringBefore('?')
            .substringBefore('#')
            .trimEnd('/')
            .substringAfterLast('/')
            .lowercase()

        val cleaned = slug
            .replace(Regex("-(?:predictions?|betting|tips?|live|stream|odds).*$"), "")

        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = cleaned.indexOf(marker)
            if (idx <= 0) continue
            val home = slugWords(cleaned.substring(0, idx))
            val away = slugWords(cleaned.substring(idx + marker.length))
            if (valid(home, away)) return home to away
        }
        return null
    }

    private fun slugWords(value: String): String =
        value.replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(' ')
            .joinToString(" ") { word ->
                if (word.isBlank()) word else word.replaceFirstChar { it.uppercase() }
            }

    private fun stableHrefId(href: String): String =
        decode(href)
            .substringBefore('?')
            .substringBefore('#')
            .trim()
            .trimEnd('/')

    private fun decode(value: String): String =
        runCatching {
            URLDecoder.decode(value, StandardCharsets.UTF_8.name())
        }.getOrDefault(value)
}
