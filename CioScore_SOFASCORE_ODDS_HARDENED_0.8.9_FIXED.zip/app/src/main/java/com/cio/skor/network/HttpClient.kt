package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import android.util.Log
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun get(url: String, referer: String? = null, origin: String? = null): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null

        repeat(2) { attempt ->
            val requestBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")

            if (!referer.isNullOrBlank()) requestBuilder.header("Referer", referer)
            if (!origin.isNullOrBlank()) requestBuilder.header("Origin", origin)

            try {
                client.newCall(requestBuilder.build()).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string()
                    Log.d("HttpClient", "GET $url -> HTTP ${response.code}, bodyLength=${lastBody?.length ?: 0}")
                    if (response.isSuccessful || response.code in 400..499 && response.code != 429) {
                        return response.code to lastBody
                    }
                }
            } catch (_: Exception) {
                lastCode = -1
                lastBody = null
            }

            if (attempt == 0 && (lastCode == 429 || lastCode >= 500 || lastCode == -1)) {
                Thread.sleep(700)
            }
        }

        return lastCode to lastBody
    }
}
