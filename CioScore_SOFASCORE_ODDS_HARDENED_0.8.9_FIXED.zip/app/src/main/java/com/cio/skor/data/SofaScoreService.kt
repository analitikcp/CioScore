package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.net.URLEncoder
import kotlin.math.max

/**
 * Optional SofaScore enrichment layer. It never participates in CIO source
 * scoring; it only adds 1X2 odds and recent team form to an already merged match.
 * If SofaScore is unavailable, the core five-source scan remains usable.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)
    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String
    )

    private val http = HttpClient()
    private val base = "https://api.sofascore.com/api/v1"

    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups
        val events = loadTodayEvents()
        if (events.isEmpty()) return@coroutineScope groups

        val out = groups.toMutableList()
        // Keep network pressure modest; SofaScore may rate-limit aggressive bursts.
        groups.chunked(8).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val event = events.firstOrNull {
                        MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                            MatchMerger.isSameTeam(it.away, group.awayTeam)
                    }
                    if (event == null) group else group.copy(odds = loadOdds(event.id))
                }
            }.awaitAll()
            val start = chunkIndex * 8
            results.forEachIndexed { index, value -> out[start + index] = value }
        }
        out
    }

    suspend fun getLastFive(teamName: String): List<RecentMatch> = with(Dispatchers.IO) {
        val teamId = findTeamId(teamName) ?: return@with emptyList()
        val (code, body) = http.get("$base/team/$teamId/events/last/0", "https://www.sofascore.com/", "https://www.sofascore.com")
        if (code !in 200..299 || body.isNullOrBlank()) return@with emptyList()
        parseRecentMatches(JSONObject(body), teamId).take(5)
    }

    private fun loadTodayEvents(): List<EventRef> {
        val date = LocalDate.now().toString()
        val (code, body) = http.get(
            "$base/sport/football/scheduled-events/$date",
            "https://www.sofascore.com/",
            "https://www.sofascore.com"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) add(EventRef(id, home, away))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun loadOdds(eventId: Long): Odds? {
        // Prefer the complete 1X2/full-time market payload first. The other
        // endpoints are fallbacks because SofaScore has changed this API over time.
        val paths = listOf(
            "$base/event/$eventId/odds/1/all",
            "$base/event/$eventId/odds/1",
            "$base/event/$eventId/odds/1/featured"
        )

        for (url in paths) {
            val (code, body) = http.get(
                url,
                "https://www.sofascore.com/",
                "https://www.sofascore.com"
            )
            Log.d(
                "SofaScoreOdds",
                "REQUEST: event=$eventId url=$url -> HTTP=$code bodyLength=${body?.length ?: 0}"
            )
            if (code !in 200..299 || body.isNullOrBlank()) continue

            try {
                parseOdds(JSONObject(body), eventId)?.let {
                    Log.d(
                        "SofaScoreOdds",
                        "ODDS PARSED: event=$eventId -> ${it.home}/${it.draw}/${it.away}"
                    )
                    return it
                }
            } catch (e: Exception) {
                Log.d(
                    "SofaScoreOdds",
                    "PARSE ERROR: event=$eventId ${e.javaClass.simpleName}: ${e.message}"
                )
            }
        }

        Log.d("SofaScoreOdds", "ODDS NOT FOUND: event=$eventId")
        return null
    }

    private fun parseOdds(root: JSONObject, eventId: Long): Odds? {
        /*
         * Do NOT recursively accept the first arbitrary "choices" array.
         * SofaScore can return many markets in the same JSON. We first locate
         * the full-time / 1X2 market by market name/group, then parse only its
         * 1/X/2 choices.
         */
        val candidates = mutableListOf<JSONObject>()

        fun collect(value: Any?) {
            when (value) {
                is JSONObject -> {
                    if (value.has("choices")) candidates += value
                    val keys = value.keys()
                    while (keys.hasNext()) collect(value.opt(keys.next()))
                }
                is JSONArray -> {
                    for (i in 0 until value.length()) collect(value.opt(i))
                }
            }
        }
        collect(root)

        fun marketText(obj: JSONObject): String {
            return listOf(
                obj.optString("marketName"),
                obj.optString("name"),
                obj.optString("groupName"),
                obj.optString("marketGroupName"),
                obj.optString("marketType"),
                obj.optString("type")
            ).joinToString(" ").lowercase()
        }

        fun parse1x2(obj: JSONObject): Odds? {
            val choices = obj.optJSONArray("choices") ?: return null
            var one: String? = null
            var draw: String? = null
            var two: String? = null

            for (i in 0 until choices.length()) {
                val c = choices.optJSONObject(i) ?: continue
                val name = c.optString("name").trim().uppercase()
                val raw = c.opt("decimalValue")
                    ?: c.opt("decimal")
                    ?: c.opt("value")
                    ?: c.opt("odd")

                val number = when (raw) {
                    is Number -> raw.toDouble()
                    else -> raw?.toString()?.replace(',', '.')?.toDoubleOrNull()
                }

                if (number == null || number <= 1.0 || number > 100.0) continue
                val formatted = String.format(java.util.Locale.US, "%.2f", number)

                when (name) {
                    "1", "HOME", "HOME WIN", "1ST" -> one = formatted
                    "X", "DRAW", "TIE" -> draw = formatted
                    "2", "AWAY", "AWAY WIN" -> two = formatted
                }
            }

            return if (one != null && draw != null && two != null) {
                Odds(one, draw, two)
            } else null
        }

        // Strong preference for explicit full-time / match-result / 1X2 labels.
        val preferred = candidates.sortedByDescending { obj ->
            val text = marketText(obj)
            when {
                Regex("""(^|[\s_/:-])(1x2|full\s*time|fulltime|match\s*result|match\s*winner)([\s_/:-]|$)""")
                    .containsMatchIn(text) -> 100
                text.contains("1x2") -> 90
                text.contains("full time") || text.contains("fulltime") -> 80
                text.contains("match result") || text.contains("match winner") -> 70
                else -> 0
            }
        }

        for (candidate in preferred) {
            val text = marketText(candidate)
            val rank = when {
                text.contains("1x2") -> 100
                text.contains("full time") || text.contains("fulltime") -> 90
                text.contains("match result") || text.contains("match winner") -> 80
                else -> 0
            }
            if (rank <= 0) continue

            parse1x2(candidate)?.let {
                Log.d("SofaScoreOdds", "1X2 MARKET SELECTED: event=$eventId market=$text")
                return it
            }
        }

        // Conservative fallback: only accept a choices set whose labels are
        // exactly the three 1/X/2 outcomes. This prevents unrelated markets
        // such as O/U, BTTS, corners, handicaps, etc. from being displayed.
        for (candidate in candidates) {
            val choices = candidate.optJSONArray("choices") ?: continue
            val labels = mutableSetOf<String>()
            for (i in 0 until choices.length()) {
                val c = choices.optJSONObject(i) ?: continue
                labels += c.optString("name").trim().uppercase()
            }
            val hasHome = labels.any { it == "1" || it == "HOME" || it == "HOME WIN" }
            val hasDraw = labels.any { it == "X" || it == "DRAW" || it == "TIE" }
            val hasAway = labels.any { it == "2" || it == "AWAY" || it == "AWAY WIN" }
            if (hasHome && hasDraw && hasAway) {
                parse1x2(candidate)?.let {
                    Log.d(
                        "SofaScoreOdds",
                        "1X2 LABEL FALLBACK: event=$eventId market=${marketText(candidate)}"
                    )
                    return it
                }
            }
        }

        return null
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$base/search/all?q=$query",
            "https://www.sofascore.com/",
            "https://www.sofascore.com"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase()
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result)
        }
        return out.sortedByDescending { it.date }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null
    )
}
