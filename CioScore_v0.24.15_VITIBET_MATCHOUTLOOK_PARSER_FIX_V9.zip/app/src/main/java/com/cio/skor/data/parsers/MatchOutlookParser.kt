package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Robust MatchOutlook parser for Home vs Away + Result: H-A markup. */
class MatchOutlookParser : BaseParser("MatchOutlook") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Prefer the smallest DOM nodes containing both fixture and correct score.
        val nodes = doc.select("body *")
            .filter { node ->
                val text = clean(node.text())
                Regex("(?i)\\bResult\\s*:\s*\\d{1,2}\\s*[-:]\\s*\\d{1,2}\\b").containsMatchIn(text) &&
                    Regex("(?i)\\b.+?\\s+vs\\s+.+?\\b").containsMatchIn(text)
            }
            .sortedBy { it.text().length }

        for (node in nodes) {
            parseNode(node)?.let { out[it.matchKey] = it }
            if (out.size >= 200) break
        }

        // Fallback: anchor-based route for pages where fixture and result live in
        // a linked card with the score in a parent/sibling element.
        if (out.isEmpty()) {
            for (link in doc.select("a[href]")) {
                val fixture = splitFixture(clean(link.text())) ?: continue
                var current: Element? = link
                repeat(10) {
                    val n = current ?: return@repeat
                    val score = extractResult(clean(n.text()))
                    if (score != null) {
                        build(fixture.first, fixture.second, score)?.let { out[it.matchKey] = it }
                        return@repeat
                    }
                    current = n.parent()
                }
            }
        }

        return out.values.toList()
    }

    private fun parseNode(node: Element): ScoreModel? {
        val text = clean(node.text())
        val fixtureMatch = Regex("(?i)(.+?)\\s+vs\\s+(.+?)(?=\\s+Result\\s*:|\\s+Best\\s+Bet|$)").find(text)
            ?: return null
        val score = extractResult(text) ?: return null
        return build(fixtureMatch.groupValues[1], fixtureMatch.groupValues[2], score)
    }

    private fun extractResult(text: String): String? = Regex(
        "(?i)\\bResult\\s*:\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun splitFixture(raw: String): Pair<String, String>? {
        val match = Regex("(?i)^(.+?)\\s+vs\\s+(.+)$").find(clean(raw)) ?: return null
        return match.groupValues[1].trim() to match.groupValues[2].trim()
    }

    private fun build(homeRaw: String, awayRaw: String, predictedScore: String): ScoreModel? {
        val home = team(homeRaw)
        val away = team(awayRaw)
        if (!valid(home, away)) return null
        return ScoreModel(homeTeam = home, awayTeam = away, predictedScore = predictedScore, source = source)
    }
}
