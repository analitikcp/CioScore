package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Robust Vitibet/Vitisport daily correct-score parser. */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Route 1: legacy table rows.
        for (row in doc.select("tr")) {
            parseRow(row)?.let { out[it.matchKey] = it }
        }

        // Route 2: modern/legacy card containers. We deliberately inspect
        // elements containing the score tip instead of relying on CSS classes.
        if (out.isEmpty()) {
            val nodes = doc.select("body *").filter { node ->
                val text = clean(node.text())
                Regex("(?i)\\b(?:Tip|Ipucu)\\s+\\d{1,2}\\s*[-:]\\s*\\d{1,2}\\b").containsMatchIn(text) &&
                    Regex("(?i)\\bINDEX\\b").containsMatchIn(text)
            }.sortedBy { it.text().length }

            for (node in nodes) {
                parseContainer(node)?.let { out[it.matchKey] = it }
                if (out.size >= 200) break
            }
        }

        return out.values.toList()
    }

    private fun parseRow(row: Element): ScoreModel? {
        val text = clean(row.text())
        val score = extractTipScore(text) ?: return null
        val cells = row.select("th, td")
        val links = row.select("a[href]").map { clean(it.text()) }
            .filter { it.length >= 2 && !isMeta(it) }.distinct()

        val fixture = when {
            links.size >= 2 -> links[0] to links[1]
            cells.size >= 2 -> fixtureFromCells(cells, score)
            else -> fixtureFromText(text)
        } ?: return null
        return build(fixture.first, fixture.second, score)
    }

    private fun parseContainer(element: Element): ScoreModel? {
        val text = clean(element.text())
        val score = extractTipScore(text) ?: return null
        val links = element.select("a[href]").map { clean(it.text()) }
            .filter { it.length >= 2 && !isMeta(it) }.distinct()
        val fixture = if (links.size >= 2) links[0] to links[1] else fixtureFromText(text)
        return fixture?.let { build(it.first, it.second, score) }
    }

    private fun extractTipScore(text: String): String? = Regex(
        "(?i)\\b(?:Tip|Ipucu)\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun fixtureFromCells(cells: List<Element>, score: String): Pair<String, String>? {
        val texts = cells.map { clean(it.text()) }
        val idx = texts.indexOfFirst { it.contains(Regex("(?i)\\b(?:Tip|Ipucu)\\s+${Regex.escape(score)}\\b")) }
        if (idx >= 2) {
            val home = texts[idx - 2]
            val away = texts[idx - 1]
            if (!isMeta(home) && !isMeta(away)) return home to away
        }
        return fixtureFromText(texts.joinToString(" "))
    }

    private fun fixtureFromText(text: String): Pair<String, String>? {
        // Typical current Vitibet sequence: time Home Away INDEX ... Tip H-A.
        val beforeIndex = Regex("(?i)^(.*?)\\bINDEX\\b").find(text)?.groupValues?.get(1)?.trim() ?: return null
        val withoutTime = beforeIndex.replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "").trim()
        val parts = withoutTime.split(Regex("\\s{2,}|\\s+(?=[A-Z][^ ]*\\s*$)"))
        if (parts.size >= 2) {
            val home = parts[0].trim()
            val away = parts.drop(1).joinToString(" ").trim()
            if (!isMeta(home) && !isMeta(away) && home.isNotBlank() && away.isNotBlank()) return home to away
        }
        return null
    }

    private fun build(homeRaw: String, awayRaw: String, score: String): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || isMeta(home) || isMeta(away)) return null
        return ScoreModel(homeTeam = home, awayTeam = away, predictedScore = score, source = source)
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(INDEX|Tip|Ipucu|LIVE|FT)\\b.*$"), "")
        .trim(' ', '-', ':', '|')

    private fun isMeta(value: String): Boolean = value.matches(
        Regex("(?i)^(score|tip|ipucu|index|1|x|2|prediction|predictions|scheduled|finished|live)$")
    ) || value.matches(Regex("^[0-9. %+:-]+$"))
}
