package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Bet365 1X2 source backed by WBookie.
 *
 * Performance contract:
 * - WBookie is fetched ONCE per date, never once per match.
 * - The complete Bet365 column is parsed into a date index.
 * - Match lookups are local and use the application's canonical team matcher.
 * - The same date/page/index cache is shared by all service instances in-process.
 */
class WBookieOddsService {
    data class Result(
        val odds: SofaScoreService.BookmakerOdds? = null,
        val source: String = "WBOOKIE",
        val reason: String = ""
    )

    private data class CachedPage(val expiresAt: Long, val html: String)
    private data class IndexedRow(
        val home: String,
        val away: String,
        val homeCanonical: String,
        val awayCanonical: String,
        val odds: List<String>
    )
    internal data class DateIndex(
        val rows: List<IndexedRow>,
        val byFixtureKey: Map<String, List<IndexedRow>>,
        val byToken: Map<String, List<IndexedRow>>
    )

    private val http = HttpClient()
    private val zone = ZoneId.systemDefault()

    companion object {
        private const val CACHE_TTL_MS = 3 * 60 * 1000L
        private val pageCache = ConcurrentHashMap<LocalDate, CachedPage>()
        private val indexCache = ConcurrentHashMap<LocalDate, DateIndex>()
    }

    /** Preload all required WBookie dates. Each distinct date causes at most one HTTP request. */
    suspend fun preload(kickoffEpochMs: Collection<Long>): Unit = withContext(Dispatchers.IO) {
        kickoffEpochMs.asSequence()
            .filter { it > 0L }
            .map { Instant.ofEpochMilli(it).atZone(zone).toLocalDate() }
            .distinct()
            .forEach { date -> ensureIndex(date) }
    }

    /** Local-only lookup after preload; will load the date on demand if needed. */
    suspend fun fetch(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result =
        withContext(Dispatchers.IO) {
            val date = Instant.ofEpochMilli(kickoffEpochMs).atZone(zone).toLocalDate()
            val index = ensureIndex(date) ?: return@withContext Result(
                reason = "WBookie tarih sayfası alınamadı"
            )
            lookup(index, homeTeam, awayTeam)
        }

    /** Synchronous local lookup for callers that already preloaded the dates. */
    fun lookup(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): Result {
        val date = Instant.ofEpochMilli(kickoffEpochMs).atZone(zone).toLocalDate()
        val index = indexCache[date] ?: return Result(reason = "WBookie tarihi preload edilmedi")
        return lookup(index, homeTeam, awayTeam)
    }

    private fun lookup(index: DateIndex, homeTeam: String, awayTeam: String): Result {
        val homeId = canonicalId(homeTeam)
        val awayId = canonicalId(awayTeam)
        if (homeId.isBlank() || awayId.isBlank()) return Result(reason = "Takım canonical kimliği boş")

        // Fast path: exact canonical HOME/AWAY fixture key.
        index.byFixtureKey["$homeId||$awayId"]?.firstOrNull()?.let { row ->
            return success(row.odds)
        }

        // Candidate reduction: require evidence from both team sides before fuzzy scoring.
        val homeTokens = homeId.split('-').filter { it.length >= 3 }.toSet()
        val awayTokens = awayId.split('-').filter { it.length >= 3 }.toSet()
        val candidates = if (homeTokens.isNotEmpty() && awayTokens.isNotEmpty()) {
            val homePool = homeTokens.flatMap { index.byToken[it].orEmpty() }.toSet()
            val awayPool = awayTokens.flatMap { index.byToken[it].orEmpty() }.toSet()
            homePool.intersect(awayPool).toList()
        } else emptyList()

        val pool = if (candidates.isNotEmpty()) candidates else index.rows
        val best = pool.asSequence()
            .map { row -> row to fixtureScore(homeTeam, awayTeam, row) }
            .filter { (_, score) -> score.accepted }
            .maxByOrNull { (_, score) -> score.total }
            ?.first

        return if (best != null) success(best.odds)
        else Result(reason = "WBookie'de Bet365 1X2 eşleşmesi bulunamadı")
    }

    private data class FixtureScore(val total: Double, val accepted: Boolean)

    private fun fixtureScore(home: String, away: String, row: IndexedRow): FixtureScore {
        val homeExact = MatchMerger.isSameTeam(home, row.home)
        val awayExact = MatchMerger.isSameTeam(away, row.away)
        if (homeExact && awayExact) return FixtureScore(1.0, true)

        val hs = TeamAliasCanonicalizer.similarity(home, row.home)
        val `as` = TeamAliasCanonicalizer.similarity(away, row.away)
        val accepted = hs >= 0.80 && `as` >= 0.80 && (hs + `as`) / 2.0 >= 0.84
        return FixtureScore((hs + `as`) / 2.0, accepted)
    }

    private fun success(odds: List<String>): Result =
        if (odds.size == 3 && odds.all(::isValidOdd)) {
            Result(
                odds = SofaScoreService.BookmakerOdds("Bet365", odds[0], odds[1], odds[2]),
                reason = "WBookie • Bet365 1X2"
            )
        } else Result(reason = "WBookie Bet365 oranları geçersiz")

    private suspend fun ensureIndex(date: LocalDate): DateIndex? {
        val now = System.currentTimeMillis()
        indexCache[date]?.let { return it }
        pageCache[date]?.takeIf { it.expiresAt > now }?.let { cached ->
            return parsePageIndex(cached.html).also { if (it != null) indexCache[date] = it }
        }

        val url = "https://www.wbookie.com/en/odds?date=${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}"
        val (code, body) = http.getSource(url, "https://www.wbookie.com/en/odds")
        if (code !in 200..299 || body.isNullOrBlank()) return null
        pageCache[date] = CachedPage(now + CACHE_TTL_MS, body)
        return parsePageIndex(body).also { if (it != null) indexCache[date] = it }
    }

    internal fun parsePage(html: String, homeTeam: String, awayTeam: String): List<String>? {
        val index = parsePageIndex(html) ?: return null
        return lookup(index, homeTeam, awayTeam).odds?.let { listOf(it.ms1, it.msX, it.ms2) }
    }

    internal fun parsePageIndex(html: String): DateIndex? {
        val document = Jsoup.parse(html, "https://www.wbookie.com/en/odds")
        val parsed = ArrayList<IndexedRow>()

        for (table in document.select("table")) {
            val header = table.select("tr").firstOrNull { row ->
                row.select("th,td").any { it.text().trim().equals("Bet365", true) } &&
                    row.select("th,td").any { it.text().contains("Pick", true) }
            } ?: continue
            val cells = header.select("th,td")
            val bet365Index = cells.indexOfFirst { it.text().trim().equals("Bet365", true) }
            if (bet365Index < 0) continue

            val rows = table.select("tr")
            val headerIndex = rows.indexOf(header)
            for (row in rows.drop(headerIndex + 1)) {
                val rowCells = row.select("td,th")
                if (rowCells.size <= bet365Index) continue
                val pair = extractTeams(row) ?: continue
                val odds = extractOdds(rowCells[bet365Index])
                if (odds.size != 3 || odds.any { !isValidOdd(it) }) continue
                parsed += IndexedRow(
                    home = pair.first,
                    away = pair.second,
                    homeCanonical = canonicalId(pair.first),
                    awayCanonical = canonicalId(pair.second),
                    odds = odds
                )
            }
        }

        if (parsed.isEmpty()) return null
        val byFixture = HashMap<String, MutableList<IndexedRow>>()
        val byToken = HashMap<String, MutableList<IndexedRow>>()
        parsed.forEach { row ->
            val key = "${row.homeCanonical}||${row.awayCanonical}"
            byFixture.getOrPut(key) { mutableListOf() }.add(row)
            (row.homeCanonical.split('-') + row.awayCanonical.split('-'))
                .filter { it.length >= 3 }
                .distinct()
                .forEach { token -> byToken.getOrPut(token) { mutableListOf() }.add(row) }
        }
        return DateIndex(parsed, byFixture, byToken)
    }

    private fun extractTeams(row: Element): Pair<String, String>? {
        val matchLinks = row.select("a").map { it.text().trim() }.filter { it.isNotBlank() }
        if (matchLinks.size >= 2) {
            val likely = matchLinks.filterNot { it.startsWith("Compare", true) }
            if (likely.size >= 2) return likely.first() to likely[1]
        }

        val pickCell = row.select("td,th").getOrNull(1)
        val pickText = pickCell?.text()?.replace(Regex("\\s+"), " ")?.trim().orEmpty()
        val m = Regex("^1\\s*[·•.]\\s*(.*?)\\s+X\\s*[·•.]\\s*(?:Draw|Nul|Tie|Empate)\\s+2\\s*[·•.]\\s*(.*)$", RegexOption.IGNORE_CASE).find(pickText)
        if (m != null) return m.groupValues[1].trim() to m.groupValues[2].trim()
        return null
    }

    private fun extractOdds(cell: Element): List<String> =
        Regex("(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])")
            .findAll(cell.text())
            .map { it.value.replace(',', '.') }
            .toList()
            .take(3)

    private fun isValidOdd(value: String): Boolean =
        value.toDoubleOrNull()?.let { it > 1.0 && it <= 1000.0 } == true

    private fun canonicalId(value: String): String =
        TeamAliasCanonicalizer.identityForProvider("WBOOKIE", "", value).canonicalId
}
