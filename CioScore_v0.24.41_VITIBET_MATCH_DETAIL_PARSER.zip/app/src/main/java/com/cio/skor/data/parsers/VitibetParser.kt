package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Vitibet parser.
 *
 * IMPORTANT: the current Vitibet "new" quicktips page renders each fixture as
 * a dedicated match-detail anchor. The old parser walked generic div/li nodes
 * and took the first two links it found; that can pair a league link with a
 * team link and silently create hundreds of valid-looking but wrong fixtures.
 *
 * Primary path: parse only match-detail anchors.
 * Secondary path: parse the stable legacy table rows when the old design is
 * returned by Vitibet/WAF/cache.
 */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // CURRENT VITIBET DESIGN ------------------------------------------------
        // Each fixture is a dedicated <a ...clanek=match-detail...> element.
        // Never use a surrounding generic div here: it may also contain the
        // league link and therefore corrupt HOME/AWAY extraction.
        for (link in doc.select("a[href*='clanek=match-detail']")) {
            parseMatchDetailAnchor(link)?.let { out[it.matchKey] = it }
        }

        // LEGACY TABLE FALLBACK --------------------------------------------------
        // The old Vitibet page exposes real table cells:
        // date | | HOME | AWAY | | H | : | A | 1% | X% | 2% | tip | index
        if (out.isEmpty()) {
            for (row in doc.select("tr")) {
                parseLegacyRow(row)?.let { out[it.matchKey] = it }
            }
        }

        return out.values.toList()
    }

    private fun parseMatchDetailAnchor(link: Element): ScoreModel? {
        val text = clean(link.text())
        val predicted = extractTipScore(text) ?: return null

        val fixtureId = Regex("(?i)[?&]fixture_id=(\\d+)")
            .find(link.attr("href"))?.groupValues?.getOrNull(1).orEmpty()

        // Prefer explicit team/home/away elements if the current HTML exposes
        // them. We deliberately inspect leaf-ish descendants so parent nodes
        // containing the whole row are not mistaken for a team name.
        val explicitTeams = linkedTeamCandidates(link)
        if (explicitTeams.size >= 2) {
            return build(
                explicitTeams[0],
                explicitTeams[1],
                predicted,
                fixtureId
            )
        }

        // Some Vitibet variants render the team labels as direct text nodes.
        // In that case remove the metadata suffix and split the remaining
        // fixture text at the boundary immediately before INDEX. A conservative
        // token split is used only when one side can be validated as a team.
        val indexPos = Regex("(?i)\\bINDEX\\b").find(text)?.range?.first ?: text.length
        val beforeIndex = text.substring(0, indexPos).trim()
            .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
            .replace(Regex("(?i)\\s+(?:LIVE|FT)\\s+\\d{1,2}-\\d{1,2}\\s*$"), "")
            .trim()

        val split = splitFixtureText(beforeIndex) ?: return null
        return build(split.first, split.second, predicted, fixtureId)
    }

    /**
     * Collect likely team labels from nested HTML without accepting the entire
     * match row as one candidate. If Vitibet changes span/div nesting, this
     * remains more stable than a CSS-class dependency.
     */
    private fun linkedTeamCandidates(link: Element): List<String> {
        val candidates = mutableListOf<String>()

        fun consider(element: Element) {
            val raw = clean(element.text())
            if (!isTeamCandidate(raw)) return
            if (raw.length > 70) return
            if (Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica)\\b").containsMatchIn(raw)) return
            if (Regex("\\b\\d{1,3}%\\b").containsMatchIn(raw)) return
            if (Regex("(?i)^\\d{1,2}:\\d{2}$").matches(raw)) return
            if (Regex("^\\d{1,2}\\s*[-:]\\s*\\d{1,2}$").matches(raw)) return
            candidates += raw
        }

        // Prefer elements explicitly marked as home/away/team when present.
        link.select("[class*=team], [class*=home], [class*=away], [data-team], [data-home], [data-away]")
            .forEach(::consider)

        if (candidates.size < 2) {
            // Then inspect leaf-ish descendants. Parent nodes often contain the
            // entire row, so only nodes without element children are considered.
            for (element in link.select("span, strong, b, em, i, div, td")) {
                if (element.children().isEmpty()) consider(element)
            }
        }

        return candidates
            .map { cleanTeam(it) }
            .filter { isTeamCandidate(it) }
            .distinct()
    }

    private fun splitFixtureText(raw: String): Pair<String, String>? {
        val value = clean(raw)
        if (value.isBlank()) return null

        // The new page text is "HOME AWAY" with no delimiter. Prefer a
        // conservative list of known club suffixes as a boundary signal.
        val boundaryPatterns = listOf(
            Regex("(?i)^(.+\\b(?:FC|CF|SC|SK|FK|AC|AS|CD|AFC|BFC|United|City|Town|Rovers|Racing|Sporting|Club|Calcio|1899|1907|PSV|Ajax|Roma|Milan|Inter|Leipzig|Liverpool|Arsenal|Chelsea|Madrid|Barcelona|Valencia|Villarreal|Levante))\\s+(.+)$"),
            Regex("(?i)^(.+?)\\s+(FC|CF|SC|SK|FK|AC|AS|CD|AFC|BFC|United|City|Town|Rovers|Racing|Sporting|Club|Calcio)\\s+(.+)$")
        )

        for (pattern in boundaryPatterns) {
            val m = pattern.find(value) ?: continue
            val home = if (m.groupValues.size == 3) m.groupValues[1] else "${m.groupValues[1]} ${m.groupValues[2]}"
            val away = if (m.groupValues.size == 3) m.groupValues[2] else m.groupValues[3]
            if (isTeamCandidate(home) && isTeamCandidate(away) && !home.equals(away, true)) {
                return cleanTeam(home) to cleanTeam(away)
            }
        }

        return null
    }

    private fun parseLegacyRow(row: Element): ScoreModel? {
        val cells = row.select("th, td")
            .map { clean(it.text()) }
            .filter { it.isNotBlank() }
        if (cells.size < 7) return null

        val dateIndex = cells.indexOfFirst { Regex("^\\d{1,2}\\.\\d{1,2}\\.?$").matches(it) }
        if (dateIndex < 0) return null

        val scoreIndex = (dateIndex + 1 until cells.size - 2).firstOrNull { i ->
            i + 2 < cells.size &&
                cells[i].matches(Regex("^\\d{1,2}$")) &&
                cells[i + 1] == ":" &&
                cells[i + 2].matches(Regex("^\\d{1,2}$"))
        } ?: return null

        val teamCells = cells.subList(dateIndex + 1, scoreIndex)
            .filter { isTeamCandidate(it) && !it.matches(Regex("^\\d+(?:\\.\\d+)?%?$")) }
        if (teamCells.size < 2) return null

        val home = cleanTeam(teamCells[teamCells.size - 2])
        val away = cleanTeam(teamCells[teamCells.size - 1])
        val score = "${cells[scoreIndex].toIntOrNull() ?: return null}-${cells[scoreIndex + 2].toIntOrNull() ?: return null}"
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null

        val fixtureId = row.select("a[href*='fixture_id=']")
            .firstOrNull()?.attr("href")?.let {
                Regex("(?i)[?&]fixture_id=(\\d+)").find(it)?.groupValues?.getOrNull(1)
            }.orEmpty()

        return build(home, away, score, fixtureId)
    }

    private fun extractTipScore(text: String): String? = Regex(
        "(?i)\\b(?:Tip|Ipucu|Vihje|Dica)\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
    ).find(text)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    private fun build(
        homeRaw: String,
        awayRaw: String,
        score: String,
        sourceMatchId: String = ""
    ): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || !isTeamCandidate(home) || !isTeamCandidate(away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            sourceMatchId = sourceMatchId
        )
    }

    private fun isTeamCandidate(value: String): Boolean {
        val t = cleanTeam(value)
        if (t.length !in 2..70) return false
        if (t.matches(Regex("^[0-9 .:%+\\-]+$"))) return false
        if (Regex("(?i)^(index|tip|ipucu|vihje|dica|odds|status|live|ft|prediction|score|1|0|2)$").matches(t)) return false
        if (Regex("(?i)^(premier league|bundesliga|la liga|serie a|ligue 1|eredivisie)$").matches(t)) return false
        return true
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(?:INDEX|Tip|Ipucu|Vihje|Dica|LIVE|FT|Odds|Status)\\b.*$"), "")
        .trim(' ', '-', ':', '|')
}
