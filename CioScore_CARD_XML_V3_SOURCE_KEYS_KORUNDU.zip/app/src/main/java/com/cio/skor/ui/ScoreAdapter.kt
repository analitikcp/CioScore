package com.cio.skor.ui

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.R
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

/** UI adapter. Backend/source keys are NEVER changed here; only labels are masked when rendered. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(initialList: List<MatchGroup> = emptyList()) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val home: TextView = view.findViewById(R.id.tvHome)
        val away: TextView = view.findViewById(R.id.tvAway)
        val consensusLabel: TextView = view.findViewById(R.id.tvConsensusLabel)
        val consensusScore: TextView = view.findViewById(R.id.tvConsensusScore)
        val consensusBadge: TextView = view.findViewById(R.id.tvConsensusBadge)
        val predictions: LinearLayout = view.findViewById(R.id.predictionsContainer)
    }

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5",
        "forebet" to "cio6"
    )

    // IMPORTANT: this is display-only. ScoreModel.source stays unchanged.
    private fun displaySourceName(source: String): String =
        sourceLabels[source.trim().lowercase()] ?: source.trim()

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)
        displayedList = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_match, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val match = displayedList[position]
        holder.home.text = match.homeTeam
        holder.away.text = match.awayTeam
        holder.predictions.removeAllViews()

        val counts = match.predictions.groupingBy { it.predictedScore.trim() }.eachCount()
        val consensus = counts.entries.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key }
        )

        val showConsensus = consensus != null && match.predictions.size > 1
        holder.consensusLabel.visibility = if (showConsensus) View.VISIBLE else View.GONE
        holder.consensusScore.visibility = if (showConsensus) View.VISIBLE else View.GONE
        holder.consensusBadge.visibility = if (showConsensus) View.VISIBLE else View.GONE

        if (showConsensus && consensus != null) {
            holder.consensusScore.text = consensus.key
            holder.consensusBadge.text = "${consensus.value}/${match.predictions.size} kaynak"
        }

        match.predictions.forEach { prediction ->
            val row = LinearLayout(holder.itemView.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                minimumHeight = 40.dp()
                setPadding(0, 3.dp(), 0, 3.dp())
            }

            val source = TextView(context).apply {
                // ONLY UI masking: original prediction.source remains untouched.
                text = displaySourceName(prediction.source)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF101828.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            row.addView(source, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val arrow = TextView(context).apply {
                text = "→"
                textSize = 15f
                setTextColor(0xFF667085.toInt())
                gravity = android.view.Gravity.CENTER
            }
            row.addView(arrow, LinearLayout.LayoutParams(28.dp(), ViewGroup.LayoutParams.WRAP_CONTENT))

            val score = TextView(context).apply {
                text = prediction.predictedScore.trim()
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(0xFF101828.toInt())
                gravity = android.view.Gravity.CENTER
            }
            row.addView(score, LinearLayout.LayoutParams(54.dp(), ViewGroup.LayoutParams.WRAP_CONTENT))

            holder.predictions.addView(row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
    }

    private fun Int.dp(): Int =
        (this * android.content.res.Resources.getSystem().displayMetrics.density).toInt()
}
