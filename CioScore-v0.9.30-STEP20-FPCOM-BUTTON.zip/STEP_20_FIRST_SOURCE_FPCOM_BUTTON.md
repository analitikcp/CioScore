# STEP 20 — FP.com visible AÇ button

Version: 0.9.30

The first source row (FP.com) now has an explicitly sized, visible Android Button labeled `AÇ`.
Its click target is explicitly `https://footballpredictions.com/betting-tips/correct-score/`.
The row remains clickable as well.
