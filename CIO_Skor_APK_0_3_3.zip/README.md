# CIO Skor 0.3.3

CIO Skor — Skorun Merkezi.

Android uygulaması için temel proje ve 16 skor kaynağı listesi.
