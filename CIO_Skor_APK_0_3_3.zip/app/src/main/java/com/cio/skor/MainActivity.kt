package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.graphics.Typeface

data class Source(val name: String, val url: String)

class MainActivity : Activity() {

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        Source("PredictZ", "https://www.predictz.com/predictions/DATE/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/DATE/all-games/all-stakes/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 15, 20))
            setPadding(28, 30, 28, 20)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SKOR"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "16 kaynak • doğru skor merkezi"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 24)
        }
        root.addView(sub)

        val today = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 17f
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "İlk sürüm: kaynak tarama altyapısı hazırlanıyor.",
                    Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(today)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        sources.forEachIndexed { i, source ->
            val b = Button(this).apply {
                text = "${i + 1}. ${source.name}"
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { openSource(source) }
            }
            list.addView(b, LinearLayout.LayoutParams(-1, 56).apply {
                setMargins(0, 5, 0, 5)
            })
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openSource(source: Source) {
        val web = WebView(this)
        web.webViewClient = WebViewClient()
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString =
                "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36"
        }

        val back = Button(this).apply {
            text = "← Kaynaklara dön"
            setOnClickListener { showHome() }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(back, LinearLayout.LayoutParams(-1, 54))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        }

        setContentView(box)
        web.loadUrl(source.url)
    }
}
