package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** ScoreVoro correct-score parser; supports normal hyphen and Unicode dashes. */
class ScoreVoroParser : BaseParser("ScoreVoro") {
    private val score = Regex("(?<!\\d)([0-5])\\s*[-–—:]\\s*([0-5])(?!\\d)")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val candidates = doc.select("article, section, li, div[class*=card], div[class*=tip], div[class*=match], div[class*=fixture]")
        for (el in candidates.sortedBy { it.text().length }) {
            val raw = clean(el.text())
            if (raw.length !in 25..1800 || !raw.contains("Correct Score", true)) continue
            val marker = Regex("(?i)correct\\s*score").find(raw) ?: continue
            val tail = raw.substring(marker.range.last + 1, minOf(raw.length, marker.range.last + 180))
            val m = score.find(tail) ?: continue
            val predicted = "${m.groupValues[1]}-${m.groupValues[2]}"
            val pair = extractTeams(el, raw, marker.range.first) ?: continue
            val home = team(pair.first); val away = team(pair.second)
            if (!valid(home, away)) continue
            val model = ScoreModel(home, away, predicted, source)
            out[model.matchKey] = model
            if (out.size >= 250) break
        }
        return out.values.toList()
    }

    private fun extractTeams(el: Element, raw: String, marker: Int): Pair<String, String>? {
        val imageTeams = el.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("aria-label")) }
            .map(::clean).filter { looksLikeTeam(it) }.distinct()
        if (imageTeams.size >= 2) return imageTeams.take(2)[0] to imageTeams.take(2)[1]

        val links = el.select("a").map { clean(it.text()) }.filter(::looksLikeTeam).distinct()
        if (links.size >= 2) return links.take(2)[0] to links.take(2)[1]

        val before = raw.substring(0, marker).trim()
        for (sep in listOf(" vs ", " v ", " – ", " — ", " - ")) {
            val i = before.lastIndexOf(sep, true)
            if (i > 0) {
                val h = before.substring(0, i).trim().takeLast(90)
                val a = before.substring(i + sep.length).trim().take(90)
                if (looksLikeTeam(h) && looksLikeTeam(a)) return h to a
            }
        }
        return null
    }

    private fun looksLikeTeam(s: String): Boolean {
        val v = clean(s)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:%+/-]+$"))) return false
        return !Regex("(?i)^(correct score|today|match info|related tips|odds|score probability|avg goals|tips today|champions league|other)$").matches(v)
    }
}
