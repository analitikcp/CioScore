package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** ProTipster correct-score parser. Empty active tips is a valid zero-result state. */
class ProTipsterParser : BaseParser("ProTipster") {
    private val score = Regex("(?i)(?:correct\\s*score(?:\\s+regular\\s*time)?|market:\s*correct\\s*score)[^0-9]{0,100}([0-5])\\s*[-–—:]\\s*([0-5])")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val candidates = doc.select("article, section, li, div[class*=tip], div[class*=card], div[class*=match], div[class*=fixture]")
        for (el in candidates.sortedBy { it.text().length }) {
            val raw = clean(el.text())
            if (raw.length !in 25..2200 || !raw.contains("correct score", true)) continue
            val sm = score.find(raw) ?: continue
            val predicted = "${sm.groupValues[1]}-${sm.groupValues[2]}"
            val pair = extractTeams(el, raw, sm.range.first) ?: continue
            val home = team(pair.first); val away = team(pair.second)
            if (!valid(home, away)) continue
            val model = ScoreModel(home, away, predicted, source)
            out[model.matchKey] = model
            if (out.size >= 250) break
        }
        return out.values.toList()
    }

    private fun extractTeams(el: Element, raw: String, scorePos: Int): Pair<String, String>? {
        val links = el.select("a").map { clean(it.text()) }.filter(::looksLikeTeam).distinct()
        if (links.size >= 2) return links.take(2)[0] to links.take(2)[1]
        val images = el.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("aria-label")) }
            .map(::clean).filter(::looksLikeTeam).distinct()
        if (images.size >= 2) return images.take(2)[0] to images.take(2)[1]

        val before = raw.substring(0, scorePos).trim()
        for (sep in listOf(" vs ", " v ", " VS ", " – ", " — ", " - ")) {
            val i = before.lastIndexOf(sep, true)
            if (i > 0) {
                val h = before.substring(0, i).trim().takeLast(90)
                val a = before.substring(i + sep.length).trim().take(90)
                if (looksLikeTeam(h) && looksLikeTeam(a)) return h to a
            }
        }
        return null
    }

    private fun looksLikeTeam(s: String): Boolean {
        val v = clean(s)
        if (v.length !in 2..80) return false
        if (v.matches(Regex("^[0-9 .:%+/-]+$"))) return false
        return !Regex("(?i)^(correct score|market|tipster|odds|show reasoning|today|tomorrow|football|all football|best tip|tips)$").matches(v)
    }
}
