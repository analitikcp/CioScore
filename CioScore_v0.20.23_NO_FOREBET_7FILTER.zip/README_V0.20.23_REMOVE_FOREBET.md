# CioScore v0.20.23 — Forebet kaldırıldı

- Forebet (6. kaynak) tamamen çıkarıldı.
- Aktif doğru skor kaynağı sayısı 8’den 7’ye indirildi.
- Yeni sıra: FP.com, PredictZ, WinDrawWin, SoccerSeer, DailySports, ScoreVoro, ProTipster.
- ScoreVoro artık Filtre6, ProTipster Filtre7.
- Ekrandaki kaynak durumu artık X/7 olarak gösterilir.
- Forebet için parser dosyası projeden kaldırıldı.
- “En Çok Oynananlar” bölümü bu sürümde eklenmedi.
