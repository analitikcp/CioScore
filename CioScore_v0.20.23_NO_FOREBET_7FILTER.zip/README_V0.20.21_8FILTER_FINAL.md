# CioScore v0.20.21 – 8 Kaynak Final

## Uygulanan değişiklikler
- 5 mevcut doğru skor kaynağı korunmuştur.
- Filtre6 = Forebet eklendi.
- Filtre7 = ScoreVoro eklendi.
- Filtre8 = ProTipster eklendi.
- Forebet parser: `Correct score` kolonunu önceliklendirir; Unicode tire ve fallback takım ayrıştırma desteği içerir.
- ScoreVoro parser: `Correct Score` kartlarını tarar; `-`, `–`, `—`, `:` skor ayraçlarını destekler.
- ProTipster parser: `Correct score regular time` / `Market: Correct score` alanlarını destekler. Aktif doğru skor yoksa bu durum hata değil, 0 sonuç olarak raporlanır.
- Filtre durumu UI'ya eklendi: `Filtre durumu: X/8 filtreden veri çekildi`.
- Her filtre için sonuç sayısı / 0 sonuç / HTTP hata durumu gösterilir.
- ScoreAdapter kaynak etiketleri Filtre1–Filtre8 olacak şekilde genişletildi.
- HTTP referer'ları yeni 3 kaynak için eklendi.
- BaseParser skor regex'i Unicode dash karakterlerini destekleyecek şekilde genişletildi.

## Teşhis mantığı
- `✓ N`: kaynak HTTP ile ulaşıldı ve parser N tahmin çıkardı.
- `⚠ 0`: HTTP başarılı fakat parser aktif doğru skor bulamadı; kaynak gerçekten boş olabilir veya DOM/parser değişmiş olabilir.
- `✕ CODE`: HTTP/erişim hatası veya istek hatası.

## Not
Bu ortamda Android Gradle Wrapper/Gradle executable bulunmadığından APK derleme testi çalıştırılamadı. ZIP kaynak bütünlüğü kontrol edilmiştir.
