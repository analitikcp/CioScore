package com.cio.skor.data

import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.Locale

/** Normalized record used by source-specific JSON parsers. */
data class PopularBetItem(
    val homeTeam: String,
    val awayTeam: String,
    val prediction: String,
    val playCount: Long,
    val ratio: String
)

class IddaaParser {
    fun parse(jsonResponse: String): List<PopularBetItem> {
        val list = mutableListOf<PopularBetItem>()
        runCatching {
            val root = JSONObject(jsonResponse)
            val dataArray = root.optJSONArray("data") ?: return@runCatching
            for (i in 0 until dataArray.length()) {
                val item = dataArray.optJSONObject(i) ?: continue
                val match = item.optJSONObject("match")
                val home = match?.optString("homeTeam").orEmpty()
                val away = match?.optString("awayTeam").orEmpty()
                val betType = item.optString("predictionName")
                val count = item.optLong("playedCount", 0L)
                val odds = item.optString("odds", "0.00")
                if (home.isNotBlank() && away.isNotBlank()) {
                    list += PopularBetItem(home, away, betType, count, odds)
                }
            }
        }
        return list
    }
}

class BilyonerParser {
    fun parse(jsonResponse: String): List<PopularBetItem> {
        val list = mutableListOf<PopularBetItem>()
        runCatching {
            val root = JSONObject(jsonResponse)
            val events = root.optJSONArray("events") ?: return@runCatching
            for (i in 0 until events.length()) {
                val obj = events.optJSONObject(i) ?: continue
                val home = obj.optString("homeName")
                val away = obj.optString("awayName")
                val selection = obj.optString("marketValue")
                val playedCount = obj.optLong("couponCount", 0L)
                val odds = obj.optDouble("ratio", 0.0).takeIf { it > 0.0 }?.toString().orEmpty()
                if (home.isNotBlank() && away.isNotBlank()) {
                    list += PopularBetItem(home, away, selection, playedCount, odds)
                }
            }
        }
        return list
    }
}

class NesineParser {
    fun parseHtml(htmlContent: String): List<PopularBetItem> = PopularBetHtmlHeuristics.parse(htmlContent, "Nesine")
}

class MisliParser {
    fun parse(jsonResponse: String): List<PopularBetItem> {
        val list = mutableListOf<PopularBetItem>()
        runCatching {
            val root = JSONObject(jsonResponse)
            val bets = root.optJSONArray("data") ?: root.optJSONArray("bets") ?: return@runCatching
            for (i in 0 until bets.length()) {
                val betObj = bets.optJSONObject(i) ?: continue
                val home = betObj.optString("homeTeamName")
                val away = betObj.optString("awayTeamName")
                val outcome = betObj.optString("outcomeName")
                val played = betObj.optLong("totalPlayed", 0L)
                val odds = betObj.optString("rate", "0.00")
                if (home.isNotBlank() && away.isNotBlank()) {
                    list += PopularBetItem(home, away, outcome, played, odds)
                }
            }
        }
        return list
    }
}

/**
 * Fallback for rendered HTML. It deliberately uses visible text rather than
 * undocumented CSS class names, because the four sites frequently change
 * generated class names in their SPA bundles.
 */
object PopularBetHtmlHeuristics {
    private val marketTokens = listOf(
        "MS 1", "MS X", "MS 2", "MAÇ SONUCU", "TOPLAM GOL", "ALT/ÜST", "ALT/ÜST 2.5",
        "2,5 ÜST", "2.5 ÜST", "2,5 ALT", "2.5 ALT", "KARŞILIKLI GOL", "KG VAR", "KG YOK",
        "EV. GOL", "1.Y GOL", "1. Y GOL"
    )

    fun parse(html: String, source: String): List<PopularBetItem> {
        if (html.isBlank()) return emptyList()
        val doc = Jsoup.parse(html)
        val result = LinkedHashMap<String, PopularBetItem>()

        // First pass: rows/cards containing an explicit "played" counter.
        val counterRegex = Regex("(?i)\\b\\d[\\d.\\s,+]*\\s*(?:kez\\s*oynandi|kez\\s*oynandı|oynandi|oynandı)")
        for (counter in doc.getAllElements()) {
            if (!counterRegex.containsMatchIn(counter.text())) continue
            val container = nearestUsefulContainer(counter)
            addCandidate(container, source, result, requireCounter = true)
        }

        // Nesine's table may display the play count under an "Oynanma" column
        // without the words "kez oynandı". Parse table rows as a second pass.
        for (row in doc.select("tr")) {
            addCandidate(row, source, result, requireCounter = false)
        }

        return result.values.toList()
    }

    private fun nearestUsefulContainer(start: Element): Element {
        var node: Element = start
        repeat(5) {
            val text = clean(node.text())
            if (text.length in 25..700 && text.contains(" - ")) return node
            node = node.parent() ?: return node
        }
        return start
    }

    private fun addCandidate(
        element: Element?,
        source: String,
        result: MutableMap<String, PopularBetItem>,
        requireCounter: Boolean
    ) {
        if (element == null) return
        val text = clean(element.text())
        if (text.length < 15) return
        val pair = findTeamPair(text) ?: return
        val count = extractPlayCount(text)
        if (requireCounter && count <= 0L) return
        if (!requireCounter && count <= 0L) return
        val market = findMarket(text)
        val odds = extractOdds(text)
        val key = "${pair.first}|${pair.second}|${market.lowercase(Locale.ROOT)}|$source"
        result.putIfAbsent(key, PopularBetItem(pair.first, pair.second, market, count, odds))
    }

    private fun findTeamPair(text: String): Pair<String, String>? {
        val compact = text.replace(Regex("\\s+"), " ").trim()
        val match = Regex("([^|]{2,80}?)\\s+-\\s+([^|]{2,80}?)(?=\\s+(?:TV|Maç|MAC|Maç Sonucu|Karşılıklı|Toplam|Alt/Üst|MS\\b|\\d+(?:[.,]\\d+)?\\s*(?:Kez|kez|kez oynandı|oynandı))|$)", RegexOption.IGNORE_CASE).find(compact)
            ?: Regex("([^|]{2,80}?)\\s+-\\s+([^|]{2,80}?)(?:\\s{2,}|$)", RegexOption.IGNORE_CASE).find(compact)
        if (match == null) return null
        val home = match.groupValues[1].trim(' ', '-', ':')
        val away = match.groupValues[2].trim(' ', '-', ':')
        if (home.length < 2 || away.length < 2) return null
        if (home.contains("Bugün", true) || away.contains("Bugün", true)) return null
        return home to away
    }

    private fun extractPlayCount(text: String): Long {
        val explicit = Regex("(?i)(\\d[\\d.\\s,+]*)\\s*(?:kez\\s*oynandı|kez\\s*oynandi|kez|oynandı|oynandi)").find(text)
        explicit?.groupValues?.getOrNull(1)?.let { parseCount(it) }?.let { if (it > 0) return it }

        // Nesine-style rows: choose the largest integer-like number > 1000,
        // ignoring decimal odds such as 1.55.
        val candidates = Regex("(?<![\\d.,])\\d{1,3}(?:[.]\\d{3})+(?![\\d.,])|(?<![\\d.,])\\d{4,}(?![\\d.,])")
            .findAll(text)
            .mapNotNull { parseCount(it.value) }
            .filter { it >= 1000 }
            .toList()
        return candidates.maxOrNull() ?: 0L
    }

    private fun parseCount(value: String): Long = value.replace(".", "").replace(",", "").replace(" ", "").toLongOrNull() ?: 0L

    private fun findMarket(text: String): String {
        val upper = text.uppercase(Locale("tr", "TR"))
        return marketTokens.firstOrNull { upper.contains(it) } ?: "Popüler tercih"
    }

    private fun extractOdds(text: String): String = Regex("(?<!\\d)\\d+[.,]\\d{2}(?!\\d)").find(text)?.value.orEmpty()

    private fun clean(text: String): String = text.replace(Regex("\\s+"), " ").trim()
}

internal fun PopularBetItem.toModel(source: String): PopularBetModel = PopularBetModel(
    sourceName = source,
    rawHomeTeam = homeTeam,
    rawAwayTeam = awayTeam,
    prediction = prediction,
    ratioOrCount = playCount.toString(),
    odds = ratio,
)
