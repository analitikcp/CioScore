# CIO Skor 0.4.3

16 kaynaklı doğru skor tarama uygulaması.

- Otomatik tarama
- Kaynak bazlı HTTP durumu
- Kaynak bazlı temiz skor ayrıştırma
- Ortak skor konsensüsü
- Ham sayfa metni yerine temiz maç/skor gösterimi

Not: 403/429 veya SSL sertifika hataları kaynak erişim problemidir; uygulama bunları veri gibi göstermemektedir.
