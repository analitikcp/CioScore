package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.net.HttpURLConnection
import java.net.URL
import java.util.LinkedHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Prediction(val home: String, val away: String, val score: String)
private data class Result(
    val name: String,
    val code: Int,
    val predictions: List<Prediction>,
    val error: String? = null
)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button
    private lateinit var statusText: TextView
    private lateinit var consensusBox: LinearLayout

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    private val scorePattern = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
    private val pairPattern = Regex("(?iu)([\\p{L}\\p{N}][\\p{L}\\p{N} .&'’()/-]{1,70}?)\\s+(?:v|vs|versus)\\s+([\\p{L}\\p{N}][\\p{L}\\p{N} .&'’()/-]{1,70}?)(?=\\s+(?:Correct|Predicted|Exact|Score|Analysis|MATCH|Odds|$))")
    private val labelScorePattern = Regex("(?iu)(?:correct\\s*score|predicted\\s*score(?:line)?|exact\\s*score|scoreline|best)\\s*[:→-]?\\s*([0-5])\\s*[-:]\\s*([0-5])")
    private val scoreBeforeLabelPattern = Regex("(?iu)([0-5])\\s*[-:]\\s*([0-5])\\s+(?:correct\\s*score|predicted\\s*score(?:line)?|exact\\s*score|scoreline)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 11, 16))
            setPadding(14, 12, 14, 8)
        }

        root.addView(TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 17f
            setTextColor(Color.LTGRAY)
            setPadding(0, 2, 0, 7)
        })

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 16f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(Color.rgb(35, 125, 68), 10)
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 52))

        statusText = TextView(this).apply {
            text = "Hazır"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 5)
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showInitialRows()
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        consensusBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 9, 10, 9)
            setBackgroundColor(Color.rgb(18, 38, 26))
        }
        consensusBox.addView(TextView(this).apply {
            text = "🎯 SKOR BİRLEŞTİRME"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        consensusBox.addView(TextView(this).apply {
            text = "Tarama sonunda en az 2 kaynağın ortak gördüğü skorlar burada."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 0)
        })
        resultBox.addView(consensusBox)
        sources.forEachIndexed { i, s -> resultBox.addView(row("${i + 1}. ${s.name}", "⏳ Henüz taranmadı")) }
    }

    private fun scanAll() {
        try {
            scanButton.isEnabled = false
        scanButton.text = "⏳  TARANIYOR..."
        scanButton.background = rounded(Color.rgb(55, 62, 70), 10)
        statusText.text = "🌐 16 kaynak paralel taranıyor..."
        showInitialRows()

        val rows = HashMap<String, TextView>()
        for (i in 1 until resultBox.childCount) {
            val box = resultBox.getChildAt(i) as LinearLayout
            rows[sources[i - 1].name] = box.getChildAt(1) as TextView
        }

        val results = LinkedHashMap<String, Result>()
        val done = AtomicInteger(0)
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                runOnUiThread {
                    results[source.name] = result
                    rows[source.name]?.apply {
                        text = formatResult(result)
                        setTextColor(
                            when {
                                result.predictions.isNotEmpty() -> Color.rgb(75, 235, 135)
                                result.error?.startsWith("HTTP") == true -> Color.rgb(255, 90, 90)
                                else -> Color.rgb(255, 195, 75)
                            }
                        )
                    }
                    val n = done.incrementAndGet()
                    statusText.text = "📊 Tarama: $n/${sources.size} tamamlandı"
                    if (n == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                        scanButton.background = rounded(Color.rgb(35, 125, 68), 10)
                        statusText.text = "✅ 16 kaynak taraması tamamlandı"
                        renderConsensus(results.values.toList())
                    }
                }
            }
        }
        } catch (e: Exception) {
            scanButton.isEnabled = true
            scanButton.text = "🔄  TEKRAR DENE"
            scanButton.background = rounded(Color.rgb(35, 125, 68), 10)
            statusText.text = "❌ Tarama başlatılamadı: ${e.javaClass.simpleName}"
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 7, 10, 7)
            setBackgroundColor(Color.rgb(23, 31, 39))
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 3, 0, 0)
        })
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 1, 0, 1) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 15000
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                setRequestProperty("Referer", source.url)
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code • erişilemedi")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "HTTP $code • boş HTML")
            val predictions = parseSource(source.name, html)
            Result(source.name, code, predictions, if (predictions.isEmpty()) "HTTP $code • HTML geldi, temiz parser 0 maç" else null)
        } catch (e: javax.net.ssl.SSLHandshakeException) {
            Result(source.name, -1, emptyList(), "SSL • sertifika doğrulaması başarısız")
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), "${e.javaClass.simpleName} • ${e.message ?: "bağlantı hatası"}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun parseSource(name: String, html: String): List<Prediction> {
        val doc = Jsoup.parse(html)
        val out = LinkedHashMap<String, Prediction>()
        val elements = doc.select("tr, article, li, section, div, p")
        for (el in elements) {
            val text = clean(el.text())
            if (text.length !in 10..650) continue
            val p = when (name) {
                "Forebet" -> parseForebet(text)
                "PredictZ" -> parsePredictZ(text)
                "WinDrawWin" -> parseWinDrawWin(text)
                "FP.com", "FootballPredictions.net" -> parseFootballPredictions(text)
                "BettingTipsToday", "SoccerSeer", "MightyTips", "FootyStats", "GoalVertex", "NerdyTips", "Vitibet", "HuhSports", "FootballAnt", "DailySports", "Statarea" -> parseGeneric(text)
                else -> null
            }
            if (p != null && validPrediction(p)) {
                val key = normalize(p.home) + "|" + normalize(p.away)
                out[key] = p
            }
            if (out.size >= 12) break
        }
        return out.values.take(12)
    }

    private fun parseForebet(text: String): Prediction? {
        val pair = pairPattern.find(text) ?: return null
        val after = text.substring(pair.range.last + 1)
        val score = labelScorePattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
            ?: scoreBeforeLabelPattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
            ?: run {
                val scores = scoreOccurrences(after)
                scores.firstOrNull()
            }
        return score?.let { Prediction(sanitizeTeam(pair.groupValues[1]), sanitizeTeam(pair.groupValues[2]), it) }
    }

    private fun parsePredictZ(text: String): Prediction? {
        val pair = Regex("(?iu)([\\p{L}\\p{N}][\\p{L}\\p{N} .&'’()/-]{1,65}?)\\s+v\\s+([\\p{L}\\p{N}][\\p{L}\\p{N} .&'’()/-]{1,65}?)").find(text) ?: return null
        val after = text.substring(pair.range.last + 1)
        val score = Regex("(?iu)([0-5])\\s*[-:]\\s*([0-5])\\s+Correct\\s+Score\\s+Odds").find(after)
            ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
            ?: labelScorePattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
        return score?.let { Prediction(sanitizeTeam(pair.groupValues[1]), sanitizeTeam(pair.groupValues[2]), it) }
    }

    private fun parseWinDrawWin(text: String): Prediction? {
        val pair = pairPattern.find(text) ?: return null
        val after = text.substring(pair.range.last + 1)
        val score = scoreOccurrences(after).firstOrNull() ?: return null
        return Prediction(sanitizeTeam(pair.groupValues[1]), sanitizeTeam(pair.groupValues[2]), score)
    }

    private fun parseFootballPredictions(text: String): Prediction? {
        val pair = pairPattern.find(text) ?: return null
        val after = text.substring(pair.range.last + 1)
        val score = labelScorePattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
            ?: scoreOccurrences(after).firstOrNull() ?: return null
        return Prediction(sanitizeTeam(pair.groupValues[1]), sanitizeTeam(pair.groupValues[2]), score)
    }

    private fun parseGeneric(text: String): Prediction? {
        val pair = pairPattern.find(text) ?: return null
        val after = text.substring(pair.range.last + 1)
        val labeled = labelScorePattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
        val score = labeled ?: scoreBeforeLabelPattern.find(after)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
            ?: scoreOccurrences(after).firstOrNull()
            ?: return null
        return Prediction(sanitizeTeam(pair.groupValues[1]), sanitizeTeam(pair.groupValues[2]), score)
    }

    private fun scoreOccurrences(text: String): List<String> {
        val out = ArrayList<String>()
        val m = scorePattern.matcher(text)
        while (m.find() && out.size < 8) out.add("${m.group(1)}-${m.group(2)}")
        return out
    }

    private fun sanitizeTeam(s: String): String {
        return s.replace(Regex("\\b(?:preview|analysis|odds|correct|predicted|score|tips?|prediction|home|away|draw)\\b.*$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\b\\d{1,3}%\\b"), "")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '|', '→')
            .take(70)
    }

    private fun validPrediction(p: Prediction): Boolean {
        if (p.home.length < 2 || p.away.length < 2) return false
        if (p.home.equals(p.away, true)) return false
        if (isNoise(p.home) || isNoise(p.away)) return false
        if (!Regex("[\\p{L}]{2}").containsMatchIn(p.home) || !Regex("[\\p{L}]{2}").containsMatchIn(p.away)) return false
        return true
    }

    private fun isNoise(s: String): Boolean {
        val x = s.lowercase()
        return x.contains("correct score") || x.contains("predicted score") || x.contains("analysis") ||
            x.contains("match preview") || x.contains("avg goals") || x.contains("prediction") ||
            x.matches(Regex("[0-9 .%:+-]+"))
    }

    private fun normalize(s: String): String = s.lowercase()
        .replace("football club", " ")
        .replace(" fc ", " ")
        .replace(" cf ", " ")
        .replace(" afc ", " ")
        .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    private fun formatResult(r: Result): String {
        if (r.error != null) return "${if (r.code in 400..599) "❌" else "⚠️"} ${r.error}"
        return "✅ HTTP ${r.code} • ${r.predictions.size} temiz maç\n" +
            r.predictions.take(8).joinToString("\n") { "⚽ ${it.home} → ${it.score} ← ${it.away}" }
    }

    private fun renderConsensus(results: Collection<Result>) {
        consensusBox.removeAllViews()
        consensusBox.addView(TextView(this).apply {
            text = "🎯 SKOR BİRLEŞTİRME"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })

        val groups = LinkedHashMap<String, MutableMap<String, MutableList<String>>>()
        val displayNames = LinkedHashMap<String, Pair<String, String>>()
        results.filter { it.predictions.isNotEmpty() }.forEach { r ->
            r.predictions.forEach { p ->
                val key = normalize(p.home) + "|" + normalize(p.away)
                displayNames[key] = p.home to p.away
                groups.getOrPut(key) { LinkedHashMap() }.getOrPut(p.score) { mutableListOf() }.add(r.name)
            }
        }

        data class Ranked(val key: String, val score: String, val names: List<String>)
        val ranked = groups.flatMap { (key, scoreMap) ->
            scoreMap.map { (score, names) -> Ranked(key, score, names) }
        }.filter { it.names.size >= 2 }
            .sortedWith(compareByDescending<Ranked> { it.names.size }.thenBy { it.key })
            .take(15)

        if (ranked.isEmpty()) {
            consensusBox.addView(TextView(this).apply {
                text = "ℹ️ En az 2 kaynağın aynı maçı ve aynı skoru doğruladığı sonuç henüz yok."
                textSize = 12f
                setTextColor(Color.LTGRAY)
                setPadding(0, 4, 0, 0)
            })
            return
        }

        ranked.forEach { item ->
            val pair = displayNames[item.key] ?: return@forEach
            consensusBox.addView(TextView(this).apply {
                text = "⚽ ${pair.first} - ${pair.second}\n🎯 ${item.score} • ${item.names.size} kaynak\n   ${item.names.joinToString(", ")}"
                textSize = 13f
                setTextColor(Color.rgb(95, 240, 150))
                setPadding(0, 7, 0, 0)
            })
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
