package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

private data class Source(val name: String, val url: String)
private data class Result(val name: String, val code: Int, val matches: List<String>, val error: String? = null)

class MainActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(8)
    private lateinit var resultBox: LinearLayout
    private lateinit var scanButton: Button
    private lateinit var statusText: TextView

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips"),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/"),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/"),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/future/all-games/all-stakes/"),
        Source("BettingTipsToday", "https://www.bettingtips.today/correct-score-predictions-tips/"),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/"),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/"),
        Source("FootyStats", "https://footystats.org/predictions/correct-score"),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions"),
        Source("NerdyTips", "https://nerdytips.com/"),
        Source("Vitibet", "https://www.vitibet.com/"),
        Source("HuhSports", "https://www.huhsports.com/tr/predictions"),
        Source("FootballAnt", "https://www.footballant.com/tr/prediction/correct-score-predictions"),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Source("Statarea", "https://www.statarea.com/tips")
    )

    private val scorePattern = Pattern.compile("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        // Uygulama açılır açılmaz gerçek taramayı başlat.
        window.decorView.postDelayed({ scanAll() }, 500)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(7, 11, 16))
            setPadding(22, 24, 22, 16)
        }

        val title = TextView(this).apply {
            text = "⚽ CIO SCORE"
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)

        val sub = TextView(this).apply {
            text = "Skorun merkezi • 16 kaynak"
            textSize = 18f
            setTextColor(Color.LTGRAY)
            setPadding(0, 5, 0, 12)
        }
        root.addView(sub)

        scanButton = Button(this).apply {
            text = "🔄  BUGÜNÜ TARA"
            textSize = 17f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = rounded(Color.rgb(55, 65, 75), 12)
            setPadding(12, 0, 12, 0)
            setOnClickListener { scanAll() }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, 58))

        statusText = TextView(this).apply {
            text = "Hazır • tarama otomatik başlayacak"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 8)
        }
        root.addView(statusText)

        val scroll = ScrollView(this)
        resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(resultBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        showInitialRows()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun showInitialRows() {
        resultBox.removeAllViews()
        sources.forEachIndexed { index, s ->
            resultBox.addView(row("${index + 1}. ${s.name}", "⏳ Bekliyor..."))
        }
    }

    private fun scanAll() {
        scanButton.isEnabled = false
        scanButton.text = "⏳  16 KAYNAK TARANIYOR..."
        scanButton.background = rounded(Color.rgb(40, 48, 56), 12)
        statusText.text = "🌐 16 kaynak paralel taranıyor..."
        resultBox.removeAllViews()

        val rows = HashMap<String, TextView>()
        sources.forEachIndexed { index, source ->
            val r = row("${index + 1}. ${source.name}", "⏳ Bağlanıyor...")
            rows[source.name] = r.getChildAt(1) as TextView
            resultBox.addView(r)
        }

        val done = AtomicInteger(0)
        sources.forEach { source ->
            executor.execute {
                val result = fetchAndParse(source)
                runOnUiThread {
                    rows[source.name]?.let { detail ->
                        detail.text = formatResult(result)
                        detail.setTextColor(when {
                            result.matches.isNotEmpty() -> Color.rgb(75, 225, 135)
                            result.code in 400..599 -> Color.rgb(255, 95, 95)
                            else -> Color.rgb(255, 195, 75)
                        })
                    }
                    val n = done.incrementAndGet()
                    statusText.text = "📊 Tarama: $n/${sources.size} tamamlandı"
                    if (n == sources.size) {
                        scanButton.isEnabled = true
                        scanButton.text = "🔄  TEKRAR TARA"
                        scanButton.background = rounded(Color.rgb(40, 115, 65), 12)
                        statusText.text = "✅ 16 kaynak taraması tamamlandı"
                    }
                }
            }
        }
    }

    private fun row(title: String, detail: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(24, 31, 39))
        }
        val t = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val d = TextView(this).apply {
            text = detail
            textSize = 14f
            setTextColor(Color.GRAY)
            setPadding(0, 5, 0, 0)
        }
        box.addView(t)
        box.addView(d)
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 3, 0, 3) }
        return box
    }

    private fun fetchAndParse(source: Source): Result {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(source.url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12000
                readTimeout = 18000
                instanceFollowRedirects = true
                useCaches = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                setRequestProperty("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                setRequestProperty("Cache-Control", "no-cache")
            }
            val code = connection.responseCode
            if (code !in 200..399) return Result(source.name, code, emptyList(), "HTTP $code • erişilemedi")
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (html.isBlank()) return Result(source.name, code, emptyList(), "HTTP $code • boş HTML")
            val matches = extractMatches(html)
            Result(source.name, code, matches)
        } catch (e: Exception) {
            Result(source.name, -1, emptyList(), "${e.javaClass.simpleName} • ${e.message ?: "bağlantı hatası"}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun extractMatches(html: String): List<String> {
        val doc = Jsoup.parse(html)
        val found = LinkedHashSet<String>()

        // Skorun bulunduğu anlamlı HTML bloklarını önceliklendir.
        val candidates = doc.select(
            "tr, article, li, a, [class*=match], [class*=game], [class*=fixture], " +
            "[class*=prediction], [class*=score], [class*=event]"
        )

        for (el in candidates) {
            val raw = buildString {
                append(el.text())
                listOf("title", "aria-label", "data-match", "data-event", "data-teams").forEach { key ->
                    val v = el.attr(key).trim()
                    if (v.isNotEmpty()) append(" | ").append(v)
                }
            }.replace(Regex("\\s+"), " ").trim()

            if (raw.length < 5 || raw.length > 400) continue
            val scoreMatcher = scorePattern.matcher(raw)
            if (!scoreMatcher.find()) continue

            val score = "${scoreMatcher.group(1)}-${scoreMatcher.group(2)}"
            val clean = cleanMatchText(raw, score)
            if (clean.isEmpty()) continue
            if (looksLikeNoise(clean)) continue

            found.add("$clean → $score")
            if (found.size >= 10) break
        }

        // Fallback: yalnızca skor çevresindeki kısa, temiz metni kullan.
        if (found.isEmpty()) {
            val text = doc.text().replace(Regex("\\s+"), " ").trim()
            val m = scorePattern.matcher(text)
            while (m.find() && found.size < 10) {
                val score = "${m.group(1)}-${m.group(2)}"
                val start = maxOf(0, m.start() - 100)
                val snippet = text.substring(start, m.start())
                val clean = cleanMatchText(snippet, score)
                if (clean.isNotEmpty() && !looksLikeNoise(clean)) {
                    found.add("$clean → $score")
                }
            }
        }
        return found.toList()
    }

    private fun cleanMatchText(raw: String, score: String): String {
        var t = raw
            .replace(score, " ")
            .replace(Regex("\\b(?:correct|predicted|prediction|predictions|scoreline|exact|score|odds|preview|analysis|tips?|model|avg\\.?\\s*goals?)\\b"), " ", ignoreCase = true)
            .replace(Regex("\\b\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}\\b"), " ")
            .replace(Regex("\\b(?:19|20)\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}\\b"), " ")
            .replace(Regex("\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b"), " ")
            .replace(Regex("\\b\\d+(?:\\.\\d+)?%\\b"), " ")
            .replace(Regex("\\b\\d+(?:\\.\\d+)?\\b"), " ")
            .replace(Regex("[→»|]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', ',', ';', '.')

        // Takım ayırıcıları varsa sadece iki tarafı al.
        val parts = t.split(Regex("\\s+(?:vs?\\.?|versus|v\\.)\\s+|\\s+[–—-]\\s+|\\s+@\\s+|\\s*↔\\s*"), limit = 2)
        if (parts.size == 2) {
            val a = parts[0].trim(' ', '-', '–', '—', ':', ',')
            val b = parts[1].trim(' ', '-', '–', '—', ':', ',')
            if (a.length >= 2 && b.length >= 2) return "$a - $b".take(110)
        }

        // Ayırıcı yoksa HTML kartının başındaki takım adlarını kullan; açıklamayı kes.
        t = t.substringBefore(Regex("\\b(?:predicted|prediction|correct|analysis|preview|odds|first division|premier league|la liga)\\b", RegexOption.IGNORE_CASE))
            .trim(' ', '-', '–', '—', ':', ',')
        return t.take(90).trim()
    }

    private fun looksLikeNoise(text: String): Boolean {
        val lower = text.lowercase()
        if (text.length < 4) return true
        val bad = listOf("http", "www.", "sslhandshake", "trust anchor", "avg goals", "likely correct")
        return bad.any { lower.contains(it) }
    }

    private fun formatResult(r: Result): String {
        if (r.error != null) return "❌ ${r.error}"
        if (r.matches.isEmpty()) return "⚠️ HTTP ${r.code} • HTML geldi, parser 0 maç"
        return "✅ HTTP ${r.code} • ${r.matches.joinToString("\n")}" 
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
