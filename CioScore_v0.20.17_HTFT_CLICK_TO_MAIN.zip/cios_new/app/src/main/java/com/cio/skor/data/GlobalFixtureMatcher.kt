package com.cio.skor.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Global six-source fixture identity engine.
 *
 * 1) TeamAliasCanonicalizer creates stable team identities.
 * 2) Official Iddaa matchId is a fixture anchor, not a team name.
 * 3) Union-Find clusters ALL records globally, independent of arrival order.
 * 4) Team + source match-id + date/time produce a confidence score.
 */
object GlobalFixtureMatcher {
    private const val TEAM_FLOOR = 0.74
    private const val STRONG_TEAM = 0.90
    private const val MERGE_THRESHOLD = 0.86
    private const val OFFICIAL_THRESHOLD = 0.78
    private const val TIME_SOFT_WINDOW_MS = 90L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 18L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    )

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val idAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean
    )

    private class DSU(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)
        fun find(x: Int): Int {
            var n = x
            while (parent[n] != n) n = parent[n]
            var root = n
            var cur = x
            while (parent[cur] != cur) {
                val next = parent[cur]
                parent[cur] = root
                cur = next
            }
            return root
        }
        fun union(a: Int, b: Int) {
            var ra = find(a); var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) { val t = ra; ra = rb; rb = t }
            parent[rb] = ra
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = buildList {
            scraped.forEach { s ->
                add(Record(s.homeTeam, s.awayTeam, s.predictedScore, s.source, s.sourceMatchId, s.matchTimestamp, s.matchDate, s.matchTime))
            }
            officialMatches.forEach { o ->
                add(Record(o.homeTeam, o.awayTeam, null, "IDDAA", o.matchId, o.matchTimestamp, o.matchDate, o.matchTime, o))
            }
        }
        if (records.isEmpty()) return emptyList()

        val dsu = DSU(records.size)

        // A. Official IDs are absolute anchors inside the official source.
        val officialById = HashMap<String, Int>()
        records.indices.forEach { i ->
            val id = records[i].sourceMatchId.trim()
            if (records[i].official != null && id.isNotBlank()) {
                val previous = officialById.putIfAbsent(id, i)
                if (previous != null) dsu.union(previous, i)
            }
        }

        // B. Global clustering. Exact canonical fixtures are cheap to union first.
        // Fuzzy comparison is blocked by a short home/away signature so an ordinary
        // scan (hundreds/thousands of records) does not become O(n^2) Levenshtein.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { i ->
            val k = MatchMerger.key(records[i].homeTeam, records[i].awayTeam)
            exactBuckets.getOrPut(k) { mutableListOf() }.add(i)
        }
        exactBuckets.values.forEach { ids ->
            for (k in 1 until ids.size) dsu.union(ids[0], ids[k])
        }

        val candidateBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { i ->
            val k = candidateSignature(records[i])
            candidateBuckets.getOrPut(k) { mutableListOf() }.add(i)
        }

        candidateBuckets.values.forEach { ids ->
            for (x in ids.indices) {
                val i = ids[x]
                for (y in x + 1 until ids.size) {
                    val j = ids[y]
                    val a = records[i]
                    val b = records[j]
                    if (a.source.equals(b.source, ignoreCase = true) && a.sourceMatchId.isNotBlank() && b.sourceMatchId.isNotBlank() && a.sourceMatchId != b.sourceMatchId) continue
                    val evidence = score(a, b)
                    if (evidence.accepted) dsu.union(i, j)
                }
            }
        }

        // C. Build groups after all unions. This is the key difference from greedy merge.
        val buckets = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { i -> buckets.getOrPut(dsu.find(i)) { mutableListOf() }.add(records[i]) }

        return buckets.values.map { group -> buildUnified(group) }
    }


    private fun candidateSignature(r: Record): String {
        fun head(value: String): String {
            val c = TeamAliasCanonicalizer.compact(value)
            return when {
                c.length >= 3 -> c.substring(0, 3)
                c.isNotEmpty() -> c
                else -> "#"
            }
        }
        return head(r.homeTeam) + "|" + head(r.awayTeam)
    }

    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() || b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, false, 0.0, false)
        }

        val home = TeamAliasCanonicalizer.similarity(a.homeTeam, b.homeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.awayTeam, b.awayTeam)
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) && TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val teamScore = (home + away) / 2.0
        val idAnchor = sameComparableId(a, b)

        // A source-local ID is decisive only when it is comparable. Iddaa IDs are
        // global official anchors; different external sites may use unrelated IDs.
        if (idAnchor) return MatchEvidence(home, away, teamScore, 1.0, true, 1.0, true)

        if (home < TEAM_FLOOR || away < TEAM_FLOOR) {
            return MatchEvidence(home, away, teamScore, timeScore(a, b), false, 0.0, false)
        }

        val time = timeScore(a, b)
        if (time < 0.0) return MatchEvidence(home, away, teamScore, time, false, 0.0, false)

        // Exact canonical teams are safe even when an external source has no kickoff metadata.
        if (exactTeams) return MatchEvidence(home, away, 1.0, time, false, 0.94, true)

        var confidence = 0.72 * teamScore + 0.28 * time.coerceAtLeast(0.0)
        if (home >= STRONG_TEAM && away >= STRONG_TEAM) confidence += 0.06
        if (time >= 0.95) confidence += 0.04
        confidence = confidence.coerceAtMost(0.99)

        val accepted = if (a.official != null || b.official != null) {
            teamScore >= OFFICIAL_THRESHOLD && (time >= 0.0)
        } else {
            confidence >= MERGE_THRESHOLD
        }
        return MatchEvidence(home, away, teamScore, time, false, confidence, accepted)
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val ia = a.sourceMatchId.trim()
        val ib = b.sourceMatchId.trim()
        if (ia.isBlank() || ib.isBlank() || ia != ib) return false
        // IDs from different providers are not comparable except official Iddaa.
        return a.source.equals(b.source, true) || (a.official != null && b.official != null)
    }

    /** 1 = close kickoff, 0 = no usable time, -1 = hard contradiction. */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            if (delta <= TIME_SOFT_WINDOW_MS) return 1.0 - delta.toDouble() / TIME_SOFT_WINDOW_MS * 0.10
            return 0.90 - (delta - TIME_SOFT_WINDOW_MS).toDouble() / (TIME_HARD_WINDOW_MS - TIME_SOFT_WINDOW_MS) * 0.90
        }

        val da = parseDate(a.matchDate)
        val db = parseDate(b.matchDate)
        if (da != null && db != null) return if (da == db) 0.92 else -1.0
        return 0.0
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) runCatching { return LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern)) }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(display.first, display.second, officialMatch = official)
        result.officialMatchId = official?.matchId.orEmpty()

        // One visible prediction per source. Prefer a record with score and stronger identity.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { it.predictedScore != null }.forEach { r ->
            val key = r.source.trim().lowercase()
            val old = bySource[key]
            if (old == null || sourceRecordPriority(r, official) > sourceRecordPriority(old, official)) bySource[key] = r
        }
        bySource.values.forEach { r -> result.predictions += r.source to r.predictedScore.orEmpty() }

        result.fixtureConfidence = groupConfidence(group)
        if (official != null) result.officialMatch = official
        return result
    }

    private fun chooseDisplay(group: List<Record>, official: IddaaMarketService.OpenedMarketMatch?): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull { TeamAliasCanonicalizer.canonical(it.homeTeam).length + TeamAliasCanonicalizer.canonical(it.awayTeam).length }
            ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourceRecordPriority(r: Record, official: IddaaMarketService.OpenedMarketMatch?): Int {
        var p = 0
        if (official != null) p += 10
        if (r.matchTimestamp > 0L) p += 2
        if (r.predictedScore != null) p += 5
        return p
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        var total = 0.0; var count = 0
        for (i in 0 until group.lastIndex) for (j in i + 1..group.lastIndex) {
            val e = score(group[i], group[j])
            if (e.accepted) { total += e.confidence; count++ }
        }
        return if (count == 0) 1.0 else total / count
    }
}
