# CioScore v0.20.17 – HT/FT Match Navigation

HT/FT Açılan Maçlar ekranındaki bir maç satırına dokunulduğunda MainActivity yeniden kullanılır (CLEAR_TOP | SINGLE_TOP). Ev sahibi TARGET_MATCH_QUERY olarak arama alanına yazılır; ev sahibi + deplasman canonical eşleşmesiyle doğru filtrelenmiş kart bulunur ve RecyclerView o karta kaydırılır.

Mevcut GlobalFixtureMatcher/MatchMerger yapısı değiştirilmemiştir.
