package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceTimeZone
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** FP.com Correct Score parser. */
class FPComParser : BaseParser("FP.com", SourceTimeZone.EUROPE_LONDON) {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (row in doc.select("table tr")) {
            val cells = row.select("th, td")
            if (cells.size < 2) continue

            val score = extractScore(cells[1]) ?: continue
            val teams = extractTeams(cells[0]) ?: continue

            val home = cleanTeamName(teams.first)
            val away = cleanTeamName(teams.second)
            if (!isRealTeam(home) || !isRealTeam(away)) continue

            val href = cells[0].select("a[href]").firstOrNull()?.attr("href") ?: ""
            val sourceMatchId = if (href.isBlank()) "" else stableHrefId(href)
            // FP.com exposes the real fixture schedule as a date+time pair in
            // the fixture row/link (for example: 27/10/2026, 19:45). Do not
            // accept an isolated <time>, countdown, page clock, or publication
            // timestamp as kickoff. The previous generic metadata scan could
            // capture 01:45 from unrelated page markup and manufacture a future
            // timestamp for a match that had already finished.
            val explicitKickoff = extractFpKickoff(row, cells[0])
            val raw = extractFixtureMetadata(row)
            val metadata = mergeMetadata(
                date = explicitKickoff?.first.orEmpty(),
                time = explicitKickoff?.second ?: "--:--",
                competition = raw.competitionName.ifBlank { extractNearestCompetition(row) },
                competitionCountry = raw.competitionCountry,
                rawDateTime = ""
            )
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchTimestamp = metadata.matchTimestamp,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName,
                competitionCountry = metadata.competitionCountry
            )
            val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
            out[key] = model
            if (out.size >= 50) break
        }
        return out.values.toList()
    }


    /**
     * Extract only a fixture-local date+time pair. A standalone HH:mm is never
     * enough to establish kickoff because FP.com pages also contain unrelated
     * clocks and publication/update times.
     */
    private fun extractFpKickoff(row: Element, fixtureCell: Element): Pair<String, String>? {
        val texts = buildList {
            add(fixtureCell.text())
            add(row.text())
        }
        val patterns = listOf(
            Regex("\\b(\\d{1,2}[./-]\\d{1,2}[./-]\\d{4})\\D{0,16}([01]?\\d|2[0-3]):([0-5]\\d)\\b"),
            Regex("\\b(\\d{4}[-/]\\d{1,2}[-/]\\d{1,2})\\D{0,16}([01]?\\d|2[0-3]):([0-5]\\d)\\b")
        )
        for (text in texts) {
            for (pattern in patterns) {
                val m = pattern.find(text) ?: continue
                val date = normalizeDate(m.groupValues[1])
                if (date.isBlank()) continue
                val time = "%02d:%s".format(m.groupValues[2].toInt(), m.groupValues[3])
                return date to time
            }
        }
        return null
    }

    private fun extractScore(cell: Element): String? {
        val text = cell.text().replace('\u00A0', ' ').trim()
        val m = Regex("^\\s*([0-5])\\s*[-:]\\s*([0-5])\\s*$").matchEntire(text)
            ?: Regex("\\b([0-5])\\s*[-:]\\s*([0-5])\\b").find(text)
            ?: return null
        return "${m.groupValues[1]}-${m.groupValues[2]}"
    }

    private fun extractTeams(cell: Element): Pair<String, String>? {
        // FP.com currently renders the match as one link containing both teams
        // plus date/time. The link URL contains the fixture slug, which is the
        // safest way to split the two team names.
        val link = cell.select("a[href]").firstOrNull()
        if (link != null) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/')
                .substringAfterLast('/')
                .lowercase()

            val pair = splitSlug(slug)
            if (pair != null) return pair

            // Some versions use the visible text with an explicit v/vs separator.
            val visible = stripDate(link.text())
            val visiblePair = splitVisible(visible)
            if (visiblePair != null) return visiblePair
        }

        // Fallback: any explicit home/away elements.
        val home = firstText(cell, ".home-team", ".homeTeam", ".team-home", "[class*=home-team]")
        val away = firstText(cell, ".away-team", ".awayTeam", ".team-away", "[class*=away-team]")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        return splitVisible(stripDate(cell.text()))
    }

    private fun splitSlug(slug: String): Pair<String, String>? {
        val cleaned = slug
            .replace(Regex("-(?:prediction|tips?|correct-score|odds).*$"), "")

        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = cleaned.indexOf(marker)
            if (idx > 0) {
                val home = slugWords(cleaned.substring(0, idx))
                val away = slugWords(cleaned.substring(idx + marker.length))
                if (isRealTeam(home) && isRealTeam(away)) return home to away
            }
        }
        return null
    }

    private fun splitVisible(text: String): Pair<String, String>? {
        val cleaned = text.replace(Regex("\\s+"), " ").trim()
        val m = Regex("(?i)^(.+?)\\s+(?:v|vs|versus)\\s+(.+)$").find(cleaned)
            ?: return null
        val home = m.groupValues[1].trim()
        val away = m.groupValues[2].trim()
        if (isRealTeam(home) && isRealTeam(away)) return home to away
        return null
    }

    private fun stripDate(text: String): String {
        return text
            .replace(Regex("\\b\\d{1,2}/\\d{1,2}/\\d{4}\\b.*$"), "")
            .replace(Regex("\\b\\d{1,2}-\\d{1,2}-\\d{4}\\b.*$"), "")
            .trim()
    }

    private fun slugWords(value: String): String {
        return value.replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(' ')
            .joinToString(" ") { word ->
                if (word.isBlank()) word else word.replaceFirstChar { it.uppercase() }
            }
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.select(selector).firstOrNull()?.text()?.let(::cleanTeamName)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun stableHrefId(href: String): String =
        URLDecoder.decode(href.trim(), StandardCharsets.UTF_8.name())
            .substringBefore('?')
            .substringBefore('#')
            .trim()
            .trimEnd('/')

    private fun cleanTeamName(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .replace(Regex("(?i)\\b(correct\\s*score|odds|probability|prediction|tip)\\b.*$"), "")
        .trim(' ', '-', '–', '—', ':', '|')

    private fun isRealTeam(value: String): Boolean {
        val v = cleanTeamName(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:/-]+$"))) return false
        if (v.contains(Regex("(?i)correct\\s*score|probability|odds|prediction|betting tips|read more"))) return false
        return true
    }
}
