# v0.25.39 — FP.com Fixture Kickoff Provenance Fix

## Root cause confirmed by v0.25.38 diagnostic

v0.25.38 fixed the generic card-wide time fallback, but FP.com still passed its entire fixture row through generic metadata extraction. The scan showed FP.com as `tam=18` while finished 27 Oct fixtures such as AS Roma–Cagliari were still rendered as `28.10.2026 01:45`. This means a semantically-labelled but non-fixture `<time>` element was still being accepted as kickoff.

## v0.25.39 changes

- FP.com now accepts kickoff only when a **date and time occur together inside the fixture row/link**.
- Isolated `HH:mm` values are no longer sufficient for FP.com kickoff.
- FP.com no longer falls back to the page date plus an unrelated row time.
- If no trustworthy date+time pair exists, FP.com emits `matchTimestamp=0` and the existing real-time safety gate removes the prediction from UI.
- Source timezone remains `Europe/London`; display conversion remains `Europe/Istanbul`.
- Existing official Iddaa enrichment and real-time past-match filter remain unchanged.

## Expected result

At 28 Oct 2026 01:07 TRT, FP.com fixtures whose source schedule is 27 Oct 2026 19:45 UK normalize to the already elapsed instant and are removed by `PAST_MATCH_FILTERED`. They cannot become `28.10.2026 01:45` merely because an unrelated page clock contains that value.
