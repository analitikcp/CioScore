package com.cio.skor.data

import com.cio.skor.data.SourceResult
import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.CancellationException
import java.util.concurrent.atomic.AtomicInteger
import org.jsoup.Jsoup

/** Six football score-prediction sources. Official iddaa.com remains enrichment only. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
        // Filter 6: Forebet Correct Score. The page exposes the full football
        // prediction feed across leagues; parser reads only the dedicated
        // Correct Score field for each upcoming fixture.
        Source("Forebet", "https://www.forebet.com/en/football-predictions/", ForebetParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val completedCount = AtomicInteger(0)
        sources.map { source ->
            async(Dispatchers.IO) {
                val result = try {
                    val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                    // A single slow source must never hold the whole scan hostage.
                    // Hard cap each source request; no retry here because a second long
                    // request only makes the overall scan feel hung.
                    val (code, html) = withTimeout(15_000L) {
                        withContext(Dispatchers.IO) { http.getFast(source.url, referer) }
                    }
                    if (code in 200..299 && !html.isNullOrBlank()) {
                        SourceResult(
                            source.name,
                            code,
                            source.parser.parse(Jsoup.parse(html, source.url)),
                            null
                        )
                    } else {
                        SourceResult(source.name, code, emptyList(), "HTTP_$code")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }

                onProgress(completedCount.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()
    }
}
