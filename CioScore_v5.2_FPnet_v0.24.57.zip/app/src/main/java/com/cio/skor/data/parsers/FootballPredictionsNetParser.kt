package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * FootballPredictions.net parser.
 *
 * Important: the FP.net correct-score index is treated ONLY as a discovery page.
 * Scores are read from the individual fixture pages. This avoids coupling the
 * parser to the changing card/table markup of the index page.
 */
class FootballPredictionsNetParser : BaseParser("FP.net") {

    companion object {
        private const val MAX_FIXTURE_LINKS = 60
    }

    /** Discover fixture URLs from an FP.net index/list page. */
    fun discoverMatchUrls(doc: Document): List<String> =
        doc.select("a[href]")
            .mapNotNull { normalizeMatchHref(it.attr("href")) }
            .distinct()
            .take(MAX_FIXTURE_LINKS)

    /** Parse one individual FP.net fixture page. */
    fun parseFixture(doc: Document, url: String): ScoreModel? {
        val pair = splitFixtureSlug(url) ?: return null
        val home = team(pair.first)
        val away = team(pair.second)
        if (!valid(home, away)) return null

        // The fixture page contains an old/current match result near the top.
        // Therefore the score MUST be extracted only from the semantic
        // "Correct Score Prediction" section, never from the first score on
        // the page.
        val score = extractCorrectScoreFromDocument(doc) ?: return null
        if (!ScoreModel.hasRenderablePrediction(score)) return null

        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source,
            sourceMatchId = stableHrefId(url)
        )
    }

    override fun parse(doc: Document): List<ScoreModel> {
        // Kept for compatibility with BaseParser. Repository uses the two-stage
        // discovery/detail flow above for FP.net.
        return emptyList()
    }

    private fun extractCorrectScoreFromDocument(doc: Document): String? {
        // First try the actual semantic heading and a bounded following region.
        val labels = doc.select("h1,h2,h3,h4,h5,h6,strong,b,p,div,span")
            .filter { clean(it.text()).equals("Correct Score Prediction", true) }

        for (label in labels) {
            val region = boundedRegion(label)
            extractScoreAfterAnchor(region)?.let { return it }
        }

        // Some rendered variants put the label and arrow/text in a sibling
        // container. Search the document text with a bounded window.
        val body = clean(doc.body()?.text().orEmpty())
        extractScoreAfterAnchor(body)?.let { return it }

        return null
    }

    private fun extractScoreAfterAnchor(text: String): String? {
        val match = Regex(
            "(?is)correct\\s+score\\s+prediction\\b.{0,500}?\\b(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b"
        ).find(text) ?: return null
        val h = match.groupValues[1].toIntOrNull() ?: return null
        val a = match.groupValues[2].toIntOrNull() ?: return null
        if (h !in 0..20 || a !in 0..20) return null
        return "$h-$a"
    }

    private fun boundedRegion(element: Element): String {
        // Include the label's parent and a few following siblings. Do not use
        // the entire page here: that could associate an unrelated score.
        val chunks = ArrayList<String>()
        chunks += element.text()
        var sibling = element.nextElementSibling()
        repeat(8) {
            if (sibling == null) return@repeat
            chunks += sibling.text()
            sibling = sibling.nextElementSibling()
        }
        val parent = element.parent()
        if (parent != null) chunks += parent.text()
        return clean(chunks.joinToString(" "))
    }

    private fun normalizeMatchHref(raw: String): String? {
        if (raw.isBlank()) return null
        val href = decode(raw.trim())
        val absolute = when {
            href.startsWith("https://footballpredictions.net/", true) -> href
            href.startsWith("http://footballpredictions.net/", true) ->
                "https://footballpredictions.net/" + href.substringAfter("://footballpredictions.net/")
            href.startsWith("/") -> "https://footballpredictions.net" + href
            else -> return null
        }
        if (!isMatchHref(absolute)) return null
        return absolute
            .substringBefore('?')
            .substringBefore('#')
            .trimEnd('/')
    }

    private fun isMatchHref(href: String): Boolean {
        val n = decode(href).lowercase()
        if (!n.contains("footballpredictions.net")) return false
        val path = n.substringBefore('?').substringBefore('#').trimEnd('/')
        // Actual fixture URLs observed on FP.net use this suffix.
        if (!path.endsWith("-predictions-betting-tips")) return false
        return path.contains("-v-") || path.contains("-vs-") || path.contains("-versus-")
    }

    private fun splitFixtureSlug(href: String): Pair<String, String>? {
        val slug = decode(href)
            .substringBefore('?')
            .substringBefore('#')
            .trimEnd('/')
            .substringAfterLast('/')
            .lowercase()

        val cleaned = slug.removeSuffix("-predictions-betting-tips")
        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = cleaned.indexOf(marker)
            if (idx <= 0) continue
            val home = slugWords(cleaned.substring(0, idx))
            val away = slugWords(cleaned.substring(idx + marker.length))
            if (valid(home, away)) return home to away
        }
        return null
    }

    private fun slugWords(value: String): String =
        value.replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .split(' ')
            .joinToString(" ") { word ->
                if (word.isBlank()) word else word.replaceFirstChar { it.uppercase() }
            }

    private fun stableHrefId(href: String): String =
        decode(href)
            .substringBefore('?')
            .substringBefore('#')
            .trim()
            .trimEnd('/')

    private fun decode(value: String): String =
        runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }
            .getOrDefault(value)
}
