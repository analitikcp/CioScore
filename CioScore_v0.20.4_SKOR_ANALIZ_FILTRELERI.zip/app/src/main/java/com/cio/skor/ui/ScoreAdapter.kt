package com.cio.skor.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

/** One card per unified match; source names are displayed as CIO labels. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    // Resmi İddaa 1X2 oranları; external odds alanı kullanılmaz.
    val iddaaMs1: String? = null,
    val iddaaMsX: String? = null,
    val iddaaMs2: String? = null,
    val htFtOdds: LinkedHashMap<String, String> = linkedMapOf(),
    val matchTimestamp: Long = 0L,
    val displayTime: String = "--:--",
    val displayDate: String = "",
    val homeTeamId: Long? = null,
    val awayTeamId: Long? = null
)

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String, Long?) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList
    private var currentQuery = ""

    // UI MASKESİ: ScoreModel.source değerleri değiştirilmez.
    private val sourceLabels = mapOf(
        "fp.com" to "Skor Analiz Filtre 1",
        "predictz" to "Skor Analiz Filtre 2",
        "windrawwin" to "Skor Analiz Filtre 3",
        "soccerseer" to "Skor Analiz Filtre 4",
        "dailysports" to "Skor Analiz Filtre 5"
    )

    private fun displaySourceName(source: String): String {
        val normalized = source.trim().lowercase()

        return sourceLabels[normalized]
            ?: sourceLabels.entries
                .firstOrNull { normalized.contains(it.key) }
                ?.value
            ?: normalized
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        refreshDisplayed()
    }


    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        var list = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        displayedList = list
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val ctx = parent.context

        // Kart: yükseklik kesinlikle WRAP_CONTENT.
        val card = LinearLayout(ctx).apply {

            orientation = LinearLayout.VERTICAL

            layoutParams =
                RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val horizontal = dp(ctx, 8)
                    val vertical = dp(ctx, 6)
                    setMargins(
                        horizontal,
                        vertical,
                        horizontal,
                        vertical
                    )
                }

            val padding = dp(ctx, 10)
            setPadding(
                padding,
                padding,
                padding,
                padding
            )

            background =
                GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(ctx, 14).toFloat()
                    setStroke(
                        dp(ctx, 1),
                        0xFFE7EAF0.toInt()
                    )
                }

            elevation = dp(ctx, 3).toFloat()

            clipChildren = false
            clipToPadding = false
        }

        return VH(card)
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.card.removeAllViews()
        holder.card.isClickable = true
        holder.card.isFocusable = true
        holder.card.setOnClickListener {
            // Card click opens the home team history as a reliable fallback.
            onTeamClick(match.homeTeam, match.homeTeamId)
        }

        // ------------------------------------------------
        // BAŞLAMA SAATİ — resmi İddaa
        // ------------------------------------------------
        holder.card.addView(TextView(ctx).apply {
            text = if (match.displayTime != "--:--") "🕐 ${match.displayTime}" else "🕐 --:--"
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 5) }
        })

        // ------------------------------------------------
        // MS 1 / MS X / MS 2 oranları
        // ------------------------------------------------
        if (match.iddaaMs1 != null || match.iddaaMsX != null || match.iddaaMs2 != null) {
            val oddsRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 6) }
            }
            fun oddsCell(label: String, value: String): LinearLayout {
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                box.addView(TextView(ctx).apply {
                    text = label
                    textSize = 9f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                })
                box.addView(TextView(ctx).apply {
                    text = value
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                    gravity = Gravity.CENTER
                })
                return box
            }
            oddsRow.addView(oddsCell("MS 1", match.iddaaMs1 ?: "-"))
            oddsRow.addView(oddsCell("MS X", match.iddaaMsX ?: "-"))
            oddsRow.addView(oddsCell("MS 2", match.iddaaMs2 ?: "-"))
            holder.card.addView(oddsRow)
        }



        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam, match.homeTeamId) }
                isClickable = true
                isFocusable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam, match.awayTeamId) }
                isClickable = true
                isFocusable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.card.addView(teams)

        // ------------------------------------------------
        // SADE TAHMİN — yalnızca MS 1 / MS X / MS 2
        // Yalnızca sonuç tahmini gösterilir: MS 1 / MS X / MS 2.
        // ------------------------------------------------
        val outcomeCounts = match.predictions
            .mapNotNull { predictionOutcome(it.predictedScore) }
            .groupingBy { it }
            .eachCount()
        val analysisOutcome = outcomeCounts
            .maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            ?.key

        val predictionRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 7) }
        }

        predictionRow.addView(TextView(ctx).apply {
            text = "TAHMİN: ${when (analysisOutcome) {
                "1" -> "MS 1"
                "X" -> "MS X"
                "2" -> "MS 2"
                else -> "MS X"
            }}"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF00796B.toInt())
        })

        holder.card.addView(predictionRow)

        // ------------------------------------------------
        // RESMİ İDDAA İY/MS (HT/FT) — 9 KOMBİNASYON
        // ------------------------------------------------
        if (match.htFtOdds.isNotEmpty()) {
            holder.card.addView(TextView(ctx).apply {
                text = "İY/MS • RESMİ İDDAA"
                textSize = 9f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF00796B.toInt())
                setPadding(0, dp(ctx, 7), 0, dp(ctx, 3))
            })

            val order = listOf("1/1", "1/X", "1/2", "X/1", "X/X", "X/2", "2/1", "2/X", "2/2")
            for (chunk in order.chunked(3)) {
                val htRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                }
                chunk.forEach { key ->
                    val cell = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    cell.addView(TextView(ctx).apply {
                        text = key
                        textSize = 8f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(0xFF667085.toInt())
                        gravity = Gravity.CENTER
                    })
                    cell.addView(TextView(ctx).apply {
                        text = match.htFtOdds[key] ?: "-"
                        textSize = 11f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(0xFF00796B.toInt())
                        gravity = Gravity.CENTER
                    })
                    htRow.addView(cell)
                }
                holder.card.addView(htRow)
            }
        }

        // ------------------------------------------------
        // SKOR ANALİZ FİLTRELERİ
        // ------------------------------------------------
        // Her skor kaynağı kullanıcı arayüzünde Skor Analiz Filtre 1..5 olarak gösterilir;
        // gerçek veri kaynağı adı kullanıcı arayüzüne sızmaz.
        val orderedPredictions = match.predictions
            .sortedWith(compareBy<ScoreModel> {
                when (displaySourceName(it.source)) {
                    "Skor Analiz Filtre 1" -> 1
                    "Skor Analiz Filtre 2" -> 2
                    "Skor Analiz Filtre 3" -> 3
                    "Skor Analiz Filtre 4" -> 4
                    "Skor Analiz Filtre 5" -> 5
                    else -> 99
                }
            })

        if (orderedPredictions.isNotEmpty()) {
            holder.card.addView(View(ctx).apply {
                setBackgroundColor(0xFFE5E7EB.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 1)
                ).apply {
                    topMargin = dp(ctx, 8)
                    bottomMargin = dp(ctx, 3)
                }
            })

            orderedPredictions.take(5).forEach { prediction ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = dp(ctx, 2)
                        bottomMargin = dp(ctx, 2)
                    }
                }

                row.addView(TextView(ctx).apply {
                    text = displaySourceName(prediction.source)
                    textSize = 11f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })

                row.addView(TextView(ctx).apply {
                    text = "→ ${prediction.predictedScore}"
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF101828.toInt())
                    gravity = Gravity.END
                })

                holder.card.addView(row)
            }
        }
    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 13f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun predictionOutcome(score: String): String? {
        val match = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
