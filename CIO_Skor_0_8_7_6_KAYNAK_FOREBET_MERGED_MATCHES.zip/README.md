CIO SCORE 0.8.7 - 6 KAYNAK - FOREBET FIX

Base: 0.8.7 SoccerSeer old working parser project.
DailySports: real DailySportsParser + correct-score URL.
Forebet: restored broader parser from CIO_Skor_0_8_18_FOREBET_GERI_GERCEK_ROOT working version.
Other source parsers preserved.

Important: Forebet parser uses multiple DOM fallbacks (.rcnt, class*=rcnt, article[class*=rcnt], team-node parent walk) and labeled score fallback.
