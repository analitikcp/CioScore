package com.cio.skor

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: ScoreAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(0, top, 0, 0)
            insets
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            id = 100
            setBackgroundColor(Color.WHITE)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 10, 20, 8)
        }

        header.addView(TextView(this).apply {
            text = "CIO SCORE"
            textSize = 28f
            setTextColor(Color.BLACK)
            setTypeface(typeface, 1)
        })

        header.addView(TextView(this).apply {
            text = "Skorun Merkezi • ${repo.sourceCount} kaynak"
            textSize = 14f
            setTextColor(Color.GRAY)
        })

        status = TextView(this).apply {
            text = "Hazır"
            textSize = 14f
            setPadding(0, 10, 0, 8)
        }
        header.addView(status)

        val button = Button(this).apply {
            text = "BUGÜNÜ TARA"
            setOnClickListener { scan() }
        }
        header.addView(button)

        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = ScoreAdapter(emptyList())
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun scan() {
        status.text = "⏳ 0/${repo.sourceCount} kaynak taranıyor..."
        adapter.update(emptyList())

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { n, name ->
                    runOnUiThread {
                        status.text = "⏳ $n/${repo.sourceCount} • $name"
                    }
                }
            }

            val scores = results
                .flatMap { it.scores }
                .filter(::isDisplayable)
                .distinctBy { "${canonicalTeam(it.homeTeam)}|${canonicalTeam(it.awayTeam)}|${it.predictedScore}|${it.source}" }

            val goodSources = scores
                .map { it.source.trim() }
                .filter { it.isNotEmpty() }
                .distinct()

            val groups = groupMatches(scores)
            adapter.update(groups)

            status.text = if (goodSources.isEmpty()) {
                "⚠️ 0 kaynak • 0 temiz skor"
            } else {
                "✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\n" +
                    "🟢 " + goodSources.joinToString(" • ") +
                    "\n⚽ ${groups.size} farklı maç"
            }
        }
    }

    /**
     * Same match = same normalized home + normalized away team.
     * We deliberately keep home/away order so a reversed fixture is not merged.
     */
    private fun groupMatches(scores: List<ScoreModel>): List<MatchGroup> {
        // Different sites often write the same club differently (FC/FK/CF,
        // accents, punctuation, "United" vs "Utd", etc.). Build one row per
        // fixture instead of one row per source. Home/away order is preserved.
        val groups = mutableListOf<MutableList<ScoreModel>>()

        for (score in scores) {
            val existing = groups.firstOrNull { group ->
                val first = group.first()
                sameTeam(first.homeTeam, score.homeTeam) &&
                    sameTeam(first.awayTeam, score.awayTeam)
            }

            if (existing == null) groups.add(mutableListOf(score))
            else existing.add(score)
        }

        return groups.map { list ->
            // A source contributes at most one prediction to a match.
            val ordered = list.distinctBy { it.source.trim().lowercase() }
            MatchGroup(
                homeTeam = ordered.first().homeTeam,
                awayTeam = ordered.first().awayTeam,
                predictions = ordered
            )
        }
    }

    private fun sameTeam(a: String, b: String): Boolean {
        val x = canonicalTeam(a)
        val y = canonicalTeam(b)
        if (x == y) return true
        if (x.length >= 6 && y.length >= 6 && (x.contains(y) || y.contains(x))) return true

        // Common prediction-site abbreviations. These are deliberately small
        // and conservative so unrelated clubs are not accidentally merged.
        val aliases = mapOf(
            "manchesterunited" to "manutd",
            "manchesterutd" to "manutd",
            "manchesterunitedfc" to "manutd",
            "manchestercity" to "mancity",
            "manchestercityfc" to "mancity",
            "tottenhamhotspur" to "tottenham",
            "tottenhamhotspurfc" to "tottenham",
            "intermilan" to "inter",
            "internazionale" to "inter",
            "psveindhoven" to "psv",
            "psveindhoven" to "psv",
            "atleticomadrid" to "atleticomad",
            "parissaintgermain" to "psg",
            "parissg" to "psg",
            "borussiadortmund" to "dortmund",
            "bayernmunich" to "bayernmunich",
            "bayernmünchen" to "bayernmunich"
        )
        return aliases.getOrDefault(x, x) == aliases.getOrDefault(y, y)
    }

    /** Normalize accents, punctuation and common club suffixes for cross-source matching. */
    private fun canonicalTeam(value: String): String {
        var s = value.trim().lowercase()
        s = s.replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
        s = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9]+"), "")

        // Common suffixes that differ between prediction sites.
        val suffixes = listOf("footballclub", "soccerclub", "club", "fc", "fk", "cf", "sc", "afc")
        var changed = true
        while (changed) {
            changed = false
            for (suffix in suffixes) {
                if (s.endsWith(suffix) && s.length > suffix.length + 2) {
                    s = s.removeSuffix(suffix)
                    changed = true
                    break
                }
            }
        }
        return s
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
