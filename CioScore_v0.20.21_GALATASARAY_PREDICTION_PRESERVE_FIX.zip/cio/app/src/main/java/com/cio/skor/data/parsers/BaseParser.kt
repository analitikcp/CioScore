package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

abstract class BaseParser(protected val source: String) {
    protected val scoreRegex = Regex("(?<!\\d)([0-5])\\s*[-–—:]\\s*([0-5])(?!\\d)")
    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()
    protected fun score(s: String): String? = scoreRegex.find(s)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }
    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }
    abstract fun parse(doc: Document): List<ScoreModel>
}
