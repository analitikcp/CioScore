package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Forebet correct-score parser. Uses the table first, then card/text fallbacks. */
class ForebetParser : BaseParser("Forebet") {
    private val dateTime = Regex("\\b\\d{2}/\\d{2}/\\d{4}\\s+\\d{1,2}:\\d{2}\\b")
    private val scoreAny = Regex("(?<!\\d)([0-5])\\s*[-–—:]\\s*([0-5])(?!\\d)")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val rows = doc.select("tr, div[class*=match], div[class*=fixture], article")
        for (el in rows) {
            val raw = clean(el.text())
            if (raw.length !in 20..1800) continue
            val score = extractCorrectScore(el, raw) ?: continue
            val teams = extractTeams(el, raw) ?: continue
            val home = team(teams.first)
            val away = team(teams.second)
            if (!valid(home, away)) continue
            val model = ScoreModel(home, away, score, source)
            out[model.matchKey] = model
            if (out.size >= 250) break
        }
        return out.values.toList()
    }

    private fun extractCorrectScore(el: Element, raw: String): String? {
        // Forebet's current table has an explicit "Correct score" column. Prefer
        // that cell over any live/full-time result that may also be present.
        val labelled = el.select("td, th, div, span").firstOrNull { c ->
            c.text().trim().equals("Correct score", true)
        }
        if (labelled != null) {
            val cells = el.select("td, th")
            val index = cells.indexOfFirst { it === labelled || it.text().trim().equals("Correct score", true) }
            if (index >= 0 && index + 1 < cells.size) {
                scoreAny.find(cells[index + 1].text())?.let { return norm(it) }
            }
        }
        val labelledPattern = Regex("(?i)correct\\s*score[^0-9]{0,80}([0-5])\\s*[-–—:]\\s*([0-5])")
        labelledPattern.find(raw)?.let { return "${it.groupValues[1]}-${it.groupValues[2]}" }

        // On some layouts the correct-score value is the first score after the
        // Pred field. Avoid grabbing a completed-match score when possible.
        val pred = Regex("(?i)\\bPred\\b").find(raw)
        if (pred != null) {
            scoreAny.find(raw.substring(pred.range.last + 1))?.let { return norm(it) }
        }
        return scoreAny.find(raw)?.let { norm(it) }
    }

    private fun extractTeams(el: Element, raw: String): Pair<String, String>? {
        val links = el.select("a[href]").map { clean(it.text()) }
            .filter { it.length in 2..70 && !it.matches(Regex("(?i)^(preview|live|more|tips|stats|trend|score)$")) }
            .distinct()
        if (links.size >= 2) {
            // Team names are normally adjacent in the match link/table row.
            val firstTwo = links.take(2)
            if (firstTwo[0].split(" ").size <= 8 && firstTwo[1].split(" ").size <= 8) return firstTwo[0] to firstTwo[1]
        }

        // Fallback: team names occur immediately before the fixture date/time.
        val dt = dateTime.find(raw)
        if (dt != null) {
            val before = raw.substring(0, dt.range.first).trim()
            val parts = splitTeamPair(before)
            if (parts != null) return parts
        }

        val plain = Regex("(?i)([A-Za-zÀ-ÿ0-9.'’&()/-]{2,}(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/-]{2,}){0,5})\\s+(?:vs|v|–|—)\\s+([A-Za-zÀ-ÿ0-9.'’&()/-]{2,}(?:\\s+[A-Za-zÀ-ÿ0-9.'’&()/-]{2,}){0,5})").find(raw)
        return plain?.let { it.groupValues[1] to it.groupValues[2] }
    }

    private fun splitTeamPair(before: String): Pair<String, String>? {
        val separators = listOf(" vs ", " v ", " – ", " — ")
        for (sep in separators) {
            val i = before.indexOf(sep, ignoreCase = true)
            if (i > 0) {
                val h = before.substring(0, i).trim()
                val a = before.substring(i + sep.length).trim()
                if (h.length in 2..70 && a.length in 2..70) return h to a
            }
        }
        return null
    }

    private fun norm(m: MatchResult) = "${m.groupValues[1]}-${m.groupValues[2]}"
}
