package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup

/**
 * Production scraper repository.
 * Every source is isolated: an HTTP/parser failure in one source cannot stop
 * the other sources. Diagnostics preserve HTTP codes and parser failures.
 */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> =
        withContext(Dispatchers.IO) {
            progressCount = 0
            coroutineScope {
                sources.map { source ->
                    async {
                        val result = fetchOne(source)
                        onProgressCompleted(onProgress, source.name)
                        result
                    }
                }.awaitAll()
            }
        }

    private fun fetchOne(source: Source): SourceResult {
        // A separate HttpClient instance prevents mutable connection/cookie state
        // from one source leaking into another source.
        val http = HttpClient()
        return try {
            val (code, html) = http.get(source.url)

            if (code !in 200..299) {
                return SourceResult(
                    source = source.name,
                    httpCode = code,
                    scores = emptyList(),
                    error = "HTTP_$code"
                )
            }

            if (html.isNullOrBlank()) {
                return SourceResult(source.name, code, emptyList(), "EMPTY_BODY")
            }

            val scores = try {
                source.parser.parse(Jsoup.parse(html, source.url))
            } catch (e: Exception) {
                return SourceResult(
                    source.name,
                    code,
                    emptyList(),
                    "PARSER_${e.javaClass.simpleName}"
                )
            }

            SourceResult(
                source = source.name,
                httpCode = code,
                scores = scores,
                error = if (scores.isEmpty()) "NO_SCORES" else null
            )
        } catch (e: Exception) {
            SourceResult(
                source = source.name,
                httpCode = -1,
                scores = emptyList(),
                error = "NETWORK_${e.javaClass.simpleName}"
            )
        }
    }

    private fun onProgressCompleted(callback: (Int, String) -> Unit, name: String) {
        // Progress is only a UI callback; source result ordering remains stable
        // because awaitAll preserves the source-list order.
        synchronized(this) {
            progressCount++
            callback(progressCount, name)
        }
    }

    @Volatile private var progressCount = 0
}
