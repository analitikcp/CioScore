package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * The Football Predictions exact-score list parser.
 *
 * The public page exposes each fixture as a link whose slug contains
 * `home-vs-away`, while the surrounding row contains kickoff time and the
 * predicted exact score. We deliberately use the fixture URL as identity
 * instead of trying to split the concatenated visible team text.
 */
class TheFootballPredictionsParser : BaseParser("TheFootballPredictions") {

    private val fixtureHref = Regex("/([^/?#]+-vs-[^/?#]+-prediction[^/?#]*)", RegexOption.IGNORE_CASE)
    private val dateInSlug = Regex("date-(\\d{2}-\\d{2}-\\d{4})", RegexOption.IGNORE_CASE)
    private val gameId = Regex("game-id-([A-Za-z0-9_-]+)", RegexOption.IGNORE_CASE)
    private val timeRegex = Regex("\\b([01]?\\d|2[0-3]):[0-5]\\d\\b")

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (link in doc.select("a[href]")) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            if (!fixtureHref.containsMatchIn(href)) continue
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            val pair = splitFixture(slug) ?: continue

            // TFP renders the correct score immediately AFTER the fixture link,
            // followed by two point values (e.g. 16 and 84).  Never search an
            // arbitrary ancestor: that is how point values/other rows can become
            // a fake score such as 16-0 or 20-0.
            val score = scoreImmediatelyAfterFixtureLink(link) ?: continue
            val context = fixtureRowText(link)
            val time = timeRegex.find(context)?.value ?: "--:--"
            val date = dateInSlug.find(slug)?.groupValues?.get(1)?.let(::toIsoDate).orEmpty()
            val id = gameId.find(slug)?.groupValues?.get(1).orEmpty()

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = id,
                matchDate = date,
                matchTime = time
            )
            val key = if (id.isNotBlank()) "ID|$id" else model.matchKey
            out[key] = model
        }
        return out.values.toList()
    }

    // The TFP page is a table-like list: the fixture link is in one cell,
    // the actual Tip is in a following cell, and the two Pts values follow it.
    // Parse the score from the cells of THIS row, never from an arbitrary
    // ancestor. This makes 16/84 point values impossible to become a score.
    private val tfpCorrectScoreRegex = Regex("(?<!\\d)([0-9])\\s+-\\s+([0-9])(?!\\d)")

    private fun scoreImmediatelyAfterFixtureLink(link: org.jsoup.nodes.Element): String? {
        fun firstScore(text: String): String? =
            tfpCorrectScoreRegex.find(text.replace('\u00A0', ' '))?.let {
                "${it.groupValues[1]}-${it.groupValues[2]}"
            }

        // PRIMARY: the current TFP DOM has one fixture per table row.
        // Find the fixture cell and inspect only subsequent cells in that row.
        val row = link.closest("tr")
        if (row != null) {
            val cells = row.select("td, th")
            val fixtureCellIndex = cells.indexOfFirst { it.select("a[href]").any { a ->
                fixtureHref.containsMatchIn(a.attr("href")) &&
                    a.attr("href") == link.attr("href")
            } }
            if (fixtureCellIndex >= 0) {
                for (i in fixtureCellIndex + 1 until cells.size) {
                    firstScore(cells[i].text())?.let { return it }
                }
            }
            // Some responsive variants put the score in the same cell.
            firstScore(cells.getOrNull(fixtureCellIndex)?.text().orEmpty())?.let { return it }
        }

        // SECONDARY: the link's immediate parent/siblings only. Never climb
        // through a container that can contain multiple fixtures.
        firstScore(link.text())?.let { return it }
        firstScore(link.parent()?.text().orEmpty())?.let { return it }
        var sibling = link.nextElementSibling()
        repeat(6) {
            val element = sibling ?: return@repeat
            firstScore(element.text())?.let { return it }
            sibling = element.nextElementSibling()
        }
        return null
    }

    private fun fixtureRowText(link: org.jsoup.nodes.Element): String {
        val row = link.closest("tr")
        if (row != null) return row.text().replace('\u00A0', ' ')
        return link.parent()?.text()?.replace('\u00A0', ' ') ?: link.text()
    }

    private fun splitFixture(slug: String): Pair<String, String>? {
        val base = slug.replace(Regex("-prediction.*$", RegexOption.IGNORE_CASE), "")
        val marker = "-vs-"
        val idx = base.indexOf(marker, ignoreCase = true)
        if (idx <= 0) return null
        val home = slugWords(base.substring(0, idx))
        val away = slugWords(base.substring(idx + marker.length))
        return if (valid(home, away)) home to away else null
    }

    private fun slugWords(value: String): String = value
        .replace(Regex("[-_]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun toIsoDate(value: String): String {
        val parts = value.split('-')
        return if (parts.size == 3) "${parts[2]}-${parts[1]}-${parts[0]}" else ""
    }
}
