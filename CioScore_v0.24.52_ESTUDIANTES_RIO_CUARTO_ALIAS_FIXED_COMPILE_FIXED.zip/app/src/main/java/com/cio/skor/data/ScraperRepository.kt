package com.cio.skor.data

import com.cio.skor.data.SourceResult
import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.CancellationException
import java.util.concurrent.atomic.AtomicInteger
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import org.jsoup.Jsoup

/** Four score-prediction sources; official iddaa.com remains the authoritative fixture source. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser()),
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val completedCount = AtomicInteger(0)
        val results = sources.map { source ->
            async(Dispatchers.IO) {
                val startTime = System.currentTimeMillis()
                val result = try {
                    val referer = when (source.name) {
                        "DailySports" -> "https://dailysports.net/"
                        else -> null
                    }
                    // IMPORTANT: the timeout belongs to THIS child coroutine.
                    val (code, html) = withTimeout(15_000L) {
                        withContext(Dispatchers.IO) {
                            when (source.name) {
                                else -> http.getFast(source.url, referer)
                            }
                        }
                    }
                    val rawBytes = html?.toByteArray(Charsets.UTF_8)?.size ?: 0
                    val isHttpSuccess = code in 200..299 && !html.isNullOrBlank()
                    val scores = if (isHttpSuccess) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else {
                        emptyList()
                    }
                    val parserError = when {
                        !isHttpSuccess -> "HTTP_$code"
                        scores.isEmpty() -> "DOM_CHANGED_OR_EMPTY"
                        else -> null
                    }
                    SourceResult(
                        source = source.name,
                        httpCode = code,
                        scores = scores,
                        error = parserError,
                        durationMs = System.currentTimeMillis() - startTime,
                        rawHtmlBytes = rawBytes
                    )
                } catch (e: TimeoutCancellationException) {
                    // TimeoutCancellationException is normally a CancellationException,
                    // but this one belongs to our local withTimeout and MUST be contained.
                    SourceResult(
                        source = source.name,
                        httpCode = -2,
                        scores = emptyList(),
                        error = "TIMEOUT_15S",
                        durationMs = System.currentTimeMillis() - startTime
                    )
                } catch (e: CancellationException) {
                    // Only a cancellation coming from outside this source's local
                    // timeout may cancel the child/parent scan.
                    throw e
                } catch (e: Exception) {
                    SourceResult(
                        source = source.name,
                        httpCode = -1,
                        scores = emptyList(),
                        error = "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown error"}",
                        durationMs = System.currentTimeMillis() - startTime
                    )
                }

                onProgress(completedCount.incrementAndGet(), source.name)
                result
            }
        }.awaitAll()

        // Diagnostic only: observe each source result without changing behavior.
        val sourceCounts = results.associate { result ->
            result.source to result.scores.size
        }
        PipelineDiagnostics.log(
            sourceCounts = sourceCounts,
            rawPredictions = results.sumOf { it.scores.size }
        )

        results
    }
}
