# CioScore v0.23.16 — FULL PARSER ISOLATION + FALLBACK REPAIR

## Purpose
This release applies the requested parser recovery architecture without changing the existing ScoreModel contract used by the app.

## 1. BaseParser compatibility repair
- Keeps `BaseParser(protected val source: String = "Unknown")` so existing parser subclasses remain source-compatible.
- Restores a real `extractScore(String)` helper.
- Fixes the non-breaking-space character literal to `\u00A0`.
- Keeps normalized score output as `H-A`.
- Adds shared URL/slug, data-attribute, image alt/title, visible-text and DOM fallback helpers.
- Adds `genericModels(Document)` for additive fallback parsing.

## 2. No artificial parser limits
No parser contains the previous 50/100/300-result truncation controls.

## 3. Additive layered parsing
Source-specific parsing runs first. Generic fallback then runs as a second layer and only inserts a fixture when its canonical match key is not already present. This prevents a partially changed page from losing otherwise parseable fixtures.

## 4. Isolated repository execution
`ScraperRepository` now uses `supervisorScope` and source-local exception handling. One source can fail/timeout/return malformed HTML without cancelling the other four.

## 5. Multiple URL candidates
Each source has a primary correct-score URL and, where useful, a secondary today/predictions URL. A secondary URL is attempted only if the primary response produces no usable parsed matches.

## 6. Diagnostics
Each source reports:
- source name
- parsed count
- success flag
- error text
- HTTP code

The complete scan is stored in `lastScanReport` and logged by MainActivity under `CioScoreScraper`.

## 7. Existing Iddaa / HTFT code
The v0.23.15 Iddaa/HTFT repair is preserved. This release does not replace the official Iddaa feed with external prediction data.

## Build note
The source was checked for brace balance and obvious Kotlin structure issues. A full Android/Gradle build was not available in this execution environment because the project has no Gradle wrapper and the Android SDK/Gradle dependency cache is not installed here.
