# CioScore v0.23.12 — Parser + Diagnostic Refactor

## Parser / extraction
- Removed all artificial parser result truncation limits.
- Added layered team extraction helpers in `BaseParser` using CSS/data attributes, links and visible `home v away` text.
- Strengthened FP.com extraction with link/slug scoring and generic fallbacks.
- Strengthened PredictZ extraction with visible-text and link fallbacks.
- Strengthened WinDrawWin tip-link detection.
- Strengthened SoccerSeer for the current `Team A 2-2 Team B` row layout in addition to legacy prediction markers.
- DailySports existing robust marker/card extraction retained.

## Network / source reliability
- `ScraperRepository` no longer uses `HttpClient.getFast()` for source scans.
- Uses the resilient `HttpClient.get()` with retries and a 45s per-source coroutine budget.
- Adds source-specific referers.

## Diagnostics
- Added `ScraperRepository.SourceDiagnostic`.
- Added `ScraperRepository.ScraperScanReport`.
- `lastScanReport` stores the latest scan report.
- `fetchAllWithReport()` returns both source results and diagnostics.
- `MainActivity` logs per-source count, HTTP status and error to Logcat under `CioScoreScraper`.

This build is source-level refactoring. A full Android Gradle build was not run in this environment because the uploaded project has no `gradlew` wrapper and no system Gradle executable was available.
