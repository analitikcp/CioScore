# CioScore v0.23.14 — PARSER STABLE FALLBACK

Preserves the last known-working source parsers, removes all artificial extraction limits, adds conservative fallback extraction only when a primary parser yields no matches, and restores the proven fast HTTP path as the primary request with resilient fallback.
