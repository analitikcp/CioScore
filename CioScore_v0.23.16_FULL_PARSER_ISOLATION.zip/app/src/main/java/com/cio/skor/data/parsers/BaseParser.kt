package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/**
 * Common, crash-safe helpers shared by all five external score parsers.
 *
 * The existing project uses ScoreModel (not a separate ParsedScraperMatch
 * type), so this base class deliberately keeps that contract intact.
 */
abstract class BaseParser(protected val source: String = "Unknown") {

    /** Correct-score only: 0-0 through 5-5, with '-' or ':' and optional spaces. */
    protected val scoreRegex = Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")

    protected fun clean(s: String): String = s
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    /** Backward-compatible score helper used by all parser implementations. */
    protected fun extractScore(text: String): String? =
        scoreRegex.find(clean(text))?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }

    protected fun score(s: String): String? = extractScore(s)

    protected fun scoreAt(s: String): Pair<Int, String>? = scoreRegex.find(clean(s))?.let {
        it.range.first to "${it.groupValues[1]}-${it.groupValues[2]}"
    }

    protected fun team(s: String): String = clean(s)
        .replace(
            Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score|match preview)\\b"),
            " "
        )
        .replace(Regex("\\([^)]*\\)"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|', ',')

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..70 || b.length !in 2..70 || a.equals(b, true)) return false
        return looksLikeTeam(a) && looksLikeTeam(b)
    }

    protected fun looksLikeTeam(value: String): Boolean {
        val v = team(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
        val bad = Regex(
            "(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?|home|away|draw|tip|tips|pick|match preview|preview|analysis|statistics|stats|view|read more|more|today|tomorrow|yesterday|ft|final|finished|btts|over|under|1x2)$"
        )
        if (bad.matches(v)) return false
        if (v.contains(Regex("(?i)correct\\s*score|prediction|predicted|match preview|last 5|goals scored|goals conceded|read more"))) return false
        return true
    }

    /** Extract a fixture from a /home-team-vs-away-team/ style URL. */
    protected fun pairFromSlug(href: String): Pair<String, String>? {
        if (href.isBlank()) return null
        val decoded = try {
            URLDecoder.decode(href, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            href
        }
        var slug = decoded.substringBefore('?').substringBefore('#')
            .trimEnd('/').substringAfterLast('/').lowercase()
        slug = slug.replace(Regex("-(?:prediction|predictions|tip|tips|correct-score|odds|preview).*$"), "")

        for (marker in listOf("-vs-", "-v-", "-versus-")) {
            val idx = slug.indexOf(marker)
            if (idx <= 0) continue
            val h = slugWords(slug.substring(0, idx))
            val a = slugWords(slug.substring(idx + marker.length))
            if (valid(h, a)) return h to a
        }
        return null
    }

    private fun slugWords(s: String): String = s.replace('-', ' ')
        .replace(Regex("\\s+"), " ").trim()
        .split(' ').filter { it.isNotBlank() }
        .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }

    protected fun firstTeamPairFromLinks(element: Element): Pair<String, String>? {
        val candidates = element.select(
            "[data-home-team], [data-away-team], [data-team], [data-team-name], img[alt], img[title], a[href]"
        ).flatMap { n ->
            listOf(
                n.text(), n.attr("title"), n.attr("aria-label"), n.attr("data-team"),
                n.attr("data-team-name"), n.attr("data-home-team"), n.attr("data-away-team"), n.attr("alt")
            )
        }.map(::team).filter(::looksLikeTeam).distinct()

        return if (candidates.size >= 2) candidates[0] to candidates[1] else null
    }

    protected fun pairFromVisibleText(text: String): Pair<String, String>? {
        val t = clean(text)
        val m = Regex(
            "(?i)^(.{2,80}?)\\s+(?:v|vs|versus)\\s+(.{2,80}?)(?:\\s+(?:prediction|predicted|correct score|odds|tip|pick)\\b.*)?$"
        ).find(t) ?: return null
        val h = team(m.groupValues[1])
        val a = team(m.groupValues[2])
        return if (valid(h, a)) h to a else null
    }

    /**
     * Generic fallback candidates. This is deliberately targeted: it scans
     * match-like containers only and never walks every nested text node.
     */
    protected fun genericScoreElements(doc: Document): Sequence<Element> = sequence {
        val selectors = listOf(
            "tr:has(td)",
            "article",
            "li",
            "[class*=match]",
            "[class*=fixture]",
            "[class*=prediction]",
            "[class*=correct-score]",
            "[data-game]",
            "[data-match]",
            "[data-event]"
        )
        val seen = LinkedHashSet<Element>()
        for (selector in selectors) {
            for (e in doc.select(selector)) {
                val text = buildElementText(e)
                if (text.length in 8..1400 && scoreRegex.containsMatchIn(text) && seen.add(e)) {
                    yield(e)
                }
            }
        }
    }

    protected fun buildElementText(element: Element): String = buildString {
        append(element.text())
        listOf(
            "title", "aria-label", "data-match", "data-event", "data-teams",
            "data-home-team", "data-away-team", "data-team", "data-team-name"
        ).forEach { key ->
            val value = element.attr(key).trim()
            if (value.isNotEmpty()) append(" | ").append(value)
        }
        element.select("img[alt], img[title]").forEach { img ->
            val value = (img.attr("alt").ifBlank { img.attr("title") }).trim()
            if (value.isNotEmpty()) append(" | ").append(value)
        }
    }.replace(Regex("\\s+"), " ").trim()

    protected fun genericTeams(element: Element, raw: String, scoreStart: Int = -1): Pair<String, String>? {
        val homeSelectors = listOf(
            ".team-home", ".home-team", ".homeTeam", ".team1", ".home",
            "[class*=home-team]", "[class*=homeTeam]", "[data-home-team]"
        )
        val awaySelectors = listOf(
            ".team-away", ".away-team", ".awayTeam", ".team2", ".away",
            "[class*=away-team]", "[class*=awayTeam]", "[data-away-team]"
        )

        val h = homeSelectors.asSequence()
            .mapNotNull { element.selectFirst(it)?.text()?.let(::team) }
            .firstOrNull(::looksLikeTeam)
        val a = awaySelectors.asSequence()
            .mapNotNull { element.selectFirst(it)?.text()?.let(::team) }
            .firstOrNull(::looksLikeTeam)
        if (h != null && a != null && valid(h, a)) return h to a

        // URL/slug layer.
        for (link in element.select("a[href]")) {
            pairFromSlug(link.attr("href"))?.let { if (valid(it.first, it.second)) return it }
        }

        // Attribute/image/link layer.
        firstTeamPairFromLinks(element)?.let { if (valid(it.first, it.second)) return it }

        // Visible text layer.
        pairFromVisibleText(raw)?.let { return it }

        // Last-resort text around the score: Home v Away / Home - Away.
        if (scoreStart >= 0 && scoreStart <= raw.length) {
            var before = raw.substring(0, scoreStart).trim()
            before = before.replace(
                Regex("(?i)\\b(?:prediction|predicted|pred|tip|correct score|confidence|conf\\.)\\b.*$"),
                ""
            ).trim()
            for (sep in listOf(" vs ", " v ", " versus ", " – ", " — ", " - ", " @ ")) {
                val parts = before.split(sep, limit = 2)
                if (parts.size == 2) {
                    val home = team(parts[0])
                    val away = team(parts[1])
                    if (valid(home, away)) return home to away
                }
            }
        }
        return null
    }

    /** Generic source-neutral fallback. Source-specific parsers should run first. */
    protected fun genericModels(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        genericScoreElements(doc).forEach { el ->
            val raw = buildElementText(el)
            val found = scoreAt(raw) ?: return@forEach
            val pair = genericTeams(el, raw, found.first) ?: return@forEach
            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) return@forEach
            val model = ScoreModel(home, away, found.second, source)
            out[model.matchKey] = model
        }
        return out.values.toList()
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
