package com.cio.skor.data

import com.cio.skor.data.parsers.BaseParser
import com.cio.skor.data.parsers.DailySportsParser
import com.cio.skor.data.parsers.FPComParser
import com.cio.skor.data.parsers.PredictZParser
import com.cio.skor.data.parsers.SoccerSeerParser
import com.cio.skor.data.parsers.WinDrawWinParser
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.jsoup.Jsoup
import java.util.concurrent.atomic.AtomicInteger

/** Five independent correct-score sources. Official iddaa.com is enriched separately. */
class ScraperRepository {

    data class Source(
        val name: String,
        val urls: List<String>,
        val parser: BaseParser
    ) {
        constructor(name: String, url: String, parser: BaseParser) : this(name, listOf(url), parser)
    }

    data class SourceDiagnostic(
        val sourceName: String,
        val count: Int,
        val isSuccess: Boolean,
        val errorMessage: String? = null,
        val httpCode: Int = -1
    )

    data class ScraperScanReport(
        val diagnostics: List<SourceDiagnostic>,
        val totalRawMatches: Int
    )

    @Volatile
    var lastScanReport: ScraperScanReport = ScraperScanReport(emptyList(), 0)
        private set

    private val http = HttpClient()

    /** Primary URL first; alternatives are tried only when the previous attempt yields no usable matches. */
    private val sources = listOf(
        Source(
            "FP.com",
            listOf(
                "https://footballpredictions.com/betting-tips/correct-score/",
                "https://footballpredictions.com/todays-football-predictions/"
            ),
            FPComParser()
        ),
        Source(
            "PredictZ",
            listOf(
                "https://www.predictz.com/predictions/today/correct-score/",
                "https://www.predictz.com/predictions/today/"
            ),
            PredictZParser()
        ),
        Source(
            "WinDrawWin",
            listOf("https://www.windrawwin.com/predictions/today/"),
            WinDrawWinParser()
        ),
        Source(
            "SoccerSeer",
            listOf(
                "https://soccerseer.com/soccer/correct-score-predictions/",
                "https://soccerseer.com/"
            ),
            SoccerSeerParser()
        ),
        Source(
            "DailySports",
            listOf(
                "https://dailysports.net/mathematical-predictions/correct-score/",
                "https://dailysports.net/football/predictions/"
            ),
            DailySportsParser()
        )
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> =
        fetchAllWithReport(onProgress).first

    /**
     * Isolated source execution: one source can fail, timeout or return bad HTML
     * without cancelling its siblings or turning the entire scan into zero data.
     */
    suspend fun fetchAllWithReport(
        onProgress: (Int, String) -> Unit = { _, _ -> }
    ): Pair<List<SourceResult>, ScraperScanReport> = supervisorScope {
        val completed = AtomicInteger(0)
        val deferred = sources.map { source ->
            async(Dispatchers.IO) {
                val result = fetchSourceSafely(source)
                onProgress(completed.incrementAndGet(), source.name)
                result
            }
        }

        val results = deferred.awaitAll()
        val report = ScraperScanReport(
            diagnostics = results.map { r ->
                SourceDiagnostic(
                    sourceName = r.source,
                    count = r.scores.size,
                    isSuccess = r.error == null && r.scores.isNotEmpty(),
                    errorMessage = r.error,
                    httpCode = r.httpCode
                )
            },
            totalRawMatches = results.sumOf { it.scores.size }
        )
        lastScanReport = report
        results to report
    }

    private suspend fun fetchSourceSafely(source: Source): SourceResult {
        var lastCode = -1
        var lastError = "NO_USABLE_RESPONSE"

        for (url in source.urls) {
            try {
                val referer = refererFor(source.name)
                val response = withTimeoutOrNull(50_000L) {
                    withContext(Dispatchers.IO) {
                        // Fast path first; full retrying path is the fallback.
                        val fast = http.getFast(url, referer)
                        if (fast.first in 200..299 && !fast.second.isNullOrBlank()) {
                            fast
                        } else {
                            http.get(url, referer)
                        }
                    }
                }

                if (response == null) {
                    lastError = "TIMEOUT"
                    continue
                }

                val (code, html) = response
                lastCode = code
                if (code !in 200..299 || html.isNullOrBlank()) {
                    lastError = "HTTP_$code"
                    continue
                }

                try {
                    val doc = Jsoup.parse(html, url)
                    val parsed = source.parser.parse(doc)
                    if (parsed.isNotEmpty()) {
                        return SourceResult(source.name, code, parsed, null)
                    }
                    lastError = "ZERO_MATCHES_AFTER_PARSE"
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    lastError = "PARSE_${t.javaClass.simpleName}:${t.message ?: "error"}"
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                lastError = "NETWORK_${t.javaClass.simpleName}:${t.message ?: "error"}"
            }
        }

        return SourceResult(source.name, lastCode, emptyList(), lastError)
    }

    private fun refererFor(source: String): String = when (source) {
        "DailySports" -> "https://dailysports.net/"
        "PredictZ" -> "https://www.predictz.com/"
        "WinDrawWin" -> "https://www.windrawwin.com/"
        "SoccerSeer" -> "https://soccerseer.com/"
        else -> "https://footballpredictions.com/"
    }
}
