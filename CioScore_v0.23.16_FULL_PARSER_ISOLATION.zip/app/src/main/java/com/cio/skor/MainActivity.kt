package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)

        recyclerView = findViewById(R.id.recyclerScores)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            }
        )
        recyclerView.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scan() }
        // Toplu HT/FT ekranı: ana ekranda HT/FT maçları listelemiyoruz.
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        scanning = true
        setScanningUi(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all 5 score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all 6 before rendering cards.
                val (results, report) = withContext(Dispatchers.IO) { repo.fetchAllWithReport { _, _ -> } }
                report.diagnostics.forEach { d ->
                    Log.d("CioScoreScraper", "${d.sourceName}: ${d.count} matches, http=${d.httpCode}, success=${d.isSuccess}, error=${d.errorMessage}")
                }
                Log.d("CioScoreScraper", "TOTAL RAW MATCHES: ${report.totalRawMatches}")
                if (runId != scanGeneration) return@launch

                val scores: List<ScoreModel> = results
                    .flatMap { result: SourceResult -> result.scores }
                    .filter(::isDisplayable)
                    .distinctBy {
                        "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                        "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                        "${it.predictedScore}|${it.source.trim().lowercase()}"
                    }

                // Official Iddaa enrichment is optional for the main prediction list.
                // Never let a slow/unavailable official feed block the core scan.
                val officialResult = try {
                    withTimeoutOrNull(10_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) return@launch

                val unified = MatchMerger.mergeMatches(
                    scores,
                    officialResult?.matches.orEmpty()
                )

                val displayableUnified = unified.filter { it.predictions.isNotEmpty() }

                val baseGroups = displayableUnified
                    // iddaa.com is source 6 for identity/market enrichment; it does
                    // not add new prediction-only cards to the main analysis list.
                    .map { match ->
                    SofaScoreService.MatchGroupData(
                        homeTeam = match.mainHomeTeam,
                        awayTeam = match.mainAwayTeam,
                        predictions = match.predictions.map { (source, score) ->
                            ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                        }
                    )
                }

                // SofaScore is enrichment only. If its endpoint is slow/down,
                // render the already merged source data instead of losing the scan.
                val groupsWithIds = try {
                    withTimeoutOrNull(5_000L) {
                        sofaScore.enrichTeamIds(baseGroups)
                    } ?: baseGroups
                } catch (_: Exception) {
                    baseGroups
                }

                // IMPORTANT: enrichTeamIds preserves input order. Do not re-find
                // the official fixture by fuzzy team names here; that would create
                // a second, weaker matching layer and can reintroduce duplicates.
                // GlobalFixtureMatcher is the single identity authority.
                allGroups = displayableUnified.mapIndexed { index, unifiedMatch ->
                    val match = groupsWithIds.getOrNull(index)
                    val official = unifiedMatch.officialMatch

                    MatchGroup(
                        homeTeam = match?.homeTeam ?: unifiedMatch.mainHomeTeam,
                        awayTeam = match?.awayTeam ?: unifiedMatch.mainAwayTeam,
                        predictions = match?.predictions ?: unifiedMatch.predictions.map { (source, score) ->
                            ScoreModel(unifiedMatch.mainHomeTeam, unifiedMatch.mainAwayTeam, score, source)
                        },
                        iddaaMs1 = official?.ms1,
                        iddaaMsX = official?.msX,
                        iddaaMs2 = official?.ms2,
                        htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                        hasHtFt = official?.hasHtFt == true,
                        matchTimestamp = official?.matchTimestamp ?: 0L,
                        displayTime = official?.matchTime ?: "--:--",
                        displayDate = official?.matchDate ?: "",
                        homeTeamId = match?.homeTeamId,
                        awayTeamId = match?.awayTeamId
                    )
                }
                // One identity engine -> one fixture -> one UI card. There is no
                // second canonical groupBy pass because that can collapse distinct
                // same-team fixtures and hide identity errors.
                .distinctBy { MatchMerger.key(it.homeTeam, it.awayTeam) }
                .sortedWith(
                    compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                        .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                        .thenBy { it.homeTeam.lowercase() }
                )

                adapter.submitList(allGroups)
                focusPendingMatch()
            } catch (_: Exception) {
                // Keep the UI quiet; no partial duplicate list is rendered.
            } finally {
                setScanningUi(false)
            }
        }
    }


    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    companion object {
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
