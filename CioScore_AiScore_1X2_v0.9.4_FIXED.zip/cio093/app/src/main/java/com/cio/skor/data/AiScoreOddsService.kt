package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import java.util.Locale

/**
 * AiScore 1X2 enrichment.
 *
 * Important: do not guess an AiScore match URL from team names. AiScore match
 * pages contain an internal match id, and the prediction URL is not reliable
 * for every fixture. We first load AiScore's official "today matches" index,
 * resolve the real match/odds URL by fuzzy team-name matching, then read the
 * 1/X/2 opening odds from that match's /odds page.
 */
class AiScoreOddsService {
    data class Odds(
        val home: String,
        val draw: String,
        val away: String,
        val source: String = "AiScore"
    )

    private data class AiMatchLink(
        val home: String,
        val away: String,
        val oddsUrl: String
    )

    private val http = HttpClient()
    private val semaphore = Semaphore(6)

    @Volatile
    private var todayLinks: List<AiMatchLink> = emptyList()

    @Volatile
    private var todayLinksLoaded = false

    suspend fun enrich(
        groups: List<SofaScoreService.MatchGroupData>,
        onProgress: (completed: Int, total: Int) -> Unit = { _, _ -> },
        onItem: (group: SofaScoreService.MatchGroupData) -> Unit = {}
    ): List<SofaScoreService.MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups

        // One inexpensive index request resolves real AiScore match ids.
        val index = loadTodayMatchIndex()
        val results = groups.map { group ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val odds = findOdds(group.homeTeam, group.awayTeam, index)
                    val result = group.copy(
                        odds = odds?.let {
                            SofaScoreService.Odds(
                                home = it.home,
                                draw = it.draw,
                                away = it.away
                            )
                        }
                    )
                    onItem(result)
                    synchronized(this@AiScoreOddsService) {
                        completedCount += 1
                        onProgress(completedCount, groups.size)
                    }
                    result
                }
            }
        }.awaitAll()
        results
    }

    @Volatile
    private var completedCount: Int = 0

    private fun loadTodayMatchIndex(): List<AiMatchLink> {
        if (todayLinksLoaded) return todayLinks
        synchronized(this) {
            if (todayLinksLoaded) return todayLinks
            val (code, body) = http.getFast(
                "https://www.aiscore.com/today-matches/futbol",
                "https://www.aiscore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) {
                todayLinksLoaded = true
                todayLinks = emptyList()
                return todayLinks
            }

            val doc = Jsoup.parse(body)
            val found = LinkedHashMap<String, AiMatchLink>()
            for (a in doc.select("a[href*='/match-']")) {
                val href = a.attr("abs:href").ifBlank { a.attr("href") }
                if (href.isBlank()) continue
                val matchPath = href.substringBefore('?').substringBefore('#')
                if (!matchPath.contains("/match-")) continue

                val text = a.text().trim()
                if (text.isBlank()) continue

                val teams = extractTeams(text)
                if (teams == null) continue

                val oddsUrl = if (matchPath.endsWith("/odds")) {
                    matchPath
                } else {
                    matchPath.trimEnd('/') + "/odds"
                }
                found[oddsUrl] = AiMatchLink(teams.first, teams.second, oddsUrl)
            }

            todayLinks = found.values.toList()
            todayLinksLoaded = true
            return todayLinks
        }
    }

    /** Extract a home/away pair from common AiScore match-link anchor text. */
    private fun extractTeams(text: String): Pair<String, String>? {
        val cleaned = text.replace(Regex("\\s+"), " ").trim()
        val parts = cleaned.split(Regex("\\s+(?:vs|v)\\.?\\s+|\\s+-\\s+"), limit = 2)
        if (parts.size == 2 && parts[0].length >= 2 && parts[1].length >= 2) {
            return parts[0].trim() to parts[1].trim()
        }
        return null
    }

    private fun findOdds(
        home: String,
        away: String,
        index: List<AiMatchLink>
    ): Odds? {
        val resolved = index
            .map { link ->
                val score = teamPairScore(home, away, link.home, link.away)
                link to score
            }
            .filter { it.second >= 0.82 }
            .maxByOrNull { it.second }
            ?.first

        if (resolved != null) {
            val (code, body) = http.getFast(
                resolved.oddsUrl,
                "https://www.aiscore.com/today-matches/futbol"
            )
            if (code in 200..299 && !body.isNullOrBlank()) {
                parseOdds(body)?.let { return it }
            }
        }

        // Fallback for fixtures missing from today's index.
        return findPredictionFallback(home, away)
    }

    private fun findPredictionFallback(home: String, away: String): Odds? {
        val homeSlug = slug(home)
        val awaySlug = slug(away)
        if (homeSlug.isBlank() || awaySlug.isBlank()) return null

        val urls = listOf(
            "https://www.aiscore.com/prediction/football-$homeSlug-vs-$awaySlug-prediction",
            "https://www.aiscore.com/prediction/football-$awaySlug-vs-$homeSlug-prediction"
        )

        for (url in urls.distinct()) {
            val (code, body) = http.getFast(url, "https://www.aiscore.com/")
            if (code in 200..299 && !body.isNullOrBlank()) {
                parseOdds(body)?.let { return it }
            }
        }
        return null
    }

    private fun parseOdds(html: String): Odds? {
        val doc = Jsoup.parse(html)
        val text = doc.text().replace(Regex("\\s+"), " ")
        val marker = Regex("Opening odds", RegexOption.IGNORE_CASE).find(text)
            ?: return null

        val tail = text.substring(marker.range.last + 1)
        val values = Regex("""(?<![\\d.])(?:\\d{1,3})(?:\\.\\d{1,2})(?![\\d.])""")
            .findAll(tail)
            .map { it.value }
            .take(3)
            .toList()

        if (values.size != 3) return null
        val nums = values.mapNotNull { it.toDoubleOrNull() }
        if (nums.size != 3 || nums.any { it <= 1.0 || it > 100.0 }) return null

        return Odds(format(nums[0]), format(nums[1]), format(nums[2]))
    }

    private fun teamPairScore(
        wantedHome: String,
        wantedAway: String,
        actualHome: String,
        actualAway: String
    ): Double {
        val direct = (teamScore(wantedHome, actualHome) + teamScore(wantedAway, actualAway)) / 2.0
        val reversed = (teamScore(wantedHome, actualAway) + teamScore(wantedAway, actualHome)) / 2.0
        // Home/away order matters: reversed matches are deliberately penalized.
        return maxOf(direct, reversed - 0.10)
    }

    private fun teamScore(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        if (aa.contains(bb) || bb.contains(aa)) return 0.94
        val maxLen = maxOf(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun format(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    private fun slug(value: String): String {
        val lower = value.lowercase(Locale.US)
            .replace("&", " and ")
            .replace("ı", "i").replace("İ", "i")
            .replace("ş", "s").replace("Ş", "s")
            .replace("ğ", "g").replace("Ğ", "g")
            .replace("ü", "u").replace("Ü", "u")
            .replace("ö", "o").replace("Ö", "o")
            .replace("ç", "c").replace("Ç", "c")
            .replace("ø", "o").replace("Ø", "o")
            .replace("æ", "ae").replace("Æ", "ae")
            .replace("å", "a").replace("Å", "a")
        return lower.replace(Regex("[^a-z0-9]+"), "-").trim('-')
    }
}
