# CIO Score 0.10.7 – 6 Kaynak Scraper Fix

Bu sürüm mevcut 6 kaynaklı çalışan projeyi temel alır.

## Yapılan düzeltmeler
- Her kaynak için ayrı `HttpClient` instance'ı.
- Kaynağa göre doğru `Referer`.
- 429 ve 5xx için sınırlı retry.
- HTTP hataları artık `HTTP_403`, `HTTP_429` gibi görünür.
- Boş cevap `EMPTY_BODY`, parser hatası `PARSER_*`, skor bulunamaması `NO_SCORES` olarak raporlanır.
- Bir kaynağın hatası diğer kaynakların taramasını durdurmaz.
- İkinci taramada progress artık 0'dan başlar.
- DailySports için mevcut WebView fallback korunmuştur.
- GitHub Actions debug APK üretmeye devam eder.

## Kaynaklar
1. FP.com
2. Forebet
3. PredictZ
4. WinDrawWin
5. SoccerSeer
6. DailySports

> Not: Bu paket 6 kaynaklı tabanı düzeltir. Pasted edilen 7. kaynak olan FootballPredictionsNet için projede parser bulunmadığından sahte parser eklenmemiştir.
