package com.cio.skor.network

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Independent HTTP client for source scraping.
 * - Source-specific Referer/headers
 * - Retry for transient 429/5xx responses
 * - Never throws for normal HTTP error responses
 * - Returns the final HTTP code + body so the repository can diagnose failures
 */
class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(40, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    fun get(url: String): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null
        var lastError: Exception? = null

        repeat(3) { attempt ->
            try {
                val host = runCatching { java.net.URI(url).host.orEmpty() }.getOrDefault("")
                val referer = when {
                    host.contains("dailysports.net") -> "https://dailysports.net/"
                    host.contains("forebet.com") -> "https://www.forebet.com/"
                    host.contains("predictz.com") -> "https://www.predictz.com/"
                    host.contains("windrawwin.com") -> "https://www.windrawwin.com/"
                    host.contains("footballpredictions.com") -> "https://footballpredictions.com/"
                    host.contains("footballpredictions.net") -> "https://footballpredictions.net/"
                    host.contains("soccerseer.com") -> "https://soccerseer.com/"
                    else -> "https://www.google.com/"
                }

                val request = Request.Builder()
                    .url(url)
                    .get()
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                    .header("Cache-Control", "no-cache")
                    .header("Pragma", "no-cache")
                    .header("Referer", referer)
                    .header("DNT", "1")
                    .build()

                client.newCall(request).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string()
                    Log.d("CIO_HTTP", "attempt=${attempt + 1} HTTP=$lastCode bytes=${lastBody?.length ?: 0} host=$host url=${response.request.url}")

                    // Retry only transient/rate-limit responses.
                    if (lastCode == 429 || lastCode in 500..599) {
                        if (attempt < 2) {
                            Thread.sleep(700L * (attempt + 1))
                            return@repeat
                        }
                    }

                    return lastCode to lastBody
                }
            } catch (e: Exception) {
                lastError = e
                Log.w("CIO_HTTP", "attempt=${attempt + 1} failed url=$url", e)
                if (attempt < 2) Thread.sleep(500L * (attempt + 1))
            }
        }

        if (lastError != null) {
            throw lastError as Exception
        }
        return lastCode to lastBody
    }
}
