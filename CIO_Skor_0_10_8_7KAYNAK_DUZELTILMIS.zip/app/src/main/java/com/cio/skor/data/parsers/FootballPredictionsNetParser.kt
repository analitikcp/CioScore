package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

/**
 * FootballPredictions.net correct-score parser.
 *
 * The site has used several HTML layouts over time, so the parser deliberately
 * uses multiple anchors: fixture links, explicit home/away classes, and the
 * visible "Team A vs Team B" text. Scores are taken only from the same row/card
 * as the fixture and only after a date/time anchor when one exists.
 */
class FootballPredictionsNetParser : BaseParser("FootballPredictionsNet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // Table rows are the preferred structure on the correct-score page.
        for (row in doc.select("table tr")) {
            addFromElement(row, out)
            if (out.size >= 100) break
        }

        // Card/link based layouts are used as fallback.
        if (out.isEmpty()) {
            val candidates = doc.select(
                "article, li, .match, .fixture, .prediction, [class*=match], " +
                    "[class*=fixture], [class*=prediction], [class*=correct-score]"
            )
            for (el in candidates) {
                addFromElement(el, out)
                if (out.size >= 100) break
            }
        }

        return out.values.toList()
    }

    private fun addFromElement(el: Element, out: LinkedHashMap<String, ScoreModel>) {
        val raw = clean(el.text())
        if (raw.length !in 8..1200) return

        val score = extractScore(el, raw) ?: return
        val teams = extractTeams(el) ?: splitVisibleTeams(raw) ?: return

        val home = cleanTeamName(teams.first)
        val away = cleanTeamName(teams.second)
        if (!valid(home, away)) return
        if (looksLikeNoise(home) || looksLikeNoise(away)) return

        val model = ScoreModel(home, away, score, source)
        out[model.matchKey] = model
    }

    private fun extractScore(el: Element, raw: String): String? {
        // Prefer explicit correct-score labels.
        val labelled = Regex(
            "(?i)(?:correct\\s*score|predicted\\s*score|score\\s*tip|prediction)" +
                "[^0-9]{0,80}([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})"
        ).find(raw)
        if (labelled != null) return normalizeScore(labelled.groupValues[1], labelled.groupValues[2])

        // If a date/time is present, only inspect the text after it. This avoids
        // accidentally interpreting YYYY-MM-DD fragments as a score.
        val dateIndex = Regex("\\b20\\d{2}[-/]\\d{1,2}[-/]\\d{1,2}\\b").find(raw)?.range?.last
        val afterDate = if (dateIndex != null) raw.substring(dateIndex + 1) else raw
        val scores = Regex("\\b([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})\\b").findAll(afterDate)

        for (m in scores) {
            val a = m.groupValues[1].toIntOrNull() ?: continue
            val b = m.groupValues[2].toIntOrNull() ?: continue
            if (a in 0..15 && b in 0..15) return "$a-$b"
        }

        return null
    }

    private fun normalizeScore(a: String, b: String): String? {
        val x = a.toIntOrNull() ?: return null
        val y = b.toIntOrNull() ?: return null
        if (x !in 0..15 || y !in 0..15) return null
        return "$x-$y"
    }

    private fun extractTeams(el: Element): Pair<String, String>? {
        val home = firstText(
            el,
            ".home-team", ".homeTeam", ".team-home", ".home", 
            "[class*=home-team]", "[class*=homeTeam]"
        )
        val away = firstText(
            el,
            ".away-team", ".awayTeam", ".team-away", ".away",
            "[class*=away-team]", "[class*=awayTeam]"
        )
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // Fixture links are usually the cleanest source of the two team names.
        for (a in el.select("a[href]")) {
            val text = clean(a.text())
            splitVisibleTeams(text)?.let { return it }

            val href = a.attr("href")
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
            val slugPair = splitSlug(slug)
            if (slugPair != null) return slugPair
        }

        return null
    }

    private fun splitVisibleTeams(value: String): Pair<String, String>? {
        val cleaned = cleanTeamName(
            value.replace(Regex("(?i)\\b(?:preview|prediction|correct score|odds|tips?)\\b.*$"), "")
        )
        val m = Regex("(?i)^(.+?)\\s+(?:vs?|versus)\\s+(.+)$").find(cleaned)
        if (m != null) {
            val h = cleanTeamName(m.groupValues[1])
            val a = cleanTeamName(m.groupValues[2])
            if (valid(h, a)) return h to a
        }

        // Common layout: two team names separated by a dash/em dash.
        for (sep in listOf(" – ", " — ", " - ")) {
            val idx = cleaned.indexOf(sep)
            if (idx > 1) {
                val h = cleanTeamName(cleaned.substring(0, idx))
                val a = cleanTeamName(cleaned.substring(idx + sep.length))
                if (valid(h, a)) return h to a
            }
        }
        return null
    }

    private fun splitSlug(slugValue: String): Pair<String, String>? {
        val slug = slugValue
            .replace(Regex("-(?:predictions?|betting|tips?|correct-score|odds).*$", RegexOption.IGNORE_CASE), "")
        for (sep in listOf("-v-", "-vs-", "-versus-")) {
            val idx = slug.indexOf(sep)
            if (idx > 1) {
                val h = slugWords(slug.substring(0, idx))
                val a = slugWords(slug.substring(idx + sep.length))
                if (valid(h, a)) return h to a
            }
        }
        return null
    }

    private fun slugWords(value: String): String = value
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
        .split(' ')
        .filter { it.isNotBlank() }
        .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }

    private fun firstText(el: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = el.select(selector).firstOrNull()?.text()?.let(::cleanTeamName)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun cleanTeamName(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .replace(Regex("(?i)\\b(?:correct\\s*score|predicted\\s*score|prediction|odds|probability|betting tips?|preview|analysis)\\b.*$"), "")
        .trim(' ', '-', '–', '—', ':', '|', '•')

    private fun looksLikeNoise(value: String): Boolean {
        val v = value.trim()
        if (v.matches(Regex("^[0-9 .:/+%-]+$"))) return true
        val bad = listOf("match", "prediction", "predicted", "correct score", "odds", "probability", "tip", "tips")
        return bad.any { v.equals(it, true) }
    }
}
