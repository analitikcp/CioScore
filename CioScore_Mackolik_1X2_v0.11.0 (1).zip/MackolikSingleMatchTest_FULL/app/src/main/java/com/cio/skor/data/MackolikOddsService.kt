package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

/**
 * Maçkolik İddaa Programı'nı TEK HTTP isteğiyle okur.
 *
 * Doğrulanmış sayfa: https://arsiv2.mackolik.com/Iddaa-Programi
 * Her maç satırındaki ilk üç ondalık değer MS1 / MSX / MS2 olarak alınır.
 */
class MackolikOddsService {
    companion object {
        private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    data class MackolikMatch(
        val homeTeam: String,
        val awayTeam: String,
        val odds: SofaScoreService.Odds
    )

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val matches: List<MackolikMatch>,
        val error: String? = null
    )

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(PROGRAM_URL)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                .header("Referer", "https://arsiv2.mackolik.com/")
                .build()

            client.newCall(request).execute().use { response ->
                val html = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result(response.code, html.length, emptyList(), "HTTP ${response.code}")
                }

                val doc = Jsoup.parse(html)
                val parsed = LinkedHashMap<String, MackolikMatch>()
                val rows = doc.select("tr")
                val oddsRegex = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
                val codeAndOddsRegex = Regex("\\b\\d{5}\\s+([0-9]{1,2}[.,][0-9]{2})\\s+([0-9]{1,2}[.,][0-9]{2})\\s+([0-9]{1,2}[.,][0-9]{2})")
                val timeRegex = Regex("^\\d{1,2}:\\d{2}\\s+")

                for (row in rows) {
                    val text = row.text().replace(Regex("\\s+"), " ").trim()
                    if (text.isBlank()) continue

                    val codeMatch = codeAndOddsRegex.find(text) ?: continue
                    val prefix = text.substring(0, codeMatch.range.first).trim()
                    val teamsText = prefix.replace(timeRegex, "").trim()

                    val dash = teamsText.indexOf(" - ")
                    if (dash <= 0 || dash >= teamsText.length - 3) continue

                    val home = cleanTeam(teamsText.substring(0, dash))
                    val away = cleanTeam(teamsText.substring(dash + 3))
                    if (home.isBlank() || away.isBlank()) continue
                    if (home.length > 80 || away.length > 80) continue
                    if (!looksLikeTeamPair(home, away)) continue

                    val values = codeMatch.groupValues.drop(1).map { it.replace(',', '.') }
                    if (values.size != 3 || values.any { !it.matches(Regex("\\d{1,2}\\.\\d{2}")) }) continue

                    val key = MatchMerger.key(home, away)
                    parsed[key] = MackolikMatch(
                        homeTeam = home,
                        awayTeam = away,
                        odds = SofaScoreService.Odds(values[0], values[1], values[2])
                    )
                }

                // İkinci, daha toleranslı geçiş: selector/format değişirse satırın
                // içindeki takım adlarını mevcut Cio maçlarıyla eşleştirmek için
                // yalnızca odds üçlüsünü güvenceye alıyoruz. İlk geçiş başarılıysa
                // hiçbir ekstra HTTP isteği yapılmaz.
                val fallbackRows = if (parsed.isEmpty()) rows else emptyList()
                if (fallbackRows.isNotEmpty()) {
                    for (row in fallbackRows) {
                        val text = row.text().replace(Regex("\\s+"), " ").trim()
                        val odds = oddsRegex.findAll(text).map { it.value.replace(',', '.') }.toList()
                        if (odds.size < 3) continue
                        val candidate = extractTeamsBeforeOdds(text, odds.first()) ?: continue
                        val key = MatchMerger.key(candidate.first, candidate.second)
                        parsed[key] = MackolikMatch(
                            candidate.first,
                            candidate.second,
                            SofaScoreService.Odds(odds[0], odds[1], odds[2])
                        )
                    }
                }

                Result(response.code, html.length, parsed.values.toList())
            }
        } catch (e: Exception) {
            Result(-1, 0, emptyList(), "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
        }
    }

    fun findForTeamPair(
        matches: List<MackolikMatch>,
        homeTeam: String,
        awayTeam: String
    ): MackolikMatch? {
        return matches.firstOrNull {
            MatchMerger.isSameTeam(it.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(it.awayTeam, awayTeam)
        }
    }

    private fun cleanTeam(value: String): String {
        return value
            .replace(Regex("\\s+"), " ")
            .trim(' ', '|', '•')
            .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
            .trim()
    }

    private fun looksLikeTeamPair(home: String, away: String): Boolean {
        val bad = setOf("İddaa", "Programı", "MS", "Kod", "Lig", "Tümü")
        return home.length >= 2 && away.length >= 2 &&
            bad.none { home.equals(it, true) || away.equals(it, true) }
    }

    private fun extractTeamsBeforeOdds(text: String, firstOdd: String): Pair<String, String>? {
        val idx = text.indexOf(firstOdd)
        if (idx <= 0) return null
        var prefix = text.substring(0, idx).trim()
        prefix = prefix.replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "").trim()
        val dash = prefix.indexOf(" - ")
        if (dash <= 0) return null
        val home = cleanTeam(prefix.substring(0, dash))
        val away = cleanTeam(prefix.substring(dash + 3))
        return if (looksLikeTeamPair(home, away)) home to away else null
    }
}
