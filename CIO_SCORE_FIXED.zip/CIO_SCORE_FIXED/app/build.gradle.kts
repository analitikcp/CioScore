plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cio.skor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.cio.skor"
        minSdk = 24
        targetSdk = 35
        versionCode = 6
        versionName = "0.4.9-forebet-fix"
    }
    buildTypes { release { isMinifyEnabled = false } }
}

dependencies { implementation("org.jsoup:jsoup:1.18.3") }
