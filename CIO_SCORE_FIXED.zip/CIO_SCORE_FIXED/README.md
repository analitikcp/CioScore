# CIO SCORE 0.4.9 — Forebet Fix

Forebet parser'ı düzeltilmiş Android kaynak projesi.

Eski sürüm Forebet kartında `Pred/Prediction/Correct Score/Score` kelimesini aynı HTML elementinde arıyordu. Bu şart sağlanmadığında HTTP 200 gelse bile 0 maç dönebiliyordu. Yeni sürüm Forebet'e özgü kartları, geniş kartları ve son çare olarak sayfa metnindeki skorları tarıyor.

Kaynakta bulunmayan skor uydurulmaz. Proje Android Studio ile açılıp derlenebilir.
