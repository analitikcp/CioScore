# CIO Skor APK – 0.1.0

Bu ilk Android prototipidir.

- 16 skor kaynağı listelenir.
- Kaynakların Correct Score sayfaları WebView içinde açılır.
- API anahtarı içermez.
- Telegram/Google Apps Script içermez.
- Sonraki aşamada kaynak sayfalarından maç + skor çıkarma ve aynı maçları eşleştirme yapılacaktır.

## APK oluşturma
Android Studio ile projeyi açın.
Gradle sync tamamlandıktan sonra:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Android build sistemi APK üretmek için Gradle/Android Gradle Plugin kullanır.
