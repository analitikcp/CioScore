# CioScore v0.13.1

## 7 critical fixes
- VALUE uses expected value (EV): CIO probability × decimal odds - 1.
- CIO probabilities use mild Jeffreys smoothing to avoid artificial 0%/100%.
- Match merging uses safer containment rules and 82% fuzzy threshold.
- CioScore and CIO probability remain explicitly separate.
- UI labels market disagreement as ORAN ÇELİŞKİSİ, not ORAN YALANI.
- Duplicate score-consensus block removed.
- Android version aligned to 0.13.1 / versionCode 119; Maçkolik is the displayed odds source.

CioScore is a consensus/strength index, not a literal win probability.
