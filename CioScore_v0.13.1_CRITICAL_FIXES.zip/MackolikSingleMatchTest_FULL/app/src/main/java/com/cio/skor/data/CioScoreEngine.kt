package com.cio.skor.data

/**
 * CioScore 2.0
 *
 * CioScore is a strength/consensus index (0-100), NOT a literal win probability.
 * Outcome probabilities are consensus estimates derived from the available CIO
 * predictions. Market probabilities are normalized from the 1X2 odds.
 */
object CioScoreEngine {
    data class ScoreConsensus(val score: String, val count: Int, val percent: Int)

    data class Result(
        val score: Int,
        val confidence: String,
        val exactConsensus: Int,
        val outcomeConsensus: Int,
        val marketConfidence: Int,
        val directionAgreement: Int,
        val sourceCoverage: Int,
        val topScores: List<ScoreConsensus>,
        val cioProbabilities: Map<String, Int>,
        val marketProbabilities: Map<String, Int>,
        val value: Map<String, Int>,
        val bestValueDirection: String?,
        val bestValuePoints: Int,
        val marketMismatch: Int,
        val bestValueEdge: Int
    )

    fun calculate(predictions: List<ScoreModel>, odds: SofaScoreService.Odds?): Result {
        if (predictions.isEmpty()) {
            return Result(0, "Düşük", 0, 0, 0, 0, 0, emptyList(), emptyMap(), emptyMap(), emptyMap(), null, 0, 0, 0)
        }

        val n = predictions.size.toDouble()
        val scoreCounts = predictions
            .map { it.predictedScore.trim() }
            .filter { Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").matches(it) }
            .groupingBy { it }
            .eachCount()

        val exactMax = scoreCounts.values.maxOrNull() ?: 0
        val exact = exactMax / n

        val topScores = scoreCounts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(3)
            .map { ScoreConsensus(it.key, it.value, (it.value / n * 100.0).toInt()) }

        val outcomes = predictions.mapNotNull { outcome(it.predictedScore) }
        val outcomeCounts = outcomes.groupingBy { it }.eachCount()
        val outcomeMax = outcomeCounts.values.maxOrNull() ?: 0
        val outcome = if (outcomes.isEmpty()) 0.0 else outcomeMax / outcomes.size.toDouble()
        val cioProb = outcomeProbabilities(outcomes)

        val market = odds?.let { marketProbabilities(it) }
        val marketConfidence = market?.values?.maxOrNull() ?: 0.0
        val cioDirection = outcomeCounts.maxByOrNull { it.value }?.key
        val marketDirection = market?.maxByOrNull { it.value }?.key
        val agreement = if (cioDirection != null && marketDirection != null && cioDirection == marketDirection) 1.0 else 0.0

        val sourceCoverage = (predictions.map { it.source.trim().lowercase() }.distinct().size / 5.0).coerceIn(0.0, 1.0)
        val stability = if (outcomes.isEmpty()) 0.0 else outcomeCounts.values.maxOrNull()!!.toDouble() / outcomes.size.toDouble()

        // Strength score: deliberately separate from betting probability/value.
        val raw =
            25.0 * exact +
            20.0 * outcome +
            15.0 * marketConfidence +
            15.0 * agreement +
            10.0 * sourceCoverage +
            15.0 * stability

        val score = raw.coerceIn(0.0, 100.0).toInt()
        val confidence = when {
            score >= 80 -> "Yüksek"
            score >= 65 -> "Orta-Yüksek"
            score >= 50 -> "Orta"
            else -> "Düşük"
        }

        val marketMap = market?.mapValues { (it.value * 100.0).toInt() } ?: emptyMap()
        val cioMap = cioProb.mapValues { (it.value * 100.0).toInt() }

        // VALUE is expected value (EV), not merely a probability-point difference:
        // EV = CIO probability × decimal odds - 1. This directly answers whether
        // the CIO estimate is attractive at the quoted price.
        val valueMap = if (market != null && odds != null) {
            val decimalOdds = mapOf("1" to odds.home, "X" to odds.draw, "2" to odds.away)
                .mapValues { it.value.toDoubleOrNull() ?: 0.0 }
            listOf("1", "X", "2").associateWith { direction ->
                val p = cioProb[direction].orZero()
                val odd = decimalOdds[direction] ?: 0.0
                if (p > 0.0 && odd > 1.0) (p * odd - 1.0) * 100.0 else 0.0
            }.mapValues { kotlin.math.round(it.value).toInt() }
        } else emptyMap()

        val best = valueMap.maxByOrNull { it.value }
        val bestEdge = if (market != null) {
            listOf("1", "X", "2").maxOfOrNull { direction ->
                kotlin.math.abs(cioProb[direction].orZero() - market[direction].orZero()) * 100.0
            }?.toInt() ?: 0
        } else 0

        return Result(
            score = score,
            confidence = confidence,
            exactConsensus = (exact * 100).toInt(),
            outcomeConsensus = (outcome * 100).toInt(),
            marketConfidence = (marketConfidence * 100).toInt(),
            directionAgreement = (agreement * 100).toInt(),
            sourceCoverage = (sourceCoverage * 100).toInt(),
            topScores = topScores,
            cioProbabilities = cioMap,
            marketProbabilities = marketMap,
            value = valueMap,
            bestValueDirection = best?.key,
            bestValuePoints = best?.value ?: 0,
            marketMismatch = bestEdge,
            bestValueEdge = bestEdge
        )
    }

    private fun outcomeProbabilities(outcomes: List<String>): Map<String, Double> {
        if (outcomes.isEmpty()) return emptyMap()
        // Mild Jeffreys smoothing (0.5 pseudo-observation per outcome) avoids
        // artificial hard 0%/100% values without overwhelming a five-source sample.
        val counts = outcomes.groupingBy { it }.eachCount()
        val prior = 0.5
        val denominator = outcomes.size + prior * 3.0
        return listOf("1", "X", "2").associateWith { key ->
            ((counts[key] ?: 0) + prior) / denominator
        }
    }

    private fun marketProbabilities(odds: SofaScoreService.Odds): Map<String, Double>? {
        val values = listOf(odds.home.toDoubleOrNull(), odds.draw.toDoubleOrNull(), odds.away.toDoubleOrNull())
        if (values.any { value -> value == null || value <= 1.0 }) return null
        val raw = values.map { 1.0 / (it ?: return null) }
        val total = raw.sum()
        if (total <= 0.0) return null
        return mapOf("1" to raw[0] / total, "X" to raw[1] / total, "2" to raw[2] / total)
    }

    private fun outcome(score: String): String? {
        val m = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = m.groupValues[1].toIntOrNull() ?: return null
        val away = m.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }

    private fun Double?.orZero(): Double = this ?: 0.0
}
