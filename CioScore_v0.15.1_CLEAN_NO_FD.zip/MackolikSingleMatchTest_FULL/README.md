# CioScore v0.15.1

- 5 tahmin kaynağı → MatchMerger → CIO modeli.
- Maçkolik 1X2 oranları ayrı piyasa referansı olarak kullanılır.
- SofaScore takım adına dokunulduğunda Son 5 Maç verisi getirir.
- Ana ekrandaki tarama durum satırı kaldırıldı.
- Alt KAYNAK / TEMİZ SKOR / MAÇ istatistik footer kaldırıldı.
- Eski tarihsel CSV entegrasyonu ve buna ait indirme/cache katmanı paketten çıkarıldı.
- GÜÇLÜ/SKOR küçük filtre butonları bu sürümde bulunmaz.
