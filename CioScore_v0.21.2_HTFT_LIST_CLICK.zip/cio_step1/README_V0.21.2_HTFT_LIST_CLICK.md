# CioScore v0.21.2 — HT/FT Liste Maç Tıklama

Bu sürümde **HT/FT Açılan Maçlar** ekranındaki her maç satırı tıklanabilir.

Akış:

1. Ana ekranda `HT/FT AÇILAN MAÇLAR` açılır.
2. Kullanıcı listeden bir maça dokunur.
3. HT/FT ekranı `RESULT_OK` ile ana ekrana resmi takım adlarını ve maç zamanını döndürür.
4. Ana ekran mevcut `allGroups` listesindeki canonical takım kimliklerini karşılaştırır.
5. Aynı takımların aynı gün birden fazla fikstürü olabilmesi için en yakın `matchTimestamp` seçilir.
6. Arama filtresi temizlenir ve RecyclerView doğrudan ilgili maç kartına kaydırılır.

Mevcut GlobalFixtureMatcher / MatchMerger mimarisine yeni bir fuzzy eşleştirme katmanı eklenmemiştir.
