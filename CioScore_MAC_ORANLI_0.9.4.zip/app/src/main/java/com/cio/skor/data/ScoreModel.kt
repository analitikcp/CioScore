package com.cio.skor.data

data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String,
    // 1X2 match odds; nullable because a source may not provide odds.
    val ms1: String? = null,
    val msX: String? = null,
    val ms2: String? = null
) {
    val matchKey: String get() = MatchMerger.key(homeTeam, awayTeam)
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null
)
