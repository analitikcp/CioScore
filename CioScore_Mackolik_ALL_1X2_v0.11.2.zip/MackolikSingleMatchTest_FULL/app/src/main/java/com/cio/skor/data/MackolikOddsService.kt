package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.concurrent.TimeUnit

/**
 * Maçkolik İddaa Programı'nı TEK HTTP isteğiyle okur.
 *
 * Doğrulanmış HTML yapısı:
 *   Saat | ... | Takım 1 - Takım 2 | Kod | MS1 | MSX | MS2 | ...
 *
 * Önemli: bütün HTML'i "üç oran gördüm = maç" diye taramıyoruz.
 * Önce gerçek maç satırını (TR), sonra 5 haneli MS kodunu, ardından
 * kodun hemen arkasındaki ilk üç MS 1/X/2 oranını okuyoruz.
 */
class MackolikOddsService {
    companion object {
        private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"
        private val ODDS = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
        private val CODE = Regex("(?<![0-9])\\d{5}(?![0-9])")
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    data class MackolikMatch(
        val homeTeam: String,
        val awayTeam: String,
        val odds: SofaScoreService.Odds
    )

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val rowCount: Int,
        val parsedRows: Int,
        val matches: List<MackolikMatch>,
        val error: String? = null
    )

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(PROGRAM_URL)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                .header("Referer", "https://arsiv2.mackolik.com/")
                .build()

            client.newCall(request).execute().use { response ->
                val html = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result(
                        response.code, html.length, 0, 0, emptyList(), "HTTP ${response.code}"
                    )
                }

                val doc = Jsoup.parse(html, PROGRAM_URL)
                val rows = doc.select("tr")
                val parsed = LinkedHashMap<String, MackolikMatch>()
                var parsedRows = 0

                for (row in rows) {
                    val parsedMatch = parseMatchRow(row) ?: continue
                    parsedRows++
                    val key = MatchMerger.key(parsedMatch.homeTeam, parsedMatch.awayTeam)
                    parsed[key] = parsedMatch
                }

                Result(
                    httpCode = response.code,
                    htmlLength = html.length,
                    rowCount = rows.size,
                    parsedRows = parsedRows,
                    matches = parsed.values.toList(),
                    error = null
                )
            }
        } catch (e: Exception) {
            Result(
                httpCode = -1,
                htmlLength = 0,
                rowCount = 0,
                parsedRows = 0,
                matches = emptyList(),
                error = "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}"
            )
        }
    }

    /**
     * Gerçek Mackolik maç satırını parse eder.
     * Öncelik: takım hücresi + 5 haneli kod + kod sonrası ilk 3 MS oranı.
     */
    private fun parseMatchRow(row: Element): MackolikMatch? {
        val text = row.text().replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        val codeMatch = CODE.find(text) ?: return null
        val afterCode = text.substring(codeMatch.range.last + 1)

        // Koddan sonra gelen ilk üç oran doğrudan MS 1 / X / 2'dir.
        val odds = ODDS.findAll(afterCode)
            .map { it.value.replace(',', '.') }
            .take(3)
            .toList()

        if (odds.size != 3) return null

        val teams = extractTeamPair(row, text, codeMatch.range.first)
            ?: return null

        if (!validTeam(teams.first) || !validTeam(teams.second)) return null

        return MackolikMatch(
            homeTeam = teams.first,
            awayTeam = teams.second,
            odds = SofaScoreService.Odds(odds[0], odds[1], odds[2])
        )
    }

    /**
     * Maçkolik'in takım adı hücresini doğrudan bulur.
     * Hücre yapısı değişirse satır metni üzerinden güvenli fallback kullanılır.
     */
    private fun extractTeamPair(row: Element, text: String, codeStart: Int): Pair<String, String>? {
        // 1) Gerçek HTML'deki takım hücresini tercih et.
        val cells = row.select("td, th")
        for (cell in cells) {
            val cellText = cell.text().replace(Regex("\\s+"), " ").trim()
            val pair = splitTeamPair(cellText)
            if (pair != null && validTeam(pair.first) && validTeam(pair.second)) {
                return pair
            }
        }

        // 2) Koddan önceki bölümden fallback.
        val prefix = text.substring(0, codeStart)
            .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
            .trim()

        return splitTeamPair(prefix)
    }

    private fun splitTeamPair(value: String): Pair<String, String>? {
        var text = value.replace(Regex("\\s+"), " ").trim()
        if (text.isBlank()) return null

        // Başlangıç saati / tablo artıklarını temizle.
        text = text.replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "").trim()
        text = text.trim(' ', '|', '•')

        val dash = text.indexOf(" - ")
        if (dash <= 0 || dash >= text.length - 3) return null

        val home = cleanTeam(text.substring(0, dash))
        val away = cleanTeam(text.substring(dash + 3))
        return if (home.isNotBlank() && away.isNotBlank()) home to away else null
    }

    private fun cleanTeam(value: String): String {
        return value
            .replace(Regex("\\s+"), " ")
            .trim(' ', '|', '•')
            .replace(Regex("\\s+(?:\\d{5})$"), "")
            .trim()
    }

    private fun validTeam(value: String): Boolean {
        if (value.length !in 2..80) return false
        if (value.count { it.isLetter() } < 2) return false

        val bad = setOf(
            "İddaa", "Programı", "MS", "Kod", "Lig", "Tümü", "Futbol", "Basketbol"
        )
        return bad.none { value.equals(it, ignoreCase = true) }
    }

    fun findForTeamPair(
        matches: List<MackolikMatch>,
        homeTeam: String,
        awayTeam: String
    ): MackolikMatch? {
        return matches.firstOrNull {
            MatchMerger.isSameTeam(it.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(it.awayTeam, awayTeam)
        }
    }
}
