package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser restored from the last known working Forebet build.
 *
 * Forebet exposes each fixture as a .rcnt match block. The home/away names
 * live in .homeTeam / .awayTeam and the correct-score value is exposed in
 * .ex_sc.tabonly. We keep the parser deliberately narrow so it cannot pick
 * up probabilities/odds/final scores from elsewhere in the row.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val blocks = doc.select("div.rcnt")
            .ifEmpty { doc.select("div.rcnt[class*=tr_]") }

        for (block in blocks) {
            val home = firstTeam(block, ".homeTeam") ?: continue
            val away = firstTeam(block, ".awayTeam") ?: continue

            val cleanHome = cleanForebetTeam(home)
            val cleanAway = cleanForebetTeam(away)
            if (!valid(cleanHome, cleanAway)) continue

            val predictedScore = extractCorrectScore(block)
                ?: extractPredictedScore(block)
                ?: continue

            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 80) break
        }

        return out.values.toList()
    }

    private fun firstTeam(block: Element, selector: String): String? {
        val element = block.select(selector).firstOrNull() ?: return null
        val value = element.select("span").firstOrNull()?.text()
            ?.takeIf { it.isNotBlank() }
            ?: element.text()
        return value.replace('\u00A0', ' ').trim().takeIf { it.isNotBlank() }
    }

    private fun extractCorrectScore(block: Element): String? {
        for (element in block.select("div.ex_sc.tabonly, div.ex_sc, [class*=ex_sc]")) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun extractPredictedScore(block: Element): String? {
        for (element in block.select("span.forepr, .forepr, [class*=forepr]")) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun exactScore(value: String): String? {
        val text = value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        val match = Regex("^([0-5])\\s*[-:]\\s*([0-5])$").matchEntire(text) ?: return null
        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun cleanForebetTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')
}
