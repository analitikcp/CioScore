CIO Score 0.8.15 — Forebet recovery from the known working 0.8.7 request/parser behavior.

FP.com, PredictZ, WinDrawWin and SoccerSeer are preserved. The Forebet parser is restored
from the known working parser structure, and Forebet is requested first with the exact
mobile CIOScore user-agent used by the last known working build, with desktop fallback.
No merge-engine changes are included in this build.
