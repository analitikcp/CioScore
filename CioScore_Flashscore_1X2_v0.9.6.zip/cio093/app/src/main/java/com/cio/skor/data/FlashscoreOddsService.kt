package com.cio.skor.data

import com.cio.skor.network.HttpClient
import com.cio.skor.data.SofaScoreService.MatchGroupData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import java.util.Locale

/**
 * Flashscore 1X2 enrichment.
 *
 * The main scan is independent from this service. We load Flashscore's football
 * index once, resolve real match URLs by fuzzy team-name matching, then read the
 * 1/X/2 odds shown on the match page. Results are streamed back to the UI.
 */
class FlashscoreOddsService {
    data class Odds(
        val home: String,
        val draw: String,
        val away: String,
        val source: String = "Flashscore"
    )

    private data class FlashMatchLink(
        val home: String,
        val away: String,
        val url: String
    )

    private val http = HttpClient()
    private val semaphore = Semaphore(6)

    @Volatile private var todayLinks: List<FlashMatchLink> = emptyList()
    @Volatile private var todayLinksLoaded = false

    suspend fun enrich(
        groups: List<MatchGroupData>,
        onProgress: (completed: Int, total: Int) -> Unit = { _, _ -> },
        onItem: (group: MatchGroupData) -> Unit = {}
    ): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups

        val index = loadTodayMatchIndex()
        var completed = 0

        groups.map { group ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    val odds = findOdds(group.homeTeam, group.awayTeam, index)
                    val result = group.copy(
                        odds = odds?.let {
                            SofaScoreService.Odds(it.home, it.draw, it.away)
                        }
                    )
                    onItem(result)
                    val done = synchronized(this@FlashscoreOddsService) { ++completed }
                    onProgress(done, groups.size)
                    result
                }
            }
        }.awaitAll()
    }

    private fun loadTodayMatchIndex(): List<FlashMatchLink> {
        if (todayLinksLoaded) return todayLinks
        synchronized(this) {
            if (todayLinksLoaded) return todayLinks

            val (code, body) = http.getFast(
                "https://www.flashscore.com/football/",
                "https://www.flashscore.com/"
            )
            if (code !in 200..299 || body.isNullOrBlank()) {
                todayLinksLoaded = true
                todayLinks = emptyList()
                return todayLinks
            }

            val doc = Jsoup.parse(body)
            val found = LinkedHashMap<String, FlashMatchLink>()
            for (a in doc.select("a[href*='/match/football/']")) {
                val href = a.attr("abs:href").ifBlank { a.attr("href") }
                if (href.isBlank()) continue
                val path = href.substringBefore('?').substringBefore('#').trimEnd('/')
                val marker = "/match/football/"
                val pos = path.indexOf(marker)
                if (pos < 0) continue
                val rest = path.substring(pos + marker.length)
                val parts = rest.split('/').filter { it.isNotBlank() }
                if (parts.size < 2) continue

                // Flashscore URLs contain team slugs plus internal IDs. Keeping
                // the slug intact makes fuzzy matching robust to the ID suffix.
                val home = parts[0]
                val away = parts[1]
                found[path] = FlashMatchLink(home, away, href)
            }

            todayLinks = found.values.toList()
            todayLinksLoaded = true
            return todayLinks
        }
    }

    private fun findOdds(home: String, away: String, index: List<FlashMatchLink>): Odds? {
        val resolved = index
            .map { it to teamPairScore(home, away, it.home, it.away) }
            .filter { it.second >= 0.70 }
            .maxByOrNull { it.second }
            ?.first ?: return null

        val (code, body) = http.getFast(
            resolved.url,
            "https://www.flashscore.com/football/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return parseOdds(body)
    }

    private fun parseOdds(html: String): Odds? {
        val text = Jsoup.parse(html).text().replace(Regex("\\s+"), " ")

        // Prefer the pre-match block when Flashscore exposes both live and
        // pre-match odds. Otherwise fall back to the 1 X 2 block.
        val start = listOf(
            Regex("Pre-match odds", RegexOption.IGNORE_CASE).find(text)?.range?.last?.plus(1),
            Regex("1 X 2", RegexOption.IGNORE_CASE).find(text)?.range?.last?.plus(1)
        ).filterNotNull().minOrNull() ?: return null

        val tail = text.substring(start)
        val values = Regex("(?<![\\d.])(?:\\d{1,3})(?:\\.\\d{1,2})(?![\\d.])")
            .findAll(tail)
            .map { it.value }
            .take(3)
            .toList()

        if (values.size != 3) return null
        val nums = values.mapNotNull { it.toDoubleOrNull() }
        if (nums.size != 3 || nums.any { it <= 1.0 || it > 100.0 }) return null
        return Odds(format(nums[0]), format(nums[1]), format(nums[2]))
    }

    private fun teamPairScore(wantedHome: String, wantedAway: String, actualHome: String, actualAway: String): Double {
        val direct = (teamScore(wantedHome, actualHome) + teamScore(wantedAway, actualAway)) / 2.0
        val reversed = (teamScore(wantedHome, actualAway) + teamScore(wantedAway, actualHome)) / 2.0
        return maxOf(direct, reversed - 0.10)
    }

    private fun teamScore(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = normalize(a)
        val bb = normalize(b)
        if (aa.isBlank() || bb.isBlank()) return 0.0
        if (aa.contains(bb) || bb.contains(aa)) return 0.94
        val maxLen = maxOf(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun normalize(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]"), "")

    private fun format(value: Double): String = String.format(Locale.US, "%.2f", value)
}
