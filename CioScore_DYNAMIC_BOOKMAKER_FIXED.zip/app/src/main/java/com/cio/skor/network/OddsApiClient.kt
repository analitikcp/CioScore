package com.cio.skor.network

import android.util.Log
import org.json.JSONArray
import com.cio.skor.data.MatchMerger
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * The Odds API v4 client.
 *
 * Important: v4 requires a real sport key. There is no documented generic
 * `soccer` sport key in the current sport list, so we discover active
 * soccer_* keys from /v4/sports and query those leagues instead of hardcoding
 * soccer_epl.
 */
object OddsApiClient {

    private const val API_KEY = "de27ecac1f8b332cbeb5bb84a5276a7d"
    private const val API_HOST = "https://api.the-odds-api.com/v4"
    private const val REGIONS = "eu,uk"
    private const val MARKETS = "h2h"
    private const val ODDS_FORMAT = "decimal"

    // Keep a little headroom so a scan does not spend the whole remaining quota.
    private const val MIN_REMAINING_BEFORE_NEXT_LEAGUE = 1
    // Safety cap: do not serially request an unbounded number of leagues.
    private const val MAX_SOCCER_LEAGUE_REQUESTS_PER_SCAN = 12

    var remainingRequests: String = "-"
        private set

    fun fetchOdds(): List<OddsData> {
        if (API_KEY.isBlank()) return emptyList()

        val result = linkedMapOf<String, OddsData>()

        try {
            val sportKeys = fetchActiveSoccerSportKeys()
            Log.d(
                "OddsApiClient",
                "Aktif futbol ligleri: ${sportKeys.size}, bu taramada sorgulanacak: ${minOf(sportKeys.size, MAX_SOCCER_LEAGUE_REQUESTS_PER_SCAN)}"
            )

            for (sportKey in sportKeys.take(MAX_SOCCER_LEAGUE_REQUESTS_PER_SCAN)) {
                val remaining = remainingRequests.toIntOrNull()
                if (remaining != null && remaining <= MIN_REMAINING_BEFORE_NEXT_LEAGUE) {
                    Log.w("OddsApiClient", "Kota koruması: kalan=$remaining, yeni lig isteği durduruldu")
                    break
                }

                val events = fetchOddsForSport(sportKey)
                for (odds in events) {
                    result.putIfAbsent(MatchMerger.key(odds.homeTeam, odds.awayTeam), odds)
                }
            }
        } catch (e: Exception) {
            Log.e("OddsApiClient", "Odds API genel hata", e)
        }

        Log.d("OddsApiClient", "Toplam Bet365 oranlı maç: ${result.size}")
        return result.values.toList()
    }

    private fun fetchActiveSoccerSportKeys(): List<String> {
        val json = get("$API_HOST/sports/?apiKey=$API_KEY") ?: return emptyList()
        val array = JSONArray(json)
        val keys = mutableListOf<String>()

        for (i in 0 until array.length()) {
            val sport = array.getJSONObject(i)
            val key = sport.optString("key")
            val active = sport.optBoolean("active", false)

            // Only current soccer leagues; exclude futures/outrights.
            if (active && key.startsWith("soccer_") &&
                !key.contains("winner", ignoreCase = true)) {
                keys += key
            }
        }

        return keys.distinct().sortedWith(compareBy<String> {
            when {
                it == "soccer_turkey_super_league" -> 0
                it == "soccer_uefa_champs_league" -> 1
                it == "soccer_uefa_champs_league_qualification" -> 2
                it == "soccer_uefa_europa_league" -> 3
                it == "soccer_epl" -> 4
                else -> 10
            }
        }.thenBy { it })
    }

    private fun fetchOddsForSport(sportKey: String): List<OddsData> {
        val encodedKey = java.net.URLEncoder.encode(sportKey, "UTF-8")
        val url = "$API_HOST/sports/$encodedKey/odds/?" +
            "apiKey=$API_KEY&regions=$REGIONS&markets=$MARKETS&oddsFormat=$ODDS_FORMAT"

        val json = get(url) ?: return emptyList()
        val events = JSONArray(json)
        Log.d("OddsApiClient", "[$sportKey] API event count=${events.length()}")
        val result = mutableListOf<OddsData>()

        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            val home = event.optString("home_team").trim()
            val away = event.optString("away_team").trim()
            if (home.isBlank() || away.isBlank()) continue

            val bookmakers = event.optJSONArray("bookmakers") ?: continue

            val bookmakerKeys = buildList {
                for (b in 0 until bookmakers.length()) {
                    val bm = bookmakers.getJSONObject(b)
                    add("${bm.optString("key")}=${bm.optString("title")}")
                }
            }

            Log.d(
                "OddsApiClient",
                "[$sportKey] $home - $away bookmakers=$bookmakerKeys"
            )

            // Use the first bookmaker that actually exposes h2h.
            val bookmaker = findFirstH2hBookmaker(bookmakers)
            if (bookmaker == null) {
                Log.d("OddsApiClient", "[$sportKey] No h2h bookmaker: $home - $away")
                continue
            }
            val bookmakerTitle = bookmaker.optString("title").ifBlank { bookmaker.optString("key") }
            val h2h = findH2h(bookmaker.optJSONArray("markets")) ?: continue

            var odd1 = "-"
            var oddX = "-"
            var odd2 = "-"

            val outcomes = h2h.optJSONArray("outcomes") ?: continue
            for (j in 0 until outcomes.length()) {
                val outcome = outcomes.getJSONObject(j)
                val name = outcome.optString("name").trim()
                val price = outcome.optDouble("price", Double.NaN)
                if (price.isNaN()) continue

                when {
                    MatchMerger.isSameTeam(name, home) -> odd1 = formatOdd(price)
                    MatchMerger.isSameTeam(name, away) -> odd2 = formatOdd(price)
                    name.equals("Draw", ignoreCase = true) -> oddX = formatOdd(price)
                }
            }

            Log.d(
                "OddsApiClient",
                "[$sportKey] ODDS: $home - $away => $bookmakerTitle | MS1=$odd1 MSX=$oddX MS2=$odd2"
            )

            if (odd1 != "-" || oddX != "-" || odd2 != "-") {
                result += OddsData(home, away, bookmakerTitle, odd1, oddX, odd2)
            }
        }

        if (result.isEmpty()) Log.d("OddsApiClient", "No Bet365 odds returned after scan")
        return result
    }

    private fun findFirstH2hBookmaker(bookmakers: JSONArray): JSONObject? {
        for (i in 0 until bookmakers.length()) {
            val bm = bookmakers.getJSONObject(i)
            if (findH2h(bm.optJSONArray("markets")) != null) return bm
        }
        return null
    }

    private fun findH2h(markets: JSONArray?): JSONObject? {
        if (markets == null) return null
        for (i in 0 until markets.length()) {
            val market = markets.getJSONObject(i)
            if (market.optString("key") == "h2h") return market
        }
        return null
    }

    private fun get(urlString: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6000
                readTimeout = 9000
                useCaches = false
            }

            remainingRequests = connection.getHeaderField("x-requests-remaining") ?: remainingRequests
            Log.d("OddsApiClient", "Kalan Odds API hakkı: $remainingRequests")

            val code = connection.responseCode
            if (code != HttpURLConnection.HTTP_OK) {
                Log.e(
                    "OddsApiClient",
                    "HTTP $code (remaining=$remainingRequests, endpoint=${urlString.substringBefore("?")})"
                )
                null
            } else {
                connection.inputStream.bufferedReader().use { it.readText() }
            }
        } catch (e: Exception) {
            Log.e("OddsApiClient", "HTTP hata", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)
}

data class OddsData(
    val homeTeam: String,
    val awayTeam: String,
    val bookmakerName: String,
    val odd1: String,
    val oddX: String,
    val odd2: String
)
