# Button text fit fix

- Main filter buttons `İDDAA BÜLTENİ (N)` and `DİĞER MAÇLAR (N)` now use a 52dp row.
- Uniform text auto-sizing scales from 12sp down to 9sp on narrow screens.
- Horizontal padding was reduced to 2dp and font padding is disabled.
- The existing single-line end-ellipsis remains only as a last-resort fallback for unusually large counts.
- No score-source, matcher, official İddaa verification, or data-flow logic was changed.
