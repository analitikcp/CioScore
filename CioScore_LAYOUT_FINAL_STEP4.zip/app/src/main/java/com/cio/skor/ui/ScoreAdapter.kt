package com.cio.skor.ui

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel

/** One card per unified match; source names are displayed as CIO labels. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>
)

class ScoreAdapter(initialList: List<MatchGroup> = emptyList()) : RecyclerView.Adapter<ScoreAdapter.VH>() {
    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList

    private val sourceLabels = mapOf(
        "FP.com" to "cio1",
        "PredictZ" to "cio2",
        "WinDrawWin" to "cio3",
        "SoccerSeer" to "cio4",
        "DailySports" to "cio5",
        "Forebet" to "cio6"
    )

    private fun displaySourceName(source: String): String {
        val trimmed = source.trim()
        return sourceLabels.entries.firstOrNull { it.key.equals(trimmed, ignoreCase = true) }?.value
            ?: trimmed.lowercase()
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        displayedList = newList
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    fun filter(query: String) {
        val q = MatchMerger.normalizeTeamName(query)
        displayedList = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            background = GradientDrawable().apply {
                setColor(0xFFFFFFFF.toInt())
                cornerRadius = 28f
                setStroke(2, 0xFFE7EAF0.toInt())
            }
            elevation = 5f
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(14, 8, 14, 8) }
        }
        return VH(card)
    }

    override fun getItemCount() = displayedList.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ctx = holder.card.context
        val match = displayedList[position]
        holder.card.removeAllViews()

        val teams = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val home = teamText(ctx, match.homeTeam)
        val vs = TextView(ctx).apply {
            text = "VS"
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFF667085.toInt())
            background = GradientDrawable().apply {
                setColor(0xFFF2F4F7.toInt())
                shape = GradientDrawable.OVAL
            }
        }
        val away = teamText(ctx, match.awayTeam)
        teams.addView(home, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        teams.addView(vs, LinearLayout.LayoutParams(44, 44))
        teams.addView(away, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        holder.card.addView(teams)

        val counts = match.predictions.groupingBy { it.predictedScore }.eachCount()
        val consensus = counts.entries.maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
        if (consensus != null && match.predictions.size > 1) {
            val label = TextView(ctx).apply {
                text = "KONSENSÜS"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(0xFF008F83.toInt())
                setTypeface(typeface, Typeface.BOLD)
            }
            val score = TextView(ctx).apply {
                text = consensus.key
                textSize = 30f
                gravity = Gravity.CENTER
                setTextColor(0xFF009688.toInt())
                setTypeface(typeface, Typeface.BOLD)
            }
            val strength = TextView(ctx).apply {
                text = "${consensus.value}/${match.predictions.size} kaynak"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                setTypeface(typeface, Typeface.BOLD)
                background = GradientDrawable().apply {
                    setColor(0xFF18A86B.toInt())
                    cornerRadius = 18f
                }
                setPadding(18, 8, 18, 8)
            }
            holder.card.addView(label)
            holder.card.addView(score)
            val wrap = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
            wrap.addView(strength)
            holder.card.addView(wrap)
        }

        val divider = View(ctx).apply { setBackgroundColor(0xFFE7EAF0.toInt()) }
        holder.card.addView(divider, LinearLayout.LayoutParams(-1, 1).apply { setMargins(0, 8, 0, 4) })

        match.predictions.forEach { prediction ->
            val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
            val source = TextView(ctx).apply {
                text = displaySourceName(prediction.source)
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
            }
            val arrow = TextView(ctx).apply {
                text = "→"
                textSize = 16f
                setTextColor(0xFF667085.toInt())
                gravity = Gravity.CENTER
            }
            val score = TextView(ctx).apply {
                text = prediction.predictedScore
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
            }
            row.addView(source, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(arrow, LinearLayout.LayoutParams(36, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(score, LinearLayout.LayoutParams(60, ViewGroup.LayoutParams.WRAP_CONTENT))
            holder.card.addView(row)
        }
    }

    private fun teamText(ctx: android.content.Context, name: String) = TextView(ctx).apply {
        text = name
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(0xFF101828.toInt())
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
}
