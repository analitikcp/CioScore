package com.cio.skor.data

import android.content.Context

/**
 * Independent odds-panel pipeline.
 *
 * The main card odds and this panel deliberately have separate call paths.
 * Today the panel exposes exactly two bureaus: official Iddaa and Bet365.
 * New bureaus can be added here later without changing ScoreAdapter or the
 * official prediction/verification pipeline.
 */
class OddsPanelService(context: Context) {
    data class OddsRow(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String,
        val primary: Boolean = false
    )

    private val bet365 = SofaScoreService(context)

    suspend fun fetchBet365(homeTeam: String, awayTeam: String): OddsRow? {
        return bet365.fetchBookmakerOdds(homeTeam, awayTeam)
            .firstOrNull { it.bookmaker.contains("Bet365", true) }
            ?.let { OddsRow("Bet365", it.ms1, it.msX, it.ms2, primary = true) }
    }

    fun iddaaRow(ms1: String?, msX: String?, ms2: String?): OddsRow? {
        if (ms1 == null && msX == null && ms2 == null) return null
        return OddsRow(
            bookmaker = "İddaa.com",
            ms1 = ms1 ?: "-",
            msX = msX ?: "-",
            ms2 = ms2 ?: "-"
        )
    }
}
