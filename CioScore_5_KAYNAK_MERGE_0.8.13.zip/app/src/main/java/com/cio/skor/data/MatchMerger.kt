package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance
import java.text.Normalizer as JavaNormalizer

/**
 * Central place for team-name normalization and cross-source fixture merging.
 *
 * Matching is intentionally conservative: a false merge is more damaging to
 * CIO Score than leaving two uncertain records separate. Home/away direction
 * is always respected.
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    private val removableSuffixes = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "club", "sc", "ac", "cf"
    )

    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        value = value
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        return value.split(' ')
            .filter { it.isNotBlank() && it !in removableSuffixes }
            .joinToString(" ")
            .trim()
    }

    private fun compact(value: String): String =
        normalizeTeamName(value).replace(" ", "")

    private fun tokens(value: String): Set<String> =
        normalizeTeamName(value).split(' ').filter { it.isNotBlank() }.toSet()

    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    /**
     * Returns a confidence score in [0,1]. Exact normalized names score 1.0.
     * Short/generic names are deliberately harder to match than long names.
     */
    fun teamMatchScore(name1: String, name2: String): Double {
        val norm1 = compact(name1)
        val norm2 = compact(name2)
        if (norm1.isBlank() || norm2.isBlank()) return 0.0
        if (norm1 == norm2) return 1.0

        val token1 = tokens(name1)
        val token2 = tokens(name2)
        if (token1.isNotEmpty() && token2.isNotEmpty()) {
            val smaller = if (token1.size <= token2.size) token1 else token2
            val larger = if (token1.size <= token2.size) token2 else token1
            val tokenOverlap = smaller.intersect(larger).size.toDouble() / smaller.size.toDouble()
            val lengthRatio = minOf(norm1.length, norm2.length).toDouble() /
                maxOf(norm1.length, norm2.length).toDouble()

            // Only allow containment when the shorter name is substantial.
            // This prevents "United" from matching "Manchester United".
            if (tokenOverlap == 1.0 && minOf(norm1.length, norm2.length) >= 7 && lengthRatio >= 0.62) {
                return 0.96
            }
        }

        val maxLength = maxOf(norm1.length, norm2.length)
        if (maxLength == 0) return 0.0
        val distance = levenshtein.apply(norm1, norm2)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()

        // Conservative thresholds for fuzzy matching. Generic short names
        // need a much closer edit-distance match than long names.
        return when {
            minOf(norm1.length, norm2.length) <= 5 -> if (similarity >= 0.90) similarity else 0.0
            minOf(norm1.length, norm2.length) <= 8 -> if (similarity >= 0.86) similarity else 0.0
            else -> if (similarity >= 0.82) similarity else 0.0
        }
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        teamMatchScore(name1, name2) >= 0.82

    data class UnifiedMatch(
        val mainHomeTeam: String,
        val mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf()
    )

    private data class Candidate(
        val index: Int,
        val homeScore: Double,
        val awayScore: Double,
        val combinedScore: Double
    )

    /**
     * Merge records using the best two-sided home/away candidate rather than
     * the first fuzzy match. Ambiguous candidates are left separate.
     */
    fun mergeMatches(scrapedList: List<ScoreModel>): List<UnifiedMatch> {
        val unifiedMatches = mutableListOf<UnifiedMatch>()

        for (scraped in scrapedList) {
            val candidates = unifiedMatches.mapIndexedNotNull { index, unified ->
                val homeScore = teamMatchScore(unified.mainHomeTeam, scraped.homeTeam)
                val awayScore = teamMatchScore(unified.mainAwayTeam, scraped.awayTeam)
                if (homeScore <= 0.0 || awayScore <= 0.0) return@mapIndexedNotNull null

                // Both sides matter. The weaker side is weighted strongly so a
                // single generic team name cannot drag an unrelated match in.
                val combined = homeScore * 0.5 + awayScore * 0.5
                Candidate(index, homeScore, awayScore, combined)
            }.sortedByDescending { it.combinedScore }

            val best = candidates.firstOrNull()
            val second = candidates.getOrNull(1)

            val canMerge = best != null &&
                best.homeScore >= 0.82 &&
                best.awayScore >= 0.82 &&
                best.combinedScore >= 0.86 &&
                (second == null || best.combinedScore - second.combinedScore >= 0.035)

            if (canMerge) {
                val existing = unifiedMatches[best!!.index]
                val sourceExists = existing.predictions.any {
                    it.first.trim().equals(scraped.source.trim(), ignoreCase = true)
                }
                if (!sourceExists) {
                    existing.predictions.add(scraped.source to scraped.predictedScore)
                }
            } else {
                unifiedMatches.add(
                    UnifiedMatch(
                        mainHomeTeam = scraped.homeTeam,
                        mainAwayTeam = scraped.awayTeam,
                        predictions = mutableListOf(scraped.source to scraped.predictedScore)
                    )
                )
            }
        }

        return unifiedMatches
    }
}
