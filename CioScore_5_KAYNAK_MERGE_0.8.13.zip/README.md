# CIO Score 0.8.13 - 5 Kaynak - Güçlü Maç Birleştirme

Bu sürümde 5 kaynaktan gelen skorlar önce tek ham havuzda toplanır, ardından ev/deplasman takım adları normalize edilerek aynı maç iki taraflı güven skoru ile birleştirilir. Belirsiz eşleşmeler ayrı bırakılır.

Aktif kaynaklar: FP.com, PredictZ, WinDrawWin, SoccerSeer ve DailySports.

SofaScore yalnızca yardımcı katmandır: son 5 maç ve 1X2 oran zenginleştirmesi için kullanılır; CIO kaynak sayısına dahil değildir.
