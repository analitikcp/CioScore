package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document

/**
 * Isolated parser used only by the nine-source test package.
 * It deliberately does not reference any of the legacy five/six parsers.
 */
open class SitePredictionParser(sourceName: String) : BaseParser(sourceName) {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val selectors = listOf(
            "article", "li", "tr", "section", "div[class*=match]", "div[class*=fixture]",
            "div[class*=prediction]", "div[class*=game]", "div[class*=event]", "div[class*=tip]"
        )
        for (el in doc.select(selectors.joinToString(","))) {
            val raw = clean(el.text())
            if (raw.length !in 8..700) continue
            val sc = Regex("(?i)(?:correct\\s*score|predicted\\s*score(?:line)?|scoreline|prediction|pred|tip)[^0-9]{0,100}([0-5])\\s*[-:]\\s*([0-5])")
                .find(raw)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: score(raw) ?: continue
            val match = Regex("(?i)(.{2,80}?)\\s+(?:v|vs\\.?|versus|[-–—])\\s+(.{2,80}?)(?=\\s+(?:correct|predicted|prediction|pred|tip|score|odds)\\b|$)")
                .find(raw) ?: continue
            val a = team(match.groupValues[1])
            val b = team(match.groupValues[2])
            if (valid(a, b)) {
                val key = "${a.lowercase()}|${b.lowercase()}|$sc"
                out.putIfAbsent(key, ScoreModel(a, b, sc, source))
            }
            if (out.size >= 100) break
        }
        return out.values.toList()
    }
}
