package com.cio.skor.data

import com.cio.skor.data.parsers.DailySportsParser
import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup

/** Isolated DailySports-only test project. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: DailySportsParser)
    private val http = HttpClient()
    private val source = Source(
        "DailySports",
        "https://dailysports.net/mathematical-predictions/correct-score/",
        DailySportsParser()
    )

    val sourceCount: Int get() = 1
    val sourceNames: List<String> get() = listOf(source.name)

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> {
        return try {
            val (code, html) = http.get(source.url)
            val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                source.parser.parse(Jsoup.parse(html, source.url))
            } else emptyList()
            onProgress(1, source.name)
            listOf(SourceResult(source.name, code, scores, null))
        } catch (e: Exception) {
            onProgress(1, source.name)
            listOf(SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName))
        }
    }
}
