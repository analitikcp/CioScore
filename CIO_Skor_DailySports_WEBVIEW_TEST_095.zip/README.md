DailySports isolated test 0.9.3.

One source only: DailySports.
URL: https://dailysports.net/mathematical-predictions/correct-score/

Flow: direct OkHttp first; if zero parsed scores, hidden Android WebView loads the same page with JavaScript/DOM storage enabled and the rendered document HTML is parsed with the DailySports-specific parser.

The live page currently exposes game team names in image alt text and a literal Prediction Correct Score line; parser targets that structure.
