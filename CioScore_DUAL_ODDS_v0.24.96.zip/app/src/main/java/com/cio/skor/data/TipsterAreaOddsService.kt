package com.cio.skor.data

import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * API-free TipsterArea odds transport.
 *
 * TipsterArea publishes a server-rendered "Leading Bookmakers Odds / Standard
 * 1X2" table.  The bookmaker labels are often image alt attributes rather than
 * normal text, so discovery and parsing must not depend on Element.text().
 */
class TipsterAreaOddsService {
    data class Odds(val bookmaker: String, val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()

    private val wantedBookmakers = linkedMapOf(
        "1xbet" to "1xBet",
        "bet-at-home" to "bet-at-home",
        "betfair" to "Betfair",
        "bwin" to "bwin",
        "unibet" to "Unibet"
    )

    private data class CacheEntry(val expiresAt: Long, val value: List<Odds>)
    private val oddsCache = ConcurrentHashMap<String, CacheEntry>()
    private val urlCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val cacheTtlMs = 5 * 60 * 1000L

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        matchDate: String = ""
    ): List<Odds> {
        val cacheKey = "${normalize(homeTeam)}|${normalize(awayTeam)}|${dateKey(matchDate)}"
        oddsCache[cacheKey]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return it.value }

        val detailUrl = discoverMatchUrl(homeTeam, awayTeam, matchDate) ?: return emptyList()
        val (code, body) = http.getSource(detailUrl, "https://tipsterarea.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()

        val result = parseOdds(body)
        if (result.isNotEmpty()) {
            oddsCache[cacheKey] = CacheEntry(System.currentTimeMillis() + cacheTtlMs, result)
        }
        return result
    }

    private fun discoverMatchUrl(homeTeam: String, awayTeam: String, matchDate: String): String? {
        val home = normalizedTeamVariants(homeTeam)
        val away = normalizedTeamVariants(awayTeam)
        if (home.isEmpty() || away.isEmpty()) return null

        val dates = candidateDates(matchDate)
        for (date in dates) {
            val dateKey = date.toString()
            val urlCacheKey = "${home.joinToString("_")}|${away.joinToString("_")}|$dateKey"
            urlCache[urlCacheKey]?.takeIf { it.first > System.currentTimeMillis() }?.let { return it.second }

            // TipsterArea date index uses dd-MM-yyyy (not ISO yyyy-MM-dd).
            // The previous implementation used the wrong URL shape, so the
            // discovery request could return no match links even though the
            // fixture and its five bookmaker rows existed on TipsterArea.
            val tipsterDate = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
            val url = "https://tipsterarea.com/matches/date-$tipsterDate"
            val (code, body) = http.getSource(url, "https://tipsterarea.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue

            val doc = Jsoup.parse(body, "https://tipsterarea.com/")
            val candidates = doc.select("a[href*='/match/']")
            for (a in candidates) {
                val href = a.absUrl("href").ifBlank { "https://tipsterarea.com${a.attr("href")}" }
                if (href.isBlank()) continue

                // TipsterArea match links contain both team names in the slug.
                // This is more reliable than anchor text because many rows use
                // team logos/images and therefore have little/no text content.
                val hrefNorm = normalize(href.substringBefore('?').substringBefore('#'))
                val anchorNorm = normalize(a.text())
                val combined = "$hrefNorm $anchorNorm"

                if (teamPairMatches(combined, home, away)) {
                    urlCache[urlCacheKey] = System.currentTimeMillis() + cacheTtlMs to href
                    return href
                }
            }
        }
        return null
    }

    private fun candidateDates(raw: String): List<LocalDate> {
        val base = parseDate(raw) ?: LocalDate.now()
        return listOf(base, base.minusDays(1), base.plusDays(1)).distinct()
    }

    private fun parseDate(raw: String): LocalDate? {
        val value = raw.trim().take(10)
        if (value.isBlank()) return null
        val formats = listOf(
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
        )
        return formats.firstNotNullOfOrNull { formatter ->
            try { LocalDate.parse(value, formatter) } catch (_: DateTimeParseException) { null }
        }
    }

    private fun dateKey(raw: String): String = parseDate(raw)?.toString() ?: raw.trim()

    private fun normalizedTeamVariants(value: String): List<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptyList()

        val stripped = base.split(' ')
            .filterNot { it in GENERIC_TEAM_PREFIXES }
            .joinToString(" ")
            .trim()

        return listOf(base, stripped)
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun teamPairMatches(text: String, homeVariants: List<String>, awayVariants: List<String>): Boolean {
        val haystack = normalize(text)
        val homeHit = homeVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        val awayHit = awayVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        return homeHit && awayHit
    }

    private fun containsTeamPhrase(haystack: String, team: String): Boolean {
        if (team.isBlank()) return false
        if (haystack.contains(team)) return true

        // Handle common short-name differences, e.g. "CD Universidad Catolica"
        // vs a URL slug containing only "universidad catolica".
        val tokens = team.split(' ').filter { it.length >= 3 }
        if (tokens.isEmpty()) return false
        val hits = tokens.count { haystack.contains(it) }
        return hits >= maxOf(1, (tokens.size * 0.75).toInt())
    }

    private fun parseOdds(html: String): List<Odds> {
        val doc = Jsoup.parse(html)

        // The page contains several odds tables. Select only the table that is
        // explicitly the Standard 1X2 market, then parse bookmaker rows by image
        // alt text as well as ordinary text.
        val table = doc.select("table").firstOrNull { table ->
            val visible = normalize(table.text())
            val alts = table.select("img[alt]").joinToString(" ") { it.attr("alt") }
            val marker = normalize("$visible $alts")
            marker.contains("standard 1x2") &&
                wantedBookmakers.keys.any { marker.contains(normalize(it)) }
        } ?: return emptyList()

        val rowsByBookmaker = linkedMapOf<String, Odds>()
        for (tr in table.select("tr")) {
            val bookmakerKey = bookmakerFromRow(tr) ?: continue
            val values = numericOddsFromRow(tr)
            if (values.size < 3) continue

            val clean = values.takeLast(3).mapNotNull(::cleanOdd)
            if (clean.size != 3) continue

            rowsByBookmaker.putIfAbsent(
                bookmakerKey,
                Odds(
                    wantedBookmakers.getValue(bookmakerKey),
                    clean[0], clean[1], clean[2]
                )
            )
        }

        return wantedBookmakers.keys.mapNotNull { rowsByBookmaker[it] }
    }

    private fun bookmakerFromRow(row: Element): String? {
        val imageNames = row.select("img[alt]").map { it.attr("alt") }.filter { it.isNotBlank() }
        val text = buildString {
            append(row.text())
            if (imageNames.isNotEmpty()) append(' ').append(imageNames.joinToString(" "))
        }
        val normalized = normalize(text)
        return wantedBookmakers.keys.firstOrNull { key ->
            normalized.contains(normalize(key))
        }
    }

    private fun numericOddsFromRow(row: Element): List<String> {
        val rawParts = row.select("td,th").flatMap { cell ->
            val text = cell.text().trim()
            if (text.isNotBlank()) listOf(text) else emptyList()
        }
        val raw = rawParts.joinToString(" ")
        val matches = ODDS_NUMBER.findAll(raw).map { it.value }.toList()
        if (matches.size >= 3) return matches

        // A few TipsterArea variants put the values in attributes/spans. Fall
        // back to the complete row text, but still require exactly three usable
        // numeric values after bookmaker identification.
        return ODDS_NUMBER.findAll(row.wholeText()).map { it.value }.toList()
    }

    private fun cleanOdd(value: String): String? {
        val normalized = value.replace(',', '.').trim()
        val number = normalized.toDoubleOrNull() ?: return null
        if (number <= 1.0 || number > 100.0) return null
        return String.format(Locale.US, "%.2f", number)
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("https?://|www\\."), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private val ODDS_NUMBER = Regex("(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])")
        private val GENERIC_TEAM_PREFIXES = setOf(
            "fc", "cf", "cd", "sc", "ac", "afc", "fk", "sk", "club", "clube",
            "deportivo", "deportiva", "deportes", "football", "soccer"
        )
    }
}
