package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

abstract class BaseParser(protected val source: String) {
    // Shared score extraction. Parsers may still use source-specific DOM logic
    // to locate the correct text, but score normalization lives in one place.
    protected val scoreRegex = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)")

    protected fun extractStandardScore(rawText: String): Pair<Int, Int>? {
        val match = scoreRegex.find(rawText) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        if (home > 20 || away > 20) return null
        return home to away
    }

    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    protected fun score(s: String): String? =
        extractStandardScore(s)?.let { (home, away) -> "$home-$away" }

    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }

    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }


    protected data class FixtureMetadata(
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val countryName: String = ""
    )

    /**
     * Extract fixture context from the smallest source-specific card/block.
     * The matcher should not have to guess date/time/competition from team names.
     */
    protected fun fixtureMetadata(element: Element): FixtureMetadata {
        val text = clean(element.text())
        val date = Regex("\\b(?:\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}|\\d{4}-\\d{1,2}-\\d{1,2})\\b")
            .find(text)?.value.orEmpty()
        val time = Regex("\\b(?:[01]?\\d|2[0-3]):[0-5]\\d\\b")
            .find(text)?.value?.let {
                val parts = it.split(":")
                parts[0].padStart(2, '0') + ":" + parts[1]
            } ?: "--:--"

        fun first(selector: String): String = element.select(selector)
            .map { clean(it.text()) }
            .firstOrNull { it.isNotBlank() && it.length <= 120 }
            .orEmpty()

        val competition = first(
            ".league, .competition, .tournament, [class*=league], [class*=competition], [class*=tournament], [data-league], [data-competition]"
        )
        val country = first(
            ".country, [class*=country], [data-country], [class*=region], [data-region]"
        )
        return FixtureMetadata(date, time, competition, country)
    }

    abstract fun parse(doc: Document): List<ScoreModel>
}
