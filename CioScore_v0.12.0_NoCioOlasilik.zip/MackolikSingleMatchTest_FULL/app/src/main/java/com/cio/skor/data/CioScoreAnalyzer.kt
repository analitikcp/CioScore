package com.cio.skor.data

import com.cio.skor.ui.MatchGroup
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Deterministic, explainable 0-100 match rating built from the five source
 * score predictions and Mackolik 1X2 odds.
 */
object CioScoreAnalyzer {
    data class Analysis(
        val score: Int,
        val confidence: String,
        val bestOutcome: String,
        val bestValuePercent: Int?,
        val consensusScore: String,
        val consensusCount: Int,
        val predictionCount: Int
    )

    fun analyze(match: MatchGroup): Analysis {
        val predictions = match.predictions.mapNotNull { parseScore(it.predictedScore) }
        val n = predictions.size
        if (n == 0) {
            return Analysis(
                0, "Yetersiz", "-", null, "-", 0, 0
            )
        }

        val scoreCounts = predictions.groupingBy { "${it.first}-${it.second}" }.eachCount()
        val consensus = scoreCounts.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key }
        )!!
        val consensusRatio = consensus.value.toDouble() / n

        val agreementPoints = (15.0 + 35.0 * consensusRatio).coerceAtMost(50.0)
        val coveragePoints = (20.0 * (n.toDouble() / 5.0)).coerceAtMost(20.0)

        var oddsPoints = 0.0
        var bestOutcome = outcomeFromScore(consensus.key)
        var bestValue: Double? = null

        match.odds?.let { odds ->
            val oddsValues = listOf(parseOdds(odds.home), parseOdds(odds.draw), parseOdds(odds.away))
            if (oddsValues.all { it != null && it > 1.0 }) {
                val raw = oddsValues.map { 1.0 / it!! }
                val total = raw.sum()
                val marketProb = raw.map { it / total }
                val modelProb = outcomeProbabilities(predictions)

                val modelBest = modelProb.indices.maxByOrNull { modelProb[it] } ?: 0
                bestOutcome = listOf("MS 1", "MS X", "MS 2")[modelBest]
                val edge = modelProb[modelBest] * oddsValues[modelBest]!! - 1.0
                bestValue = edge * 100.0

                val marketFavorite = marketProb.indices.maxByOrNull { marketProb[it] } ?: 0
                val consensusOutcome = outcomeIndex(outcomeFromScore(consensus.key))
                oddsPoints = if (consensusOutcome == marketFavorite) {
                    20.0
                } else {
                    val distance = abs(modelProb[consensusOutcome] - marketProb[consensusOutcome])
                    (14.0 - distance * 40.0).coerceIn(0.0, 14.0)
                }
            }
        }

        val total = (agreementPoints + coveragePoints + oddsPoints).roundToInt().coerceIn(0, 100)
        val confidence = when {
            total >= 80 -> "Çok yüksek"
            total >= 65 -> "Yüksek"
            total >= 50 -> "Orta"
            else -> "Düşük"
        }

        val valuePercent = bestValue?.let { if (it > 0.0) it.roundToInt() else null }

        return Analysis(
            total,
            confidence,
            bestOutcome,
            valuePercent,
            consensus.key,
            consensus.value,
            n
        )
    }

    private fun parseScore(value: String): Pair<Int, Int>? {
        val m = Regex("^(\\d{1,2})-(\\d{1,2})$").matchEntire(value.trim()) ?: return null
        return m.groupValues[1].toIntOrNull()?.let { h ->
            m.groupValues[2].toIntOrNull()?.let { a -> h to a }
        }
    }

    private fun parseOdds(value: String): Double? = value.replace(',', '.').toDoubleOrNull()

    private fun outcomeFromScore(score: String): String {
        val p = parseScore(score) ?: return "MS X"
        return when {
            p.first > p.second -> "MS 1"
            p.first < p.second -> "MS 2"
            else -> "MS X"
        }
    }

    private fun outcomeIndex(outcome: String): Int = when (outcome) {
        "MS 1" -> 0
        "MS 2" -> 2
        else -> 1
    }

    private fun outcomeProbabilities(predictions: List<Pair<Int, Int>>): List<Double> {
        if (predictions.isEmpty()) return listOf(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)
        val counts = doubleArrayOf(0.0, 0.0, 0.0)
        predictions.forEach { (h, a) -> counts[when { h > a -> 0; h < a -> 2; else -> 1 }] += 1.0 }
        return counts.map { it / predictions.size }
    }
}
