package com.cio.skor.data

/**
 * Keeps bookmaker provenance deterministic when several odds pipelines return
 * the same bookmaker. A broad board is useful for discovery, but a dedicated
 * bookmaker pipeline must win for its own bookmaker.
 */
object OddsSourcePolicy {
    fun priority(source: String, bookmaker: String): Int {
        val s = source.trim().lowercase()
        val b = bookmaker.trim().lowercase()
        return when (b) {
            "bet365" -> when {
                s == "bet365-chain" -> 100
                s == "totalcorner" -> 40
                else -> 20
            }
            "bwin" -> when {
                s == "bwin-chain" -> 100
                s == "totalcorner" -> 40
                else -> 20
            }
            else -> when {
                s == "totalcorner" -> 70
                else -> 20
            }
        }
    }
}
