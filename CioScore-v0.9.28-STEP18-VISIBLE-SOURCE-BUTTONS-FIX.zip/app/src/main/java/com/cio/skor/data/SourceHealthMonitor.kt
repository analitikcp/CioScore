package com.cio.skor.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/** Live, process-local health state for prediction sources and parsers. */
object SourceHealthMonitor {
    private const val MAX_HISTORY = 40
    private val latestBySource = ConcurrentHashMap<String, SourceHealthSnapshot>()
    private val historyBuffer = ArrayDeque<SourceHealthSnapshot>()
    private val lock = Any()

    private val _state = MutableStateFlow(SourceHealthState())
    val state: StateFlow<SourceHealthState> = _state.asStateFlow()

    fun record(report: ParserHealthReport) {
        val snapshot = SourceHealthSnapshot(
            sourceName = report.sourceName,
            status = report.status,
            httpCode = report.httpCode,
            parsedCount = report.parsedCount,
            rawHtmlBytes = report.rawHtmlBytes,
            durationMs = report.durationMs,
            errorMessage = report.errorMessage,
            timestamp = System.currentTimeMillis()
        )
        latestBySource[report.sourceName] = snapshot
        synchronized(lock) {
            historyBuffer.addLast(snapshot)
            while (historyBuffer.size > MAX_HISTORY) historyBuffer.removeFirst()
            _state.value = SourceHealthState(
                latest = latestBySource.toMap().values.sortedBy { it.sourceName },
                history = historyBuffer.toList(),
                updatedAt = snapshot.timestamp
            )
        }
    }

    fun recordAll(reports: List<ParserHealthReport>) = reports.forEach(::record)

    fun clear() {
        latestBySource.clear()
        synchronized(lock) {
            historyBuffer.clear()
            _state.value = SourceHealthState()
        }
    }
}

data class SourceHealthSnapshot(
    val sourceName: String,
    val status: ParserStatus,
    val httpCode: Int,
    val parsedCount: Int,
    val rawHtmlBytes: Int,
    val durationMs: Long,
    val errorMessage: String?,
    val timestamp: Long
)

data class SourceHealthState(
    val latest: List<SourceHealthSnapshot> = emptyList(),
    val history: List<SourceHealthSnapshot> = emptyList(),
    val updatedAt: Long = 0L
) {
    val healthyCount: Int get() = latest.count { it.status == ParserStatus.HEALTHY }
    val degradedCount: Int get() = latest.count { it.status == ParserStatus.DEGRADED }
    val failedCount: Int get() = latest.count { it.status == ParserStatus.FAILED || it.status == ParserStatus.DOM_CHANGED }
}
