package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Bwin 1X2 transport.
 *
 * The public Bwin sports feed has changed JSON shapes over time. This parser is
 * deliberately schema-tolerant: it accepts the common `items`, `fixtures`,
 * nested `results.items` containers and both object/array/string participant
 * names. It never invents an odd; all three 1X2 prices must be real numbers.
 */
class BwinSportsApiService {
    data class Odds(val ms1: String, val msX: String, val ms2: String)

    private data class CacheEntry(val expiresAt: Long, val fixtures: List<JSONObject>)

    private val http = HttpClient()
    private val cache = ConcurrentHashMap<String, CacheEntry>()

    suspend fun fetch(homeTeam: String, awayTeam: String): Odds? {
        val wantedHome = normalize(homeTeam)
        val wantedAway = normalize(awayTeam)
        if (wantedHome.isBlank() || wantedAway.isBlank()) return null

        // Keep the number of requests bounded. Regional hosts are fallbacks,
        // not 15 requests per match.
        val endpoints = listOf(
            "https://sportsapi.bwin.com/offer/api/4/tr/fixtures?language=en&isInPlay=false&onlyMainMarkets=true&marketsFilterCriteria=Visible",
            "https://sportsapi.bwin.es/offer/api/4/es/fixtures?language=en&isInPlay=false&onlyMainMarkets=true&marketsFilterCriteria=Visible",
            "https://sportsapi.bwin.pt/offer/api/4/pt/fixtures?language=en&isInPlay=false&onlyMainMarkets=true&marketsFilterCriteria=Visible"
        )

        for (url in endpoints) {
            val key = SourceCacheIdentity.source("BwinDirectApi") + "|" + url.substringBefore("?")
            val fixtures = loadFixtures(url, key)
            if (fixtures.isEmpty()) continue

            val fixture = fixtures.firstOrNull { json ->
                val pair = participantPair(json)
                pair != null && sameTeam(pair.first, wantedHome) && sameTeam(pair.second, wantedAway)
            } ?: continue

            parseOneXTwo(fixture)?.let {
                Log.d(TAG, "BWIN DIRECT API HIT $homeTeam - $awayTeam $it url=${url.substringBefore('?')}")
                return it
            }
        }

        Log.d(TAG, "BWIN DIRECT API MISS $homeTeam - $awayTeam")
        return null
    }

    private suspend fun loadFixtures(url: String, key: String): List<JSONObject> {
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { it.expiresAt > now }?.let { return it.fixtures }

        val (code, body) = http.getSource(url, url.substringBefore("/offer/"))
        if (code !in 200..299 || body.isNullOrBlank()) {
            Log.d(TAG, "BWIN API HTTP $code url=${url.substringBefore('?')}")
            return emptyList()
        }

        val root = runCatching { JSONObject(body) }.getOrNull() ?: return emptyList()
        val fixtures = extractFixtures(root)
        if (fixtures.isNotEmpty()) cache[key] = CacheEntry(now + CACHE_TTL_MS, fixtures)
        return fixtures
    }

    private fun extractFixtures(root: JSONObject): List<JSONObject> {
        val candidates = listOfNotNull(
            root.optJSONArray("items"),
            root.optJSONArray("fixtures"),
            root.optJSONArray("events"),
            root.optJSONObject("results")?.optJSONArray("items"),
            root.optJSONObject("data")?.optJSONArray("items"),
            root.optJSONObject("data")?.optJSONArray("fixtures"),
            root.optJSONObject("data")?.optJSONArray("events"),
            root.optJSONObject("results")?.optJSONArray("fixtures")
        )
        return candidates.firstOrNull()?.let(::directObjects).orEmpty()
    }

    private fun directObjects(array: JSONArray): List<JSONObject> = buildList {
        for (i in 0 until array.length()) array.optJSONObject(i)?.let { add(it) }
    }

    private fun participantPair(fixture: JSONObject): Pair<String, String>? {
        val participants = fixture.optJSONArray("participants") ?: return null
        val named = buildList {
            for (i in 0 until participants.length()) {
                val p = participants.optJSONObject(i) ?: continue
                val name = readName(p.opt("name"))
                    .ifBlank { readName(p.opt("participantName")) }
                    .ifBlank { p.optString("text").trim() }
                if (name.isNotBlank()) add(name to p.optJSONObject("properties")?.optString("type").orEmpty())
            }
        }
        val home = named.firstOrNull { it.second.equals("HomeTeam", true) }?.first
            ?: named.getOrNull(0)?.first
        val away = named.firstOrNull { it.second.equals("AwayTeam", true) }?.first
            ?: named.getOrNull(1)?.first
        return if (!home.isNullOrBlank() && !away.isNullOrBlank()) home to away else null
    }

    private fun readName(value: Any?): String {
        return when (value) {
            is String -> value.trim()
            is JSONObject -> value.optString("value").trim()
                .ifBlank { value.optString("text").trim() }
                .ifBlank { value.optString("shortText").trim() }
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    val text = readName(value.opt(i))
                    if (text.isNotBlank()) return text
                }
                ""
            }
            else -> ""
        }
    }

    private fun parseOneXTwo(fixture: JSONObject): Odds? {
        val markets = listOfNotNull(
            fixture.optJSONArray("markets"),
            fixture.optJSONArray("optionMarkets"),
            fixture.optJSONObject("markets")?.optJSONArray("items"),
            fixture.optJSONObject("data")?.optJSONArray("markets")
        ).flatMap(::objectsFromAny)

        for (market in markets) {
            if (!isResultMarket(market)) continue
            val options = listOfNotNull(
                market.optJSONArray("options"),
                market.optJSONArray("selections"),
                market.optJSONArray("outcomes")
            ).firstOrNull() ?: continue

            var home: String? = null
            var draw: String? = null
            var away: String? = null
            for (j in 0 until options.length()) {
                val option = options.optJSONObject(j) ?: continue
                val odds = optionOdds(option) ?: continue
                val optionName = optionName(option).lowercase(Locale.US)
                val drawFlag = option.optJSONObject("parameters")?.optJSONArray("optionTypes")?.let { arr ->
                    (0 until arr.length()).any { arr.optString(it).equals("Draw", true) }
                } == true
                when {
                    drawFlag || optionName == "draw" || optionName == "x" || optionName.contains("draw") -> draw = odds
                    optionName == "home" || optionName == "1" -> home = odds
                    optionName == "away" || optionName == "2" -> away = odds
                }
            }
            if (home != null && draw != null && away != null) return Odds(home!!, draw!!, away!!)
        }
        return null
    }

    private fun objectsFromAny(value: Any): List<JSONObject> = when (value) {
        is JSONArray -> directObjects(value)
        else -> emptyList()
    }

    private fun isResultMarket(market: JSONObject): Boolean {
        val hay = listOf(
            market.optString("marketType"),
            market.optString("happening"),
            market.optString("period"),
            market.optString("name"),
            readName(market.opt("name")),
            market.optString("marketName")
        ).joinToString(" ").lowercase(Locale.US)
        return hay.contains("match result") || hay.contains("full time result") ||
            hay.contains("1x2") || hay.contains("3 way") || hay.contains("3-way")
    }

    private fun optionName(option: JSONObject): String =
        readName(option.opt("name"))
            .ifBlank { option.optString("selectionName").trim() }
            .ifBlank { option.optString("result").trim() }

    private fun optionOdds(option: JSONObject): String? {
        val directCandidates = listOf(
            option.opt("odds"),
            option.opt("price"),
            option.opt("decimalOdds"),
            option.opt("decimalValue")
        )
        for (candidate in directCandidates) {
            val number = when (candidate) {
                is JSONObject -> candidate.optString("odds").toDoubleOrNull()
                    ?: candidate.optString("decimalValue").toDoubleOrNull()
                    ?: candidate.optString("value").toDoubleOrNull()
                else -> candidate?.toString()?.toDoubleOrNull()
            }
            if (number != null && number > 1.0 && number <= 1000.0) return String.format(Locale.US, "%.2f", number)
        }
        val prices = option.optJSONArray("price")
        if (prices != null) {
            for (i in 0 until prices.length()) {
                val price = prices.optJSONObject(i) ?: continue
                val number = price.optString("odds").toDoubleOrNull()
                    ?: price.optString("decimalValue").toDoubleOrNull()
                if (number != null && number > 1.0 && number <= 1000.0) return String.format(Locale.US, "%.2f", number)
            }
        }
        return null
    }

    private fun sameTeam(actual: String, wanted: String): Boolean {
        val a = normalize(actual)
        if (a == wanted) return true
        val at = a.split(' ').filter { it.length >= 3 }
        val wt = wanted.split(' ').filter { it.length >= 3 }
        if (at.isEmpty() || wt.isEmpty()) return false
        val overlap = wt.count { token -> at.any { it == token || it.contains(token) || token.contains(it) } }
        return overlap >= maxOf(1, kotlin.math.ceil(wt.size * 0.70).toInt())
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private const val TAG = "CioBwinSportsApi"
        private const val CACHE_TTL_MS = 90_000L
    }
}
