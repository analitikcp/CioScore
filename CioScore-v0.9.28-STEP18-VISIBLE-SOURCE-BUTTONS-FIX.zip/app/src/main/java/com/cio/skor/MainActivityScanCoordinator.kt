package com.cio.skor

import android.app.Activity
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.DropReason
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.MatchSessionStore
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ParserHealthReport
import com.cio.skor.data.ParserStatus
import com.cio.skor.data.SourceHealthMonitor
import com.cio.skor.data.PipelineStage
import com.cio.skor.data.PredictionCoverageStatus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.UnmatchedReason
import com.cio.skor.data.PredictionSourceCoverage
import com.cio.skor.data.IddaaMarketService
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class MainActivityScanCoordinator(
    private val host: Activity,
    private val repo: ScraperRepository,
    private val iddaaMarkets: IddaaMarketService,
    private val adapter: ScoreAdapter,
    private val recyclerView: RecyclerView,
    private val buildPredictionFirstGroups: (List<ScoreModel>, List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>) -> List<MatchGroup>,
    private val coalesceDisplayGroups: (List<MatchGroup>) -> List<MatchGroup>,
    private val isDisplayable: (ScoreModel) -> Boolean,
    private val onOddsBatch: (List<MatchGroup>) -> Unit,
    private val onBet365Preload: suspend (List<MatchGroup>) -> Unit,
    private val onGroupsReady: (List<MatchGroup>) -> Unit,
    private val onFocusPendingMatch: () -> Unit,
    private val onScanningChanged: (Boolean) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var scanning = false
    private var scanGeneration = 0

    fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        val scanStartMs = System.currentTimeMillis()
        scanning = true
        onScanningChanged(true)
        adapter.submitList(emptyList())

        scope.launch {
            try {
                // Fetch all configured score-analysis sources and official iddaa.com, then
                // perform ONE fixture merge across all prediction sources before rendering cards.
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll(
                        onProgress = { completed, source ->
                            host.runOnUiThread {
                                if (runId == scanGeneration) {
                                    onStatus("Kaynaklar: $completed/${repo.sourceCount} — $source")
                                }
                            }
                        },
                        onHealth = { report ->
                            // Publish immediately as each source finishes, so the health
                            // panel can observe live provider/parser state during a scan.
                            SourceHealthMonitor.record(report)
                        }
                    )
                }
                if (runId != scanGeneration) return@launch

                val healthySources = results.count { it.error == null && it.httpCode in 200..299 }
                val failedSources = results.count { it.error != null }
                val sourceSummary = results.joinToString(" • ") {
                    val state = it.error ?: "OK (${it.scores.size})"
                    "${it.source}: $state"
                }
                Log.d("ScanSummary", "healthy=$healthySources failed=$failedSources | $sourceSummary")

                if (healthySources == 0) {
                    onStatus("Tüm tahmin kaynakları başarısız oldu.")
                    Toast.makeText(host, "Tüm tahmin kaynakları başarısız oldu. Ayrıntılar logcat'te.", Toast.LENGTH_LONG).show()
                    return@launch
                }

                onStatus("Kaynaklar: $healthySources/${repo.sourceCount} başarılı" +
                    if (failedSources > 0) " • $failedSources sorunlu" else "")

                // Keep all CPU-heavy reconciliation/diagnostic work off the Android main thread.
                // The previous version returned from the source fetch onto Dispatchers.Main and
                // then ran fixture coverage + identity diagnostics there, which could trigger an
                // ANR after the UI reported "4/4 successful".
                onStatus("Kaynaklar: $healthySources/${repo.sourceCount} başarılı • Maçlar işleniyor…")
                val preparedGroups: List<MatchGroup> = withContext(Dispatchers.Default) {
                    val rawScores = results.sumOf { it.scores.size }

                // PREDICTION-FIRST HARD RULE: every parsed provider prediction is eligible
                // for the UI. Iddaa is enrichment only and is never a source gate.
                val parsedPredictionScores = results.flatMap { result: SourceResult -> result.scores }

                // KICKOFF CANONICALIZATION
                // Keep all renderable predictions through identity/official enrichment.
                // The past-match gate is intentionally applied AFTER GlobalFixtureMatcher
                // so an authoritative İddaa kickoff can correct a provider-side clock.
                // This is independent from the İddaa 06:00 bulletin window.
                val displayableScores = parsedPredictionScores.filter { isDisplayable(it) }
                val invalidScores = rawScores - displayableScores.size

                // Diagnostic only: count prediction records after the displayability filter.
                runCatching {
                    val diagnosticCounts = parsedPredictionScores.groupingBy { it.source }.eachCount()
                    com.cio.skor.data.PipelineDiagnostics.log(
                        sourceCounts = diagnosticCounts,
                        rawPredictions = parsedPredictionScores.size
                    )
                }

                // Iddaa is fetched only for optional enrichment. It MUST NOT gate, reject,
                // or shrink the provider prediction set, regardless of bulletin window.

                // Official Iddaa enrichment uses the FULL official football bulletin.
                // HT/FT availability is only a market property; it must NEVER restrict
                // the official fixture candidate pool used by GlobalFixtureMatcher.
                // The main scan tolerates a slower official response so the full bulletin
                // has time to arrive before matching.
                val officialResult = try {
                    withTimeoutOrNull(25_000L) {
                        withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    }
                } catch (_: Exception) {
                    null
                }
                if (runId != scanGeneration) throw CancellationException("Scan superseded")

                // No official fixture pool is used as a gate. Provider predictions remain
                // displayable even when the official bulletin has no matching fixture.

                // Deduplicate only true provider duplicates. Team names + score + source
                // are NOT a sufficient identity: the same clubs can legitimately play more
                // than once in the bulletin. Prefer the provider's match ID; otherwise keep
                // kickoff/date/time/competition metadata in the fallback key.
                val dedupedScores: List<ScoreModel> = displayableScores.distinctBy { prediction ->
                    val home = MatchMerger.normalizeTeamName(prediction.homeTeam)
                    val away = MatchMerger.normalizeTeamName(prediction.awayTeam)
                    val source = prediction.source.trim().lowercase()
                    val providerId = prediction.sourceMatchId.trim()
                    if (providerId.isNotBlank()) {
                        "ID|$source|$providerId"
                    } else {
                        "META|$source|$home|$away|${prediction.predictedScore.trim()}|" +
                            "${prediction.matchTimestamp}|${prediction.matchDate.trim()}|" +
                            "${prediction.matchTime.trim()}|${prediction.competitionName.trim().lowercase()}"
                    }
                }

                // IMPORTANT: there is NO Iddaa prediction gate anymore.
                // We only load the official bulletin so it can optionally enrich
                // prediction cards with MS1/MSX/MS2 and HT/FT data.
                val officialInBulletinWindow = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    // Use the service's already merged official fixture pool. Reusing
                    // allParsedMatches here would re-introduce duplicate official records
                    // that the service intentionally collapsed before the identity graph.
                    officialResult.matches.filter { official ->
                        official.matchTimestamp >= officialResult.bulletinStartMillis &&
                            official.matchTimestamp < officialResult.bulletinEndMillis
                    }
                } else {
                    emptyList()
                }

                // Seed one immutable prediction identity before ANY metadata copy or
                // matcher pass. This ID is carried through Record -> UnifiedMatch -> UI
                // and is never reconstructed from team names or score text.
                val identitySeededScores = dedupedScores.mapIndexed { index, prediction ->
                    if (prediction.predictionId.isNotBlank()) prediction
                    else prediction.copy(
                        predictionId = "P-${index}-${prediction.source.trim().lowercase()}-${
                            prediction.sourceMatchId.trim().ifBlank {
                                MatchMerger.normalizeTeamName(prediction.homeTeam) + "_" +
                                    MatchMerger.normalizeTeamName(prediction.awayTeam)
                            }
                        }"
                    )
                }

                // METADATA RECONCILIATION: before clustering, fill only missing
                // date/time/league/country fields. The predictionId survives every copy.
                val reconciledScores = withContext(Dispatchers.Default) {
                    GlobalFixtureMatcher.reconcileMetadata(
                        predictions = identitySeededScores,
                        officialMatches = officialInBulletinWindow
                    )
                }

                // PREDICTION-FIRST DISPLAY: never let the official Iddaa bulletin
                // determine whether a provider prediction exists in the UI. The official
                // 06:00-06:00 window has already been applied inside IddaaMarketService
                // to the official feed only; it is deliberately NOT applied to predictions.
                // The previous implementation still routed every prediction through
                // GlobalFixtureMatcher before building cards; that collapsed the 117
                // provider records into only 4 unified fixtures in the APK.
                // Build the display fixture set directly from provider predictions.
                // Iddaa is consulted afterwards, only as optional enrichment.
                val allPreparedGroups: List<MatchGroup> = withContext(Dispatchers.Default) {
                    val rawGroups = buildPredictionFirstGroups(reconciledScores, officialInBulletinWindow)
                    // FINAL FIXTURE-LEVEL COALESCE:
                    // The identity matcher is authoritative, but a provider can
                    // still emit the same fixture under different source IDs.
                    // Never let that provider-side duplication become two APK cards.
                    //
                    // IMPORTANT: do one final source backfill before the UI gate.
                    // Some providers publish only a date (no kickoff time), while
                    // another provider publishes the exact kickoff. Without this
                    // pass the same fixture could become separate one-source cards,
                    // making the four prediction rows appear empty even though the
                    // parser already has the real score. This pass only unions real
                    // parsed predictions; it never creates or guesses a score.
                    val withSources = coalesceDisplayGroups(rawGroups)

                    // OFFICIAL BULLETIN BASELINE: the main screen must still show the
                    // future fixtures in the official 06:00→06:00 İddaa bulletin even
                    // when every prediction parser misses that fixture. Previously the
                    // adapter required at least one prediction row, so a valid bulletin
                    // with 0 matched predictions produced a completely empty screen.
                    // Create an official-only card with empty prediction rows; never
                    // synthesize a score. If a provider group already represents the
                    // same fixture, keep the provider-enriched card instead.
                    val officialOnly: List<MatchGroup> = officialInBulletinWindow.asSequence()
                        .filter { official ->
                            val officialFixtureId = "IDDAA:${official.matchId}"
                            withSources.none { group -> group.fixtureId == officialFixtureId }
                        }
                        .map { official ->
                            MatchGroup(
                                isIddaaBulletinMatch = true,
                                homeTeam = official.homeTeam,
                                awayTeam = official.awayTeam,
                                predictions = emptyList(),
                                iddaaProgramUrl = official.matchDate.takeIf { it.isNotBlank() }?.let(::buildIddaaProgramUrl),
                                iddaaMs1 = official.ms1,
                                iddaaMsX = official.msX,
                                iddaaMs2 = official.ms2,
                                htFtOdds = official.htFtOdds,
                                hasHtFt = official.hasHtFt,
                                matchTimestamp = official.matchTimestamp,
                                displayTime = official.matchTime,
                                displayDate = official.matchDate,
                                fixtureId = "IDDAA:${official.matchId}"
                            )
                        }
                        .toList()

                    withSources + officialOnly
                }

                // REAL-TIME UPCOMING FIXTURE GATE
                // Use the actual moment at which the finished scan is about to be
                // rendered, not the 06:00 İddaa bulletin boundary. A kickoff at or
                // before this instant is already started/finished and is never shown.
                // Unknown kickoff is also excluded: without a trustworthy kickoff we
                // cannot prove that the prediction is still actionable.
                val reconciledKickoffCount = reconciledScores.count { it.matchTimestamp > 0L }
                val reconciledKickoffBySource = reconciledScores
                    .filter { it.matchTimestamp > 0L }
                    .groupingBy { it.source }.eachCount()
                Log.d("MetadataReconcile", "kickoff=$reconciledKickoffCount/${reconciledScores.size} bySource=$reconciledKickoffBySource")

                val renderNowMs = System.currentTimeMillis().coerceAtLeast(scanStartMs)
                val pastMatchGroups = allPreparedGroups.filter {
                    it.matchTimestamp > 0L && it.matchTimestamp <= renderNowMs
                }
                val missingKickoffGroups = allPreparedGroups.filter { it.matchTimestamp <= 0L }
                    val preparedGroups = allPreparedGroups.filter {
                        it.matchTimestamp > renderNowMs
                    }

                val iddaaMatchedForUi = preparedGroups.count {
                    it.iddaaMs1 != null || it.iddaaMsX != null || it.iddaaMs2 != null
                }
                val predictionNotInIddaaPredictions = preparedGroups
                    .filter { !it.isIddaaBulletinMatch }
                    .flatMap { it.predictions }
                val unmatchedOfficialDiagnostics = predictionNotInIddaaPredictions
                    .map { GlobalFixtureMatcher.diagnoseOfficialMismatch(it, officialInBulletinWindow) }
                val predictionNotInIddaaDetails = unmatchedOfficialDiagnostics.map { item ->
                    val source = predictionNotInIddaaPredictions.firstOrNull { p ->
                        p.homeTeam == item.predictionHome && p.awayTeam == item.predictionAway
                    }?.source ?: "?"
                    "${item.predictionHome} vs ${item.predictionAway} | $source | ${diagnosticReasonLabel(item.probableReason)}"
                }
                // IMPORTANT: the 06:00-06:00 rule belongs ONLY to the official İddaa
                // bulletin. Prediction providers and independent bookmaker odds
                // are never filtered by that window. This diagnostic list only records
                // predictions whose own timestamp falls outside the official bulletin;
                // it NEVER removes them from preparedGroups or the UI.
                val predictionOutsideBulletinDetails = if (
                    officialResult != null &&
                    officialResult.bulletinStartMillis > 0L &&
                    officialResult.bulletinEndMillis > officialResult.bulletinStartMillis
                ) {
                    dedupedScores.filter { prediction ->
                        val ts = prediction.matchTimestamp
                        ts > 0L && (
                            ts < officialResult.bulletinStartMillis ||
                                ts >= officialResult.bulletinEndMillis
                            )
                    }.map { prediction ->
                        "${prediction.homeTeam} vs ${prediction.awayTeam} | ${prediction.source} | " +
                            "IDDAA_BULLETIN_WINDOW_DISJOINT"
                    }
                } else {
                    emptyList()
                }

                // BIDIRECTIONAL SOURCE COVERAGE DIAGNOSTIC:
                // The older diagnostic only asked "which provider predictions failed
                // to attach to Iddaa?". That cannot explain the much larger reverse
                // gap: official fixtures with no prediction card at all. Inspect every
                // official fixture against every parsed provider source without changing
                // the UI or matcher behavior.
                val coverageSourceNames = results.map { it.source }
                val coverageDetails = officialInBulletinWindow.flatMap { official ->
                    coverageSourceNames.map { source ->
                        val sourcePredictions = dedupedScores.filter { it.source == source }
                        GlobalFixtureMatcher.diagnoseOfficialCoverage(
                            official = official,
                            source = source,
                            predictions = sourcePredictions
                        )
                    }
                }
                val coverageMatchedBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.MATCHED }
                    .groupingBy { it.source }.eachCount()
                val coveragePresentButUnmatchedBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.SOURCE_PRESENT_BUT_UNMATCHED }
                    .groupingBy { it.source }.eachCount()
                val coverageAbsentBySource = coverageDetails
                    .filter { it.status == PredictionCoverageStatus.SOURCE_ABSENT_FROM_PARSED_DATA }
                    .groupingBy { it.source }.eachCount()
                val predictionSourceCoverage = PredictionSourceCoverage(
                    officialFixtureCount = officialInBulletinWindow.size,
                    sourceNames = coverageSourceNames,
                    matchedBySource = coverageMatchedBySource,
                    presentButUnmatchedBySource = coveragePresentButUnmatchedBySource,
                    absentBySource = coverageAbsentBySource,
                    details = coverageDetails
                )

                val metadataCompleteBySource = dedupedScores
                    .groupBy { it.source }
                    .mapValues { (_, items) ->
                        items.count { it.matchDate.isNotBlank() && it.matchTime != "--:--" && it.competitionName.isNotBlank() }
                    }
                val metadataPartialBySource = dedupedScores
                    .groupBy { it.source }
                    .mapValues { (_, items) ->
                        items.count { it.matchDate.isNotBlank() || it.matchTime != "--:--" || it.competitionName.isNotBlank() }
                    }
                val predictionNotInIddaaByReason = unmatchedOfficialDiagnostics
                    .groupingBy { it.probableReason.name }
                    .eachCount()
                val pastMatchDetails = pastMatchGroups.take(30).map { match ->
                    "${match.homeTeam} vs ${match.awayTeam} | ${match.displayDate} ${match.displayTime}"
                }

                ObservabilityBus.publish(
                    ScanTrace(
                        // Build parser health reports inline. This is diagnostic-only and
                        // never filters, rejects, or removes prediction matches.
                        parserReports = results.map { result ->
                            val status = when {
                                result.error == null && result.httpCode in 200..299 && result.scores.isNotEmpty() ->
                                    ParserStatus.HEALTHY
                                result.httpCode in 200..299 && result.scores.isEmpty() ->
                                    ParserStatus.DOM_CHANGED
                                else ->
                                    ParserStatus.FAILED
                            }
                            ParserHealthReport(
                                sourceName = result.source,
                                httpCode = result.httpCode,
                                rawHtmlBytes = result.rawHtmlBytes,
                                parsedCount = result.scores.size,
                                durationMs = result.durationMs,
                                status = status,
                                errorMessage = result.error
                            )
                        },
                        stageMetrics = linkedMapOf(
                            PipelineStage.HTTP to results.count { it.httpCode in 200..299 },
                            PipelineStage.PARSER to rawScores,
                            PipelineStage.NORMALIZATION to dedupedScores.size,
                            PipelineStage.IDENTITY to preparedGroups.size,
                            PipelineStage.CONFIDENCE to preparedGroups.count { it.predictions.size >= 2 },
                            PipelineStage.MERGE to preparedGroups.size,
                            PipelineStage.IDDAA_ENRICHMENT to iddaaMatchedForUi,
                            PipelineStage.UI to preparedGroups.size
                        ),
                        // Only genuinely invalid provider records are drops.
                        // A prediction missing from Iddaa is explicitly NOT a drop.
                        dropReasons = buildList {
                            if (invalidScores > 0) {
                                add(DropReason(PipelineStage.PARSER, "INVALID_SCORE_OR_TEAM", invalidScores))
                            }
                        },
                        totalDurationMs = System.currentTimeMillis() - scanStartMs,
                        unmatchedOfficialDiagnostics = unmatchedOfficialDiagnostics,
                        officialFeedDiagnostics = officialResult?.let { result ->
                            com.cio.skor.data.OfficialFeedDiagnostics(
                                httpEvents = result.httpEvents,
                                httpMarketConfig = result.httpMarketConfig,
                                rawEventCount = result.rawEventCount,
                                parsedEventCount = result.parsedEventCount,
                                timestampedEventCount = result.timestampedEventCount,
                                bulletinEventCountBeforeMerge = result.bulletinEventCountBeforeMerge,
                                bulletinDate = result.bulletinDate,
                                bulletinWindow = result.bulletinWindow,
                                mergedFixtureCount = result.mergedFixtureCount,
                                marketMatches = result.marketMatches,
                                error = result.error,
                                dateDistribution = result.dateDistribution,
                                sampleFixtures = result.sampleFixtures
                            )
                        },
                        predictionFixtureCount = preparedGroups.count { it.predictions.isNotEmpty() },
                        officialMatchedPredictionCount = iddaaMatchedForUi,
                        // Diagnostic-only: an official fixture is "official-only" when
                        // no parsed prediction source has a MATCHED coverage result.
                        // Do not synthesize or infer fixture counts from UI card counts.
                        officialOnlyFixtureCount = coverageDetails
                            .groupBy { "${it.officialHome}\u0000${it.officialAway}" }
                            .count { (_, items) ->
                                items.none { it.status == PredictionCoverageStatus.MATCHED }
                            },
                        // These two fields are enrichment diagnostics only. They do NOT
                        // represent dropped predictions.
                        predictionNotInIddaaCount = predictionNotInIddaaDetails.size,
                        predictionNotInIddaaDetails = predictionNotInIddaaDetails.toList(),
                        predictionNotInIddaaBySource = predictionNotInIddaaDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        predictionNotInIddaaByReason = predictionNotInIddaaByReason,
                        metadataCompleteBySource = metadataCompleteBySource,
                        metadataTotalBySource = dedupedScores.groupBy { it.source }.mapValues { it.value.size },
                        metadataPartialBySource = metadataPartialBySource,
                        predictionOutsideBulletinCount = predictionOutsideBulletinDetails.size,
                        predictionOutsideBulletinDetails = predictionOutsideBulletinDetails.toList(),
                        predictionOutsideBulletinBySource = predictionOutsideBulletinDetails
                            .mapNotNull { it.split(" | ").getOrNull(1) }
                            .groupingBy { it }.eachCount(),
                        pastMatchFilteredCount = pastMatchGroups.size,
                        pastMatchFilteredDetails = pastMatchDetails,
                        missingKickoffCount = missingKickoffGroups.size,
                        missingKickoffBySource = missingKickoffGroups
                            .flatMap { it.predictions }
                            .groupingBy { it.source }.eachCount(),
                        reconciledKickoffCount = reconciledKickoffCount,
                        reconciledKickoffBySource = reconciledKickoffBySource,
                        predictionSourceCoverage = predictionSourceCoverage
                    )
                )

                    preparedGroups
                }

                val enrichedGroups = preparedGroups

                // Bet365 PRELOAD: MoviOdds -> 7M Sport -> ChekiOdds -> SingleBet -> SimplyOdds.
                runCatching {
                    onBet365Preload(enrichedGroups)
                }.onFailure {
                    Log.w("CioScoreOdds", "Bet365 kaynak preload uyarısı: ${it.message}")
                }

                MatchSessionStore.latestGroups = enrichedGroups
                onGroupsReady(enrichedGroups)
                // PRELOAD ODDS: network work starts for the whole result set as soon
                // as the scan finishes. RecyclerView visibility/scroll position no
                // longer controls when bookmaker requests begin.
                adapter.prepareOddsPreload(enrichedGroups)
                recyclerView.visibility = View.VISIBLE
                adapter.submitList(enrichedGroups)
                onOddsBatch(enrichedGroups)
                recyclerView.post {
                    recyclerView.visibility = View.VISIBLE
                    recyclerView.invalidate()
                }
                onStatus("${enrichedGroups.size} maç • İddaa + Bet365(MoviOdds→7M Sport→ChekiOdds→SingleBet→SimplyOdds) + bwin • Teşhis: 🔍")
                onFocusPendingMatch()
            } catch (e: CancellationException) {
                // Activity destruction / newer scan cancellation is expected.
                throw e
            } catch (e: Exception) {
                Log.e("MainActivity", "Tarama hattında beklenmeyen çökme", e)
                onStatus("Tarama hatası: ${e.javaClass.simpleName.ifBlank { "Exception" }}")
                Toast.makeText(
                    host,
                    "Tarama sırasında hata oluştu: ${e.localizedMessage ?: (e.javaClass.simpleName.ifBlank { "Exception" })}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                if (runId == scanGeneration) onScanningChanged(false)
            }
        }
    }



    fun cancel() { scope.cancel() }
    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    private fun diagnosticReasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.OFFICIAL_BULLETIN_ABSENT -> "Resmi bültende yok"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "Resmi aday bulunamadı"
        UnmatchedReason.NAME_MISMATCH -> "Takım adı uyuşmuyor"
        UnmatchedReason.DATE_MISMATCH -> "Tarih uyuşmuyor"
        UnmatchedReason.TIME_MISMATCH -> "Saat uyuşmuyor"
        UnmatchedReason.COMPETITION_MISMATCH -> "Lig/organizasyon uyuşmuyor"
        UnmatchedReason.AMBIGUOUS_OFFICIAL_CANDIDATE -> "Birden fazla resmi aday"
        UnmatchedReason.METADATA_MISSING -> "Program bilgisi eksik"
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "Takım adı/alias sorunu"
    }

}
