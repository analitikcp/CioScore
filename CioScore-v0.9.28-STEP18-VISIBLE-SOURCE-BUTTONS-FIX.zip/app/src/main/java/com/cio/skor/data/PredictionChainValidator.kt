package com.cio.skor.data

/**
 * Final safety gate shared by the parser/merge/UI chain.
 *
 * A source is considered a usable exact-score source only when both team names
 * and a strict numeric exact score are present. HTTP 200 by itself is never
 * enough to promote a source to a healthy score source.
 */
object PredictionChainValidator {
    private val EXACT_SCORE = Regex("^\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\s*$")

    data class Validation(
        val valid: Boolean,
        val normalizedScore: String = "",
        val reason: String = ""
    )

    fun validate(prediction: ScoreModel): Validation {
        if (prediction.homeTeam.isBlank()) return Validation(false, reason = "MISSING_HOME_TEAM")
        if (prediction.awayTeam.isBlank()) return Validation(false, reason = "MISSING_AWAY_TEAM")
        if (prediction.homeTeam.trim().equals(prediction.awayTeam.trim(), ignoreCase = true)) {
            return Validation(false, reason = "SAME_HOME_AWAY_TEAM")
        }

        val score = EXACT_SCORE.matchEntire(prediction.predictedScore.trim())
            ?: return Validation(false, reason = "INVALID_EXACT_SCORE")
        val home = score.groupValues[1].toIntOrNull()
            ?: return Validation(false, reason = "INVALID_HOME_SCORE")
        val away = score.groupValues[2].toIntOrNull()
            ?: return Validation(false, reason = "INVALID_AWAY_SCORE")
        if (home !in 0..20 || away !in 0..20) {
            return Validation(false, reason = "SCORE_OUT_OF_RANGE")
        }

        return Validation(true, "$home-$away")
    }

    fun sanitize(prediction: ScoreModel): ScoreModel? {
        val validation = validate(prediction)
        if (!validation.valid) return null
        return if (prediction.predictedScore == validation.normalizedScore) {
            prediction
        } else {
            prediction.copy(predictedScore = validation.normalizedScore)
        }
    }
}
