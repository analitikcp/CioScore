package com.cio.skor.data

import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Public bookmaker-comparison fallback dedicated to the bwin row.
 *
 * Why this exists:
 * - TipsterArea does not publish bwin for every fixture.
 * - SofaScore's internal provider catalogue/odds endpoints are not a stable
 *   public API and can stop returning a bwin provider without warning.
 * - bwin's official Sports API requires commercial credentials.
 *
 * OddsSafari publicly renders bookmaker-specific 1X2 rows. We use it only to
 * read the row whose bookmaker is explicitly bwin; we never copy a best/average
 * price into the bwin row.
 */
class OddsSafariBwinService {
    data class Odds(val bookmaker: String = "bwin", val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val pageCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val cacheTtlMs = 90_000L

    private data class CacheEntry(val expiresAt: Long, val value: Odds?)

    suspend fun fetch(homeTeam: String, awayTeam: String, matchDate: String = ""): Odds? {
        val key = "${normalize(homeTeam)}|${normalize(awayTeam)}|${matchDate.take(10)}"
        cache[key]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return it.value }

        val coupon = fetchPage("https://www.oddssafari.com/coupons/full/sports/10") ?: run {
            cache[key] = CacheEntry(System.currentTimeMillis() + 15_000L, null)
            return null
        }
        val eventUrl = discoverEventUrl(coupon, homeTeam, awayTeam)
        if (eventUrl == null) {
            cache[key] = CacheEntry(System.currentTimeMillis() + 30_000L, null)
            return null
        }

        val detail = fetchPage(eventUrl)
        val odds = detail?.let(::parseBwin1x2)
        cache[key] = CacheEntry(System.currentTimeMillis() + cacheTtlMs, odds)
        return odds
    }

    private suspend fun fetchPage(url: String): String? {
        pageCache[url]?.takeIf { it.first > System.currentTimeMillis() }?.let { return it.second }
        val primary = http.getSource(url, "https://www.oddssafari.com/")
        val body = if (primary.first in 200..299 && !primary.second.isNullOrBlank()) {
            primary.second
        } else {
            val fallback = http.get(url, "https://www.oddssafari.com/")
            if (fallback.first in 200..299 && !fallback.second.isNullOrBlank()) fallback.second else null
        }
        if (!body.isNullOrBlank()) pageCache[url] = System.currentTimeMillis() + 45_000L to body
        return body
    }

    private fun discoverEventUrl(html: String, homeTeam: String, awayTeam: String): String? {
        val home = teamVariants(homeTeam)
        val away = teamVariants(awayTeam)
        if (home.isEmpty() || away.isEmpty()) return null

        val doc = Jsoup.parse(html, "https://www.oddssafari.com/")
        var best: String? = null
        var bestScore = 0.0
        for (a in doc.select("a[href*=/matches/soccer/], a[href*=/match/soccer/], a[href*=/matches/]") ) {
            val href = a.absUrl("href").ifBlank { a.attr("href") }
            if (href.isBlank()) continue
            val evidence = normalize(a.text() + " " + a.attr("title") + " " + href)
            val hs = teamSimilarity(evidence, home)
            val ascore = teamSimilarity(evidence, away)
            if (hs < 0.60 || ascore < 0.60) continue
            val score = (hs + ascore) / 2.0
            if (score > bestScore) {
                bestScore = score
                best = href
            }
            if (hs >= 0.90 && ascore >= 0.90) return href
        }
        return best?.takeIf { bestScore >= 0.72 }
    }

    private fun parseBwin1x2(html: String): Odds? {
        val doc = Jsoup.parse(html)
        val candidates = mutableListOf<Pair<Double, Odds>>()
        for (row in doc.select("tr")) {
            if (!isBwinRow(row)) continue
            val numbers = numericValues(row)
            if (numbers.size < 3) continue
            val firstThree = numbers.take(3)
            if (!valid(firstThree)) continue
            val odds = Odds(
                ms1 = fmt(firstThree[0]),
                msX = fmt(firstThree[1]),
                ms2 = fmt(firstThree[2])
            )
            // Prefer rows whose ancestor/table is explicitly 1-X-2 / Match Result.
            val context = normalize(row.parent()?.text().orEmpty() + " " + row.parents().firstOrNull()?.text().orEmpty())
            val bonus = if (context.contains("1 x 2") || context.contains("match result")) 2.0 else 0.0
            candidates += (bonus to odds)
        }
        return candidates.maxByOrNull { it.first }?.second
            ?: parseBwinFromFlatText(doc)
    }

    private fun parseBwinFromFlatText(doc: org.jsoup.nodes.Document): Odds? {
        val text = doc.text()
        val normalized = normalize(text)
        val marker = normalized.indexOf("bwin")
        if (marker < 0) return null
        val tail = text.substring(marker.coerceAtLeast(0)).take(220)
        val nums = ODDS_NUMBER.findAll(tail).mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
            .filter { it > 1.0 && it <= 100.0 }
            .take(3)
            .toList()
        return if (nums.size == 3) Odds(ms1 = fmt(nums[0]), msX = fmt(nums[1]), ms2 = fmt(nums[2])) else null
    }

    private fun isBwinRow(row: Element): Boolean {
        val labels = row.select("img[alt]").map { it.attr("alt") }
        val text = normalize(row.text() + " " + labels.joinToString(" "))
        return Regex("\\bbwin\\b").containsMatchIn(text) && !text.contains("bet365")
    }

    private fun numericValues(row: Element): List<Double> =
        ODDS_NUMBER.findAll(row.text())
            .mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
            .filter { it > 1.0 && it <= 100.0 }
            .toList()

    private fun valid(values: List<Double>): Boolean =
        values.size >= 3 && values.take(3).all { it > 1.0 && it <= 100.0 }

    private fun fmt(value: Double): String = String.format(Locale.US, "%.2f", value)

    private fun teamVariants(value: String): List<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptyList()
        val stripped = base.split(' ').filterNot { it in GENERIC_PREFIXES }.joinToString(" ").trim()
        return listOf(base, stripped).filter { it.isNotBlank() }.distinct()
    }

    private fun teamSimilarity(haystack: String, variants: List<String>): Double =
        variants.maxOfOrNull { team ->
            if (haystack.contains(team)) 1.0 else {
                val tokens = team.split(' ').filter { it.length >= 3 }
                if (tokens.isEmpty()) 0.0 else tokens.count { haystack.contains(it) }.toDouble() / tokens.size
            }
        } ?: 0.0

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("https?://|www\\."), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private val ODDS_NUMBER = Regex("(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])")
        private val GENERIC_PREFIXES = setOf(
            "fc", "cf", "cd", "sc", "ac", "afc", "fk", "sk", "nk", "club", "clube",
            "deportivo", "deportiva", "football", "soccer"
        )
    }
}
