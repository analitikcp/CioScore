package com.cio.skor.data

/**
 * Single UI-facing registry for prediction-provider names.
 *
 * The repository owns which providers are actually fetched; this registry only
 * defines their stable display order/labels. Unknown providers are still
 * renderable, which prevents a new parser from silently disappearing from the
 * APK just because the adapter was not updated at the same time.
 */
object PredictionSourceCatalog {
    private val preferredOrder = listOf(
        "FP.com", "PredictZ", "WinDrawWin", "DailySports",
        "BallPrediction", "Correct-Score.net", "FootballScorePredictor",
        "AccurateTip"
    )

    private val labels: Map<String, String> = listOf(
        Pair("fp.com", "FP.com"),
        Pair("predictz", "PredictZ"),
        Pair("windrawwin", "WinDrawWin"),
        Pair("dailysports", "DailySports"),
        Pair("ballprediction", "BallPrediction"),
        Pair("correct-score.net", "Correct-Score.net"),
        Pair("footballscorepredictor", "FootballScorePredictor"),
        Pair("accuratetip", "AccurateTip")
    ).toMap()

    private val urls: Map<String, String> = listOf(
        Pair("fp.com", "https://footballpredictions.com/betting-tips/correct-score/"),
        Pair("predictz", "https://www.predictz.com/predictions/today/correct-score/all-games/"),
        Pair("windrawwin", "https://www.windrawwin.com/predictions/today/"),
        Pair("dailysports", "https://dailysports.net/mathematical-predictions/correct-score/"),
        Pair("ballprediction", "https://ballprediction.com/"),
        Pair("correct-score.net", "https://www.correct-score.net/en/"),
        Pair("footballscorepredictor", "https://www.footballscorepredictor.com/correct-score-predictions/"),
        Pair("accuratetip", "https://www.accuratetip.com/correct-score-predictions")
    ).toMap()

    fun orderOf(source: String): Int =
        preferredOrder.indexOfFirst { it.equals(source.trim(), ignoreCase = true) }
            .takeIf { it >= 0 } ?: preferredOrder.size

    fun displayLabel(source: String): String {
        labels[source.trim().lowercase()]?.let { return it }
        return source.trim()
    }

    fun url(source: String): String? = urls[source.trim().lowercase()]
}
