package com.cio.skor.data

import java.security.MessageDigest
import java.util.Locale

/**
 * Stable, source-scoped cache identity helpers.
 *
 * Cache keys must never rely on list position, object identity, or only the
 * first/last provider row. Those shortcuts can reuse stale data when a source
 * returns a different page with the same row count and boundary IDs.
 */
object SourceCacheIdentity {

    fun source(source: String): String = normalize(source)

    fun team(team: String): String = normalize(team)

    fun date(date: String): String = date.trim().lowercase(Locale.ROOT)

    fun fixture(
        source: String,
        homeTeam: String,
        awayTeam: String,
        matchDate: String = "",
        sourceMatchId: String = "",
        competition: String = ""
    ): String = listOf(
        source(source),
        team(homeTeam),
        team(awayTeam),
        date(matchDate),
        normalize(sourceMatchId),
        normalize(competition)
    ).joinToString("|") { it.length.toString() + ":" + it }

    /** Content identity for an entire provider result set. Order is irrelevant. */
    fun resultSet(source: String, predictions: List<ScoreModel>): String {
        val rows = predictions.map { prediction ->
            fixture(
                source = source,
                homeTeam = prediction.homeTeam,
                awayTeam = prediction.awayTeam,
                matchDate = prediction.matchDate,
                sourceMatchId = prediction.sourceMatchId,
                competition = prediction.competitionName
            ) + "|" + normalize(prediction.predictedScore) +
                "|" + prediction.matchTimestamp +
                "|" + normalize(prediction.predictionId)
        }.sorted()
        return digest(source(source) + "|" + rows.joinToString("\n"))
    }

    private fun normalize(value: String): String = value
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")

    private fun digest(value: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
