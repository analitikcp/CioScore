package com.cio.skor.data

import android.content.Context
import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Independent bookmaker board backed by TotalCorner's football API.
 *
 * This is deliberately separate from the Bet365 verification chain. TotalCorner
 * exposes Bet365 plus a broad set of other bookmakers and, importantly, keeps
 * bookmaker identity and opening/closing prices instead of collapsing the
 * market to one "best" number.
 */
class TotalCornerOddsService(context: Context) {
    data class BookmakerSnapshot(
        val bookmaker: String,
        val openMs1: String?,
        val openMsX: String?,
        val openMs2: String?,
        val closeMs1: String?,
        val closeMsX: String?,
        val closeMs2: String?,
        val latestMs1: String?,
        val latestMsX: String?,
        val latestMs2: String?,
        val matchId: String,
        val source: String = "TotalCorner"
    ) {
        fun latestComplete(): Boolean = listOf(latestMs1, latestMsX, latestMs2).all { it?.toDoubleOrNull()?.let { n -> n > 1.0 && n <= 1000.0 } == true }
    }

    data class Result<T>(val value: T? = null, val error: String? = null)

    private data class CacheEntry(val expiresAt: Long, val value: List<BookmakerSnapshot>)
    private data class MatchRef(val id: String, val home: String, val away: String, val start: Long)

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val http = HttpClient()
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private val scheduleCache = ConcurrentHashMap<String, Pair<Long, List<MatchRef>>>()

    fun getToken(): String = prefs.getString(TOKEN_KEY, "").orEmpty().trim()
    fun setToken(token: String) = prefs.edit().putString(TOKEN_KEY, token.trim()).apply()
    fun clearToken() = prefs.edit().remove(TOKEN_KEY).apply()

    suspend fun fetchBookmakers(homeTeam: String, awayTeam: String, kickoffEpochSec: Long): Result<List<BookmakerSnapshot>> =
        withContext(Dispatchers.IO) {
            val token = getToken()
            if (token.isBlank()) return@withContext Result(error = "TotalCorner API token ayarlanmadı")

            val cacheKey = SourceCacheIdentity.fixture(
                source = "TotalCorner",
                homeTeam = homeTeam,
                awayTeam = awayTeam,
                matchDate = Instant.ofEpochSecond(kickoffEpochSec).atZone(ZONE).toLocalDate().toString()
            ) + "|hour=" + (kickoffEpochSec / 3600L)
            cache[cacheKey]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return@withContext Result(it.value) }

            val target = Instant.ofEpochSecond(kickoffEpochSec).atZone(ZONE).toLocalDate()
            val candidateDates = listOf(target.minusDays(1), target, target.plusDays(1))
            val candidates = candidateDates.flatMap { loadSchedule(it, token) }
                .distinctBy { it.id }
                .filter { sameTeam(it.home, homeTeam) && sameTeam(it.away, awayTeam) }
                .sortedBy { kotlin.math.abs(it.start - kickoffEpochSec) }

            val match = candidates.firstOrNull { kotlin.math.abs(it.start - kickoffEpochSec) <= 3 * 3600L }
                ?: return@withContext Result(error = "TotalCorner fixture eşleşmedi")

            val rows = fetchMatchBookmakers(match.id, token)
            if (rows.isNotEmpty()) cache[cacheKey] = CacheEntry(System.currentTimeMillis() + CACHE_TTL_MS, rows)
            Log.d(TAG, "TotalCorner ${homeTeam} - ${awayTeam}: fixture=${match.id} bookmakers=${rows.size}")
            Result(rows)
        }

    private suspend fun loadSchedule(date: LocalDate, token: String): List<MatchRef> = withContext(Dispatchers.IO) {
        val key = date.toString()
        scheduleCache[key]?.takeIf { it.first > System.currentTimeMillis() }?.let { return@withContext it.second }
        val dateParam = date.format(DateTimeFormatter.BASIC_ISO_DATE)
        val all = mutableListOf<MatchRef>()
        var page = 1
        while (page <= 20) {
            val url = "https://api.totalcorner.com/v1/match/schedule?token=$token&date=$dateParam&page=$page&columns=events"
            val (code, body) = http.getSource(url, "https://www.totalcorner.com/")
            if (code !in 200..299 || body.isNullOrBlank()) break
            val root = runCatching { JSONObject(body) }.getOrNull() ?: break
            if (root.optInt("success", 0) != 1) break
            val data = root.opt("data")
            val array = when (data) {
                is JSONArray -> data
                is JSONObject -> data.optJSONArray("matches") ?: JSONArray()
                else -> JSONArray()
            }
            if (array.length() == 0) break
            for (i in 0 until array.length()) parseMatch(array.optJSONObject(i))?.let(all::add)
            val pagination = root.optJSONObject("pagination")
            if (pagination?.optBoolean("next", false) != true) break
            page++
        }
        scheduleCache[key] = System.currentTimeMillis() + SCHEDULE_TTL_MS to all
        all
    }

    private suspend fun fetchMatchBookmakers(matchId: String, token: String): List<BookmakerSnapshot> = coroutineScope {
        val url = "https://api.totalcorner.com/v1/match/bookmaker_odds/$matchId?token=$token"
        val (code, body) = http.getSource(url, "https://www.totalcorner.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return@coroutineScope emptyList()
        val root = runCatching { JSONObject(body) }.getOrNull() ?: return@coroutineScope emptyList()
        if (root.optInt("success", 0) != 1) return@coroutineScope emptyList()
        val data = root.optJSONArray("data")?.optJSONObject(0) ?: return@coroutineScope emptyList()
        val bookmakers = data.optJSONArray("bookmakers") ?: return@coroutineScope emptyList()
        val out = mutableListOf<BookmakerSnapshot>()
        for (i in 0 until bookmakers.length()) {
            val row = bookmakers.optJSONObject(i) ?: continue
            val name = row.optString("name").trim().ifBlank { row.optString("slug").trim() }
            if (name.isBlank()) continue
            val odds = row.optJSONObject("odds") ?: continue
            val open = odds.optJSONObject("open")
            val close = odds.optJSONObject("close")
            val inplay = odds.optJSONObject("inplay")
            val latest = close ?: open ?: inplay ?: continue
            val snap = BookmakerSnapshot(
                bookmaker = name,
                openMs1 = decimal(open, "home"), openMsX = decimal(open, "draw"), openMs2 = decimal(open, "away"),
                closeMs1 = decimal(close, "home"), closeMsX = decimal(close, "draw"), closeMs2 = decimal(close, "away"),
                latestMs1 = decimal(latest, "home"), latestMsX = decimal(latest, "draw"), latestMs2 = decimal(latest, "away"),
                matchId = matchId
            )
            if (snap.latestComplete()) out += snap
        }
        out.sortedBy { it.bookmaker.lowercase(Locale.US) }
    }

    private fun parseMatch(row: JSONObject?): MatchRef? {
        if (row == null) return null
        val id = row.opt("id")?.toString().orEmpty()
        val home = row.optString("h").trim()
        val away = row.optString("a").trim()
        val start = parseStart(row.optString("start")) ?: return null
        if (id.isBlank() || home.isBlank() || away.isBlank()) return null
        return MatchRef(id, home, away, start)
    }

    private fun parseStart(raw: String): Long? = runCatching {
        LocalDateTimeCompat.parse(raw).atZone(ZONE).toEpochSecond()
    }.getOrNull()

    private fun decimal(obj: JSONObject?, key: String): String? {
        if (obj == null) return null
        val n = obj.optDouble(key, Double.NaN)
        return if (n.isFinite() && n > 1.0 && n <= 1000.0) String.format(Locale.US, "%.3f", n).trimEnd('0').trimEnd('.') else null
    }

    private fun sameTeam(a: String, b: String): Boolean {
        val x = normalize(a); val y = normalize(b)
        if (x == y) return true
        val xt = x.split(' ').filter { it.length >= 3 }.toSet()
        val yt = y.split(' ').filter { it.length >= 3 }.toSet()
        if (xt.isEmpty() || yt.isEmpty()) return false
        val overlap = xt.intersect(yt).size
        return overlap >= kotlin.math.ceil(minOf(xt.size, yt.size) * 0.75).toInt()
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
        .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace("ı", "i").replace("ß", "ss")
        .replace(Regex("[^a-z0-9]+"), " ").trim()

    companion object {
        private const val TAG = "CioTotalCorner"
        private const val PREFS = "totalcorner_odds_v1"
        private const val TOKEN_KEY = "token"
        private const val CACHE_TTL_MS = 90_000L
        private const val SCHEDULE_TTL_MS = 5 * 60_000L
        private val ZONE: ZoneId = ZoneId.of("Europe/Istanbul")
    }

    /** Tiny dependency-free parser for TotalCorner's YYYY-MM-DD HH:mm:ss timestamps. */
    private object LocalDateTimeCompat {
        fun parse(raw: String): java.time.LocalDateTime = java.time.LocalDateTime.parse(
            raw.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        )
    }
}
