package com.cio.skor.data

/**
 * Short, action-oriented diagnostic report.
 * Only problems that can justify a code/data fix are shown.
 */
object DiagnosticReportBuilder {
    private const val MAX_ITEMS = 5

    fun build(trace: ScanTrace, liveHealth: SourceHealthState = SourceHealthMonitor.state.value): String {
        val parserProblems = trace.parserReports
            .filter { it.status != ParserStatus.HEALTHY || !it.errorMessage.isNullOrBlank() }
            .sortedWith(compareBy<ParserHealthReport>({ severity(it.status) }, { -it.parsedCount }))
        val mergeProblems = trace.unmatchedOfficialDiagnostics
            .sortedWith(compareByDescending<UnmatchedDiagnosticItem> { reasonSeverity(it.probableReason) }
                .thenBy { it.combinedSimilarity })
        val drops = trace.dropReasons
            .filter { it.count > 0 && !it.reasonCode.contains("SOURCE_ABSENT_FROM_PARSED_DATA") }
            .sortedByDescending { it.count }
        val liveProblems = liveHealth.latest
            .filter { it.status != ParserStatus.HEALTHY }
            .sortedWith(compareBy<SourceHealthSnapshot>({ severity(it.status) }, { -it.parsedCount }))

        val problemCount = parserProblems.size + mergeProblems.size + drops.size
        val sb = StringBuilder()
        sb.appendLine("TEŞHİS — SADECE SORUNLAR [#${trace.scanId}]")
        sb.appendLine("Maç: ${trace.predictionFixtureCount} | İddaa eşleşen: ${trace.officialMatchedPredictionCount} | Süre: ${trace.totalDurationMs} ms")

        if (problemCount == 0 && liveProblems.isEmpty()) {
            sb.appendLine("🟢 Kritik sorun tespit edilmedi.")
            return sb.toString().trimEnd()
        }

        if (parserProblems.isNotEmpty() || liveProblems.isNotEmpty()) {
            sb.appendLine("🔴 KAYNAK / PARSER — düzeltme adayı")
            val merged = (parserProblems.map { it.sourceName to formatParser(it) } +
                liveProblems.map { it.sourceName to formatLive(it) })
                .distinctBy { it.first }
                .take(MAX_ITEMS)
            merged.forEach { (_, line) -> sb.appendLine("• $line") }
            if (parserProblems.size + liveProblems.size > MAX_ITEMS) sb.appendLine("• … diğer kaynaklar gizlendi")
        }

        if (mergeProblems.isNotEmpty()) {
            sb.appendLine("🔴 EŞLEŞTİRME — matcher/alias/schedule kontrolü")
            mergeProblems.take(MAX_ITEMS).forEach { item ->
                val candidate = if (item.bestOfficialHome != null && item.bestOfficialAway != null) {
                    " → ${item.bestOfficialHome} vs ${item.bestOfficialAway}"
                } else ""
                sb.appendLine("• ${reasonLabel(item.probableReason)}: ${item.predictionHome} vs ${item.predictionAway}$candidate")
            }
            if (mergeProblems.size > MAX_ITEMS) sb.appendLine("• … +${mergeProblems.size - MAX_ITEMS} eşleşme sorunu")
        }

        if (drops.isNotEmpty()) {
            sb.appendLine("🟠 VERİ KAYBI — pipeline aşaması")
            drops.take(MAX_ITEMS).forEach { drop ->
                sb.appendLine("• ${drop.stage}: ${drop.reasonCode} (${drop.count})")
            }
            if (drops.size > MAX_ITEMS) sb.appendLine("• … diğer drop nedenleri gizlendi")
        }

        sb.appendLine("ODAK: ${fixFocus(parserProblems, mergeProblems, drops)}")
        return sb.toString().trimEnd()
    }

    private fun formatParser(r: ParserHealthReport): String {
        val error = r.errorMessage?.substringBefore('\n')?.take(100).orEmpty()
        return "${r.sourceName}: ${r.status}, HTTP ${r.httpCode}, ${r.parsedCount} skor" +
            if (error.isNotBlank()) " — $error" else ""
    }

    private fun formatLive(r: SourceHealthSnapshot): String =
        "${r.sourceName}: ${r.status}, HTTP ${r.httpCode}, ${r.parsedCount} skor" +
            (r.errorMessage?.substringBefore('\n')?.take(100)?.let { " — $it" } ?: "")

    private fun fixFocus(
        parser: List<ParserHealthReport>,
        merge: List<UnmatchedDiagnosticItem>,
        drops: List<DropReason>
    ): String = when {
        parser.any { it.status == ParserStatus.DOM_CHANGED } -> "önce DOM/parser"
        parser.any { it.status == ParserStatus.FAILED } -> "önce kaynak/HTTP/parser"
        merge.any { it.probableReason == UnmatchedReason.NAME_MISMATCH || it.probableReason == UnmatchedReason.ALIAS_STEMMING_PROBLEM } -> "önce alias/team identity"
        merge.any { it.probableReason == UnmatchedReason.DATE_MISMATCH || it.probableReason == UnmatchedReason.TIME_MISMATCH } -> "önce schedule metadata"
        merge.isNotEmpty() -> "önce fixture matcher"
        drops.isNotEmpty() -> "önce pipeline drop nedeni"
        else -> "yok"
    }

    private fun severity(status: ParserStatus): Int = when (status) {
        ParserStatus.DOM_CHANGED -> 0
        ParserStatus.FAILED -> 1
        ParserStatus.DEGRADED -> 2
        ParserStatus.HEALTHY -> 3
    }

    private fun reasonSeverity(reason: UnmatchedReason): Int = when (reason) {
        UnmatchedReason.DATE_MISMATCH, UnmatchedReason.TIME_MISMATCH -> 0
        UnmatchedReason.NAME_MISMATCH, UnmatchedReason.ALIAS_STEMMING_PROBLEM -> 1
        UnmatchedReason.COMPETITION_MISMATCH, UnmatchedReason.AMBIGUOUS_OFFICIAL_CANDIDATE -> 2
        else -> 3
    }

    private fun reasonLabel(reason: UnmatchedReason): String = when (reason) {
        UnmatchedReason.OFFICIAL_BULLETIN_ABSENT -> "BÜLTEN YOK"
        UnmatchedReason.NO_OFFICIAL_CANDIDATE -> "ADAY YOK"
        UnmatchedReason.NAME_MISMATCH -> "İSİM"
        UnmatchedReason.DATE_MISMATCH -> "TARİH"
        UnmatchedReason.TIME_MISMATCH -> "SAAT"
        UnmatchedReason.COMPETITION_MISMATCH -> "LİG"
        UnmatchedReason.AMBIGUOUS_OFFICIAL_CANDIDATE -> "BELİRSİZ"
        UnmatchedReason.METADATA_MISSING -> "METADATA"
        UnmatchedReason.ALIAS_STEMMING_PROBLEM -> "ALIAS"
    }
}
