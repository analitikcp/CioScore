package com.cio.skor.data

/** Parses a 1X2 odds query and matches exact/nearby decimal odds. */
object OddsSearchMatcher {
    data class Query(val ms1: Double, val msX: Double, val ms2: Double)

    data class MatchResult(
        val exact: Boolean,
        val distance: Double
    )

    private val NUMBER = Regex("\\d+(?:[.,]\\d+)?")

    fun parse(text: String): Query? {
        val normalized = text.trim().replace(',', '.')
        val numbers = NUMBER.findAll(normalized).mapNotNull { it.value.toDoubleOrNull() }.toList()
        if (numbers.size != 3) return null
        if (numbers.any { it <= 1.0 || it > 1000.0 }) return null
        return Query(numbers[0], numbers[1], numbers[2])
    }

    fun compare(query: Query, ms1: Double, msX: Double, ms2: Double): MatchResult? {
        if (ms1 <= 1.0 || msX <= 1.0 || ms2 <= 1.0) return null
        val diffs = listOf(
            kotlin.math.abs(query.ms1 - ms1),
            kotlin.math.abs(query.msX - msX),
            kotlin.math.abs(query.ms2 - ms2)
        )
        val tolerances = listOf(query.ms1, query.msX, query.ms2).map { maxOf(0.05, it * 0.02) }
        if (diffs.zip(tolerances).any { (diff, tolerance) -> diff > tolerance }) return null
        val exact = diffs.all { it < 0.005 }
        return MatchResult(exact = exact, distance = diffs.sum())
    }
}
