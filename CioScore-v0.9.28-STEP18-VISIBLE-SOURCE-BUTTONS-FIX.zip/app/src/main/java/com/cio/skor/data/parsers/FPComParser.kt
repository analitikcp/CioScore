package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceTimeZone
import com.cio.skor.data.MatchMerger
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

/** FP.com Correct Score parser. */
class FPComParser : BaseParser("FP.com", SourceTimeZone.EUROPE_LONDON) {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (row in doc.select("table tr")) {
            val cells = row.select("th, td")
            if (cells.size < 2) continue

            val score = extractScore(cells[1]) ?: continue
            val teams = extractTeams(cells[0]) ?: continue

            val home = cleanTeamName(teams.first)
            val away = cleanTeamName(teams.second)
            if (!isRealTeam(home) || !isRealTeam(away)) continue

            val href = cells[0].select("a[href]").firstOrNull()?.attr("href") ?: ""
            val sourceMatchId = if (href.isBlank()) "" else stableHrefId(href)
            val raw = extractFixtureMetadata(row)
            val pageDate = extractPageDate(doc)
            val metadata = mergeMetadata(
                date = raw.matchDate.ifBlank { pageDate },
                time = raw.matchTime,
                competition = raw.competitionName.ifBlank { extractNearestCompetition(row) },
                competitionCountry = raw.competitionCountry,
                rawDateTime = raw.rawDateTime
            )
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchTimestamp = metadata.matchTimestamp,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName,
                competitionCountry = metadata.competitionCountry
            )
            val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else model.matchKey
            out[key] = model
        }
        // FP.com changed its public betting-tips markup in 2026: the same
        // correct-score data is now also exposed as labelled text rather than
        // only as the old two-column table. Keep the table parser above, but
        // recover from the current page structure when it yields nothing.
        if (out.isEmpty()) {
            parseCurrentTipsPage(doc, out)
        }

        return out.values.toList()
    }

    private fun parseCurrentTipsPage(doc: Document, out: LinkedHashMap<String, ScoreModel>) {
        val scorePattern = Regex("""(?i)\bCorrect\s+Score(?:\s+Tip)?\s*[:：]?\s*([0-5])\s*[-:]\s*([0-5])\b""")
        val markers = doc.getElementsContainingText("Correct Score")
            .filter { scorePattern.containsMatchIn(it.text()) }
            .sortedBy { it.text().length }

        for (marker in markers) {
            val scoreMatch = scorePattern.find(marker.text()) ?: continue
            val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
            var node: Element? = marker
            var teams: Pair<String, String>? = null
            var fixtureNode: Element? = null
            repeat(8) {
                node = node?.parent() ?: return@repeat
                val candidate = node ?: return@repeat
                val text = candidate.text().replace('\u00A0', ' ').replace(Regex("""\s+"""), " ").trim()
                if (text.length > 3000) return@repeat

                val anchors = candidate.select("a[href]")
                for (a in anchors) {
                    val visible = a.text().replace('\u00A0', ' ').replace(Regex("""\s+"""), " ").trim()
                    val pair = splitVisible(visible)
                        ?: splitSlug(a.attr("href").substringBefore('?').trimEnd('/').substringAfterLast('/').lowercase())
                    if (pair != null) {
                        teams = pair
                        fixtureNode = candidate
                        break
                    }
                }
                if (teams == null) {
                    val pair = splitVisibleFromContainer(text)
                    if (pair != null) {
                        teams = pair
                        fixtureNode = candidate
                    }
                }
                if (teams != null) return@repeat
            }

            val pair = teams ?: continue
            val home = cleanTeamName(pair.first)
            val away = cleanTeamName(pair.second)
            if (!isRealTeam(home) || !isRealTeam(away)) continue
            val container = fixtureNode ?: marker
            val href = container.select("a[href]").firstOrNull { it.attr("href").contains("/") }?.attr("href").orEmpty()
            val sourceMatchId = stableHrefId(href)
            val raw = extractFixtureMetadata(container)
            val metadata = mergeMetadata(
                date = raw.matchDate.ifBlank { extractPageDate(doc) },
                time = raw.matchTime,
                competition = raw.competitionName.ifBlank { extractNearestCompetition(container) },
                competitionCountry = raw.competitionCountry,
                rawDateTime = raw.rawDateTime
            )
            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchTimestamp = metadata.matchTimestamp,
                matchDate = metadata.matchDate,
                matchTime = metadata.matchTime,
                competitionName = metadata.competitionName,
                competitionCountry = metadata.competitionCountry
            )
            val key = if (sourceMatchId.isNotBlank()) "ID|$sourceMatchId" else "${home.lowercase()}|${away.lowercase()}|$score"
            out.putIfAbsent(key, model)
        }
    }

    private fun splitVisibleFromContainer(text: String): Pair<String, String>? {
        val cleaned = text.replace('\u00A0', ' ').replace(Regex("""\s+"""), " ").trim()
        val match = Regex("""(?i)([A-Za-z0-9À-ÿ][A-Za-z0-9À-ÿ .&'’()/-]{1,70}?)\s+(?:v|vs|versus)\s+([A-Za-z0-9À-ÿ][A-Za-z0-9À-ÿ .&'’()/-]{1,70}?)(?:\s+[0-9]{1,2}[:.][0-9]{2}|\s+Correct\s+Score|$)""").find(cleaned)
            ?: return null
        val home = cleanTeamName(match.groupValues[1])
        val away = cleanTeamName(match.groupValues[2])
        return if (isRealTeam(home) && isRealTeam(away)) home to away else null
    }

    private fun extractScore(cell: Element): String? {
        val text = cell.text().replace('\u00A0', ' ').trim()
        val m = Regex("""^\s*([0-5])\s*[-:]\s*([0-5])\s*$""").matchEntire(text)
            ?: Regex("""\b([0-5])\s*[-:]\s*([0-5])\b""").find(text)
            ?: return null
        return "${m.groupValues[1]}-${m.groupValues[2]}"
    }

    private fun extractTeams(cell: Element): Pair<String, String>? {
        // FP.com currently renders the match as one link containing both teams
        // plus date/time. The link URL contains the fixture slug, which is the
        // safest way to split the two team names.
        val link = cell.select("a[href]").firstOrNull()
        if (link != null) {
            val href = URLDecoder.decode(link.attr("href"), StandardCharsets.UTF_8.name())
            val slug = href.substringBefore('?').substringBefore('#').trimEnd('/')
                .substringAfterLast('/')
                .lowercase()

            val pair = splitSlug(slug)
            if (pair != null) return pair

            // Some versions use the visible text with an explicit v/vs separator.
            val visible = stripDate(link.text())
            val visiblePair = splitVisible(visible)
            if (visiblePair != null) return visiblePair
        }

        // Fallback: any explicit home/away elements.
        val home = firstText(cell, ".home-team", ".homeTeam", ".team-home", "[class*=home-team]")
        val away = firstText(cell, ".away-team", ".awayTeam", ".team-away", "[class*=away-team]")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        return splitVisible(stripDate(cell.text()))
    }

    private fun splitSlug(slug: String): Pair<String, String>? {
        val cleaned = slug
            .replace(Regex("""-(?:prediction|tips?|correct-score|odds).*$"""), "")

        val markers = listOf("-vs-", "-v-", "-versus-")
        for (marker in markers) {
            val idx = cleaned.indexOf(marker)
            if (idx > 0) {
                val home = slugWords(cleaned.substring(0, idx))
                val away = slugWords(cleaned.substring(idx + marker.length))
                if (isRealTeam(home) && isRealTeam(away)) return home to away
            }
        }
        return null
    }

    private fun splitVisible(text: String): Pair<String, String>? {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        val m = Regex("""(?i)^(.+?)\s+(?:v|vs|versus)\s+(.+)$""").find(cleaned)
            ?: return null
        val home = m.groupValues[1].trim()
        val away = m.groupValues[2].trim()
        if (isRealTeam(home) && isRealTeam(away)) return home to away
        return null
    }

    private fun stripDate(text: String): String {
        return text
            .replace(Regex("""\b[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}\b.*$"""), "")
            .replace(Regex("""\b[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}\b.*$"""), "")
            .trim()
    }

    private fun slugWords(value: String): String {
        return value.replace('-', ' ')
            .replace(Regex("""\s+"""), " ")
            .trim()
            .split(' ')
            .joinToString(" ") { word ->
                if (word.isBlank()) word else word.replaceFirstChar { it.uppercase() }
            }
    }

    private fun firstText(element: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = element.select(selector).firstOrNull()?.text()?.let(::cleanTeamName)
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun stableHrefId(href: String): String =
        URLDecoder.decode(href.trim(), StandardCharsets.UTF_8.name())
            .substringBefore('?')
            .substringBefore('#')
            .trim()
            .trimEnd('/')

    private fun cleanTeamName(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("""\s+"""), " ")
        .replace(Regex("""(?i)\b(correct\s*score|odds|probability|prediction|tip)\b.*$"""), "")
        .trim(' ', '-', '–', '—', ':', '|')

    private fun isRealTeam(value: String): Boolean {
        val v = cleanTeamName(value)
        if (v.length !in 2..70) return false
        if (v.matches(Regex("""^[0-9 .:/-]+$"""))) return false
        if (v.contains(Regex("""(?i)correct\s*score|probability|odds|prediction|betting tips|read more"""))) return false
        return true
    }
}
