package com.cio.skor

import kotlin.math.roundToInt
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.util.Log
import android.widget.Toast
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.MatchSessionStore
import com.cio.skor.data.GlobalFixtureMatcher
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.TeamAliasCanonicalizer
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.ObservabilityBus
import com.cio.skor.data.ScanTrace
import com.cio.skor.data.SourceHealthMonitor
import com.cio.skor.data.DiagnosticReportBuilder
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter

class MainActivity : Activity() {
    companion object {
        private const val CIO_PANEL_URL = "https://www.atlantikiddaa.com/panel"
        private const val IDDAA_BULLETIN_URL = "https://www.iddaa.com/program/futbol?msg=1"
        const val TARGET_MATCH_QUERY = "TARGET_MATCH_QUERY"
        const val EXTRA_TARGET_HOME = "TARGET_MATCH_HOME"
        const val EXTRA_TARGET_AWAY = "TARGET_MATCH_AWAY"
        const val EXTRA_TARGET_TIMESTAMP = "TARGET_MATCH_TIMESTAMP"
        private const val REQUEST_HTFT = 2101
    }
    private val repo = ScraperRepository()
    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanStatus: TextView
    private lateinit var recyclerView: RecyclerView
    private var pendingTargetHome: String? = null
    private var pendingTargetAway: String? = null
    private var allGroups: List<MatchGroup> = emptyList()
    private lateinit var oddsCoordinator: MainActivityOddsCoordinator
    private lateinit var scanCoordinator: MainActivityScanCoordinator
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanStatus = findViewById(R.id.tvScanStatus)

        recyclerView = findViewById(R.id.recyclerScores)
        val bottomSystemSpacer = findViewById<View>(R.id.bottomSystemSpacer)

        // STRONG BOTTOM-SAFE-AREA FIX
        // Android 15+/targetSdk 36 uses edge-to-edge. The navigation surface may
        // be transparent, so merely padding the RecyclerView can still leave the
        // final card visually underneath the system buttons. We reserve a real
        // layout area AFTER the RecyclerView. That area is never occupied by a
        // match card, so the last card can always be scrolled completely above
        // the navigation bar. Keep the RecyclerView padding as a secondary
        // safeguard for gesture-navigation devices.
        val baseRecyclerBottomPadding = recyclerView.paddingBottom
        val minimumBottomSafeArea = dp(24)
        ViewCompat.setOnApplyWindowInsetsListener(recyclerView) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                baseRecyclerBottomPadding + dp(16)
            )
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomSystemSpacer) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            val safeHeight = maxOf(minimumBottomSafeArea, navigationBottom + dp(24))
            view.layoutParams = view.layoutParams.apply { height = safeHeight }
            view.requestLayout()
            insets
        }
        ViewCompat.requestApplyInsets(recyclerView)
        ViewCompat.requestApplyInsets(bottomSystemSpacer)

        recyclerView.layoutManager = LinearLayoutManager(this)
        // 94+ official fixtures are valid. Disable change animations and keep
        // RecyclerView work predictable so a large bulletin cannot stall the UI.
        recyclerView.setHasFixedSize(false)
        recyclerView.itemAnimator = null
        recyclerView.setItemViewCacheSize(4)
        adapter = ScoreAdapter(
            this,
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                }, REQUEST_HTFT)
            },
            onExternalOddsRequest = { match -> oddsCoordinator.enqueueOdds(match) },
            onCioAiClick = { match, books ->
                val scoreRows = match.predictions
                    .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                    .map { "${it.source}|${it.predictedScore}" }
                val bookRows = books.map { "${it.bookmaker}|${it.ms1}|${it.msX}|${it.ms2}" }
                startActivity(Intent(this, CioAiActivity::class.java).apply {
                    putExtra(CioAiActivity.EXTRA_HOME, match.homeTeam)
                    putExtra(CioAiActivity.EXTRA_AWAY, match.awayTeam)
                    putExtra(CioAiActivity.EXTRA_1, match.iddaaMs1)
                    putExtra(CioAiActivity.EXTRA_X, match.iddaaMsX)
                    putExtra(CioAiActivity.EXTRA_2, match.iddaaMs2)
                    putStringArrayListExtra(CioAiActivity.EXTRA_SCORES, ArrayList(scoreRows))
                    putStringArrayListExtra(CioAiActivity.EXTRA_BOOKS, ArrayList(bookRows))
                })
            }
        )
        recyclerView.adapter = adapter

        oddsCoordinator = MainActivityOddsCoordinator(this, adapter)
        scanCoordinator = MainActivityScanCoordinator(
            host = this,
            repo = repo,
            iddaaMarkets = com.cio.skor.data.IddaaMarketService(),
            adapter = adapter,
            recyclerView = recyclerView,
            buildPredictionFirstGroups = ::buildPredictionFirstGroups,
            coalesceDisplayGroups = ::coalesceDisplayGroups,
            isDisplayable = ::isDisplayable,
            onOddsBatch = oddsCoordinator::enqueueOddsBatch,
            onBet365Preload = oddsCoordinator::preloadBet365,
            onGroupsReady = { groups -> allGroups = groups },
            onFocusPendingMatch = ::focusPendingMatch,
            onScanningChanged = ::setScanningUi,
            onStatus = { status -> scanStatus.text = status }
        )

        searchInput = findViewById(R.id.etSearch)
        handleMatchSelection(intent)
        scanButton.setOnClickListener { scanCoordinator.scan() }

        findViewById<TextView>(R.id.btnHome).setOnClickListener {
            adapter.setFavoritesOnly(false)
            updateBottomNav(true)
        }
        findViewById<TextView>(R.id.btnFavorites).setOnClickListener {
            adapter.setFavoritesOnly(true)
            updateBottomNav(false)
            if (adapter.favoriteCount() == 0) {
                Toast.makeText(this, "Henüz favori maç eklemedin. Karttaki ★ simgesine bas.", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<TextView>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivityForResult(Intent(this, HtFtOpenedMatchesActivity::class.java), REQUEST_HTFT)
        }
        findViewById<TextView>(R.id.btnXCandidates).setOnClickListener {
            if (allGroups.isEmpty()) {
                Toast.makeText(this, "Önce bugünün taramasını yap.", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(this, XCandidateActivity::class.java))
            }
        }
        findViewById<TextView>(R.id.btnMore).setOnClickListener { showMoreMenu() }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun updateBottomNav(homeSelected: Boolean) {
        val home = findViewById<TextView>(R.id.btnHome)
        val fav = findViewById<TextView>(R.id.btnFavorites)
        home.setTextColor(if (homeSelected) 0xFF22D3EE.toInt() else 0xFFE5E7EB.toInt())
        fav.setTextColor(if (!homeSelected) 0xFFFFC107.toInt() else 0xFFE5E7EB.toInt())
    }

    private fun showMoreMenu() {
        val dialog = BottomSheetDialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(20))
            setBackgroundColor(0xFFF8FAFC.toInt())
        }
        val title = TextView(this).apply {
            text = "☰  Daha Fazla"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF102A43.toInt())
            setPadding(0, 0, 0, dp(10))
        }
        container.addView(title)
        fun action(text: String, click: () -> Unit) {
            val item = TextView(this).apply {
                this.text = text
                textSize = 16f
                setTextColor(0xFF243B53.toInt())
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(14), dp(12), dp(14))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(12).toFloat()
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
                ).apply { bottomMargin = dp(8) }
                setOnClickListener { click(); dialog.dismiss() }
            }
            container.addView(item)
        }
        action("🔍  Teşhis", ::showDiagnostics)
        action("📋  İddaa Bülteni", {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(IDDAA_BULLETIN_URL))) }
                .onFailure { Toast.makeText(this, "İddaa bülteni açılamadı.", Toast.LENGTH_SHORT).show() }
        })
        action("🌐  Cio Panel", {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(CIO_PANEL_URL))) }
                .onFailure { Toast.makeText(this, "Cio Panel açılamadı.", Toast.LENGTH_SHORT).show() }
        })
        dialog.setContentView(container)
        dialog.show()
    }

    /** Prediction-first UI grouping. Iddaa is enrichment only and never a gate. */
    private fun buildPredictionFirstGroups(
        predictions: List<ScoreModel>,
        officialMatches: List<com.cio.skor.data.IddaaMarketService.OpenedMarketMatch>
    ): List<MatchGroup> {
        // IMPORTANT: never regroup predictions with a simple home||away key here.
        // That bypassed GlobalFixtureMatcher and caused multilingual names or
        // damaged home names to split an otherwise identical fixture into cards.
        // The matcher is now the single source of truth for provider clustering.
        val unified = GlobalFixtureMatcher.merge(predictions, officialMatches)

        // GlobalFixtureMatcher already carries the best official anchor on each
        // unified component. Do not run a second full prediction × official scan
        // here: that duplicated the identity engine and could select a different
        // official fixture from the one used to form the component.


        // CRITICAL INVARIANT: Iddaa is enrichment only. Provider predictions
        // always create a card, while a successfully matched Iddaa fixture only
        // enriches that card with official names/odds/bulletin state.
        val predictionById = predictions
            .filter { it.predictionId.isNotBlank() }
            .associateBy { it.predictionId }
        return unified.mapNotNull { match ->
            // Identity lookup is preferred, but it must never become a data-loss gate.
            // GlobalFixtureMatcher already carries the exact Record selected for the
            // unified component. If a predictionId was lost during an intermediate
            // copy, render that Record directly instead of dropping a real score.
            // This preserves the matcher decision without doing any second fuzzy lookup.
            val cardPredictions = match.predictionRecords
                .mapNotNull { record ->
                    val resolved = predictionById[record.predictionId]
                    if (resolved != null) {
                        resolved
                    } else if (ScoreModel.hasRenderablePrediction(record.predictedScore)) {
                        Log.d(
                            "MainActivity",
                            "PREDICTION_CHAIN_FALLBACK fixture=${match.fixtureId} " +
                                "source=${record.source} predictionId=${record.predictionId}"
                        )
                        ScoreModel(
                            homeTeam = record.homeTeam,
                            awayTeam = record.awayTeam,
                            predictedScore = record.predictedScore.orEmpty(),
                            source = record.source,
                            sourceMatchId = record.sourceMatchId,
                            matchTimestamp = record.matchTimestamp,
                            matchDate = record.matchDate,
                            matchTime = record.matchTime,
                            competitionName = record.competitionName,
                            competitionCountry = record.competitionCountry,
                            predictionId = record.predictionId
                        )
                    } else {
                        null
                    }
                }
                .filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                .distinctBy { it.source.trim().lowercase() }
            if (cardPredictions.isEmpty()) return@mapNotNull null

            val primary = cardPredictions.first()
            val official = match.officialMatch
            MatchGroup(
                isIddaaBulletinMatch = official != null,
                homeTeam = official?.homeTeam ?: match.mainHomeTeam.ifBlank { primary.homeTeam },
                awayTeam = official?.awayTeam ?: match.mainAwayTeam.ifBlank { primary.awayTeam },
                predictions = cardPredictions,
                iddaaProgramUrl = official?.let { buildIddaaProgramUrl(it.matchDate) },
                iddaaMs1 = official?.ms1, iddaaMsX = official?.msX, iddaaMs2 = official?.ms2,
                htFtOdds = official?.htFtOdds ?: linkedMapOf(),
                hasHtFt = official?.hasHtFt ?: false,
                matchTimestamp = official?.matchTimestamp?.takeIf { it > 0L }
                    ?: match.predictionRecords.maxOfOrNull { it.matchTimestamp }?.takeIf { it > 0L }
                    ?: primary.matchTimestamp,
                displayTime = official?.matchTime?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchTime.isNotBlank() && it.matchTime != "--:--" }?.matchTime
                    ?: primary.matchTime,
                displayDate = official?.matchDate?.takeIf { it.isNotBlank() }
                    ?: match.predictionRecords.firstOrNull { it.matchDate.isNotBlank() }?.matchDate
                    ?: primary.matchDate,
                homeTeamId = null, awayTeamId = null,
                fixtureId = match.fixtureId
            )
        }.sortedWith(
            compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                .thenBy { it.homeTeam.lowercase() }
                .thenBy { it.awayTeam.lowercase() }
        )
    }

    /** Final UI grouping by the fixture identity already produced by GlobalFixtureMatcher. */
    private fun coalesceDisplayGroups(groups: List<MatchGroup>): List<MatchGroup> {
        if (groups.size < 2) return groups

        val merged = LinkedHashMap<String, MatchGroup>()

        for (incoming in groups) {
            // No second fixture matcher here. A group is merged only when the
            // authoritative matcher already assigned the exact same fixtureId.
            val key = incoming.fixtureId.ifBlank {
                // Records without a fixtureId are intentionally kept isolated;
                // deriving a new identity here would recreate the old bug.
                "UNIDENTIFIED:${System.identityHashCode(incoming)}"
            }
            val existing = merged[key]
            if (existing == null) {
                merged[key] = incoming
                continue
            }

            val bySource = LinkedHashMap<String, MutableList<ScoreModel>>()
            fun addPredictions(list: List<ScoreModel>) {
                list.filter { ScoreModel.hasRenderablePrediction(it.predictedScore) }
                    .forEach { prediction ->
                        bySource.getOrPut(prediction.source.trim().lowercase()) { mutableListOf() }
                            .add(prediction)
                    }
            }
            addPredictions(existing.predictions)
            addPredictions(incoming.predictions)

            val resolvedPredictions = LinkedHashMap<String, ScoreModel>()
            bySource.forEach { (sourceKey, candidates) ->
                val distinctScores = candidates.map { it.predictedScore.trim() }.distinct()
                if (distinctScores.size == 1) {
                    resolvedPredictions[sourceKey] = candidates.first()
                } else {
                    // Same fixture + same source + different scores is diagnostic
                    // metadata, not a UI gate. Keep one deterministic candidate so
                    // a provider conflict cannot erase that source's prediction.
                    Log.d("MainActivity",
                        "SOURCE_CONFLICT fixture=${incoming.fixtureId} source=$sourceKey scores=$distinctScores")
                    val selected = candidates.maxWithOrNull(
                        compareBy<ScoreModel> {
                            if (ScoreModel.hasRenderablePrediction(it.predictedScore)) 1 else 0
                        }
                            .thenBy { it.predictedScore.orEmpty() }
                            .thenBy { it.predictionId.orEmpty() }
                    )
                    if (selected != null) resolvedPredictions[sourceKey] = selected
                }
            }

            // Official metadata wins when both records represent the same exact
            // fixture. Because the key already contains the resolved kickoff minute,
            // no max()/min() timestamp heuristic is needed here.
            val preferred = if (incoming.isIddaaBulletinMatch && !existing.isIddaaBulletinMatch) {
                incoming
            } else {
                existing
            }
            val preferredTimestamp = when {
                preferred.isIddaaBulletinMatch && preferred.matchTimestamp > 0L -> preferred.matchTimestamp
                existing.isIddaaBulletinMatch && existing.matchTimestamp > 0L -> existing.matchTimestamp
                incoming.isIddaaBulletinMatch && incoming.matchTimestamp > 0L -> incoming.matchTimestamp
                else -> preferred.matchTimestamp.takeIf { it > 0L }
                    ?: existing.matchTimestamp.takeIf { it > 0L }
                    ?: incoming.matchTimestamp
            }

            merged[key] = preferred.copy(
                isIddaaBulletinMatch = existing.isIddaaBulletinMatch || incoming.isIddaaBulletinMatch,
                predictions = resolvedPredictions.values.toList(),
                iddaaMs1 = preferred.iddaaMs1 ?: existing.iddaaMs1 ?: incoming.iddaaMs1,
                iddaaMsX = preferred.iddaaMsX ?: existing.iddaaMsX ?: incoming.iddaaMsX,
                iddaaMs2 = preferred.iddaaMs2 ?: existing.iddaaMs2 ?: incoming.iddaaMs2,
                htFtOdds = if (preferred.htFtOdds.isNotEmpty()) preferred.htFtOdds
                    else existing.htFtOdds.ifEmpty { incoming.htFtOdds },
                hasHtFt = existing.hasHtFt || incoming.hasHtFt,
                iddaaProgramUrl = preferred.iddaaProgramUrl ?: existing.iddaaProgramUrl ?: incoming.iddaaProgramUrl,
                matchTimestamp = preferredTimestamp,
                displayTime = preferred.displayTime.ifBlank { existing.displayTime.ifBlank { incoming.displayTime } },
                displayDate = preferred.displayDate.ifBlank { existing.displayDate.ifBlank { incoming.displayDate } },
                fixtureId = preferred.fixtureId.ifBlank { existing.fixtureId.ifBlank { incoming.fixtureId } }
            )
        }

        return merged.values.toList()
    }

    @Deprecated("Use Activity Result APIs when migrating the app to ComponentActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_HTFT && resultCode == RESULT_OK && data != null) {
            handleMatchSelection(data)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMatchSelection(intent)
    }

    private fun handleMatchSelection(intent: Intent?) {
        val home = intent?.getStringExtra(EXTRA_TARGET_HOME)
            ?: intent?.getStringExtra(TARGET_MATCH_QUERY)
        val away = intent?.getStringExtra(EXTRA_TARGET_AWAY)

        if (!home.isNullOrBlank()) {
            pendingTargetHome = home
            pendingTargetAway = away
            searchInput.setText(home)
            if (allGroups.isNotEmpty()) {
                focusPendingMatch()
            }
        }
    }

    private fun focusPendingMatch() {
        val home = pendingTargetHome ?: return
        val away = pendingTargetAway
        adapter.focusOnMatch(home, away)
        recyclerView.post {
            if (adapter.itemCount > 0) recyclerView.scrollToPosition(0)
        }
    }

    private fun dp(value: Int): Int =
        android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()


    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun diagnosticReportText(trace: ScanTrace): String =
        DiagnosticReportBuilder.build(trace, SourceHealthMonitor.state.value)

    private fun showDiagnostics() {
        val trace = ObservabilityBus.lastTrace.value
        if (trace == null) {
            Toast.makeText(this, "Henüz tamamlanmış bir tarama teşhisi yok.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 24)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SCAN DIAGNOSTIC PANEL"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val copyButton = Button(this).apply {
            text = "📋 KOPYALA"
            textSize = 11f
            setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("CioScore Scan Diagnostic", diagnosticReportText(trace)))
                Toast.makeText(this@MainActivity, "Teşhis raporu panoya kopyalandı.", Toast.LENGTH_SHORT).show()
            }
        }
        header.addView(title)
        header.addView(copyButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(header)

        val reportView = TextView(this).apply {
            text = diagnosticReportText(trace)
            textSize = 13f
            setPadding(0, 16, 0, 12)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply {
            addView(reportView)
        }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        dialog.setContentView(root)
        dialog.show()
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARA…" else "TARA"
        if (active) scanStatus.text = "${repo.sourceCount} kaynak taranıyor…"
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!ScoreModel.hasRenderablePrediction(x.predictedScore)) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    private fun buildIddaaProgramUrl(matchDate: String): String {
        val encodedDate = java.net.URLEncoder.encode(matchDate, "UTF-8")
        return "https://www.iddaa.com/program/futbol?date=$encodedDate"
    }

    override fun onDestroy() {
        if (::scanCoordinator.isInitialized) scanCoordinator.cancel()
        if (::oddsCoordinator.isInitialized) oddsCoordinator.cancel()
        super.onDestroy()
    }
}
