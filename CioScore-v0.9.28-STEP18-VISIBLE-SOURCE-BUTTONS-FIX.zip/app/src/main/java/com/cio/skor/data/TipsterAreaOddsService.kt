package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * TipsterArea -> bookmaker odds provider.
 *
 * Priority for bwin is intentionally:
 *   1) TipsterArea
 *   2) other providers in MainActivity (SofaScore / OddsSafari / direct bwin API)
 *
 * This class is deliberately self-contained.  There is no teamSimilarity()
 * dependency and no local/nested helper function, which keeps this file safe
 * for the Kotlin compiler configuration used by the project.
 */
class TipsterAreaOddsService {

    data class Odds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    private val http = HttpClient()

    private val wantedBookmakers = linkedMapOf(
        "1xbet" to "1xBet",
        "bet-at-home" to "bet-at-home",
        "betfair" to "Betfair",
        "bwin" to "bwin",
        "unibet" to "Unibet"
    )

    private val blockedBookmakerKeys = setOf("bet365", "bet 365")

    private data class CacheEntry(val expiresAt: Long, val value: List<Odds>)

    private val oddsCache = ConcurrentHashMap<String, CacheEntry>()
    private val urlCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val indexCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val indexMutex = Mutex()

    private val oddsCacheTtlMs = 5 * 60 * 1000L
    private val indexCacheTtlMs = 2 * 60 * 1000L
    private val urlCacheTtlMs = 10 * 60 * 1000L

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        matchDate: String = ""
    ): List<Odds> {
        val key = SourceCacheIdentity.fixture("TipsterArea", homeTeam, awayTeam, matchDate)
        val now = System.currentTimeMillis()
        val cached = oddsCache[key]
        if (cached != null && cached.expiresAt > now) {
            return cached.value
        }

        val detailUrl = discoverMatchUrl(homeTeam, awayTeam, matchDate)
        if (detailUrl.isNullOrBlank()) {
            Log.w(TAG, "MATCH MISS home=$homeTeam away=$awayTeam date=$matchDate")
            return emptyList()
        }

        val response = fetchHtml(detailUrl)
        val code = response.first
        val html = response.second
        if (code !in 200..299 || html.isNullOrBlank()) {
            Log.w(TAG, "DETAIL MISS code=$code url=$detailUrl")
            return emptyList()
        }

        val parsed = parseOdds(html)
        val bwin = parsed.firstOrNull { it.bookmaker.equals("bwin", ignoreCase = true) }

        Log.d(
            TAG,
            "DETAIL HIT home=$homeTeam away=$awayTeam " +
                "bwin=${bwin?.ms1 ?: "-"}/${bwin?.msX ?: "-"}/${bwin?.ms2 ?: "-"} " +
                "rows=${parsed.size}"
        )

        if (parsed.isNotEmpty()) {
            oddsCache[key] = CacheEntry(now + oddsCacheTtlMs, parsed)
        }

        return parsed
    }

    private suspend fun discoverMatchUrl(
        homeTeam: String,
        awayTeam: String,
        matchDate: String
    ): String? {
        val homeVariants = normalizedTeamVariants(homeTeam)
        val awayVariants = normalizedTeamVariants(awayTeam)
        if (homeVariants.isEmpty() || awayVariants.isEmpty()) return null

        for (date in candidateDates(matchDate)) {
            val dateKey = date.toString()
            val cacheKey = SourceCacheIdentity.fixture(
                "TipsterArea-index",
                homeVariants.joinToString("_"),
                awayVariants.joinToString("_"),
                dateKey
            )

            val cached = urlCache[cacheKey]
            if (cached != null && cached.first > System.currentTimeMillis()) {
                return cached.second
            }

            val formattedDate = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
            val indexUrls = listOf(
                "https://tipsterarea.com/matches/date-$formattedDate",
                "https://tipsterarea.com/matches-hour/date-$formattedDate"
            )

            for (indexUrl in indexUrls) {
                val body = getCachedIndex(indexUrl) ?: continue
                val document = Jsoup.parse(body, "https://tipsterarea.com/")

                val links = document.select("a[href]")
                for (anchor in links) {
                    val href = absoluteMatchUrl(anchor)
                    if (href.isBlank()) continue
                    if (!href.contains("/match/", ignoreCase = true)) continue

                    val anchorText = normalize(anchor.text())
                    val hrefText = normalize(href)

                    val homeScore = bestSimilarity(anchorText, homeVariants)
                        .coerceAtLeast(bestSimilarity(hrefText, homeVariants))
                    val awayScore = bestSimilarity(anchorText, awayVariants)
                        .coerceAtLeast(bestSimilarity(hrefText, awayVariants))

                    if (homeScore >= MATCH_THRESHOLD && awayScore >= MATCH_THRESHOLD) {
                        urlCache[cacheKey] =
                            System.currentTimeMillis() + urlCacheTtlMs to href
                        Log.d(TAG, "MATCH HIT $homeTeam - $awayTeam -> $href")
                        return href
                    }
                }
            }
        }

        return null
    }

    private fun absoluteMatchUrl(anchor: Element): String {
        val absolute = anchor.absUrl("href").trim()
        if (absolute.isNotBlank()) return absolute

        val raw = anchor.attr("href").trim()
        if (raw.isBlank()) return ""
        if (raw.startsWith("http://") || raw.startsWith("https://")) return raw

        return "https://tipsterarea.com" +
            if (raw.startsWith("/")) raw else "/$raw"
    }

    private suspend fun getCachedIndex(url: String): String? {
        val now = System.currentTimeMillis()
        val cached = indexCache[url]
        if (cached != null && cached.first > now) return cached.second

        return indexMutex.withLock {
            val secondCheck = indexCache[url]
            if (secondCheck != null && secondCheck.first > System.currentTimeMillis()) {
                return@withLock secondCheck.second
            }

            val response = fetchHtml(url)
            val code = response.first
            val body = response.second

            if (code in 200..299 && !body.isNullOrBlank()) {
                indexCache[url] =
                    System.currentTimeMillis() + indexCacheTtlMs to body
                body
            } else {
                Log.w(TAG, "INDEX MISS code=$code url=$url")
                null
            }
        }
    }

    private suspend fun fetchHtml(url: String): Pair<Int, String?> {
        val primary = http.getSource(url, "https://tipsterarea.com/")
        if (primary.first in 200..299 && !primary.second.isNullOrBlank()) {
            return primary
        }

        val fallback = http.get(url, "https://tipsterarea.com/")
        return fallback
    }

    private fun parseOdds(html: String): List<Odds> {
        val document = Jsoup.parse(html, "https://tipsterarea.com/")
        val result = linkedMapOf<String, Odds>()

        // First pass: table rows. This is the normal TipsterArea layout.
        for (table in document.select("table")) {
            for (row in table.select("tr")) {
                addParsedRow(result, row)
            }
        }

        // Second pass: responsive/mobile layouts sometimes do not preserve the
        // bookmaker row inside a normal table. Scan generic row-like elements.
        if (!result.containsKey("bwin")) {
            val candidates = document.select("tr, li, .odds, .bookmaker, [class*=bookmaker]")
            for (element in candidates) {
                addParsedRow(result, element)
            }
        }

        // Never let TipsterArea become a Bet365 provider.
        return wantedBookmakers.keys.mapNotNull { result[it] }
    }

    private fun addParsedRow(result: MutableMap<String, Odds>, element: Element) {
        val bookmakerKey = bookmakerKeyFromElement(element) ?: return
        val numbers = extractOddsNumbers(element)
        if (numbers.size < 3) return

        val cleaned = numbers.mapNotNull(::cleanOdd)
        if (cleaned.size < 3) return

        val last = cleaned.lastIndex
        val odds = Odds(
            bookmaker = wantedBookmakers.getValue(bookmakerKey),
            ms1 = cleaned[last - 2],
            msX = cleaned[last - 1],
            ms2 = cleaned[last]
        )

        if (validOdds(odds) && !result.containsKey(bookmakerKey)) {
            result[bookmakerKey] = odds
        }
    }

    private fun bookmakerKeyFromElement(element: Element): String? {
        val altNames = element.select("img[alt]")
            .map { it.attr("alt").trim() }
            .filter { it.isNotBlank() }

        val labels = element.select("img[title], [title]")
            .map { it.attr("title").trim() }
            .filter { it.isNotBlank() }

        val source = buildString {
            append(element.text())
            if (altNames.isNotEmpty()) append(' ').append(altNames.joinToString(" "))
            if (labels.isNotEmpty()) append(' ').append(labels.joinToString(" "))
        }

        val normalized = normalize(source)
        if (normalized.isBlank()) return null

        if (blockedBookmakerKeys.any { blocked ->
                normalized.contains(normalize(blocked))
            }) {
            return null
        }

        return wantedBookmakers.keys.firstOrNull { key ->
            normalized.contains(normalize(key))
        }
    }

    private fun extractOddsNumbers(element: Element): List<String> {
        val cellText = element.select("td, th")
            .map { it.text().trim() }
            .filter { it.isNotBlank() }
            .joinToString(" ")

        val fromCells = ODDS_NUMBER.findAll(cellText)
            .map { it.value }
            .toList()

        if (fromCells.size >= 3) return fromCells

        return ODDS_NUMBER.findAll(element.text())
            .map { it.value }
            .toList()
    }

    private fun validOdds(odds: Odds): Boolean {
        return listOf(odds.ms1, odds.msX, odds.ms2).all { value ->
            val number = value.toDoubleOrNull()
            number != null && number > 1.0 && number <= 100.0
        }
    }

    private fun cleanOdd(raw: String): String? {
        val normalized = raw.replace(',', '.').trim()
        val number = normalized.toDoubleOrNull() ?: return null
        if (number <= 1.0 || number > 100.0) return null
        return String.format(Locale.US, "%.2f", number)
    }

    private fun bestSimilarity(haystackRaw: String, variants: List<String>): Double {
        val haystack = normalize(haystackRaw)
        if (haystack.isBlank() || variants.isEmpty()) return 0.0

        var best = 0.0
        for (rawVariant in variants) {
            val variant = normalize(rawVariant)
            if (variant.isBlank()) continue

            if (haystack == variant || haystack.contains(variant)) {
                best = maxOf(best, 1.0)
                continue
            }

            val tokens = variant.split(' ')
                .filter { it.length >= 3 }
                .distinct()

            if (tokens.isEmpty()) continue

            val hits = tokens.count { token -> haystack.contains(token) }
            val score = hits.toDouble() / tokens.size.toDouble()
            best = maxOf(best, score)
        }

        return best
    }

    private fun normalizedTeamVariants(value: String): List<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptyList()

        val stripped = base.split(' ')
            .filterNot { token -> token in GENERIC_TEAM_PREFIXES }
            .joinToString(" ")
            .trim()

        return listOf(base, stripped)
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun candidateDates(raw: String): List<LocalDate> {
        val base = parseDate(raw) ?: LocalDate.now(KickoffNormalizer.ZONE)
        return listOf(base, base.minusDays(1), base.plusDays(1)).distinct()
    }

    private fun parseDate(raw: String): LocalDate? {
        val value = raw.trim().take(10)
        if (value.isBlank()) return null

        val formats = listOf(
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
        )

        for (formatter in formats) {
            try {
                return LocalDate.parse(value, formatter)
            } catch (_: DateTimeParseException) {
                // Try the next supported format.
            }
        }
        return null
    }



    private fun normalize(value: String): String {
        return Normalizer.normalize(
            value.lowercase(Locale.US),
            Normalizer.Form.NFD
        )
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("https?://|www\\."), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
    }

    companion object {
        private const val TAG = "TipsterAreaOdds"
        private const val MATCH_THRESHOLD = 0.75

        private val ODDS_NUMBER = Regex(
            "(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])"
        )

        private val GENERIC_TEAM_PREFIXES = setOf(
            "fc", "cf", "cd", "sc", "ac", "afc", "fk", "sk", "club", "clube",
            "deportivo", "deportiva", "deportes", "football", "soccer", "nk"
        )
    }
}
