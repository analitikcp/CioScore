package com.cio.skor.data

/**
 * Centralized matcher thresholds and schedule windows.
 *
 * Keeping these values outside the public facade makes tuning safer and keeps
 * the identity engine focused on matching behavior rather than configuration.
 */
internal object GlobalFixtureMatcherConfig {
    const val TEAM_FUZZY_MIN = 0.72
    const val MATCH_FUZZY_MIN = 0.78
    const val AUTO_MERGE_CONFIDENCE = 0.84
    const val TIME_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    const val TIME_HARD_WINDOW_MS = 12L * 60L * 60L * 1000L
}
