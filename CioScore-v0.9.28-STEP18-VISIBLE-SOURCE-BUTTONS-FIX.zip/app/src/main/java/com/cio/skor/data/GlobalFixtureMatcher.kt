package com.cio.skor.data

import android.util.Log
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Production-oriented global fixture identity engine.
 *
 * Four identity layers are intentionally separated:
 * 1) TeamAliasCanonicalizer  -> stable source-independent team IDs
 * 2) Official Iddaa anchor   -> strongest fixture authority
 * 3) Union-Find clustering    -> global, non-greedy grouping
 * 4) Evidence/confidence      -> ID + date/time + team similarity validation
 *
 * Important invariant: a fuzzy pair can never create a cluster merely because
 * one side matches. Home AND away must agree. Official fixtures can relax the
 * name threshold only when the official record is the anchor and there is no
 * contradictory time information.
 */
object GlobalFixtureMatcher {

    const val BUILD_SIGNATURE = "CIO-REAL-GENERIC-V6.0-IDENTITY-CHAIN"

    const val CANONICAL_PIPELINE_VERSION = "v0.9.25-SOURCE-ONE-SIDE-SCHEDULE-V3-IDENTITY-CHAIN"

    // Hard gates: a fuzzy fixture must have credible evidence on BOTH sides.
    // The combined gate prevents two mediocre team similarities from becoming a match.
    private const val TEAM_FUZZY_MIN = 0.72
    private const val MATCH_FUZZY_MIN = 0.78
    private const val AUTO_MERGE_CONFIDENCE = 0.84

    // Kickoff mismatch is a hard rejection. Twelve hours is intentionally wide
    // enough for timezone/date-rollover differences, but still blocks unrelated
    // fixtures from becoming candidates.
    private const val TIME_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 12L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val competitionCountry: String = "",
        val official: IddaaMarketService.OpenedMarketMatch? = null,
        /** Exact provider prediction identity; never reconstructed by fuzzy lookup. */
        val predictionId: String = ""
    ) {
        // Identity is immutable for a record. Compute it once at construction
        // instead of normalizing the same provider name on every pair comparison.
        val homeIdentity: TeamAliasCanonicalizer.TeamIdentity =
            TeamAliasCanonicalizer.identityForProvider(source, competitionCountry, homeTeam)
        val awayIdentity: TeamAliasCanonicalizer.TeamIdentity =
            TeamAliasCanonicalizer.identityForProvider(source, competitionCountry, awayTeam)
        val homeCanonicalId: String get() = homeIdentity.canonicalId
        val awayCanonicalId: String get() = awayIdentity.canonicalId
        val fixtureKey: String get() = "$homeCanonicalId||$awayCanonicalId"
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        /**
         * The exact prediction records that produced [predictions].
         *
         * The UI must consume this identity-graph output instead of regrouping
         * raw predictions by canonical team key, otherwise two fixtures that
         * the matcher deliberately kept separate could be collapsed again.
         */
        val predictionRecords: MutableList<Record> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = "",
        var fixtureKey: String = "",
        /** One immutable fixture identity for the whole matcher component. */
        var fixtureId: String = "",
        /** Sources that emitted conflicting scores for this exact fixture. */
        val sourceConflicts: MutableSet<String> = linkedSetOf()
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val competitionScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean,
        val homeCanonicalA: String = "",
        val homeCanonicalB: String = "",
        val awayCanonicalA: String = "",
        val awayCanonicalB: String = ""
    )


    /** Metadata reconciliation is delegated to the isolated engine module. */
    fun reconcileMetadata(
        predictions: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<ScoreModel> = GlobalFixtureMatcherEngine.reconcileMetadata(predictions, officialMatches)

    /** Global identity merge facade. */
    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> = GlobalFixtureMatcherEngine.merge(scraped, officialMatches)

    /** Pairwise evidence facade retained for tests and diagnostics. */
    fun score(a: Record, b: Record): MatchEvidence = GlobalFixtureMatcherEngine.score(a, b)

    /** Official coverage diagnostics facade. */
    fun diagnoseOfficialCoverage(
        official: IddaaMarketService.OpenedMarketMatch,
        source: String,
        predictions: List<ScoreModel>
    ) = GlobalFixtureMatcherEngine.diagnoseOfficialCoverage(official, source, predictions)

    /** Official mismatch diagnostics facade. */
    fun diagnoseOfficialMismatch(
        prediction: ScoreModel,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ) = GlobalFixtureMatcherEngine.diagnoseOfficialMismatch(prediction, officialMatches)
}
