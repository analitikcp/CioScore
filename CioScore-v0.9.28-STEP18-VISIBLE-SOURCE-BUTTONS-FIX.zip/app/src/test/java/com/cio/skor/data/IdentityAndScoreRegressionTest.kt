package com.cio.skor.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityAndScoreRegressionTest {
    @Test fun teamAliasesResolveKnownVariants() {
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Man Utd") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("VfL Bochum", "Bochum") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("FSV Mainz 05", "Mainz") >= 0.80)
    }

    @Test fun seniorAndYouthTeamsDoNotCollapse() {
        assertFalse(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Manchester United U21") >= 0.95)
    }

    @Test fun renderableScoreContractRejectsTextualAndPartialValues() {
        assertTrue(ScoreModel.hasRenderablePrediction("1-0"))
        assertTrue(ScoreModel.hasRenderablePrediction(" 2 : 2 "))
        assertFalse(ScoreModel.hasRenderablePrediction("Home win"))
        assertFalse(ScoreModel.hasRenderablePrediction("1-"))
        assertFalse(ScoreModel.hasRenderablePrediction("TBD"))
    }
    @Test fun fourPredictionProvidersCollapseIntoOneFixtureWithFourPredictions() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", kickoff),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", kickoff),
            ScoreModel("Manchester United", "Liverpool FC", "2:0", "WinDrawWin", "wdw-1", kickoff),
            ScoreModel("Man United", "Liverpool", "1-0", "DailySports", "ds-1", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("All four prediction providers must form one fixture", unified.size == 1)
        assertTrue("The unified fixture must retain all four prediction sources", unified.single().predictions.size == 4)
        assertTrue(unified.single().predictions.map { it.first }.toSet().containsAll(
            setOf("FP.com", "PredictZ", "WinDrawWin", "DailySports")
        ))
    }


    @Test fun sameScheduleAndAwayTeamMergeEvenWhenHomeNamesDiffer() {
        val predictions = listOf(
            ScoreModel(
                homeTeam = "Example Home FC",
                awayTeam = "Shared Away FC",
                predictedScore = "2-1",
                source = "ProviderA",
                sourceMatchId = "a-1",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Premier League",
                competitionCountry = "England"
            ),
            ScoreModel(
                homeTeam = "Completely Different Home Name",
                awayTeam = "Shared Away FC",
                predictedScore = "1-0",
                source = "ProviderB",
                sourceMatchId = "b-1",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Premier League",
                competitionCountry = "England"
            )
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Same date + kickoff + league + identical away team must merge", unified.size == 1)
        assertTrue("Both provider predictions must survive the merge", unified.single().predictions.size == 2)
    }

    @Test fun motorLublinMergesAcrossLocalizedLeagueLabelsWhenAwayTeamMatches() {
        val predictions = listOf(
            ScoreModel(
                homeTeam = "Legia Warszawa",
                awayTeam = "Motor Lublin",
                predictedScore = "2-1",
                source = "ProviderA",
                sourceMatchId = "motor-a",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Poland - Ekstraklasa",
                competitionCountry = "Poland"
            ),
            ScoreModel(
                homeTeam = "Legia Warsaw",
                awayTeam = "Motor Lublin",
                predictedScore = "1-0",
                source = "ProviderB",
                sourceMatchId = "motor-b",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Ekstraklasa",
                competitionCountry = "Poland"
            )
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Motor Lublin fixture must merge across localized league labels", unified.size == 1)
        assertTrue("Both Motor Lublin predictions must survive the merge", unified.single().predictions.size == 2)
    }

    @Test fun sameTeamsOnDifferentDatesRemainSeparateFixtures() {
        val dayOne = 1_800_000_000_000L
        val dayTwo = dayOne + 24L * 60L * 60L * 1000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", dayOne),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", dayTwo)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Different fixture dates must not collapse", unified.size == 2)
    }

    @Test fun predictionRemainsVisibleWhenNoIddaaFixtureExists() {
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "FP.com", "fp-1", 1_800_000_000_000L),
            ScoreModel("Arsenal", "Chelsea", "1-0", "PredictZ", "pz-1", 1_800_000_000_000L)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Prediction-first data must survive without an Iddaa match", unified.size == 1)
        assertTrue(unified.single().predictions.size == 2)
        assertTrue(unified.single().officialMatch == null)
    }

    @Test fun sevenMSportParserReadsBet365OneXTwoRow() {
        val html = """
            <table>
              <tr><th>Match</th><th>Bookmaker</th><th>1</th><th>X</th><th>2</th></tr>
              <tr>
                <td><a>Manchester United</a> <a>Liverpool FC</a></td>
                <td>Bet365</td><td>2.10</td><td>3.60</td><td>3.20</td>
              </tr>
            </table>
        """
        val parsed = SevenMSportBet365Service().parse(html)
        val row = parsed.values.single()
        assertTrue(row.home == "Manchester United")
        assertTrue(row.away == "Liverpool FC")
        assertTrue(row.odds.ms1 == "2.10")
        assertTrue(row.odds.msX == "3.60")
        assertTrue(row.odds.ms2 == "3.20")
    }

    @Test fun chekiOddsParsesBet365FromExplicitBookmakerRow() {
        val html = """
            <div class="match-card">
              <h2>Austin v Real Salt Lake</h2>
              <div>1 3.10 Bet365 X 3.60 Bet365 2 2.20 Bet365</div>
              <table>
                <tr><th>Bookmaker</th><th>1</th><th>X</th><th>2</th></tr>
                <tr><td>Bet365</td><td>3.10</td><td>3.60</td><td>2.20</td></tr>
              </table>
            </div>
        """
        val index = ChekiOddsBet365Service().parsePageIndex(html)
        assertTrue(index != null)
        val row = index!!.rows.single()
        assertTrue(row.home == "Austin")
        assertTrue(row.away == "Real Salt Lake")
        assertTrue(row.odds == listOf("3.10", "3.60", "2.20"))
    }


    @Test fun sameTeamsSameDateDifferentKickoffsRemainSeparateFixtures() {
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "ProviderA", "a-1", 0L,
                "30.10.2026", "18:00", "Premier League", "England"),
            ScoreModel("Arsenal", "Chelsea", "1-0", "ProviderB", "b-1", 0L,
                "30.10.2026", "20:00", "Premier League", "England")
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Different explicit kickoffs must not collapse into one fixture", unified.size == 2)
    }

    @Test fun reversedHomeAwayTeamsRemainSeparateFixtures() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "ProviderA", "a-1", kickoff),
            ScoreModel("Chelsea", "Arsenal", "1-2", "ProviderB", "b-1", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Home/away reversal must not create the same fixture", unified.size == 2)
    }

    @Test fun seniorAndYouthFixturesRemainSeparateDuringGlobalMerge() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "ProviderA", "senior-1", kickoff),
            ScoreModel("Manchester United U21", "Liverpool U21", "1-0", "ProviderB", "youth-1", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Senior and youth fixtures must remain separate", unified.size == 2)
    }

    @Test fun threeProvidersWithAliasVariantsStillProduceExactlyOneFixture() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Legia Warszawa", "Motor Lublin", "2-1", "ProviderA", "legia-a", kickoff),
            ScoreModel("Legia Warsaw", "Motor Lublin", "1-0", "ProviderB", "legia-b", kickoff),
            ScoreModel("Legia Warszawa", "Motor Lublin FC", "2-0", "ProviderC", "legia-c", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Equivalent localized aliases should collapse to one fixture", unified.size == 1)
        assertTrue("No provider prediction may be lost", unified.single().predictions.size == 3)
    }

    @Test fun providerPredictionIdsRemainAttachedToExactRecordsAfterMerge() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "ProviderA", "provider-a-123", kickoff,
                predictionId = "prediction-A"),
            ScoreModel("Arsenal", "Chelsea", "1-1", "ProviderB", "provider-b-456", kickoff,
                predictionId = "prediction-B")
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())
        val ids = unified.single().predictionRecords.map { it.predictionId }.toSet()

        assertTrue("Prediction identity must survive fixture merging", ids == setOf("prediction-A", "prediction-B"))
    }

    @Test fun duplicateProviderRowsDoNotCreateASecondFixture() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "ProviderA", "same-row", kickoff),
            ScoreModel("Arsenal", "Chelsea", "2-1", "ProviderA", "same-row", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Duplicate rows should stay inside one fixture cluster", unified.size == 1)
        assertTrue("Duplicate source rows must not become separate fixtures", unified.single().predictions.size == 2)
    }

    @Test fun differentDatesRemainSeparateEvenWhenProviderNamesAreIdentical() {
        val predictions = listOf(
            ScoreModel("Real Madrid", "Barcelona", "2-1", "ProviderA", "match-1", 0L,
                "30.10.2026", "20:00", "La Liga", "Spain"),
            ScoreModel("Real Madrid", "Barcelona", "1-1", "ProviderB", "match-2", 0L,
                "31.10.2026", "20:00", "La Liga", "Spain")
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Different calendar dates must remain separate fixtures", unified.size == 2)
    }

    @Test fun missingScheduleMetadataDoesNotBreakExactTeamMerge() {
        val predictions = listOf(
            ScoreModel("Inter Milan", "Juventus", "2-1", "ProviderA", "inter-a"),
            ScoreModel("Inter", "Juventus", "1-0", "ProviderB", "inter-b")
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Compatible team identities without schedule metadata should still merge", unified.size == 1)
        assertTrue(unified.single().predictions.size == 2)
    }

    @Test fun aliasChainWithMissingScheduleMetadataStillFormsOneFixture() {
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "ProviderA", "chain-a", 0L),
            ScoreModel("Man Utd", "Liverpool FC", "1-1", "ProviderB", "chain-b", 0L),
            ScoreModel("Manchester United", "Liverpool", "2-0", "ProviderC", "chain-c", 0L)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Strong two-sided identity aliases without schedule metadata must remain one fixture", unified.size == 1)
        assertTrue("All chain members must survive", unified.single().predictionRecords.size == 3)
    }

    @Test fun sameProviderIdCanRepairStaleScheduleWithoutMergingDifferentTeams() {
        val predictions = listOf(
            ScoreModel("Legia Warszawa", "Motor Lublin", "2-1", "ProviderA", "stable-id", 1_800_000_000_000L, "30.10.2026", "18:00", "Ekstraklasa", "Poland"),
            ScoreModel("Legia Warsaw", "Motor Lublin FC", "1-0", "ProviderA", "stable-id", 0L, "", "--:--", "", "Poland")
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Same provider identity must keep the records in one fixture", unified.size == 1)
        assertTrue(unified.single().predictionRecords.size == 2)
    }

    @Test fun differentFixturesWithSharedTeamDoNotMergeTransitively() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Orlando City", "Toronto FC", "2-1", "ProviderA", "fixture-a", kickoff),
            ScoreModel("Miami FC", "Nashville SC", "1-0", "ProviderB", "fixture-b", kickoff),
            ScoreModel("Orlando City", "Nashville SC", "0-0", "ProviderC", "fixture-c", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Unrelated fixtures must not collapse through transitive team matches", unified.size == 3)
    }


    @Test
    fun sourceCacheIdentitySeparatesProvidersWithSameFixture() {
        val tipster = SourceCacheIdentity.fixture("TipsterArea", "Team A", "Team B", "2026-10-31", "123")
        val bwin = SourceCacheIdentity.fixture("Bwin", "Team A", "Team B", "2026-10-31", "123")
        assertNotEquals(tipster, bwin)
    }

    @Test
    fun sourceCacheIdentitySeparatesDatesAndSourceMatchIds() {
        val today = SourceCacheIdentity.fixture("FP.com", "Team A", "Team B", "2026-10-31", "same")
        val tomorrow = SourceCacheIdentity.fixture("FP.com", "Team A", "Team B", "2026-11-01", "same")
        val otherId = SourceCacheIdentity.fixture("FP.com", "Team A", "Team B", "2026-10-31", "other")
        assertNotEquals(today, tomorrow)
        assertNotEquals(today, otherId)
    }

    @Test
    fun sourceResultSetIdentityChangesWhenMiddleRowChanges() {
        val base = listOf(
            ScoreModel("A", "B", "1-0", "FP.com", sourceMatchId = "1", matchDate = "2026-10-31"),
            ScoreModel("C", "D", "2-1", "FP.com", sourceMatchId = "2", matchDate = "2026-10-31"),
            ScoreModel("E", "F", "0-0", "FP.com", sourceMatchId = "3", matchDate = "2026-10-31")
        )
        val changed = base.toMutableList().apply {
            this[1] = this[1].copy(predictedScore = "3-1")
        }
        assertNotEquals(
            SourceCacheIdentity.resultSet("FP.com", base),
            SourceCacheIdentity.resultSet("FP.com", changed)
        )
    }


    @Test
    fun diagnosticAliasVariantsConverge() {
        val pairs = listOf(
            "Mirassol FC SP" to "Mirassol",
            "CA Aldosivi" to "Aldosivi",
            "Charleston Battery" to "Charleston",
            "Rhode Island FC" to "Rhode Island",
            "Tampa Bay Rowdies" to "Tampa Bay",
            "Miami FC" to "Miami",
            "Union Omaha SC" to "Union Omaha",
            "Chattanooga Red Wolves SC" to "Chattanooga Red Wolves"
        )
        pairs.forEach { (provider, official) ->
            assertTrue(
                TeamAliasCanonicalizer.canonical(provider) == TeamAliasCanonicalizer.canonical(official),
                "Alias mismatch: $provider vs $official"
            )
        }
    }
}
