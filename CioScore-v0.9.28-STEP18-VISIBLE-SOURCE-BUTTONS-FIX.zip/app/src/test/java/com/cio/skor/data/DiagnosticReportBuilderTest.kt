package com.cio.skor.data

import kotlin.test.Test
import kotlin.test.assertContains
import kotlin.test.assertFalse

class DiagnosticReportBuilderTest {
    @Test
    fun reportShowsOnlyActionableProblemSections() {
        val trace = ScanTrace(
            parserReports = listOf(
                ParserHealthReport("FP.com", 200, 1200, 0, 900, ParserStatus.DOM_CHANGED, "selector missing")
            ),
            stageMetrics = emptyMap(),
            dropReasons = listOf(DropReason(PipelineStage.PARSER, "EMPTY_RESULT", 12)),
            totalDurationMs = 1200
        )
        val report = DiagnosticReportBuilder.build(trace, SourceHealthState())
        assertContains(report, "KAYNAK / PARSER")
        assertContains(report, "DOM_CHANGED")
        assertContains(report, "VERİ KAYBI")
        assertContains(report, "ODAK: önce DOM/parser")
        assertFalse(report.contains("CANLI SOURCE HEALTH"))
    }

    @Test
    fun healthyReportIsCompact() {
        val trace = ScanTrace(
            parserReports = listOf(ParserHealthReport("FP.com", 200, 1000, 4, 200, ParserStatus.HEALTHY)),
            stageMetrics = emptyMap(),
            dropReasons = emptyList(),
            totalDurationMs = 200,
            predictionFixtureCount = 4,
            officialMatchedPredictionCount = 4
        )
        val report = DiagnosticReportBuilder.build(trace, SourceHealthState())
        assertContains(report, "Kritik sorun tespit edilmedi")
        assertFalse(report.contains("FP.com"))
    }
}
