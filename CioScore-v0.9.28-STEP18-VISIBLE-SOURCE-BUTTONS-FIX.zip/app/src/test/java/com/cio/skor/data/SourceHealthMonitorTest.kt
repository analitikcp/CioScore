package com.cio.skor.data

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceHealthMonitorTest {
    @After fun cleanup() = SourceHealthMonitor.clear()

    @Test fun latestStateIsUpdatedPerSource() {
        SourceHealthMonitor.record(ParserHealthReport("FP.com", 200, 1200, 4, 320, ParserStatus.HEALTHY))
        SourceHealthMonitor.record(ParserHealthReport("PredictZ", 200, 1000, 0, 410, ParserStatus.DOM_CHANGED, "DOM_CHANGED_OR_EMPTY"))
        val state = SourceHealthMonitor.state.value
        assertEquals(2, state.latest.size)
        assertEquals(1, state.healthyCount)
        assertEquals(1, state.failedCount)
    }

    @Test fun repeatedSourceReplacesLatestButKeepsHistory() {
        SourceHealthMonitor.record(ParserHealthReport("FP.com", 200, 1000, 3, 100, ParserStatus.HEALTHY))
        SourceHealthMonitor.record(ParserHealthReport("FP.com", 200, 900, 0, 140, ParserStatus.DOM_CHANGED, "DOM changed"))
        val state = SourceHealthMonitor.state.value
        assertEquals(1, state.latest.size)
        assertEquals(ParserStatus.DOM_CHANGED, state.latest.single().status)
        assertEquals(2, state.history.size)
    }

    @Test fun historyIsBounded() {
        repeat(50) { index ->
            SourceHealthMonitor.record(ParserHealthReport("S$index", 200, 1, 1, 1, ParserStatus.HEALTHY))
        }
        assertEquals(40, SourceHealthMonitor.state.value.history.size)
        assertTrue(SourceHealthMonitor.state.value.updatedAt > 0L)
    }
}
