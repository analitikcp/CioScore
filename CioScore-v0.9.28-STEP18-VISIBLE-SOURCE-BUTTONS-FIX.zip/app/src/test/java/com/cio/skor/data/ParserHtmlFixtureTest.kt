package com.cio.skor.data

import com.cio.skor.data.parsers.AccurateTipExactScoreParser
import com.cio.skor.data.parsers.BallPredictionExactScoreParser
import com.cio.skor.data.parsers.CorrectScoreNetParser
import com.cio.skor.data.parsers.DailySportsParser
import com.cio.skor.data.parsers.FPComParser
import com.cio.skor.data.parsers.FootballScorePredictorParser
import com.cio.skor.data.parsers.PredictZParser
import com.cio.skor.data.parsers.WinDrawWinParser
import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.charset.StandardCharsets

/**
 * HTML fixture tests for active prediction parsers.
 *
 * These tests intentionally parse local, deterministic HTML rather than live
 * provider pages. They protect the provider-specific selectors/markup rules
 * from silently regressing when parsers are refactored.
 */
class ParserHtmlFixtureTest {

    private fun fixture(name: String) =
        requireNotNull(javaClass.classLoader?.getResourceAsStream("parser-fixtures/$name")) {
            "Missing parser HTML fixture: $name"
        }.use { input ->
            Jsoup.parse(input, StandardCharsets.UTF_8.name(), "https://fixture.test/")
        }

    private fun assertSingleScore(rows: List<ScoreModel>, home: String, away: String, score: String) {
        assertEquals("fixture row count", 1, rows.size)
        val row = rows.single()
        assertEquals(home, row.homeTeam)
        assertEquals(away, row.awayTeam)
        assertEquals(score, row.predictedScore)
        assertFalse("source must be populated", row.source.isBlank())
    }

    @Test fun fpComFixtureParsesTeamsAndScore() {
        assertSingleScore(FPComParser().parse(fixture("fpcom.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun predictZFixtureParsesTeamsAndScore() {
        assertSingleScore(PredictZParser().parse(fixture("predictz.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun winDrawWinFixtureParsesTipAndScore() {
        assertSingleScore(WinDrawWinParser().parse(fixture("windrawwin.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun dailySportsFixtureUsesImageTeamMetadata() {
        assertSingleScore(DailySportsParser().parse(fixture("dailysports.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun correctScoreNetFixtureParsesProviderSpecificPickMarkup() {
        assertSingleScore(CorrectScoreNetParser().parse(fixture("correct-score-net.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun ballPredictionFixtureParsesSplitCorrectScoreColumn() {
        assertSingleScore(BallPredictionExactScoreParser().parse(fixture("ballprediction.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun footballScorePredictorFixtureParsesAdjacentPredictionGoals() {
        assertSingleScore(FootballScorePredictorParser().parse(fixture("football-score-predictor.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun accurateTipFixtureParsesExplicitCorrectScoreText() {
        assertSingleScore(AccurateTipExactScoreParser().parse(fixture("accuratetip.html")), "Arsenal", "Chelsea", "2-1")
    }

    @Test fun fixtureParsingDoesNotInventRowsFromUnrelatedHtml() {
        val doc = Jsoup.parse("""
            <html><body>
              <h1>Arsenal Chelsea</h1>
              <div>Latest news: Arsenal won 2-1 yesterday.</div>
            </body></html>
        """, "https://fixture.test/")
        assertTrue(FPComParser().parse(doc).isEmpty())
        assertTrue(PredictZParser().parse(doc).isEmpty())
        assertTrue(WinDrawWinParser().parse(doc).isEmpty())
        assertTrue(DailySportsParser().parse(doc).isEmpty())
        assertTrue(CorrectScoreNetParser().parse(doc).isEmpty())
    }
}
