package com.cio.skor.data

import org.junit.Assert.*
import org.junit.Test

class OddsSearchMatcherTest {
    @Test
    fun parsesThreeOddsWithSlashAndComma() {
        val q = OddsSearchMatcher.parse("1,85 / 3,40 / 4,20")
        assertNotNull(q)
        assertEquals(1.85, q!!.ms1, 0.001)
        assertEquals(3.40, q.msX, 0.001)
        assertEquals(4.20, q.ms2, 0.001)
    }

    @Test
    fun exactOddsMatch() {
        val q = OddsSearchMatcher.parse("1.85 3.40 4.20")!!
        val result = OddsSearchMatcher.compare(q, 1.85, 3.40, 4.20)
        assertNotNull(result)
        assertTrue(result!!.exact)
    }

    @Test
    fun nearbyOddsMatchWithinTwoPercentOrFiveHundredths() {
        val q = OddsSearchMatcher.parse("1.85 3.40 4.20")!!
        val result = OddsSearchMatcher.compare(q, 1.88, 3.46, 4.26)
        assertNotNull(result)
        assertFalse(result!!.exact)
    }

    @Test
    fun clearlyDifferentOddsDoNotMatch() {
        val q = OddsSearchMatcher.parse("1.85 3.40 4.20")!!
        assertNull(OddsSearchMatcher.compare(q, 2.20, 3.40, 4.20))
    }
}
