package com.cio.skor.data

import org.junit.Assert.assertEquals
import org.junit.Test

class OddsSourcePolicyTest {
    @Test
    fun dedicatedBwinChainBeatsBroadTotalCorner() {
        assertEquals(100, OddsSourcePolicy.priority("bwin-chain", "bwin"))
        assertEquals(40, OddsSourcePolicy.priority("TotalCorner", "bwin"))
    }

    @Test
    fun dedicatedBet365ChainBeatsBroadTotalCorner() {
        assertEquals(100, OddsSourcePolicy.priority("Bet365-chain", "Bet365"))
        assertEquals(40, OddsSourcePolicy.priority("TotalCorner", "Bet365"))
    }

    @Test
    fun broadBookmakersPreferTotalCorner() {
        assertEquals(70, OddsSourcePolicy.priority("TotalCorner", "Pinnacle"))
        assertEquals(20, OddsSourcePolicy.priority("other", "Pinnacle"))
    }
}
