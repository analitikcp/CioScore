package com.cio.skor.data

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

class PredictionSourceCatalogTest {
    @Test
    fun allDisplayedSourcesHaveStableLabelsAndUrls() {
        val sources = listOf(
            "FP.com", "PredictZ", "WinDrawWin", "DailySports",
            "BallPrediction", "Correct-Score.net", "FootballScorePredictor",
            "AccurateTip"
        )

        sources.forEach { source ->
            assertEquals(source, PredictionSourceCatalog.displayLabel(source))
            val url = PredictionSourceCatalog.url(source)
            assertNotNull(url)
            check(url.startsWith("https://"))
        }
    }

    @Test
    fun eachSourceUsesTheRequestedDestinationPage() {
        val expected = mapOf(
            "FP.com" to "https://footballpredictions.com/betting-tips/correct-score/",
            "PredictZ" to "https://www.predictz.com/predictions/today/correct-score/all-games/",
            "WinDrawWin" to "https://www.windrawwin.com/predictions/today/",
            "DailySports" to "https://dailysports.net/mathematical-predictions/correct-score/",
            "BallPrediction" to "https://ballprediction.com/",
            "Correct-Score.net" to "https://www.correct-score.net/en/",
            "FootballScorePredictor" to "https://www.footballscorepredictor.com/correct-score-predictions/",
            "AccurateTip" to "https://www.accuratetip.com/correct-score-predictions"
        )

        expected.forEach { (source, url) ->
            assertEquals(url, PredictionSourceCatalog.url(source))
        }
    }

    @Test
    fun sourceUrlLookupIsCaseInsensitive() {
        assertEquals(
            PredictionSourceCatalog.url("FP.com"),
            PredictionSourceCatalog.url("fp.COM")
        )
    }
}
