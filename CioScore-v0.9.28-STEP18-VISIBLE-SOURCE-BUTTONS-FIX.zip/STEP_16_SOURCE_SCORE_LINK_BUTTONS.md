# Step 16 — Kaynak Skor Butonları

- 8 skor/tahmin kaynağının her satırı tam genişlikte tıklanabilir kaynak butonu olarak bırakıldı.
- Her satırın sağ tarafına görünür `AÇ` butonu eklendi; satırın tamamı ve `AÇ` alanı aynı hedefi açar.
- Hedefler `PredictionSourceCatalog` üzerinden tek merkezden yönetilir.
- FP.com → Correct Score
- PredictZ → Correct Score
- WinDrawWin → Günlük tahminler
- DailySports → Correct Score
- BallPrediction → Ana sayfa
- Correct-Score.net → Correct Score
- FootballScorePredictor → Correct Score
- AccurateTip → Correct Score
- Kaynak skor verisi değiştirilmedi; yalnızca kaynak bağlantısı UI'sı güçlendirildi.
- `PredictionSourceCatalogTest` tüm 8 kaynağın hedef URL'sini birebir doğrular.
- Sürüm: 0.9.26 / versionCode 300
