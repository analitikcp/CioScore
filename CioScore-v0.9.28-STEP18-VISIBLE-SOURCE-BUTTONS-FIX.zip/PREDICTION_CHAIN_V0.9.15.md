# CioScore v0.9.15 — Prediction Chain Hardening

- Version: 0.9.15 / versionCode 299
- Added a shared final exact-score/team validation gate.
- Generic expanded parsers now sanitize scores before emitting ScoreModel records.
- Source fetches use a short isolated retry for transient network/server failures.
- Deterministic 4xx responses are not repeatedly hammered.
- HTTP 200 is still never treated as a score-source success unless parsed exact-score records exist.
- Existing Iddaa enrichment remains enrichment-only; provider predictions are not gated out by the official bulletin.
