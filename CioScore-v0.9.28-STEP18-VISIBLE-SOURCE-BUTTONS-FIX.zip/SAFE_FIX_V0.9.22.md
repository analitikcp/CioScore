# SAFE FIX v0.9.22

- Diagnostic panel reduced to problem-only summary.
- Schedule candidate generation no longer requires literal competition label equality.
- Same date + kickoff + country creates the candidate bucket; final competition compatibility remains mandatory.
- Conservative competition compatibility accepts localized/verbose league labels such as `Poland - Ekstraklasa` vs `Ekstraklasa` while rejecting unrelated competitions.
- One-sided team anchor remains valid only with same explicit schedule and compatible competition.
- No synthetic fixture, score, odds, or team identity is generated.
