# Prediction chain fix v0.9.24

- MainActivity no longer drops a matcher-selected prediction when predictionId lookup misses.
- The exact GlobalFixtureMatcher.Record is used as a safe fallback when it contains a renderable score.
- Blank prediction IDs are excluded from the lookup index so they cannot overwrite each other.
- No fuzzy re-matching or score synthesis is introduced.
- UI remains 9-source; FutHead is not re-enabled.
