# Source cleanup — v0.9.24

## What was removed

The active scraper registry in `ScraperRepository.kt` contains 10 score-prediction sources. During static dependency analysis, the following provider/parser code was found to have no active registration and no call sites:

- FootballPredictions.com (`FootballPredictionsComExactScoreParser`)
- `ExpandedExactScoreParsers.kt` (helper-only, no call sites)
- `AdditionalPredictionParser.kt` (no call sites)

These were removed so the APK does not carry dead/unwired prediction-source code.

## Active sources retained

1. FP.com
2. PredictZ
3. WinDrawWin
4. DailySports
6. BallPrediction
7. Correct-Score.net
8. FootballScorePredictor
9. AccurateTip
10. FutHead Predictions

## Important validation note

The isolated build environment has no outbound network access. Therefore a live HTTP/parser run could not be used to prove that a source currently returns zero predictions. This cleanup removes only sources that are demonstrably inactive/unwired in the supplied project; it does not claim that any of the 10 active sources is permanently dead.
