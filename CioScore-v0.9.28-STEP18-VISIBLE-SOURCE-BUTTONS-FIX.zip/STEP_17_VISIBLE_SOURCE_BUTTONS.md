# STEP 17 — Görünür Kaynak AÇ Butonları

- Sürüm: 0.9.27 / versionCode 301
- Her skor tahmini satırının sağında gerçek, görünür bir `AÇ` butonu bulunur.
- Satırın tamamına dokunmak ve `AÇ` butonuna dokunmak aynı kaynak URL'sini açar.
- Buton mavi, beyaz yazılı ve 48dp genişliğindedir; önceki TextView tabanlı görünüm yerine gerçek Android Button kullanılır.
- Kaynak hedefleri `PredictionSourceCatalog` üzerinden merkezi olarak yönetilir.
