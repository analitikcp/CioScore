# Step 15 — Skor Kaynakları Tıklanabilir Butonlar

- 8 skor/tahmin kaynağı kartı tıklanabilir hale getirildi.
- Her kaynak satırı Android tarayıcı açarak ilgili kaynağın doğrudan sayfasına gider.
- Kaynak başındaki emoji/şekiller kaldırıldı; isimler standart metin olarak gösteriliyor.
- Kaynak adı ve URL tek `PredictionSourceCatalog` üzerinden yönetiliyor.
- Mevcut skor/prediction verisi değişmedi; yalnızca UI etkileşimi ve standartlaştırma yapıldı.
- `PredictionSourceCatalogTest` ile tüm kaynakların HTTPS URL'si ve isimleri doğrulanıyor.


## 15.1 — 2026-10-31 diagnostic alias reconciliation
- Fixed the five diagnostic fixture-name mismatch families: Mirassol, Aldosivi, Charleston/Rhode Island, Tampa Bay/Miami, Union Omaha/Chattanooga Red Wolves.
- Added regression coverage so these provider/official naming variants converge to the same canonical identity.
- FP.com button targets the direct Correct Score page.
