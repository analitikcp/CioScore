CioScore v0.9.21 — SAFE MATCH-MERGE FIX

Root cause fixed:
- GlobalFixtureMatcher PASS 4 used a two-sided canonical token pre-filter.
- If HOME names differed enough to share no token, a pair with identical AWAY,
  date, kickoff and competition never reached the evidence scorer.
- The existing scorer already supported the requested one-sided schedule anchor,
  but the candidate pre-filter prevented it from running.

Minimal fix:
- Added a schedule-anchored candidate index keyed by normalized date, kickoff,
  competition and country.
- Within the schedule bucket, a pair is sent to the existing scorer when either
  HOME or AWAY has exact/strong canonical identity.
- Schedule metadata alone never merges fixtures.
- Existing componentsCompatible(), metadata contradiction gates and fuzzy
  confidence rules remain authoritative.
- No fake scores, teams, odds or fixtures added.
- Added regression test: same schedule + identical away team + different home
  names must merge into one unified fixture.
