# STEP 18 — Kaynak AÇ Butonlarını Görsel Olarak Sabitleme

- Sürüm: 0.9.28 / versionCode 302
- Mevcut kaynak satırları korunmuştur.
- Her satırın sağında ayrı ve sabit ölçülü Android `Button` bulunur.
- Buton 56dp x 30dp, mavi zemin, beyaz `AÇ` yazısı ve kenarlık ile özellikle görünür hale getirilmiştir.
- Satırın tamamına dokunmak veya `AÇ` butonuna dokunmak aynı kaynak URL'sini açar.
- Kaynak URL'leri `PredictionSourceCatalog` üzerinden merkezi olarak kullanılmaya devam eder.
- APK derlemesi bu ortamda Gradle dağıtımı DNS erişimi olmadığı için doğrulanamamıştır.
