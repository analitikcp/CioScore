# CioScore v0.9.25 — SOURCE_CONFLICT prediction retention

- `GlobalFixtureMatcher.buildUnified()` no longer drops a source when duplicate records for the same fixture contain different predicted scores.
- The conflict remains recorded in diagnostics, but the best deterministic candidate is retained for UI rendering.
- `MainActivity.coalesceDisplayGroups()` applies the same rule at the final UI merge stage.
- Version name standardized to `0.9.25`.

This fix prevents a provider-level duplicate/conflict from deleting all predictions from that source.
