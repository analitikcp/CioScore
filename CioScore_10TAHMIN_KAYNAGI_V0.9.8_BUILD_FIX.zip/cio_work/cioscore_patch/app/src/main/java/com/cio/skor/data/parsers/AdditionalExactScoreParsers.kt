package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import com.cio.skor.data.parsers.BaseParser.FixtureMetadata
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Source-specific, API-free exact-score parsers.
 *
 * Each provider has a different public HTML layout. These parsers intentionally
 * do not share one broad prediction regex: a score is accepted only when it is
 * found in the provider's own fixture/prediction structure.
 */

private fun cleanProviderTeam(raw: String): String = raw
    .replace(Regex("(?i)\\bimage\\b"), " ")
    .replace(Regex("(?i)\\b(?:our pick|correct score|predicted score|prediction)\\b.*$"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':')

private fun looksLikeProviderTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.contains(Regex("(?i)^(time|date|details|predict|prediction|correct score|our pick|odds|score|home|away|draw|vs|x|1x2|preview|football|image|more)$"))) return false
    return true
}

private fun scoreFrom(text: String): String? {
    val m = Regex("(?<!\\d)(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})(?!\\d)").find(text) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null
    val a = m.groupValues[2].toIntOrNull() ?: return null
    return if (h in 0..20 && a in 0..20) "$h-$a" else null
}

private fun model(source: String, home: String, away: String, score: String, scope: Element): ScoreModel? {
    val h = cleanProviderTeam(home)
    val a = cleanProviderTeam(away)
    if (!looksLikeProviderTeam(h) || !looksLikeProviderTeam(a) || h.equals(a, true)) return null
    return ScoreModel(
        homeTeam = h,
        awayTeam = a,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
    )
}

/** Sports Mole: the listing page links to preview articles; the article itself contains the explicit "We say:" line. */
class SportsMoleExactScoreParser : BaseParser("Sports Mole") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val marker = Regex("(?is)\\bwe\\s+say\\s*:\\s*(.+?)\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\s+(.+?)(?=[.!?]|$)")
        val scopes = (doc.select("article, main, [class*=article], [class*=preview], body") + doc.select("strong, b, p, h2, h3"))
            .distinct()
        for (el in scopes) {
            val text = clean(el.text())
            val m = marker.find(text) ?: continue
            val score = "${m.groupValues[2]}-${m.groupValues[3]}"
            val item = modelWithMetadata(
                source = "Sports Mole",
                home = m.groupValues[1],
                away = m.groupValues[4],
                score = score,
                scope = el,
                competition = extractNearestCompetition(el)
            ) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** Forebet: current listing rows expose date/time, teams and a separate correct-score value. */
class ForebetExactScoreParser : BaseParser("Forebet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, [class*=match], [class*=fixture], [class*=rcnt], [class*=fdate], main")
        for (el in scopes) {
            val text = clean(el.text())
            if (!Regex("\\b\\d{1,2}/\\d{1,2}/\\d{4}\\b").containsMatchIn(text)) continue
            val score = scoreFromForebet(el) ?: continue
            val teams = teamCandidates(el)
            if (teams.size < 2) continue
            val item = modelWithMetadata(
                "Forebet", teams[0], teams[1], score, el, extractNearestCompetition(el)
            ) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun scoreFromForebet(el: Element): String? {
        // Preferred: an element explicitly labelled as the prediction/correct score.
        val labelled = el.select("[class*=score], [class*=pred], [data-score], [data-correct-score]")
            .asSequence().map { clean(it.text().ifBlank { it.attr("data-score") }) }
            .mapNotNull(::scoreFrom).firstOrNull()
        if (labelled != null) return labelled

        // Current Forebet rows contain the prediction as "Pred 1-1" and also
        // repeat it as a spaced "1 - 1" value. Prefer a score after a 1/X/2 token.
        val text = clean(el.text())
        val afterPred = Regex("(?is)\\b(?:pred|prediction)\\s+[12x]\\s+(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})\\b").find(text)
        if (afterPred != null) return "${afterPred.groupValues[1]}-${afterPred.groupValues[2]}"
        val all = scoreRegex.findAll(text).map { "${it.groupValues[1]}-${it.groupValues[2]}" }.toList()
        return all.firstOrNull { it != "29-10" && it != "30-10" }
    }

    private fun teamCandidates(el: Element): List<String> {
        val imageTeams = el.select("img").flatMap {
            listOf(it.attr("alt"), it.attr("title"), it.attr("data-team"))
        }.map(::cleanProviderTeam).filter(::looksLikeProviderTeam).distinct()
        if (imageTeams.size >= 2) return imageTeams.take(2)

        val links = el.select("a[href]").map { cleanProviderTeam(it.text()) }
            .filter(::looksLikeProviderTeam).distinct()
        if (links.size >= 2) return links.take(2)

        return el.select("[class*=home], [class*=away], [class*=team]")
            .map { cleanProviderTeam(it.text()) }
            .filter(::looksLikeProviderTeam).distinct().take(2)
    }
}

/** Correct-Score.net: cards explicitly contain Home VS Away OUR PICK score. */
class CorrectScoreNetParser : BaseParser("Correct-Score.net") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val pattern = Regex("(?i)(.+?)\\s+VS\\s+(.+?)\\s+OUR[ \\t]*PICK[ \\t]*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})")
        for (el in doc.select("article, section, [class*=match], [class*=fixture], main")) {
            val text = clean(el.text())
            if (text.length > 4000 || !text.contains(Regex("(?i)our[ \\t]*pick"))) continue
            val m = pattern.find(text) ?: continue
            val item = model("Correct-Score.net", m.groupValues[1], m.groupValues[2], "${m.groupValues[3]}-${m.groupValues[4]}", el) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** BallPrediction: the current table has a CS column whose two score cells are often rendered separately. */
class BallPredictionExactScoreParser : BaseParser("BallPrediction") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // List pages expose a table header containing "CS" and the data rows
        // contain the predicted home/away goals in the CS column, sometimes as
        // one text node ("1 2") and sometimes as two separate cells.
        for (table in doc.select("table")) {
            val header = table.select("tr").firstOrNull { it.text().contains(Regex("(?i)\\bCS\\b|correct score")) }
                ?: continue
            val headerCells = header.select("th, td").map { clean(it.text()) }
            val csIndex = headerCells.indexOfFirst { it.equals("CS", true) || it.contains(Regex("(?i)correct score")) }
            for (row in table.select("tr")) {
                if (row == header) continue
                val cells = row.select("th, td").map { clean(it.text()) }.filter { it.isNotBlank() }
                if (cells.size < 3) continue
                val teams = extractBallTeams(row)
                if (teams.size < 2) continue
                val score = extractBallScoreFromColumn(cells, csIndex) ?: continue
                val item = modelWithMetadata("BallPrediction", teams[0], teams[1], score, row, extractNearestCompetition(row)) ?: continue
                out.putIfAbsent(item.matchKey, item)
            }
        }

        // Match/detail pages use a plain "Correct score 1 - 2" block.
        if (out.isEmpty()) {
            for (el in doc.select("article, section, main, [class*=match], [class*=prediction], body")) {
                val text = clean(el.text())
                if (!text.contains(Regex("(?i)correct score"))) continue
                val score = Regex("(?i)correct score\\s*(?:[:\\-])?\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})").find(text)
                    ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: continue
                val teams = extractBallTeams(el)
                if (teams.size < 2) continue
                val item = modelWithMetadata("BallPrediction", teams[0], teams[1], score, el, extractNearestCompetition(el)) ?: continue
                out.putIfAbsent(item.matchKey, item)
            }
        }
        return out.values.toList()
    }

    private fun extractBallTeams(el: Element): List<String> {
        val imgs = el.select("img").flatMap {
            listOf(it.attr("alt"), it.attr("title"), it.attr("data-team"))
        }.map(::cleanProviderTeam).filter(::looksLikeProviderTeam).distinct()
        if (imgs.size >= 2) return imgs.take(2)
        return el.select("a[href], [class*=team], [class*=home], [class*=away]")
            .map { cleanProviderTeam(it.text()) }
            .filter(::looksLikeProviderTeam).distinct().take(2)
    }

    private fun extractBallScoreFromColumn(cells: List<String>, csIndex: Int): String? {
        if (csIndex >= 0 && csIndex < cells.size) {
            val cs = cells[csIndex]
            scoreFrom(cs)?.let { return it }
            Regex("^\\s*(\\d{1,2})\\s+(\\d{1,2})\\s*$").matchEntire(cs)?.let {
                return "${it.groupValues[1]}-${it.groupValues[2]}"
            }
            val pair = cells.drop(csIndex).take(3).joinToString(" ")
            Regex("^.*?(\\d{1,2})\\s+(\\d{1,2})\\s*$").find(pair)?.let {
                return "${it.groupValues[1]}-${it.groupValues[2]}"
            }
        }
        return cells.asReversed().asSequence()
            .mapNotNull { cell -> Regex("^\\s*(\\d{1,2})\\s+(\\d{1,2})\\s*$").matchEntire(cell) }
            .map { "${it.groupValues[1]}-${it.groupValues[2]}" }
            .firstOrNull()
    }
}

/** Football Score Predictor: current table has Home, predicted-home, predicted-away, Away as separate cells. */
class FootballScorePredictorParser : BaseParser("FootballScorePredictor") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("table tr")) {
            val cells = row.select("th, td").map { clean(it.text()) }.filter { it.isNotBlank() }
            if (cells.size < 4) continue
            val pairIndex = (0 until cells.lastIndex).firstOrNull { i ->
                val h = cells[i].toIntOrNull(); val a = cells[i + 1].toIntOrNull()
                h != null && a != null && h in 0..20 && a in 0..20
            } ?: continue
            val home = stripForm(cells.getOrNull(pairIndex - 1).orEmpty())
            val away = stripForm(cells.drop(pairIndex + 2).firstOrNull { looksLikeProviderTeam(stripForm(it)) }.orEmpty())
            if (!looksLikeProviderTeam(home) || !looksLikeProviderTeam(away)) continue
            val score = "${cells[pairIndex].toInt()}-${cells[pairIndex + 1].toInt()}"
            val item = modelWithMetadata("FootballScorePredictor", home, away, score, row, extractNearestCompetition(row)) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }

    private fun stripForm(value: String): String = value
        .replace(Regex("(?:\\s+[WDL]){2,8}\\s*$", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\s+"), " ").trim()
}

/** FutHead Predictions: current rows expose two team links followed by probability/coef and a score. */
class FutHeadPredictionsParser : BaseParser("FutHead Predictions") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, [class*=event], [class*=match], article, section")
        for (row in scopes) {
            val text = clean(row.text())
            val score = scoreFrom(text) ?: continue
            val teams = row.select("a[href]").map { cleanProviderTeam(it.text()) }
                .filter(::looksLikeProviderTeam).distinct()
            if (teams.size < 2) continue
            val item = modelWithMetadata("FutHead Predictions", teams[0], teams[1], score, row, extractNearestCompetition(row)) ?: continue
            out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

private fun modelWithMetadata(
    source: String,
    home: String,
    away: String,
    score: String,
    scope: Element,
    competition: String = ""
): ScoreModel? {
    val h = cleanProviderTeam(home)
    val a = cleanProviderTeam(away)
    if (!looksLikeProviderTeam(h) || !looksLikeProviderTeam(a) || h.equals(a, true)) return null
    val parser = object : BaseParser(source) {
        override fun parse(doc: Document): List<ScoreModel> = emptyList()
    }
    val metadata = parser.extractFixtureMetadataForExternal(scope, competition)
    return ScoreModel(
        homeTeam = h,
        awayTeam = a,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = metadata.matchTimestamp,
        matchDate = metadata.matchDate,
        matchTime = metadata.matchTime,
        competitionName = metadata.competitionName,
        competitionCountry = metadata.competitionCountry
    )
}

private fun BaseParser.extractFixtureMetadataForExternal(scope: Element, competition: String): FixtureMetadata {
    return extractFixtureMetadata(scope).let { base ->
        if (base.competitionName.isNotBlank() || competition.isBlank()) base
        else mergeMetadata(base.matchDate, base.matchTime, competition, base.competitionCountry, base.rawDateTime)
    }
}
