# CioScore 0.9.8 — Kotlin derleme hataları düzeltmesi

## Düzeltilen hatalar

1. `MainActivity.kt` içinde `officialOnly` bloğu lambda dışında kalan `officialMatches` isimli olmayan bir değişkene referans veriyordu. Doğru kapsam değişkeni `officialInBulletinWindow` olarak düzeltildi. Bu tek hata, sonraki `it`, `homeTeam`, `awayTeam`, `size` ve type-inference hatalarının büyük bölümünü zincirleme oluşturuyordu.

2. `AdditionalExactScoreParsers.kt` içinde `FixtureMetadata` nested tipi import edilmediği için `Unresolved reference 'FixtureMetadata'` oluşuyordu. `BaseParser.FixtureMetadata` açıkça import edildi.

## Not

Kaynak kod düzeltmeleri yapıldı. Bu çalışma ortamında Gradle dağıtımı internetten indirilemediği için burada tam APK derlemesi doğrulanamadı; CI/runner tarafında aynı kaynakla derleme yapılmalıdır.
