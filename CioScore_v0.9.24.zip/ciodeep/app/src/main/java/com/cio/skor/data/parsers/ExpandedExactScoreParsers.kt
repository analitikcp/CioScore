package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Expanded exact-score sources validated as public pages before being added to
 * the live pool. A prediction is emitted only when the provider's own score
 * marker and the two teams are found in the same small DOM scope.
 */

private fun teamCells(el: Element): List<String> {
    val candidates = el.select("[class*=home], [class*=away], [class*=team], td, th, a[href*=match], a[href*=fixture]")
        .map { cleanExpandedTeam(it.text()) }
        .filter(::looksLikeExpandedTeam)
        .distinct()
    if (candidates.size >= 2) return candidates.take(2)

    val images = el.select("img").flatMap { listOf(it.attr("alt"), it.attr("title"), it.attr("data-team")) }
        .map(::cleanExpandedTeam).filter(::looksLikeExpandedTeam).distinct()
    return images.take(2)
}

private fun add(
    out: LinkedHashMap<String, ScoreModel>,
    source: String,
    homeRaw: String,
    awayRaw: String,
    score: String,
    scope: Element,
    competition: String,
    parser: BaseParser
) {
    val home = cleanExpandedTeam(homeRaw)
    val away = cleanExpandedTeam(awayRaw)
    if (!looksLikeExpandedTeam(home) || !looksLikeExpandedTeam(away) || home.equals(away, true)) return
    val baseMetadata: BaseParser.FixtureMetadata = parser.extractFixtureMetadata(scope)
    val metadata: BaseParser.FixtureMetadata = if (
        baseMetadata.competitionName.isNotBlank() || competition.isBlank()
    ) {
        baseMetadata
    } else {
        parser.mergeMetadata(
            baseMetadata.matchDate,
            baseMetadata.matchTime,
            competition,
            baseMetadata.competitionCountry,
            baseMetadata.rawDateTime
        )
    }
    val model = ScoreModel(
        homeTeam = home,
        awayTeam = away,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = metadata.matchTimestamp,
        matchDate = metadata.matchDate,
        matchTime = metadata.matchTime,
        competitionName = metadata.competitionName,
        competitionCountry = metadata.competitionCountry
    )
    out.putIfAbsent(model.source + "|" + model.matchKey, model)
}

private fun cleanExpandedTeam(value: String): String = value
    .replace(Regex("(?i)\\b(?:predicted scoreline|correct score|second likely correct scoreline|odds|prediction|predictions|tip)\\b.*$"), " ")
    .replace(Regex("\\b(?:[01]?\[0-9]|2[0-3]):[0-5]\[0-9]\\b"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':', '·')

private fun looksLikeExpandedTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.contains(Regex("(?i)^(correct score|predicted scoreline|prediction|predictions|odds|tip|home|away|draw|score|preview|weather|prob\\.?)$"))) return false
    return true
}
