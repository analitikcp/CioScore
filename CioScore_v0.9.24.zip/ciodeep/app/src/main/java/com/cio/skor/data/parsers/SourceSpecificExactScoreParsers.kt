package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * v0.9.16 source-by-source DOM parsers.
 *
 * IMPORTANT: there is intentionally no provider-agnostic score parser here.
 * Each class knows the provider's own fixture/prediction markers and DOM shape.
 * Shared helpers only build/validate ScoreModel after a source-specific parser
 * has selected the fixture scope.
 */

private fun sourceTeam(raw: String): String = raw
    .replace(Regex("(?i)\\bimage\\b"), " ")
    .replace(Regex("(?i)\\b(?:correct score|predicted scoreline|our pick|prediction|predictions|tip|details|odds)\\b.*$"), " ")
    .replace(Regex("\\s+"), " ")
    .trim(' ', '|', '-', ':', '·')

private fun validTeam(value: String): Boolean {
    if (value.length !in 2..90) return false
    if (value.matches(Regex("^[0-9 .:+%/\\-]+$"))) return false
    if (value.matches(Regex("(?i)^(home|away|draw|score|correct score|prediction|predictions|tip|odds|time|date|details|preview|football|image|vs|event)$"))) return false
    return true
}

private fun scorePair(raw: String): String? {
    val m = Regex("(?<!\[0-9])(\[0-9]{1,2})\\s*[-:]\\s*(\[0-9]{1,2})(?!\[0-9])").find(raw) ?: return null
    val h = m.groupValues[1].toIntOrNull() ?: return null
    val a = m.groupValues[2].toIntOrNull() ?: return null
    return if (h in 0..20 && a in 0..20) "$h-$a" else null
}

private fun firstTwoTeams(scope: Element): List<String> {
    // DOM priority is deliberate: explicit home/away nodes are stronger than
    // arbitrary links. A generic first-two-links strategy can capture league,
    // tipster or navigation anchors and silently swap/poison fixture identity.
    val homeAway = listOf(
        scope.select("[data-home-team]").firstOrNull()?.text().orEmpty(),
        scope.select("[data-away-team]").firstOrNull()?.text().orEmpty(),
        scope.select("[class*=home-team], [class*=home_team], [class*=hometeam]").firstOrNull()?.text().orEmpty(),
        scope.select("[class*=away-team], [class*=away_team], [class*=awayteam]").firstOrNull()?.text().orEmpty()
    ).map(::sourceTeam).filter(::validTeam)
    if (homeAway.size >= 2) return homeAway.take(2)

    val teamNodes = scope.select("[class*=team], [class*=Team]")
        .map { sourceTeam(it.text()) }
        .filter(::validTeam)
        .distinct()
    if (teamNodes.size >= 2) return teamNodes.take(2)

    // Last resort is still fixture-local: only anchors inside the selected
    // prediction row/card are considered, never page-level navigation links.
    val links = scope.select("a[href]")
        .map { sourceTeam(it.text()) }
        .filter(::validTeam)
        .filterNot { it.contains(Regex("(?i)correct score|prediction|predictions|details|odds|tip")) }
        .distinct()
    return links.take(2)
}

private fun buildSourceModel(
    parser: BaseParser,
    source: String,
    homeRaw: String,
    awayRaw: String,
    score: String,
    scope: Element,
    competition: String = ""
): ScoreModel? {
    val home = sourceTeam(homeRaw)
    val away = sourceTeam(awayRaw)
    if (!validTeam(home) || !validTeam(away) || home.equals(away, true)) return null

    val base = parser.extractFixtureMetadata(scope)
    val meta = if (base.competitionName.isNotBlank() || competition.isBlank()) base
    else parser.mergeMetadata(base.matchDate, base.matchTime, competition, base.competitionCountry, base.rawDateTime)

    return ScoreModel(
        homeTeam = home,
        awayTeam = away,
        predictedScore = score,
        source = source,
        sourceMatchId = scope.select("a[href]").firstOrNull()?.attr("href").orEmpty(),
        matchTimestamp = meta.matchTimestamp,
        matchDate = meta.matchDate,
        matchTime = meta.matchTime,
        competitionName = meta.competitionName,
        competitionCountry = meta.competitionCountry
    )
}

/** FootballPredictions.com: betting-tip table rows contain explicit Correct Score fields. */
class FootballPredictionsComExactScoreParser : BaseParser("FootballPredictions.com") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        for (row in doc.select("table tr, article, li, [class*=match], [class*=fixture]")) {
            val text = clean(row.text())
            if (!text.contains(Regex("(?i)correct\\s*score"))) continue
            val m = Regex("(?i)correct\\s*score\\s*[:-]?\\s*([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})").find(text) ?: continue
            val score = "${m.groupValues[1]}-${m.groupValues[2]}"
            val teams = firstTwoTeams(row)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "FootballPredictions.com", teams[0], teams[1], score, row, extractNearestCompetition(row))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

/** FutHead Predictions: event rows contain score + Time + Date + Details. */
class FutHeadPredictionsExactScoreParser : BaseParser("FutHead Predictions") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val scopes = doc.select("tr, article, li, div[class*=event], div[class*=match], [class*=prediction]")
            .filter { it.text().contains(Regex("(?i)\\bTime\\s*:|\\bDate\\s*:|\\bPredict\\b")) }
            .sortedBy { it.text().length }
        for (scope in scopes) {
            val text = clean(scope.text())
            val time = Regex("""(?i)\bTime\s*:\s*(?:[01]?[0-9]|2[0-3]):[0-5][0-9]""").containsMatchIn(text)
            if (!time) continue
            val date = Regex("""(?i)\bDate\s*:\s*[0-9]{2}\.[0-9]{2}\.[0-9]{2,4}""").containsMatchIn(text)
            if (!date) continue
            val score = Regex("(?i)\\b(?:Predict|Score)\\b[^0-9]{0,20}(\[0-9]{1,2})\\s*[-:]\\s*(\[0-9]{1,2})\\b").find(text)
                ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
                ?: scorePair(text.substringBefore("Time:"))
                ?: continue
            val teams = firstTwoTeams(scope)
            if (teams.size < 2) continue
            val item = buildSourceModel(this, "FutHead Predictions", teams[0], teams[1], score, scope, extractNearestCompetition(scope))
            if (item != null) out.putIfAbsent(item.matchKey, item)
        }
        return out.values.toList()
    }
}

