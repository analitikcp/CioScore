package com.cio.skor.data

interface BettingFlowProvider {
    val name: String
    val description: String
    val requiresCredentials: Boolean

    suspend fun fetch(bulletinDate: String): ProviderResult
}

data class ProviderResult(
    val provider: String,
    val flows: List<BettingFlowModel> = emptyList(),
    val error: String? = null,
    val capturedAt: Long = System.currentTimeMillis()
)
