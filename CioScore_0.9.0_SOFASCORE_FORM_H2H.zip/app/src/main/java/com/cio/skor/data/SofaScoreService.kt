package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

/**
 * SofaScore enrichment layer. It never becomes a CIO prediction source.
 * It adds reliable match metadata (kickoff/league), current 1X2 odds,
 * recent home/away form and H2H summary when the public endpoints provide it.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)

    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    data class FormSummary(
        val results: String,
        val record: String,
        val goalsFor: Int,
        val goalsAgainst: Int
    )

    data class H2HSummary(
        val played: Int,
        val homeWins: Int,
        val draws: Int,
        val awayWins: Int,
        val goals: Int
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String,
        val homeId: Long,
        val awayId: Long,
        val startTimestamp: Long,
        val tournament: String
    )

    private val http = HttpClient()
    private val base = "https://api.sofascore.com/api/v1"
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)

    suspend fun enrich(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups
        val events = loadTodayEvents()
        if (events.isEmpty()) return@coroutineScope groups

        val out = groups.toMutableList()
        // Keep the request burst modest because SofaScore can rate-limit aggressive clients.
        groups.chunked(4).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val event = events.firstOrNull {
                        MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                            MatchMerger.isSameTeam(it.away, group.awayTeam)
                    }
                    if (event == null) {
                        group
                    } else {
                        val homeForm = loadFormById(event.homeId, event.id)
                        val awayForm = loadFormById(event.awayId, event.id)
                        group.copy(
                            eventId = event.id,
                            kickoff = formatKickoff(event.startTimestamp),
                            league = event.tournament,
                            odds = loadOdds(event.id),
                            homeForm = homeForm,
                            awayForm = awayForm,
                            h2h = loadH2H(event.id, event.homeId, event.awayId)
                        )
                    }
                }
            }.awaitAll()
            val start = chunkIndex * 4
            results.forEachIndexed { index, value -> out[start + index] = value }
        }
        out
    }

    /** Backwards-compatible name used by older code. */
    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = enrich(groups)

    suspend fun getLastFive(teamName: String): List<RecentMatch> = with(Dispatchers.IO) {
        val teamId = findTeamId(teamName) ?: return@with emptyList()
        loadLastFive(teamId)
    }

    private fun loadTodayEvents(): List<EventRef> {
        val date = LocalDate.now().toString()
        val (code, body) = http.get(
            "$base/sport/football/scheduled-events/$date",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    val homeId = e.optJSONObject("homeTeam")?.optLong("id", -1L) ?: -1L
                    val awayId = e.optJSONObject("awayTeam")?.optLong("id", -1L) ?: -1L
                    val timestamp = e.optLong("startTimestamp", 0L)
                    val tournament = e.optJSONObject("tournament")?.optString("name").orEmpty()
                    if (id > 0 && homeId > 0 && awayId > 0 && home.isNotBlank() && away.isNotBlank() && timestamp > 0) {
                        add(EventRef(id, home, away, homeId, awayId, timestamp, tournament))
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun formatKickoff(timestamp: Long): String = try {
        Instant.ofEpochSecond(timestamp)
            .atZone(ZoneId.systemDefault())
            .toLocalTime()
            .format(timeFormatter)
    } catch (_: Exception) {
        ""
    }

    private fun loadOdds(eventId: Long): Odds? {
        val paths = listOf(
            "$base/event/$eventId/odds/1/all",
            "$base/event/$eventId/odds"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseOdds(JSONObject(body))?.let { return it }
        }
        return null
    }

    private fun parseOdds(root: JSONObject): Odds? {
        fun walk(value: Any?): Odds? {
            when (value) {
                is JSONObject -> {
                    val choices = value.optJSONArray("choices")
                    if (choices != null) {
                        var one: String? = null
                        var draw: String? = null
                        var two: String? = null
                        for (i in 0 until choices.length()) {
                            val c = choices.optJSONObject(i) ?: continue
                            val name = c.optString("name").trim().uppercase(Locale.US)
                            val raw = c.opt("decimalValue") ?: c.opt("decimal") ?: c.opt("value")
                            val number = raw?.toString()?.toDoubleOrNull()
                            if (number == null || number <= 1.0 || number > 100.0) continue
                            val formatted = String.format(Locale.US, "%.2f", number)
                            when (name) {
                                "1", "HOME" -> one = formatted
                                "X", "DRAW" -> draw = formatted
                                "2", "AWAY" -> two = formatted
                            }
                        }
                        if (one != null && draw != null && two != null) return Odds(one, draw, two)
                    }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = walk(value.opt(keys.next()))
                        if (found != null) return found
                    }
                }
                is JSONArray -> for (i in 0 until value.length()) {
                    val found = walk(value.opt(i))
                    if (found != null) return found
                }
            }
            return null
        }
        return walk(root)
    }

    private fun loadFormById(teamId: Long, eventId: Long): FormSummary? {
        val matches = loadLastFive(teamId, eventId)
        if (matches.isEmpty()) return null
        val goalsFor = matches.sumOf { scoreFor(it.score) }
        val goalsAgainst = matches.sumOf { scoreAgainst(it.score) }
        val wins = matches.count { it.result == "G" }
        val draws = matches.count { it.result == "B" }
        val losses = matches.count { it.result == "M" }
        return FormSummary(
            results = matches.joinToString(" ") { it.result },
            record = "$winsG $drawsB $lossesM",
            goalsFor = goalsFor,
            goalsAgainst = goalsAgainst
        )
    }

    private fun scoreFor(score: String): Int = score.substringBefore('-').toIntOrNull() ?: 0
    private fun scoreAgainst(score: String): Int = score.substringAfter('-').toIntOrNull() ?: 0

    private fun loadLastFive(teamId: Long, excludeEventId: Long = -1L): List<RecentMatch> {
        val (code, body) = http.get(
            "$base/team/$teamId/events/last/0",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            parseRecentMatches(JSONObject(body), teamId)
                .filterNot { it.eventId == excludeEventId }
                .take(5)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$base/search/all?q=$query",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase(Locale.US)
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatchWithId> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatchWithId>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                Instant.ofEpochSecond(timestamp).atZone(ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            out += RecentMatchWithId(
                eventId = e.optLong("id", -1L),
                date = date,
                opponent = opponent,
                score = "$teamGoals-$oppGoals",
                isHome = isHome,
                result = result
            )
        }
        return out.sortedByDescending { it.date }
    }

    private data class RecentMatchWithId(
        val eventId: Long,
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String
    )

    private fun loadH2H(eventId: Long, currentHomeId: Long, currentAwayId: Long): H2HSummary? {
        val paths = listOf(
            "$base/event/$eventId/h2h/events",
            "$base/event/$eventId/h2h"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseH2H(JSONObject(body), currentHomeId, currentAwayId)?.let { return it }
        }
        return null
    }

    private fun parseH2H(root: JSONObject, currentHomeId: Long, currentAwayId: Long): H2HSummary? {
        val events = root.optJSONArray("events") ?: return null
        var played = 0
        var homeWins = 0
        var draws = 0
        var awayWins = 0
        var goals = 0
        for (i in 0 until minOf(events.length(), 5)) {
            val e = events.optJSONObject(i) ?: continue
            if (e.optJSONObject("status")?.optString("type") != "finished") continue
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val hId = e.optJSONObject("homeTeam")?.optLong("id", -1L) ?: -1L
            val aId = e.optJSONObject("awayTeam")?.optLong("id", -1L) ?: -1L
            if (hId != currentHomeId && hId != currentAwayId && aId != currentHomeId && aId != currentAwayId) continue
            played++
            goals += hs + ascore
            val currentHomeGoals = if (hId == currentHomeId) hs else ascore
            val currentAwayGoals = if (hId == currentHomeId) ascore else hs
            when {
                currentHomeGoals > currentAwayGoals -> homeWins++
                currentHomeGoals < currentAwayGoals -> awayWins++
                else -> draws++
            }
        }
        return if (played > 0) H2HSummary(played, homeWins, draws, awayWins, goals) else null
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val eventId: Long? = null,
        val kickoff: String = "",
        val league: String = "",
        val odds: Odds? = null,
        val homeForm: FormSummary? = null,
        val awayForm: FormSummary? = null,
        val h2h: H2HSummary? = null
    )

}
