CIO Score 0.8.4 - MightyTips Correct Score parser

Reference: https://www.mightytips.com/football-predictions/correct-score/
Only the MightyTips source was changed. PredictZ, FP.com and WinDrawWin were preserved.
