package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Source-specific parser for MightyTips Correct Score page. */
class MightyTipsParser : BaseParser("MightyTips") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // The current page renders each prediction as:
        // date -> time -> home -> dash -> away -> Score: -> x-y -> author.
        // We anchor on the literal Score: label rather than scanning arbitrary scores.
        for (scoreLabel in doc.getElementsContainingOwnText("Score:")) {
            val score = findScore(scoreLabel) ?: continue
            val card = findCard(scoreLabel) ?: continue
            val teams = extractTeams(card, scoreLabel) ?: continue
            val home = cleanTeam(teams.first)
            val away = cleanTeam(teams.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(home, away, score, source)
            out[model.matchKey] = model
            if (out.size >= 60) break
        }
        return out.values.toList()
    }

    private fun findScore(label: Element): String? {
        // Prefer the element immediately containing the score after Score:.
        val parentText = clean(label.parent()?.text() ?: label.text())
        val after = Regex("(?i)Score:\\s*([0-5])\\s*[-:]\\s*([0-5])").find(parentText)
        if (after != null) return "${after.groupValues[1]}-${after.groupValues[2]}"

        var node: Element? = label
        repeat(5) {
            node = node?.parent()
            val text = clean(node?.text() ?: "")
            val m = Regex("(?i)Score:\\s*([0-5])\\s*[-:]\\s*([0-5])").find(text)
            if (m != null) return "${m.groupValues[1]}-${m.groupValues[2]}"
        }
        return null
    }

    private fun findCard(label: Element): Element? {
        var node: Element? = label
        repeat(8) {
            node = node?.parent()
            val n = node ?: return@repeat
            val text = clean(n.text())
            if (text.length in 20..700 &&
                Regex("(?i)Score:\\s*[0-5]\\s*[-:]\\s*[0-5]").containsMatchIn(text)) {
                return n
            }
        }
        return null
    }

    private fun extractTeams(card: Element, scoreLabel: Element): Pair<String, String>? {
        // Best signal: team logo alt text. The page uses team logo images next to
        // the two team names. Ignore generic/site/navigation image labels.
        val alts = card.select("img[alt]")
            .map { it.attr("alt").trim() }
            .filter { isTeamLike(it) }
            .distinct()
        if (alts.size >= 2) return alts[0] to alts[1]

        // Fallback: use visible text around the score and explicit v/vs/dash separators.
        val text = clean(card.text())
        val withoutScore = text
            .replace(Regex("(?i)Score:\\s*[0-5]\\s*[-:]\\s*[0-5]"), " ")
            .replace(Regex("\\b\\d{1,2}:\\d{2}\\b"), " ")
            .replace(Regex("\\b\\d{1,2}\\.\\d{2}\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val explicit = Regex("(?i)^(.{2,70}?)\\s+(?:v|vs)\\s+(.{2,70}?)(?:\\s+Read Prediction.*)?$")
            .find(withoutScore)
        if (explicit != null) return explicit.groupValues[1].trim() to explicit.groupValues[2].trim()

        val dash = Regex("^(.{2,70}?)\\s+[—–-]\\s+(.{2,70}?)(?:\\s+(?:Score|Read Prediction|[A-Z][a-z]+\\s+[A-Z][a-z]+).*)?$")
            .find(withoutScore)
        if (dash != null) return dash.groupValues[1].trim() to dash.groupValues[2].trim()

        // DOM fallback: two non-generic headings/links before the Score label.
        val texts = card.select("h2,h3,h4,a,[class*=team],[class*=home],[class*=away]")
            .map { clean(it.text()) }
            .filter { isTeamLike(it) }
            .distinct()
        if (texts.size >= 2) return texts[0] to texts[1]

        return null
    }

    private fun isTeamLike(value: String): Boolean {
        val s = cleanTeam(value)
        if (s.length !in 2..70) return false
        if (Regex("(?i)^(mighty tips|score|read prediction|today|tomorrow|all football tips|correct score)$").matches(s)) return false
        if (Regex("^[0-9 .:/-]+$").matches(s)) return false
        if (Regex("(?i)^(image|logo|icon|avatar)$").matches(s)) return false
        return !Regex("(?i)^(ryan allan|nemanja lalic|paulius kundzelevicius|aleksandar krstic|kate richardson)$").matches(s)
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(score|read prediction|prediction|correct score|odds)\\b.*$"), "")
        .replace(Regex("\\b\\d{1,2}:\\d{2}\\b"), "")
        .trim(' ', '-', '–', '—', ':', '|')
}
