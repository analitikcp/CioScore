package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup
import java.util.Locale

/**
 * AiScore 1X2 enrichment.
 *
 * AiScore exposes match pages with the football 1/X/2 market in the
 * server-rendered page. We intentionally use the public match page rather
 * than an undocumented private API so the app does not need an API key.
 *
 * The page's "Opening odds" 1/X/2 values are used when they are available.
 * If AiScore cannot be matched, the core CIO prediction data is still shown.
 */
class AiScoreOddsService {
    data class Odds(
        val home: String,
        val draw: String,
        val away: String,
        val source: String = "AiScore"
    )

    private val http = HttpClient()

    suspend fun enrich(groups: List<SofaScoreService.MatchGroupData>): List<SofaScoreService.MatchGroupData> =
        coroutineScope {
            if (groups.isEmpty()) return@coroutineScope groups

            groups.chunked(6).flatMap { chunk ->
                chunk.map { group ->
                    async(Dispatchers.IO) {
                        val odds = findOdds(group.homeTeam, group.awayTeam)
                        group.copy(
                            odds = odds?.let {
                                SofaScoreService.Odds(
                                    home = it.home,
                                    draw = it.draw,
                                    away = it.away
                                )
                            }
                        )
                    }
                }.awaitAll()
            }
        }

    private fun findOdds(home: String, away: String): Odds? {
        val homeSlug = slug(home)
        val awaySlug = slug(away)
        if (homeSlug.isBlank() || awaySlug.isBlank()) return null

        // AiScore prediction URLs normally use away-vs-home ordering.
        val urls = listOf(
            "https://www.aiscore.com/en/prediction/football-$awaySlug-vs-$homeSlug-prediction",
            "https://www.aiscore.com/en/prediction/football-$homeSlug-vs-$awaySlug-prediction"
        ).distinct()

        for (url in urls) {
            val (code, body) = http.get(url, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue

            val odds = parseOdds(body, home, away)
            if (odds != null) return odds
        }
        return null
    }

    private fun parseOdds(html: String, home: String, away: String): Odds? {
        val doc = Jsoup.parse(html)
        val text = doc.text()
        val marker = Regex("Opening odds", RegexOption.IGNORE_CASE)
            .find(text) ?: return null

        // The first 3 decimal values after "Opening odds" are the 1/X/2
        // prices in AiScore's football prediction page.
        val tail = text.substring(marker.range.last + 1)
        val values = Regex("""(?<![\d.])(?:\d{1,3})(?:\.\d{1,2})(?![\d.])""")
            .findAll(tail)
            .map { it.value }
            .take(3)
            .toList()

        if (values.size != 3) return null

        // Avoid accidentally accepting handicap/O-U prices when the page
        // layout changes: 1X2 odds normally fall into a sane decimal range.
        val nums = values.mapNotNull { it.toDoubleOrNull() }
        if (nums.size != 3 || nums.any { it <= 1.0 || it > 100.0 }) return null

        return Odds(
            home = format(nums[0]),
            draw = format(nums[1]),
            away = format(nums[2])
        )
    }

    private fun format(value: Double): String =
        String.format(Locale.US, "%.2f", value)

    private fun slug(value: String): String {
        val lower = value
            .lowercase(Locale.US)
            .replace("&", " and ")
            .replace("ı", "i")
            .replace("İ", "i")
            .replace("ş", "s")
            .replace("Ş", "s")
            .replace("ğ", "g")
            .replace("Ğ", "g")
            .replace("ü", "u")
            .replace("Ü", "u")
            .replace("ö", "o")
            .replace("Ö", "o")
            .replace("ç", "c")
            .replace("Ç", "c")
            .replace("ø", "o")
            .replace("Ø", "o")
            .replace("æ", "ae")
            .replace("Æ", "ae")
            .replace("å", "a")
            .replace("Å", "a")

        return lower
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
    }
}
