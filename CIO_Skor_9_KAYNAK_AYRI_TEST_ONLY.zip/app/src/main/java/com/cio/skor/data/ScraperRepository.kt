package com.cio.skor.data

import com.cio.skor.data.parsers.BaseParser
import com.cio.skor.data.parsers.GenericParser
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/** Standalone test build containing ONLY the nine requested sources. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/", GenericParser("MightyTips")),
        Source("FootyStats", "https://footystats.org/predictions", GenericParser("FootyStats")),
        Source("GoalVertex", "https://www.goalvertex.com/correct-score-predictions", GenericParser("GoalVertex")),
        Source("NerdyTips", "https://nerdytips.com/", GenericParser("NerdyTips")),
        Source("Vitibet", "https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal", GenericParser("Vitibet")),
        Source("HuhSports", "https://www.huhsports.com/predictions", GenericParser("HuhSports")),
        Source("FootballAnt", "https://www.footballant.com/prediction/correct-score-predictions", GenericParser("FootballAnt")),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", GenericParser("DailySports")),
        Source("Statarea", "https://www.statarea.com/predictions", GenericParser("Statarea"))
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = http.get(source.url)
                    val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else emptyList()
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
