# CIO Skor - 9 Kaynak Ayrı Test

Bu ZIP bilinçli olarak yalnızca şu 9 kaynağı içerir:

1. MightyTips
2. FootyStats
3. GoalVertex
4. NerdyTips
5. Vitibet
6. HuhSports
7. FootballAnt
8. DailySports
9. Statarea

FP.com, FP.net, Forebet, PredictZ, WinDrawWin ve SoccerSeer bu test paketine dahil değildir.

Tarama sonunda her kaynağın HTTP kodu ve çıkardığı skor sayısı ekranda ayrı ayrı gösterilir. Bu paket 9 kaynağın bağımsız test edilmesi içindir.
