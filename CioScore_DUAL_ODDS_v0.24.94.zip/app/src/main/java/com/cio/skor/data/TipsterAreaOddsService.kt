package com.cio.skor.data

import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * API-free TipsterArea odds transport.
 *
 * It discovers the public match page from TipsterArea's date index and then
 * reads only the server-rendered "Leading Bookmakers Odds / Standard 1X2"
 * table. No JS/CAPTCHA/access-control bypass is attempted.
 */
class TipsterAreaOddsService {
    data class Odds(val bookmaker: String, val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()

    private val wantedBookmakers = linkedMapOf(
        "1xbet" to "1xBet",
        "bet-at-home" to "bet-at-home",
        "betfair" to "Betfair",
        "bwin" to "bwin",
        "unibet" to "Unibet"
    )

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        matchDate: String = ""
    ): List<Odds> {
        val detailUrl = discoverMatchUrl(homeTeam, awayTeam, matchDate) ?: return emptyList()
        val (code, body) = http.getSource(detailUrl, "https://tipsterarea.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return parseOdds(body)
    }

    private fun discoverMatchUrl(homeTeam: String, awayTeam: String, matchDate: String): String? {
        val dates = candidateDates(matchDate)
        val home = normalize(homeTeam)
        val away = normalize(awayTeam)

        for (date in dates) {
            val url = "https://tipsterarea.com/matches/date-${date.format(DateTimeFormatter.ISO_DATE)}"
            val (code, body) = http.getSource(url, "https://tipsterarea.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            val doc = Jsoup.parse(body)
            for (a in doc.select("a[href*='/match/']")) {
                val text = normalize(a.text())
                if (containsTeams(text, home, away)) {
                    return a.absUrl("href").ifBlank { "https://tipsterarea.com${a.attr("href")}" }
                }
            }
        }
        return null
    }

    private fun candidateDates(raw: String): List<LocalDate> {
        val base = runCatching {
            LocalDate.parse(raw.trim().take(10), DateTimeFormatter.ISO_DATE)
        }.getOrNull() ?: LocalDate.now()
        return listOf(base, base.minusDays(1), base.plusDays(1)).distinct()
    }

    private fun containsTeams(text: String, home: String, away: String): Boolean {
        if (home.isBlank() || away.isBlank()) return false
        val direct = text.contains(home) && text.contains(away)
        if (direct) return true
        val compact = text.replace("-", " ")
        return compact.contains(home) && compact.contains(away)
    }

    private fun parseOdds(html: String): List<Odds> {
        val doc = Jsoup.parse(html)
        val table = doc.select("table").firstOrNull { table ->
            table.text().contains("Standard 1X2", true) &&
                table.text().contains("1xbet", true)
        } ?: return emptyList()

        val rows = mutableListOf<Odds>()
        for (tr in table.select("tr")) {
            val cells = tr.select("th,td").map { it.text().trim() }.filter { it.isNotBlank() }
            if (cells.size < 4) continue
            val rawName = cells.first()
            val key = bookmakerKey(rawName) ?: continue
            val values = cells.drop(1).take(3).map(::cleanOdd)
            if (values.size == 3 && values.all { it != null }) {
                rows += Odds(wantedBookmakers.getValue(key), values[0]!!, values[1]!!, values[2]!!)
            }
        }

        // Some pages render bookmaker names as image alt text instead of cell text.
        // Jsoup's element text/ownText still sees the accessible alt-derived text
        // on the surrounding row in the server HTML; no JS execution is needed.
        return rows.distinctBy { it.bookmaker.lowercase(Locale.US) }
    }

    private fun bookmakerKey(name: String): String? {
        val n = normalize(name)
        return wantedBookmakers.keys.firstOrNull { key -> n == normalize(key) || n.contains(normalize(key)) }
    }

    private fun cleanOdd(value: String): String? {
        val normalized = value.replace(',', '.').trim()
        val number = normalized.toDoubleOrNull() ?: return null
        if (number <= 1.0 || number > 100.0) return null
        return String.format(Locale.US, "%.2f", number)
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
}
