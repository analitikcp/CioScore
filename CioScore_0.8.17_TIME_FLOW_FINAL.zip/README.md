CioScore 0.8.14

Başlama saati ScoreModel/MatchGroup içinde matchTime + timestamp olarak taşınır. Kaynak parser saatleri önce doldurur; MatchMerger saatleri koruyup timestamp ile sıralar; SofaScore yalnızca eksik saat için fallback sağlar. item_score.xml içindeki tvMatchTime her zaman görünür ve ScoreAdapter tarafından doğrudan bağlanır.
