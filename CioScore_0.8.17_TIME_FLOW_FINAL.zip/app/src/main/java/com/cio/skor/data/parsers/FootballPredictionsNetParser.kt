package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** FP.net Correct Score parser. Kept isolated so other working parsers are untouched. */
class FootballPredictionsNetParser : BaseParser("FootballPredictions.net") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // FP.net commonly exposes prediction content in articles/cards/tables.
        val blocks = doc.select("article, .prediction, .prediction-card, .match, .fixture, tr")

        for (block in blocks) {
            val text = clean(block.text())
            if (text.isBlank()) continue

            val score = extractLabeledScore(block) ?: continue
            val teams = extractTeams(block) ?: continue

            val home = cleanTeam(teams.first)
            val away = cleanTeam(teams.second)
            if (!valid(home, away)) continue
            if (looksNoisy(home) || looksNoisy(away)) continue

            val (matchTime, timestamp) = extractKickoff(block)
            val model = ScoreModel(home, away, score, source, matchTime, timestamp)
            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        return out.values.toList()
    }

    private fun extractLabeledScore(block: Element): String? {
        val selectors = listOf(
            ".correct-score", ".correct_score", ".predicted-score",
            ".predicted_score", ".score-prediction", ".prediction-score",
            ".score", "[class*=correct-score]", "[class*=predicted-score]"
        )

        for (selector in selectors) {
            val value = block.select(selector).firstOrNull()?.text()?.trim() ?: continue
            val score = score(value)
            if (score != null) return score
        }

        val labels = Regex(
            "(?is)(?:correct\\s*score|predicted\\s*score|prediction|scoreline)\\s*[:\\-]?\\s*([0-5]\\s*[-:]\\s*[0-5])"
        )
        return labels.find(block.text())?.groupValues?.getOrNull(1)?.let { score(it) }
    }

    private fun extractTeams(block: Element): Pair<String, String>? {
        val home = firstText(block,
            ".home-team", ".homeTeam", ".team-home", ".hometeam", "[class*=home-team]")
        val away = firstText(block,
            ".away-team", ".awayTeam", ".team-away", ".awayteam", "[class*=away-team]")

        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // FP.net fixture/article links often contain the two team names.
        val links = block.select("a[href]")
        for (link in links) {
            val visible = clean(link.text())
            val pair = splitTeams(visible)
            if (pair != null) return pair
        }

        return splitTeams(clean(block.text()))
    }

    private fun splitTeams(text: String): Pair<String, String>? {
        val cleaned = text
            .replace("\u00A0", " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val patterns = listOf(
            Regex("(?i)^(.+?)\\s+(?:v|vs|versus)\\s+(.+?)$"),
            Regex("^(.+?)\\s+[–—-]\\s+(.+?)$")
        )

        for (pattern in patterns) {
            val match = pattern.find(cleaned) ?: continue
            var home = match.groupValues[1]
            var away = match.groupValues[2]

            home = cleanTeam(home)
            away = cleanTeam(away)

            if (valid(home, away) && !looksNoisy(home) && !looksNoisy(away)) {
                return home to away
            }
        }
        return null
    }

    private fun firstText(block: Element, vararg selectors: String): String? {
        for (selector in selectors) {
            val value = block.select(selector).firstOrNull()?.text()?.trim()
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    private fun cleanTeam(value: String): String {
        return value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .replace(Regex("(?i)\\b(correct\\s*score|prediction|predicted\\s*score|odds|probability|betting tips?|preview|analysis|read more)\\b.*$"), "")
            .trim(' ', '-', '–', '—', ':', '|')
    }

    private fun looksNoisy(value: String): Boolean {
        return value.contains(Regex(
            "(?i)correct\\s*score|probability|odds|prediction|predicted\\s*score|betting tips?|preview|analysis|read more"
        ))
    }
}
