package com.cio.skor.data

import com.cio.skor.data.SofaScoreService

data class ScoreModel(
    val homeTeam: String,
    val awayTeam: String,
    val predictedScore: String,
    val source: String,
    /** Local kickoff time shown in the UI, e.g. 18:30. */
    val matchTime: String = "",
    /** Epoch seconds used only for chronological sorting. */
    val timestamp: Long = 0L
) {
    val matchKey: String get() = MatchMerger.key(homeTeam, awayTeam)
}

data class SourceResult(
    val source: String,
    val httpCode: Int,
    val scores: List<ScoreModel>,
    val error: String? = null
)

/** UI-facing unified fixture model. Kept in data layer so time is not UI-owned. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    val odds: SofaScoreService.Odds? = null,
    val matchTime: String = "",
    val timestamp: Long = 0L
)
