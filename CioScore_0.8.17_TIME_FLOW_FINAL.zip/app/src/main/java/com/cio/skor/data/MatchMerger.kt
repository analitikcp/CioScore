package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance
import java.text.Normalizer as JavaNormalizer

/**
 * Central place for team-name normalization and cross-source fixture merging.
 * All five sources are merged only AFTER their raw ScoreModel records are collected.
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    private val removableSuffixes = setOf("fc", "fk", "sk", "cd", "nk", "afc", "club")

    /**
     * Standardize a team name before any comparison:
     * lowercase -> transliterate accents/Turkish chars -> remove punctuation ->
     * remove common club suffix tokens -> collapse whitespace.
     */
    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        // Handle the remaining Latin accented characters consistently.
        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")

        value = value
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = value.split(' ')
            .filter { it.isNotBlank() && it !in removableSuffixes }

        return tokens.joinToString(" ").trim()
    }

    private fun compact(value: String): String =
        normalizeTeamName(value).replace(" ", "")

    /** Levenshtein based fuzzy comparison, with containment and 70% threshold. */
    /** Stable identity key after the same normalization used by matching. */
    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    fun isSameTeam(name1: String, name2: String): Boolean {
        val norm1 = compact(name1)
        val norm2 = compact(name2)

        if (norm1.isBlank() || norm2.isBlank()) return false
        if (norm1 == norm2) return true
        if (norm1.contains(norm2) || norm2.contains(norm1)) return true

        val maxLength = maxOf(norm1.length, norm2.length)
        if (maxLength == 0) return true

        val distance = levenshtein.apply(norm1, norm2)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.70
    }

    data class UnifiedMatch(
        val mainHomeTeam: String,
        val mainAwayTeam: String,
        val predictions: MutableList<ScoreModel> = mutableListOf(),
        var matchTime: String = "",
        var timestamp: Long = 0L
    )

    /**
     * Merge ALL raw source predictions into one fixture group when both
     * home and away teams match fuzzily. Source name is never part of identity.
     */
    fun mergeMatches(scrapedList: List<ScoreModel>): List<UnifiedMatch> {
        val unifiedMatches = mutableListOf<UnifiedMatch>()

        for (scraped in scrapedList) {
            val existingMatch = unifiedMatches.find { unified ->
                isSameTeam(unified.mainHomeTeam, scraped.homeTeam) &&
                    isSameTeam(unified.mainAwayTeam, scraped.awayTeam)
            }

            if (existingMatch != null) {
                // Keep one prediction per source inside the unified fixture.
                val sourceExists = existingMatch.predictions.any {
                    it.source.trim().equals(scraped.source.trim(), ignoreCase = true)
                }
                if (!sourceExists) {
                    existingMatch.predictions.add(scraped)
                }
                // TRUTH STANDARD:
                // 1) The first valid timestamp already attached to this fixture
                //    remains authoritative.
                // 2) If the fixture has no timestamp, a valid incoming timestamp
                //    becomes authoritative.
                // 3) If neither side has a timestamp, convert the first valid
                //    HH:mm source text to today's local epoch seconds.
                // 4) Whenever a timestamp exists, matchTime is regenerated from
                //    that timestamp. The two fields therefore cannot diverge.
                val existingTimestamp = existingMatch.timestamp.takeIf { it > 0L }
                val incomingTimestamp = scraped.timestamp.takeIf { it > 0L }

                val canonicalTimestamp = existingTimestamp
                    ?: incomingTimestamp
                    ?: parseTimeToTimestamp(existingMatch.matchTime)
                    ?: parseTimeToTimestamp(scraped.matchTime)
                    ?: 0L

                existingMatch.timestamp = canonicalTimestamp
                existingMatch.matchTime = if (canonicalTimestamp > 0L) {
                    formatTimestamp(canonicalTimestamp)
                } else {
                    existingMatch.matchTime.trim().ifBlank {
                        scraped.matchTime.trim()
                    }
                }
            } else {
                // New fixture: establish the same truth standard immediately.
                // Timestamp wins; otherwise an HH:mm source value is converted
                // to today's local epoch seconds so sorting remains deterministic.
                val initialTimestamp =
                    scraped.timestamp.takeIf { it > 0L }
                        ?: parseTimeToTimestamp(scraped.matchTime)
                        ?: 0L

                val initialMatchTime =
                    if (initialTimestamp > 0L) {
                        formatTimestamp(initialTimestamp)
                    } else {
                        scraped.matchTime.trim()
                    }

                unifiedMatches.add(
                    UnifiedMatch(
                        mainHomeTeam = scraped.homeTeam,
                        mainAwayTeam = scraped.awayTeam,
                        predictions = mutableListOf(scraped),
                        matchTime = initialMatchTime,
                        timestamp = initialTimestamp
                    )
                )
            }
        }

        // Final safety pass: timestamp is the single source of truth for
        // display whenever it exists.
        unifiedMatches.forEach { match ->
            if (match.timestamp > 0L) {
                // timestamp is the ONLY canonical value.
                match.matchTime = formatTimestamp(match.timestamp)
            } else {
                // Never return null/blank to the UI. This is deliberately a
                // display fallback; it does not create a fake sortable time.
                match.matchTime = match.matchTime.trim().ifBlank { "--:--" }
            }
        }

        return unifiedMatches.sortedWith(
            compareBy<UnifiedMatch> { it.timestamp == 0L }
                .thenBy { it.timestamp }
                .thenBy { it.mainHomeTeam.lowercase() }
        )
    }

    /**
     * Converts an HH:mm source value to today's local epoch seconds.
     *
     * The app's scan is explicitly for today's fixtures, so a plain source
     * clock value is anchored to today's local date. This is only a fallback
     * when the source did not provide a real timestamp.
     */
    private fun parseTimeToTimestamp(timeText: String): Long? {
        val text = timeText.trim()
        if (text.isBlank() || text == "--:--") return null

        // HH:mm / HH:mm:ss / HH.mm / HH.mm.ss / 12-hour AM/PM.
        val clock = Regex(
            """(?i)^\s*(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?\s*(am|pm)?\s*$"""
        ).matchEntire(text)

        if (clock != null) {
            val rawHour = clock.groupValues[1].toIntOrNull() ?: return null
            val minute = clock.groupValues[2].toIntOrNull() ?: return null
            val second = clock.groupValues[3].toIntOrNull() ?: 0
            val suffix = clock.groupValues[4].lowercase()

            val hour = when {
                suffix == "pm" && rawHour < 12 -> rawHour + 12
                suffix == "am" && rawHour == 12 -> 0
                else -> rawHour
            }

            if (hour !in 0..23 || minute !in 0..59 || second !in 0..59) return null

            return try {
                java.time.LocalDate.now()
                    .atTime(hour, minute, second)
                    .atZone(java.time.ZoneId.systemDefault())
                    .toEpochSecond()
            } catch (_: Exception) {
                null
            }
        }

        // ISO-8601 fallback: 2026-09-06T20:00:00Z / +03:00.
        return try {
            java.time.Instant.parse(text).epochSecond
        } catch (_: Exception) {
            try {
                java.time.LocalDateTime.parse(
                    text,
                    java.time.format.DateTimeFormatter.ISO_LOCAL_DATE_TIME
                ).atZone(java.time.ZoneId.systemDefault()).toEpochSecond()
            } catch (_: Exception) {
                null
            }
        }
    }

    /** Formats epoch seconds in the device's local timezone for UI display. */
    private fun formatTimestamp(timestamp: Long): String =
        java.time.format.DateTimeFormatter.ofPattern("HH:mm")
            .withZone(java.time.ZoneId.systemDefault())
            .format(java.time.Instant.ofEpochSecond(timestamp))
}
