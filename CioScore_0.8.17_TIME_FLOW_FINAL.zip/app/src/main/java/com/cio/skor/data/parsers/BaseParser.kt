package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

abstract class BaseParser(protected val source: String) {
    protected val scoreRegex = Regex("(?<!\\d)([0-5])\\s*[-:]\\s*([0-5])(?!\\d)")
    protected fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()
    protected fun score(s: String): String? = scoreRegex.find(s)?.let { "${it.groupValues[1]}-${it.groupValues[2]}" }
    protected fun team(s: String): String {
        var t = clean(s)
        t = t.replace(Regex("(?i)\\b(predictions?|preview|analysis|why this|correct score odds?|correct score|predicted scoreline|predicted score)\\b"), " ")
        t = t.replace(Regex("\\([^)]*\\)"), " ")
        t = t.replace(Regex("\\s+"), " ").trim(' ', '-', ':', '|')
        return t
    }
    protected fun valid(a: String, b: String): Boolean {
        if (a.length !in 2..60 || b.length !in 2..60) return false
        if (a.equals(b, true)) return false
        val bad = Regex("(?i)^(odds|prediction|predicted|correct score|avg goals|results?|best leagues?)$")
        return !bad.matches(a) && !bad.matches(b)
    }

    /**
     * Extract kickoff information from the actual source card. This is the
     * source-level time path; it does not depend on SofaScore matching.
     */
    protected fun extractKickoff(element: Element): Pair<String, Long> {
        /*
         * TIME FLOW FIX:
         * A kickoff is frequently stored on a child <time> element or in a
         * data-* attribute. element.attr(...) only checks the current node and
         * therefore misses those values. Inspect the element AND descendants.
         */
        val nodes = buildList {
            add(element)
            addAll(
                element.select(
                    "time, [datetime], [data-datetime], [data-start-timestamp], " +
                        "[data-timestamp], [startTimestamp], [data-kickoff], " +
                        "[data-match-time], [class*=time], [class*=kickoff], [class*=date]"
                )
            )
        }.distinct()

        val candidates = buildList {
            for (node in nodes) {
                add(node.text())
                listOf(
                    "datetime",
                    "data-datetime",
                    "data-start-timestamp",
                    "data-timestamp",
                    "startTimestamp",
                    "data-kickoff",
                    "data-match-time"
                ).forEach { attr ->
                    val value = node.attr(attr).trim()
                    if (value.isNotBlank()) add(value)
                }
            }
            // Last fallback: complete card text.
            add(element.text())
        }.map(::clean).filter { it.isNotBlank() }.distinct()

        // ------------------------------------------------------------
        // 1. Machine-readable epoch timestamps.
        // ------------------------------------------------------------
        for (candidate in candidates) {
            val numeric = candidate.toLongOrNull()
            if (numeric != null && numeric > 1_000_000_000L) {
                val seconds = if (numeric > 10_000_000_000L) numeric / 1000L else numeric
                return formatTimestamp(seconds) to seconds
            }
        }

        // ------------------------------------------------------------
        // 2. ISO-8601 timestamps, including offsets and fractional seconds.
        // ------------------------------------------------------------
        for (candidate in candidates) {
            val isoCandidates = listOf(
                candidate,
                Regex(
                    """\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?\b"""
                ).find(candidate)?.value.orEmpty()
            ).filter { it.isNotBlank() }

            for (iso in isoCandidates) {
                try {
                    val instant = Instant.parse(iso).epochSecond
                    return formatTimestamp(instant) to instant
                } catch (_: Exception) {
                    // Try a local ISO value without timezone below.
                    try {
                        val local = java.time.LocalDateTime.parse(
                            iso,
                            DateTimeFormatter.ISO_LOCAL_DATE_TIME
                        )
                        val instant = local.atZone(ZoneId.systemDefault()).toEpochSecond()
                        return formatTimestamp(instant) to instant
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // ------------------------------------------------------------
        // 3. Human-readable clock formats:
        //    20:00 / 20:00:00 / 20.00 / 8:00 PM / 8.00 PM
        // ------------------------------------------------------------
        val timePatterns = listOf(
            Regex("(?i)\\b(0?[0-9]|1[0-2])[:.]([0-5][0-9])(?:[:.]([0-5][0-9]))?\\s*(am|pm)\\b"),
            Regex("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)(?:[:.]([0-5]\\d))?\\b")
        )

        var foundTime: LocalTime? = null
        var foundDate: LocalDate? = null

        for (candidate in candidates) {
            for (pattern in timePatterns) {
                val m = pattern.find(candidate) ?: continue
                val hour = m.groupValues[1].toInt()
                val minute = m.groupValues[2].toInt()
                val second = m.groupValues.getOrNull(3)?.toIntOrNull() ?: 0
                val suffix = m.groupValues.getOrNull(4)?.lowercase(Locale.US)

                val adjusted = when {
                    suffix == "pm" && hour < 12 -> hour + 12
                    suffix == "am" && hour == 12 -> 0
                    else -> hour
                }

                foundTime = LocalTime.of(adjusted, minute, second)
                foundDate = extractDate(listOf(candidate))
                break
            }
            if (foundTime != null) break
        }

        if (foundTime == null) return "" to 0L

        val date = foundDate ?: run {
            val text = candidates.joinToString(" ").lowercase(Locale.US)
            when {
                text.contains("tomorrow") -> LocalDate.now().plusDays(1)
                text.contains("yesterday") -> LocalDate.now().minusDays(1)
                else -> LocalDate.now()
            }
        }

        val instant = ZonedDateTime
            .of(date, foundTime, ZoneId.systemDefault())
            .toEpochSecond()

        return DateTimeFormatter.ofPattern("HH:mm").format(foundTime) to instant
    }

    private fun extractDate(candidates: List<String>): LocalDate? {
        val patterns = listOf(
            Regex("\\b(20\\d{2})[-/](\\d{1,2})[-/](\\d{1,2})\\b"),
            Regex("\\b(\\d{1,2})[-/](\\d{1,2})[-/](20\\d{2})\\b")
        )
        for (text in candidates) for (p in patterns) {
            val m = p.find(text) ?: continue
            return try {
                if (m.groupValues[1].length == 4) {
                    LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
                } else {
                    LocalDate.of(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
                }
            } catch (_: Exception) { null }
        }
        return null
    }

    protected fun formatTimestamp(timestamp: Long): String =
        DateTimeFormatter.ofPattern("HH:mm")
            .withZone(ZoneId.systemDefault())
            .format(Instant.ofEpochSecond(timestamp))

    abstract fun parse(doc: Document): List<ScoreModel>
}
