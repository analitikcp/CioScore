# Bet365 TipsterArea integration

TipsterArea is probed for an explicitly labelled Bet365 Standard 1X2 row.
Only a real Bet365 row is accepted; bwin/Unibet/other bookmakers are never relabelled as Bet365.

# bwin regression guard

The TipsterArea request is shared between bwin and Bet365. bwin, SofaScore and the bwin Sports API race independently; the first valid real bwin 1X2 result is published immediately. A slow TipsterArea response cannot block bwin.

# Bet365 latency guard

Bet365 sources race independently. The first valid real Bet365 1X2 result is published without waiting for a slower source. Remaining requests are cancelled after a winner.
