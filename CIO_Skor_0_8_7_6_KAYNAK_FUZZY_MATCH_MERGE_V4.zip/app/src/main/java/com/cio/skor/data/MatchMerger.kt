package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance

/**
 * Cross-source fixture merger.
 * All raw predictions are collected first, then team names are normalized and
 * matched fuzzily so harmless source-name variations do not create duplicate
 * fixtures.
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    fun normalizeTeamName(name: String): String {
        var s = name.lowercase()
            .replace("ç", "c").replace("ğ", "g").replace("ı", "i")
            .replace("ö", "o").replace("ş", "s").replace("ü", "u")
            .replace("á", "a").replace("à", "a").replace("ä", "a")
            .replace("é", "e").replace("è", "e").replace("ë", "e")
            .replace("í", "i").replace("ì", "i").replace("ï", "i")
            .replace("ó", "o").replace("ò", "o")
            .replace("ú", "u").replace("ù", "u")
            .replace("ý", "y").replace("ñ", "n")
            .replace("š", "s").replace("ž", "z").replace("đ", "d")
            .replace("ð", "d").replace("þ", "th").replace("ß", "ss")
            .replace("æ", "ae").replace("œ", "oe").replace("ø", "o")

        s = s.replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\b(fc|fk|sk|cd|nk|afc)\\b"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val removable = setOf(
            "cf", "sc", "ac", "rc", "bv", "ks", "ss", "sv", "if", "bk",
            "mk", "as", "us", "ud"
        )
        s = s.split(' ').filter { it.isNotBlank() && it !in removable }.joinToString(" ")

        val aliases = mapOf(
            "jagiellonia bialystok" to "jagiellonia",
            "kairat almaty" to "kairat",
            "ferencvarosi" to "ferencvaros",
            "ferencvaros budapest" to "ferencvaros",
            "jablonec 97" to "jablonec",
            "riga football club" to "riga",
            "riga fc" to "riga",
            "ki klaksvik" to "klaksvik",
            "agf aarhus" to "aarhus",
            "aarhus gf" to "aarhus",
            "fc thun" to "thun",
            "nk rijeka" to "rijeka",
            "partizan belgrade" to "partizan",
            "inter club d escaldes" to "inter escaldes",
            "inter club descaldes" to "inter escaldes",
            "inter d escaldes" to "inter escaldes",
            "egnatia rogozhine" to "egnatia",
            "egnatia rogzhine" to "egnatia",
            "sint truidense" to "st truidense",
            "fc inter" to "inter turku",
            "manchester united" to "manutd",
            "manchester utd" to "manutd",
            "man utd" to "manutd",
            "manchester city" to "mancity",
            "man city" to "mancity",
            "tottenham hotspur" to "tottenham",
            "psv eindhoven" to "psv",
            "paris saint germain" to "psg",
            "paris sg" to "psg",
            "borussia dortmund" to "dortmund",
            "bayern munich" to "bayern",
            "bayern munchen" to "bayern"
        )

        return aliases[s] ?: s.replace(" ", "")
    }

    fun canonicalTeam(value: String): String = normalizeTeamName(value)

    /**
     * Same-team test: exact match, containment (Jablonec/Jablonec97), then
     * Levenshtein similarity >= 75%. Very short names require exact/containment
     * to avoid false positives such as unrelated two-letter clubs.
     */
    fun isSameTeam(name1: String, name2: String): Boolean {
        val a = normalizeTeamName(name1)
        val b = normalizeTeamName(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        if (a.contains(b) || b.contains(a)) return true
        val maxLength = maxOf(a.length, b.length)
        if (maxLength < 4) return false
        val distance = levenshtein.apply(a, b)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.75
    }

    fun key(home: String, away: String): String =
        normalizeTeamName(home) + "||" + normalizeTeamName(away)
}
