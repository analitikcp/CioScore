# CIO Skor 0.8.17 – Forebet working-source restoration

Base: CIO_Skor_APK_0_8_7_SOCCERSEER_OLD_WORKING_PARSER

Changes ONLY for Forebet connectivity/extraction:
- Forebet parser restored to the older working extraction approach.
- Supports .rcnt/.homeTeam/.awayTeam and Correct Score / forepr fields.
- Android cleartext traffic enabled because a redirect may downgrade HTTP.
- Other source parsers and UI are unchanged from the base.
