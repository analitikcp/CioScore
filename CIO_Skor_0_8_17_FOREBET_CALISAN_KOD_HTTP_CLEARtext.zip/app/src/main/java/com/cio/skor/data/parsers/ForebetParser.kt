package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser based on the older working Forebet extraction logic.
 *
 * Important: keep this parser intentionally conservative. It looks only at
 * match cards and prediction/score elements, never at arbitrary page-wide
 * score-looking numbers.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val found = LinkedHashMap<String, ScoreModel>()

        // Current Forebet match cards.
        val blocks = doc.select("div.rcnt")
            .ifEmpty { doc.select("div.rcnt[class*=tr_]") }
            .ifEmpty { doc.select("[class*=rcnt]") }

        for (block in blocks) {
            val home = teamText(block, ".homeTeam, .hometeam, [class*=homeTeam]") ?: continue
            val away = teamText(block, ".awayTeam, .awayteam, [class*=awayTeam]") ?: continue

            val cleanHome = cleanTeam(home)
            val cleanAway = cleanTeam(away)
            if (!valid(cleanHome, cleanAway)) continue

            val score = extractScore(block) ?: continue
            val model = ScoreModel(cleanHome, cleanAway, score, source)
            found[model.matchKey] = model
            if (found.size >= 80) break
        }

        return found.values.toList()
    }

    private fun teamText(block: Element, selector: String): String? {
        val el = block.select(selector).firstOrNull() ?: return null
        return (el.select("span").firstOrNull()?.text()?.takeIf { it.isNotBlank() }
            ?: el.text())
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .takeIf { it.isNotBlank() }
    }

    private fun extractScore(block: Element): String? {
        // First choice: Forebet Correct Score field.
        val correctSelectors = listOf(
            "div.ex_sc.tabonly",
            "div.ex_sc",
            ".ex_sc",
            "[class*=ex_sc]"
        )
        for (selector in correctSelectors) {
            for (el in block.select(selector)) {
                exactScore(el.text())?.let { return it }
            }
        }

        // Known fallback from the older working parser: Pred column.
        val predSelectors = listOf(
            "span.forepr",
            ".forepr",
            "[class*=forepr]"
        )
        for (selector in predSelectors) {
            for (el in block.select(selector)) {
                exactScore(el.text())?.let { return it }
            }
        }

        // Last fallback: only prediction/score-related elements inside the
        // current match card. Never scan the whole page.
        for (el in block.select("[class*=pred], [class*=score]")) {
            exactScore(el.text())?.let { return it }
        }
        return null
    }

    private fun exactScore(value: String): String? {
        val text = value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

        val m = Regex("^([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})$").matchEntire(text)
            ?: return null

        val home = m.groupValues[1].toIntOrNull() ?: return null
        val away = m.groupValues[2].toIntOrNull() ?: return null
        if (home !in 0..15 || away !in 0..15) return null
        return "$home-$away"
    }

    private fun cleanTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')
}
