package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Direct bwin.com football 1X2 reader.
 *
 * We intentionally use the public football page/event HTML instead of the
 * partner Sports API because the latter requires an affiliate AccessId and
 * AccessIdToken. The bwin football page currently renders Result 1X2 as
 * 1 / X / 2 decimal prices in the server response.
 */
class BwinOddsService {
    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    private val http = HttpClient()
    private val listingUrls = listOf(
        "https://www.bwin.com/en/sports/football-4/betting",
        "https://www.bwin.com/en/sports/football-4",
        "https://www.bwin.com/en/sports/football-4/today",
        "https://www.bwin.com/en/sports/football-4/tomorrow",
        "https://www.bwin.com/en/sports/football-4/after-2-days",
        "https://www.bwin.com/en/sports/football-4/after-3-days"
    )

    suspend fun fetchOdds(homeTeam: String, awayTeam: String): BookmakerOdds? =
        withContext(Dispatchers.IO) {
            val home = normalize(homeTeam)
            val away = normalize(awayTeam)
            if (home.isBlank() || away.isBlank()) return@withContext null

            for (url in listingUrls) {
                val (code, body) = http.get(url, "https://www.bwin.com/")
                if (code !in 200..299 || body.isNullOrBlank()) continue

                val href = findEventHref(body, home, away)
                if (href != null) {
                    val eventUrl = absoluteUrl(href)
                    val (eventCode, eventBody) = http.get(eventUrl, "https://www.bwin.com/")
                    if (eventCode in 200..299 && !eventBody.isNullOrBlank()) {
                        parseEventOdds(eventBody, home, away)?.let {
                            Log.d(TAG, "BWIN DIRECT $homeTeam - $awayTeam = ${it.ms1}/${it.msX}/${it.ms2}")
                            return@withContext it
                        }
                    }
                }

                // Fallback: some regional/listing variants expose the prices
                // immediately after the event link. Parse that local segment.
                parseListingOdds(body, home, away)?.let {
                    Log.d(TAG, "BWIN LISTING $homeTeam - $awayTeam = ${it.ms1}/${it.msX}/${it.ms2}")
                    return@withContext it
                }
            }

            Log.d(TAG, "BWIN DIRECT MISS $homeTeam - $awayTeam")
            null
        }

    private fun findEventHref(html: String, home: String, away: String): String? {
        val anchor = Regex(
            "<a[^>]+href=[\\\"']([^\\\"']*/sports/events/[^\\\"']+)[\\\"'][^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        for (match in anchor.findAll(html)) {
            val href = match.groupValues[1]
            val text = clean(match.groupValues[2])
            val n = normalize(text)
            val hrefNorm = normalize(href)
            // Bwin's current SSR markup often puts the team names in
            // attributes/route slugs rather than the anchor's visible text.
            // Match against both the anchor text and the event URL slug.
            if ((n.contains(home) && n.contains(away)) ||
                (hrefNorm.contains(home) && hrefNorm.contains(away))) return href
        }
        return null
    }

    private fun parseListingOdds(html: String, home: String, away: String): BookmakerOdds? {
        val anchor = Regex(
            "<a[^>]+href=[\\\"']([^\\\"']*/sports/events/[^\\\"']+)[\\\"'][^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
        )
        for (match in anchor.findAll(html)) {
            val text = clean(match.groupValues[2])
            val n = normalize(text)
            if (!n.contains(home) || !n.contains(away)) continue
            val start = match.range.last + 1
            val end = minOf(html.length, start + 12000)
            val segment = clean(html.substring(start, end))
            parseThreeWay(segment)?.let { return BookmakerOdds("Bwin", it.first, it.second, it.third) }
        }
        return null
    }

    private fun parseEventOdds(html: String, home: String, away: String): BookmakerOdds? {
        val cleanText = clean(html)
        val normalizedText = normalize(cleanText)
        if (!normalizedText.contains(home) || !normalizedText.contains(away)) return null

        // Current Bwin event pages render the main market as:
        //   [home] 5.00  X  4.00  [away] 1.50
        // and repeat the block. Anchor the extraction to the team names so
        // we do not accidentally consume a later BTTS/handicap market.
        val number = "([0-9]{1,3}(?:[.,][0-9]{1,3})?)"
        val homeRaw = Regex.escape(cleanTextToken(home))
        val awayRaw = Regex.escape(cleanTextToken(away))
        val teamPattern = Regex(
            "(?is)$homeRaw\\s+$number\\s+X\\s+$number\\s+$awayRaw\\s+$number"
        )
        teamPattern.find(cleanText)?.let { m ->
            val values = m.groupValues.drop(1).map { it.replace(',', '.') }
            if (values.size >= 3) return BookmakerOdds("Bwin", values[0], values[1], values[2])
        }

        // Fallback for pages whose markup inserts labels between team and
        // price; constrain the scan to a short window around the first home
        // team occurrence.
        val homeIndex = normalizedText.indexOf(home)
        if (homeIndex >= 0) {
            val start = maxOf(0, homeIndex - 120)
            val end = minOf(cleanText.length, homeIndex + 900)
            parseThreeWay(cleanText.substring(start, end))?.let {
                return BookmakerOdds("Bwin", it.first, it.second, it.third)
            }
        }
        return null
    }

    private fun parseThreeWay(text: String): Triple<String, String, String>? {
        val number = "([0-9]{1,3}(?:[.,][0-9]{1,3})?)"
        val patterns = listOf(
            Regex("\\b1\\s+$number\\s+X\\s+$number\\s+2\\s+$number\\b", RegexOption.IGNORE_CASE),
            Regex("$number\\s+X\\s+$number(?:\\s+[^0-9]{1,80})?$number", RegexOption.IGNORE_CASE)
        )
        for (pattern in patterns) {
            val m = pattern.find(text) ?: continue
            val values = m.groupValues.drop(1).map { it.replace(',', '.') }
            if (values.size >= 3) return Triple(values[0], values[1], values[2])
        }
        return null
    }

    private fun absoluteUrl(href: String): String = when {
        href.startsWith("http://") || href.startsWith("https://") -> href
        href.startsWith("/") -> "https://www.bwin.com$href"
        else -> "https://www.bwin.com/$href"
    }


    private fun cleanTextToken(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun clean(value: String): String = value
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun normalize(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace('ı', 'i')
        .replace('ş', 's')
        .replace('ğ', 'g')
        .replace('ü', 'u')
        .replace('ö', 'o')
        .replace('ç', 'c')
        .replace(Regex("[^a-z0-9]"), "")

    companion object {
        private const val TAG = "BwinOddsService"
    }
}
