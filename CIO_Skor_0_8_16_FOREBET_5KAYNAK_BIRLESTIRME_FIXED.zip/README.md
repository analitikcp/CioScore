# CIO Score 0.8.16

Bu sürüm iki çalışan parçayı aynı ZIP'te korur:

- **Forebet:** 0.8.14'teki daha geniş parser geri getirildi; `.rcnt/.homeTeam/.awayTeam`, eski `meta[itemprop=name]` ve `forepr/ex_sc` yolları korunur.
- **Forebet HTTP:** 0.8.15'teki mobil CIOScore User-Agent ilk sırada, masaüstü UA fallback olarak kalır.
- **Diğer bilinen çalışan kaynaklar:** FP.com, PredictZ, WinDrawWin, SoccerSeer.
- **Birleştirme:** 0.8.13'teki `MatchMerger` geri getirildi. Aynı maçın farklı yazımlarını alias + token + edit-distance ile eşleştirir ve aynı kaynağın iki kez aynı maça girmesini engeller.
- **UI:** Birleştirilmiş maçta her kaynağın skoru ayrı gösterilir; birden fazla kaynak aynı skoru verirse KONSENSÜS gösterilir.
- **GitHub Actions:** ZIP kökünde `.github/workflows/build-apk.yml` bulunur; `app` klasörünü doğrudan kökten bulur ve debug APK üretir.

Not: Uygulama 15 kaynaklık tarama havuzunu korur. Ekrandaki **"X kaynak • Y temiz skor"** sayısı gerçekten skor döndüren kaynakları gösterir. Forebet veri döndürdüğünde bu sayı 5'e çıkmalıdır.
