package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Forebet parser - hardened version.
 *
 * Forebet has used a few slightly different DOM layouts over time.  We keep
 * the normal .rcnt/.homeTeam/.awayTeam path, but also support the older
 * meta[itemprop=name] match label and the forepr prediction span.  Nothing
 * here changes the other source parsers.
 */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val blocks = doc.select("div.rcnt")
            .ifEmpty { doc.select("[class~=rcnt]") }
            .ifEmpty { doc.select("div[class*=rcnt]") }

        for (block in blocks) {
            val teams = extractTeams(block) ?: continue
            val cleanHome = cleanTeam(teams.first)
            val cleanAway = cleanTeam(teams.second)
            if (!valid(cleanHome, cleanAway)) continue

            val predictedScore = extractCorrectScore(block)
                ?: extractPredictedScore(block)
                ?: continue

            val model = ScoreModel(
                homeTeam = cleanHome,
                awayTeam = cleanAway,
                predictedScore = predictedScore,
                source = source
            )
            out[model.matchKey] = model
            if (out.size >= 80) break
        }

        return out.values.toList()
    }

    private fun extractTeams(block: Element): Pair<String, String>? {
        val home = firstText(block, ".homeTeam, .hometeam, [class*=homeTeam]")
        val away = firstText(block, ".awayTeam, .awayteam, [class*=awayTeam]")
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // Forebet's older layout exposes the complete fixture in meta name.
        val meta = block.select("meta[itemprop=name]").firstOrNull()
            ?.attr("content")
            ?.trim()
            ?.takeIf { it.isNotBlank() }
        if (meta != null) {
            val parts = meta.split(Regex("\\s+[-–—]\\s+"), limit = 2)
            if (parts.size == 2) return parts[0] to parts[1]
        }

        return null
    }

    private fun firstText(block: Element, selector: String): String? {
        val element = block.select(selector).firstOrNull() ?: return null
        return (element.select("span").firstOrNull()?.text()?.takeIf { it.isNotBlank() }
            ?: element.text())
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
            .takeIf { it.isNotBlank() }
    }

    private fun extractCorrectScore(block: Element): String? {
        val selectors = listOf(
            "div.ex_sc.tabonly",
            "div.ex_sc",
            ".ex_sc",
            "[class*=ex_sc]"
        )
        for (selector in selectors) {
            for (element in block.select(selector)) {
                exactScore(element.text())?.let { return it }
            }
        }
        return null
    }

    private fun extractPredictedScore(block: Element): String? {
        for (element in block.select("span.forepr, .forepr, [class*=forepr]")) {
            exactScore(element.text())?.let { return it }
        }

        // Last-resort fallback: only inspect the small prediction-related
        // elements, never arbitrary page-wide numbers.
        for (element in block.select("[class*=pred], [class*=score]")) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun exactScore(value: String): String? {
        val text = value
            .replace('\u00A0', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
        val match = Regex("^([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})$").matchEntire(text)
            ?: return null
        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    private fun cleanTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')
}
