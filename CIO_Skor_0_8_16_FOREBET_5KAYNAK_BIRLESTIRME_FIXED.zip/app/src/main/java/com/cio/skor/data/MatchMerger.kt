package com.cio.skor.data

import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

/** Merges parsed fixtures only. Source parsers are intentionally untouched. */
object MatchMerger {
    data class Group(val homeTeam: String, val awayTeam: String, val predictions: List<ScoreModel>)

    private data class TeamForm(
        val exact: String,
        val compact: String,
        val tokens: Set<String>,
        val base: String,
        val baseTokens: Set<String>
    )

    private val aliases = mapOf(
        "rapid vienna" to "rapid wien", "rapid wien" to "rapid wien",
        "athens aek" to "aek athens", "aek athens fc" to "aek athens", "aek athens" to "aek athens",
        "newcastle" to "newcastle united", "newcastle united" to "newcastle united",
        "west bromwich" to "west bromwich albion", "west bromwich albion" to "west bromwich albion",
        "nk celje" to "celje", "celje" to "celje",
        "nk slovan bratislava" to "slovan bratislava", "slovan bratislava" to "slovan bratislava",
        "man utd" to "manchester united", "manchester utd" to "manchester united",
        "spurs" to "tottenham", "tottenham hotspur" to "tottenham",
        "psv eindhoven" to "psv", "psv eindhoven fc" to "psv",
        "sporting lisbon" to "sporting cp", "sporting lisboa" to "sporting cp",
        "inter milan" to "internazionale", "internazionale milano" to "internazionale"
    )

    private val orgWords = setOf("football","soccer","club","fc","fk","cf","sc","afc","nk","ik","if","sv","sk","ac","ec","calcio","the","bsc","ks","kks")
    private val suffixes = setOf("city","united","town","rovers","wanderers","athletic","county","albion","hotspur","sporting","reserves","reserve","women","ladies","u21","u23","u19")

    fun merge(scores: List<ScoreModel>): List<Group> {
        val unique = scores.filter { it.homeTeam.isNotBlank() && it.awayTeam.isNotBlank() }
            .distinctBy { "${norm(it.homeTeam)}|${norm(it.awayTeam)}|${it.predictedScore.trim()}|${it.source.lowercase()}" }
        if (unique.isEmpty()) return emptyList()
        val parent = IntArray(unique.size) { it }
        val rank = IntArray(unique.size)
        val edges = ArrayList<Triple<Int,Int,Double>>()

        for (i in 0 until unique.size) for (j in i+1 until unique.size) {
            if (unique[i].source.equals(unique[j].source, true)) continue
            val sim = fixtureSimilarity(unique[i], unique[j])
            if (sim >= 0.86) edges += Triple(i,j,sim)
        }
        for ((a,b,_) in edges.sortedByDescending { it.third }) {
            val ra=find(parent,a); val rb=find(parent,b)
            if (ra==rb || sourceConflict(parent,unique,ra,rb)) continue
            union(parent,rank,ra,rb)
        }

        val map=LinkedHashMap<Int,MutableList<ScoreModel>>()
        unique.indices.forEach { i -> map.getOrPut(find(parent,i)){mutableListOf()}.add(unique[i]) }
        return map.values.map { list ->
            val ordered=list.sortedWith(compareBy<ScoreModel>{sourceRank(it.source)}.thenBy{norm(it.homeTeam)})
            Group(ordered.first().homeTeam, ordered.first().awayTeam, ordered)
        }.sortedWith(compareByDescending<Group>{it.predictions.size}.thenBy{norm(it.homeTeam)})
    }

    private fun fixtureSimilarity(a: ScoreModel,b: ScoreModel):Double {
        val direct=pairScore(teamSimilarity(a.homeTeam,b.homeTeam),teamSimilarity(a.awayTeam,b.awayTeam))
        val reverse=pairScore(teamSimilarity(a.homeTeam,b.awayTeam),teamSimilarity(a.awayTeam,b.homeTeam))
        return max(direct, if(reverse>=0.96) reverse*0.997 else 0.0)
    }

    private fun pairScore(a:Double,b:Double):Double {
        val low=min(a,b); val high=max(a,b)
        if(low<0.80) return 0.0
        if(low>=0.98) return 1.0
        if(low>=0.90 && high>=0.94) return low*0.6+high*0.4
        if(low>=0.84 && high>=0.96) return low*0.65+high*0.35
        return 0.0
    }

    private fun teamSimilarity(a:String,b:String):Double {
        val x=form(a); val y=form(b)
        if(x.exact.isBlank()||y.exact.isBlank()) return 0.0
        if(x.exact==y.exact || x.compact==y.compact) return 1.0
        val ax=aliases[x.exact]; val ay=aliases[y.exact]
        if(ax!=null && ay!=null && ax==ay) return 0.995
        if(ax!=null && ax==y.exact || ay!=null && ay==x.exact) return 0.995
        if(oneSidedSuffixMatch(x,y)) return 0.96

        val inter=x.baseTokens.intersect(y.baseTokens).size
        val union=x.baseTokens.union(y.baseTokens).size
        val jac=if(union==0) 0.0 else inter.toDouble()/union
        val lev=editSim(x.base,y.base)
        val containment=if(x.base.length>=5 && y.base.length>=5 && (x.base.contains(y.base)||y.base.contains(x.base))) 0.91 else 0.0
        return max(jac,max(lev,containment)).coerceAtMost(0.95)
    }

    private fun oneSidedSuffixMatch(a:TeamForm,b:TeamForm):Boolean {
        if(a.base==b.base) return a.exact!=b.exact
        val at=a.tokens; val bt=b.tokens
        if(at.size+1==bt.size && bt.containsAll(at)) return (bt-at).singleOrNull() in suffixes
        if(bt.size+1==at.size && at.containsAll(bt)) return (at-bt).singleOrNull() in suffixes
        return false
    }

    private fun form(value:String):TeamForm {
        val clean=normWords(value)
        val rawTokens=clean.split(' ').filter { it.isNotBlank() }
        val tokens=rawTokens.filter { it !in orgWords }.toSet()
        val baseTokens=tokens.toMutableSet()
        // Reserve/U-age markers are retained; they are meaningful for fixtures.
        val base=baseTokens.joinToString(" ")
        val exact=tokens.joinToString(" ")
        return TeamForm(exact,exact.replace(" ",""),tokens,base,baseTokens)
    }

    private fun normWords(value:String):String {
        var s=value.trim().lowercase()
            .replace("&"," and ").replace("ı","i").replace("ğ","g").replace("ü","u")
            .replace("ş","s").replace("ö","o").replace("ç","c")
        s=Normalizer.normalize(s,Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"),"")
        s=s.replace(Regex("[^a-z0-9]+")," ").trim()
        return s
    }
    private fun norm(value:String)=formRaw(value).replace(" ","")
    private fun formRaw(value:String):String {
        var s=normWords(value)
        val toks=s.split(' ').filter { it.isNotBlank() && it !in orgWords }
        return toks.joinToString(" ")
    }

    private fun editSim(a:String,b:String):Double {
        if(a==b) return 1.0
        val m=max(a.length,b.length); if(m==0)return 1.0
        return 1.0-lev(a,b).toDouble()/m
    }
    private fun lev(a:String,b:String):Int {
        if(a.isEmpty())return b.length; if(b.isEmpty())return a.length
        var p=IntArray(b.length+1){it}; var c=IntArray(b.length+1)
        for(i in a.indices){ c[0]=i+1; for(j in b.indices){ c[j+1]=minOf(c[j]+1,p[j+1]+1,p[j]+if(a[i]==b[j])0 else 1) }; val t=p;p=c;c=t }
        return p[b.length]
    }

    private fun sourceRank(s:String):Int=when {
        s.contains("fp.com",true)->0; s.contains("forebet",true)->1; s.contains("predictz",true)->2
        s.contains("windrawwin",true)->3; s.contains("soccerseer",true)->4; s.contains("footballpredictions.net",true)->5
        else->10
    }
    private fun find(p:IntArray,x:Int):Int { var r=x; while(p[r]!=r)r=p[r]; var y=x; while(p[y]!=y){val n=p[y];p[y]=r;y=n}; return r }
    private fun union(p:IntArray,r:IntArray,a:Int,b:Int){ if(a==b)return; if(r[a]<r[b])p[a]=b else {p[b]=a;if(r[a]==r[b])r[a]++} }
    private fun sourceConflict(p:IntArray,s:List<ScoreModel>,a:Int,b:Int):Boolean {
        for(i in s.indices) if(find(p,i)==a) for(j in s.indices) if(find(p,j)==b && s[i].source.equals(s[j].source,true)) return true
        return false
    }
}
