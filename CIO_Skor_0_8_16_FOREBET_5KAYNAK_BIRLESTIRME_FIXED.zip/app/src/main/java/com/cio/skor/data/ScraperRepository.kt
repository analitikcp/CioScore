package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    // BettingTipsToday is intentionally removed: its domain is no longer an active prediction source.
    // The known working parsers are kept unchanged; Forebet is handled separately with its dedicated HTTP path.
    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("FootballPredictions.net", "https://footballpredictions.net/correct-score-predictions-betting-tips", FootballPredictionsNetParser()),
        Source("Forebet", "https://www.forebet.com/en/football-tips-and-predictions-for-today/", ForebetParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("MightyTips", "https://www.mightytips.com/football-predictions/correct-score/", GenericParser("MightyTips")),
        Source("FootyStats", "https://footystats.org/predictions", GenericParser("FootyStats")),
        Source("GoalVertex", "https://www.goalvertex.com/", GenericParser("GoalVertex")),
        Source("NerdyTips", "https://nerdytips.com/", GenericParser("NerdyTips")),
        Source("Vitibet", "https://www.vitibet.com/", GenericParser("Vitibet")),
        Source("HuhSports", "https://www.huhsports.com/", GenericParser("HuhSports")),
        Source("FootballAnt", "https://www.footballant.com/", GenericParser("FootballAnt")),
        Source("DailySports", "https://www.dailysports.com/", GenericParser("DailySports")),
        Source("Statarea", "https://www.statarea.com/", GenericParser("Statarea"))
    )

    val sourceCount: Int get() = sources.size

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                try {
                    val (code, html) = if (source.name == "Forebet") http.getForebet(source.url) else http.get(source.url)
                    val scores = if (code in 200..299 && !html.isNullOrBlank()) {
                        source.parser.parse(Jsoup.parse(html, source.url))
                    } else {
                        emptyList()
                    }
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, code, scores, null)
                } catch (e: Exception) {
                    onProgress(index + 1, source.name)
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }
            }
        }.awaitAll()
    }
}
