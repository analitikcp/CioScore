package com.cio.skor.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityAndScoreRegressionTest {
    @Test fun teamAliasesResolveKnownVariants() {
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Man Utd") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("VfL Bochum", "Bochum") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("FSV Mainz 05", "Mainz") >= 0.80)
    }

    @Test fun seniorAndYouthTeamsDoNotCollapse() {
        assertFalse(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Manchester United U21") >= 0.95)
    }

    @Test fun renderableScoreContractRejectsTextualAndPartialValues() {
        assertTrue(ScoreModel.hasRenderablePrediction("1-0"))
        assertTrue(ScoreModel.hasRenderablePrediction(" 2 : 2 "))
        assertFalse(ScoreModel.hasRenderablePrediction("Home win"))
        assertFalse(ScoreModel.hasRenderablePrediction("1-"))
        assertFalse(ScoreModel.hasRenderablePrediction("TBD"))
    }
    @Test fun fourPredictionProvidersCollapseIntoOneFixtureWithFourPredictions() {
        val kickoff = 1_800_000_000_000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", kickoff),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", kickoff),
            ScoreModel("Manchester United", "Liverpool FC", "2:0", "WinDrawWin", "wdw-1", kickoff),
            ScoreModel("Man United", "Liverpool", "1-0", "DailySports", "ds-1", kickoff)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("All four prediction providers must form one fixture", unified.size == 1)
        assertTrue("The unified fixture must retain all four prediction sources", unified.single().predictions.size == 4)
        assertTrue(unified.single().predictions.map { it.first }.toSet().containsAll(
            setOf("FP.com", "PredictZ", "WinDrawWin", "DailySports")
        ))
    }


    @Test fun sameScheduleAndAwayTeamMergeEvenWhenHomeNamesDiffer() {
        val predictions = listOf(
            ScoreModel(
                homeTeam = "Example Home FC",
                awayTeam = "Shared Away FC",
                predictedScore = "2-1",
                source = "ProviderA",
                sourceMatchId = "a-1",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Premier League",
                competitionCountry = "England"
            ),
            ScoreModel(
                homeTeam = "Completely Different Home Name",
                awayTeam = "Shared Away FC",
                predictedScore = "1-0",
                source = "ProviderB",
                sourceMatchId = "b-1",
                matchTimestamp = 0L,
                matchDate = "30.10.2026",
                matchTime = "18:00",
                competitionName = "Premier League",
                competitionCountry = "England"
            )
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Same date + kickoff + league + identical away team must merge", unified.size == 1)
        assertTrue("Both provider predictions must survive the merge", unified.single().predictions.size == 2)
    }

    @Test fun sameTeamsOnDifferentDatesRemainSeparateFixtures() {
        val dayOne = 1_800_000_000_000L
        val dayTwo = dayOne + 24L * 60L * 60L * 1000L
        val predictions = listOf(
            ScoreModel("Manchester United", "Liverpool", "2-1", "FP.com", "fp-1", dayOne),
            ScoreModel("Man Utd", "Liverpool", "1-1", "PredictZ", "pz-1", dayTwo)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Different fixture dates must not collapse", unified.size == 2)
    }

    @Test fun predictionRemainsVisibleWhenNoIddaaFixtureExists() {
        val predictions = listOf(
            ScoreModel("Arsenal", "Chelsea", "2-1", "FP.com", "fp-1", 1_800_000_000_000L),
            ScoreModel("Arsenal", "Chelsea", "1-0", "PredictZ", "pz-1", 1_800_000_000_000L)
        )

        val unified = GlobalFixtureMatcher.merge(predictions, emptyList())

        assertTrue("Prediction-first data must survive without an Iddaa match", unified.size == 1)
        assertTrue(unified.single().predictions.size == 2)
        assertTrue(unified.single().officialMatch == null)
    }

    @Test fun sevenMSportParserReadsBet365OneXTwoRow() {
        val html = """
            <table>
              <tr><th>Match</th><th>Bookmaker</th><th>1</th><th>X</th><th>2</th></tr>
              <tr>
                <td><a>Manchester United</a> <a>Liverpool FC</a></td>
                <td>Bet365</td><td>2.10</td><td>3.60</td><td>3.20</td>
              </tr>
            </table>
        """
        val parsed = SevenMSportBet365Service().parse(html)
        val row = parsed.values.single()
        assertTrue(row.home == "Manchester United")
        assertTrue(row.away == "Liverpool FC")
        assertTrue(row.odds.ms1 == "2.10")
        assertTrue(row.odds.msX == "3.60")
        assertTrue(row.odds.ms2 == "3.20")
    }

    @Test fun chekiOddsParsesBet365FromExplicitBookmakerRow() {
        val html = """
            <div class="match-card">
              <h2>Austin v Real Salt Lake</h2>
              <div>1 3.10 Bet365 X 3.60 Bet365 2 2.20 Bet365</div>
              <table>
                <tr><th>Bookmaker</th><th>1</th><th>X</th><th>2</th></tr>
                <tr><td>Bet365</td><td>3.10</td><td>3.60</td><td>2.20</td></tr>
              </table>
            </div>
        """
        val index = ChekiOddsBet365Service().parsePageIndex(html)
        assertTrue(index != null)
        val row = index!!.rows.single()
        assertTrue(row.home == "Austin")
        assertTrue(row.away == "Real Salt Lake")
        assertTrue(row.odds == listOf("3.10", "3.60", "2.20"))
    }

}

