# CioScore v0.9.13 — Deep Alias + Compact Diagnostic

- Broadmeadow aliases expanded: Broadmeadow, Broadmeadow FC, Broadmeadow Magic, Broadmeadow Magic FC, Broadmeadow Magic NNSW, Broadmeadow NNSW variants canonicalize to `broadmeadow magic`.
- Adelaide City / Adelaide City FC / Adelaide City SC canonicalize to `adelaide city`.
- Existing two-sided identity and schedule/competition gates remain active; this does not introduce a generic one-sided fuzzy acceptance rule.
- Diagnostic report reduced to a true summary: match counts, problem counts, failed parsers, official count/date, and max 6 distinct problematic examples.
- Removed routine per-source health dump and long diagnostic distributions from the copied/displayed report.
- versionCode 297 / versionName 0.9.13.
