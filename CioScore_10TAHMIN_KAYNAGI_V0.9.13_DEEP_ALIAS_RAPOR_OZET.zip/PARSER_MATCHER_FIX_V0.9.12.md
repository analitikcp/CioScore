# CioScore v0.9.12 — Matcher + Compact Diagnostic

- Broadmeadow Magic / Broadmeadow Magic FC / Broadmeadow Magic NNSW variants explicitly canonicalized.
- Adelaide City / Adelaide City FC explicitly canonicalized.
- Matcher pipeline: v0.25.49-CLUB-ALIAS-SCHEDULE-IDENTITY-V6.0.
- Alias acceptance remains two-sided and schedule/competition gates remain active; one-sided fuzzy matches are not accepted.
- Scan diagnostic is now compact: summary counts, only problem categories, source health, and max 8 problematic examples.
- Removed long reverse-coverage and full official-not-matched dumps from the visible/copy report.
