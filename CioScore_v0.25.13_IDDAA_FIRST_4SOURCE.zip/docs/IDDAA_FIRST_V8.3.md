# CioScore — İddaa First Fixture Assembly V8.3

## Amaç

İddaa futbol bülteni ana/master fixture evrenidir. APK'deki maç kartları prediction-first değil, **Iddaa-first** oluşturulur.

Her resmi İddaa fixture'ı tam olarak bir ana kart üretir. FP.com, PredictZ, WinDrawWin ve DailySports tahminleri bu karta bağımsız olarak bağlanır.

## Kurallar

1. İddaa fixture'ı kartın kimliğidir.
2. Her resmi İddaa fixture'ı eşleşen tahmin olmasa bile UI'da kalır.
3. Her prediction source, İddaa fixture'larına bağımsız eşleştirilir.
4. Provider A'nın eşleşmesi Provider B'nin eşleşmesine bağlı değildir.
5. Aynı provider prediction kaydı iki farklı İddaa fixture'ına atanamaz.
6. Aynı İddaa fixture'ında her provider için en fazla bir prediction tutulur.
7. Aday çiftler confidence sırasıyla atanır; daha güçlü eşleşme zayıf eşleşme tarafından çalınmaz.
8. Tahmin bulunamazsa ilgili kaynak kartta boş kalır; İddaa maçı silinmez.
9. Yeni bir skor kaynağı eklenmez; mevcut dört kaynak korunur.

## Beklenen tanı metrikleri

- İddaa toplam fixture sayısı
- 4/4 kaynak eşleşen fixture sayısı
- 3/4, 2/4, 1/4 kaynak eşleşen fixture sayıları
- 0/4 kaynak eşleşen resmi fixture sayısı

Bu yapı "kaç prediction bulundu?" yerine "İddaa bülteninin kaç maçı kaç kaynakla eşleşti?" sorusunu ölçer.
