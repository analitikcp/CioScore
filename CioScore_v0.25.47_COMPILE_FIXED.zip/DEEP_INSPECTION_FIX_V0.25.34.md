# CioScore v0.25.34 — Deep Team Identity Hardening

## Problem
Provider names such as `VfL Bochum`, `Bochum`, `FSV Mainz 05`, `Mainz 05`, and `Mainz` could resolve to different canonical identities because German club-form prefixes were not treated consistently by the canonicalizer and fingerprint layer.

This could split one real fixture across provider components, causing the main card to expose only one provider prediction even when multiple sources described the same match.

## Fix
- Added high-confidence German club-form prefixes (`VfL`, `VfB`, `FSV`, `TSV`, `SSV`, `BSG`, `CFC`, `KFC`, `SG`, `SpVgg`) to the generic metadata-token layer.
- Added explicit high-confidence aliases for `VfL Bochum`, `FSV Mainz`, and `FSV Mainz 05`.
- Applied the same prefix semantics to `TeamFingerprintExtractor`, so canonical identity and fingerprint identity cannot disagree on these forms.
- Kept youth/reserve tiers separate; the change does not remove `U21/U19/II/III/Reserve/B` tier information.
- Kept distinctive descriptors such as `United`, `City`, `Town`, `Athletic`, `Real`, etc. identity-bearing.
- Bumped matcher signature to `CIO-REAL-GENERIC-V5.5` and canonical pipeline to `v0.25.34-TEAM-IDENTITY-TIER-SAFE-V5.6`.

## Regression targets
Expected canonical equivalence:
- `VfL Bochum` == `Bochum`
- `VFL Bochum` == `Bochum`
- `FSV Mainz 05` == `Mainz 05` == `Mainz`

Expected non-equivalence examples:
- `Manchester City` != `Manchester United`
- `Flora Tallinn` != `Flora Tallinn U21`
- `Tartu JK Welco` != `Tartu`

## Scope
No broad substring/stemming or city-name deletion was introduced. The change is intentionally limited to high-confidence German club-form metadata and explicit verified aliases.
