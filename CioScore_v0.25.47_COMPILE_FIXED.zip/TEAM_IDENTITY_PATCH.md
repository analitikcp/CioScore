# CioScore v0.25.27 — Team Identity Diagnostic Fix

## 2026-10-26 scan findings

Fixed four real canonicalization/alias gaps reported by the v0.25.26 diagnostic:

- `Al Ahli` ↔ `Ahli Saudi`
- `Al-Gharafa` ↔ `AL Gharraf SC`
- `Al Qadsiah` ↔ `AL Qadisiyah FC`
- `Salford` ↔ `Salford City`
- `Zalgiris` ↔ `Zalgiris Vilnius` (explicit alias; `Kauno Zalgiris` remains `zalgiris-kaunas`)

These are explicit full-name aliases only; no generic substring/stemming rule was introduced.

## Safety regression checks

- `Bayer Leverkusen` ≠ `Bayer Leverkusen II`
- `Flora Tallinn` ≠ `Flora II`
- `Kauno Zalgiris` ≠ bare `Zalgiris`

## Official bulletin scope

The 14 FP.com `NO_OFFICIAL_CANDIDATE` items are not team-name failures. The supplied diagnostic shows the official bulletin window is `26.10.2026 06:00 → 27.10.2026 06:00`, while those fixtures are outside that window (`PREDICTION_OUTSIDE_06_00`). They must remain excluded from official-Iddaa enrichment unless the product policy intentionally changes the bulletin window.

## Validation

The modified TeamAliasCanonicalizer and its fingerprint dependencies compile with Kotlin/JVM, and the explicit alias/tier regression cases above pass. Full Android Gradle compilation still depends on the external Gradle distribution being available in the build environment.
