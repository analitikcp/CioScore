# CioScore v0.25.32 — Deep Inspection Hardening

## Critical repairs

- Synchronized project/build metadata to version 0.25.32 / versionCode 258.
- Repaired `BaseParser.extractPageDate()` so `today` uses a true regex word boundary (`\\btoday\\b`).
- Removed the unsafe last-mile cross-kickoff fixture merge in `MainActivity.coalesceDisplayGroups()`.
- Removed `maxOf(existing.matchTimestamp, incoming.matchTimestamp)` from final fixture identity handling.
- Preserved official Iddaa timestamp preference only inside an already identical canonical HOME/AWAY + kickoff-minute key.
- Updated CI hard-source guards to validate the actual ScoreAdapter render gate and the new source invariants.

## Identity policy

`GlobalFixtureMatcher` is the authoritative fixture reconciliation layer. The final UI coalescer is now intentionally conservative and cannot manufacture a fixture identity by merging two different kickoff times.

## Build note

A clean Gradle build should be run in GitHub Actions/another networked Android build environment. The offline analysis environment may not have the Gradle distribution or Maven artifacts required for a full compile.
