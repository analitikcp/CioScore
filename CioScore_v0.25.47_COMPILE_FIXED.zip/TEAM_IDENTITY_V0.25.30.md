# CioScore v0.25.30 — Official Bulletin Reconciliation Fix

## Purpose
The 2026-10-27 scan diagnostic showed 13 `ALIAS_STEMMING_PROBLEM` cases causing otherwise equivalent prediction/official fixture names to remain separate. This patch adds explicit, narrow aliases for the observed provider variants.

## Fixed examples
- Mainz 05 ↔ Mainz
- Ciudad de Lucena ↔ Ciudad Lucena
- Rayo Majadah ↔ Rayo Majadahonda
- Billericay ↔ Billericay Town
- Hampton & Richmond ↔ Hampton and Richmond
- Dover ↔ Dover Athletic
- Chelmsford C ↔ Chelmsford City
- Radcliffe ↔ Radcliffe Borough
- Walton & Hersham FC ↔ Walton and Hersham
- US Catanzaro 1929 ↔ Catanzaro
- Virtus Entella ↔ Entella
- Leicester City ↔ Leicester
- Wigan Athletic ↔ Wigan
- Luton Town ↔ Luton
- Oxford ↔ Oxford United
- Stockport ↔ Stockport County
- Cambridge ↔ Cambridge United

## Safety
- No generic substring/stemming rule was added.
- Youth/reserve tiers remain part of the identity and are not merged with senior teams.
- `Cambridge U21` remains distinct from `Cambridge United` in regression testing.
- The remaining `NO_OFFICIAL_CANDIDATE` cases are not converted into false official matches; they require a separate official-feed/bulletin investigation.

## Validation
The TeamAliasCanonicalizer Kotlin/JVM regression suite passed for all listed reconciliation pairs. Full Android Gradle build was not run because the environment cannot download the configured Gradle 9.5.0 distribution.
