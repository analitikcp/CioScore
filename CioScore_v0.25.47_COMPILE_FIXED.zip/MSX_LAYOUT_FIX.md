# v0.25.29 — MS X Adayları ekran kalibrasyon düzeltmesi

- XCandidateActivity edge-to-edge system bar inset desteği eklendi.
- Status bar yüksekliği üst padding'e dahil ediliyor; başlık artık saat/ikonların altından başlıyor.
- Navigation bar yüksekliği alt padding'e dahil ediliyor; son maç kartı ve skor satırı sistem gezinme çubuğunun altında kalmıyor.
- RecyclerView alt padding'i ayrıca korunuyor.
- Ana ekranın mevcut layout/inset mantığı değiştirilmedi.
