# CioScore v0.25.31 — MS X ekranı kalibrasyon / navigation-safe-area düzeltmesi

## Problem
MS X Adayları ekranında Android 15/16 edge-to-edge nedeniyle üst başlık sistem çubuğuna çok yaklaşabiliyor ve alt kartın butonları/navigation alanı sistem gezinme çubuğunun altında kalabiliyordu.

## Fix
- `XCandidateActivity` için status/navigation/display-cutout insetleri uygulanmaya devam ediyor.
- RecyclerView sonuna gerçek bir `bottomSafeSpacer` eklendi.
- Spacer yüksekliği minimum 104dp, navigation inset daha büyükse `navigationBottom + 24dp` olacak.
- RecyclerView ayrıca 16dp iç alt boşluk taşıyor.
- Böylece son kartın `İDDAA BÜLTENİNDE AÇ`, `TAHMİN`, `Skor Analiz` bölümleri navigation bar'ın altında kalmıyor.
- Başlık alanı 56dp -> 50dp küçültülerek içerik için ek dikey alan kazanıldı.
- Version: 0.25.31 / versionCode 257.

## Not
Tam Android Gradle APK derlemesi ortamın Gradle dağıtım indirme erişimine bağlıdır. Kod değişikliği ZIP içine işlendi.
