# v0.25.28 — MS X Adayları ekranı

- Ana ekrana `MS X ADAYLARI` butonu eklendi.
- Tarama sonrası oluşan `MatchGroup` listesi uygulama içi oturum deposuna aktarılıyor.
- Ayrı `XCandidateActivity` ekranı yalnızca en az bir kaynağın beraberlik skoru verdiği maçları gösteriyor.
- X skoru: `0-0`, `1-1`, `2-2` vb. eşit ev/deplasman skorları.
- Mevcut `GlobalFixtureMatcher`, Team Identity ve İddaa zenginleştirmesi değiştirilmedi.
- Aynı birleşik maç tek kart olarak kalıyor; sadece filtrelenmiş görünüm açılıyor.
- Gelecek zamanlı maç ve render edilebilir skor güvenlik filtresi `ScoreAdapter` tarafından korunuyor.
