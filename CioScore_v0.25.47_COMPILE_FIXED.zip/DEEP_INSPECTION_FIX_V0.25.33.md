# CioScore v0.25.33 — MS X Odds Panel Repair

## Root cause
`XCandidateActivity` constructed `ScoreAdapter` with an empty `onOddsClick = { }` callback. The main screen correctly wired `onOddsClick` to its odds bottom-sheet, but the dedicated MS X screen did not. Therefore tapping `📊 ORANLAR` on an X-candidate card did nothing.

## Fix
- Added a lifecycle-bound coroutine scope to `XCandidateActivity`.
- Added the same independent `OddsPanelService` bottom-sheet flow used by `MainActivity`.
- Wired `onOddsClick = { match -> showOddsPanel(match) }`.
- Wired `onExternalOddsRequest` to a serialized SofaScore Bet365 queue with two retries, matching the main screen behavior.
- The queue removes completed keys even after the final failed attempt, preventing permanent de-duplication.
- Cancels the X-screen coroutine scope in `onDestroy()`.

## Version
- `versionName`: 0.25.33
- `versionCode`: 259
