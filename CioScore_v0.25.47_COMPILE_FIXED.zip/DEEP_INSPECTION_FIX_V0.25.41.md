# CioScore v0.25.41 — Minimal Safe Diagnostic Fix

- `officialOnlyFixtureCount` no longer reports a hard-coded `0`; it is derived only from actual bidirectional coverage diagnostics.
- No synthetic/fake fixtures, scores, odds, teams, or kickoff values were added.
- Team-history API naming now matches behavior (`getLastTenByTeamId`); runtime behavior is unchanged.
- No matcher thresholds, kickoff gates, source parsers, odds logic, or UI filtering rules were changed.
- Build verification was attempted, but the environment could not download Gradle 9.5.0 because external DNS/network access was unavailable.
