# v0.25.35 — Team Identity / Exact Official Recovery

## Root-cause correction

The v0.25.34 alias additions were insufficient because the global matcher could still reject an exact canonical provider/official pair before clustering when provider metadata contained an explicit date/competition contradiction. That left the same official fixture in a separate prediction component, so the main card could show only one source even though the scan parsed several providers.

## Fixes
- Added safe leading ordinal handling for names such as `1. FSV Mainz 05` and `1. FC ...`.
- Added explicit `VfL Bochum 1848` / `1. FSV Mainz 05` aliases.
- Added PASS 5 exact-official recovery in `GlobalFixtureMatcher`.
- Recovery requires a unique official fixture with exact canonical HOME/AWAY identity, matching reserve/youth tier, and equal calendar date when both dates exist.
- Provider kickoff/competition differences no longer split an exact official fixture after identity is proven; they remain provider metadata and the official record remains authoritative for final display.
- Existing components are only bridged when every member preserves the same exact canonical HOME/AWAY identity and calendar date.

## Safety
This is not a generic fuzzy merge. No one-sided team match, city-only match, substring match, or cross-date merge is introduced. Ambiguous multiple official fixtures with the same canonical HOME/AWAY key are not auto-recovered.
