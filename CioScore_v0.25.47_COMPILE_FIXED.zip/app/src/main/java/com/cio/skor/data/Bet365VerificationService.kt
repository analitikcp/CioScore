package com.cio.skor.data

/**
 * Single Bet365 truth policy for every UI surface.
 *
 * Bet365 is rendered only when AiScore and Flashscore identify the same market
 * and all three 1X2 prices are within the configured tolerance. No surface may
 * bypass this gate by calling SofaScore directly.
 */
class Bet365VerificationService {
    private val dualSource = DualSourceBet365Service()

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        expectedDate: String? = null
    ): SofaScoreService.BookmakerOdds? {
        val verified = dualSource.fetch(homeTeam, awayTeam, expectedDate) ?: return null
        return SofaScoreService.BookmakerOdds(
            bookmaker = "Bet365",
            ms1 = verified.ms1,
            msX = verified.msX,
            ms2 = verified.ms2
        )
    }
}
