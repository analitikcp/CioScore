package com.cio.skor.data

import java.util.UUID

data class DropReason(
    val stage: PipelineStage,
    val reasonCode: String,
    val count: Int,
    val details: List<String> = emptyList()
)

enum class PipelineStage {
    HTTP, PARSER, NORMALIZATION, IDENTITY, CONFIDENCE, MERGE, IDDAA_ENRICHMENT, UI
}

data class ParserHealthReport(
    val sourceName: String,
    val httpCode: Int,
    val rawHtmlBytes: Int,
    val parsedCount: Int,
    val durationMs: Long,
    val status: ParserStatus,
    val errorMessage: String? = null
)

enum class ParserStatus { HEALTHY, DEGRADED, FAILED, DOM_CHANGED }

data class UnmatchedDiagnosticItem(
    val predictionHome: String,
    val predictionAway: String,
    val bestOfficialHome: String?,
    val bestOfficialAway: String?,
    val homeSimilarity: Double,
    val awaySimilarity: Double,
    val homeCanonicalPrediction: String = "",
    val homeCanonicalOfficial: String = "",
    val awayCanonicalPrediction: String = "",
    val awayCanonicalOfficial: String = "",
    val combinedSimilarity: Double = 0.0,
    val dateDifferenceDays: Int = 0,
    val probableReason: UnmatchedReason
)

enum class UnmatchedReason {
    OFFICIAL_BULLETIN_ABSENT,
    NO_OFFICIAL_CANDIDATE,
    NAME_MISMATCH,
    DATE_MISMATCH,
    TIME_MISMATCH,
    COMPETITION_MISMATCH,
    AMBIGUOUS_OFFICIAL_CANDIDATE,
    METADATA_MISSING,
    ALIAS_STEMMING_PROBLEM
}

data class OfficialFeedDiagnostics(
    val httpEvents: Int,
    val httpMarketConfig: Int,
    val rawEventCount: Int,
    val parsedEventCount: Int,
    val timestampedEventCount: Int,
    val bulletinEventCountBeforeMerge: Int,
    val mergedFixtureCount: Int,
    val bulletinDate: String = "",
    val bulletinWindow: String = "",
    val marketMatches: Int,
    val error: String? = null,
    val dateDistribution: List<String> = emptyList(),
    val sampleFixtures: List<String> = emptyList()
)


/** Bidirectional coverage of the official bulletin against each parsed prediction source. */
data class PredictionSourceCoverageItem(
    val officialHome: String,
    val officialAway: String,
    val source: String,
    val status: PredictionCoverageStatus,
    val bestPredictionHome: String = "",
    val bestPredictionAway: String = "",
    val homeSimilarity: Double = 0.0,
    val awaySimilarity: Double = 0.0,
    val combinedSimilarity: Double = 0.0,
    val reason: String = ""
)

enum class PredictionCoverageStatus {
    MATCHED,
    SOURCE_PRESENT_BUT_UNMATCHED,
    SOURCE_ABSENT_FROM_PARSED_DATA
}

data class PredictionSourceCoverage(
    val officialFixtureCount: Int,
    val sourceNames: List<String>,
    val matchedBySource: Map<String, Int> = emptyMap(),
    val presentButUnmatchedBySource: Map<String, Int> = emptyMap(),
    val absentBySource: Map<String, Int> = emptyMap(),
    val details: List<PredictionSourceCoverageItem> = emptyList()
)

data class ScanTrace(
    val scanId: String = UUID.randomUUID().toString().take(8).uppercase(),
    val timestamp: Long = System.currentTimeMillis(),
    val parserReports: List<ParserHealthReport>,
    val stageMetrics: Map<PipelineStage, Int>,
    val dropReasons: List<DropReason>,
    val totalDurationMs: Long,
    val unmatchedOfficialDiagnostics: List<UnmatchedDiagnosticItem> = emptyList(),
    val officialFeedDiagnostics: OfficialFeedDiagnostics? = null,
    val predictionFixtureCount: Int = 0,
    val officialMatchedPredictionCount: Int = 0,
    val officialOnlyFixtureCount: Int = 0,
    val predictionNotInIddaaCount: Int = 0,
    val predictionNotInIddaaDetails: List<String> = emptyList(),
    val predictionNotInIddaaBySource: Map<String, Int> = emptyMap(),
    val predictionNotInIddaaByReason: Map<String, Int> = emptyMap(),
    val metadataCompleteBySource: Map<String, Int> = emptyMap(),
    val metadataTotalBySource: Map<String, Int> = emptyMap(),
    val metadataPartialBySource: Map<String, Int> = emptyMap(),
    val predictionOutsideBulletinCount: Int = 0,
    val predictionOutsideBulletinBySource: Map<String, Int> = emptyMap(),
    val predictionOutsideBulletinDetails: List<String> = emptyList(),
    val pastMatchFilteredCount: Int = 0,
    val pastMatchFilteredDetails: List<String> = emptyList(),
    val missingKickoffCount: Int = 0,
    val missingKickoffBySource: Map<String, Int> = emptyMap(),
    val reconciledKickoffCount: Int = 0,
    val reconciledKickoffBySource: Map<String, Int> = emptyMap(),
    val predictionSourceCoverage: PredictionSourceCoverage? = null
)
