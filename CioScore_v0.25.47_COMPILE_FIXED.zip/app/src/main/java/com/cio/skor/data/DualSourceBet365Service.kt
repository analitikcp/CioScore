package com.cio.skor.data

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Bet365 source gate: AiScore + Flashscore are the only primary sources.
 * A Bet365 row is returned only when both sources identify the same fixture and
 * their 1X2 prices are close enough to represent the same live market snapshot.
 */
class DualSourceBet365Service {
    data class Odds(
        val ms1: String,
        val msX: String,
        val ms2: String,
        val source: String = "AiScore+Flashscore"
    )

    private val aiScore = AiScoreOddsService()
    private val flashscore = FlashscoreOddsService()

    suspend fun fetch(homeTeam: String, awayTeam: String, expectedDate: String? = null): Odds? =
        coroutineScope {
            val ai = async(Dispatchers.IO) { runCatching { aiScore.fetch(homeTeam, awayTeam, expectedDate) }.getOrNull() }
            val fs = async(Dispatchers.IO) { runCatching { flashscore.fetchBookmakerOdds(homeTeam, awayTeam).firstOrNull() }.getOrNull() }
            val a = ai.await()
            val f = fs.await()

            if (a == null || f == null) {
                Log.d(TAG, "Bet365 verification failed: AiScore=${a != null} Flashscore=${f != null} $homeTeam - $awayTeam")
                return@coroutineScope null
            }

            if (!withinTolerance(a.ms1, f.ms1) || !withinTolerance(a.msX, f.msX) || !withinTolerance(a.ms2, f.ms2)) {
                Log.w(TAG, "Bet365 disagreement: AiScore=${a.ms1}/${a.msX}/${a.ms2} Flashscore=${f.ms1}/${f.msX}/${f.ms2} $homeTeam - $awayTeam")
                return@coroutineScope null
            }

            // Do not average/synthesize odds. Prefer Flashscore's exact row because
            // its feed is explicitly bookmaker-labelled and is the freshest direct
            // 1X2 feed in this app; AiScore remains the independent confirmation.
            Odds(f.ms1, f.msX, f.ms2)
        }

    private fun withinTolerance(a: String, b: String): Boolean {
        val x = a.toDoubleOrNull() ?: return false
        val y = b.toDoubleOrNull() ?: return false
        return abs(x - y) <= 0.25
    }

    companion object { private const val TAG = "CioScoreBet365Gate" }
}
