package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Conservative AiScore Bet365 1X2 reader.
 *
 * AiScore is used as a primary corroboration source, never as a blind fallback.
 * If the match identity or an explicit Bet365 1X2 block cannot be proven, this
 * service returns null. It does not invent or reuse cached odds.
 */
class AiScoreOddsService {
    data class Odds(
        val ms1: String,
        val msX: String,
        val ms2: String,
        val source: String = "AiScore"
    )

    private val http = HttpClient()

    suspend fun fetch(homeTeam: String, awayTeam: String, expectedDate: String? = null): Odds? =
        withContext(Dispatchers.IO) {
            val url = buildMatchUrl(homeTeam, awayTeam)
            val (code, body) = http.getSource(url, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) {
                Log.d(TAG, "AiScore miss code=$code match=$homeTeam - $awayTeam")
                return@withContext null
            }

            val document = Jsoup.parse(body, url)
            val visible = document.text()
            val raw = body.replace("\\u0026", "&")

            // Identity is mandatory. A generic team search page is never enough.
            if (!containsTeam(visible, homeTeam) || !containsTeam(visible, awayTeam)) {
                Log.d(TAG, "AiScore identity miss match=$homeTeam - $awayTeam")
                return@withContext null
            }

            // If the caller knows the fixture date, require it to be visible in
            // the page before accepting odds. This prevents a same-team historical
            // fixture from being mistaken for today's event.
            if (!expectedDate.isNullOrBlank()) {
                val compact = normalizeDate(expectedDate)
                val dateNeedles = setOf(
                    expectedDate,
                    expectedDate.replace('-', '/'),
                    expectedDate.replace('-', '.'),
                    compact.replace('-', '/'),
                    compact.replace('-', '.')
                )
                if (dateNeedles.none { it.isNotBlank() && (visible.contains(it) || raw.contains(it)) }) {
                    Log.d(TAG, "AiScore date miss expected=$expectedDate match=$homeTeam - $awayTeam")
                    return@withContext null
                }
            }

            parseBet365OneXTwo(visible)?.also {
                Log.d(TAG, "AiScore BET365 HIT $homeTeam - $awayTeam ${it.ms1}/${it.msX}/${it.ms2}")
            }
        }

    private fun buildMatchUrl(home: String, away: String): String {
        val slug = { value: String ->
            value.lowercase(Locale.ROOT)
                .replace(Regex("\\b(ce|go)\\b$"), "")
                .replace("esporte clube", "")
                .replace('&'.toString(), " and ")
                .replace(Regex("[^a-z0-9]+"), "-")
                .trim('-')
        }
        val h = URLEncoder.encode(slug(home), StandardCharsets.UTF_8.name()).replace("+", "-")
        val a = URLEncoder.encode(slug(away), StandardCharsets.UTF_8.name()).replace("+", "-")
        return "https://www.aiscore.com/live/football-$h-vs-$a"
    }

    private fun containsTeam(text: String, wanted: String): Boolean {
        val normalizedText = normalize(text)
        val normalizedWanted = normalize(wanted)
        if (normalizedWanted.isBlank()) return false
        if (normalizedText.contains(normalizedWanted)) return true

        // Common short/full-name variations used by AiScore.
        val tokens = normalizedWanted.split(' ').filter { it.length >= 4 }
        return tokens.isNotEmpty() && tokens.count { normalizedText.contains(it) } >= minOf(2, tokens.size)
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace("á", "a").replace("à", "a").replace("ã", "a").replace("â", "a")
        .replace("é", "e").replace("ê", "e")
        .replace("í", "i").replace("ó", "o").replace("ô", "o").replace("õ", "o")
        .replace("ú", "u").replace("ç", "c")
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\b(ce|go)\\b$"), "")
        .trim()


    private fun normalizeDate(value: String): String {
        val cleaned = value.trim().replace('.', '-').replace('/', '-')
        val parts = cleaned.split('-')
        if (parts.size != 3) return cleaned
        return if (parts[0].length == 4) cleaned else parts[2] + "-" + parts[1].padStart(2, '0') + "-" + parts[0].padStart(2, '0')
    }

    /**
     * Extract only an explicit Bet365 1X2 block. AiScore can expose opening and
     * current rows; the last complete 1X2 triple in the Bet365 block is treated
     * as the current/pre-match row. If the block is ambiguous, return null.
     */
    private fun parseBet365OneXTwo(text: String): Odds? {
        val lower = text.lowercase(Locale.ROOT)
        val bookmakerIndex = lower.indexOf("bet365")
        if (bookmakerIndex < 0) return null

        val start = bookmakerIndex
        val end = listOf(
            lower.indexOf("1xbet", start + 6),
            lower.indexOf("bet-at-home", start + 6),
            lower.indexOf("bwin", start + 6),
            lower.indexOf("unibet", start + 6),
            lower.indexOf("betfair", start + 6),
            lower.indexOf("pinnacle", start + 6)
        ).filter { it > start }.minOrNull() ?: minOf(text.length, start + 1800)

        val block = text.substring(start, end)
        val oneXtwo = Regex("(?i)\\b1\\s*[xX]\\s*2\\b").find(block)
        val scoped = if (oneXtwo != null) block.substring(oneXtwo.range.last + 1) else block

        val numbers = Regex("(?<![0-9])([1-9][0-9]?\\.[0-9]{2})(?![0-9])")
            .findAll(scoped)
            .mapNotNull { it.groupValues.getOrNull(1)?.toDoubleOrNull() }
            .filter { it > 1.0 && it <= 50.0 }
            .toList()

        if (numbers.size < 3) return null

        // Use the final complete triple, matching AiScore's opening/current layout.
        val triple = numbers.takeLast(3)
        return Odds(fmt(triple[0]), fmt(triple[1]), fmt(triple[2]))
    }

    private fun fmt(value: Double): String = String.format(Locale.US, "%.2f", value)

    companion object {
        private const val TAG = "CioScoreAiScore"
    }
}
