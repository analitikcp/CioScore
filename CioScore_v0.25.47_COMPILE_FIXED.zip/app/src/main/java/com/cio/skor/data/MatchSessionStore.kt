package com.cio.skor.data

import com.cio.skor.ui.MatchGroup

/** In-memory handoff for the latest scan between MainActivity and secondary screens. */
object MatchSessionStore {
    @Volatile
    var latestGroups: List<MatchGroup> = emptyList()
}
