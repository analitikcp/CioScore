package com.cio.skor.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IdentityAndScoreRegressionTest {
    @Test fun teamAliasesResolveKnownVariants() {
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Man Utd") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("VfL Bochum", "Bochum") >= 0.80)
        assertTrue(TeamAliasCanonicalizer.similarityCanonical("FSV Mainz 05", "Mainz") >= 0.80)
    }

    @Test fun seniorAndYouthTeamsDoNotCollapse() {
        assertFalse(TeamAliasCanonicalizer.similarityCanonical("Manchester United", "Manchester United U21") >= 0.95)
    }

    @Test fun renderableScoreContractRejectsTextualAndPartialValues() {
        assertTrue(ScoreModel.hasRenderablePrediction("1-0"))
        assertTrue(ScoreModel.hasRenderablePrediction(" 2 : 2 "))
        assertFalse(ScoreModel.hasRenderablePrediction("Home win"))
        assertFalse(ScoreModel.hasRenderablePrediction("1-"))
        assertFalse(ScoreModel.hasRenderablePrediction("TBD"))
    }
}
