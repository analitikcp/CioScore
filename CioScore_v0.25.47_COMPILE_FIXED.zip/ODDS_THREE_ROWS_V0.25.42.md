# v0.25.42 — Main card 3-bookmaker odds

- Main match cards now show three 1X2 rows together: official İddaa, Bet365, and bwin.
- Bet365 continues to use the existing fallback chain.
- bwin is read from the existing TipsterArea Standard 1X2 parser; no odds are fabricated.
- If a source is not available yet, the row shows a loading marker and later updates when the lookup completes.
- No matcher, kickoff gate, prediction, or team-identity logic changed.
