# CioScore v0.25.40 — Kickoff + Team History Fix

## 1. Kickoff metadata
- Restored fixture-scoped kickoff extraction for provider links and `<time>` nodes.
- Never falls back to arbitrary `HH:mm` values from the whole card.
- Source time zones remain authoritative before conversion to Istanbul.
- This prevents page clocks/countdowns from becoming match kickoffs while allowing providers such as FP.com to expose their real fixture time through the match link.

## 2. Team last matches
- Team IDs were previously always null in `MainActivity`, forcing a fragile name search.
- Improved SofaScore team resolution with exact canonical matching and multiple public API host variants.
- Recent fixtures are fetched across multiple history pages instead of only page 0.
- Finished fixtures are merged, timestamp-sorted, and the newest 10 are displayed.
- UI label changed from `Son 5 Maç` to `Son 10 Maç`.
- Recent-match ordering now uses the actual event timestamp.
