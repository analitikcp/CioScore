# v0.25.45 — Reverse Coverage + Matcher Performance Fix

- Reverse coverage diagnostics no longer scan every provider fixture for every official fixture.
- Added source-local canonical fixture index and two-sided token pre-filter.
- Added early `SOURCE_ABSENT_FROM_PARSED_DATA` exit before similarity scoring.
- Metadata reconciliation now uses an indexed official candidate pool instead of scanning the entire official bulletin per prediction.
- Existing canonical similarity cache remains active; canonicalizer now also handles verified provider/official aliases and conservative plural drift.
- Added explicit aliases for the 28 unmatched cases observed in v0.25.44 diagnostics.
