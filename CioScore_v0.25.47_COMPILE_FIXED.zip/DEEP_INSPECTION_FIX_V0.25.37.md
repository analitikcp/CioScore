# v0.25.37 — Bidirectional Prediction Source Coverage Diagnostic

## Problem
The previous diagnostic only inspected provider predictions that failed to attach to the official İddaa bulletin. It could not explain official İddaa fixtures for which no provider prediction appeared at all.

## Fix
Added a reverse diagnostic: every official bulletin fixture is inspected against every parsed prediction source. The report now separates:

- `MATCHED` — provider prediction was found and accepted by the existing identity pipeline.
- `SOURCE_PRESENT_BUT_UNMATCHED` — a plausible provider-side candidate was parsed, but the existing identity/metadata gates rejected it.
- `SOURCE_ABSENT_FROM_PARSED_DATA` — no credible two-sided candidate exists in the parsed provider records. This means absent from the parser output; it does not claim that the upstream webpage itself lacked the fixture.

## Important
This patch is diagnostic-only. It does not change fixture merging, UI gating, official enrichment, or prediction selection.

The diagnostic is available in the existing SCAN DIAGNOSTIC PANEL and in the copied diagnostic report.
