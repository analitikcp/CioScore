# v0.25.36 — Official Bulletin Diagnostic Split

## Purpose
Separate a genuinely absent official İddaa fixture from a fixture that exists in the official bulletin but cannot be reconciled by team identity.

## Changes
- Added `OFFICIAL_BULLETIN_ABSENT` to `UnmatchedReason`.
- `diagnoseOfficialMismatch()` now ranks official fixtures by two-sided team similarity before applying metadata gates.
- Strong two-sided candidates can now surface `DATE_MISMATCH`, `TIME_MISMATCH`, or `COMPETITION_MISMATCH` even when the normal matcher correctly rejects the pair.
- Weak/no two-sided candidates are reported as `OFFICIAL_BULLETIN_ABSENT` or `NAME_MISMATCH` based on evidence.
- Merge behavior is unchanged; this is diagnostic-only.
- UI label updated accordingly.

## Safety
No new fuzzy merge path, alias, one-sided match, substring match, or official fixture recovery was introduced.
