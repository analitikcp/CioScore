# v0.25.38 — Past Fixture / Timezone Guard Fix

## Root cause

Prediction pages scoped to **Today** were resolving the page date with the app
zone (`Europe/Istanbul`) even when the provider page is based on a different
local day (notably WinDrawWin/PredictZ, which use the UK calendar). In addition,
the generic parser could scan an entire fixture card for the first `HH:mm` and
mistake an unrelated page/update/countdown time for kickoff. That could turn a
finished fixture into a future timestamp and bypass the existing real-time
`matchTimestamp > now` gate.

## v0.25.38 changes

- WinDrawWin now uses `Europe/London` for source-local date/time normalization.
- PredictZ now uses `Europe/London` for source-local date/time normalization.
- `Today` page dates are resolved in the parser's **source timezone**, not
  `Europe/Istanbul`.
- Explicit `Today` pages prefer the source-local current date over stale card
  dates.
- Generic kickoff extraction no longer uses a card-wide `findTime(text)` fallback.
- Generic `[datetime]` extraction is restricted to fixture/kickoff semantic
  selectors; article/page timestamps are not treated as match kickoff.
- DailySports no longer uses the card-wide time fallback in its metadata merge.
- Existing final real-time past-match gate remains unchanged.

## Expected result

At 28 Oct 2026 01:05 TRT, a UK `Today` page still representing 27 Oct UK time
will resolve to **27.10.2026**, so a 27 Oct fixture cannot be manufactured as
`28.10.2026 01:45` and shown as upcoming. If a trustworthy fixture kickoff is
not present, the prediction remains without a timestamp and is excluded by the
existing safety gate rather than being assigned a guessed time.
