# CioScore v0.25.43 — AiScore + Flashscore primary Bet365 gate

## Goal
Replace the previous blind Bet365 fallback chain with a conservative two-source gate.

## Primary sources
1. AiScore — fixture identity + explicit Bet365 1X2 block.
2. Flashscore — fixture identity + bookmaker-labelled Bet365 1X2 feed.

## Acceptance rule
Bet365 is rendered only when:
- both primary sources find the same home/away fixture;
- AiScore confirms the expected fixture date when the card has a display date;
- both sources return a complete Bet365 1X2 row;
- each corresponding price differs by no more than 0.25 decimal odds.

No averaging or synthetic odds are created. The exact Flashscore Bet365 row is displayed after AiScore corroboration.

## Rejection rule
If either primary source is unavailable, the fixture identity/date is unproven, or the two Bet365 rows materially disagree, Bet365 is omitted (`...` in the UI). Old GoalLineExpert, SofaScore and WinComparator Bet365 fallbacks are no longer used by the main-card odds path.

## Other odds
The existing bwin TipsterArea path remains unchanged. Iddaa official market odds remain unchanged.

## Safety
No fake odds, no stale Bet365 cache, no cross-fixture fallback.
