package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer

/**
 * Cross-source fixture identity.
 * Team names are presentation data; canonical home+away is the identity.
 * One fixture must produce one card, regardless of which of the 6 sources
 * supplied the record.
 */
object MatchMerger {
    private val genericTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ifk", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio"
    )

    private val aliases = mapOf(
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek athens" to "aek athens",
        "lask linz" to "lask",
        "lask" to "lask",
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "man city" to "manchester city",
        "spurs" to "tottenham hotspur",
        "tottenham" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",
        "newcastle" to "newcastle united",
        "newcastle utd" to "newcastle united",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "cardiff" to "cardiff city",
        "stoke" to "stoke city",
        "norwich" to "norwich city",
        "coventry" to "coventry city",
        "leicester" to "leicester city",
        "swansea" to "swansea city",
        "birmingham" to "birmingham city",
        "hull" to "hull city",
        "lincoln" to "lincoln city"
    )

    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace("athina", "athens")
            .replace("atina", "athens")
            .replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i')
            .replace('ö', 'o').replace('ş', 's').replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss").replace("æ", "ae").replace("œ", "oe")
            .replace("ø", "o").replace("ð", "d").replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val withoutGeneric = value.split(' ')
            .filter { it.isNotBlank() && it !in genericTokens }
            .joinToString(" ")

        return aliases[withoutGeneric] ?: withoutGeneric
    }

    private fun compact(name: String) = normalizeTeamName(name).replace(" ", "")

    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    /** Conservative team equivalence. Exact canonical equality wins. */
    fun isSameTeam(name1: String, name2: String): Boolean {
        val a = compact(name1)
        val b = compact(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true

        // Only allow containment when the shorter name is distinctive.
        val shorter = if (a.length <= b.length) a else b
        val longer = if (a.length <= b.length) b else a
        if (shorter.length >= 8 && longer.contains(shorter)) return true

        // Fuzzy fallback: high threshold + same first character prevents
        // short/common strings from collapsing unrelated clubs.
        if (a.first() != b.first()) return false
        val similarity = similarity(a, b)
        return similarity >= 0.90
    }

    private fun similarity(a: String, b: String): Double {
        val distance = levenshtein(a, b)
        val max = maxOf(a.length, b.length)
        return if (max == 0) 1.0 else 1.0 - distance.toDouble() / max.toDouble()
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val replace = prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(replace, prev[j] + 1, cur[j - 1] + 1)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null
    )

    /**
     * Global merge for sources 1-5 + official iddaa.com (source 6).
     * A source contributes at most one prediction per fixture.
     */
    fun mergeMatches(
        scrapedList: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()
    ): List<UnifiedMatch> {
        val groups = LinkedHashMap<String, UnifiedMatch>()

        // Sources 1-5. Canonical fixture key is the primary index; fuzzy matching
        // is only used for variants that cannot be canonicalised exactly.
        for (incoming in scrapedList) {
            val group = findGroup(groups.values, incoming.homeTeam, incoming.awayTeam)
            if (group == null) {
                groups[key(incoming.homeTeam, incoming.awayTeam)] = UnifiedMatch(
                    normalizeDisplayName(incoming.homeTeam),
                    normalizeDisplayName(incoming.awayTeam),
                    mutableListOf(incoming.source to incoming.predictedScore)
                )
            } else {
                val exists = group.predictions.any { it.first.equals(incoming.source, true) }
                if (!exists) group.predictions.add(incoming.source to incoming.predictedScore)
            }
        }

        // Source 6 is enrichment of the SAME fixture groups. It may not create a
        // duplicate card when a source-1..5 prediction already identifies the match.
        for (official in officialMatches) {
            val group = findGroup(groups.values, official.homeTeam, official.awayTeam)
            if (group == null) {
                groups[key(official.homeTeam, official.awayTeam)] = UnifiedMatch(
                    normalizeDisplayName(official.homeTeam),
                    normalizeDisplayName(official.awayTeam),
                    mutableListOf(),
                    official
                )
            } else {
                group.officialMatch = mergeOfficial(group.officialMatch, official)
                // Prefer official display spelling only after identity is established.
                if (group.mainHomeTeam.isBlank()) group.mainHomeTeam = normalizeDisplayName(official.homeTeam)
                if (group.mainAwayTeam.isBlank()) group.mainAwayTeam = normalizeDisplayName(official.awayTeam)
            }
        }

        return groups.values.toList()
    }

    private fun findGroup(
        groups: Collection<UnifiedMatch>,
        home: String,
        away: String
    ): UnifiedMatch? {
        val exact = groups.firstOrNull {
            key(it.mainHomeTeam, it.mainAwayTeam) == key(home, away)
        }
        if (exact != null) return exact
        return groups.firstOrNull { isSameFixture(it.mainHomeTeam, it.mainAwayTeam, home, away) }
    }

    private fun isSameFixture(h1: String, a1: String, h2: String, a2: String): Boolean =
        isSameTeam(h1, h2) && isSameTeam(a1, a2)

    private fun mergeOfficial(
        current: IddaaMarketService.OpenedMarketMatch?,
        incoming: IddaaMarketService.OpenedMarketMatch
    ): IddaaMarketService.OpenedMarketMatch {
        if (current == null) return incoming
        val combined = linkedMapOf<String, String>().apply {
            putAll(current.htFtOdds)
            putAll(incoming.htFtOdds)
        }
        return current.copy(
            matchId = current.matchId.ifBlank { incoming.matchId },
            homeTeam = current.homeTeam.ifBlank { incoming.homeTeam },
            awayTeam = current.awayTeam.ifBlank { incoming.awayTeam },
            matchTimestamp = if (current.matchTimestamp > 0L) current.matchTimestamp else incoming.matchTimestamp,
            matchTime = if (current.matchTime != "--:--") current.matchTime else incoming.matchTime,
            matchDate = current.matchDate.ifBlank { incoming.matchDate },
            ms1 = current.ms1 ?: incoming.ms1,
            msX = current.msX ?: incoming.msX,
            ms2 = current.ms2 ?: incoming.ms2,
            hasHtFt = current.hasHtFt || incoming.hasHtFt || combined.isNotEmpty(),
            htFtOdds = combined
        )
    }

    private fun normalizeDisplayName(raw: String): String {
        return when (normalizeTeamName(raw)) {
            "aek athens" -> "AEK Athens"
            "lask" -> "LASK"
            "cardiff city" -> "Cardiff City"
            "stoke city" -> "Stoke City"
            "norwich city" -> "Norwich City"
            "coventry city" -> "Coventry City"
            "leicester city" -> "Leicester City"
            "swansea city" -> "Swansea City"
            "birmingham city" -> "Birmingham City"
            "hull city" -> "Hull City"
            "lincoln city" -> "Lincoln City"
            "manchester united" -> "Manchester United"
            "manchester city" -> "Manchester City"
            "tottenham hotspur" -> "Tottenham Hotspur"
            "wolverhampton wanderers" -> "Wolverhampton Wanderers"
            "west bromwich albion" -> "West Bromwich Albion"
            "nottingham forest" -> "Nottingham Forest"
            "brighton and hove albion" -> "Brighton & Hove Albion"
            "queens park rangers" -> "Queens Park Rangers"
            "newcastle united" -> "Newcastle United"
            "paris saint germain" -> "Paris Saint-Germain"
            else -> raw.trim()
        }
    }
}
