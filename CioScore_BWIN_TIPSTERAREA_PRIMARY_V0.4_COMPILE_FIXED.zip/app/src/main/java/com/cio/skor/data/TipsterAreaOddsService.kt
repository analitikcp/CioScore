package com.cio.skor.data

import com.cio.skor.network.HttpClient
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.text.Normalizer
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * API-free TipsterArea odds transport.
 *
 * TipsterArea publishes a server-rendered "Leading Bookmakers Odds / Standard
 * 1X2" table.  The bookmaker labels are often image alt attributes rather than
 * normal text, so discovery and parsing must not depend on Element.text().
 */
class TipsterAreaOddsService {
    data class Odds(val bookmaker: String, val ms1: String, val msX: String, val ms2: String)

    private val http = HttpClient()

    // TipsterArea is a bwin/other-bookmaker source only. Bet365 is deliberately
    // blocked here so it can NEVER become a Bet365 source, even if TipsterArea
    // changes its HTML and exposes a Bet365 row. Bet365 is handled exclusively
    // by the dedicated Bet365 providers/direct-feed layers.
    private val wantedBookmakers = linkedMapOf(
        "1xbet" to "1xBet",
        "bet-at-home" to "bet-at-home",
        "betfair" to "Betfair",
        "bwin" to "bwin",
        "unibet" to "Unibet"
    )

    private val blockedBookmakerKeys = setOf("bet365", "bet 365")

    private data class CacheEntry(val expiresAt: Long, val value: List<Odds>)
    private val oddsCache = ConcurrentHashMap<String, CacheEntry>()
    private val urlCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val indexCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private val indexMutex = Mutex()
    private val cacheTtlMs = 5 * 60 * 1000L
    private val indexCacheTtlMs = 2 * 60 * 1000L

    suspend fun fetch(
        homeTeam: String,
        awayTeam: String,
        matchDate: String = ""
    ): List<Odds> {
        val cacheKey = "${normalize(homeTeam)}|${normalize(awayTeam)}|${dateKey(matchDate)}"
        oddsCache[cacheKey]?.takeIf { it.expiresAt > System.currentTimeMillis() }?.let { return it.value }

        val detailUrl = discoverMatchUrl(homeTeam, awayTeam, matchDate)
        if (detailUrl.isNullOrBlank()) {
            android.util.Log.w("TipsterAreaOdds", "MATCH MISS $homeTeam - $awayTeam date=$matchDate")
            return emptyList()
        }

        val (code, body) = fetchTipsterHtml(detailUrl)
        if (code !in 200..299 || body.isNullOrBlank()) {
            android.util.Log.w("TipsterAreaOdds", "DETAIL MISS code=$code url=$detailUrl")
            return emptyList()
        }

        val result = parseOdds(body)
        val bwin = result.firstOrNull { it.bookmaker.equals("bwin", true) }
        android.util.Log.d(
            "TipsterAreaOdds",
            "DETAIL HIT $homeTeam - $awayTeam bwin=${bwin?.ms1 ?: "-"}/${bwin?.msX ?: "-"}/${bwin?.ms2 ?: "-"} rows=${result.size}"
        )
        if (result.isNotEmpty()) {
            oddsCache[cacheKey] = CacheEntry(System.currentTimeMillis() + cacheTtlMs, result)
        }
        return result
    }

    private suspend fun discoverMatchUrl(homeTeam: String, awayTeam: String, matchDate: String): String? {
        val home = normalizedTeamVariants(homeTeam)
        val away = normalizedTeamVariants(awayTeam)
        if (home.isEmpty() || away.isEmpty()) return null

        val dates = candidateDates(matchDate)
        for (date in dates) {
            val dateKey = date.toString()
            val urlCacheKey = "${home.joinToString("_")}|${away.joinToString("_")}|$dateKey"
            urlCache[urlCacheKey]?.takeIf { it.first > System.currentTimeMillis() }?.let { return it.second }

            val tipsterDate = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"))
            val indexUrls = listOf(
                "https://tipsterarea.com/matches/date-$tipsterDate",
                "https://tipsterarea.com/matches-hour/date-$tipsterDate"
            )

            for (url in indexUrls) {
                val body = getCachedIndex(url) ?: continue
                val doc = Jsoup.parse(body, "https://tipsterarea.com/")

                // IMPORTANT: the date page already contains the exact fixture link.
                // Use the visible anchor text first; this avoids fuzzy matching against
                // unrelated page content and prevents repeated index downloads.
                for (a in doc.select("a[href]") ) {
                    val rawHref = a.attr("href").trim()
                    val href = a.absUrl("href").ifBlank {
                        when {
                            rawHref.startsWith("http") -> rawHref
                            rawHref.isNotBlank() -> "https://tipsterarea.com${if (rawHref.startsWith('/')) rawHref else "/$rawHref"}"
                            else -> ""
                        }
                    }
                    if (href.isBlank() || !href.contains("/match/", ignoreCase = true)) continue

                    val anchorText = normalize(a.text())
                    val hrefText = normalize(href)
                    val anchorHome = teamSimilarity(anchorText, home)
                    val anchorAway = teamSimilarity(anchorText, away)
                    val hrefHome = teamSimilarity(hrefText, home)
                    val hrefAway = teamSimilarity(hrefText, away)
                    val hs = maxOf(anchorHome, hrefHome)
                    val ascore = maxOf(anchorAway, hrefAway)

                    if (hs >= 0.75 && ascore >= 0.75) {
                        urlCache[urlCacheKey] = System.currentTimeMillis() + cacheTtlMs to href
                        android.util.Log.d("TipsterAreaOdds", "MATCH HIT $homeTeam - $awayTeam -> $href")
                        return href
                    }
                }
            }
        }
        return null
    }

    private suspend fun getCachedIndex(url: String): String? {
        val now = System.currentTimeMillis()
        indexCache[url]?.takeIf { it.first > now }?.let { return it.second }

        // Only one coroutine refreshes a given TipsterArea index at a time. The
        // app scans many fixtures simultaneously; without this guard each card
        // could hammer the same date page and trigger rate limiting.
        return indexMutex.withLock {
            val again = indexCache[url]?.takeIf { it.first > System.currentTimeMillis() }
            if (again != null) return@withLock again.second
            val (code, body) = fetchTipsterHtml(url)
            if (code in 200..299 && !body.isNullOrBlank()) {
                indexCache[url] = System.currentTimeMillis() + indexCacheTtlMs to body
                body
            } else {
                android.util.Log.w("TipsterAreaOdds", "INDEX MISS code=$code url=$url")
                null
            }
        }
    }

    /**
     * TipsterArea may return a normal HTML document, a transient 403/429, or
     * an empty body depending on the edge node.  Use the browser-profile fetch
     * first and then the simpler OkHttp path as a second transport.  Neither
     * path bypasses JS/CAPTCHA/access controls.
     */
    private fun fetchTipsterHtml(url: String): Pair<Int, String?> {
        val primary = http.getSource(url, "https://tipsterarea.com/")
        if (primary.first in 200..299 && !primary.second.isNullOrBlank()) return primary

        val fallback = http.get(url, "https://tipsterarea.com/")
        return fallback
    }

    private fun candidateDates(raw: String): List<LocalDate> {
        val base = parseDate(raw) ?: LocalDate.now(KickoffNormalizer.ZONE)
        return listOf(base, base.minusDays(1), base.plusDays(1)).distinct()
    }

    private fun parseDate(raw: String): LocalDate? {
        val value = raw.trim().take(10)
        if (value.isBlank()) return null
        val formats = listOf(
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy")
        )
        return formats.firstNotNullOfOrNull { formatter ->
            try { LocalDate.parse(value, formatter) } catch (_: DateTimeParseException) { null }
        }
    }

    private fun dateKey(raw: String): String = parseDate(raw)?.toString() ?: raw.trim()

    private fun normalizedTeamVariants(value: String): List<String> {
        val base = normalize(value)
        if (base.isBlank()) return emptyList()

        val stripped = base.split(' ')
            .filterNot { it in GENERIC_TEAM_PREFIXES }
            .joinToString(" ")
            .trim()

        return listOf(base, stripped)
            .filter { it.isNotBlank() }
            .distinct()
    }

    /**
     * Returns a tolerant match score for a team name against a normalized text
     * fragment.  The previous V0.4 source called teamSimilarity() without
     * defining it, which caused the Kotlin compile failure.
     *
     * Scoring is intentionally simple and deterministic:
     * - 1.0 for an exact/full phrase match
     * - token coverage for common URL/label abbreviations
     * - best score across the supplied team-name variants
     */
    private fun teamSimilarity(text: String, variants: List<String>): Double {
        val haystack = normalize(text)
        if (haystack.isBlank() || variants.isEmpty()) return 0.0

        var best = 0.0
        for (variantRaw in variants) {
            val variant = normalize(variantRaw)
            if (variant.isBlank()) continue

            if (haystack == variant || haystack.contains(variant)) {
                best = maxOf(best, 1.0)
                continue
            }

            val tokens = variant.split(' ').filter { it.length >= 3 }.distinct()
            if (tokens.isEmpty()) continue

            val hits = tokens.count { token -> haystack.contains(token) }
            val coverage = hits.toDouble() / tokens.size.toDouble()
            best = maxOf(best, coverage)
        }
        return best
    }

    private fun teamPairMatches(text: String, homeVariants: List<String>, awayVariants: List<String>): Boolean {
        val haystack = normalize(text)
        val homeHit = homeVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        val awayHit = awayVariants.any { variant -> containsTeamPhrase(haystack, variant) }
        return homeHit && awayHit
    }

    private fun containsTeamPhrase(haystack: String, team: String): Boolean {
        if (team.isBlank()) return false
        if (haystack.contains(team)) return true

        // Handle common short-name differences, e.g. "CD Universidad Catolica"
        // vs a URL slug containing only "universidad catolica".
        val tokens = team.split(' ').filter { it.length >= 3 }
        if (tokens.isEmpty()) return false
        val hits = tokens.count { haystack.contains(it) }
        return hits >= maxOf(1, (tokens.size * 0.75).toInt())
    }

    private fun parseOdds(html: String): List<Odds> {
        val doc = Jsoup.parse(html)
        val tables = doc.select("table")

        // Prefer the Standard 1X2 table, but parse ALL tables as well. TipsterArea
        // has used desktop/mobile duplicate tables and localized headers; limiting
        // the parser to one guessed table can hide a valid bwin row.
        val preferred = tables.filter { table ->
            val marker = normalize(
                table.text() + " " + table.select("img[alt]").joinToString(" ") { it.attr("alt") }
            )
            marker.contains("standard 1x2") || marker.contains("standard 1 x 2")
        }
        val tablesToScan = (preferred + tables).distinct()
        val rowsByBookmaker = linkedMapOf<String, Odds>()

        for (table in tablesToScan) {
            for (tr in table.select("tr")) {
                val bookmakerKey = bookmakerFromRow(tr) ?: continue
                val values = numericOddsFromRow(tr)
                if (values.size < 3) continue

                val clean = values.mapNotNull(::cleanOdd)
                if (clean.size < 3) continue

                // Some responsive rows contain an extra market number before the
                // three prices. The final three valid decimals are the 1/X/2 row.
                val odds = Odds(
                    wantedBookmakers.getValue(bookmakerKey),
                    clean[clean.lastIndex - 2], clean[clean.lastIndex - 1], clean.last()
                )
                if (validOdds(odds)) rowsByBookmaker.putIfAbsent(bookmakerKey, odds)
            }
        }

        return wantedBookmakers.keys.mapNotNull { rowsByBookmaker[it] }
    }

    private fun validOdds(odds: Odds): Boolean =
        listOf(odds.ms1, odds.msX, odds.ms2).all {
            it.toDoubleOrNull()?.let { value -> value > 1.0 && value <= 100.0 } == true
        }

    private fun bookmakerFromRow(row: Element): String? {
        val imageNames = row.select("img[alt]").map { it.attr("alt") }.filter { it.isNotBlank() }
        val text = buildString {
            append(row.text())
            if (imageNames.isNotEmpty()) append(' ').append(imageNames.joinToString(" "))
        }
        val normalized = normalize(text)

        // HARD BLOCK: TipsterArea must never supply Bet365 data.
        // Do this before bookmaker matching so a future wantedBookmakers change
        // cannot accidentally re-introduce Bet365 through this parser.
        if (blockedBookmakerKeys.any { normalized.contains(normalize(it)) }) return null

        return wantedBookmakers.keys.firstOrNull { key ->
            normalized.contains(normalize(key))
        }
    }

    private fun numericOddsFromRow(row: Element): List<String> {
        val rawParts = row.select("td,th").flatMap { cell ->
            val text = cell.text().trim()
            if (text.isNotBlank()) listOf(text) else emptyList()
        }
        val raw = rawParts.joinToString(" ")
        val matches = ODDS_NUMBER.findAll(raw).map { it.value }.toList()
        if (matches.size >= 3) return matches

        // A few TipsterArea variants put the values in attributes/spans. Fall
        // back to the complete row text, but still require exactly three usable
        // numeric values after bookmaker identification.
        return ODDS_NUMBER.findAll(row.wholeText()).map { it.value }.toList()
    }

    private fun cleanOdd(value: String): String? {
        val normalized = value.replace(',', '.').trim()
        val number = normalized.toDoubleOrNull() ?: return null
        if (number <= 1.0 || number > 100.0) return null
        return String.format(Locale.US, "%.2f", number)
    }

    private fun normalize(value: String): String =
        Normalizer.normalize(value.lowercase(Locale.US), Normalizer.Form.NFD)
            .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
            .replace("ı", "i")
            .replace("ß", "ss")
            .replace(Regex("https?://|www\\."), " ")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    companion object {
        private val ODDS_NUMBER = Regex("(?<![A-Za-z])\\d{1,3}(?:[.,]\\d{1,3})?(?![A-Za-z])")
        private val GENERIC_TEAM_PREFIXES = setOf(
            "fc", "cf", "cd", "sc", "ac", "afc", "fk", "sk", "club", "clube",
            "deportivo", "deportiva", "deportes", "football", "soccer"
        )
    }
}
