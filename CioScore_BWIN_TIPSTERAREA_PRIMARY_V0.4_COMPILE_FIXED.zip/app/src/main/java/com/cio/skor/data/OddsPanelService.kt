package com.cio.skor.data

/** Independent odds-panel pipeline. Bet365 is sourced only from WBookie. */
class OddsPanelService {
    data class OddsRow(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String,
        val primary: Boolean = false
    )

    private val wbookie = WBookieOddsService()
    private val tipsterArea = TipsterAreaOddsService()

    suspend fun fetchBet365(homeTeam: String, awayTeam: String, kickoffEpochMs: Long): OddsRow? =
        wbookie.fetch(homeTeam, awayTeam, kickoffEpochMs).odds?.let {
            OddsRow("Bet365 · WBookie", it.ms1, it.msX, it.ms2, primary = true)
        }

    suspend fun fetchTipsterArea(homeTeam: String, awayTeam: String, matchDate: String): List<OddsRow> =
        tipsterArea.fetch(homeTeam, awayTeam, matchDate)
            .filterNot { it.bookmaker.contains("Bet365", ignoreCase = true) }
            .map { OddsRow(it.bookmaker, it.ms1, it.msX, it.ms2) }

    fun iddaaRow(ms1: String?, msX: String?, ms2: String?): OddsRow? {
        if (ms1 == null && msX == null && ms2 == null) return null
        return OddsRow("İddaa.com", ms1 ?: "-", msX ?: "-", ms2 ?: "-")
    }
}
