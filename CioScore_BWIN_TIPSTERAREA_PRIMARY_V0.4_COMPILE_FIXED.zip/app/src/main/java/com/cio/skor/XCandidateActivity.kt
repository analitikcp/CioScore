package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchSessionStore
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.OddsPanelService
import com.cio.skor.data.WBookieOddsService
import com.cio.skor.data.SofaScoreService
import com.cio.skor.data.ScoreModel
import com.cio.skor.ui.ScoreAdapter
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import kotlinx.coroutines.withContext

/**
 * Dedicated MS X candidate screen.
 *
 * A fixture is an X candidate when at least one currently renderable prediction
 * has equal home/away goals (e.g. 0-0, 1-1, 2-2). The main fixture grouping and
 * official İddaa enrichment are reused; this screen is only a filtered view.
 */
class XCandidateActivity : Activity() {
    private lateinit var adapter: ScoreAdapter
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val oddsPanelService by lazy { OddsPanelService() }
    private val oddsQueue = ArrayDeque<com.cio.skor.ui.MatchGroup>()
    private val oddsQueuedKeys = mutableSetOf<String>()
    private val oddsRetryCount = mutableMapOf<String, Int>()
    private var oddsQueueRunning = false

    private fun oddsKey(match: com.cio.skor.ui.MatchGroup): String =
        "${MatchMerger.normalizeTeamName(match.homeTeam)}::${MatchMerger.normalizeTeamName(match.awayTeam)}::${match.displayDate.trim().lowercase()}::${match.matchTimestamp}"

    private fun enqueueOdds(match: com.cio.skor.ui.MatchGroup) {
        val key = oddsKey(match)
        if (!oddsQueuedKeys.add(key)) return
        oddsQueue.addLast(match)
        processNextOdds()
    }

    private fun processNextOdds() {
        if (oddsQueueRunning || oddsQueue.isEmpty()) return
        val next = oddsQueue.removeFirst()
        val key = oddsKey(next)
        oddsQueueRunning = true
        scope.launch {
            val rows = runCatching {
                withContext(Dispatchers.IO) {
                    buildList {
                        oddsPanelService.fetchBet365(
                            next.homeTeam, next.awayTeam, next.matchTimestamp
                        )?.let(::add)
                    }
                }
            }.getOrDefault(emptyList())
            val adapterRows = rows.map {
                SofaScoreService.BookmakerOdds(
                    bookmaker = it.bookmaker,
                    ms1 = it.ms1,
                    msX = it.msX,
                    ms2 = it.ms2
                )
            }
            adapter.setExternalOdds(next, adapterRows)
            oddsQueuedKeys.remove(key)

            if (rows.isEmpty()) {
                val attempt = (oddsRetryCount[key] ?: 0) + 1
                oddsRetryCount[key] = attempt
                if (attempt <= 2) {
                    delay(2500L)
                    enqueueOdds(next)
                } else {
                    oddsRetryCount.remove(key)
                }
            } else {
                oddsRetryCount.remove(key)
            }
            oddsQueueRunning = false
            processNextOdds()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 15+/targetSdk 36 may render this Activity edge-to-edge.
        // The X-candidate screen is built programmatically, so it must apply
        // the system-bar insets itself; otherwise the title is pushed under
        // the status bar and the last card/score is hidden behind navigation.
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val baseHorizontal = dp(12)
        val baseVertical = dp(12)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(baseHorizontal, baseVertical, baseHorizontal, baseVertical)
            setBackgroundColor(0xFFF7F9FC.toInt())
        }

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                    WindowInsetsCompat.Type.navigationBars() or
                    WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(
                baseHorizontal,
                baseVertical + bars.top,
                baseHorizontal,
                baseVertical + bars.bottom
            )
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val back = Button(this).apply {
            text = "‹ Geri"
            setOnClickListener { finish() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(92), dp(44)))

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        titleBox.addView(TextView(this).apply {
            text = "MS X ADAYLARI"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF101828.toInt())
        })
        titleBox.addView(TextView(this).apply {
            text = "Beraberlik skoru üreten maçlar"
            textSize = 12f
            setTextColor(0xFF475569.toInt())
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(header)

        val xGroups = MatchSessionStore.latestGroups
            .filter { match ->
                match.predictions.any { prediction -> isXPrediction(prediction.predictedScore) }
            }
            .sortedBy { it.matchTimestamp.takeIf { ts -> ts > 0L } ?: Long.MAX_VALUE }

        root.addView(TextView(this).apply {
            text = "${xGroups.size} X adayı maç"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        })

        val recycler = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@XCandidateActivity)
            setHasFixedSize(false)
            itemAnimator = null
            setItemViewCacheSize(4)
        }

        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { _, _ -> },
            onHtFtClick = { _, _ -> },
            onExternalOddsRequest = { match -> enqueueOdds(match) },
            onOddsClick = { match -> showOddsPanel(match) }
        )
        // Keep the final card physically above Android's navigation surface.
        // A RecyclerView bottom padding alone is not sufficient on Android 15/16
        // when the navigation bar is transparent/edge-to-edge. We therefore add
        // a real spacer AFTER the list and resize it from the navigation inset.
        recycler.clipToPadding = false
        val baseRecyclerBottomPadding = dp(12)
        recycler.setPadding(0, 0, 0, baseRecyclerBottomPadding)
        recycler.adapter = adapter
        adapter.submitList(xGroups)
        root.addView(recycler, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val bottomSafeSpacer = View(this).apply {
            setBackgroundColor(0xFFF7F9FC.toInt())
        }
        root.addView(bottomSafeSpacer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(104)
        ))

        ViewCompat.setOnApplyWindowInsetsListener(recycler) { view, insets ->
            // Keep a small internal padding for gesture navigation as well.
            view.setPadding(
                view.paddingLeft,
                view.paddingTop,
                view.paddingRight,
                baseRecyclerBottomPadding + dp(16)
            )
            insets
        }
        ViewCompat.setOnApplyWindowInsetsListener(bottomSafeSpacer) { view, insets ->
            val navigationBottom = insets.getInsets(
                WindowInsetsCompat.Type.navigationBars()
            ).bottom
            // 104dp minimum gives enough clearance for 3-button and gesture
            // navigation. Add the actual inset when it is larger.
            val safeHeight = maxOf(dp(104), navigationBottom + dp(24))
            view.layoutParams = view.layoutParams.apply { height = safeHeight }
            view.requestLayout()
            insets
        }
        ViewCompat.requestApplyInsets(recycler)
        ViewCompat.requestApplyInsets(bottomSafeSpacer)

        if (xGroups.isEmpty()) {
            recycler.visibility = View.GONE
            root.addView(TextView(this).apply {
                text = "Bu taramada MS X adayı bulunamadı.\n\nÖrnek X skorları: 0-0, 1-1, 2-2."
                textSize = 15f
                setTextColor(0xFF475569.toInt())
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(32), dp(24), dp(32))
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            ))
        }

        setContentView(root)
    }


    /**
     * The X-candidate screen is a separate Activity, so it cannot call the
     * private MainActivity odds-panel method. Keep the exact same panel
     * contract here: official Iddaa row first, then independent Bet365 providers
     * and TipsterArea for non-Bet365 bookmaker rows. TipsterArea is never used
     * as a Bet365 source.
     * This is intentionally a single-fixture request and does not depend on
     * the main screen's adapter/cache lifecycle.
     */
    private fun showOddsPanel(match: com.cio.skor.ui.MatchGroup) {
        val dialog = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(24))
        }

        fun label(text: String, size: Float = 13f, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFF101828.toInt())
                if (bold) setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(4), 0, dp(4))
            }

        fun addRow(row: OddsPanelService.OddsRow) {
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    setColor(if (row.primary) 0xFFF0FDF4.toInt() else 0xFFF8FAFC.toInt())
                    cornerRadius = dp(10).toFloat()
                    setStroke(dp(1), if (row.primary) 0xFFBBE7CA.toInt() else 0xFFE4E7EC.toInt())
                }
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            }
            container.addView(TextView(this).apply {
                text = if (row.primary) "★ ${row.bookmaker}" else row.bookmaker
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(0xFF101828.toInt())
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f)
            })
            listOf(row.ms1, row.msX, row.ms2).forEach { value ->
                container.addView(TextView(this).apply {
                    text = value
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setTextColor(0xFF155EEF.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
            }
            root.addView(container)
        }

        root.addView(label("ORANLAR", 20f, true))
        root.addView(label("${match.homeTeam}  -  ${match.awayTeam}", 13f, true))
        root.addView(label("MS1 / MSX / MS2", 11f))
        oddsPanelService.iddaaRow(match.iddaaMs1, match.iddaaMsX, match.iddaaMs2)?.let(::addRow)

        val loading = label("Yurtdışı oranlar yükleniyor…", 12f)
        root.addView(loading)
        dialog.setContentView(root)
        dialog.show()

        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val bet365 = runCatching {
                    oddsPanelService.fetchBet365(
                        match.homeTeam, match.awayTeam, match.matchTimestamp
                    )
                }.getOrNull()
                val tipster = runCatching {
                    oddsPanelService.fetchTipsterArea(
                        match.homeTeam,
                        match.awayTeam,
                        match.displayDate
                    )
                }.getOrDefault(emptyList())
                Triple(bet365, null, tipster)
            }

            if (!dialog.isShowing) return@launch
            root.removeView(loading)

            val bet365 = result.first
            val tipster = result.third
            if (bet365 != null) addRow(bet365)
            else root.addView(label("Bet365 · WBookie: oran bulunamadı.", 12f))

            if (tipster.isNotEmpty()) {
                tipster.forEach(::addRow)
                root.addView(label("Kaynak: TipsterArea · Standard 1X2", 10f))
            } else {
                root.addView(label("TipsterArea oranları bu maç için bulunamadı.", 12f))
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun isXPrediction(score: String): Boolean {
        if (!ScoreModel.hasRenderablePrediction(score)) return false
        val parts = score.trim().replace(':', '-').split('-')
        if (parts.size != 2) return false
        return parts[0].trim().toIntOrNull() == parts[1].trim().toIntOrNull()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
