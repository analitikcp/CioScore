# CioScore V0.1 UI baseline

- Main action row: equal-width TEŞHİS / HT/FT / MS X buttons.
- Bottom action row: equal-width TARA / İDDAA BÜLTENİ / CİO PANEL buttons.
- Prediction source rows use a fixed equal height for FP.com, PredictZ, WinDrawWin and DailySports.
- Odds and prediction data logic is unchanged from FIX5.
- V0.1 keeps WBookie as primary Bet365 source, ChekiOdds as secondary Bet365 source, and the FIX5 bwin source priority.
