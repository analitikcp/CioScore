package com.cio.skor.data

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs
import org.apache.commons.text.similarity.JaroWinklerSimilarity
import org.apache.commons.text.similarity.LevenshteinDistance
import org.apache.commons.text.similarity.NGramDistance
import org.apache.commons.codec.language.DoubleMetaphone

/**
 * Production-oriented global fixture identity engine.
 *
 * Four identity layers are intentionally separated:
 * 1) TeamAliasCanonicalizer  -> stable source-independent team IDs
 * 2) Official Iddaa anchor   -> strongest fixture authority
 * 3) Union-Find clustering    -> global, non-greedy grouping
 * 4) Evidence/confidence      -> ID + date/time + team similarity validation
 *
 * Important invariant: a fuzzy pair can never create a cluster merely because
 * one side matches. Home AND away must agree. Official fixtures can relax the
 * name threshold only when the official record is the anchor and there is no
 * contradictory time information.
 */
object GlobalFixtureMatcher {

    const val CANONICAL_PIPELINE_VERSION = "v0.25.12-MATCHER-V4-CONSENSUS"

    // Hard gates: a fuzzy fixture must have credible evidence on BOTH sides.
    // The combined gate prevents two mediocre team similarities from becoming a match.
    private const val TEAM_FUZZY_MIN = 0.72
    private const val MATCH_FUZZY_MIN = 0.78
    private const val AUTO_MERGE_CONFIDENCE = 0.84

    // Kickoff mismatch is a hard rejection. Twelve hours is intentionally wide
    // enough for timezone/date-rollover differences, but still blocks unrelated
    // fixtures from becoming candidates.
    private const val TIME_PUBLICATION_TOLERANCE_MS = 30L * 60L * 1000L
    private const val TIME_TIMEZONE_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 12L * 60L * 60L * 1000L

    private val jaroWinkler = JaroWinklerSimilarity()
    private val levenshteinDistance = LevenshteinDistance()
    private val ngramDistance = NGramDistance(3)
    private val doubleMetaphone = DoubleMetaphone()

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val competitionName: String = "",
        val countryName: String = "",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    ) {
        // Identity is immutable for a record. Compute it once at construction
        // instead of normalizing the same provider name on every pair comparison.
        val homeIdentity: TeamAliasCanonicalizer.TeamIdentity = TeamAliasCanonicalizer.identity(homeTeam)
        val awayIdentity: TeamAliasCanonicalizer.TeamIdentity = TeamAliasCanonicalizer.identity(awayTeam)
        val homeCanonicalId: String get() = homeIdentity.canonicalId
        val awayCanonicalId: String get() = awayIdentity.canonicalId
        val fixtureKey: String get() = "$homeCanonicalId||$awayCanonicalId"
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        /**
         * The exact prediction records that produced [predictions].
         *
         * The UI must consume this identity-graph output instead of regrouping
         * raw predictions by canonical team key, otherwise two fixtures that
         * the matcher deliberately kept separate could be collapsed again.
         */
        val predictionRecords: MutableList<Record> = mutableListOf(),
        var consensusCount: Int = 0,
        var consensusConfidence: Double = 0.0,
        var highConfidenceConsensus: Boolean = false,
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = "",
        var fixtureKey: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val competitionScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean,
        val homeCanonicalA: String = "",
        val homeCanonicalB: String = "",
        val awayCanonicalA: String = "",
        val awayCanonicalB: String = "",
        val countryScore: Double = 0.0
    )

    private class UnionFind(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)
        private val members = Array(size) { mutableListOf(it) }

        fun find(value: Int): Int {
            var x = value
            while (parent[x] != x) x = parent[x]
            val root = x
            x = value
            while (parent[x] != x) {
                val next = parent[x]
                parent[x] = root
                x = next
            }
            return root
        }

        fun componentMembers(value: Int): List<Int> = members[find(value)]

        fun union(a: Int, b: Int) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) {
                val tmp = ra; ra = rb; rb = tmp
            }
            parent[rb] = ra
            members[ra].addAll(members[rb])
            members[rb].clear()
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)

        // All configured prediction sources: prediction records.
        scraped.forEach { s ->
            records += Record(
                homeTeam = s.homeTeam,
                awayTeam = s.awayTeam,
                predictedScore = s.predictedScore,
                source = s.source,
                sourceMatchId = s.sourceMatchId,
                matchTimestamp = s.matchTimestamp,
                matchDate = s.matchDate,
                matchTime = s.matchTime,
                competitionName = s.competitionName,
                countryName = s.countryName
            )
        }

        // Source 6: official Iddaa fixture/market records.
        officialMatches.forEach { o ->
            records += Record(
                homeTeam = o.homeTeam,
                awayTeam = o.awayTeam,
                source = "IDDAA",
                sourceMatchId = o.matchId,
                matchTimestamp = o.matchTimestamp,
                matchDate = o.matchDate,
                matchTime = o.matchTime,
                competitionName = o.competitionName,
                countryName = o.countryName,
                official = o
            )
        }

        if (records.isEmpty()) return emptyList()

        val uf = UnionFind(records.size)
        // Score/evidence is pure for a record pair. Cache it locally so the
        // component safety gate and later passes never recompute the same
        // canonicalization/Levenshtein work.
        val evidenceCache = HashMap<Long, MatchEvidence>(records.size * 8)
        fun cachedScore(aIndex: Int, bIndex: Int): MatchEvidence {
            val lo = minOf(aIndex, bIndex).toLong()
            val hi = maxOf(aIndex, bIndex).toLong()
            val key = (lo shl 32) xor (hi and 0xffffffffL)
            return evidenceCache[key] ?: score(records[aIndex], records[bIndex]).also { evidenceCache[key] = it }
        }

        // PASS 1 -----------------------------------------------------
        // Official anchor: same official ID is absolute identity inside
        // the official namespace. Never compare IDs from different providers.
        val officialIdIndex = HashMap<String, Int>()
        records.indices.forEach { index ->
            val record = records[index]
            if (record.official != null) {
                val id = record.sourceMatchId.trim()
                if (id.isNotBlank()) {
                    officialIdIndex[id]?.let { uf.union(it, index) } ?: run {
                        officialIdIndex[id] = index
                    }
                }
            }
        }

        // PASS 2 -----------------------------------------------------
        // Canonical fixture key is deterministic and does not depend on the
        // arrival order of sources. This is the main fix for AEK/LASK variants.
        // A component may only grow when EVERY record in the two components is
        // mutually compatible. This prevents transitive false fixtures such as
        // Orlando-Toronto + Miami-Nashville => Toronto-Nashville.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { index ->
            val key = records[index].fixtureKey
            if (key != "||") exactBuckets.getOrPut(key) { mutableListOf() }.add(index)
        }
        exactBuckets.values.forEach { bucket ->
            for (i in 1 until bucket.size) {
                // Exact team names are not enough to merge fixtures from different
                // dates/kickoffs. Reuse the same evidence gate so PASS 2 cannot
                // bypass the hard time/competition filters.
                if (cachedScore(bucket[0], bucket[i]).accepted &&
                    componentsCompatible(uf, bucket[0], bucket[i], ::cachedScore)) {
                    uf.union(bucket[0], bucket[i])
                }
            }
        }

        // PASS 3 -----------------------------------------------------
        // Official anchor matching first.
        val officialByFixtureKey = HashMap<String, MutableList<Int>>()
        val officialIndices = ArrayList<Int>(officialMatches.size)
        records.indices.forEach { index ->
            if (records[index].official != null) {
                officialIndices += index
                officialByFixtureKey.getOrPut(records[index].fixtureKey) { mutableListOf() }.add(index)
            }
        }
        // Official anchor matching first. A prediction source with no time/ID
        // can still attach to the official fixture because the official fixture
        // is today's authoritative roster. Team agreement is always two-sided.
        records.indices.forEach { i ->
            val candidate = records[i]
            if (candidate.official != null) return@forEach

            var bestIndex = -1
            var bestScore = -1.0

            // Most provider records already canonicalize to the exact official
            // HOME/AWAY identity. Search that tiny bucket first; only fall back
            // to the full official roster when canonical identity is unavailable
            // or the exact bucket is rejected by a hard time/competition gate.
            val exactCandidates = officialByFixtureKey[candidate.fixtureKey].orEmpty()
            for (j in exactCandidates) {
                if (!similarityCandidate(candidate, records[j])) continue
                val evidence = cachedScore(i, j)
                if (evidence.accepted && evidence.confidence > bestScore) {
                    bestScore = evidence.confidence
                    bestIndex = j
                }
            }

            // Preserve the old fallback behavior when an exact canonical pair
            // exists but every exact candidate is rejected by a hard evidence
            // gate. This keeps recall behavior unchanged while making the normal
            // path O(number of exact official duplicates) instead of O(all official).
            if (bestIndex < 0) {
                for (j in officialIndices) {
                    if (exactCandidates.contains(j)) continue
                    if (!similarityCandidate(candidate, records[j])) continue
                    val evidence = cachedScore(i, j)
                    if (evidence.accepted && evidence.confidence > bestScore) {
                        bestScore = evidence.confidence
                        bestIndex = j
                    }
                }
            }
            if (bestIndex >= 0 &&
                componentsCompatibleWithOfficialAnchor(
                    uf, i, bestIndex, records, ::cachedScore
                )) {
                uf.union(i, bestIndex)
            }
        }

        // PASS 4 -----------------------------------------------------
        // Global fuzzy clustering among non-official records. No prefix block,
        // no greedy "first match wins". Pair decisions are evidence based.
        // IMPORTANT: Union-Find connectivity alone is NOT fixture identity.
        // Before any union we require the two entire components to be mutually
        // compatible. This blocks A-B + B-C from becoming a false A-C fixture.
        for (i in records.indices) {
            for (j in i + 1 until records.size) {
                val a = records[i]
                val b = records[j]
                if (sameSourceDifferentIds(a, b)) continue
                // Official fixtures are already handled by PASS 1/3. Keeping
                // them out of global fuzzy clustering prevents an official
                // record from acting as a bridge between unrelated predictions.
                if (a.official != null || b.official != null) continue
                // Context-first candidate reduction: do not spend team similarity
                // work on pairs from contradictory country/competition buckets.
                if (!similarityCandidate(a, b)) continue

                val evidence = cachedScore(i, j)
                if (!evidence.accepted) continue

                // High-confidence fuzzy pairs may union globally. Exact canonical
                // fixtures were already unioned in PASS 2; official anchors were
                // handled in PASS 3.
                if (evidence.idAnchor ||
                    evidence.officialAnchor ||
                    evidence.confidence >= AUTO_MERGE_CONFIDENCE) {
                    if (componentsCompatible(uf, i, j, ::cachedScore)) {
                        uf.union(i, j)
                    }
                }
            }
        }

        // Build connected components.
        val grouped = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { index ->
            grouped.getOrPut(uf.find(index)) { mutableListOf() }.add(records[index])
        }

        return grouped.values.map(::buildUnified)
    }

    /**
     * Prevents transitive fixture pollution. A union is allowed only when every
     * record already in component A is compatible with every record already in
     * component B. Pairwise graph connectivity is not sufficient for a fixture:
     * A~B and B~C must NOT imply A~C.
     */
    /**
     * Official-anchor union rule.
     *
     * A prediction source does NOT need to be compatible with every other
     * prediction source already attached to the same official fixture. Each
     * provider is allowed to identify the official fixture independently. This
     * is essential when one provider says "Bayern Munih" and another says
     * "Bayern Munich" or uses a completely different language/abbreviation.
     *
     * The official record remains the single bridge. Two different official
     * fixture IDs can never be bridged by this helper.
     */
    private fun componentsCompatibleWithOfficialAnchor(
        uf: UnionFind,
        aIndex: Int,
        bIndex: Int,
        records: List<Record>,
        scorer: (Int, Int) -> MatchEvidence
    ): Boolean {
        val rootA = uf.find(aIndex)
        val rootB = uf.find(bIndex)
        if (rootA == rootB) return true

        val membersA = uf.componentMembers(rootA)
        val membersB = uf.componentMembers(rootB)
        val officialA = membersA.filter { records[it].official != null }
        val officialB = membersB.filter { records[it].official != null }

        // If neither component has an official anchor, use the strict global
        // component safety rule.
        if (officialA.isEmpty() && officialB.isEmpty()) {
            return componentsCompatible(uf, aIndex, bIndex, scorer)
        }

        // Distinct official fixtures are never allowed to merge.
        if (officialA.isNotEmpty() && officialB.isNotEmpty()) {
            val idsA = officialA.map { records[it].sourceMatchId.trim() }.filter { it.isNotBlank() }.toSet()
            val idsB = officialB.map { records[it].sourceMatchId.trim() }.filter { it.isNotBlank() }.toSet()
            if (idsA.isNotEmpty() && idsB.isNotEmpty() && idsA.intersect(idsB).isEmpty()) return false
            return officialA.all { a -> officialB.all { b -> scorer(a, b).accepted } }
        }

        // Exactly one side is already anchored to Iddaa. Only the incoming
        // component needs to prove compatibility with that official fixture.
        // Do NOT require prediction-vs-prediction compatibility.
        val officialMembers = if (officialA.isNotEmpty()) officialA else officialB
        val incomingMembers = if (officialA.isNotEmpty()) membersB else membersA
        return officialMembers.all { officialIndex ->
            incomingMembers.all { incomingIndex ->
                scorer(officialIndex, incomingIndex).accepted
            }
        }
    }

    private fun componentsCompatible(
        uf: UnionFind,
        aIndex: Int,
        bIndex: Int,
        scorer: (Int, Int) -> MatchEvidence
    ): Boolean {
        val rootA = uf.find(aIndex)
        val rootB = uf.find(bIndex)
        if (rootA == rootB) return true

        // Union-Find keeps component membership incrementally. The old code
        // rescanned ALL records to discover both components for every accepted
        // pair, turning a few hundred fixtures into a very expensive nested
        // hot path. We keep the exact same pairwise safety rule, but inspect only
        // the two actual components.
        val membersA = uf.componentMembers(rootA)
        val membersB = uf.componentMembers(rootB)
        for (a in membersA) {
            for (b in membersB) {
                if (!scorer(a, b).accepted) return false
            }
        }
        return true
    }

    /**
     * Cheap fixture-context prefilter. It runs BEFORE any team-name similarity
     * calculation. If both records explicitly identify a country or competition
     * and those contexts contradict each other, the pair is not even eligible
     * for Jaro/Levenshtein/phonetic comparison. Missing metadata is treated as
     * unknown rather than as a contradiction; this preserves recall for providers
     * that omit league/country fields.
     */
    private fun contextCompatibleBeforeSimilarity(a: Record, b: Record): Boolean {
        val countryA = a.countryName.trim()
        val countryB = b.countryName.trim()
        if (countryA.isNotBlank() && countryB.isNotBlank()) {
            val country = contextScore(countryA, countryB)
            if (country < 0.80) return false
        }

        val competitionA = a.competitionName.trim()
        val competitionB = b.competitionName.trim()
        if (competitionA.isNotBlank() && competitionB.isNotBlank()) {
            val competition = competitionScore(competitionA, competitionB)
            if (competition < 0.80) return false
        }
        return true
    }

    /** Same prefilter exposed to the merge passes so the candidate universe is
     * reduced before expensive team similarity is requested. */
    private fun similarityCandidate(a: Record, b: Record): Boolean =
        contextCompatibleBeforeSimilarity(a, b)

    /** Public for regression tests and diagnostics. */
    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() ||
            b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, 0.0, false, false, 0.0, false)
        }

        if (sameSourceDifferentIds(a, b)) {
            return MatchEvidence(0.0, 0.0, 0.0, -1.0, 0.0, false, false, 0.0, false)
        }

        // CONTEXT-FIRST GATE: country/competition contradictions are rejected
        // before any team-name similarity or phonetic work. This prevents
        // Arsenal (England) from entering the same fuzzy candidate space as
        // Arsenal de Sarandi (Argentina).
        if (!contextCompatibleBeforeSimilarity(a, b)) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, -1.0, false, false, 0.0, false)
        }

        // CANONICAL INTEGRATION GATE (v0.23.2): every team comparison MUST
        // pass through TeamAliasCanonicalizer before any similarity operation.
        // Raw provider names are retained only for diagnostics/display.
        val homeCanonicalA = a.homeIdentity.canonicalName
        val homeCanonicalB = b.homeIdentity.canonicalName
        val awayCanonicalA = a.awayIdentity.canonicalName
        val awayCanonicalB = b.awayIdentity.canonicalName

        val homeBase = TeamAliasCanonicalizer.similarityCanonical(
            homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
        )
        val awayBase = TeamAliasCanonicalizer.similarityCanonical(
            awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
        )
        val home = enrichedNameSimilarity(homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam, homeBase)
        val away = enrichedNameSimilarity(awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam, awayBase)
        val teamScore = (home + away) / 2.0
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
            TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val exactAway = TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val exactHome = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam)
        val exactCanonicalTeams =
            homeCanonicalA.isNotBlank() && homeCanonicalA == homeCanonicalB &&
            awayCanonicalA.isNotBlank() && awayCanonicalA == awayCanonicalB &&
            home >= 0.99 && away >= 0.99
        val idAnchor = sameComparableId(a, b)
        val officialAnchor = a.official != null || b.official != null
        val time = timeScore(a, b)
        val competition = competitionScore(a.competitionName, b.competitionName)
        val country = contextScore(a.countryName, b.countryName)

        // The official Iddaa fixture is the authority for today's roster. Some
        // prediction providers publish a stale/wrong competition label (or a
        // timezone-shifted kickoff) while still naming the exact same two teams.
        // When the canonical HOME and AWAY identities are exact, do not let a
        // provider-side competition/time mismatch erase an otherwise certain
        // official fixture. This is deliberately limited to official-anchor
        // matching; non-official clustering keeps the strict contradiction gates.
        // Exact team identity is strong, but it must never override a hard
        // kickoff contradiction. Without this guard, the same teams appearing
        // in different fixtures (for example a league rematch) could be attached
        // to the wrong official event merely because the names are exact.
        if (officialAnchor && time >= 0.0 && (exactTeams || exactCanonicalTeams)) {
            val confidence = (
                0.92 +
                    0.04 * time.coerceAtLeast(0.0) +
                    0.04 * if (competition >= 0.0) competition else 0.0
            ).coerceIn(0.92, 0.99)
            return MatchEvidence(
                homeSimilarity = home,
                awaySimilarity = away,
                teamScore = 1.0,
                timeScore = time,
                competitionScore = competition,
                idAnchor = idAnchor,
                officialAnchor = true,
                confidence = confidence,
                accepted = true,
                homeCanonicalA = homeCanonicalA,
                homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA,
                awayCanonicalB = awayCanonicalB
            )
        }

        // OFFICIAL-ANCHOR FALLBACK WHEN PROVIDER METADATA IS MISSING:
        // Prediction parsers may publish only team + score and omit reliable
        // date/time/competition fields. In that situation
        // the previous matcher returned time=0.0 / competition=0.0 and then
        // required the full schedule gate, so valid Iddaa fixtures were silently
        // classified as "fixture-yok". The official Iddaa record already owns
        // the authoritative date/time/competition. If the provider has NO
        // schedule metadata at all, use the official fixture as the schedule
        // anchor and require strong team identity instead.
        //
        // This is deliberately narrower than generic fuzzy clustering: it is
        // only available against an official Iddaa record, and the non-official
        // side must prove at least one exact canonical team plus strong identity
        // on the other side. Thus language pairs such as Israel/İsrail work while
        // arbitrary same-city collisions do not.
        val providerScheduleMissing =
            a.matchTimestamp <= 0L && b.matchTimestamp > 0L &&
                (a.matchTime.isBlank() || a.matchTime == "--:--") &&
                a.competitionName.isBlank()
        val reverseProviderScheduleMissing =
            b.matchTimestamp <= 0L && a.matchTimestamp > 0L &&
                (b.matchTime.isBlank() || b.matchTime == "--:--") &&
                b.competitionName.isBlank()
        val oneSidedCanonicalAnchor =
            (homeCanonicalA == homeCanonicalB && home >= 0.99) ||
                (awayCanonicalA == awayCanonicalB && away >= 0.99)
        val otherSideIdentity =
            teamIdentityEvidence(homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam) &&
                teamIdentityEvidence(awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam)
        val strongFuzzyOfficialIdentity =
            home >= 0.74 && away >= 0.74 && teamScore >= 0.79
        if (officialAnchor &&
            (providerScheduleMissing || reverseProviderScheduleMissing) &&
            (oneSidedCanonicalAnchor && otherSideIdentity || strongFuzzyOfficialIdentity)) {
            return MatchEvidence(
                home, away, 1.0, 1.0,
                if (competition >= 0.0) competition else 0.0,
                idAnchor = false, officialAnchor = true,
                confidence = 0.95, accepted = true,
                homeCanonicalA = homeCanonicalA, homeCanonicalB = homeCanonicalB,
                awayCanonicalA = awayCanonicalA, awayCanonicalB = awayCanonicalB
            )
        }

        // SCHEDULE + COMPETITION + ONE-SIDE TEAM ANCHOR:
        // Date + kickoff + competition are the hard fixture gates. Once those
        // three pieces are identical, a clear team identity on EITHER side is
        // enough to survive a language/name variant on the other side.
        //
        // Examples:
        //   Austria - Israel  <->  Avusturya - İsrail
        //   Manchester United - Arsenal <-> Man Utd - Arsenal
        //
        // The anchor may be an exact canonical identity or a very strong
        // canonical similarity (>= 0.97). This is intentionally NOT a fuzzy
        // schedule-free merge: without the exact date/time/competition gate it
        // cannot fire.
        // Full fixture-context anchor: when date + kickoff + league + country
        // agree, team names only need to retain a meaningful two-sided identity.
        // This is the intended path for translated provider names.
        val fullContextAnchor =
            sameExplicitSchedule(a, b) &&
                competition >= 0.80 &&
                country >= 0.80 &&
                home >= 0.60 &&
                away >= 0.60 &&
                teamScore >= 0.68
        if (fullContextAnchor) {
            return MatchEvidence(
                home, away, teamScore, 1.0, competition, idAnchor, officialAnchor,
                0.96, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB,
                country
            )
        }

        val scheduleAndCompetition = sameExplicitSchedule(a, b) && competition >= 0.80 && country >= 0.0
        val strongHomeAnchor = exactHome || home >= 0.97
        val strongAwayAnchor = exactAway || away >= 0.97
        if (scheduleAndCompetition && (strongHomeAnchor || strongAwayAnchor)) {
            return MatchEvidence(
                home, away, 1.0, 1.0, competition, idAnchor, false, 0.97, true,
                homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB
            )
        }

        // A provider can translate the competition name (for example an English
        // league label versus its Turkish bulletin label). When the official
        // kickoff is aligned and both teams strongly identify the same fixture,
        // a textual competition mismatch is not enough to reject the match.
        // Outside that official/time-aligned context, an explicit contradiction
        // remains a hard rejection.
        val translatedCompetitionWithStrongSchedule =
            officialAnchor && time >= 0.85 && teamScore >= 0.79
        if (competition < 0.0 && !translatedCompetitionWithStrongSchedule) {
            return MatchEvidence(home, away, teamScore, time, competition, false, officialAnchor, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // Same official ID or same ID in the same source is the strongest anchor.
        if (idAnchor) {
            return MatchEvidence(home, away, teamScore, maxOf(0.0, time), competition, true, officialAnchor, 1.0, true)
        }

        // Official roster is authoritative for today's fixtures. Do not let a
        // provider timezone/date contradiction reject a strong two-sided name match.
        if (time < 0.0 && !officialAnchor) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (officialAnchor) {
            // A known kickoff contradiction is a hard rejection for every official
            // matching path, including fuzzy identity. Exact team names must never
            // override a different fixture date/time.
            if (time < 0.0) {
                return MatchEvidence(
                    home, away, teamScore, time, competition, false, true, 0.0, false,
                    homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB
                )
            }

            // Official matching must prove TEAM IDENTITY, not merely string
            // similarity. This prevents collisions such as:
            //   Minnesota United -> Manchester United
            //   Al Sailiya -> Al Quwa Al Jawiya
            //   Ostersunds -> Estrela (Braga)
            // while still accepting legitimate provider expansions such as:
            //   Bokelj -> FK Bokelj Kotor
            //   Otrant -> FK Otrant-Olympic Ulcinj
            //   Dallas -> FC Dallas
            val homeIdentity = teamIdentityEvidence(
                homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam
            )
            val awayIdentity = teamIdentityEvidence(
                awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam
            )
            // Official-anchor matching is deliberately more recall-oriented than
            // generic clustering. The official fixture supplies the event context,
            // so a provider can use a translated/abbreviated team name. Identity
            // evidence may therefore come from either an explicit alias/subset OR
            // a strong two-sided canonical similarity.
            val scheduleStrong = time >= 0.85 || (sameExplicitSchedule(a, b) && competition >= 0.80)
            val fuzzyTwoSided = home >= 0.74 && away >= 0.74 && teamScore >= 0.79
            val oneSideExactWithContext =
                (strongTeamAnchor(homeCanonicalA, homeCanonicalB, a.homeTeam, b.homeTeam) && away >= 0.68) ||
                    (strongTeamAnchor(awayCanonicalA, awayCanonicalB, a.awayTeam, b.awayTeam) && home >= 0.68)
            val accepted = exactTeams || exactCanonicalTeams ||
                (homeIdentity && awayIdentity) ||
                (scheduleStrong && (fuzzyTwoSided || oneSideExactWithContext))
            if (!accepted) {
                return MatchEvidence(home, away, teamScore, time, competition, false, true, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
            }
            // Weighted fixture score: home 30%, away 30%, time 20%,
            // competition 10%, country 10%. Team score itself is the mean of
            // the home/away evidence, so both sides materially affect identity.
            val weightedFixtureScore =
                0.30 * home +
                    0.30 * away +
                    0.20 * time.coerceAtLeast(0.0) +
                    0.10 * competition.coerceAtLeast(0.0) +
                    0.10 * country.coerceAtLeast(0.0)
            val confidence = weightedFixtureScore.coerceIn(0.0, 0.99)
            return MatchEvidence(home, away, teamScore, time, competition, false, true, confidence, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        // Non-official fuzzy match: both sides must pass. A one-sided high score
        // is never sufficient.
        if (home < TEAM_FUZZY_MIN || away < TEAM_FUZZY_MIN || teamScore < MATCH_FUZZY_MIN) {
            return MatchEvidence(home, away, teamScore, time, competition, false, false, 0.0, false, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        if (exactTeams) {
            return MatchEvidence(home, away, 1.0, time, competition, false, false, 0.99, true, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
        }

        val timeContribution = if (time > 0.0) time else 0.0
        // Weighted score for non-official clustering. Home/away identity and
        // schedule context are intentionally more important than raw text.
        var confidence =
            0.30 * home +
                0.30 * away +
                0.20 * timeContribution +
                0.10 * competition.coerceAtLeast(0.0) +
                0.10 * country.coerceAtLeast(0.0)
        confidence = confidence.coerceIn(0.0, 0.99)

        return MatchEvidence(home, away, teamScore, time, competition, false, false, confidence, confidence >= AUTO_MERGE_CONFIDENCE, homeCanonicalA, homeCanonicalB, awayCanonicalA, awayCanonicalB)
    }

    private fun strongTeamAnchor(
        canonicalA: String,
        canonicalB: String,
        rawA: String,
        rawB: String
    ): Boolean {
        if (canonicalA.isBlank() || canonicalB.isBlank()) return false
        if (TeamAliasCanonicalizer.exact(rawA, rawB) || canonicalA == canonicalB) return true
        val a = canonicalA.split(' ').filter(String::isNotBlank).toSet()
        val b = canonicalB.split(' ').filter(String::isNotBlank).toSet()
        val smaller = if (a.size <= b.size) a else b
        val larger = if (a.size <= b.size) b else a
        if (smaller.isNotEmpty() && larger.containsAll(smaller)) {
            val distinctive = smaller.any { it.length >= 4 && it !in setOf("city", "club", "united", "sport") }
            if (distinctive) return true
        }
        return TeamAliasCanonicalizer.similarityCanonical(canonicalA, canonicalB, rawA, rawB) >= 0.90
    }

    private fun enrichedNameSimilarity(
        canonicalA: String,
        canonicalB: String,
        rawA: String,
        rawB: String,
        canonicalScore: Double
    ): Double {
        if (canonicalScore >= 0.99) return 1.0
        val a = comparisonText(canonicalA.ifBlank { rawA })
        val b = comparisonText(canonicalB.ifBlank { rawB })
        if (a.isBlank() || b.isBlank()) return canonicalScore
        val jw = jaroWinkler.apply(a, b)
        val maxLen = maxOf(a.length, b.length).coerceAtLeast(1)
        val lev = 1.0 - (levenshteinDistance.apply(a, b).toDouble() / maxLen)
        val ng = ngramDistance.apply(a, b).toDouble()
        val mpA = doubleMetaphone.doubleMetaphone(a)
        val mpB = doubleMetaphone.doubleMetaphone(b)
        val metaphone = when {
            mpA.isBlank() || mpB.isBlank() -> 0.0
            mpA == mpB -> 1.0
            doubleMetaphone.isDoubleMetaphoneEqual(a, b) -> 0.94
            else -> 0.0
        }
        val combined = 0.30 * canonicalScore + 0.25 * jw + 0.20 * lev + 0.15 * ng + 0.10 * metaphone
        return maxOf(canonicalScore, combined).coerceIn(0.0, 1.0)
    }

    private fun comparisonText(value: String): String = value
        .lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun contextScore(a: String, b: String): Double {
        val ca = normalizeContext(a)
        val cb = normalizeContext(b)
        if (ca.isBlank() || cb.isBlank()) return 0.0
        if (ca == cb) return 1.0
        val sa = ca.split(' ').filter(String::isNotBlank).toSet()
        val sb = cb.split(' ').filter(String::isNotBlank).toSet()
        if (sa.isNotEmpty() && sb.isNotEmpty()) {
            val smaller = if (sa.size <= sb.size) sa else sb
            val larger = if (sa.size <= sb.size) sb else sa
            if (larger.containsAll(smaller)) return 0.95
        }
        val compactA = ca.replace(" ", "")
        val compactB = cb.replace(" ", "")
        val maxLen = maxOf(compactA.length, compactB.length)
        if (maxLen == 0) return 0.0
        val similarity = 1.0 - levenshtein(compactA, compactB).toDouble() / maxLen
        return if (similarity >= 0.80) similarity else -1.0
    }

    private fun normalizeContext(value: String): String {
        var v = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ı", "i").replace("ğ", "g").replace("ü", "u")
            .replace("ş", "s").replace("ö", "o").replace("ç", "c")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ").trim()
        v = mapOf(
            "turkiye" to "turkey", "turkey" to "turkey",
            "ingiltere" to "england", "england" to "england",
            "almanya" to "germany", "germany" to "germany",
            "ispanya" to "spain", "spain" to "spain",
            "italya" to "italy", "italy" to "italy",
            "fransa" to "france", "france" to "france",
            "portekiz" to "portugal", "portugal" to "portugal",
            "hollanda" to "netherlands", "netherlands" to "netherlands",
            "belcika" to "belgium", "belgium" to "belgium",
            "avusturya" to "austria", "austria" to "austria",
            "isvicre" to "switzerland", "switzerland" to "switzerland",
            "yunanistan" to "greece", "greece" to "greece"
        )[v] ?: v
        return v
    }

    /**
     * Strong team-identity evidence for official fixture matching.
     *
     * Similarity alone is intentionally NOT identity. Common words such as
     * "al", "city", "united", "fc" and short fragments can make unrelated
     * clubs look deceptively close.
     *
     * We accept only:
     *  - exact canonical identity; or
     *  - a conservative token-subset expansion where the shorter canonical name
     *    is wholly contained in the longer one and contains a distinctive token
     *    (>= 5 chars). This covers source expansions like "Bokelj" ->
     *    "Bokelj Kotor" without making generic words an identity anchor.
     */
    private fun teamIdentityEvidence(
        canonicalA: String,
        canonicalB: String,
        rawA: String,
        rawB: String
    ): Boolean {
        if (canonicalA.isBlank() || canonicalB.isBlank()) return false
        if (TeamAliasCanonicalizer.exact(rawA, rawB)) return true
        if (canonicalA == canonicalB) return true

        val aTokens = canonicalA.split(' ').filter(String::isNotBlank).toSet()
        val bTokens = canonicalB.split(' ').filter(String::isNotBlank).toSet()
        if (aTokens.isEmpty() || bTokens.isEmpty()) return false

        val smaller = if (aTokens.size <= bTokens.size) aTokens else bTokens
        val larger = if (aTokens.size <= bTokens.size) bTokens else aTokens
        if (!larger.containsAll(smaller)) return false

        // Generic edge words are never allowed to establish identity.
        val generic = setOf(
            "al", "el", "the", "fc", "fci", "fk", "sk", "cd", "nk",
            "afc", "ff", "cf", "sc", "ac", "as", "bsc", "rc", "sv",
            "bk", "pfc", "club", "city", "united"
        )
        val distinctive = smaller.filter { it.length >= 5 && it !in generic }
        return distinctive.isNotEmpty()
    }

    private fun competitionScore(a: String, b: String): Double {
        val ca = normalizeCompetition(a)
        val cb = normalizeCompetition(b)
        if (ca.isBlank() || cb.isBlank()) return 0.0
        if (ca == cb) return 1.0
        val compactA = ca.replace(" ", "")
        val compactB = cb.replace(" ", "")
        if (compactA == compactB) return 1.0
        val maxLen = maxOf(compactA.length, compactB.length)
        if (maxLen == 0) return 1.0
        val distance = levenshtein(compactA, compactB)
        val similarity = 1.0 - distance.toDouble() / maxLen
        return if (similarity >= 0.80) similarity else -1.0
    }

    private fun normalizeCompetition(value: String): String {
        var v = value.lowercase()
            .replace("uefa ", "")
            .replace("official ", "")
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val aliases = mapOf(
            "dunya kupasi" to "world cup",
            "dunya kupasi elemeleri" to "world cup qualifiers",
            "avrupa sampiyonasi" to "european championship",
            "avrupa sampiyonasi elemeleri" to "european championship qualifiers",
            "milletler ligi" to "nations league",
            "uefa nations league" to "nations league",
            "dostluk maci" to "friendly international",
            "dostluk maclari" to "friendly international",
            "international friendly" to "friendly international",
            "friendly" to "friendly international"
        )
        v = aliases[v] ?: v
        return v
    }

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(replace, current[j - 1] + 1, previous[j] + 1)
            }
            val swap = previous; previous = current; current = swap
        }
        return previous[b.length]
    }

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, ignoreCase = true)) return false
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        return idA.isNotBlank() && idB.isNotBlank() && idA != idB
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        if (idA.isBlank() || idB.isBlank() || idA != idB) return false

        // IDs are only portable when both records explicitly belong to the same
        // provider namespace, or both are official records.
        return a.source.equals(b.source, ignoreCase = true) ||
            (a.official != null && b.official != null)
    }

    /**
     * Time evidence:
     *  1. exact/near kickoff -> positive score
     *  2. 3h is the soft tolerance requested for timezone drift
     *  3. >6h is a hard contradiction
     *  4. missing time -> neutral (0), not a penalty
     *  5. known different calendar dates -> contradiction unless timestamps are
     *     close enough to account for timezone rollover.
     */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            if (delta <= TIME_PUBLICATION_TOLERANCE_MS) return 1.0
            // Epoch timestamps are already UTC-normalized. The wider soft window
            // is reserved for providers that expose local wall-clock values as
            // timestamps with an undocumented timezone offset.
            val soft = 1.0 - ((delta - TIME_PUBLICATION_TOLERANCE_MS).toDouble() /
                (TIME_TIMEZONE_SOFT_WINDOW_MS - TIME_PUBLICATION_TOLERANCE_MS)).coerceIn(0.0, 1.0)
            return soft
        }

        val dateA = parseDate(a.matchDate)
        val dateB = parseDate(b.matchDate)
        if (dateA != null && dateB != null) {
            val days = abs(java.time.temporal.ChronoUnit.DAYS.between(dateA, dateB))
            return when {
                days == 0L -> 0.92
                // With no trustworthy timestamp we cannot safely explain a calendar-day
                // difference. Treat it as a hard contradiction rather than allowing
                // exact team names to bridge two different fixtures.
                else -> -1.0
            }
        }

        return 0.0
    }

    /**
     * Strict fixture schedule gate used by the one-sided away-team fallback.
     * Both date and kickoff must be present and equal (or timestamps must be
     * within 15 minutes), otherwise the fallback is deliberately disabled.
     */
    private fun sameExplicitSchedule(a: Record, b: Record): Boolean {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            return abs(a.matchTimestamp - b.matchTimestamp) <= 15L * 60L * 1000L
        }
        val dateA = parseDate(a.matchDate) ?: return false
        val dateB = parseDate(b.matchDate) ?: return false
        if (dateA != dateB) return false
        val timeA = parseTime(a.matchTime) ?: return false
        val timeB = parseTime(b.matchTime) ?: return false
        return timeA == timeB
    }

    private fun parseTime(value: String): LocalTime? {
        val v = value.trim()
        if (v.isBlank() || v == "--:--") return null
        return runCatching { LocalTime.parse(v, DateTimeFormatter.ofPattern("HH:mm")) }.getOrNull()
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) {
            val parsed = runCatching {
                LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(
            mainHomeTeam = display.first,
            mainAwayTeam = display.second,
            officialMatch = official,
            officialMatchId = official?.matchId.orEmpty(),
            fixtureKey = TeamAliasCanonicalizer.identity(display.first).canonicalId +
                "||" + TeamAliasCanonicalizer.identity(display.second).canonicalId
        )

        // One prediction per source. If the same provider emitted duplicates,
        // keep the record with the richest identity metadata.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { !it.predictedScore.isNullOrBlank() }.forEach { record ->
            val sourceKey = record.source.trim().lowercase()
            val old = bySource[sourceKey]
            if (old == null || sourcePriority(record) > sourcePriority(old)) {
                bySource[sourceKey] = record
            }
        }
        bySource.values.forEach { record ->
            result.predictions += record.source to record.predictedScore.orEmpty()
            result.predictionRecords += record
        }

        val predictionSources = group.filter { !it.predictedScore.isNullOrBlank() }
            .map { it.source.trim() }.filter { it.isNotBlank() }.distinct()
        result.consensusCount = predictionSources.size
        result.consensusConfidence = consensusConfidence(group)
        result.highConfidenceConsensus = predictionSources.size >= 2 && result.consensusConfidence >= 0.78
        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun chooseDisplay(
        group: List<Record>,
        official: IddaaMarketService.OpenedMarketMatch?
    ): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull {
            TeamAliasCanonicalizer.canonical(it.homeTeam).length +
                TeamAliasCanonicalizer.canonical(it.awayTeam).length
        } ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourcePriority(record: Record): Int {
        var score = 0
        if (!record.predictedScore.isNullOrBlank()) score += 5
        if (record.matchTimestamp > 0L) score += 3
        if (record.matchDate.isNotBlank()) score += 1
        if (record.sourceMatchId.isNotBlank()) score += 1
        if (record.official != null) score += 10
        return score
    }

    private fun sourceWeight(source: String): Double = when (source.trim().lowercase(Locale.ROOT)) {
        "fp.com" -> 1.00
        "predictz" -> 0.98
        "windrawwin" -> 0.96
        "dailysports" -> 0.94
        else -> 0.85
    }

    private fun consensusConfidence(group: List<Record>): Double {
        val predictionSources = group.filter { !it.predictedScore.isNullOrBlank() }
            .map { it.source.trim().lowercase(Locale.ROOT) }
            .distinct()
        if (predictionSources.size < 2) return 0.0
        // Consensus is fixture-level: two independent sources confirming the
        // same official fixture are enough even when their predicted scores differ.
        // Source weights only break ties when more than two sources participate.
        val totalWeight = predictionSources.sumOf(::sourceWeight)
        if (totalWeight <= 0.0) return 0.0
        return (predictionSources.size.coerceAtMost(3) / 3.0 * 0.5 +
            (totalWeight / predictionSources.size.coerceAtLeast(1)).coerceIn(0.0, 1.0) * 0.5).coerceIn(0.0, 1.0)
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        val accepted = mutableListOf<Double>()
        for (i in 0 until group.lastIndex) {
            for (j in i + 1..group.lastIndex) {
                val evidence = score(group[i], group[j])
                if (evidence.accepted) accepted += evidence.confidence
            }
        }
        return if (accepted.isEmpty()) 1.0 else accepted.average().coerceIn(0.0, 1.0)
    }
}
