package com.cio.skor.data

import android.util.Log
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.util.Locale

/**
 * Reads the Bet365 1X2 block from AiScore's match odds page.
 * AiScore exposes two tabs on the odds page: Opening odds and Pre-match odds.
 * We keep those two independently so the main card can show opening and
 * latest pre-match/closing without requiring an Odds Data API token.
 */
class AiScoreBet365HistoryService {
    data class Line(val ms1: String, val msX: String, val ms2: String)
    data class History(
        val opening: Line?,
        val closing: Line?,
        val current: Line?,
        val oddsUrl: String?
    )

    private val http = HttpClient()

    suspend fun fetch(matchUrl: String?, homeTeam: String, awayTeam: String): History? =
        withContext(Dispatchers.IO) {
            if (matchUrl.isNullOrBlank()) return@withContext null
            val oddsUrl = resolveOddsUrl(matchUrl) ?: return@withContext null
            val (code, body) = http.getSource(oddsUrl, "https://www.aiscore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) {
                Log.d(TAG, "AiScore odds miss code=$code $homeTeam - $awayTeam")
                return@withContext null
            }

            val document = Jsoup.parse(body, oddsUrl)
            val visible = document.text().replace(Regex("\\s+"), " ").trim()
            if (!containsTeam(visible, homeTeam) || !containsTeam(visible, awayTeam)) return@withContext null

            val opening = parseTab(document, visible, "Opening odds")
            val prematch = parseTab(document, visible, "Pre-match odds")
            val all = parseBet365Block(visible)
            val open = opening ?: all.firstOrNull()
            val current = prematch ?: all.lastOrNull()
            val close = current ?: open
            if (open == null && current == null) return@withContext null

            Log.d(TAG, "AiScore Bet365 HIT $homeTeam - $awayTeam opening=${fmt(open)} closing=${fmt(close)} url=$oddsUrl")
            History(open, close, current ?: close, oddsUrl)
        }

    private fun resolveOddsUrl(matchUrl: String): String? {
        val normalized = matchUrl.trim()
        if (normalized.contains("/odds")) return normalized

        // A live page normally links to the canonical /match-.../.../odds page.
        val (code, body) = http.getSource(normalized, "https://www.aiscore.com/")
        if (code in 200..299 && !body.isNullOrBlank()) {
            val doc = Jsoup.parse(body, normalized)
            val link = doc.select("a[href*='/match-'][href*='/odds'], a[href*='/odds']")
                .mapNotNull { it.absUrl("href").ifBlank { it.attr("href") } }
                .firstOrNull { it.contains("/match-") && it.contains("/odds") }
            if (!link.isNullOrBlank()) return link

            // Some AiScore pages expose the canonical match URL in JSON/script text.
            val regex = Regex("https?://(?:www\\.|m\\.)?aiscore\\.com/match-[a-z0-9-]+/[a-z0-9]+/odds", RegexOption.IGNORE_CASE)
            regex.find(body)?.value?.let { return it }
        }

        // If the caller already supplied a canonical /match-... URL, append odds.
        val marker = normalized.indexOf("/match-")
        if (marker >= 0) {
            val base = normalized.substring(0, normalized.length)
                .substringBefore("?")
                .trimEnd('/')
            return if (base.endsWith("/odds")) base else "$base/odds"
        }
        return null
    }

    private fun parseTab(doc: org.jsoup.nodes.Document, visible: String, tabName: String): Line? {
        // Prefer a DOM block containing both the tab label and Bet365. If the
        // page is JS-hydrated and the values are embedded in script JSON, the
        // fallback scans the text around the tab marker.
        val candidates = doc.select("body *").asSequence()
            .filter { el ->
                val t = el.text().replace(Regex("\\s+"), " ").trim()
                t.contains(tabName, true) && t.contains("Bet365", true)
            }
            .sortedBy { it.text().length }
            .toList()
        for (el in candidates) {
            val line = parseBet365Block(el.text().replace(Regex("\\s+"), " ").trim()).firstOrNull()
            if (line != null) return line
        }

        val idx = visible.indexOf(tabName, ignoreCase = true)
        if (idx >= 0) {
            val window = visible.substring(idx, minOf(visible.length, idx + 2200))
            return parseBet365Block(window).firstOrNull()
        }
        return null
    }

    private fun parseBet365Block(text: String): List<Line> {
        val lower = text.lowercase(Locale.ROOT)
        val start = lower.indexOf("bet365")
        if (start < 0) return emptyList()
        val endCandidates = listOf(
            "1xbet", "bet-at-home", "bwin", "unibet", "betfair", "pinnacle"
        ).mapNotNull { marker -> lower.indexOf(marker, start + 6).takeIf { it > start } }
        val end = endCandidates.minOrNull() ?: minOf(text.length, start + 2400)
        val block = text.substring(start, end)
        val nums = Regex("(?<![0-9])([1-9][0-9]?\\.[0-9]{1,2})(?![0-9])")
            .findAll(block)
            .map { it.groupValues[1] }
            .filter { it.toDoubleOrNull()?.let { n -> n > 1.0 && n <= 50.0 } == true }
            .toList()
        if (nums.size < 3) return emptyList()
        return nums.chunked(3).mapNotNull { triple ->
            if (triple.size == 3) Line(triple[0], triple[1], triple[2]) else null
        }
    }

    private fun containsTeam(text: String, wanted: String): Boolean {
        val t = normalize(text)
        val w = normalize(wanted)
        if (w.isBlank()) return false
        if (t.contains(w)) return true
        val tokens = w.split(' ').filter { it.length >= 4 }
        return tokens.isNotEmpty() && tokens.count { t.contains(it) } >= minOf(2, tokens.size)
    }

    private fun normalize(value: String): String = value.lowercase(Locale.ROOT)
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()

    private fun fmt(line: Line?): String = line?.let { "${it.ms1}/${it.msX}/${it.ms2}" } ?: "-"

    companion object { private const val TAG = "CioAiScoreBet365History" }
}
