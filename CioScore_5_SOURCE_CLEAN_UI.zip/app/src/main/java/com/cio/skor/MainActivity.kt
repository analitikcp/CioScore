package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()

    private lateinit var status: TextView
    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        status = findViewById(R.id.tvStatus)
        findViewById<TextView>(R.id.tvSourceCount).text = "Skorun Merkezi"
        findViewById<TextView>(R.id.tvStatSources).text = repo.sourceCount.toString()
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        val recycler = findViewById<RecyclerView>(R.id.recyclerScores)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(emptyList())
        recycler.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        findViewById<Button>(R.id.btnScan).setOnClickListener { scan() }
        findViewById<Button>(R.id.btnClearSearch).setOnClickListener {
            searchInput.setText("")
            adapter.submitList(allGroups)
        }

        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        adapter.submitList(emptyList())
        findViewById<TextView>(R.id.tvStatSources).text = "0"
        findViewById<TextView>(R.id.tvStatScores).text = "0"
        findViewById<TextView>(R.id.tvStatMatches).text = "0"

        scope.launch {
            val results = withContext(Dispatchers.IO) {
                repo.fetchAll { _, _ ->
                    // İlerleme sırasında kaynak adı ekranda gösterilmez.
                }
            }

            val scores = results
                .flatMap { result -> result.scores }
                .filter(::isDisplayable)
                .distinctBy {
                    "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                    "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                    "${it.predictedScore}|${it.source.trim().lowercase()}"
                }

            val goodSources = scores.map { sourceLabel(it.source) }
                .filter { it.isNotEmpty() }
                .distinct()

            // Önce bütün ham kayıtlar toplanır, sonra MatchMerger ile birleştirilir.
            val unified = MatchMerger.mergeMatches(scores)
            allGroups = unified.map { match ->
                MatchGroup(
                    homeTeam = match.mainHomeTeam,
                    awayTeam = match.mainAwayTeam,
                    predictions = match.predictions.map { (source, score) ->
                        ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                    }
                )
            }

            adapter.submitList(allGroups)
            findViewById<TextView>(R.id.tvStatSources).text = goodSources.size.toString()
            findViewById<TextView>(R.id.tvStatScores).text = scores.size.toString()
            findViewById<TextView>(R.id.tvStatMatches).text = allGroups.size.toString()
        }
    }

    private fun sourceLabel(source: String): String = when (source.trim().lowercase()) {
        "fp.com" -> "cio1"
        "predictz" -> "cio2"
        "windrawwin" -> "cio3"
        "soccerseer" -> "cio4"
        "dailysports" -> "cio5"
        "cio1", "cio2", "cio3", "cio4", "cio5" -> source.trim().lowercase()
        else -> source.trim().lowercase()
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
