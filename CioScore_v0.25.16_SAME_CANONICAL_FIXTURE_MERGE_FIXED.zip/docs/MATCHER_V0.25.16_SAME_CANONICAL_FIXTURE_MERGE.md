# CioScore v0.25.16 — Same Canonical Fixture Merge Fix

## Problem reproduced

When multiple prediction providers publish the same fixture, the UI could render
multiple cards for the same canonical HOME/AWAY pair. The failure was especially
visible for national-team fixtures such as:

- Niger — Lesotho
- provider A: 2-1
- provider B: 1-0
- provider C: 2-1
- official Iddaa fixture: Niger — Lesotho

The identity engine already canonicalized the two team names, but PASS 3 used the
first record in a canonical HOME/AWAY bucket as the sole comparison representative.
A provider-specific timestamp/metadata difference could therefore leave another
record outside the connected component.

## Fix

`GlobalFixtureMatcher` now has a deterministic **PASS 3A**:

- exact canonical HOME identity **and** exact canonical AWAY identity are required;
- records are bucketed by canonical fixture + normalized calendar date;
- cross-provider records in the same exact fixture/date bucket are reconciled;
- provider epoch timestamps are not used as the sole blocker because providers can
  construct timestamps using different timezone conventions;
- if both displayed kickoff times exist, a >12-hour contradiction is still rejected;
- same-provider records with different source IDs remain protected by the existing
  hard barrier;
- national-team fixtures and fixtures containing an official Iddaa anchor may
  reconcile despite provider-specific competition labels;
- fuzzy/partial team matches still use the existing evidence and component safety
  rules.

This keeps the safety boundary for unrelated fixtures while removing the
order-sensitive split that produced duplicate cards.

## UI invariant

`ScoreAdapter` already renders all predictions carried by one `MatchGroup`, so
after reconciliation the Niger — Lesotho example becomes **one card** containing
the available source predictions (for example 2-1, 1-0, 2-1), rather than three
separate cards.

## Regression check

A standalone Kotlin compilation was run against the matcher/data layer with a
three-provider Niger — Lesotho fixture plus an official Iddaa record. Result:

`groups=1`

and the unified group contained all three provider predictions.

A full Android Gradle build could not be executed in this environment because the
Gradle wrapper distribution was not locally cached and external dependency
resolution was unavailable. The matcher/data Kotlin sources were compiled
successfully with `kotlinc`.
