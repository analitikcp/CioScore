package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** Forebet correct-score parser. */
class ForebetParser : BaseParser("Forebet") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val blocks = doc.select("div.rcnt")
        for (block in blocks) {
            val pair = extractTeams(block) ?: continue
            val home = cleanForebetTeam(pair.first)
            val away = cleanForebetTeam(pair.second)
            if (!valid(home, away)) continue

            val predictedScore = extractCorrectScore(block)
                ?: extractPredictedScore(block)
                ?: continue

            val model = ScoreModel(home, away, predictedScore, source)
            out[model.matchKey] = model
        }

        return out.values.toList()
    }

    private fun extractTeams(block: Element): Pair<String, String>? {
        val home = block.selectFirst("span.homeTeam")?.text()?.trim()
        val away = block.selectFirst("span.awayTeam")?.text()?.trim()
        if (!home.isNullOrBlank() && !away.isNullOrBlank()) return home to away

        // Forebet has historically exposed the fixture name as meta[itemprop=name].
        val meta = block.selectFirst("meta[itemprop=name][content]")?.attr("content")?.trim()
        if (!meta.isNullOrBlank()) {
            val separators = listOf(" vs ", " - ", " – ", " — ")
            for (sep in separators) {
                val parts = meta.split(sep, limit = 2)
                if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                    return parts[0].trim() to parts[1].trim()
                }
            }
        }

        // Last-resort DOM fallback for minor markup changes.
        val links = block.select("a.tnmscn")
        if (links.size >= 2) {
            val h = links[0].selectFirst("span.homeTeam")?.text() ?: links[0].text()
            val a = links[1].selectFirst("span.awayTeam")?.text() ?: links[1].text()
            if (h.isNotBlank() && a.isNotBlank()) return h.trim() to a.trim()
        }
        return null
    }

    private fun extractCorrectScore(block: Element): String? {
        val selectors = listOf(
            "div.ex_sc.tabonly",
            "div.ex_sc",
        )
        for (selector in selectors) {
            for (element in block.select(selector)) {
                exactScore(element.text())?.let { return it }
            }
        }
        return null
    }

    private fun extractPredictedScore(block: Element): String? {
        // Current Forebet pages expose 1X2 prediction in forepr, not a score.
        // Some older layouts exposed a score there, so retain it as fallback.
        for (element in block.select("span.forepr, .forepr")) {
            exactScore(element.text())?.let { return it }
        }
        return null
    }

    private fun exactScore(value: String): String? {
        val text = value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ").trim()
        val match = Regex("^([0-9]{1,2})\\s*[-:]\\s*([0-9]{1,2})$").matchEntire(text)
            ?: return null
        val h = match.groupValues[1].toIntOrNull() ?: return null
        val a = match.groupValues[2].toIntOrNull() ?: return null
        if (h > 9 || a > 9) return null
        return "$h-$a"
    }

    private fun cleanForebetTeam(value: String): String =
        value.replace('\u00A0', ' ').replace(Regex("\\s+"), " ")
            .trim(' ', '-', '–', '—', ':', '|')
}
