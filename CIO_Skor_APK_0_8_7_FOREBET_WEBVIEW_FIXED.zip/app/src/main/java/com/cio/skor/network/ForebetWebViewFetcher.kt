package com.cio.skor.network

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * Forebet fallback fetcher.
 *
 * Forebet can return a different/challenge page to a raw Android HTTP client.
 * A real Android WebView executes the site's JavaScript and keeps the normal
 * browser cookie/session state. We only use this when the normal HTTP request
 * produced no parseable scores.
 */
class ForebetWebViewFetcher(private val context: Context) {

    suspend fun fetch(url: String, timeoutMs: Long = 15_000L): String? =
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
                val webView = WebView(context.applicationContext)
                var finished = false
                val handler = Handler(Looper.getMainLooper())
                val timeout = Runnable {
                    if (!finished && continuation.isActive) {
                        finished = true
                        evaluateHtmlAsync(webView) { html ->
                            if (finished && continuation.isActive) {
                                safeDestroy(webView)
                                continuation.resume(html)
                            }
                        }
                    }
                }

                fun complete(html: String?) {
                    if (finished || !continuation.isActive) return
                    finished = true
                    handler.removeCallbacks(timeout)
                    safeDestroy(webView)
                    continuation.resume(html)
                }

                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.settings.databaseEnabled = true
                webView.settings.loadsImagesAutomatically = false
                webView.settings.userAgentString = DESKTOP_UA
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        handler.removeCallbacks(timeout)
                        handler.postDelayed(timeout, timeoutMs)
                    }

                    override fun onPageFinished(view: WebView?, pageUrl: String?) {
                        // Let deferred scripts/challenge redirects settle before
                        // reading the DOM.  The short delay is intentional.
                        handler.postDelayed({
                            if (finished || !continuation.isActive) return@postDelayed
                            evaluateWhenReady(webView, 0, complete)
                        }, 1000L)
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        if (request?.isForMainFrame == true) complete(null)
                    }
                }

                webView.loadUrl(url)
                handler.postDelayed(timeout, timeoutMs)

                continuation.invokeOnCancellation {
                    handler.removeCallbacks(timeout)
                    safeDestroy(webView)
                }
            }
        }

    private fun evaluateHtmlAsync(webView: WebView, callback: (String?) -> Unit) {
        webView.evaluateJavascript("document.documentElement.outerHTML") { value ->
            callback(unescapeJavascriptString(value))
        }
    }

    private fun evaluateWhenReady(
        webView: WebView,
        attempt: Int,
        callback: (String?) -> Unit
    ) {
        val script = """
            (function() {
              var rows = document.querySelectorAll('div.rcnt').length;
              var html = document.documentElement ? document.documentElement.outerHTML : '';
              if (rows > 0 || html.indexOf('Forebet') >= 0 || html.indexOf('forebet') >= 0 || $attempt >= 8) {
                return html;
              }
              return '';
            })();
        """.trimIndent()

        webView.evaluateJavascript(script) { value ->
            val html = unescapeJavascriptString(value)
            if (!html.isNullOrBlank() && (html.contains("rcnt") || attempt >= 8)) {
                callback(html)
            } else {
                Handler(Looper.getMainLooper()).postDelayed({
                    evaluateWhenReady(webView, attempt + 1, callback)
                }, 750L)
            }
        }
    }

    private fun unescapeJavascriptString(value: String?): String? {
        if (value == null || value == "null") return null
        return try {
            org.json.JSONTokener(value).nextValue()?.toString()
        } catch (_: Exception) {
            value.removePrefix("\"").removeSuffix("\"")
                .replace("\\u003C", "<")
                .replace("\\u003E", ">")
                .replace("\\\"", "\"")
                .replace("\\n", "\n")
                .replace("\\/", "/")
        }
    }

    private fun safeDestroy(webView: WebView) {
        try {
            webView.stopLoading()
            webView.webViewClient = null
            webView.destroy()
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/131.0.0.0 Safari/537.36"
    }
}
