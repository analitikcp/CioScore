package com.cio.skor.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.CioScoreEngine
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SofaScoreService

/** One card per unified match; source names are displayed as CIO labels. */
data class MatchGroup(
    val homeTeam: String,
    val awayTeam: String,
    val predictions: List<ScoreModel>,
    val odds: SofaScoreService.Odds? = null,
    val homeTeamId: Long? = null,
    val awayTeamId: Long? = null
)

class ScoreAdapter(
    initialList: List<MatchGroup> = emptyList(),
    private val onTeamClick: (String, Long?) -> Unit = { _, _ -> }
) : RecyclerView.Adapter<ScoreAdapter.VH>() {

    class VH(val card: LinearLayout) : RecyclerView.ViewHolder(card)

    private var fullList: List<MatchGroup> = initialList
    private var displayedList: List<MatchGroup> = initialList
    private var currentQuery = ""

    // UI MASKESİ: ScoreModel.source değerleri değiştirilmez.
    private val sourceLabels = mapOf(
        "fp.com" to "cio1",
        "predictz" to "cio2",
        "windrawwin" to "cio3",
        "soccerseer" to "cio4",
        "dailysports" to "cio5"
    )

    private fun displaySourceName(source: String): String {
        val normalized = source.trim().lowercase()

        return sourceLabels[normalized]
            ?: sourceLabels.entries
                .firstOrNull { normalized.contains(it.key) }
                ?.value
            ?: normalized
    }

    fun submitList(newList: List<MatchGroup>) {
        fullList = newList
        refreshDisplayed()
    }


    private fun refreshDisplayed() {
        val q = MatchMerger.normalizeTeamName(currentQuery)
        var list = if (q.isEmpty()) fullList else fullList.filter { match ->
            val home = MatchMerger.normalizeTeamName(match.homeTeam)
            val away = MatchMerger.normalizeTeamName(match.awayTeam)
            home.contains(q) || away.contains(q) ||
                MatchMerger.isSameTeam(home, q) || MatchMerger.isSameTeam(away, q)
        }
        displayedList = list
        notifyDataSetChanged()
    }

    fun update(v: List<MatchGroup>) = submitList(v)

    /** Update one visible match card without redrawing the whole list. */
    fun updateOdds(homeTeam: String, awayTeam: String, odds: SofaScoreService.Odds) {
        fun same(match: MatchGroup): Boolean =
            MatchMerger.isSameTeam(match.homeTeam, homeTeam) &&
                MatchMerger.isSameTeam(match.awayTeam, awayTeam)

        val fullIndex = fullList.indexOfFirst(::same)
        if (fullIndex >= 0) {
            fullList = fullList.toMutableList().apply {
                val old = this[fullIndex]
                this[fullIndex] = old.copy(odds = odds)
            }
        }

        val displayedIndex = displayedList.indexOfFirst(::same)
        if (displayedIndex >= 0) {
            displayedList = displayedList.toMutableList().apply {
                val old = this[displayedIndex]
                this[displayedIndex] = old.copy(odds = odds)
            }
            notifyItemChanged(displayedIndex)
        }
    }

    fun filter(query: String) {
        currentQuery = query
        refreshDisplayed()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val ctx = parent.context

        // Kart: yükseklik kesinlikle WRAP_CONTENT.
        val card = LinearLayout(ctx).apply {

            orientation = LinearLayout.VERTICAL

            layoutParams =
                RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    val horizontal = dp(ctx, 8)
                    val vertical = dp(ctx, 6)
                    setMargins(
                        horizontal,
                        vertical,
                        horizontal,
                        vertical
                    )
                }

            val padding = dp(ctx, 10)
            setPadding(
                padding,
                padding,
                padding,
                padding
            )

            background =
                GradientDrawable().apply {
                    setColor(0xFFFFFFFF.toInt())
                    cornerRadius = dp(ctx, 14).toFloat()
                    setStroke(
                        dp(ctx, 1),
                        0xFFE7EAF0.toInt()
                    )
                }

            elevation = dp(ctx, 3).toFloat()

            clipChildren = false
            clipToPadding = false
        }

        return VH(card)
    }

    override fun getItemCount(): Int =
        displayedList.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val ctx = holder.card.context
        val match = displayedList[position]

        // RecyclerView recycling temizliği.
        holder.card.removeAllViews()

        // ------------------------------------------------
        // TAKIMLAR
        // ------------------------------------------------

        val teams =
            LinearLayout(ctx).apply {

                orientation =
                    LinearLayout.HORIZONTAL

                gravity =
                    Gravity.CENTER_VERTICAL

                layoutParams =
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
            }

        val home =
            teamText(ctx, match.homeTeam).apply {
                setOnClickListener { onTeamClick(match.homeTeam, match.homeTeamId) }
                isClickable = true
            }

        val vs =
            TextView(ctx).apply {

                text = "VS"
                textSize = 12f

                setTypeface(
                    typeface,
                    Typeface.BOLD
                )

                gravity = Gravity.CENTER

                setTextColor(
                    0xFF667085.toInt()
                )

                background =
                    GradientDrawable().apply {
                        setColor(
                            0xFFF2F4F7.toInt()
                        )
                        shape =
                            GradientDrawable.OVAL
                    }

                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(ctx, 44),
                        dp(ctx, 44)
                    ).apply {
                        leftMargin = dp(ctx, 4)
                        rightMargin = dp(ctx, 4)
                    }
            }

        val away =
            teamText(ctx, match.awayTeam).apply {
                setOnClickListener { onTeamClick(match.awayTeam, match.awayTeamId) }
                isClickable = true
            }

        teams.addView(
            home,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        teams.addView(vs)

        teams.addView(
            away,
            LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        )

        holder.card.addView(teams)

        // ------------------------------------------------
        // CIO SCORE — tek puanda tüm mevcut verinin özeti
        // ------------------------------------------------
        val cio = CioScoreEngine.calculate(match.predictions, match.odds)
        val scoreRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 7) }
        }
        val scoreLabel = TextView(ctx).apply {
            text = "CioScore"
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF475467.toInt())
        }
        val scoreValue = TextView(ctx).apply {
            text = "${cio.score}/100" + if (cio.score >= 80) " 🔥" else ""
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val confidence = TextView(ctx).apply {
            text = "Güven: ${cio.confidence}"
            textSize = 10f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF344054.toInt())
            gravity = Gravity.CENTER
        }
        scoreRow.addView(scoreLabel)
        scoreRow.addView(scoreValue)
        scoreRow.addView(confidence)
        holder.card.addView(scoreRow)

        // ------------------------------------------------
        // SADE ANALİZ SONUCU
        // 5 kaynağın skorlarından 1/X/2 çoğunluğu.
        // ------------------------------------------------
        val insight = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 6) }
        }

        val outcomeCounts = match.predictions
            .mapNotNull { predictionOutcome(it.predictedScore) }
            .groupingBy { it }
            .eachCount()
        val analysisOutcome = outcomeCounts
            .maxByOrNull { it.value }
            ?.key

        insight.addView(TextView(ctx).apply {
            text = when (analysisOutcome) {
                "1" -> "EV KAZANIR"
                "X" -> "MAÇ BERABERE BİTER"
                "2" -> "DEPLASMAN KAZANIR"
                else -> "NET SONUÇ YOK"
            }
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(ctx, 10), dp(ctx, 5), dp(ctx, 10), dp(ctx, 5))
            background = GradientDrawable().apply {
                cornerRadius = dp(ctx, 16).toFloat()
                setColor(when (analysisOutcome) {
                    "1" -> 0xFF16A34A.toInt()
                    "X" -> 0xFF64748B.toInt()
                    "2" -> 0xFFDC2626.toInt()
                    else -> 0xFF94A3B8.toInt()
                })
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        })

        holder.card.addView(insight)

        // ------------------------------------------------
        // MS 1 / MS X / MS 2 oranları
        // ------------------------------------------------
        match.odds?.let { odds ->
            val oddsRow = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(ctx, 6) }
            }
            fun oddsCell(label: String, value: String): LinearLayout {
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                box.addView(TextView(ctx).apply {
                    text = label
                    textSize = 9f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF667085.toInt())
                    gravity = Gravity.CENTER
                })
                box.addView(TextView(ctx).apply {
                    text = value
                    textSize = 13f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                    gravity = Gravity.CENTER
                })
                return box
            }
            oddsRow.addView(oddsCell("MS 1", odds.home))
            oddsRow.addView(oddsCell("MS X", odds.draw))
            oddsRow.addView(oddsCell("MS 2", odds.away))
            holder.card.addView(oddsRow)
        }

        // ------------------------------------------------
        // AYIRICI
        // ------------------------------------------------

        val divider =
            View(ctx).apply {
                setBackgroundColor(
                    0xFFE7EAF0.toInt()
                )
            }

        holder.card.addView(
            divider,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(ctx, 1)
            ).apply {
                topMargin = dp(ctx, 8)
                bottomMargin = dp(ctx, 4)
            }
        )

        // ------------------------------------------------
        // KAYNAK + SKORLAR
        // ------------------------------------------------

        match.predictions.forEach { prediction ->

            val row =
                LinearLayout(ctx).apply {

                    orientation =
                        LinearLayout.HORIZONTAL

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = dp(ctx, 2)
                            bottomMargin = dp(ctx, 2)
                        }

                    clipChildren = false
                    clipToPadding = false
                }

            val source =
                TextView(ctx).apply {

                    text =
                        displaySourceName(
                            prediction.source
                        )

                    textSize = 11f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    ellipsize =
                        TextUtils.TruncateAt.END

                    gravity =
                        Gravity.CENTER_VERTICAL

                    layoutParams =
                        LinearLayout.LayoutParams(
                            0,
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            1f
                        )
                }

            val arrow =
                TextView(ctx).apply {

                    text = "→"
                    textSize = 14f

                    setTextColor(
                        0xFF667085.toInt()
                    )

                    gravity =
                        Gravity.CENTER

                    layoutParams =
                        LinearLayout.LayoutParams(
                            dp(ctx, 28),
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            val score =
                TextView(ctx).apply {

                    text =
                        prediction.predictedScore

                    textSize = 13f

                    setTypeface(
                        typeface,
                        Typeface.BOLD
                    )

                    setTextColor(
                        0xFF101828.toInt()
                    )

                    maxLines = 1

                    gravity =
                        Gravity.END or
                            Gravity.CENTER_VERTICAL

                    // Sabit 60dp yok: skor kendi genişliğini alır.
                    layoutParams =
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                }

            row.addView(source)
            row.addView(arrow)
            row.addView(score)

            holder.card.addView(row)
        }

        // Kartın kendisi de dinamik yükseklikte kalır.
        holder.card.layoutParams =
            (holder.card.layoutParams
                ?: RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )).apply {
                    width =
                        ViewGroup.LayoutParams.MATCH_PARENT
                    height =
                        ViewGroup.LayoutParams.WRAP_CONTENT
                }
    }

    private fun teamText(
        ctx: Context,
        name: String
    ): TextView =
        TextView(ctx).apply {

            text = name
            textSize = 13f

            setTypeface(
                typeface,
                Typeface.BOLD
            )

            setTextColor(
                0xFF101828.toInt()
            )

            gravity =
                Gravity.CENTER

            maxLines = 1

            ellipsize =
                TextUtils.TruncateAt.END
        }

    private fun predictionOutcome(score: String): String? {
        val match = Regex("^(\\d+)\\s*[-:]\\s*(\\d+)$").find(score.trim()) ?: return null
        val home = match.groupValues[1].toIntOrNull() ?: return null
        val away = match.groupValues[2].toIntOrNull() ?: return null
        return when {
            home > away -> "1"
            home < away -> "2"
            else -> "X"
        }
    }

    private fun dp(
        context: Context,
        value: Int
    ): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics
        ).toInt()
}
