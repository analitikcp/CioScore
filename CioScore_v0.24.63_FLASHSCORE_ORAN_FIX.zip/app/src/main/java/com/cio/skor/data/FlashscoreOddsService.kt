package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Flashscore fallback for bookmaker 1X2 odds.
 *
 * Flashscore exposes a football live/scheduled feed containing the event id
 * (AA) and an odds GraphQL endpoint keyed by that event id. This avoids trying
 * to scrape the rendered HTML page.
 */
class FlashscoreOddsService {
    data class BookmakerOdds(
        val bookmaker: String,
        val ms1: String,
        val msX: String,
        val ms2: String
    )

    private val http = HttpClient()
    private val feedUrl = "https://www.flashscore.com/x/feed/f_1_-1_3_en_1"
    private val oddsUrl = "https://global.ds.lsapp.eu/odds/pq_graphql"

    suspend fun fetchBookmakerOdds(homeTeam: String, awayTeam: String): List<BookmakerOdds> =
        withContext(Dispatchers.IO) {
            val eventId = findEventId(homeTeam, awayTeam) ?: return@withContext emptyList()
            val regions = listOf(
                "GB" to "",
                "DE" to "",
                "TR" to "",
                "US" to ""
            )
            val rows = coroutineScope {
                regions.map { (geo, sub) ->
                    async(Dispatchers.IO) { fetchEventOdds(eventId, geo, sub) }
                }.awaitAll().flatten()
            }

            val preferred = listOf(
                "bet365", "bwin", "betfair", "william hill", "williamhill", "unibet",
                "pinnacle", "1xbet", "betway"
            )
            rows.distinctBy { it.bookmaker.lowercase().trim() }
                .sortedWith(compareBy<BookmakerOdds> {
                    val idx = preferred.indexOfFirst { key -> it.bookmaker.contains(key, true) }
                    if (idx >= 0) idx else 100
                })
                .take(8)
        }

    private fun findEventId(homeTeam: String, awayTeam: String): String? {
        val (code, body) = http.get(feedUrl, "https://www.flashscore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return null

        val homeNorm = normalize(homeTeam)
        val awayNorm = normalize(awayTeam)
        for (section in body.split('~')) {
            val fields = parseFields(section)
            val id = fields["AA"] ?: continue
            val home = fields["AE"].orEmpty()
            val away = fields["AF"].orEmpty()
            if (isSameTeam(home, homeNorm) && isSameTeam(away, awayNorm)) return id
        }
        return null
    }

    private fun fetchEventOdds(eventId: String, geo: String, sub: String): List<BookmakerOdds> {
        val q = buildString {
            append(oddsUrl)
            append("?_hash=oce")
            append("&eventId=").append(URLEncoder.encode(eventId, StandardCharsets.UTF_8.name()))
            append("&projectId=2")
            append("&geoIpCode=").append(geo)
            if (sub.isNotBlank()) append("&geoIpSubdivisionCode=").append(sub)
        }
        val (code, body) = http.get(q, "https://www.flashscore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return runCatching {
            val root = JSONObject(body)
            val eventOdds = root.optJSONObject("data")?.optJSONObject("findOddsByEventId")
                ?: return@runCatching emptyList()

            val bookmakerNames = mutableMapOf<String, String>()
            val settings = eventOdds.optJSONObject("settings")
            val bookmakers = settings?.optJSONArray("bookmakers")
            if (bookmakers != null) {
                for (i in 0 until bookmakers.length()) {
                    val entry = bookmakers.optJSONObject(i) ?: continue
                    val bookmaker = entry.optJSONObject("bookmaker") ?: continue
                    val id = bookmaker.opt("id")?.toString().orEmpty()
                    val name = bookmaker.optString("name").trim()
                    if (id.isNotBlank() && name.isNotBlank()) bookmakerNames[id] = name
                }
            }

            val out = mutableListOf<BookmakerOdds>()
            val odds = eventOdds.optJSONArray("odds") ?: return@runCatching out
            for (i in 0 until odds.length()) {
                val item = odds.optJSONObject(i) ?: continue
                if (!item.optString("bettingType").equals("HOME_AWAY", true)) continue
                if (!item.optString("bettingScope").equals("FULL_TIME", true)) continue
                val values = item.optJSONArray("odds") ?: continue
                if (values.length() < 3) continue
                val one = decimal(values.optJSONObject(0)) ?: continue
                val draw = decimal(values.optJSONObject(1)) ?: continue
                val two = decimal(values.optJSONObject(2)) ?: continue
                val bookmakerId = item.opt("bookmakerId")?.toString().orEmpty()
                val name = bookmakerNames[bookmakerId].orEmpty()
                if (name.isBlank()) continue
                out += BookmakerOdds(name, one, draw, two)
            }
            out
        }.getOrDefault(emptyList())
    }

    private fun decimal(obj: JSONObject?): String? {
        if (obj == null) return null
        val value = obj.opt("value")?.toString()?.toDoubleOrNull() ?: return null
        if (value <= 1.0 || value > 100.0) return null
        return String.format(java.util.Locale.US, "%.2f", value)
    }

    private fun parseFields(section: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (part in section.split('¬')) {
            val pos = part.indexOf('÷')
            if (pos <= 0) continue
            out[part.substring(0, pos)] = part.substring(pos + 1)
        }
        return out
    }

    private fun normalize(value: String): String =
        MatchMerger.normalizeTeamName(value).replace(" ", "")

    private fun isSameTeam(actual: String, normalizedWanted: String): Boolean {
        if (MatchMerger.isSameTeam(actual, normalizedWanted)) return true
        val a = normalize(actual)
        if (a == normalizedWanted) return true
        if (a.isBlank() || normalizedWanted.isBlank()) return false
        return a.contains(normalizedWanted) || normalizedWanted.contains(a)
    }
}
