package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer

/**
 * Global fixture identity for CioScore.
 *
 * IMPORTANT:
 * - The 5 prediction sites and official iddaa.com are different DATA SOURCES,
 *   but a fixture is still ONE UI card.
 * - Team spelling is presentation data; canonical home+away is identity.
 * - Never remove meaningful team words globally (for example "Linz" or "IFK").
 *   Only safe leading/trailing club-type tokens are removed.
 */
object MatchMerger {

    private val removableEdgeTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio"
    )

    /** Known cross-site / language variants. Keys and values are canonical. */
    private val aliases = mapOf(
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek athens" to "aek athens",
        "lask linz" to "lask",
        "lask" to "lask",
        "ifk mariehamn" to "ifk mariehamn",
        "mariehamn" to "ifk mariehamn",
        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "man city" to "manchester city",
        "spurs" to "tottenham hotspur",
        "tottenham" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers",
        "newcastle" to "newcastle united",
        "newcastle utd" to "newcastle united",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "cardiff" to "cardiff city",
        "stoke" to "stoke city",
        "norwich" to "norwich city",
        "coventry" to "coventry city",
        "leicester" to "leicester city",
        "swansea" to "swansea city",
        "birmingham" to "birmingham city",
        "hull" to "hull city",
        "lincoln" to "lincoln city"
    )

    /**
     * Converts source-specific team spellings into a stable canonical form.
     * Examples:
     *   AEK Athens -> aek athens
     *   AEK Atina  -> aek athens
     *   LASK      -> lask
     *   LASK Linz -> lask
     *   FC Brugge -> brugge
     *
     * Note: "linz" and "ifk" are NOT globally deleted because they can be
     * meaningful parts of other clubs.
     */
    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace("athina", "athens")
            .replace("atina", "athens")
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = value.split(' ').filter { it.isNotBlank() }.toMutableList()
        while (tokens.isNotEmpty() && tokens.first() in removableEdgeTokens) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in removableEdgeTokens) tokens.removeAt(tokens.lastIndex)

        value = tokens.joinToString(" ")
        return aliases[value] ?: value
    }

    private fun compact(name: String): String = normalizeTeamName(name).replace(" ", "")

    /** Stable home/away fixture key. Home and away order is intentional. */
    fun key(homeTeam: String, awayTeam: String): String =
        "${normalizeTeamName(homeTeam)}||${normalizeTeamName(awayTeam)}"

    /** Conservative team equivalence used by all UI/data layers. */
    fun isSameTeam(name1: String, name2: String): Boolean {
        val a = compact(name1)
        val b = compact(name2)
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true

        // Do not let short names such as "A" or "Utd" absorb unrelated clubs.
        val shorter = if (a.length <= b.length) a else b
        val longer = if (a.length <= b.length) b else a
        if (shorter.length >= 8 && longer.contains(shorter)) return true

        // Conservative fuzzy fallback. Same first character avoids many false
        // positives while allowing minor spelling/transliteration differences.
        if (a.first() != b.first()) return false
        return similarity(a, b) >= 0.90
    }

    private fun similarity(a: String, b: String): Double {
        val max = maxOf(a.length, b.length)
        if (max == 0) return 1.0
        return 1.0 - levenshtein(a, b).toDouble() / max.toDouble()
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val replace = prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(replace, prev[j] + 1, cur[j - 1] + 1)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null
    )

    /**
     * Merge ALL five prediction sources first, then enrich the same groups with
     * official iddaa.com (source 6). The result is one UnifiedMatch per fixture.
     */
    fun mergeMatches(
        scrapedList: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch> = emptyList()
    ): List<UnifiedMatch> {
        val groups = mutableListOf<UnifiedMatch>()

        // Sources 1-5.
        for (incoming in scrapedList) {
            val group = findGroup(groups, incoming.homeTeam, incoming.awayTeam)
            if (group == null) {
                groups += UnifiedMatch(
                    mainHomeTeam = normalizeDisplayName(incoming.homeTeam),
                    mainAwayTeam = normalizeDisplayName(incoming.awayTeam),
                    predictions = mutableListOf(incoming.source to incoming.predictedScore)
                )
            } else {
                // One prediction per source per fixture. This also prevents a
                // repeated parser result from creating another visible row/card.
                val alreadyFromSource = group.predictions.any {
                    it.first.equals(incoming.source, ignoreCase = true)
                }
                if (!alreadyFromSource) {
                    group.predictions += incoming.source to incoming.predictedScore
                }
            }
        }

        // Source 6: official iddaa markets enrich the existing fixture. An
        // official-only fixture is retained for the dedicated HT/FT screen, but
        // MainActivity intentionally hides it when it has no prediction source.
        for (official in officialMatches) {
            val group = findGroup(groups, official.homeTeam, official.awayTeam)
            if (group == null) {
                groups += UnifiedMatch(
                    mainHomeTeam = normalizeDisplayName(official.homeTeam),
                    mainAwayTeam = normalizeDisplayName(official.awayTeam),
                    officialMatch = official
                )
            } else {
                group.officialMatch = mergeOfficial(group.officialMatch, official)
            }
        }

        return groups
    }

    private fun findGroup(
        groups: Collection<UnifiedMatch>,
        home: String,
        away: String
    ): UnifiedMatch? {
        // Pass 1: canonical identity. This is what resolves known variants such
        // as AEK Athens/Athina and LASK/LASK Linz with zero fuzzy guessing.
        val incomingKey = key(home, away)
        groups.firstOrNull { key(it.mainHomeTeam, it.mainAwayTeam) == incomingKey }
            ?.let { return it }

        // Pass 2: conservative fuzzy identity for unseen spelling variations.
        return groups.firstOrNull {
            isSameFixture(it.mainHomeTeam, it.mainAwayTeam, home, away)
        }
    }

    private fun isSameFixture(h1: String, a1: String, h2: String, a2: String): Boolean =
        isSameTeam(h1, h2) && isSameTeam(a1, a2)

    private fun mergeOfficial(
        current: IddaaMarketService.OpenedMarketMatch?,
        incoming: IddaaMarketService.OpenedMarketMatch
    ): IddaaMarketService.OpenedMarketMatch {
        if (current == null) return incoming

        val combined = linkedMapOf<String, String>().apply {
            putAll(current.htFtOdds)
            putAll(incoming.htFtOdds)
        }

        return current.copy(
            matchId = current.matchId.ifBlank { incoming.matchId },
            homeTeam = current.homeTeam.ifBlank { incoming.homeTeam },
            awayTeam = current.awayTeam.ifBlank { incoming.awayTeam },
            matchTimestamp = if (current.matchTimestamp > 0L) current.matchTimestamp else incoming.matchTimestamp,
            matchTime = if (current.matchTime != "--:--") current.matchTime else incoming.matchTime,
            matchDate = current.matchDate.ifBlank { incoming.matchDate },
            ms1 = current.ms1 ?: incoming.ms1,
            msX = current.msX ?: incoming.msX,
            ms2 = current.ms2 ?: incoming.ms2,
            hasHtFt = current.hasHtFt || incoming.hasHtFt || combined.isNotEmpty(),
            htFtOdds = combined
        )
    }

    private fun normalizeDisplayName(raw: String): String {
        return when (normalizeTeamName(raw)) {
            "aek athens" -> "AEK Athens"
            "lask" -> "LASK"
            "ifk mariehamn" -> "IFK Mariehamn"
            "cardiff city" -> "Cardiff City"
            "stoke city" -> "Stoke City"
            "norwich city" -> "Norwich City"
            "coventry city" -> "Coventry City"
            "leicester city" -> "Leicester City"
            "swansea city" -> "Swansea City"
            "birmingham city" -> "Birmingham City"
            "hull city" -> "Hull City"
            "lincoln city" -> "Lincoln City"
            "manchester united" -> "Manchester United"
            "manchester city" -> "Manchester City"
            "tottenham hotspur" -> "Tottenham Hotspur"
            "wolverhampton wanderers" -> "Wolverhampton Wanderers"
            "west bromwich albion" -> "West Bromwich Albion"
            "nottingham forest" -> "Nottingham Forest"
            "brighton and hove albion" -> "Brighton & Hove Albion"
            "queens park rangers" -> "Queens Park Rangers"
            "newcastle united" -> "Newcastle United"
            "paris saint germain" -> "Paris Saint-Germain"
            else -> raw.trim()
        }
    }
}
