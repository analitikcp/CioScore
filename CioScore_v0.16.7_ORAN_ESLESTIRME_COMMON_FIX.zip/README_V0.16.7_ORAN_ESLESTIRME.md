CioScore v0.16.7 — ORAN + TAKIM EŞLEŞTİRME ORTAK ÇÖZÜM

Yapılanlar:
1. Takım isimleri için canonical eşleştirme eklendi. Cardiff/Cardiff City, Stoke/Stoke City, Swansea/Swansea City vb. kaynak farklılıkları tek maça birleştirilir.
2. City/United gibi kelimeler global olarak silinmedi; Manchester City / Manchester United gibi yanlış birleşmeler önlenir.
3. Mackolik oran eşleştirmesi canonical key + güvenli fuzzy matching üzerinden güçlendirildi.
4. Mackolik parser için alternatif hücre tabanlı oran okuma fallback'i eklendi; kodun farklı HTML konumlarında da 1X2 aranır.
5. Mackolik birincil kaynaktır. Mackolik'te eşleşmeyen maçlarda SofaScore 1X2 endpoint'i fallback olarak denenir. Geçerli Mackolik oranı asla SofaScore ile ezilmez.
6. Mevcut takım adına tıklama / Son 5 Maç ekranı korunmuştur.
7. Maçkolik • MS 1X2 metin temizliği korunmuştur; kartta yalnızca MS 1X2 gösterilir.

Önemli: Bir maç için hem Mackolik hem SofaScore gerçek 1X2 verisi döndürmüyorsa uygulama sahte oran üretmez; oran satırı gösterilmez.
