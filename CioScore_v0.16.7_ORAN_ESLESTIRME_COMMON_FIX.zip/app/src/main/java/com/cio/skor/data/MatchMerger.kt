package com.cio.skor.data

import org.apache.commons.text.similarity.LevenshteinDistance
import java.text.Normalizer as JavaNormalizer

/**
 * Central place for team-name normalization and cross-source fixture merging.
 * Source sites often abbreviate the same club differently (e.g. Cardiff / Cardiff City).
 */
object MatchMerger {
    private val levenshtein = LevenshteinDistance()

    private val removableSuffixes = setOf("fc", "fk", "sk", "cd", "nk", "afc", "club")

    // Safe, explicit aliases for common source-name differences. We deliberately
    // do NOT globally remove "city" or "united": that could merge Manchester City
    // with Manchester United. These aliases are only applied to known clubs.
    private val aliases = mapOf(
        "cardiff" to "cardiff",
        "cardiff city" to "cardiff",
        "stoke" to "stoke",
        "stoke city" to "stoke",
        "swansea" to "swansea",
        "swansea city" to "swansea",
        "bristol city" to "bristol city",
        "bristol" to "bristol city",
        "norwich" to "norwich city",
        "norwich city" to "norwich city",
        "derby" to "derby county",
        "derby county" to "derby county",
        "hull" to "hull city",
        "hull city" to "hull city",
        "coventry" to "coventry city",
        "coventry city" to "coventry city",
        "leicester" to "leicester city",
        "leicester city" to "leicester city",
        "birmingham" to "birmingham city",
        "birmingham city" to "birmingham city",
        "sheffield united" to "sheffield united",
        "qpr" to "queens park rangers",
        "queens park rangers" to "queens park rangers",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton wanderers" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "west bromwich" to "west bromwich albion",
        "west bromwich albion" to "west bromwich albion"
    )

    /** Basic normalized text, preserving meaningful words such as City/United. */
    fun normalizeTeamName(name: String): String {
        if (name.isBlank()) return ""

        var value = name.lowercase()
            .replace('ç', 'c')
            .replace('ğ', 'g')
            .replace('ı', 'i')
            .replace('ö', 'o')
            .replace('ş', 's')
            .replace('ü', 'u')

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        val tokens = value.split(' ')
            .filter { it.isNotBlank() && it !in removableSuffixes }

        return tokens.joinToString(" ").trim()
    }

    /** Canonical identity key used for both fixture merging and odds matching. */
    fun canonicalTeamName(name: String): String {
        val normalized = normalizeTeamName(name)
        if (normalized.isBlank()) return ""
        return aliases[normalized] ?: normalized
    }

    private fun compactCanonical(value: String): String =
        canonicalTeamName(value).replace(" ", "")

    fun key(homeTeam: String, awayTeam: String): String =
        "${canonicalTeamName(homeTeam)}||${canonicalTeamName(awayTeam)}"

    fun isSameTeam(name1: String, name2: String): Boolean {
        val norm1 = compactCanonical(name1)
        val norm2 = compactCanonical(name2)

        if (norm1.isBlank() || norm2.isBlank()) return false
        if (norm1 == norm2) return true

        // Conservative containment for genuinely descriptive names.
        val tokens1 = canonicalTeamName(name1).split(' ').filter { it.isNotBlank() }
        val tokens2 = canonicalTeamName(name2).split(' ').filter { it.isNotBlank() }
        val shorter = if (tokens1.size <= tokens2.size) tokens1 else tokens2
        val longer = if (tokens1.size <= tokens2.size) tokens2 else tokens1
        val safeContainment = shorter.isNotEmpty() &&
            (shorter.size >= 2 || shorter.joinToString("").length >= 8) &&
            shorter.all { it in longer }
        if (safeContainment) return true

        val maxLength = maxOf(norm1.length, norm2.length)
        if (maxLength == 0) return true
        val distance = levenshtein.apply(norm1, norm2)
        val similarity = 1.0 - distance.toDouble() / maxLength.toDouble()
        return similarity >= 0.82
    }

    data class UnifiedMatch(
        val mainHomeTeam: String,
        val mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf()
    )

    /** Merge all source predictions into one fixture group. */
    fun mergeMatches(scrapedList: List<ScoreModel>): List<UnifiedMatch> {
        val unifiedMatches = mutableListOf<UnifiedMatch>()

        for (scraped in scrapedList) {
            val existingMatch = unifiedMatches.find { unified ->
                isSameTeam(unified.mainHomeTeam, scraped.homeTeam) &&
                    isSameTeam(unified.mainAwayTeam, scraped.awayTeam)
            }

            if (existingMatch != null) {
                val sourceExists = existingMatch.predictions.any {
                    it.first.trim().equals(scraped.source.trim(), ignoreCase = true)
                }
                if (!sourceExists) {
                    existingMatch.predictions.add(scraped.source to scraped.predictedScore)
                }
            } else {
                unifiedMatches.add(
                    UnifiedMatch(
                        mainHomeTeam = scraped.homeTeam,
                        mainAwayTeam = scraped.awayTeam,
                        predictions = mutableListOf(scraped.source to scraped.predictedScore)
                    )
                )
            }
        }
        return unifiedMatches
    }
}
