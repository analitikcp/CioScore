package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.util.concurrent.TimeUnit

/**
 * Mackolik Iddaa Programi: tek HTTP istegi, gercek TR satirlari uzerinden parse.
 *
 * Gercek satir ornegi:
 * Cagliari - Lecce | 12221 | 1.86 | 2.84 | 3.50 | ...
 *
 * Parser, body icindeki rastgele decimal sayilari degil;
 * 1) takim hucresini, 2) 5 haneli MS kodunu, 3) kodun hemen sonraki 3 orani okur.
 */
class MackolikOddsService {
    companion object {
        private const val PROGRAM_URL = "https://arsiv2.mackolik.com/Iddaa-Programi"
        private val CODE = Regex("(?<![0-9])\\d{4,7}(?![0-9])")
        private val ODDS = Regex("(?<![0-9])(?:[0-9]{1,2})[.,][0-9]{2}(?![0-9])")
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    data class MackolikMatch(
        val homeTeam: String,
        val awayTeam: String,
        val odds: SofaScoreService.Odds
    )

    data class Result(
        val httpCode: Int,
        val htmlLength: Int,
        val rowCount: Int,
        val parsedRows: Int,
        val matches: List<MackolikMatch>,
        val sample: String = "-",
        val error: String? = null
    )

    suspend fun fetchToday(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(16_000L) {
            try {
                val request = Request.Builder()
                    .url(PROGRAM_URL)
                    .header(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                            "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                    )
                    .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                    .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                    .header("Referer", "https://arsiv2.mackolik.com/")
                    .build()

                client.newCall(request).execute().use { response ->
                    val html = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withTimeoutOrNull Result(
                            response.code, html.length, 0, 0, emptyList(), error = "HTTP ${response.code}"
                        )
                    }
                    if (html.isBlank()) {
                        return@withTimeoutOrNull Result(
                            response.code, 0, 0, 0, emptyList(), error = "HTML BOS"
                        )
                    }

                    val doc = Jsoup.parse(html, PROGRAM_URL)
                    val rows = doc.select("tr")
                    val parsed = LinkedHashMap<String, MackolikMatch>()
                    var parsedRows = 0
                    var sample = "-"

                    for (row in rows) {
                        val item = parseMatchRow(row) ?: continue
                        parsedRows++
                        parsed[MatchMerger.key(item.homeTeam, item.awayTeam)] = item
                        if (sample == "-") {
                            sample = "${item.homeTeam} - ${item.awayTeam}: " +
                                "${item.odds.home} / ${item.odds.draw} / ${item.odds.away}"
                        }
                    }

                    Result(
                        httpCode = response.code,
                        htmlLength = html.length,
                        rowCount = rows.size,
                        parsedRows = parsedRows,
                        matches = parsed.values.toList(),
                        sample = sample
                    )
                }
            } catch (e: Exception) {
                Result(
                    httpCode = -1,
                    htmlLength = 0,
                    rowCount = 0,
                    parsedRows = 0,
                    matches = emptyList(),
                    error = "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}"
                )
            }
        } ?: Result(
            httpCode = -1,
            htmlLength = 0,
            rowCount = 0,
            parsedRows = 0,
            matches = emptyList(),
            error = "Mackolik zaman asimi"
        )
    }

    private fun parseMatchRow(row: Element): MackolikMatch? {
        val cells = row.select("td, th")
        if (cells.isEmpty()) return null

        // First locate the cell that actually contains the two team names.
        var pairIndex = -1
        var pair: Pair<String, String>? = null
        for (i in cells.indices) {
            val text = cells[i].text().replace(Regex("\\s+"), " ").trim()
            val candidate = splitTeamPair(text)
            if (candidate != null && validTeam(candidate.first) && validTeam(candidate.second)) {
                pairIndex = i
                pair = candidate
                break
            }
        }
        pair ?: return null

        val rowText = row.text().replace(Regex("\\s+"), " ").trim()

        // Preferred path: the official 1X2 values immediately follow the
        // program/event code. Some rows omit that code, so a cell-based
        // fallback is also provided below.
        val odds = mutableListOf<String>()
        val code = CODE.find(rowText)
        if (code != null) {
            val afterCode = rowText.substring(code.range.last + 1)
            odds += ODDS.findAll(afterCode)
                .map { it.value.replace(',', '.') }
                .take(3)
        }

        // Fallback for alternate Mackolik row layouts where the code is not
        // rendered as text or is placed in a separate/non-standard element.
        if (odds.size < 3) {
            val tail = cells.drop(pairIndex + 1)
                .joinToString(" ") { it.text().replace(Regex("\\s+"), " ").trim() }
            odds.clear()
            odds += ODDS.findAll(tail)
                .map { it.value.replace(',', '.') }
                .take(3)
        }

        if (odds.size != 3) return null

        return MackolikMatch(
            homeTeam = pair.first,
            awayTeam = pair.second,
            odds = SofaScoreService.Odds(odds[0], odds[1], odds[2])
        )
    }

    private fun splitTeamPair(value: String): Pair<String, String>? {
        var text = value.replace(Regex("\\s+"), " ").trim()
        if (text.isBlank() || text.contains(":")) return null

        // Tek bir " - " takim ayiraci bekliyoruz.
        val matches = Regex("\\s+-\\s+").findAll(text).toList()
        if (matches.size != 1) return null

        val dash = matches[0]
        val home = cleanTeam(text.substring(0, dash.range.first))
        val away = cleanTeam(text.substring(dash.range.last + 1))

        if (home.length !in 2..80 || away.length !in 2..80) return null
        if (home.count { it.isLetter() } < 2 || away.count { it.isLetter() } < 2) return null
        return home to away
    }

    private fun cleanTeam(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim(' ', '|', '•')
        .replace(Regex("^\\d{1,2}:\\d{2}\\s+"), "")
        .trim()

    private fun validTeam(value: String): Boolean {
        if (value.length !in 2..80) return false
        if (value.count { it.isLetter() } < 2) return false
        val bad = setOf("Iddaa", "Programi", "MS", "Kod", "Lig", "Tumu", "Futbol", "Basketbol")
        return bad.none { value.equals(it, ignoreCase = true) }
    }

    fun findForTeamPair(
        matches: List<MackolikMatch>,
        homeTeam: String,
        awayTeam: String
    ): MackolikMatch? = matches.firstOrNull {
        MatchMerger.isSameTeam(it.homeTeam, homeTeam) &&
            MatchMerger.isSameTeam(it.awayTeam, awayTeam)
    }
}
