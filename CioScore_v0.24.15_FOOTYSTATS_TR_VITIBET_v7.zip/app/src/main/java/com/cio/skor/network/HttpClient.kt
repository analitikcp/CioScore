package com.cio.skor.network

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Cookie
import okhttp3.HttpUrl
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLHandshakeException
import java.util.concurrent.TimeUnit

class HttpClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun getFast(url: String, referer: String? = null): Pair<Int, String?> {
        val requestBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/131.0 Mobile Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")

        if (!referer.isNullOrBlank()) requestBuilder.header("Referer", referer)

        val fastClient = client.newBuilder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(9, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build()

        return try {
            fastClient.newCall(requestBuilder.build()).execute().use { response ->
                response.code to response.body?.string()
            }
        } catch (e: SocketTimeoutException) {
            -100 to "Socket Timeout: ${e.localizedMessage ?: "timeout"}"
        } catch (e: UnknownHostException) {
            -101 to "DNS/Host Error: ${e.localizedMessage ?: "unknown host"}"
        } catch (e: SSLHandshakeException) {
            -102 to "SSL Error: ${e.localizedMessage ?: "handshake failed"}"
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown Network Error"}"
        }
    }


    /**
     * FootyStats uses a stricter web request profile than the other prediction sources.
     * Warm the Turkish site first so the prediction request can reuse the session cookies.
     * This is intentionally source-specific; the generic source HTTP path stays unchanged.
     */
    fun getFootyStats(): Pair<Int, String?> {
        val warmUrl = "https://footystats.org/tr/"
        val trUrl = "https://footystats.org/tr/predictions/correct-score"
        val enUrl = "https://footystats.org/predictions/correct-score"
        val cookies = LinkedHashMap<String, Cookie>()

        val browserClient = client.newBuilder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(9, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build()

        fun rememberCookies(url: HttpUrl, response: okhttp3.Response) {
            Cookie.parseAll(url, response.headers).forEach { cookie ->
                cookies["${cookie.name}|${cookie.domain}|${cookie.path}"] = cookie
            }
        }

        fun request(url: String, referer: String): Pair<Int, String?> {
            val builder = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7")
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")
                .header("Upgrade-Insecure-Requests", "1")
                .header("Sec-Fetch-Dest", "document")
                .header("Sec-Fetch-Mode", "navigate")
                .header("Sec-Fetch-Site", "same-origin")
                .header("Sec-Fetch-User", "?1")
                .header("Referer", referer)

            if (cookies.isNotEmpty()) {
                val cookieHeader = cookies.values.joinToString("; ") { "${it.name}=${it.value}" }
                builder.header("Cookie", cookieHeader)
            }

            browserClient.newCall(builder.build()).execute().use { response ->
                rememberCookies(response.request.url, response)
                return response.code to response.body?.string()
            }
        }

        return try {
            // First request establishes the same-origin session/cookies used by the page.
            runCatching { request(warmUrl, "https://footystats.org/tr/") }

            val tr = request(trUrl, warmUrl)
            if (tr.first in 200..299 && !tr.second.isNullOrBlank()) {
                tr
            } else {
                // Keep a deterministic English fallback for cases where the Turkish route
                // is redirected or temporarily unavailable. Parser supports both headings.
                request(enUrl, "https://footystats.org/")
            }
        } catch (e: SocketTimeoutException) {
            -100 to "Socket Timeout: ${e.localizedMessage ?: "timeout"}"
        } catch (e: UnknownHostException) {
            -101 to "DNS/Host Error: ${e.localizedMessage ?: "unknown host"}"
        } catch (e: SSLHandshakeException) {
            -102 to "SSL Error: ${e.localizedMessage ?: "handshake failed"}"
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown Network Error"}"
        }
    }

    /** Vitibet exposes a simple legacy football table; use browser-like headers and a short fallback. */
    fun getVitibet(url: String): Pair<Int, String?> {
        val clientVitibet = client.newBuilder()
            .connectTimeout(7, TimeUnit.SECONDS)
            .readTimeout(9, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build()

        fun request(target: String): Pair<Int, String?> {
            val request = Request.Builder()
                .url(target)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")
                .header("Upgrade-Insecure-Requests", "1")
                .header("Referer", "https://www.vitibet.com/")
                .build()
            clientVitibet.newCall(request).execute().use { response ->
                return response.code to response.body?.string()
            }
        }

        return try {
            val primary = request(url)
            if (primary.first in 200..299 && !primary.second.isNullOrBlank()) primary
            else request("https://www.vitibet.com/index.php?clanek=quicktips&lang=en&sekce=fotbal")
        } catch (e: SocketTimeoutException) {
            -100 to "Socket Timeout: ${e.localizedMessage ?: "timeout"}"
        } catch (e: UnknownHostException) {
            -101 to "DNS/Host Error: ${e.localizedMessage ?: "unknown host"}"
        } catch (e: SSLHandshakeException) {
            -102 to "SSL Error: ${e.localizedMessage ?: "handshake failed"}"
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.localizedMessage ?: "Unknown Network Error"}"
        }
    }

    fun get(url: String, referer: String? = null): Pair<Int, String?> {
        var lastCode = -1
        var lastBody: String? = null

        repeat(2) { attempt ->
            val requestBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9,tr;q=0.8")
                .header("Cache-Control", "no-cache")
                .header("Pragma", "no-cache")

            if (!referer.isNullOrBlank()) requestBuilder.header("Referer", referer)

            try {
                client.newCall(requestBuilder.build()).execute().use { response ->
                    lastCode = response.code
                    lastBody = response.body?.string()
                    if (response.isSuccessful || response.code in 400..499 && response.code != 429) {
                        return response.code to lastBody
                    }
                }
            } catch (_: Exception) {
                lastCode = -1
                lastBody = null
            }

            if (attempt == 0 && (lastCode == 429 || lastCode >= 500 || lastCode == -1)) {
                Thread.sleep(700)
            }
        }

        return lastCode to lastBody
    }
}
