package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Vitibet/Vitisport daily football correct-score table parser.
 * The legacy table view exposes fixture + exact score in simple rows;
 * the parser intentionally ignores 1X2 percentages, index and tip columns.
 */
class VitibetParser : BaseParser("Vitibet") {
    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        for (row in doc.select("tr")) {
            val model = parseRow(row) ?: continue
            out[model.matchKey] = model
            if (out.size >= 200) break
        }

        // Fallback for the newer card/list markup where fixture links are used.
        if (out.isEmpty()) {
            for (container in doc.select("article, li, .match, .fixture, .game")) {
                val model = parseContainer(container) ?: continue
                out[model.matchKey] = model
                if (out.size >= 200) break
            }
        }

        return out.values.toList()
    }

    private fun parseRow(row: Element): ScoreModel? {
        val text = clean(row.text())
        val scoreMatch = Regex("(?<!\\d)(\\d{1,2})\\s*[:\\-]\\s*(\\d{1,2})(?!\\d)").find(text)
            ?: return null

        val score = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"
        val cells = row.select("th, td")
        val links = row.select("a[href]")
            .map { clean(it.text()) }
            .filter { it.length >= 2 }
            .distinct()

        val fixture = when {
            links.size >= 2 -> links[0] to links[1]
            cells.size >= 2 -> findFixtureFromCells(cells, scoreMatch)
            else -> null
        } ?: return null

        return build(fixture.first, fixture.second, score)
    }

    private fun findFixtureFromCells(cells: List<Element>, scoreMatch: MatchResult): Pair<String, String>? {
        val texts = cells.map { clean(it.text()) }
        val scoreIndex = texts.indexOfFirst { cell ->
            Regex("(?<!\\d)${Regex.escape(scoreMatch.groupValues[1])}\\s*[:\\-]\\s*${Regex.escape(scoreMatch.groupValues[2])}(?!\\d)")
                .containsMatchIn(cell)
        }
        if (scoreIndex < 2) return null

        // In the legacy table the two fixture columns immediately precede the score column.
        val home = texts[scoreIndex - 2]
        val away = texts[scoreIndex - 1]
        if (looksLikeNoise(home) || looksLikeNoise(away)) return null
        return home to away
    }

    private fun parseContainer(element: Element): ScoreModel? {
        val text = clean(element.text())
        val score = Regex("(?<!\\d)(\\d{1,2})\\s*[:\\-]\\s*(\\d{1,2})(?!\\d)").find(text)
            ?.let { "${it.groupValues[1]}-${it.groupValues[2]}" } ?: return null

        val links = element.select("a[href]")
            .map { clean(it.text()) }
            .filter { it.length >= 2 }
            .distinct()
        if (links.size < 2) return null
        return build(links[0], links[1], score)
    }

    private fun build(homeRaw: String, awayRaw: String, score: String): ScoreModel? {
        val home = cleanTeam(homeRaw)
        val away = cleanTeam(awayRaw)
        if (!valid(home, away) || looksLikeNoise(home) || looksLikeNoise(away)) return null
        return ScoreModel(
            homeTeam = home,
            awayTeam = away,
            predictedScore = score,
            source = source
        )
    }

    private fun cleanTeam(value: String): String = clean(value)
        .replace(Regex("(?i)\\b(INDEX|Tip|LIVE|FT)\\b.*$"), "")
        .trim(' ', '-', ':', '|')

    private fun looksLikeNoise(value: String): Boolean =
        value.matches(Regex("(?i)^(score|tip|index|1|x|2|prediction|predictions|scheduled|finished|live)$")) ||
            value.matches(Regex("^[0-9. %+:-]+$"))
}
