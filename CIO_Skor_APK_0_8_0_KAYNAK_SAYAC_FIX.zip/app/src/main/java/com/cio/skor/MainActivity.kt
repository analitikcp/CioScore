package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.ScraperRepository
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.*

class MainActivity:Activity(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private val repo=ScraperRepository()
    private lateinit var status:TextView
    private lateinit var list:RecyclerView
    private lateinit var adapter:ScoreAdapter
    override fun onCreate(b:Bundle?){super.onCreate(b);WindowCompat.setDecorFitsSystemWindows(window,false);buildUi();ViewCompat.setOnApplyWindowInsetsListener(findViewById(100)){v,i->val top=i.getInsets(WindowInsetsCompat.Type.statusBars()).top;v.setPadding(0,top,0,0);i}}
    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;id=100;setBackgroundColor(Color.WHITE)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,10,20,8)}
        header.addView(TextView(this).apply{text="CIO SCORE";textSize=28f;setTextColor(Color.BLACK);setTypeface(typeface,1)})
        header.addView(TextView(this).apply{text="Skorun Merkezi • ${repo.sourceCount} kaynak";textSize=14f;setTextColor(Color.GRAY)})
        status=TextView(this).apply{text="Hazır";textSize=14f;setPadding(0,10,0,8)};header.addView(status)
        val button=Button(this).apply{text="BUGÜNÜ TARA";setOnClickListener{scan()}};header.addView(button)
        root.addView(header,LinearLayout.LayoutParams(-1,-2))
        list=RecyclerView(this).apply{layoutManager=LinearLayoutManager(this@MainActivity)};adapter=ScoreAdapter(emptyList());list.adapter=adapter;root.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }
    private fun scan(){status.text="⏳ 0/${repo.sourceCount} kaynak taranıyor...";adapter.update(emptyList());scope.launch{
        val results=withContext(Dispatchers.IO){repo.fetchAll{n,name->runOnUiThread{status.text="⏳ $n/${repo.sourceCount} • $name"}}}
        val scores=results
            .flatMap{it.scores}
            .filter { isDisplayable(it) }
            .distinctBy { "${it.matchKey}|${it.predictedScore}|${it.source}" }

        adapter.update(scores)

        // A source is green ONLY when at least one clean score is actually
        // passed to the adapter for display. HTTP 200 / parser execution alone
        // never counts as a successful source.
        val goodSources=scores.map { it.source }.distinct()
        val sourceText=if(goodSources.isEmpty()) "Kaynak yok" else goodSources.joinToString(" • ")
        status.text="✅ ${goodSources.size} kaynak • ${scores.size} temiz skor\\n🟢 $sourceText"
    }

    private fun isDisplayable(x:ScoreModel):Boolean{
        if(x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if(!Regex("""^[0-9]{1,2}-[0-9]{1,2}$""").matches(x.predictedScore.trim())) return false
        if(x.homeTeam.equals(x.awayTeam,true)) return false
        return true
    }
    }}
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
