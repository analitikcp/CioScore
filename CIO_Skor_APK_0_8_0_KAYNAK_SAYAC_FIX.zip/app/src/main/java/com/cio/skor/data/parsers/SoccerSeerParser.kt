package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/** SoccerSeer upcoming correct-score parser. Finished matches are rejected. */
class SoccerSeerParser : BaseParser("SoccerSeer") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        val candidates = doc.select(
            "tr, article, li, .match-card, .prediction-card, " +
            "[class*=match], [class*=fixture], [class*=prediction], [class*=game]"
        )

        for (el in candidates) {
            val raw = clean(el.text())
            if (raw.length !in 8..500) continue
            if (isFinished(raw)) continue

            val scoreMatch = Regex("(?i)(?:correct\\s*score|predicted\\s*score|prediction|pred|tip)[^0-9]{0,80}([0-5])\\s*[-:]\\s*([0-5])")
                .find(raw)
                ?: continue
            val predicted = "${scoreMatch.groupValues[1]}-${scoreMatch.groupValues[2]}"

            val pair = extractTeams(el, raw, scoreMatch.range.first)
                ?: continue

            val home = team(pair.first)
            val away = team(pair.second)
            if (!valid(home, away)) continue
            if (looksNumericOrStatus(home) || looksNumericOrStatus(away)) continue

            val model = ScoreModel(home, away, predicted, source)
            out[model.matchKey] = model
        }

        return out.values.take(100)
    }

    private fun extractTeams(el: Element, raw: String, scoreStart: Int): Pair<String, String>? {
        val homeSelectors = listOf(
            ".home", ".home-team", ".homeTeam", ".team-home", ".team1",
            "[class*=home-team]", "[class*=homeTeam]"
        )
        val awaySelectors = listOf(
            ".away", ".away-team", ".awayTeam", ".team-away", ".team2",
            "[class*=away-team]", "[class*=awayTeam]"
        )

        val home = homeSelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { it.length in 2..80 }
        val away = awaySelectors.asSequence()
            .map { el.select(it).text().trim() }
            .firstOrNull { it.length in 2..80 }
        if (home != null && away != null) return home to away

        // Fallback: the match text commonly uses "Home - Away" / "Home v Away".
        val beforeScore = raw.substring(0, scoreStart).trim()
            .replace(Regex("(?i)\\b(?:prediction|pred|tip|correct score|correct score predictions?|confidence|conf\\.)\\b.*$"), "")
            .trim()

        val separators = listOf(" v ", " vs ", " - ", " – ", " — ")
        for (sep in separators) {
            val parts = beforeScore.split(sep, limit = 2)
            if (parts.size == 2) {
                val h = parts[0].trim()
                val a = parts[1].trim()
                if (h.length in 2..80 && a.length in 2..80) return h to a
            }
        }
        return null
    }

    private fun isFinished(text: String): Boolean {
        val t = text.lowercase()
        val finished = listOf(
            " full time ", " full-time ", " finished ", " final ", " ft ",
            "result:", "result ", "completed", "match ended", "ended"
        )
        val padded = " $t "
        return finished.any { padded.contains(it) }
    }

    private fun looksNumericOrStatus(value: String): Boolean {
        val v = value.trim()
        if (v.matches(Regex("[0-9:%./+ -]+"))) return true
        return v.equals("FT", true) || v.equals("Final", true) || v.equals("Finished", true)
    }
}
