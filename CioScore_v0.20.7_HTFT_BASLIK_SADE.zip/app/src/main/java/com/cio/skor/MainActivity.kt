package com.cio.skor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.cio.skor.data.MatchMerger
import com.cio.skor.data.ScoreModel
import com.cio.skor.data.SourceResult
import com.cio.skor.data.ScraperRepository
import com.cio.skor.data.SofaScoreService
import com.cio.skor.ui.MatchGroup
import com.cio.skor.ui.ScoreAdapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo = ScraperRepository()
    private val sofaScore = SofaScoreService()
    private val iddaaMarkets = com.cio.skor.data.IddaaMarketService()

    private lateinit var adapter: ScoreAdapter
    private lateinit var searchInput: EditText
    private lateinit var scanButton: Button
    private lateinit var scanProgress: ProgressBar
    private var scanning = false
    private var scanGeneration = 0
    private var allGroups: List<MatchGroup> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        val root = findViewById<android.view.View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top, view.paddingRight, view.paddingBottom)
            insets
        }

        scanButton = findViewById(R.id.btnScan)
        scanProgress = findViewById(R.id.progressScan)

        val recycler = findViewById<RecyclerView>(R.id.recyclerScores)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = ScoreAdapter(
            emptyList(),
            onTeamClick = { team, teamId -> showLastFive(team, teamId) },
            onHtFtClick = { home, away ->
                startActivity(Intent(this, HtFtOpenedMatchesActivity::class.java).apply {
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_HOME_TEAM, home)
                    putExtra(HtFtOpenedMatchesActivity.EXTRA_AWAY_TEAM, away)
                })
            }
        )
        recycler.adapter = adapter

        searchInput = findViewById(R.id.etSearch)
        scanButton.setOnClickListener { scan() }
        findViewById<Button>(R.id.btnHtFtOpenedMatches).setOnClickListener {
            startActivity(Intent(this, HtFtOpenedMatchesActivity::class.java))
        }
        // REAL-TIME FILTER: kullanıcı yazdıkça liste anında filtrelenir.
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                adapter.filter(query)
                // Sonuç bilgisi üstteki istatistik kartında tutulur; kaynak isimleri burada gösterilmez.
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun scan() {
        if (scanning) return
        val runId = ++scanGeneration
        scanning = true
        setScanningUi(true)

        adapter.submitList(emptyList())

        scope.launch {
            try {
                val results = withContext(Dispatchers.IO) {
                    repo.fetchAll { _, _ -> }
                }

                val scores: List<ScoreModel> = results
                    .flatMap { result: SourceResult -> result.scores }
                    .filter(::isDisplayable)
                    .distinctBy {
                        "${MatchMerger.normalizeTeamName(it.homeTeam)}|" +
                        "${MatchMerger.normalizeTeamName(it.awayTeam)}|" +
                        "${it.predictedScore}|${it.source.trim().lowercase()}"
                    }

                // Önce bütün ham kayıtlar toplanır, sonra MatchMerger ile birleştirilir.
                val unified = MatchMerger.mergeMatches(scores)
                val baseGroups = unified.map { match ->
                    SofaScoreService.MatchGroupData(
                        homeTeam = match.mainHomeTeam,
                        awayTeam = match.mainAwayTeam,
                        predictions = match.predictions.map { (source, score) ->
                            ScoreModel(match.mainHomeTeam, match.mainAwayTeam, score, source)
                        }
                    )
                }

                // Takım ID'lerini tek seferde çöz; sonraki tıklamalarda arama yapılmaz.
                val groupsWithIds = sofaScore.enrichTeamIds(baseGroups)

                // Maç kartları önce CIO tahminleriyle hazırlanır; resmi İddaa oranları aşağıda bağlanır.
                allGroups = groupsWithIds.map { match ->
                    MatchGroup(
                        homeTeam = match.homeTeam,
                        awayTeam = match.awayTeam,
                        predictions = match.predictions,
                        iddaaMs1 = null,
                        iddaaMsX = null,
                        iddaaMs2 = null,
                        homeTeamId = match.homeTeamId,
                        awayTeamId = match.awayTeamId
                    )
                }
                adapter.submitList(allGroups)

                try {
                    val result = withContext(Dispatchers.IO) { iddaaMarkets.fetchToday() }
                    if (runId != scanGeneration) return@launch

                    val oddsMap = result.matches.associateBy {
                        MatchMerger.key(it.homeTeam, it.awayTeam)
                    }

                    // ORAN KAYNAĞI: yalnızca resmi İddaa veri akışı.
                    allGroups = allGroups.map { group ->
                        val exact = oddsMap[MatchMerger.key(group.homeTeam, group.awayTeam)]
                            ?: result.matches.firstOrNull {
                                MatchMerger.isSameTeam(it.homeTeam, group.homeTeam) &&
                                    MatchMerger.isSameTeam(it.awayTeam, group.awayTeam)
                            }
                        if (exact != null) {
                            group.copy(
                                // MS1/MSX/MS2: ONLY official Iddaa program odds.
                                // No external odds fallback is allowed.
                                iddaaMs1 = exact.ms1,
                                iddaaMsX = exact.msX,
                                iddaaMs2 = exact.ms2,
                                htFtOdds = if (exact.hasHtFt) exact.htFtOdds else linkedMapOf(),
                                matchTimestamp = exact.matchTimestamp,
                                displayTime = exact.matchTime,
                                displayDate = exact.matchDate
                            )
                        } else group
                    }

                    allGroups = allGroups.sortedWith(
                        compareBy<MatchGroup> { it.matchTimestamp <= 0L }
                            .thenBy { if (it.matchTimestamp > 0L) it.matchTimestamp else Long.MAX_VALUE }
                            .thenBy { it.homeTeam.lowercase() }
                    )
                    adapter.submitList(allGroups)
                } catch (e: Exception) {
                    // Resmi oran servisi başarısız olsa bile mevcut CIO kartları ekranda kalır.
                }
            } catch (e: Exception) {
                // Tarama hatası ekrana diagnostic sayaç olarak basılmaz.
            } finally {
                setScanningUi(false)
            }
        }
    }

    private fun showLastFive(teamName: String, teamId: Long?) {
        startActivity(
            Intent(this, LastMatchesActivity::class.java).apply {
                putExtra(LastMatchesActivity.EXTRA_TEAM_NAME, teamName)
                putExtra(LastMatchesActivity.EXTRA_TEAM_ID, teamId)
            }
        )
    }

    private fun setScanningUi(active: Boolean) {
        scanning = active
        scanButton.isEnabled = !active
        scanButton.text = if (active) "TARANIYOR…" else "⚡ BUGÜNÜ TARA"
        scanProgress.visibility = if (active) View.VISIBLE else View.GONE
    }

    private fun isDisplayable(x: ScoreModel): Boolean {
        if (x.homeTeam.isBlank() || x.awayTeam.isBlank() || x.source.isBlank()) return false
        if (!Regex("^[0-9]{1,2}-[0-9]{1,2}$").matches(x.predictedScore.trim())) return false
        if (x.homeTeam.equals(x.awayTeam, ignoreCase = true)) return false
        return true
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
