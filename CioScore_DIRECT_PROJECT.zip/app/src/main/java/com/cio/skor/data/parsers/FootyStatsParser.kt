package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * FootyStats Correct Score parser.
 *
 * IMPORTANT:
 * - Reads only the full-time "Predicted Scoreline" section.
 * - Never reads "Predicted 1H Scoreline".
 * - Never promotes "Second Likely Correct Scoreline" to the primary pick.
 * - FootyStats uses both ':' and '-' between the two predicted goals.
 */
class FootyStatsParser : BaseParser("FootyStats") {

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()

        // FootyStats renders the full-time section first and the 1H section after it.
        // Restrict traversal to elements that belong to the full-time section.
        val fullTimeHeading = doc.select("h1, h2, h3, h4, h5").firstOrNull { heading ->
            heading.text().contains("Correct Score Predictions For Today", ignoreCase = true)
        } ?: return emptyList()

        val firstHalfHeading = doc.select("h1, h2, h3, h4, h5").firstOrNull { heading ->
            heading.text().contains("Correct Score 1st Half Predictions", ignoreCase = true)
        }

        val candidates = collectBetween(fullTimeHeading, firstHalfHeading)
            .filter { element ->
                element.text().contains("Predicted Scoreline", ignoreCase = true) &&
                    !element.text().contains("Predicted 1H Scoreline", ignoreCase = true)
            }

        for (scoreElement in candidates) {
            val score = extractFullTimeScore(scoreElement) ?: continue
            val fixture = findFixture(scoreElement) ?: continue

            val home = cleanTeam(fixture.first)
            val away = cleanTeam(fixture.second)
            if (!valid(home, away)) continue

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source
            )

            out[model.matchKey] = model
            if (out.size >= 50) break
        }

        return out.values.toList()
    }

    /**
     * Collect elements after the full-time heading and before the 1H heading.
     * This avoids ever treating a first-half prediction as a full-time prediction.
     */
    private fun collectBetween(start: Element, end: Element?): List<Element> {
        val root = start.ownerDocument() ?: return emptyList()
        val all = root.select("body *")
        val startIndex = all.indexOf(start)
        if (startIndex < 0) return emptyList()

        val endIndex = if (end != null) {
            val idx = all.indexOf(end)
            if (idx > startIndex) idx else all.size
        } else {
            all.size
        }

        return all.subList(startIndex + 1, endIndex)
    }

    private fun extractFullTimeScore(element: Element): String? {
        val text = clean(element.text())
        if (Regex("(?i)Predicted\\s+1H\\s+Scoreline").containsMatchIn(text)) return null

        val match = Regex(
            "(?i)Predicted\\s+Scoreline\\s*:\\s*([0-5])\\s*[:\\-]\\s*([0-5])\\b"
        ).find(text) ?: return null

        return "${match.groupValues[1]}-${match.groupValues[2]}"
    }

    /**
     * Walk upward from the prediction element until the fixture link is found.
     * FootyStats renders the fixture as a link whose visible text contains "vs".
     */
    private fun findFixture(element: Element): Pair<String, String>? {
        var current: Element? = element
        repeat(8) {
            val parent = current ?: return null
            val link = parent.select("a[href]")
                .firstOrNull { anchor ->
                    Regex("(?i)\\s+vs\\s+").containsMatchIn(clean(anchor.text()))
                }

            if (link != null) {
                return splitFixture(link.text())
            }

            current = parent.parent()
        }
        return null
    }

    private fun splitFixture(raw: String): Pair<String, String>? {
        val text = clean(raw)
            .replace(Regex("(?i)\\s*Predictions?\\s*[›>].*$"), "")
            .trim()

        val match = Regex("(?i)^(.+?)\\s+vs\\s+(.+)$").find(text) ?: return null
        val home = match.groupValues[1].trim()
        val away = match.groupValues[2].trim()

        if (home.isBlank() || away.isBlank()) return null
        return home to away
    }

    private fun cleanTeam(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '–', '—', ':', '|')

    private fun clean(value: String): String = value
        .replace('\u00A0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
