package com.cio.skor.data

import com.cio.skor.data.parsers.*
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/** Five-source repository. Forebet is intentionally excluded. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        sources.mapIndexed { index, source ->
            async {
                val result = try {
                    val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                    val (code, html) = http.get(source.url, referer)
                    if (code in 200..299 && !html.isNullOrBlank()) {
                        SourceResult(
                            source.name,
                            code,
                            source.parser.parse(Jsoup.parse(html, source.url)),
                            null
                        )
                    } else {
                        SourceResult(source.name, code, emptyList(), "HTTP_$code")
                    }
                } catch (e: Exception) {
                    SourceResult(source.name, -1, emptyList(), e.javaClass.simpleName)
                }

                onProgress(index + 1, source.name)
                result
            }
        }.awaitAll()
    }
}
