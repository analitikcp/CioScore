package com.cio.skor.network

import android.util.Log
import com.cio.skor.data.MatchMerger
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * The Odds API v4 client.
 *
 * The current ScoreModel does not carry a league/sportKey, so it is NOT
 * possible to query "only the leagues of the visible matches" without
 * changing every scraper/model. Instead this client discovers active
 * soccer_* leagues, prioritizes likely relevant leagues, and stops when
 * the account quota is exhausted.
 *
 * This is deliberately fail-safe: Odds API failure never hides scraper data.
 */
object OddsApiClient {
    private const val API_KEY = "de27ecac1f8b332cbeb5bb84a5276a7d"
    private const val API_HOST = "https://api.the-odds-api.com/v4"
    private const val REGIONS = "eu,uk"
    private const val MARKETS = "h2h"
    private const val ODDS_FORMAT = "decimal"

    // Do not spend the final request(s) just to continue discovery.
    private const val MIN_REMAINING_TO_CONTINUE = 2

    var remainingRequests: String = "-"
        private set

    fun fetchOdds(): List<OddsData> {
        Log.d("OddsApiClient", "ODDS_API_STARTED")

        if (API_KEY.isBlank()) {
            Log.e("OddsApiClient", "API_KEY_EMPTY")
            return emptyList()
        }

        val result = linkedMapOf<String, OddsData>()

        try {
            val sportKeys = fetchActiveSoccerSportKeys()
            Log.d("OddsApiClient", "SPORTS_COUNT=${sportKeys.size}")
            Log.d("OddsApiClient", "SPORT_KEYS=${sportKeys.joinToString(",")}")

            for (sportKey in sportKeys) {
                val remaining = remainingRequests.toIntOrNull()
                if (remaining != null && remaining < MIN_REMAINING_TO_CONTINUE) {
                    Log.w("OddsApiClient", "QUOTA_STOP remaining=$remaining")
                    break
                }

                val events = fetchOddsForSport(sportKey)
                Log.d("OddsApiClient", "ODDS_FETCHED sport=$sportKey count=${events.size}")

                for (odds in events) {
                    result.putIfAbsent(
                        MatchMerger.key(odds.homeTeam, odds.awayTeam),
                        odds
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("OddsApiClient", "ODDS_API_ERROR", e)
        }

        Log.d("OddsApiClient", "ODDS_TOTAL=${result.size}")
        return result.values.toList()
    }

    private fun fetchActiveSoccerSportKeys(): List<String> {
        val json = get("$API_HOST/sports/?apiKey=$API_KEY")
            ?: return emptyList()

        val array = JSONArray(json)
        val keys = mutableListOf<String>()

        for (i in 0 until array.length()) {
            val sport = array.getJSONObject(i)
            val key = sport.optString("key")
            val active = sport.optBoolean("active", false)

            if (
                active &&
                key.startsWith("soccer_") &&
                !key.contains("winner", ignoreCase = true) &&
                !key.contains("outright", ignoreCase = true)
            ) {
                keys += key
            }
        }

        // Prioritize competitions most likely to contain the scraper's
        // daily fixtures. Remaining active soccer leagues are still included.
        return keys.distinct().sortedWith(
            compareBy<String> {
                when {
                    it == "soccer_turkey_super_league" -> 0
                    it == "soccer_uefa_champs_league" -> 1
                    it.contains("uefa_champs_league") -> 2
                    it.contains("uefa_europa_league") -> 3
                    it == "soccer_epl" -> 4
                    it == "soccer_spain_la_liga" -> 5
                    it == "soccer_italy_serie_a" -> 6
                    it == "soccer_germany_bundesliga" -> 7
                    it == "soccer_france_ligue_one" -> 8
                    else -> 20
                }
            }.thenBy { it }
        )
    }

    private fun fetchOddsForSport(sportKey: String): List<OddsData> {
        val encoded = URLEncoder.encode(sportKey, "UTF-8")
        val url =
            "$API_HOST/sports/$encoded/odds/?" +
                "apiKey=$API_KEY" +
                "&regions=$REGIONS" +
                "&markets=$MARKETS" +
                "&oddsFormat=$ODDS_FORMAT"

        val json = get(url) ?: return emptyList()
        val events = JSONArray(json)

        Log.d(
            "OddsApiClient",
            "EVENT_COUNT sport=$sportKey count=${events.length()}"
        )

        val result = mutableListOf<OddsData>()

        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            val home = event.optString("home_team").trim()
            val away = event.optString("away_team").trim()

            if (home.isBlank() || away.isBlank()) continue

            val bookmakers = event.optJSONArray("bookmakers")
                ?: continue

            val names = buildList {
                for (b in 0 until bookmakers.length()) {
                    val bm = bookmakers.getJSONObject(b)
                    add("${bm.optString("key")}=${bm.optString("title")}")
                }
            }

            Log.d(
                "OddsApiClient",
                "BOOKMAKERS sport=$sportKey match=$home - $away values=$names"
            )

            val bookmaker = findFirstH2hBookmaker(bookmakers)
            if (bookmaker == null) {
                Log.d(
                    "OddsApiClient",
                    "H2H_NOT_FOUND match=$home - $away"
                )
                continue
            }

            val bookmakerName =
                bookmaker.optString("title")
                    .ifBlank { bookmaker.optString("key") }

            val h2h = findH2h(bookmaker.optJSONArray("markets"))
                ?: continue

            var odd1 = "-"
            var oddX = "-"
            var odd2 = "-"

            val outcomes = h2h.optJSONArray("outcomes")
                ?: continue

            for (j in 0 until outcomes.length()) {
                val outcome = outcomes.getJSONObject(j)
                val name = outcome.optString("name").trim()
                val price = outcome.optDouble("price", Double.NaN)

                if (price.isNaN()) continue

                when {
                    MatchMerger.isSameTeam(name, home) ->
                        odd1 = formatOdd(price)

                    MatchMerger.isSameTeam(name, away) ->
                        odd2 = formatOdd(price)

                    name.equals("Draw", ignoreCase = true) ->
                        oddX = formatOdd(price)
                }
            }

            if (odd1 != "-" || oddX != "-" || odd2 != "-") {
                Log.d(
                    "OddsApiClient",
                    "ODDS_PARSED match=$home - $away " +
                        "bookmaker=$bookmakerName MS1=$odd1 MSX=$oddX MS2=$odd2"
                )

                result += OddsData(
                    homeTeam = home,
                    awayTeam = away,
                    bookmakerName = bookmakerName,
                    odd1 = odd1,
                    oddX = oddX,
                    odd2 = odd2
                )
            }
        }

        return result
    }

    private fun findFirstH2hBookmaker(bookmakers: JSONArray): JSONObject? {
        for (i in 0 until bookmakers.length()) {
            val bookmaker = bookmakers.getJSONObject(i)
            if (findH2h(bookmaker.optJSONArray("markets")) != null) {
                return bookmaker
            }
        }
        return null
    }

    private fun findH2h(markets: JSONArray?): JSONObject? {
        if (markets == null) return null

        for (i in 0 until markets.length()) {
            val market = markets.getJSONObject(i)
            if (market.optString("key") == "h2h") {
                return market
            }
        }

        return null
    }

    private fun get(urlString: String): String? {
        var connection: HttpURLConnection? = null

        return try {
            connection =
                (URL(urlString).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 10000
                    useCaches = false
                }

            remainingRequests =
                connection.getHeaderField("x-requests-remaining")
                    ?: remainingRequests

            Log.d(
                "OddsApiClient",
                "HTTP_REQUEST endpoint=${urlString.substringBefore("?")} " +
                    "remaining=$remainingRequests"
            )

            val code = connection.responseCode

            if (code != HttpURLConnection.HTTP_OK) {
                Log.e(
                    "OddsApiClient",
                    "HTTP_STATUS=$code remaining=$remainingRequests"
                )
                null
            } else {
                connection.inputStream
                    .bufferedReader()
                    .use { it.readText() }
            }
        } catch (e: Exception) {
            Log.e("OddsApiClient", "HTTP_EXCEPTION", e)
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun formatOdd(value: Double): String =
        String.format(Locale.US, "%.2f", value)
}

data class OddsData(
    val homeTeam: String,
    val awayTeam: String,
    val bookmakerName: String,
    val odd1: String,
    val oddX: String,
    val odd2: String
)
