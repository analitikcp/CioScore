# CIO Score 0.8.8 - 5 Kaynak - Match Merge

Bu sürümde 5 kaynaktan gelen skorlar önce tek ham havuzda toplanır, ardından ev/deplasman takım adları normalize edilerek aynı maç tek kayda birleştirilir.

Aktif kaynaklar: FP.com, PredictZ, WinDrawWin, SoccerSeer ve DailySports.
