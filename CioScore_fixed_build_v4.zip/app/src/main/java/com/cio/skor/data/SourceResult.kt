package com.cio.skor.data

/** Result returned by one scraper source. */
data class SourceResult(
    val sourceName: String,
    val scores: List<ScoreModel>
)
