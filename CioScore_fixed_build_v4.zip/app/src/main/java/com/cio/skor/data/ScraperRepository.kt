package com.cio.skor.data

import com.cio.skor.data.parsers.BaseParser
import com.cio.skor.data.parsers.DailySportsParser
import com.cio.skor.data.parsers.FPComParser
import com.cio.skor.data.parsers.FlashscoreParser
import com.cio.skor.data.parsers.PredictZParser
import com.cio.skor.data.parsers.SoccerSeerParser
import com.cio.skor.data.parsers.WinDrawWinParser
import com.cio.skor.network.HttpClient
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jsoup.Jsoup

/** Five-source repository. */
class ScraperRepository {
    data class Source(val name: String, val url: String, val parser: BaseParser)

    private val http = HttpClient()

    private val sources = listOf(
        Source("FP.com", "https://footballpredictions.com/betting-tips/correct-score/", FPComParser()),
        Source("PredictZ", "https://www.predictz.com/predictions/today/correct-score/", PredictZParser()),
        Source("WinDrawWin", "https://www.windrawwin.com/predictions/today/", WinDrawWinParser()),
        Source("SoccerSeer", "https://soccerseer.com/soccer/correct-score-predictions/", SoccerSeerParser()),
        Source("DailySports", "https://dailysports.net/mathematical-predictions/correct-score/", DailySportsParser())
    )

    val sourceCount: Int get() = sources.size
    val sourceNames: List<String> get() = sources.map { it.name }

    suspend fun fetchFlashscoreOdds(): List<ScoreModel> {
        return try {
            val (code, html) = http.get("https://www.flashscore.com/")
            if (code in 200..299 && !html.isNullOrBlank()) {
                FlashscoreParser().parseOddsHtml(html)
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun fetchAllSources(): List<SourceResult> = coroutineScope {
        val tasks: List<kotlinx.coroutines.Deferred<SourceResult>> = listOf(
            async { SourceResult("Flashscore", fetchFlashscoreOdds()) }
        ) + sources.map { source ->
            async {
                try {
                    val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                    val (code, html) = http.get(source.url, referer)
                    if (code in 200..299 && !html.isNullOrBlank()) {
                        SourceResult(source.name, source.parser.parse(Jsoup.parse(html, source.url)))
                    } else {
                        SourceResult(source.name, emptyList())
                    }
                } catch (_: Exception) {
                    SourceResult(source.name, emptyList())
                }
            }
        }
        tasks.awaitAll()
    }

    suspend fun fetchAll(onProgress: (Int, String) -> Unit): List<SourceResult> = coroutineScope {
        val tasks: List<kotlinx.coroutines.Deferred<SourceResult>> = sources.mapIndexed { index, source ->
            async {
                val result = try {
                    val referer = if (source.name == "DailySports") "https://dailysports.net/" else null
                    val (code, html) = http.get(source.url, referer)
                    if (code in 200..299 && !html.isNullOrBlank()) {
                        SourceResult(
                            sourceName = source.name,
                            scores = source.parser.parse(Jsoup.parse(html, source.url))
                        )
                    } else {
                        SourceResult(sourceName = source.name, scores = emptyList())
                    }
                } catch (e: Exception) {
                    SourceResult(sourceName = source.name, scores = emptyList())
                }

                onProgress(index + 1, source.name)
                result
            }
        }
        tasks.awaitAll()
    }
}
