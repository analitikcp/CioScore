package com.cio.skor.data

data class ScoreModel(
    val id: String,
    val homeTeam: String,
    val awayTeam: String,
    val matchTime: String = "",
    val prediction: String = "",
    val source: String = "",
    val oddsMs1: String = "-",
    val oddsMsX: String = "-",
    val oddsMs2: String = "-"
) {
    // Stable key used by parsers and match-merging logic.
    val matchKey: String
        get() = "${homeTeam.lowercase().trim()}_${awayTeam.lowercase().trim()}"

    // Backward-compatible alias used by existing code.
    val predictedScore: String
        get() = prediction

    // Backward-compatible constructor used by existing parsers.
    constructor(
        homeTeam: String,
        awayTeam: String,
        predictedScore: String,
        source: String
    ) : this(
        id = "${homeTeam}_${awayTeam}".hashCode().toString(),
        homeTeam = homeTeam,
        awayTeam = awayTeam,
        prediction = predictedScore,
        source = source
    )
}
