package com.cio.skor.data.parsers

import com.cio.skor.data.ScoreModel
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * RatingBet (RBScore) Correct Score parser.
 * Source: https://ratingbet.com/football/correct-score/
 *
 * RatingBet exposes each fixture with kickoff time, competition heading,
 * home/away teams and a "Result : H-A" best correct-score prediction.
 */
class RBScoreParser : BaseParser("RBScore") {

    private val resultRegex = Regex("(?i)\\bResult\\s*:\\s*(\\d{1,2})\\s*[-:]\\s*(\\d{1,2})")
    private val timeRegex = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")
    private val pageDateRegex = Regex("(?i)Correct Score Prediction Today\\s*-\\s*([A-Za-z]{3,9})\\s+(\\d{1,2}),\\s+(\\d{4})")
    private val dateFormatter = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH)

    override fun parse(doc: Document): List<ScoreModel> {
        val out = LinkedHashMap<String, ScoreModel>()
        val pageDate = extractPageDate(doc)

        // A Result marker is unique to an individual prediction card.
        val markers = doc.getElementsContainingOwnText("Result")
            .filter { resultRegex.containsMatchIn(it.text()) }
            .sortedBy { it.text().length }

        for (marker in markers) {
            val result = resultRegex.find(marker.text()) ?: continue
            val score = "${result.groupValues[1]}-${result.groupValues[2]}"
            val card = findFixtureCard(marker) ?: continue
            val teams = extractTeams(card)
            if (teams.size < 2) continue

            val home = team(teams[0])
            val away = team(teams[1])
            if (!valid(home, away)) continue

            val matchTime = extractTime(card) ?: continue
            val competition = extractCompetition(card)
            val timestamp = buildTimestamp(pageDate, matchTime)
            val sourceMatchId = card.select("a[href]")
                .map { it.attr("href").trim() }
                .firstOrNull { it.isNotBlank() }
                ?.let { stableId(it) }
                .orEmpty()

            val model = ScoreModel(
                homeTeam = home,
                awayTeam = away,
                predictedScore = score,
                source = source,
                sourceMatchId = sourceMatchId,
                matchTimestamp = timestamp,
                matchDate = pageDate ?: "",
                matchTime = matchTime,
                competitionName = competition
            )

            val key = if (sourceMatchId.isNotBlank()) {
                "ID|$sourceMatchId"
            } else {
                "META|${home.lowercase()}|${away.lowercase()}|$pageDate|$matchTime|$competition"
            }
            out.putIfAbsent(key, model)
            if (out.size >= 300) break
        }

        return out.values.toList()
    }

    private fun findFixtureCard(start: Element): Element? {
        var current: Element? = start
        repeat(12) {
            current = current?.parent() ?: return null
            val node = current ?: return@repeat
            val text = clean(node.text())
            if (text.length !in 40..3500) return@repeat
            if (resultRegex.containsMatchIn(text) && extractTime(node) != null) {
                val teams = extractTeams(node)
                if (teams.size >= 2) return node
            }
        }
        return null
    }

    private fun extractTeams(card: Element): List<String> {
        val fromImages = card.select("img").flatMap { img ->
            listOf(img.attr("alt"), img.attr("title"), img.attr("aria-label"))
        }.map { it.removePrefix("Image:").trim() }
            .filter(::looksLikeTeam)
            .distinct()

        if (fromImages.size >= 2) return fromImages.take(2)

        val fromLinks = card.select("a").flatMap { a ->
            listOf(a.text(), a.attr("title"), a.attr("aria-label"))
        }.map(::clean)
            .filter(::looksLikeTeam)
            .distinct()

        return fromLinks.take(2)
    }

    private fun looksLikeTeam(value: String): Boolean {
        val s = clean(value).removePrefix("Image:").trim()
        if (s.length !in 2..80) return false
        if (s.matches(Regex("^[0-9 .:/%+\\-]+$"))) return false
        if (timeRegex.matches(s)) return false
        if (resultRegex.containsMatchIn(s)) return false
        return !Regex("(?i)^(game|time|best tip|result|probability|tip probability|view|close)$").matches(s)
    }

    private fun extractTime(card: Element): String? {
        return card.text().split(Regex("\\s+"))
            .map { it.trim() }
            .firstOrNull { timeRegex.matches(it) }
    }

    private fun extractCompetition(card: Element): String {
        // RatingBet groups fixtures under competition headings. Walk upward and
        // inspect previous siblings for a heading before falling back to blank.
        var node: Element? = card
        repeat(8) {
            node = node?.parent() ?: return@repeat
            val parent = node ?: return@repeat
            var sibling = parent.previousElementSibling()
            var steps = 0
            while (sibling != null && steps++ < 8) {
                val text = clean(sibling.text())
                if (text.length in 3..120 &&
                    !text.contains("Time Game", true) &&
                    !text.contains("Best Tip", true) &&
                    !timeRegex.matches(text)
                ) {
                    return text
                }
                sibling = sibling.previousElementSibling()
            }
        }
        return ""
    }

    private fun extractPageDate(doc: Document): String? {
        val h1 = doc.select("h1").firstOrNull()?.text().orEmpty()
        val match = pageDateRegex.find(h1)
        if (match != null) {
            val parsed = runCatching {
                LocalDate.parse("${match.groupValues[1].replaceFirstChar { it.uppercase() }} ${match.groupValues[2]}, ${match.groupValues[3]}", dateFormatter)
            }.getOrNull()
            if (parsed != null) return parsed.toString()
        }
        return LocalDate.now(ZoneId.of("Europe/Istanbul")).toString()
    }

    private fun buildTimestamp(date: String?, time: String): Long {
        if (date.isNullOrBlank()) return 0L
        return runCatching {
            val local = LocalDate.parse(date).atTime(
                time.substringBefore(':').toInt(),
                time.substringAfter(':').toInt()
            )
            local.atZone(ZoneId.of("Europe/Istanbul")).toInstant().toEpochMilli()
        }.getOrDefault(0L)
    }

    private fun stableId(href: String): String = href
        .substringBefore('?')
        .substringBefore('#')
        .trimEnd('/')
}
