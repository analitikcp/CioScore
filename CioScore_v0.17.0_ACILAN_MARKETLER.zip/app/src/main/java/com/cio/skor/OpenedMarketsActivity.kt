package com.cio.skor

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.cio.skor.data.MackolikMarketService
import com.cio.skor.data.MatchMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OpenedMarketsActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val service = MackolikMarketService()
    private lateinit var content: LinearLayout
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF6F8FB.toInt())
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            view.setPadding(view.paddingLeft, top + dp(8), view.paddingRight, view.paddingBottom)
            insets
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "📊 Açılan Marketler"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF0F172A.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        header.addView(Button(this).apply {
            text = "KAPAT"
            setOnClickListener { finish() }
        })
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "Bugün Maçkolik'te oranı açılmış HT/FT ve Doğru Skor maçları"
            textSize = 13f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, dp(2), 0, dp(8))
        })

        progress = ProgressBar(this).apply { visibility = View.VISIBLE }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(40)))
        status = TextView(this).apply {
            text = "Marketler taranıyor…"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF475569.toInt())
        }
        root.addView(status)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply {
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        load()
    }

    private fun load() {
        scope.launch {
            val result = withContext(Dispatchers.IO) { service.fetchOpenedMarkets() }
            progress.visibility = View.GONE
            render(result)
        }
    }

    private fun render(result: MackolikMarketService.Result) {
        content.removeAllViews()
        if (result.matches.isEmpty()) {
            status.text = result.error ?: "Bugün açılmış HT/FT veya Doğru Skor marketi bulunamadı."
            return
        }

        status.text = "${result.matches.size} maç bulundu • ${result.scanned} maç tarandı"

        val htft = result.matches.filter { it.hasHtFt }
        val score = result.matches.filter { it.hasCorrectScore }
        val both = result.matches.filter { it.hasHtFt && it.hasCorrectScore }

        addSection("🟢 HT/FT AÇILANLAR", htft)
        addSection("🔵 DOĞRU SKOR AÇILANLAR", score)
        addSection("⭐ HT/FT + DOĞRU SKOR", both)
    }

    private fun addSection(title: String, matches: List<MackolikMarketService.OpenedMarketMatch>) {
        if (matches.isEmpty()) return
        content.addView(TextView(this).apply {
            text = "$title  (${matches.size})"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF00796B.toInt())
            setPadding(0, dp(12), 0, dp(6))
        })
        matches.sortedWith(compareBy({ MatchMerger.normalizeTeamName(it.homeTeam) }, { MatchMerger.normalizeTeamName(it.awayTeam) }))
            .forEach { match ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(11), dp(12), dp(11))
                    setBackgroundColor(0xFFFFFFFF.toInt())
                    elevation = dp(2).toFloat()
                    setOnClickListener {
                        // Market discovery is a list screen for now; tapping a row is reserved
                        // for the future detailed market screen.
                    }
                }
                row.addView(TextView(this).apply {
                    text = "${match.homeTeam}  VS  ${match.awayTeam}"
                    textSize = 14f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF0F172A.toInt())
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                })
                val badges = mutableListOf<String>()
                if (match.hasHtFt) badges += "HT/FT"
                if (match.hasCorrectScore) badges += "SKOR"
                row.addView(TextView(this).apply {
                    text = badges.joinToString(" • ")
                    textSize = 11f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(0xFF00796B.toInt())
                })
                content.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(7)
                })
            }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
