package com.cio.skor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.json.JSONObject
import java.time.LocalDate
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Discovers which detailed Iddaa markets are actually opened for today's
 * football fixtures on Mackolik. This is intentionally separate from the
 * 1/X/2 odds parser so missing MS odds never hide an opened HT/FT or score
 * market.
 */
class MackolikMarketService {
    data class OpenedMarketMatch(
        val homeTeam: String,
        val awayTeam: String,
        val hasHtFt: Boolean,
        val hasCorrectScore: Boolean
    )

    data class Result(
        val matches: List<OpenedMarketMatch>,
        val scanned: Int,
        val error: String? = null
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(16, TimeUnit.SECONDS)
        .build()

    private val base = "https://www.mackolik.com"
    private val archiveUrl = "https://arsiv2.mackolik.com/Iddaa-Programi"

    suspend fun fetchOpenedMarkets(): Result = withContext(Dispatchers.IO) {
        withTimeoutOrNull(30_000L) {
            try {
                val candidates = fetchLiveCandidates().ifEmpty {
                    val html = get(archiveUrl) ?: return@withTimeoutOrNull Result(emptyList(), 0, "Bülten alınamadı")
                    val doc = Jsoup.parse(html, archiveUrl)
                    parseCandidates(doc)
                }
                if (candidates.isEmpty()) {
                    return@withTimeoutOrNull Result(emptyList(), 0, "Bugünün maç detay bağlantıları bulunamadı")
                }

                val found = coroutineScope {
                    candidates.chunked(8).flatMap { chunk ->
                        chunk.map { candidate ->
                            async(Dispatchers.IO) {
                                inspect(candidate)
                            }
                        }.awaitAll().filterNotNull()
                    }
                }

                Result(
                    matches = found
                        .groupBy { MatchMerger.key(it.homeTeam, it.awayTeam) }
                        .values
                        .map { same ->
                            OpenedMarketMatch(
                                homeTeam = same.first().homeTeam,
                                awayTeam = same.first().awayTeam,
                                hasHtFt = same.any { it.hasHtFt },
                                hasCorrectScore = same.any { it.hasCorrectScore }
                            )
                        },
                    scanned = candidates.size
                )
            } catch (e: Exception) {
                Result(emptyList(), 0, "${e.javaClass.simpleName}: ${e.message ?: "bilinmeyen hata"}")
            }
        } ?: Result(emptyList(), 0, "Market taraması zaman aşımına uğradı")
    }

    private data class Candidate(
        val homeTeam: String,
        val awayTeam: String,
        val detailUrl: String
    )

    /**
     * Mackolik's public live-scores JSON gives us the real event ID. Using the
     * event ID avoids guessing an archive row link and lets us open the same
     * match detail page that contains the complete market list.
     */
    private fun fetchLiveCandidates(): List<Candidate> {
        val date = LocalDate.now().toString()
        val url = "https://www.mackolik.com/perform/p0/ajax/components/competition/livescores/json" +
            "?sports%5B%5D=Soccer&matchDate=$date"
        val body = get(url) ?: return emptyList()
        return runCatching {
            val matches = JSONObject(body).optJSONObject("data")?.optJSONObject("matches") ?: return emptyList()
            val out = LinkedHashMap<String, Candidate>()
            val keys = matches.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = matches.optJSONObject(id) ?: continue
                if (item.optString("iddaaCode", "").isBlank() || item.optString("iddaaCode") == "None") continue
                val name = item.optString("matchName").replace(Regex("\\s+"), " ").trim()
                val parts = Regex("\\s+-\\s+").findAll(name).toList()
                if (parts.size != 1) continue
                val p = parts.first()
                val home = name.substring(0, p.range.first).trim()
                val away = name.substring(p.range.last + 1).trim()
                if (home.length !in 2..80 || away.length !in 2..80) continue
                val slug = (home + "-vs-" + away)
                    .lowercase(Locale.ROOT)
                    .replace(Regex("[^a-z0-9]+"), "-")
                    .trim('-')
                val detail = "$base/mac/$slug/iddaa/$id"
                out[MatchMerger.key(home, away)] = Candidate(home, away, detail)
            }
            out.values.toList()
        }.getOrDefault(emptyList())
    }

    private fun parseCandidates(doc: org.jsoup.nodes.Document): List<Candidate> {
        val out = LinkedHashMap<String, Candidate>()
        for (row in doc.select("tr")) {
            val teamPair = findTeamPair(row) ?: continue
            val link = row.select("a[href]").mapNotNull { it.attr("abs:href").ifBlank { null } }
                .firstOrNull { it.contains("/iddaa/", ignoreCase = true) }
                ?: row.select("a[href]").mapNotNull { it.attr("abs:href").ifBlank { null } }
                    .firstOrNull { it.contains("/mac/", ignoreCase = true) && it.contains("mackolik.com") }
                ?: continue

            val key = MatchMerger.key(teamPair.first, teamPair.second)
            out[key] = Candidate(teamPair.first, teamPair.second, link)
        }
        return out.values.toList()
    }

    private fun findTeamPair(row: Element): Pair<String, String>? {
        val cells = row.select("td, th")
        return cells.asSequence()
            .map { it.text().replace(Regex("\\s+"), " ").trim() }
            .mapNotNull { text ->
                val parts = Regex("\\s+-\\s+").findAll(text).toList()
                if (parts.size != 1) return@mapNotNull null
                val p = parts.first()
                val home = text.substring(0, p.range.first).trim()
                val away = text.substring(p.range.last + 1).trim()
                if (home.length !in 2..80 || away.length !in 2..80) null else home to away
            }
            .firstOrNull()
    }

    private fun inspect(candidate: Candidate): OpenedMarketMatch? {
        val html = get(candidate.detailUrl) ?: return null
        val doc = Jsoup.parse(html, candidate.detailUrl)

        val headers = doc.select("ul.widget-iddaa-markets__markets-list h2 span, " +
            "ul.widget-iddaa-markets__markets-list h2")
            .map { it.text().replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }

        if (headers.isEmpty()) return null

        var htFt = false
        var correctScore = false
        for (header in headers) {
            val n = normalize(header)
            if ((n.contains("iy") && n.contains("ms")) ||
                (n.contains("ilk yari") && n.contains("mac sonucu")) ||
                (n.contains("devre") && n.contains("mac sonucu")) ||
                n.contains("ilk yarima c sonucu") ||
                n.contains("ilk yari mac sonucu")
            ) htFt = true

            if (n.contains("dogru skor") || n.contains("mac skoru") || n.contains("correct score")) {
                correctScore = true
            }
        }

        if (!htFt && !correctScore) return null
        return OpenedMarketMatch(candidate.homeTeam, candidate.awayTeam, htFt, correctScore)
    }

    private fun normalize(value: String): String {
        var v = value.lowercase(Locale.ROOT)
            .replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i')
            .replace('ö', 'o').replace('ş', 's').replace('ü', 'u')
        v = java.text.Normalizer.normalize(v, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
        return v.replace(Regex("[^a-z0-9]+"), " ").trim()
    }

    private fun get(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
            .header("Referer", base + "/")
            .build()
        return runCatching {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) null else response.body?.string()
            }
        }.getOrNull()
    }
}
