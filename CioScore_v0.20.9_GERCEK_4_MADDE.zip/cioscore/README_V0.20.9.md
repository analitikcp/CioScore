# CioScore v0.20.9 — Gerçek 4 Madde

Bu sürüm v0.20.8'in kaynaklarını doğrudan düzelterek hazırlanmıştır.

## 1) Skor Analiz Filtreleri
Kartta her zaman 5 satır gösterilir:
- Skor Analiz Filtre1
- Skor Analiz Filtre2
- Skor Analiz Filtre3
- Skor Analiz Filtre4
- Skor Analiz Filtre5

Bir kaynaktan tahmin gelmezse satır kaybolmaz; `--` gösterilir.

## 2) Ana kart HT/FT oranları
Ana kartta İY/MS 9'lu oran matrisi ve `İY/MS • RESMİ İDDAA` başlığı YOK.
Ana kartta sadece resmi İddaa Maç Sonucu: MS 1 / MS X / MS 2 bulunur.
HT/FT oranları ayrı HT/FT ekranında gösterilir.

## 3) Aramayı Temizle
`ARAMAYI TEMİZLE` butonu ana layout'tan kaldırılmıştır.

## 4) HT/FT ekranı
Tek başlık: `⚡ HT/FT Açılan Maçlar (N)`.
Eski büyük çift başlık/açıklama yoktur. Maç sayısı başlığın yanındadır.

## Kritik oran düzeltmesi
MS 1 / MS X / MS 2, sportsbook HT/FT akışından alınmaz.
Ayrı resmi İddaa programı veri kaynağı kullanılır:
https://s.iddaa.com/api/v1/program/sports/1/events?date=YYYY-MM-DD

HT/FT ve event saati sportsbook akışından; MS oranları ayrı resmi program akışından alınır ve takım adlarıyla eşleştirilir.

Maçkolik oranı/kaynağı kullanılmaz.
