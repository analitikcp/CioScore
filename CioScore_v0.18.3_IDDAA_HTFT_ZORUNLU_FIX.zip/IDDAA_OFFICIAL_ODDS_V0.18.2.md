# CioScore v0.18.2 — Official Iddaa odds correction

- Maçkolik odds/market are not used.
- Official Iddaa sportsbook events + market_config remain the source.
- Critical fix: generic 1/X/2-shaped markets (such as İlk Yarı Sonucu) are no longer mistaken for MS 1/X/2.
- MS 1/X/2 is accepted only when the official market config identifies Maç Sonucu / Match Result.
- HT/FT is recognized from the 9-outcome grid and normalized 0 -> X.
- Correct Score remains grid/name based.
