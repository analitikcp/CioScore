package com.cio.skor.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.abs

/**
 * Production-oriented global fixture identity engine.
 *
 * Four identity layers are intentionally separated:
 * 1) TeamAliasCanonicalizer  -> stable source-independent team IDs
 * 2) Official Iddaa anchor   -> strongest fixture authority
 * 3) Union-Find clustering    -> global, non-greedy grouping
 * 4) Evidence/confidence      -> ID + date/time + team similarity validation
 *
 * Important invariant: a fuzzy pair can never create a cluster merely because
 * one side matches. Home AND away must agree. Official fixtures can relax the
 * name threshold only when the official record is the anchor and there is no
 * contradictory time information.
 */
object GlobalFixtureMatcher {

    private const val TEAM_FUZZY_MIN = 0.90
    private const val OFFICIAL_TEAM_MIN = 0.86
    private const val AUTO_MERGE_CONFIDENCE = 0.84

    private const val TIME_SOFT_WINDOW_MS = 3L * 60L * 60L * 1000L
    private const val TIME_HARD_WINDOW_MS = 6L * 60L * 60L * 1000L

    data class Record(
        val homeTeam: String,
        val awayTeam: String,
        val predictedScore: String? = null,
        val source: String,
        val sourceMatchId: String = "",
        val matchTimestamp: Long = 0L,
        val matchDate: String = "",
        val matchTime: String = "--:--",
        val official: IddaaMarketService.OpenedMarketMatch? = null
    ) {
        val homeCanonicalId: String get() = TeamAliasCanonicalizer.identity(homeTeam).canonicalId
        val awayCanonicalId: String get() = TeamAliasCanonicalizer.identity(awayTeam).canonicalId
        val fixtureKey: String get() = "$homeCanonicalId||$awayCanonicalId"
    }

    data class UnifiedMatch(
        var mainHomeTeam: String,
        var mainAwayTeam: String,
        val predictions: MutableList<Pair<String, String>> = mutableListOf(),
        var officialMatch: IddaaMarketService.OpenedMarketMatch? = null,
        var fixtureConfidence: Double = 1.0,
        var officialMatchId: String = "",
        var fixtureKey: String = ""
    )

    data class MatchEvidence(
        val homeSimilarity: Double,
        val awaySimilarity: Double,
        val teamScore: Double,
        val timeScore: Double,
        val idAnchor: Boolean,
        val officialAnchor: Boolean,
        val confidence: Double,
        val accepted: Boolean
    )

    private class UnionFind(size: Int) {
        private val parent = IntArray(size) { it }
        private val rank = IntArray(size)

        fun find(value: Int): Int {
            var x = value
            while (parent[x] != x) x = parent[x]
            val root = x
            x = value
            while (parent[x] != x) {
                val next = parent[x]
                parent[x] = root
                x = next
            }
            return root
        }

        fun union(a: Int, b: Int) {
            var ra = find(a)
            var rb = find(b)
            if (ra == rb) return
            if (rank[ra] < rank[rb]) {
                val tmp = ra; ra = rb; rb = tmp
            }
            parent[rb] = ra
            if (rank[ra] == rank[rb]) rank[ra]++
        }
    }

    fun merge(
        scraped: List<ScoreModel>,
        officialMatches: List<IddaaMarketService.OpenedMarketMatch>
    ): List<UnifiedMatch> {
        val records = ArrayList<Record>(scraped.size + officialMatches.size)

        // Sources 1-5: prediction records.
        scraped.forEach { s ->
            records += Record(
                homeTeam = s.homeTeam,
                awayTeam = s.awayTeam,
                predictedScore = s.predictedScore,
                source = s.source,
                sourceMatchId = s.sourceMatchId,
                matchTimestamp = s.matchTimestamp,
                matchDate = s.matchDate,
                matchTime = s.matchTime
            )
        }

        // Source 6: official Iddaa fixture/market records.
        officialMatches.forEach { o ->
            records += Record(
                homeTeam = o.homeTeam,
                awayTeam = o.awayTeam,
                source = "IDDAA",
                sourceMatchId = o.matchId,
                matchTimestamp = o.matchTimestamp,
                matchDate = o.matchDate,
                matchTime = o.matchTime,
                official = o
            )
        }

        if (records.isEmpty()) return emptyList()

        val uf = UnionFind(records.size)

        // PASS 1 -----------------------------------------------------
        // Official anchor: same official ID is absolute identity inside
        // the official namespace. Never compare IDs from different providers.
        val officialIdIndex = HashMap<String, Int>()
        records.indices.forEach { index ->
            val record = records[index]
            if (record.official != null) {
                val id = record.sourceMatchId.trim()
                if (id.isNotBlank()) {
                    officialIdIndex[id]?.let { uf.union(it, index) } ?: run {
                        officialIdIndex[id] = index
                    }
                }
            }
        }

        // PASS 2 -----------------------------------------------------
        // Canonical fixture key is deterministic and does not depend on the
        // arrival order of sources. This is the main fix for AEK/LASK variants.
        val exactBuckets = HashMap<String, MutableList<Int>>()
        records.indices.forEach { index ->
            val key = records[index].fixtureKey
            if (key != "||") exactBuckets.getOrPut(key) { mutableListOf() }.add(index)
        }
        exactBuckets.values.forEach { bucket ->
            for (i in 1 until bucket.size) uf.union(bucket[0], bucket[i])
        }

        // PASS 3 -----------------------------------------------------
        // Official anchor matching first. A prediction source with no time/ID
        // can still attach to the official fixture because the official fixture
        // is today's authoritative roster. Team agreement is always two-sided.
        records.indices.forEach { i ->
            val candidate = records[i]
            if (candidate.official != null) return@forEach

            var bestIndex = -1
            var bestScore = -1.0
            for (j in records.indices) {
                val anchor = records[j]
                if (anchor.official == null) continue
                val evidence = score(candidate, anchor)
                if (evidence.accepted && evidence.confidence > bestScore) {
                    bestScore = evidence.confidence
                    bestIndex = j
                }
            }
            if (bestIndex >= 0) uf.union(i, bestIndex)
        }

        // PASS 4 -----------------------------------------------------
        // Global fuzzy clustering among non-official records. No prefix block,
        // no greedy "first match wins". Pair decisions are evidence based.
        for (i in records.indices) {
            for (j in i + 1 until records.size) {
                val a = records[i]
                val b = records[j]
                if (sameSourceDifferentIds(a, b)) continue

                val evidence = score(a, b)
                if (!evidence.accepted) continue

                // High-confidence fuzzy pairs may union globally. Exact canonical
                // fixtures were already unioned in PASS 2; official anchors were
                // handled in PASS 3.
                if (evidence.idAnchor ||
                    evidence.officialAnchor ||
                    evidence.confidence >= AUTO_MERGE_CONFIDENCE) {
                    uf.union(i, j)
                }
            }
        }

        // Build connected components.
        val grouped = LinkedHashMap<Int, MutableList<Record>>()
        records.indices.forEach { index ->
            grouped.getOrPut(uf.find(index)) { mutableListOf() }.add(records[index])
        }

        return grouped.values.map(::buildUnified)
    }

    /** Public for regression tests and diagnostics. */
    fun score(a: Record, b: Record): MatchEvidence {
        if (a.homeTeam.isBlank() || a.awayTeam.isBlank() ||
            b.homeTeam.isBlank() || b.awayTeam.isBlank()) {
            return MatchEvidence(0.0, 0.0, 0.0, 0.0, false, false, 0.0, false)
        }

        if (sameSourceDifferentIds(a, b)) {
            return MatchEvidence(0.0, 0.0, 0.0, -1.0, false, false, 0.0, false)
        }

        val home = TeamAliasCanonicalizer.similarity(a.homeTeam, b.homeTeam)
        val away = TeamAliasCanonicalizer.similarity(a.awayTeam, b.awayTeam)
        val teamScore = (home + away) / 2.0
        val exactTeams = TeamAliasCanonicalizer.exact(a.homeTeam, b.homeTeam) &&
            TeamAliasCanonicalizer.exact(a.awayTeam, b.awayTeam)
        val idAnchor = sameComparableId(a, b)
        val officialAnchor = a.official != null || b.official != null
        val time = timeScore(a, b)

        // Same official ID or same ID in the same source is the strongest anchor.
        if (idAnchor) {
            return MatchEvidence(home, away, teamScore, maxOf(0.0, time), true, officialAnchor, 1.0, true)
        }

        // An impossible kickoff contradiction blocks a fuzzy merge even when names
        // are very similar. Exact canonical fixtures are allowed to survive only
        // when no time contradiction is present.
        if (time < 0.0) {
            return MatchEvidence(home, away, teamScore, time, false, officialAnchor, 0.0, false)
        }

        if (officialAnchor) {
            val accepted = exactTeams || (home >= OFFICIAL_TEAM_MIN && away >= OFFICIAL_TEAM_MIN)
            if (!accepted) {
                return MatchEvidence(home, away, teamScore, time, false, true, 0.0, false)
            }
            val confidence = (
                0.55 * teamScore +
                    0.30 * time.coerceAtLeast(0.0) +
                    0.15
            ).coerceIn(0.0, 0.99)
            return MatchEvidence(home, away, teamScore, time, false, true, confidence, true)
        }

        // Non-official fuzzy match: both sides must pass. A one-sided high score
        // is never sufficient.
        if (home < TEAM_FUZZY_MIN || away < TEAM_FUZZY_MIN) {
            return MatchEvidence(home, away, teamScore, time, false, false, 0.0, false)
        }

        if (exactTeams) {
            return MatchEvidence(home, away, 1.0, time, false, false, 0.98, true)
        }

        val timeContribution = if (time > 0.0) time else 0.0
        var confidence = 0.70 * teamScore + 0.30 * timeContribution
        if (home >= 0.97 && away >= 0.97) confidence += 0.04
        if (time >= 0.95) confidence += 0.04
        confidence = confidence.coerceIn(0.0, 0.99)

        return MatchEvidence(home, away, teamScore, time, false, false, confidence, confidence >= AUTO_MERGE_CONFIDENCE)
    }

    private fun sameSourceDifferentIds(a: Record, b: Record): Boolean {
        if (!a.source.equals(b.source, ignoreCase = true)) return false
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        return idA.isNotBlank() && idB.isNotBlank() && idA != idB
    }

    private fun sameComparableId(a: Record, b: Record): Boolean {
        val idA = a.sourceMatchId.trim()
        val idB = b.sourceMatchId.trim()
        if (idA.isBlank() || idB.isBlank() || idA != idB) return false

        // IDs are only portable when both records explicitly belong to the same
        // provider namespace, or both are official records.
        return a.source.equals(b.source, ignoreCase = true) ||
            (a.official != null && b.official != null)
    }

    /**
     * Time evidence:
     *  1. exact/near kickoff -> positive score
     *  2. 3h is the soft tolerance requested for timezone drift
     *  3. >6h is a hard contradiction
     *  4. missing time -> neutral (0), not a penalty
     *  5. known different calendar dates -> contradiction unless timestamps are
     *     close enough to account for timezone rollover.
     */
    private fun timeScore(a: Record, b: Record): Double {
        if (a.matchTimestamp > 0L && b.matchTimestamp > 0L) {
            val delta = abs(a.matchTimestamp - b.matchTimestamp)
            if (delta > TIME_HARD_WINDOW_MS) return -1.0
            return (1.0 - (delta.toDouble() / TIME_HARD_WINDOW_MS)).coerceIn(0.0, 1.0)
        }

        val dateA = parseDate(a.matchDate)
        val dateB = parseDate(b.matchDate)
        if (dateA != null && dateB != null) {
            val days = abs(java.time.temporal.ChronoUnit.DAYS.between(dateA, dateB))
            return when {
                days == 0L -> 0.92
                days == 1L -> 0.15
                else -> -1.0
            }
        }

        return 0.0
    }

    private fun parseDate(value: String): LocalDate? {
        val v = value.trim()
        if (v.isBlank()) return null
        val patterns = listOf("dd.MM.yyyy", "yyyy-MM-dd", "dd/MM/yyyy")
        for (pattern in patterns) {
            val parsed = runCatching {
                LocalDate.parse(v, DateTimeFormatter.ofPattern(pattern))
            }.getOrNull()
            if (parsed != null) return parsed
        }
        return null
    }

    private fun buildUnified(group: List<Record>): UnifiedMatch {
        val official = group.firstOrNull { it.official != null }?.official
        val display = chooseDisplay(group, official)
        val result = UnifiedMatch(
            mainHomeTeam = display.first,
            mainAwayTeam = display.second,
            officialMatch = official,
            officialMatchId = official?.matchId.orEmpty(),
            fixtureKey = TeamAliasCanonicalizer.identity(display.first).canonicalId +
                "||" + TeamAliasCanonicalizer.identity(display.second).canonicalId
        )

        // One prediction per source. If the same provider emitted duplicates,
        // keep the record with the richest identity metadata.
        val bySource = LinkedHashMap<String, Record>()
        group.filter { !it.predictedScore.isNullOrBlank() }.forEach { record ->
            val sourceKey = record.source.trim().lowercase()
            val old = bySource[sourceKey]
            if (old == null || sourcePriority(record) > sourcePriority(old)) {
                bySource[sourceKey] = record
            }
        }
        bySource.values.forEach { record ->
            result.predictions += record.source to record.predictedScore.orEmpty()
        }

        result.fixtureConfidence = groupConfidence(group)
        return result
    }

    private fun chooseDisplay(
        group: List<Record>,
        official: IddaaMarketService.OpenedMarketMatch?
    ): Pair<String, String> {
        if (official != null) return official.homeTeam to official.awayTeam
        val best = group.maxByOrNull {
            TeamAliasCanonicalizer.canonical(it.homeTeam).length +
                TeamAliasCanonicalizer.canonical(it.awayTeam).length
        } ?: group.first()
        return best.homeTeam to best.awayTeam
    }

    private fun sourcePriority(record: Record): Int {
        var score = 0
        if (!record.predictedScore.isNullOrBlank()) score += 5
        if (record.matchTimestamp > 0L) score += 3
        if (record.matchDate.isNotBlank()) score += 1
        if (record.sourceMatchId.isNotBlank()) score += 1
        if (record.official != null) score += 10
        return score
    }

    private fun groupConfidence(group: List<Record>): Double {
        if (group.size <= 1) return 1.0
        val accepted = mutableListOf<Double>()
        for (i in 0 until group.lastIndex) {
            for (j in i + 1..group.lastIndex) {
                val evidence = score(group[i], group[j])
                if (evidence.accepted) accepted += evidence.confidence
            }
        }
        return if (accepted.isEmpty()) 1.0 else accepted.average().coerceIn(0.0, 1.0)
    }
}
