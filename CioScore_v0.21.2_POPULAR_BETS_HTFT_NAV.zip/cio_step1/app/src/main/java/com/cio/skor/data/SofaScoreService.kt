package com.cio.skor.data

import com.cio.skor.network.HttpClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.max

/**
 * Optional SofaScore enrichment layer. It never participates in CIO source
 * scoring; it only adds 1X2 odds and recent team form to an already merged match.
 * If SofaScore is unavailable, the core five-source scan remains usable.
 */
class SofaScoreService {
    data class Odds(val home: String, val draw: String, val away: String)
    data class RecentMatch(
        val date: String,
        val opponent: String,
        val score: String,
        val isHome: Boolean,
        val result: String,
        val league: String = ""
    )

    private data class EventRef(
        val id: Long,
        val home: String,
        val away: String,
        val homeTeamId: Long?,
        val awayTeamId: Long?
    )

    private val http = HttpClient()
    private val base = "https://api.sofascore.com/api/v1"

    suspend fun enrichOdds(groups: List<MatchGroupData>): List<MatchGroupData> = coroutineScope {
        if (groups.isEmpty()) return@coroutineScope groups
        val events = loadTodayEvents()
        if (events.isEmpty()) return@coroutineScope groups

        val out = groups.toMutableList()
        // Keep network pressure modest; SofaScore may rate-limit aggressive bursts.
        groups.chunked(8).forEachIndexed { chunkIndex, chunk ->
            val results = chunk.map { group ->
                async(Dispatchers.IO) {
                    val event = events.firstOrNull {
                        MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                            MatchMerger.isSameTeam(it.away, group.awayTeam)
                    }
                    if (event == null) group else group.copy(odds = loadOdds(event.id))
                }
            }.awaitAll()
            val start = chunkIndex * 8
            results.forEachIndexed { index, value -> out[start + index] = value }
        }
        out
    }

    /** Resolve home/away SofaScore IDs once from today's scheduled events. */
    suspend fun enrichTeamIds(groups: List<MatchGroupData>): List<MatchGroupData> = withContext(Dispatchers.IO) {
        if (groups.isEmpty()) return@withContext groups
        val events = loadTodayEvents()
        if (events.isEmpty()) return@withContext groups
        groups.map { group ->
            val event = events.firstOrNull {
                MatchMerger.isSameTeam(it.home, group.homeTeam) &&
                    MatchMerger.isSameTeam(it.away, group.awayTeam)
            }
            if (event == null) group else group.copy(
                homeTeamId = event.homeTeamId,
                awayTeamId = event.awayTeamId
            )
        }
    }

    suspend fun resolveTeamId(teamName: String): Long? = withContext(Dispatchers.IO) {
        if (teamName.isBlank()) return@withContext null
        findTeamId(teamName)
    }

    suspend fun getLastFiveByTeamId(teamId: Long): List<RecentMatch> = withContext(Dispatchers.IO) {
        if (teamId <= 0L) return@withContext emptyList()
        val (code, body) = http.get("$base/team/$teamId/events/last/0", "https://www.sofascore.com/")
        if (code !in 200..299 || body.isNullOrBlank()) return@withContext emptyList()
        runCatching { parseRecentMatches(JSONObject(body), teamId).take(5) }.getOrDefault(emptyList())
    }

    private fun loadTodayEvents(): List<EventRef> {
        val date = LocalDate.now().toString()
        val (code, body) = http.get(
            "$base/sport/football/scheduled-events/$date",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return emptyList()
        return try {
            val events = JSONObject(body).optJSONArray("events") ?: return emptyList()
            buildList {
                for (i in 0 until events.length()) {
                    val e = events.optJSONObject(i) ?: continue
                    val home = e.optJSONObject("homeTeam")?.optString("name").orEmpty()
                    val away = e.optJSONObject("awayTeam")?.optString("name").orEmpty()
                    val id = e.optLong("id", -1L)
                    val homeId = e.optJSONObject("homeTeam")?.optLong("id", -1L)?.takeIf { it > 0 }
                    val awayId = e.optJSONObject("awayTeam")?.optLong("id", -1L)?.takeIf { it > 0 }
                    if (id > 0 && home.isNotBlank() && away.isNotBlank()) add(EventRef(id, home, away, homeId, awayId))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun loadOdds(eventId: Long): Odds? {
        val paths = listOf(
            "$base/event/$eventId/odds/1/all",
            "$base/event/$eventId/odds"
        )
        for (url in paths) {
            val (code, body) = http.get(url, "https://www.sofascore.com/")
            if (code !in 200..299 || body.isNullOrBlank()) continue
            parseOdds(JSONObject(body))?.let { return it }
        }
        return null
    }

    private fun parseOdds(root: JSONObject): Odds? {
        // SofaScore has changed the exact nesting of the odds payload over time.
        // Walk the JSON tree and accept the first 1/X/2 choice set with decimal values.
        fun walk(value: Any?): Odds? {
            when (value) {
                is JSONObject -> {
                    val choices = value.optJSONArray("choices")
                    if (choices != null) {
                        var one: String? = null
                        var draw: String? = null
                        var two: String? = null
                        for (i in 0 until choices.length()) {
                            val c = choices.optJSONObject(i) ?: continue
                            val name = c.optString("name").trim().uppercase()
                            val raw = c.opt("decimalValue") ?: c.opt("decimal") ?: c.opt("value")
                            val number = raw?.toString()?.toDoubleOrNull()
                            if (number == null || number <= 1.0 || number > 100.0) continue
                            val formatted = String.format(java.util.Locale.US, "%.2f", number)
                            when (name) {
                                "1", "HOME" -> one = formatted
                                "X", "DRAW" -> draw = formatted
                                "2", "AWAY" -> two = formatted
                            }
                        }
                        if (one != null && draw != null && two != null) return Odds(one, draw, two)
                    }
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val found = walk(value.opt(keys.next()))
                        if (found != null) return found
                    }
                }
                is JSONArray -> for (i in 0 until value.length()) {
                    val found = walk(value.opt(i))
                    if (found != null) return found
                }
            }
            return null
        }
        return walk(root)
    }

    private fun findTeamId(teamName: String): Long? {
        val query = java.net.URLEncoder.encode(teamName, Charsets.UTF_8.name())
        val (code, body) = http.get(
            "$base/search/all?q=$query",
            "https://www.sofascore.com/"
        )
        if (code !in 200..299 || body.isNullOrBlank()) return null
        return try {
            val root = JSONObject(body)
            val results = root.optJSONArray("results") ?: return null
            var bestId: Long? = null
            var bestScore = -1.0
            for (i in 0 until results.length()) {
                val item = results.optJSONObject(i) ?: continue
                val entityType = item.optString("type").lowercase()
                if (entityType.isNotBlank() && entityType != "team") continue
                val entity = item.optJSONObject("entity") ?: continue
                val id = entity.optLong("id", -1L)
                val name = entity.optString("name")
                if (id <= 0 || name.isBlank()) continue
                val score = teamSimilarity(name, teamName)
                if (score > bestScore) {
                    bestScore = score
                    bestId = id
                }
            }
            if (bestScore >= 0.82) bestId else null
        } catch (_: Exception) {
            null
        }
    }

    private fun teamSimilarity(a: String, b: String): Double {
        if (MatchMerger.isSameTeam(a, b)) return 1.0
        val aa = MatchMerger.normalizeTeamName(a).replace(" ", "")
        val bb = MatchMerger.normalizeTeamName(b).replace(" ", "")
        if (aa.isBlank() || bb.isBlank()) return 0.0
        val maxLen = max(aa.length, bb.length)
        var prev = IntArray(bb.length + 1) { it }
        var cur = IntArray(bb.length + 1)
        for (i in aa.indices) {
            cur[0] = i + 1
            for (j in bb.indices) {
                val cost = if (aa[i] == bb[j]) 0 else 1
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return 1.0 - prev[bb.length].toDouble() / maxLen.toDouble()
    }

    private fun parseRecentMatches(root: JSONObject, teamId: Long): List<RecentMatch> {
        val events = root.optJSONArray("events") ?: return emptyList()
        val out = mutableListOf<RecentMatch>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val status = e.optJSONObject("status")?.optString("type").orEmpty()
            if (status != "finished") continue
            val home = e.optJSONObject("homeTeam") ?: continue
            val away = e.optJSONObject("awayTeam") ?: continue
            val homeId = home.optLong("id", -1L)
            val awayId = away.optLong("id", -1L)
            val isHome = homeId == teamId
            if (!isHome && awayId != teamId) continue
            val opponent = if (isHome) away.optString("name") else home.optString("name")
            val hs = e.optJSONObject("homeScore")?.optInt("current", -1) ?: -1
            val ascore = e.optJSONObject("awayScore")?.optInt("current", -1) ?: -1
            if (hs < 0 || ascore < 0) continue
            val teamGoals = if (isHome) hs else ascore
            val oppGoals = if (isHome) ascore else hs
            val result = when {
                teamGoals > oppGoals -> "G"
                teamGoals < oppGoals -> "M"
                else -> "B"
            }
            val timestamp = e.optLong("startTimestamp", 0L)
            val date = if (timestamp > 0) {
                java.time.Instant.ofEpochSecond(timestamp)
                    .atZone(java.time.ZoneId.systemDefault()).toLocalDate().toString()
            } else ""
            val league = e.optJSONObject("tournament")?.optString("name").orEmpty()
            out += RecentMatch(date, opponent, "$teamGoals-$oppGoals", isHome, result, league)
        }
        return out.sortedByDescending { it.date }
    }

    data class MatchGroupData(
        val homeTeam: String,
        val awayTeam: String,
        val predictions: List<ScoreModel>,
        val odds: Odds? = null,
        val homeTeamId: Long? = null,
        val awayTeamId: Long? = null
    )

}
