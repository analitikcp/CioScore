package com.cio.skor.data

import java.text.Normalizer as JavaNormalizer
import java.util.Locale

/**
 * Global team identity layer.
 *
 * Rules are deliberately conservative:
 * - Unicode / Turkish characters are normalized.
 * - Punctuation and harmless club suffixes are removed only as edge tokens.
 * - Explicit aliases are preferred over broad fuzzy rules.
 * - The returned canonicalId is stable and source-independent.
 */
object TeamAliasCanonicalizer {

    private val removableEdgeTokens = setOf(
        "fc", "fk", "sk", "cd", "nk", "afc", "ff", "cf", "sc",
        "ac", "as", "bsc", "rc", "sv", "bk", "club", "calcio"
    )

    /**
     * High-confidence aliases only. Avoid broad mappings such as plain
     * "newcastle" -> "newcastle united" because they can collide with
     * Newcastle Jets / other clubs.
     */
    private val aliases = mapOf(
        "aek" to "aek athens",
        "aek athens" to "aek athens",
        "aek atina" to "aek athens",
        "aek athina" to "aek athens",
        "aek athens fc" to "aek athens",

        "lask" to "lask",
        "lask linz" to "lask",
        "lask linz fc" to "lask",

        "man utd" to "manchester united",
        "man united" to "manchester united",
        "manchester utd" to "manchester united",
        "manchester united" to "manchester united",
        "manchester united fc" to "manchester united",
        "man city" to "manchester city",
        "manchester city" to "manchester city",
        "psg" to "paris saint germain",
        "paris sg" to "paris saint germain",
        "tottenham" to "tottenham hotspur",
        "spurs" to "tottenham hotspur",
        "wolves" to "wolverhampton wanderers",
        "wolverhampton" to "wolverhampton wanderers",
        "west brom" to "west bromwich albion",
        "notts forest" to "nottingham forest",
        "brighton" to "brighton and hove albion",
        "qpr" to "queens park rangers"
    )

    data class TeamIdentity(
        val canonicalId: String,
        val canonicalName: String,
        val compactName: String
    )

    fun identity(rawName: String): TeamIdentity {
        val canonicalName = canonical(rawName)
        return TeamIdentity(
            canonicalId = canonicalName.replace(' ', '-'),
            canonicalName = canonicalName,
            compactName = canonicalName.replace(" ", "")
        )
    }

    fun canonical(name: String): String {
        if (name.isBlank()) return ""

        var value = name.trim().lowercase(Locale.ROOT)
            .replace("ı", "i")
            .replace("ğ", "g")
            .replace("ü", "u")
            .replace("ş", "s")
            .replace("ö", "o")
            .replace("ç", "c")

        value = JavaNormalizer.normalize(value, JavaNormalizer.Form.NFD)
            .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
            .replace("ß", "ss")
            .replace("æ", "ae")
            .replace("œ", "oe")
            .replace("ø", "o")
            .replace("ð", "d")
            .replace("þ", "th")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (value.isBlank()) return ""

        var tokens = value.split(' ').filter(String::isNotBlank).toMutableList()

        // Language/city variants are token-level only. This prevents accidental
        // substring corruption of unrelated club names.
        tokens = tokens.map { token ->
            when (token) {
                "athens", "atina", "athina" -> "athens"
                else -> token
            }
        }.toMutableList()

        // Remove harmless club-type tokens only at the edges.
        while (tokens.isNotEmpty() && tokens.first() in removableEdgeTokens) tokens.removeAt(0)
        while (tokens.isNotEmpty() && tokens.last() in removableEdgeTokens) tokens.removeAt(tokens.lastIndex)

        value = tokens.joinToString(" ").trim()
        if (value.isBlank()) return ""

        // Alias lookup must happen after normalization and edge-token cleanup.
        return aliases[value] ?: value
    }

    fun compact(name: String): String = canonical(name).replace(" ", "")

    fun exact(name1: String, name2: String): Boolean {
        val a = canonical(name1)
        val b = canonical(name2)
        return a.isNotBlank() && a == b
    }

    /**
     * Conservative fuzzy similarity over canonical identities.
     * Exact aliases always score 1.0.
     */
    fun similarity(name1: String, name2: String): Double {
        val a = canonical(name1)
        val b = canonical(name2)
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a == b) return 1.0
        if (a.length < 3 || b.length < 3) return 0.0

        val ca = a.replace(" ", "")
        val cb = b.replace(" ", "")
        if (ca == cb) return 1.0

        val shorter = minOf(ca.length, cb.length)
        if (shorter >= 5 && (ca.contains(cb) || cb.contains(ca))) return 0.92

        val maxLength = maxOf(ca.length, cb.length)
        if (maxLength == 0) return 1.0
        val distance = levenshtein(ca, cb)
        return ((maxLength - distance).toDouble() / maxLength).coerceIn(0.0, 1.0)
    }

    fun isSameTeam(name1: String, name2: String): Boolean =
        exact(name1, name2) || similarity(name1, name2) >= 0.80

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val replace = previous[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1
                val insert = current[j - 1] + 1
                val delete = previous[j] + 1
                current[j] = minOf(replace, insert, delete)
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }
}
