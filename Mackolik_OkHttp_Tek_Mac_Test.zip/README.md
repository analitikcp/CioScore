# Maçkolik Android OkHttp Testi

Bu küçük uygulama CioScore'a dokunmadan sadece şu soruyu test eder:

Android cihazdan OkHttp ile
https://arsiv.mackolik.com/Program/Program.aspx
sayfası okunabiliyor mu?

Test:
- HTTP durum kodu
- dönen HTML karakter sayısı
- Cagliari bulunuyor mu?
- Lecce bulunuyor mu?
- örnek oran metinlerinden biri bulunuyor mu?

## Kullanım

1. ZIP'i aç.
2. Android Studio ile klasörü aç.
3. Gradle sync tamamlanınca Debug APK oluştur.
4. Telefona kur ve uygulamayı aç.
5. Ekrandaki TEST sonucunun ekran görüntüsünü gönder.

Bu testin amacı henüz oranları CioScore'a eklemek değildir. Önce Android OkHttp erişimini kanıtlamaktır.
