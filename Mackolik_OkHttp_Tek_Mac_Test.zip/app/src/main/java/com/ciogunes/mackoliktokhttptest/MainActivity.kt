package com.ciogunes.mackoliktokhttptest

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)

        Thread {
            testMackolik()
        }.start()
    }

    private fun testMackolik() {
        val url = "https://arsiv.mackolik.com/Program/Program.aspx"
        val client = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .build()

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/151 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.8")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val hasCagliari = body.contains("Cagliari", ignoreCase = true)
                val hasLecce = body.contains("Lecce", ignoreCase = true)
                val hasOdds = body.contains("1.81") || body.contains("2.84") || body.contains("3.68")

                val message = buildString {
                    appendLine("HTTP: ${response.code}")
                    appendLine("Body: ${body.length} karakter")
                    appendLine("Cagliari: ${if (hasCagliari) "VAR" else "YOK"}")
                    appendLine("Lecce: ${if (hasLecce) "VAR" else "YOK"}")
                    appendLine("Örnek oran bulundu: ${if (hasOdds) "EVET" else "HAYIR"}")
                    appendLine()
                    appendLine(if (response.isSuccessful && hasCagliari && hasLecce)
                        "SONUÇ: Android OkHttp HTML'yi okuyabiliyor."
                    else
                        "SONUÇ: Android OkHttp testi başarısız veya sayfa farklı içerik döndürüyor.")
                    appendLine()
                    appendLine("İlk 1500 karakter:")
                    append(body.take(1500))
                }

                runOnUiThread {
                    status.text = "TEST TAMAMLANDI"
                    result.text = message
                }
            }
        } catch (e: Exception) {
            runOnUiThread {
                status.text = "TEST HATASI"
                result.text = "${e.javaClass.simpleName}: ${e.message}"
            }
        }
    }
}
