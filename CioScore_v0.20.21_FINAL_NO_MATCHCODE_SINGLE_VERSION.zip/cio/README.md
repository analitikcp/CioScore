# CioScore v0.20.21

## Current release

This ZIP contains the current CioScore source tree. Historical README/build-marker files are intentionally excluded so the project has a single canonical release number.

**Version:** 0.20.21

## Scope
- 8-source score prediction pipeline
- Global fixture identity / merge engine
- Official İddaa odds integration
- HT/FT integration
- Popular Bets integration
- Current production UI and reliability fixes
- MatchCode-based Popular Bets identity has been completely removed

## Version policy
All project-facing version references in this release must use **0.20.21**. Historical version markers are not shipped inside the source ZIP.
